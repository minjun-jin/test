import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// URPRMGT006 컴포넌트를 불러옵니다.
import URPRMGT006 from "@/pages/views/rpr/URPRMGT-006"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(URPRMGT006)

describe("[URPRMGT-006] 자금반환 - FAX 청구접수 반환 등록", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("19900101")
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])
  })

  it("getListFaxFundReturn Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it.each([
    {
      target: {
        data: {
          rqstRtnDvsnCd: "01",
          trDt: "20250101",
          respCd: "01",
        },
      },
    },
    {
      target: {
        data: {
          rqstRtnDvsnCd: "02",
          trDt: "20250101",
          respCd: null,
        },
      },
    },
  ])("valueGetter Test", async (data) => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, data)
  })

  it.each([
    {
      rqstRtnDvsnCd: "01",
      kftcBizDvsnCd: "03",
      aprvStsCd: "01",
    },
    {
      rqstRtnDvsnCd: "02",
    },
  ])("onRowClicked Test", async (param) => {
    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: param } })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })

  it.each([
    {
      data: {
        aprvStsCd: "01",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
      },
    },

    {
      data: {
        aprvStsCd: "02",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
      },
    },

    {
      data: {
        aprvStsCd: null,
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
      },
    },
  ])("onRowDoubleClicked Test", async (param) => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: param.data,
      },
    })

    await waitFor(() => {
      param.expect()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("createFaxFundReturn Test", async () => {
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {},
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
        },
      })
    const { findByText } = render(component)

    const newClickBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newClickBtn)

    const regBtn = await findByText(/SCRNITM#reg/)
    fireEvent.click(regBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("validate Test", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(1).mockReturnValueOnce(0)
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(validateTestBtn, { target: { data: {} } })
  })

  it.each(["51", "52", "99"])("updateRtnRjctRsnCd Test", async (param) => {
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#rtnRjctRsnCd/),
    ).findByTestId("onChange")

    fireEvent.click(onChangeTestBtn, { target: { data: param } })
  })

  it.each(["N", "Y", "T"])("updateRtnYn Test", async (param) => {
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#rtnYn/),
    ).findByTestId("onChange")

    fireEvent.click(onChangeTestBtn, { target: { data: param } })
  })

  it.each(["N", "Y"])("updateRqstRtnTrAmt Test", async (param) => {
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#fullRtnYn/),
    ).findByTestId("onChange")

    fireEvent.click(onChangeTestBtn, { target: { data: param } })
  })

  it.each(["01", "05"])("updateRtnRsn Test", async (param) => {
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#rtnRsnCd/),
    ).findByTestId("onChange")

    fireEvent.click(onChangeTestBtn, { target: { data: param } })
  })
})
