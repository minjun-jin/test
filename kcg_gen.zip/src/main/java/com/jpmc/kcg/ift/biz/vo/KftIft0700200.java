package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 거래집계(대변집계)
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 전문의 처리결과를 정의해 주는 코드
 * messageSendTime 전문전송시간 
 * failureInstitutionCode 장애기관코드 
 * debitCashDepositCount 차변현금입금건수 
 * debitCashDepositAmount 차변현금입금금액 
 * filler1 FILLER 
 * filler2 FILLER 
 * debitCashCancelCount 차변현금취소건수 
 * debitCashCancelAmount 차변현금취소금액 
 * filler3 FILLER 
 * filler4 FILLER 
 * debitCashDepositFailedCount 차변현금입금불능건수 
 * debitCashDepositFailedAmount 차변현금입금불능금액 
 * filler5 FILLER 
 * filler6 FILLER 
 * debitChequeInquiryCount 차변자기앞수표조회건수 
 * debitDishonorPaymentTransactionCount 차변부도출금거래건수 
 * debitDishonorPaymentTransactionAmount 차변부도출금거래금액 
 * filler7 FILLER 
 * reservedInformationField11 예비정보FIELD 중계센터 및 참가기관에서 임의 사용 가능한 FIELD
 * 
 * KftIft0700200 kftIft0700200 = new KftIft0700200(); // 거래집계(대변집계)
 * kftIft0700200.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftIft0700200.setSystemId("03"); // 시스템-ID
 * kftIft0700200.setInstitutionCode("057"); // 기관코드
 * kftIft0700200.setMessageType("0700"); // 전문종별구분코드
 * kftIft0700200.setMessageCode("200"); // 업무구분코드
 * kftIft0700200.setSendReceiveFlag("1"); // 송수신FLAG
 * kftIft0700200.setResponseCode(""); // 응답코드
 * kftIft0700200.setMessageSendTime(LocalDateTime.now()); // 전문전송시간
 * kftIft0700200.setFailureInstitutionCode("000"); // 장애기관코드
 * kftIft0700200.setDebitCashDepositCount(0); // 차변현금입금건수
 * kftIft0700200.setDebitCashDepositAmount(0L); // 차변현금입금금액
 * kftIft0700200.setFiller1(0); // FILLER
 * kftIft0700200.setFiller2(0L); // FILLER
 * kftIft0700200.setDebitCashCancelCount(0); // 차변현금취소건수
 * kftIft0700200.setDebitCashCancelAmount(0L); // 차변현금취소금액
 * kftIft0700200.setFiller3(0); // FILLER
 * kftIft0700200.setFiller4(0L); // FILLER
 * kftIft0700200.setDebitCashDepositFailedCount(0); // 차변현금입금불능건수
 * kftIft0700200.setDebitCashDepositFailedAmount(0L); // 차변현금입금불능금액
 * kftIft0700200.setFiller5(0); // FILLER
 * kftIft0700200.setFiller6(0L); // FILLER
 * kftIft0700200.setDebitChequeInquiryCount(0); // 차변자기앞수표조회건수
 * kftIft0700200.setDebitDishonorPaymentTransactionCount(0); // 차변부도출금거래건수
 * kftIft0700200.setDebitDishonorPaymentTransactionAmount(0L); // 차변부도출금거래금액
 * kftIft0700200.setFiller7(0L); // FILLER
 * kftIft0700200.setReservedInformationField11(""); // 예비정보FIELD
 * }</pre>
 */
@Data
public class KftIft0700200 implements KftIftMngHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0700"; // 전문종별구분코드
	private String messageCode = "200"; // 업무구분코드
	private String sendReceiveFlag = "1"; // 송수신FLAG
	private String responseCode; // 응답코드
	private LocalDateTime messageSendTime; // 전문전송시간
	private String failureInstitutionCode = "000"; // 장애기관코드
	private int debitCashDepositCount; // 차변현금입금건수
	private long debitCashDepositAmount; // 차변현금입금금액
	private int filler1; // FILLER
	private long filler2; // FILLER
	private int debitCashCancelCount; // 차변현금취소건수
	private long debitCashCancelAmount; // 차변현금취소금액
	private int filler3; // FILLER
	private long filler4; // FILLER
	private int debitCashDepositFailedCount; // 차변현금입금불능건수
	private long debitCashDepositFailedAmount; // 차변현금입금불능금액
	private int filler5; // FILLER
	private long filler6; // FILLER
	private int debitChequeInquiryCount; // 차변자기앞수표조회건수
	private int debitDishonorPaymentTransactionCount; // 차변부도출금거래건수
	private long debitDishonorPaymentTransactionAmount; // 차변부도출금거래금액
	private long filler7; // FILLER
	private String reservedInformationField11; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failureInstitutionCode$; // 장애기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashDepositCount$; // 차변현금입금건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashDepositAmount$; // 차변현금입금금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashCancelCount$; // 차변현금취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashCancelAmount$; // 차변현금취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashDepositFailedCount$; // 차변현금입금불능건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCashDepositFailedAmount$; // 차변현금입금불능금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler5$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler6$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitChequeInquiryCount$; // 차변자기앞수표조회건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitDishonorPaymentTransactionCount$; // 차변부도출금거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitDishonorPaymentTransactionAmount$; // 차변부도출금거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler7$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 업무구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(debitCashDepositCount$)) { // 차변현금입금건수
			return 9;
		}
		if (VOUtils.isWhitespace(debitCashDepositAmount$)) { // 차변현금입금금액
			return 10;
		}
		if (VOUtils.isWhitespace(debitCashCancelCount$)) { // 차변현금취소건수
			return 13;
		}
		if (VOUtils.isWhitespace(debitCashCancelAmount$)) { // 차변현금취소금액
			return 14;
		}
		if (VOUtils.isWhitespace(debitCashDepositFailedCount$)) { // 차변현금입금불능건수
			return 17;
		}
		if (VOUtils.isWhitespace(debitCashDepositFailedAmount$)) { // 차변현금입금불능금액
			return 18;
		}
		if (VOUtils.isWhitespace(debitChequeInquiryCount$)) { // 차변자기앞수표조회건수
			return 21;
		}
		if (VOUtils.isWhitespace(debitDishonorPaymentTransactionCount$)) { // 차변부도출금거래건수
			return 22;
		}
		if (VOUtils.isWhitespace(debitDishonorPaymentTransactionAmount$)) { // 차변부도출금거래금액
			return 23;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageSendTime$ = VOUtils.write(out, messageSendTime, 12, "yyMMddHHmmss"); // 전문전송시간
		failureInstitutionCode$ = VOUtils.write(out, failureInstitutionCode, 3); // 장애기관코드
		debitCashDepositCount$ = VOUtils.write(out, debitCashDepositCount, 6); // 차변현금입금건수
		debitCashDepositAmount$ = VOUtils.write(out, debitCashDepositAmount, 14); // 차변현금입금금액
		filler1$ = VOUtils.write(out, filler1, 6); // FILLER
		filler2$ = VOUtils.write(out, filler2, 14); // FILLER
		debitCashCancelCount$ = VOUtils.write(out, debitCashCancelCount, 6); // 차변현금취소건수
		debitCashCancelAmount$ = VOUtils.write(out, debitCashCancelAmount, 14); // 차변현금취소금액
		filler3$ = VOUtils.write(out, filler3, 6); // FILLER
		filler4$ = VOUtils.write(out, filler4, 14); // FILLER
		debitCashDepositFailedCount$ = VOUtils.write(out, debitCashDepositFailedCount, 6); // 차변현금입금불능건수
		debitCashDepositFailedAmount$ = VOUtils.write(out, debitCashDepositFailedAmount, 14); // 차변현금입금불능금액
		filler5$ = VOUtils.write(out, filler5, 6); // FILLER
		filler6$ = VOUtils.write(out, filler6, 14); // FILLER
		debitChequeInquiryCount$ = VOUtils.write(out, debitChequeInquiryCount, 6); // 차변자기앞수표조회건수
		debitDishonorPaymentTransactionCount$ = VOUtils.write(out, debitDishonorPaymentTransactionCount, 6); // 차변부도출금거래건수
		debitDishonorPaymentTransactionAmount$ = VOUtils.write(out, debitDishonorPaymentTransactionAmount, 14); // 차변부도출금거래금액
		filler7$ = VOUtils.write(out, filler7, 14); // FILLER
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 10); // 예비정보FIELD
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 전문전송시간
		failureInstitutionCode = VOUtils.toString(failureInstitutionCode$ = VOUtils.read(in, 3)); // 장애기관코드
		debitCashDepositCount = VOUtils.toInt(debitCashDepositCount$ = VOUtils.read(in, 6)); // 차변현금입금건수
		debitCashDepositAmount = VOUtils.toLong(debitCashDepositAmount$ = VOUtils.read(in, 14)); // 차변현금입금금액
		filler1 = VOUtils.toInt(filler1$ = VOUtils.read(in, 6)); // FILLER
		filler2 = VOUtils.toLong(filler2$ = VOUtils.read(in, 14)); // FILLER
		debitCashCancelCount = VOUtils.toInt(debitCashCancelCount$ = VOUtils.read(in, 6)); // 차변현금취소건수
		debitCashCancelAmount = VOUtils.toLong(debitCashCancelAmount$ = VOUtils.read(in, 14)); // 차변현금취소금액
		filler3 = VOUtils.toInt(filler3$ = VOUtils.read(in, 6)); // FILLER
		filler4 = VOUtils.toLong(filler4$ = VOUtils.read(in, 14)); // FILLER
		debitCashDepositFailedCount = VOUtils.toInt(debitCashDepositFailedCount$ = VOUtils.read(in, 6)); // 차변현금입금불능건수
		debitCashDepositFailedAmount = VOUtils.toLong(debitCashDepositFailedAmount$ = VOUtils.read(in, 14)); // 차변현금입금불능금액
		filler5 = VOUtils.toInt(filler5$ = VOUtils.read(in, 6)); // FILLER
		filler6 = VOUtils.toLong(filler6$ = VOUtils.read(in, 14)); // FILLER
		debitChequeInquiryCount = VOUtils.toInt(debitChequeInquiryCount$ = VOUtils.read(in, 6)); // 차변자기앞수표조회건수
		debitDishonorPaymentTransactionCount = VOUtils.toInt(debitDishonorPaymentTransactionCount$ = VOUtils.read(in, 6)); // 차변부도출금거래건수
		debitDishonorPaymentTransactionAmount = VOUtils.toLong(debitDishonorPaymentTransactionAmount$ = VOUtils.read(in, 14)); // 차변부도출금거래금액
		filler7 = VOUtils.toLong(filler7$ = VOUtils.read(in, 14)); // FILLER
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 10)); // 예비정보FIELD
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", failureInstitutionCode=").append(failureInstitutionCode).append(System.lineSeparator()); // 장애기관코드
		sb.append(", debitCashDepositCount=").append(debitCashDepositCount).append(System.lineSeparator()); // 차변현금입금건수
		sb.append(", debitCashDepositAmount=").append(debitCashDepositAmount).append(System.lineSeparator()); // 차변현금입금금액
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", debitCashCancelCount=").append(debitCashCancelCount).append(System.lineSeparator()); // 차변현금취소건수
		sb.append(", debitCashCancelAmount=").append(debitCashCancelAmount).append(System.lineSeparator()); // 차변현금취소금액
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append(", debitCashDepositFailedCount=").append(debitCashDepositFailedCount).append(System.lineSeparator()); // 차변현금입금불능건수
		sb.append(", debitCashDepositFailedAmount=").append(debitCashDepositFailedAmount).append(System.lineSeparator()); // 차변현금입금불능금액
		sb.append(", filler5=").append(filler5).append(System.lineSeparator()); // FILLER
		sb.append(", filler6=").append(filler6).append(System.lineSeparator()); // FILLER
		sb.append(", debitChequeInquiryCount=").append(debitChequeInquiryCount).append(System.lineSeparator()); // 차변자기앞수표조회건수
		sb.append(", debitDishonorPaymentTransactionCount=").append(debitDishonorPaymentTransactionCount).append(System.lineSeparator()); // 차변부도출금거래건수
		sb.append(", debitDishonorPaymentTransactionAmount=").append(debitDishonorPaymentTransactionAmount).append(System.lineSeparator()); // 차변부도출금거래금액
		sb.append(", filler7=").append(filler7).append(System.lineSeparator()); // FILLER
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0700"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "200"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "1"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "failureInstitutionCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "debitCashDepositCount", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "debitCashDepositAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler1", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "debitCashCancelCount", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "debitCashCancelAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "filler4", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "debitCashDepositFailedCount", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "debitCashDepositFailedAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler5", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "filler6", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "debitChequeInquiryCount", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "debitDishonorPaymentTransactionCount", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "debitDishonorPaymentTransactionAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler7", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "reservedInformationField11", "fldLen", "10", "defltVal", "")
		);
	}

}
