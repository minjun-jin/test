package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시 대행 요청내역
 * <pre>{@code
 * KftEntES9999R kftEntES9999R  = new KftEntES9999R(); // 지급제시 대행 요청내역
 * kftEntES9999R.setFileName(""); // 업무구분
 * kftEntES9999R.setDataType(""); // 데이터구분
 * kftEntES9999R.setSerialNumber(""); // 일련번호
 * kftEntES9999R.setPaymentPresentationDate(""); // 지급제시일자
 * kftEntES9999R.setPaymentPresentationNumber(""); // 지급제시번호
 * kftEntES9999R.setSettlementProcessSort(""); // 결제처리구분
 * kftEntES9999R.setEnoteNumber(""); // 어음번호
 * kftEntES9999R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES9999R.setEnoteIssueAmount(0L); // 어음발행일자
 * kftEntES9999R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES9999R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES9999R.setSplitNumber(""); // 분할번호
 * kftEntES9999R.setEndorsementNumber(""); // 배서번호
 * kftEntES9999R.setEnoteMaturedSettlementDateTime(""); // 전자어음 만기 결제일시
 * kftEntES9999R.setDefaultDate(""); // 부도일
 * kftEntES9999R.setEnoteDefaultReason(""); // 전자어음 부도사유
 * kftEntES9999R.setAccidentReportReason(""); // 사고신고서 사유
 * kftEntES9999R.setPaymentSuspensionProvisionalDisposition(""); // 지급정지 가처분
 * kftEntES9999R.setSpecialDeposit(""); // 별단예금 입금
 * kftEntES9999R.setBankManagementCompanyYn(""); // 은행관리 기업여부
 * kftEntES9999R.setRestructuringTargetCompanyYn(""); // 구조조정대상기업여부
 * kftEntES9999R.setDepositShortageCause(""); // 예금부족 원인
 * kftEntES9999R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES9999R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String paymentPresentationDate; // 지급제시일자
	private String paymentPresentationNumber; // 지급제시번호
	private String settlementProcessSort; // 결제처리구분
	private String enoteNumber; // 어음번호
	private String enoteIssueDate; // 어음발행일자
	private long enoteIssueAmount; // 어음발행일자
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String splitNumber; // 분할번호
	private String endorsementNumber; // 배서번호
	private String enoteMaturedSettlementDateTime; // 전자어음 만기 결제일시
	private String defaultDate; // 부도일
	private String enoteDefaultReason; // 전자어음 부도사유
	private String accidentReportReason; // 사고신고서 사유
	private String paymentSuspensionProvisionalDisposition; // 지급정지 가처분
	private String specialDeposit; // 별단예금 입금
	private String bankManagementCompanyYn; // 은행관리 기업여부
	private String restructuringTargetCompanyYn; // 구조조정대상기업여부
	private String depositShortageCause; // 예금부족 원인
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationNumber$; // 지급제시번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String settlementProcessSort$; // 결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementNumber$; // 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedSettlementDateTime$; // 전자어음 만기 결제일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 부도일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteDefaultReason$; // 전자어음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportReason$; // 사고신고서 사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentSuspensionProvisionalDisposition$; // 지급정지 가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specialDeposit$; // 별단예금 입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankManagementCompanyYn$; // 은행관리 기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String restructuringTargetCompanyYn$; // 구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositShortageCause$; // 예금부족 원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		paymentPresentationNumber$ = VOUtils.write(out, paymentPresentationNumber, 16); // 지급제시번호
		settlementProcessSort$ = VOUtils.write(out, settlementProcessSort, 2); // 결제처리구분
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행일자
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // 배서번호
		enoteMaturedSettlementDateTime$ = VOUtils.write(out, enoteMaturedSettlementDateTime, 14); // 전자어음 만기 결제일시
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 부도일
		enoteDefaultReason$ = VOUtils.write(out, enoteDefaultReason, 2); // 전자어음 부도사유
		accidentReportReason$ = VOUtils.write(out, accidentReportReason, 1); // 사고신고서 사유
		paymentSuspensionProvisionalDisposition$ = VOUtils.write(out, paymentSuspensionProvisionalDisposition, 1); // 지급정지 가처분
		specialDeposit$ = VOUtils.write(out, specialDeposit, 1); // 별단예금 입금
		bankManagementCompanyYn$ = VOUtils.write(out, bankManagementCompanyYn, 1); // 은행관리 기업여부
		restructuringTargetCompanyYn$ = VOUtils.write(out, restructuringTargetCompanyYn, 1); // 구조조정대상기업여부
		depositShortageCause$ = VOUtils.write(out, depositShortageCause, 1); // 예금부족 원인
		filler2$ = VOUtils.write(out, filler2, 7); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		paymentPresentationNumber = VOUtils.toString(paymentPresentationNumber$ = VOUtils.read(in, 16)); // 지급제시번호
		settlementProcessSort = VOUtils.toString(settlementProcessSort$ = VOUtils.read(in, 2)); // 결제처리구분
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행일자
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // 배서번호
		enoteMaturedSettlementDateTime = VOUtils.toString(enoteMaturedSettlementDateTime$ = VOUtils.read(in, 14)); // 전자어음 만기 결제일시
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 부도일
		enoteDefaultReason = VOUtils.toString(enoteDefaultReason$ = VOUtils.read(in, 2)); // 전자어음 부도사유
		accidentReportReason = VOUtils.toString(accidentReportReason$ = VOUtils.read(in, 1)); // 사고신고서 사유
		paymentSuspensionProvisionalDisposition = VOUtils.toString(paymentSuspensionProvisionalDisposition$ = VOUtils.read(in, 1)); // 지급정지 가처분
		specialDeposit = VOUtils.toString(specialDeposit$ = VOUtils.read(in, 1)); // 별단예금 입금
		bankManagementCompanyYn = VOUtils.toString(bankManagementCompanyYn$ = VOUtils.read(in, 1)); // 은행관리 기업여부
		restructuringTargetCompanyYn = VOUtils.toString(restructuringTargetCompanyYn$ = VOUtils.read(in, 1)); // 구조조정대상기업여부
		depositShortageCause = VOUtils.toString(depositShortageCause$ = VOUtils.read(in, 1)); // 예금부족 원인
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 7)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", paymentPresentationNumber=").append(paymentPresentationNumber).append(System.lineSeparator()); // 지급제시번호
		sb.append(", settlementProcessSort=").append(settlementProcessSort).append(System.lineSeparator()); // 결제처리구분
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // 배서번호
		sb.append(", enoteMaturedSettlementDateTime=").append(enoteMaturedSettlementDateTime).append(System.lineSeparator()); // 전자어음 만기 결제일시
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 부도일
		sb.append(", enoteDefaultReason=").append(enoteDefaultReason).append(System.lineSeparator()); // 전자어음 부도사유
		sb.append(", accidentReportReason=").append(accidentReportReason).append(System.lineSeparator()); // 사고신고서 사유
		sb.append(", paymentSuspensionProvisionalDisposition=").append(paymentSuspensionProvisionalDisposition).append(System.lineSeparator()); // 지급정지 가처분
		sb.append(", specialDeposit=").append(specialDeposit).append(System.lineSeparator()); // 별단예금 입금
		sb.append(", bankManagementCompanyYn=").append(bankManagementCompanyYn).append(System.lineSeparator()); // 은행관리 기업여부
		sb.append(", restructuringTargetCompanyYn=").append(restructuringTargetCompanyYn).append(System.lineSeparator()); // 구조조정대상기업여부
		sb.append(", depositShortageCause=").append(depositShortageCause).append(System.lineSeparator()); // 예금부족 원인
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentPresentationNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "settlementProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "enoteMaturedSettlementDateTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "paymentSuspensionProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "specialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankManagementCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "restructuringTargetCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "depositShortageCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "7", "defltVal", "")
		);
	}

}
