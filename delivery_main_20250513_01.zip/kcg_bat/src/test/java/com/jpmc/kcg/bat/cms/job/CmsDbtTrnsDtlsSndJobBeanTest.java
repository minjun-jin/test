package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.bat.BatJobTestSupporter;
import com.jpmc.kcg.bat.cms.biz.CmsAtSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dao.BatCmsAtSndRcvFileLDao;
import com.jpmc.kcg.bat.cms.dao.BatCmsWhdrwlTrnAplyMDao;
import com.jpmc.kcg.bat.com.biz.ComFileTractLBean;
import com.jpmc.kcg.cms.biz.CmsAccountValidator;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112H;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112R;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112T;
import com.jpmc.kcg.cms.dao.CmsAtSndRcvFileLMapper;
import com.jpmc.kcg.cms.dto.AccountOut;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.frw.SystemProperties;
import com.jpmc.kcg.frw.VOUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class CmsDbtTrnsDtlsSndJobBeanTest extends BatJobTestSupporter {

    @Mock
    private BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao;
    @Mock
    private BatCmsAtSndRcvFileLDao batCmsAtSndRcvFileLDao;
    @Mock 
    private CmsAtSndRcvFileLMapper cmsAtSndRcvFileLMapper;
    @Mock
    private CmsAtSndRcvLogManager cmsAtSndRcvLogManager;
    @Mock
    private CmsAccountValidator cmsAccountValidator;
    @Mock
    private SystemProperties systemProperties;
    @Mock
    private ComFileTractLBean comFileTractLBean;
    @Mock
    private BizDate bizDate;
    @InjectMocks
    private CmsDbtTrnsDtlsSndJobBean cmsDbtTrnsDtlsSndJobBean;

    // 새로 추가: MockedStatic 객체를 저장할 변수
    private MockedStatic<VOUtils> voUtilsMockedStatic;

    @BeforeEach
    void setUp() {
        // Mock static 객체 세팅
        voUtilsMockedStatic = mockStatic(VOUtils.class);
        Map<String, Object> param = new HashMap<String, Object>();
        param.put(FILE_NO, AT1112);
        param.put("TR_DT", "20241112");
        param.put("SR_DT", "20241112");
        param.put(TOT_RECORD_COUNT, 0);
        param.put(NEW_COUNT, 0);
        param.put(TERM_COUNT, 0);
        param.put(ERROR_COUNT, 0);
        param.put(TARGET_LIST, new ArrayList<CmsWhdrwlTrnAplyM>());
        setParamMap(param);
        setOrdDt("20241112");
    }

    @AfterEach
    void tearDown() {
        if (voUtilsMockedStatic != null) {
            voUtilsMockedStatic.close();
        }
    }

    private CmsWhdrwlTrnAplyM createMockRecord(String regStsCd, String regDvsnCd) {
        CmsWhdrwlTrnAplyM record = new CmsWhdrwlTrnAplyM();
        record.setAcctNo("123");
        record.setCorpCd("CORP");
        record.setRtpyrId("RTPYR");
        record.setRegStsCd(regStsCd);
        record.setRegDvsnCd(regDvsnCd);
        record.setLastChgDt("20241112");
        return record;
    }

    private AccountOut createValidAccount() {
        return AccountOut.builder().acctNo("123").acctNm("Tester").ctzBizNo("987").respCd("0000").build();
    }

    @Test
    @DisplayName("[AT1112] 신규_정상처리_테스트")
    void test1() {
        var item = createMockRecord("1", "1");
        when(VOUtils.toString(any(KftCmsAT1112H.class))).thenReturn("header content");
        when(batCmsWhdrwlTrnAplyMDao.selectList(any())).thenReturn(List.of(item));
        when(VOUtils.toString(any(KftCmsAT1112T.class))).thenReturn("trailer content");
        when(cmsAccountValidator.validateAccount(anyString())).thenReturn(createValidAccount());
        when(VOUtils.toString(any(KftCmsAT1112R.class))).thenReturn("test content");
        when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        execute(cmsDbtTrnsDtlsSndJobBean);
        assertEquals(1, batContext.getData(NEW_COUNT));
        
    }

    @Test
    @DisplayName("[AT1112] 해지_정상처리_테스트")
    void test2() {
        var item = createMockRecord("20", "1");
        when(VOUtils.toString(any(KftCmsAT1112H.class))).thenReturn("header content");
        when(batCmsWhdrwlTrnAplyMDao.selectList(any())).thenReturn(List.of(item));
        when(VOUtils.toString(any(KftCmsAT1112T.class))).thenReturn("trailer content");
        when(cmsAccountValidator.validateAccount(anyString())).thenReturn(createValidAccount());
        when(VOUtils.toString(any(KftCmsAT1112R.class))).thenReturn("test content");
        when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        execute(cmsDbtTrnsDtlsSndJobBean);
        assertEquals(1, batContext.getData(TERM_COUNT));
    }

    @Test
    @DisplayName("[AT1112] 계좌검증_실패시_ERROR_COUNT_증가") 
    void test3() {
        var item = createMockRecord("10", "1");
        AccountOut invalidAccount = AccountOut.builder().respCd("9999").build();
        when(VOUtils.toString(any(KftCmsAT1112H.class))).thenReturn("header content");
        when(batCmsWhdrwlTrnAplyMDao.selectList(any())).thenReturn(List.of(item));
        when(VOUtils.toString(any(KftCmsAT1112T.class))).thenReturn("trailer content");
        when(cmsAccountValidator.validateAccount(anyString())).thenReturn(invalidAccount);
        when(VOUtils.toString(any(KftCmsAT1112R.class))).thenReturn("test content");
        when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        execute(cmsDbtTrnsDtlsSndJobBean);
        assertEquals(1, batContext.getData(ERROR_COUNT));
    }

    @Test
    @DisplayName("[AT1112] 통합관리시스템_접수구분_처리")
    void test4() {
        var item = createMockRecord("10", "X");
                when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        when(VOUtils.toString(any(KftCmsAT1112H.class))).thenReturn("header content");
        when(batCmsWhdrwlTrnAplyMDao.selectList(any())).thenReturn(List.of(item));
        when(VOUtils.toString(any(KftCmsAT1112T.class))).thenReturn("trailer content");
        when(cmsAccountValidator.validateAccount(anyString())).thenReturn(createValidAccount());
        when(VOUtils.toString(any(KftCmsAT1112R.class))).thenReturn("test content");
        when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        execute(cmsDbtTrnsDtlsSndJobBean);
        // 확인만 수행, 값 검증은 로그로 가능
    }

    @Test
    @DisplayName("[AT1112] 정상 케이스")
    void test5() {
        CmsWhdrwlTrnAplyM application = new CmsWhdrwlTrnAplyM();
        application.setAcctNo("1234567890");
        application.setCorpCd("CORP1");
        application.setRtpyrId("RTPYR1");
        application.setRegStsCd("10");
        application.setRegDvsnCd("1");

        AccountOut account = AccountOut.builder()
                .acctNo("1234567890")
                .acctNm("Test Account")
                .ctzBizNo("1234567890")
                .respCd("0000")
                .build();

        // Mock DAOs
        when(batCmsAtSndRcvFileLDao.selectSndRcvFileList(any(), anyBoolean())).thenReturn(Collections.emptyList());
        when(VOUtils.toString(any(KftCmsAT1112H.class))).thenReturn("header content");
        
        List<CmsWhdrwlTrnAplyM> cmsWhdrwlTrnAplyMList = Collections.singletonList(application);
        when(batCmsWhdrwlTrnAplyMDao.selectList(any())).thenReturn(cmsWhdrwlTrnAplyMList);
        when(VOUtils.toString(any(KftCmsAT1112T.class))).thenReturn("trailer content");
        when(cmsAccountValidator.validateAccount(anyString())).thenReturn(account);
        when(VOUtils.toString(any(KftCmsAT1112R.class))).thenReturn("test content");
        
        // Execute the job
        execute(cmsDbtTrnsDtlsSndJobBean);

        // Verify interactions with DAOs and Validators
        verify(batCmsWhdrwlTrnAplyMDao).selectList(any());
        verify(cmsAccountValidator).validateAccount(anyString());
    }

}