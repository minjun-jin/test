package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 상환청구내역
 * <pre>{@code
 * KftEntES1116R kftEntES1116R  = new KftEntES1116R(); // 상환청구내역
 * kftEntES1116R.setFileName(""); // 업무구분
 * kftEntES1116R.setDataType(""); // 데이터구분
 * kftEntES1116R.setSerialNumber(""); // 일련번호
 * kftEntES1116R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1116R.setBankCode(""); // 은행코드
 * kftEntES1116R.setType(""); // 구분
 * kftEntES1116R.setRepaymentClaimDate(""); // 상환청구일자
 * kftEntES1116R.setEnoteNumber(""); // 어음번호
 * kftEntES1116R.setEnoteType(""); // 어음종류
 * kftEntES1116R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1116R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1116R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1116R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1116R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1116R.setDefaultReasonCode(""); // 부도사유코드
 * kftEntES1116R.setDefaultDate(""); // 부도일자
 * kftEntES1116R.setRepaymentObligorCorpIndvSort(""); // 상환의무인-법인개인구분
 * kftEntES1116R.setRepaymentObligorResidentBusinessNumber(""); // 상환의무인-주민사업자번호
 * kftEntES1116R.setRepaymentObligorCorpName(""); // 상환의무인-법인명
 * kftEntES1116R.setRepaymentObligorNameRepresentativeName(""); // 상환의무인-성명(대표자명)
 * kftEntES1116R.setRepaymentObligorAddress(""); // 상환의무인-주소
 * kftEntES1116R.setRepaymentObligorBankCode(""); // 상환의무인-은행코드
 * kftEntES1116R.setRepaymentObligorCurrentCreditAccountNumber(""); // 상환의무인-당좌(입금)계좌번호
 * kftEntES1116R.setRepaymentObligorSplitNumber(""); // 상환의무인 분할번호
 * kftEntES1116R.setRepaymentObligorEndorsementNumber(""); // 상환의무인 배서번호
 * kftEntES1116R.setUnsecuredEndorsementYn(""); // 무담보배서여부
 * kftEntES1116R.setNonEndorsableEndorsementYn(""); // 배서금지배서여부
 * kftEntES1116R.setRepaymentClaimantCorpIndvSort(""); // 상환청구인-법인개인구분
 * kftEntES1116R.setRepaymentClaimantResidentBusinessNumber(""); // 상환청구인-주민사업자번호
 * kftEntES1116R.setRepaymentClaimantCorpName(""); // 상환청구인-법인명
 * kftEntES1116R.setRepaymentClaimantNameRepresentativeName(""); // 상환청구인-성명(대표자명)
 * kftEntES1116R.setRepaymentClaimantAddress(""); // 상환청구인-주소
 * kftEntES1116R.setRepaymentClaimantBankCode(""); // 상환청구인-은행코드
 * kftEntES1116R.setRepaymentClaimantDepositAccountNumber(""); // 상환청구인-입금계좌번호
 * kftEntES1116R.setRepaymentClaimantSplitNumber(""); // 상환청구인분할번호
 * kftEntES1116R.setRepaymentClaimantEndorsementNumber(""); // 상환청구인배서번호
 * kftEntES1116R.setRepaymentClaimAmount(0L); // 상환청구금액
 * kftEntES1116R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1116R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String type; // 구분
	private String repaymentClaimDate; // 상환청구일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String defaultReasonCode; // 부도사유코드
	private String defaultDate; // 부도일자
	private String repaymentObligorCorpIndvSort; // 상환의무인-법인개인구분
	private String repaymentObligorResidentBusinessNumber; // 상환의무인-주민사업자번호
	private String repaymentObligorCorpName; // 상환의무인-법인명
	private String repaymentObligorNameRepresentativeName; // 상환의무인-성명(대표자명)
	private String repaymentObligorAddress; // 상환의무인-주소
	private String repaymentObligorBankCode; // 상환의무인-은행코드
	private String repaymentObligorCurrentCreditAccountNumber; // 상환의무인-당좌(입금)계좌번호
	private String repaymentObligorSplitNumber; // 상환의무인 분할번호
	private String repaymentObligorEndorsementNumber; // 상환의무인 배서번호
	private String unsecuredEndorsementYn; // 무담보배서여부
	private String nonEndorsableEndorsementYn; // 배서금지배서여부
	private String repaymentClaimantCorpIndvSort; // 상환청구인-법인개인구분
	private String repaymentClaimantResidentBusinessNumber; // 상환청구인-주민사업자번호
	private String repaymentClaimantCorpName; // 상환청구인-법인명
	private String repaymentClaimantNameRepresentativeName; // 상환청구인-성명(대표자명)
	private String repaymentClaimantAddress; // 상환청구인-주소
	private String repaymentClaimantBankCode; // 상환청구인-은행코드
	private String repaymentClaimantDepositAccountNumber; // 상환청구인-입금계좌번호
	private String repaymentClaimantSplitNumber; // 상환청구인분할번호
	private String repaymentClaimantEndorsementNumber; // 상환청구인배서번호
	private long repaymentClaimAmount; // 상환청구금액
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String type$; // 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDate$; // 상환청구일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonCode$; // 부도사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 부도일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpIndvSort$; // 상환의무인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorResidentBusinessNumber$; // 상환의무인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpName$; // 상환의무인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorNameRepresentativeName$; // 상환의무인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorAddress$; // 상환의무인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorBankCode$; // 상환의무인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCurrentCreditAccountNumber$; // 상환의무인-당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorSplitNumber$; // 상환의무인 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorEndorsementNumber$; // 상환의무인 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String unsecuredEndorsementYn$; // 무담보배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nonEndorsableEndorsementYn$; // 배서금지배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpIndvSort$; // 상환청구인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantResidentBusinessNumber$; // 상환청구인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpName$; // 상환청구인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantNameRepresentativeName$; // 상환청구인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantAddress$; // 상환청구인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantBankCode$; // 상환청구인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantDepositAccountNumber$; // 상환청구인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantSplitNumber$; // 상환청구인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantEndorsementNumber$; // 상환청구인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimAmount$; // 상환청구금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		type$ = VOUtils.write(out, type, 1); // 구분
		repaymentClaimDate$ = VOUtils.write(out, repaymentClaimDate, 8); // 상환청구일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		defaultReasonCode$ = VOUtils.write(out, defaultReasonCode, 2); // 부도사유코드
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 부도일자
		repaymentObligorCorpIndvSort$ = VOUtils.write(out, repaymentObligorCorpIndvSort, 1); // 상환의무인-법인개인구분
		repaymentObligorResidentBusinessNumber$ = VOUtils.write(out, repaymentObligorResidentBusinessNumber, 13); // 상환의무인-주민사업자번호
		repaymentObligorCorpName$ = VOUtils.write(out, repaymentObligorCorpName, 40, "EUC-KR"); // 상환의무인-법인명
		repaymentObligorNameRepresentativeName$ = VOUtils.write(out, repaymentObligorNameRepresentativeName, 20, "EUC-KR"); // 상환의무인-성명(대표자명)
		repaymentObligorAddress$ = VOUtils.write(out, repaymentObligorAddress, 60, "EUC-KR"); // 상환의무인-주소
		repaymentObligorBankCode$ = VOUtils.write(out, repaymentObligorBankCode, 3); // 상환의무인-은행코드
		repaymentObligorCurrentCreditAccountNumber$ = VOUtils.write(out, repaymentObligorCurrentCreditAccountNumber, 16); // 상환의무인-당좌(입금)계좌번호
		repaymentObligorSplitNumber$ = VOUtils.write(out, repaymentObligorSplitNumber, 2); // 상환의무인 분할번호
		repaymentObligorEndorsementNumber$ = VOUtils.write(out, repaymentObligorEndorsementNumber, 2); // 상환의무인 배서번호
		unsecuredEndorsementYn$ = VOUtils.write(out, unsecuredEndorsementYn, 1); // 무담보배서여부
		nonEndorsableEndorsementYn$ = VOUtils.write(out, nonEndorsableEndorsementYn, 1); // 배서금지배서여부
		repaymentClaimantCorpIndvSort$ = VOUtils.write(out, repaymentClaimantCorpIndvSort, 1); // 상환청구인-법인개인구분
		repaymentClaimantResidentBusinessNumber$ = VOUtils.write(out, repaymentClaimantResidentBusinessNumber, 13); // 상환청구인-주민사업자번호
		repaymentClaimantCorpName$ = VOUtils.write(out, repaymentClaimantCorpName, 40, "EUC-KR"); // 상환청구인-법인명
		repaymentClaimantNameRepresentativeName$ = VOUtils.write(out, repaymentClaimantNameRepresentativeName, 20, "EUC-KR"); // 상환청구인-성명(대표자명)
		repaymentClaimantAddress$ = VOUtils.write(out, repaymentClaimantAddress, 60, "EUC-KR"); // 상환청구인-주소
		repaymentClaimantBankCode$ = VOUtils.write(out, repaymentClaimantBankCode, 3); // 상환청구인-은행코드
		repaymentClaimantDepositAccountNumber$ = VOUtils.write(out, repaymentClaimantDepositAccountNumber, 16); // 상환청구인-입금계좌번호
		repaymentClaimantSplitNumber$ = VOUtils.write(out, repaymentClaimantSplitNumber, 2); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber$ = VOUtils.write(out, repaymentClaimantEndorsementNumber, 2); // 상환청구인배서번호
		repaymentClaimAmount$ = VOUtils.write(out, repaymentClaimAmount, 15); // 상환청구금액
		filler2$ = VOUtils.write(out, filler2, 12); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		type = VOUtils.toString(type$ = VOUtils.read(in, 1)); // 구분
		repaymentClaimDate = VOUtils.toString(repaymentClaimDate$ = VOUtils.read(in, 8)); // 상환청구일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		defaultReasonCode = VOUtils.toString(defaultReasonCode$ = VOUtils.read(in, 2)); // 부도사유코드
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 부도일자
		repaymentObligorCorpIndvSort = VOUtils.toString(repaymentObligorCorpIndvSort$ = VOUtils.read(in, 1)); // 상환의무인-법인개인구분
		repaymentObligorResidentBusinessNumber = VOUtils.toString(repaymentObligorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환의무인-주민사업자번호
		repaymentObligorCorpName = VOUtils.toString(repaymentObligorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환의무인-법인명
		repaymentObligorNameRepresentativeName = VOUtils.toString(repaymentObligorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환의무인-성명(대표자명)
		repaymentObligorAddress = VOUtils.toString(repaymentObligorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환의무인-주소
		repaymentObligorBankCode = VOUtils.toString(repaymentObligorBankCode$ = VOUtils.read(in, 3)); // 상환의무인-은행코드
		repaymentObligorCurrentCreditAccountNumber = VOUtils.toString(repaymentObligorCurrentCreditAccountNumber$ = VOUtils.read(in, 16)); // 상환의무인-당좌(입금)계좌번호
		repaymentObligorSplitNumber = VOUtils.toString(repaymentObligorSplitNumber$ = VOUtils.read(in, 2)); // 상환의무인 분할번호
		repaymentObligorEndorsementNumber = VOUtils.toString(repaymentObligorEndorsementNumber$ = VOUtils.read(in, 2)); // 상환의무인 배서번호
		unsecuredEndorsementYn = VOUtils.toString(unsecuredEndorsementYn$ = VOUtils.read(in, 1)); // 무담보배서여부
		nonEndorsableEndorsementYn = VOUtils.toString(nonEndorsableEndorsementYn$ = VOUtils.read(in, 1)); // 배서금지배서여부
		repaymentClaimantCorpIndvSort = VOUtils.toString(repaymentClaimantCorpIndvSort$ = VOUtils.read(in, 1)); // 상환청구인-법인개인구분
		repaymentClaimantResidentBusinessNumber = VOUtils.toString(repaymentClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환청구인-주민사업자번호
		repaymentClaimantCorpName = VOUtils.toString(repaymentClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환청구인-법인명
		repaymentClaimantNameRepresentativeName = VOUtils.toString(repaymentClaimantNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환청구인-성명(대표자명)
		repaymentClaimantAddress = VOUtils.toString(repaymentClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환청구인-주소
		repaymentClaimantBankCode = VOUtils.toString(repaymentClaimantBankCode$ = VOUtils.read(in, 3)); // 상환청구인-은행코드
		repaymentClaimantDepositAccountNumber = VOUtils.toString(repaymentClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환청구인-입금계좌번호
		repaymentClaimantSplitNumber = VOUtils.toString(repaymentClaimantSplitNumber$ = VOUtils.read(in, 2)); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber = VOUtils.toString(repaymentClaimantEndorsementNumber$ = VOUtils.read(in, 2)); // 상환청구인배서번호
		repaymentClaimAmount = VOUtils.toLong(repaymentClaimAmount$ = VOUtils.read(in, 15)); // 상환청구금액
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 12)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", type=").append(type).append(System.lineSeparator()); // 구분
		sb.append(", repaymentClaimDate=").append(repaymentClaimDate).append(System.lineSeparator()); // 상환청구일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", defaultReasonCode=").append(defaultReasonCode).append(System.lineSeparator()); // 부도사유코드
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 부도일자
		sb.append(", repaymentObligorCorpIndvSort=").append(repaymentObligorCorpIndvSort).append(System.lineSeparator()); // 상환의무인-법인개인구분
		sb.append(", repaymentObligorResidentBusinessNumber=").append(repaymentObligorResidentBusinessNumber).append(System.lineSeparator()); // 상환의무인-주민사업자번호
		sb.append(", repaymentObligorCorpName=").append(repaymentObligorCorpName).append(System.lineSeparator()); // 상환의무인-법인명
		sb.append(", repaymentObligorNameRepresentativeName=").append(repaymentObligorNameRepresentativeName).append(System.lineSeparator()); // 상환의무인-성명(대표자명)
		sb.append(", repaymentObligorAddress=").append(repaymentObligorAddress).append(System.lineSeparator()); // 상환의무인-주소
		sb.append(", repaymentObligorBankCode=").append(repaymentObligorBankCode).append(System.lineSeparator()); // 상환의무인-은행코드
		sb.append(", repaymentObligorCurrentCreditAccountNumber=").append(repaymentObligorCurrentCreditAccountNumber).append(System.lineSeparator()); // 상환의무인-당좌(입금)계좌번호
		sb.append(", repaymentObligorSplitNumber=").append(repaymentObligorSplitNumber).append(System.lineSeparator()); // 상환의무인 분할번호
		sb.append(", repaymentObligorEndorsementNumber=").append(repaymentObligorEndorsementNumber).append(System.lineSeparator()); // 상환의무인 배서번호
		sb.append(", unsecuredEndorsementYn=").append(unsecuredEndorsementYn).append(System.lineSeparator()); // 무담보배서여부
		sb.append(", nonEndorsableEndorsementYn=").append(nonEndorsableEndorsementYn).append(System.lineSeparator()); // 배서금지배서여부
		sb.append(", repaymentClaimantCorpIndvSort=").append(repaymentClaimantCorpIndvSort).append(System.lineSeparator()); // 상환청구인-법인개인구분
		sb.append(", repaymentClaimantResidentBusinessNumber=").append(repaymentClaimantResidentBusinessNumber).append(System.lineSeparator()); // 상환청구인-주민사업자번호
		sb.append(", repaymentClaimantCorpName=").append(repaymentClaimantCorpName).append(System.lineSeparator()); // 상환청구인-법인명
		sb.append(", repaymentClaimantNameRepresentativeName=").append(repaymentClaimantNameRepresentativeName).append(System.lineSeparator()); // 상환청구인-성명(대표자명)
		sb.append(", repaymentClaimantAddress=").append(repaymentClaimantAddress).append(System.lineSeparator()); // 상환청구인-주소
		sb.append(", repaymentClaimantBankCode=").append(repaymentClaimantBankCode).append(System.lineSeparator()); // 상환청구인-은행코드
		sb.append(", repaymentClaimantDepositAccountNumber=").append(repaymentClaimantDepositAccountNumber).append(System.lineSeparator()); // 상환청구인-입금계좌번호
		sb.append(", repaymentClaimantSplitNumber=").append(repaymentClaimantSplitNumber).append(System.lineSeparator()); // 상환청구인분할번호
		sb.append(", repaymentClaimantEndorsementNumber=").append(repaymentClaimantEndorsementNumber).append(System.lineSeparator()); // 상환청구인배서번호
		sb.append(", repaymentClaimAmount=").append(repaymentClaimAmount).append(System.lineSeparator()); // 상환청구금액
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "type", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "defaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentObligorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentObligorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentObligorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentObligorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentObligorCurrentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentObligorSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentObligorEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "unsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "nonEndorsableEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentClaimantNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimantEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "12", "defltVal", "")
		);
	}

}
