package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 타행이체_거액이체
 * <pre>{@code
 * msgType 메시지구분 
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 
 * messageCode 거래구분코드 
 * responseCode 응답코드 
 * requestBank 요청은행 
 * beneficiaryBankCode 수취은행 
 * transactionDate 전송일자 
 * transactionIdNumber 거래고유번호 
 * beneficiaryAccountNumber 수취계좌번호 
 * beneficiaryAmount 수취금액 
 * beneficiaryName 수취인명 
 * senderName 송신자명 
 * multipleNumber multiple number 
 * mediaType 매체구분 
 * fundType 자금성격 
 * requestorInformation 의뢰인정보 
 * withdrawalAccountNumber 출금계좌번호 
 * channelType 채널구분 
 * holidayTransactionDate 휴일거래일자 
 * responseCodeBOK 응답코드(한국은행) 
 * responseCodeOpenBank 응답코드(개설은행) 
 * fillerOrRealRemitterName filler(당발시), Real Remitter Name(타발) 
 * detailInformation Detail Information (적요) 
 * filler filler 
 * 
 * LvbHof0210450000 lvbHof0210450000 = new LvbHof0210450000(); // 타행이체_거액이체
 * lvbHof0210450000.setMsgType("KCGLVB"); // 메시지구분
 * lvbHof0210450000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * lvbHof0210450000.setMsgNo("00000000"); // 메시지번호(Key)
 * lvbHof0210450000.setMessageType("0210"); // 전문종별코드
 * lvbHof0210450000.setMessageCode("450000"); // 거래구분코드
 * lvbHof0210450000.setResponseCode("000"); // 응답코드
 * lvbHof0210450000.setRequestBank("000"); // 요청은행
 * lvbHof0210450000.setBeneficiaryBankCode("000"); // 수취은행
 * lvbHof0210450000.setTransactionDate(LocalDate.now()); // 전송일자
 * lvbHof0210450000.setTransactionIdNumber(""); // 거래고유번호
 * lvbHof0210450000.setBeneficiaryAccountNumber(""); // 수취계좌번호
 * lvbHof0210450000.setBeneficiaryAmount(0L); // 수취금액
 * lvbHof0210450000.setBeneficiaryName(""); // 수취인명
 * lvbHof0210450000.setSenderName(""); // 송신자명
 * lvbHof0210450000.setMultipleNumber("000"); // multiple number
 * lvbHof0210450000.setMediaType("01"); // 매체구분
 * lvbHof0210450000.setFundType("00"); // 자금성격
 * lvbHof0210450000.setRequestorInformation(""); // 의뢰인정보
 * lvbHof0210450000.setWithdrawalAccountNumber(""); // 출금계좌번호
 * lvbHof0210450000.setChannelType("00"); // 채널구분
 * lvbHof0210450000.setHolidayTransactionDate(""); // 휴일거래일자
 * lvbHof0210450000.setResponseCodeBOK(""); // 응답코드(한국은행)
 * lvbHof0210450000.setResponseCodeOpenBank(""); // 응답코드(개설은행)
 * lvbHof0210450000.setFillerOrRealRemitterName(""); // filler(당발시), Real Remitter Name(타발)
 * lvbHof0210450000.setDetailInformation(""); // Detail Information (적요)
 * lvbHof0210450000.setFiller(""); // filler
 * }</pre>
 */
@Data
public class LvbHof0210450000 implements LvbHofComHdr, Vo {

	private String msgType = "KCGLVB"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0210"; // 전문종별코드
	private String messageCode = "450000"; // 거래구분코드
	private String responseCode = "000"; // 응답코드
	private String requestBank = "000"; // 요청은행
	private String beneficiaryBankCode = "000"; // 수취은행
	private LocalDate transactionDate; // 전송일자
	private String transactionIdNumber; // 거래고유번호
	private String beneficiaryAccountNumber; // 수취계좌번호
	private long beneficiaryAmount; // 수취금액
	private String beneficiaryName; // 수취인명
	private String senderName; // 송신자명
	private String multipleNumber = "000"; // multiple number
	private String mediaType = "01"; // 매체구분
	private String fundType = "00"; // 자금성격
	private String requestorInformation; // 의뢰인정보
	private String withdrawalAccountNumber; // 출금계좌번호
	private String channelType = "00"; // 채널구분
	private String holidayTransactionDate; // 휴일거래일자
	private String responseCodeBOK; // 응답코드(한국은행)
	private String responseCodeOpenBank; // 응답코드(개설은행)
	private String fillerOrRealRemitterName; // filler(당발시), Real Remitter Name(타발)
	private String detailInformation; // Detail Information (적요)
	private String filler; // filler
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBank$; // 요청은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 수취은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionDate$; // 전송일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAmount$; // 수취금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String senderName$; // 송신자명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String multipleNumber$; // multiple number
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mediaType$; // 매체구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금성격
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestorInformation$; // 의뢰인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String channelType$; // 채널구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String holidayTransactionDate$; // 휴일거래일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCodeBOK$; // 응답코드(한국은행)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCodeOpenBank$; // 응답코드(개설은행)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fillerOrRealRemitterName$; // filler(당발시), Real Remitter Name(타발)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String detailInformation$; // Detail Information (적요)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // filler

	@Override
	public int validate() {
		if (VOUtils.isWhitespace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isWhitespace(systemSendReceiveTime$)) { // 시스템송수신시간
			return 1;
		}
		if (VOUtils.isWhitespace(msgNo$)) { // 메시지번호(Key)
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(responseCode$)) { // 응답코드
			return 5;
		}
		if (VOUtils.isNotNumeric(requestBank$)) { // 요청은행
			return 6;
		}
		if (VOUtils.isNotNumeric(beneficiaryBankCode$)) { // 수취은행
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryAccountNumber$)) { // 수취계좌번호
			return 10;
		}
		if (VOUtils.isNotNumeric(beneficiaryAmount$)) { // 수취금액
			return 11;
		}
		if (VOUtils.isWhitespace(multipleNumber$)) { // multiple number
			return 14;
		}
		if (VOUtils.isNotNumeric(mediaType$)) { // 매체구분
			return 15;
		}
		if (VOUtils.isNotNumeric(fundType$)) { // 자금성격
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(requestorInformation$)) { // 의뢰인정보
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(withdrawalAccountNumber$)) { // 출금계좌번호
			return 18;
		}
		if (VOUtils.isNotNumeric(channelType$)) { // 채널구분
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCodeBOK$)) { // 응답코드(한국은행)
			return 21;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCodeOpenBank$)) { // 응답코드(개설은행)
			return 22;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBank$ = VOUtils.write(out, requestBank, 3); // 요청은행
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 수취은행
		transactionDate$ = VOUtils.write(out, transactionDate, 8, "yyyyMMdd"); // 전송일자
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취계좌번호
		beneficiaryAmount$ = VOUtils.write(out, beneficiaryAmount, 14); // 수취금액
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인명
		senderName$ = VOUtils.write(out, senderName, 20, "EUC-KR"); // 송신자명
		multipleNumber$ = VOUtils.write(out, multipleNumber, 3); // multiple number
		mediaType$ = VOUtils.write(out, mediaType, 2); // 매체구분
		fundType$ = VOUtils.write(out, fundType, 2); // 자금성격
		requestorInformation$ = VOUtils.write(out, requestorInformation, 32); // 의뢰인정보
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		channelType$ = VOUtils.write(out, channelType, 2); // 채널구분
		holidayTransactionDate$ = VOUtils.write(out, holidayTransactionDate, 8); // 휴일거래일자
		responseCodeBOK$ = VOUtils.write(out, responseCodeBOK, 4); // 응답코드(한국은행)
		responseCodeOpenBank$ = VOUtils.write(out, responseCodeOpenBank, 3); // 응답코드(개설은행)
		fillerOrRealRemitterName$ = VOUtils.write(out, fillerOrRealRemitterName, 20, "EUC-KR"); // filler(당발시), Real Remitter Name(타발)
		detailInformation$ = VOUtils.write(out, detailInformation, 32); // Detail Information (적요)
		filler$ = VOUtils.write(out, filler, 30); // filler
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBank = VOUtils.toString(requestBank$ = VOUtils.read(in, 3)); // 요청은행
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 수취은행
		transactionDate = VOUtils.toLocalDate(transactionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전송일자
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취계좌번호
		beneficiaryAmount = VOUtils.toLong(beneficiaryAmount$ = VOUtils.read(in, 14)); // 수취금액
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인명
		senderName = VOUtils.toString(senderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송신자명
		multipleNumber = VOUtils.toString(multipleNumber$ = VOUtils.read(in, 3)); // multiple number
		mediaType = VOUtils.toString(mediaType$ = VOUtils.read(in, 2)); // 매체구분
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금성격
		requestorInformation = VOUtils.toString(requestorInformation$ = VOUtils.read(in, 32)); // 의뢰인정보
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		channelType = VOUtils.toString(channelType$ = VOUtils.read(in, 2)); // 채널구분
		holidayTransactionDate = VOUtils.toString(holidayTransactionDate$ = VOUtils.read(in, 8)); // 휴일거래일자
		responseCodeBOK = VOUtils.toString(responseCodeBOK$ = VOUtils.read(in, 4)); // 응답코드(한국은행)
		responseCodeOpenBank = VOUtils.toString(responseCodeOpenBank$ = VOUtils.read(in, 3)); // 응답코드(개설은행)
		fillerOrRealRemitterName = VOUtils.toString(fillerOrRealRemitterName$ = VOUtils.read(in, 20, "EUC-KR")); // filler(당발시), Real Remitter Name(타발)
		detailInformation = VOUtils.toString(detailInformation$ = VOUtils.read(in, 32)); // Detail Information (적요)
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 30)); // filler
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBank=").append(requestBank).append(System.lineSeparator()); // 요청은행
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 수취은행
		sb.append(", transactionDate=").append(transactionDate).append(System.lineSeparator()); // 전송일자
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취계좌번호
		sb.append(", beneficiaryAmount=").append(beneficiaryAmount).append(System.lineSeparator()); // 수취금액
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인명
		sb.append(", senderName=").append(senderName).append(System.lineSeparator()); // 송신자명
		sb.append(", multipleNumber=").append(multipleNumber).append(System.lineSeparator()); // multiple number
		sb.append(", mediaType=").append(mediaType).append(System.lineSeparator()); // 매체구분
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금성격
		sb.append(", requestorInformation=").append(requestorInformation).append(System.lineSeparator()); // 의뢰인정보
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", channelType=").append(channelType).append(System.lineSeparator()); // 채널구분
		sb.append(", holidayTransactionDate=").append(holidayTransactionDate).append(System.lineSeparator()); // 휴일거래일자
		sb.append(", responseCodeBOK=").append(responseCodeBOK).append(System.lineSeparator()); // 응답코드(한국은행)
		sb.append(", responseCodeOpenBank=").append(responseCodeOpenBank).append(System.lineSeparator()); // 응답코드(개설은행)
		sb.append(", fillerOrRealRemitterName=").append(fillerOrRealRemitterName).append(System.lineSeparator()); // filler(당발시), Real Remitter Name(타발)
		sb.append(", detailInformation=").append(detailInformation).append(System.lineSeparator()); // Detail Information (적요)
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // filler
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "KCGLVB"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "450000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBank", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "transactionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneficiaryAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "senderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "multipleNumber", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "mediaType", "fldLen", "2", "defltVal", "01"),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "requestorInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "channelType", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "holidayTransactionDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "responseCodeBOK", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "responseCodeOpenBank", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "fillerOrRealRemitterName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "detailInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "30", "defltVal", "")
		);
	}

}
