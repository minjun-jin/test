package com.jpmc.kcg.com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.jpmc.kcg.com.dto.ComDateM;

@Mapper
public interface ComDateMDao {
	
	/**
	 * get count of biz day
	 * @param strtDt
	 * @param endDt
	 * @return
	 */
	int selectBizDtCount(@Param("strtDt") String strtDt, @Param("endDt") String endDt);

    /**
     * Previous biz Day Search
     * @param baseDt (기준일자)
     * @param days (일수)
     * @return YYYYMMDD (이전 영업일)
     */
    String selectPreviousBizDt(@Param("baseDt") String baseDt, @Param("days") int days);

    /**
     * Next biz Day Search
     * @param baseDt (기준일자)
     * @param days (일수)
     * @return YYYYMMDD (다음 영업일)
     */
    String selectNextBizDt(@Param("baseDt") String baseDt, @Param("days") int days);
    

	/**
	 * get count of biz day for CMS
	 * @param strtDt
	 * @param endDt
	 * @return
	 */
	int selectWorkingDtCount(@Param("strtDt") String strtDt, @Param("endDt") String endDt);
   

    /**
     * Previous biz Day Search for CMS
     * @param baseDt (기준일자)
     * @param days (일수)
     * @return YYYYMMDD (이전 영업일)
     */
    String selectPreviousWorkingDt(@Param("baseDt") String baseDt, @Param("days") int days);

    /**
     * Next biz Day Search for CMS
     * @param baseDt (기준일자)
     * @param days (일수)
     * @return YYYYMMDD (다음 영업일)
     */
    String selectNextWorkingDt(@Param("baseDt") String baseDt, @Param("days") int days);

    /**
     * Date Master Search
     * @return List<ComDateM>
     */
    List<ComDateM> selectListComDateM(ComDateM in);

    /**
     * Maker Date Master Search
     * @param isMaker (Maker 권한 여부)
     * @return List<ComDateM>
     */
    List<ComDateM> selectMakerComDateMList(@Param("param") ComDateM in, @Param("isMaker") boolean isMaker);

    /**
     * Date Master Search
     * @return ComDateM
     */
    ComDateM selectComDateM(ComDateM in);

    /**
     * Insert Date Master
     *
     * @return int
     */
    int insertComDateM(ComDateM in);

    /**
     * Update Date Master
     *
     * @param ComDateM
     * @return int
     */
    int updateComDateM(ComDateM in);

    /**
     * Delete Date Master
     *
     * @return int
     */
    int deleteComDateM(ComDateM in);

    /**
     * Date Monthly List Search
     * @return List<ComDateM>
     */
    List<ComDateM> selectDateByMonth(@Param("strtDt") String strtDt, @Param("endDt") String endDt);
}
