package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자금화연장처리-제시기관별
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 
 * messageSendTime 전문전송시간 
 * participantInstitutionCode 참가기관코드 
 * extensionExchangeOfficesCount 연장교환소총갯수 
 * extensionContentArray 연장내역Array 
 * extensionContentArray.bnkCd 은행코드 
 * extensionContentArray.extTm 연장시각 
 * reservedInformationField11 예비정보FIELD 
 * 
 * KftIft0810904 kftIft0810904 = new KftIft0810904(); // 자금화연장처리-제시기관별
 * kftIft0810904.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftIft0810904.setSystemId("03"); // 시스템-ID
 * kftIft0810904.setInstitutionCode("057"); // 기관코드
 * kftIft0810904.setMessageType("0810"); // 전문종별구분코드
 * kftIft0810904.setMessageCode("904"); // 업무구분코드
 * kftIft0810904.setSendReceiveFlag("4"); // 송수신FLAG
 * kftIft0810904.setResponseCode(""); // 응답코드
 * kftIft0810904.setMessageSendTime(LocalDateTime.now()); // 전문전송시간
 * kftIft0810904.setParticipantInstitutionCode("000"); // 참가기관코드
 * kftIft0810904.setExtensionExchangeOfficesCount(0); // 연장교환소총갯수
 * KftIft0810904.ExtensionContent extensionContent = new KftIft0810904.ExtensionContent(); // 연장내역Array
 * extensionContent.setBnkCd("000"); // 은행코드
 * extensionContent.setExtTm("0000"); // 연장시각
 * kftIft0810904.getExtensionContentArray().add(extensionContent); // 연장내역Array
 * kftIft0810904.setReservedInformationField11(""); // 예비정보FIELD
 * }</pre>
 */
@Data
public class KftIft0810904 implements KftIftMngHdr, Vo {

	/**
	 * 연장내역Array
	 * <pre>{@code
	 * bnkCd 은행코드 
	 * extTm 연장시각 
	 * 
	 * KftIft0810904.ExtensionContent extensionContent = new KftIft0810904.ExtensionContent(); // 연장내역Array
	 * extensionContent.setBnkCd("000"); // 은행코드
	 * extensionContent.setExtTm("0000"); // 연장시각
	 * }</pre>
	 */
	@Data
	public static class ExtensionContent implements Vo {

		private String bnkCd = "000"; // 은행코드
		private String extTm = "0000"; // 연장시각
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String bnkCd$; // 은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String extTm$; // 연장시각

		@Override
		public void write(OutputStream out) throws IOException {
			bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
			extTm$ = VOUtils.write(out, extTm, 4); // 연장시각
		}

		@Override
		public void read(InputStream in) throws IOException {
			bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
			extTm = VOUtils.toString(extTm$ = VOUtils.read(in, 4)); // 연장시각
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
			sb.append(", extTm=").append(extTm).append(System.lineSeparator()); // 연장시각
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0810"; // 전문종별구분코드
	private String messageCode = "904"; // 업무구분코드
	private String sendReceiveFlag = "4"; // 송수신FLAG
	private String responseCode; // 응답코드
	private LocalDateTime messageSendTime; // 전문전송시간
	private String participantInstitutionCode = "000"; // 참가기관코드
	private int extensionExchangeOfficesCount; // 연장교환소총갯수
	private List<KftIft0810904.ExtensionContent> extensionContentArray = new ArrayList<>(); // 연장내역Array
	private String reservedInformationField11; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String participantInstitutionCode$; // 참가기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String extensionExchangeOfficesCount$; // 연장교환소총갯수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 업무구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageSendTime$ = VOUtils.write(out, messageSendTime, 12, "yyMMddHHmmss"); // 전문전송시간
		participantInstitutionCode$ = VOUtils.write(out, participantInstitutionCode, 3); // 참가기관코드
		extensionExchangeOfficesCount$ = VOUtils.write(out, extensionExchangeOfficesCount, 3); // 연장교환소총갯수
		VOUtils.write(out, extensionContentArray, 30, KftIft0810904.ExtensionContent::new); // 연장내역Array
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 12); // 예비정보FIELD
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 전문전송시간
		participantInstitutionCode = VOUtils.toString(participantInstitutionCode$ = VOUtils.read(in, 3)); // 참가기관코드
		extensionExchangeOfficesCount = VOUtils.toInt(extensionExchangeOfficesCount$ = VOUtils.read(in, 3)); // 연장교환소총갯수
		extensionContentArray = VOUtils.toVoList(in, 30, KftIft0810904.ExtensionContent.class); // 연장내역Array
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 12)); // 예비정보FIELD
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", participantInstitutionCode=").append(participantInstitutionCode).append(System.lineSeparator()); // 참가기관코드
		sb.append(", extensionExchangeOfficesCount=").append(extensionExchangeOfficesCount).append(System.lineSeparator()); // 연장교환소총갯수
		sb.append(", extensionContentArray=").append(extensionContentArray).append(System.lineSeparator()); // 연장내역Array
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0810"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "904"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "4"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "participantInstitutionCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "extensionExchangeOfficesCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "extensionContentArray", "fldLen", "30", "defltVal", "000000000000000000000000000000"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "extTm", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "reservedInformationField11", "fldLen", "12", "defltVal", "")
		);
	}

}
