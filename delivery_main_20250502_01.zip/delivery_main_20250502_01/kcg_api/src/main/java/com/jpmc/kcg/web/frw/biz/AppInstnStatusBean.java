package com.jpmc.kcg.web.frw.biz;

import java.time.Clock;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jpmc.kcg.web.frw.dto.FrwInstnM;
import com.jpmc.kcg.web.frw.dto.HealthComposite;
import com.jpmc.kcg.web.frw.dto.HealthInstnStatus;
import com.jpmc.kcg.web.frw.enums.ActvStatus;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class AppInstnStatusBean {
	private final Pattern  methodPattern = Pattern.compile(".*\\.([\\w]+)$"); 
	
	@Autowired
	private RestTemplate restTemplate;

	@Async
	public CompletableFuture<HealthComposite>  requestHealth(FrwInstnM frwInstnM)  {
		String health = null;
		StringBuilder builder = new StringBuilder();
        builder.append("http://");
        builder.append(frwInstnM.getHlthChcIp());
        builder.append(":");
        builder.append(frwInstnM.getHlthChcPort());
        builder.append("/actuator/health");

        String url = builder.toString();
        log.trace("URL: {}", url);

	    try {
	    	health = restTemplate.getForObject(url, String.class);
//	        health = response.getBody();
	    } catch (HttpServerErrorException | HttpClientErrorException e) {
	        // 오동작하는 서비스가 있어서 Actuator 에서 오류응답이 발생한 경우에도 body 가 있다면 정보는 넣어주기
	    	health = e.getResponseBodyAs(String.class);	
	        log.error("HttpServerErrorException occurred: ", e);
	    } catch (Exception e) {
	        // 서비스가 완전히 다운되서 리소스가 없더라도 상태 표시를 위해 정보 넣기
	    	health = "{}";
	        log.error("An error occurred: ", e);
	    }
	    HealthComposite healthComposite = new HealthComposite();
	    
	    HealthInstnStatus instnStatus = new HealthInstnStatus();
        instnStatus.setInstnId(frwInstnM.getInstnId());
        instnStatus.setIp(frwInstnM.getHlthChcIp()); // Assuming FrwInstnM has a getIp() method
        instnStatus.setPort(frwInstnM.getHlthChcPort()); // Assuming FrwInstnM has a getPort() method
        instnStatus.setDbCon(0);
        instnStatus.setMaxDbCon(0);
        instnStatus.setStatus(ActvStatus.DOWN);
        
        healthComposite.setHealthInstnStatus(instnStatus);
        
        List<Map<String, String>> scheduleTasksList = new ArrayList<>();
    	healthComposite.setHealthScheduledStatus(scheduleTasksList);
        
        ObjectMapper mapper = new ObjectMapper();
        try {
        	
			JsonNode rootNode = mapper.readTree(health);

        	if (null != rootNode.get("components") && null != rootNode.get("components").get("db")) {
	        	JsonNode component = rootNode.get("components").get("db");
	            instnStatus.setDbCon((Integer) component.get("details").get("activeConnections").asInt());
	            instnStatus.setMaxDbCon((Integer) component.get("details").get("maximumPoolSize").asInt());
	            instnStatus.setStatus("UP".equals(component.get("status").asText()) ? ActvStatus.ACTIVE : ActvStatus.INACTIVE);
        	}  	
        	
        	
        	if (null != rootNode.get("components") && null != rootNode.get("components").get("scheduling")) {
	        	JsonNode component = rootNode.get("components").get("scheduling").get("details").get("scheduledTasks");
	            
	            addScheduledTasks(frwInstnM, scheduleTasksList, component.get("cron"));
	            addScheduledTasks(frwInstnM, scheduleTasksList, component.get("fixedDelay"));
	            addScheduledTasks(frwInstnM, scheduleTasksList, component.get("fixedRate"));
	            addScheduledTasks(frwInstnM, scheduleTasksList, component.get("custom"));
        	} else {
        		// 서비스가 완전히 다운되서 리소스가 없더라도 상태 표시를 위해 정보 넣기
    	    	scheduleTasksList.add(getDefaultScheduleTaskStatus(frwInstnM));
        	}
		} catch (Exception e) {
			log.warn("An error occurred during processing, but skip.", e);
			// 서비스가 완전히 다운되서 리소스가 없더라도 상태 표시를 위해 정보 넣기
	    	scheduleTasksList.add(getDefaultScheduleTaskStatus(frwInstnM));
		}

	    return CompletableFuture.completedFuture(healthComposite);
	}
	
	
	private void addScheduledTasks(FrwInstnM frwInstnM, List<Map<String, String>> instnStatusList, JsonNode list) {
    	list.forEach(item -> {
   			log.trace("ScheduledTaskDescriptor {}",item);
	    	Map<String, String> data = new Hashtable<String, String>();
	    	data.put("instnId", frwInstnM.getInstnId());
	    	data.put("scheduled", getMethodOnly(item.get("runnable").get("target").asText()));
	    	if (null != item.get("lastExecution")) {
		    	data.put("status", item.get("lastExecution").get("status").asText());
		    	data.put("lastExecTime", Instant.parse(item.get("lastExecution").get("time").asText()).atZone(Clock.systemDefaultZone().getZone()).toString().substring(11,19));
		    	
	    	} else {
	    		data.put("status", ActvStatus.INACTIVE.name());
	    	}
	    	if (null != item.get("nextExecution")) {
	    		data.put("nextExecTime", Instant.parse(item.get("nextExecution").get("time").asText()).atZone(Clock.systemDefaultZone().getZone()).toString().substring(11,19));
	    	}
	    	instnStatusList.add(data);
    	});
    }
    
	
	private Map<String, String> getDefaultScheduleTaskStatus(FrwInstnM frwInstnM) {
		Map<String, String> data = new Hashtable<String, String>();
    	data.put("instnId", frwInstnM.getInstnId());
    	data.put("scheduled", "Unknown");
    	data.put("status", ActvStatus.INACTIVE.name());
    	data.put("lastExecTime", "");
    	data.put("nextExecTime", "");
    	return data;
	}
	

    private String getMethodOnly(String str) {
    	String result =  str;
		Matcher matcher = methodPattern.matcher(str);
		if (matcher.matches() && 1 == matcher.groupCount()) {
			result = matcher.group(1);
		}
		return result;
    }
}
