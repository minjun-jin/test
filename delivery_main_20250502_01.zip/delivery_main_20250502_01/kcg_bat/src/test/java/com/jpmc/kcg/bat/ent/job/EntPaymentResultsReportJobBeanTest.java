package com.jpmc.kcg.bat.ent.job;

import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.bat.BatJobTestSupporter;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.bat.ent.dao.BatEntSndRcvFileLDao;
import com.jpmc.kcg.ent.biz.EntCom;
import com.jpmc.kcg.ent.biz.vo.KftEntES1105R;
import com.jpmc.kcg.ent.dto.EntSndRcvFileL;
import com.jpmc.kcg.frw.VOUtils;

@ExtendWith(MockitoExtension.class)
class EntPaymentResultsReportJobBeanTest extends BatJobTestSupporter {
    
    @Mock
    private BatEntSndRcvFileLDao batEntSndRcvFileLDao;
    @Mock
    private EntCom entCom;
    @Mock
    private CmsCom cmsCom;
    @InjectMocks
    private EntPaymentResultsReportJobBean entPaymentResultsReportJobBean;
    
    private MockedStatic<VOUtils> voUtilsMockedStatic;

    @BeforeEach
    public void setUp() {
        voUtilsMockedStatic = mockStatic(VOUtils.class);
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("TRACT_DT", "20250326");
        setParamMap(param);
        setOrdDt("20250326");
    }
    
    @AfterEach
    void tearDown() {
        if (voUtilsMockedStatic != null) {
            voUtilsMockedStatic.close();
        }
    }

    @Test
    void testExecuteInternal() {

        EntSndRcvFileL file = new EntSndRcvFileL();
        file.setTrDt("20250326");
        file.setFileNm("ES1105");
        file.setDataTp("22");
        file.setTlgCtt("654122240000000000000000000000");

        KftEntES1105R mockedVo = new KftEntES1105R();
        mockedVo.setEnoteNumber("5004");
        mockedVo.setNotificationTarget("N");
        mockedVo.setBeneficiarySplitEnoteAmount(1000000);

        when(batEntSndRcvFileLDao.selectEntFileList("20250326", "ES1105", "22")).thenReturn(List.of(file));
        
        voUtilsMockedStatic
            .when(() -> VOUtils.toVo(anyString(), eq(KftEntES1105R.class)))
            .thenReturn(mockedVo);
        
        execute(entPaymentResultsReportJobBean);
        
        verify(entCom, times(1)).updateEnoteSettleManagementM(eq("5004"), any());
    }
    
        @Test
    void testExecuteInternal_noList() {
        KftEntES1105R mockedVo = new KftEntES1105R();
        mockedVo.setEnoteNumber("5004");
        mockedVo.setNotificationTarget("N");
        mockedVo.setBeneficiarySplitEnoteAmount(1000000);

        when(batEntSndRcvFileLDao.selectEntFileList("20250326", "ES1105", "22")).thenReturn(null);
        
        execute(entPaymentResultsReportJobBean);
        
        verify(entCom, never()).updateEnoteSettleManagementM(eq("5004"), eq("N"), any());
    }

}