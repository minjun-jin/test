package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90RD kftCmsEB90RD  = new KftCmsEB90RD(); // 이용기관정보통지
 * kftCmsEB90RD.setRecordType(""); // Record 구분
 * kftCmsEB90RD.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB90RD.setDataRecordType(""); // Data Record 구분코드
 * kftCmsEB90RD.setInstitutionCode(""); // 기관코드
 * kftCmsEB90RD.setChangeSeqBitMap(""); // 변경항번BitMap
 * kftCmsEB90RD.setPayerNumberSystemDesc1(""); // 납부자번호 체계 설명 1
 * kftCmsEB90RD.setPayerNumberSystemDesc2(""); // 납부자번호 체계 설명 2
 * kftCmsEB90RD.setPayerNumberSystemDesc3(""); // 납부자번호 체계 설명 3
 * kftCmsEB90RD.setFiller5(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90RD implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String dataRecordType; // Data Record 구분코드
	private String institutionCode; // 기관코드
	private String changeSeqBitMap; // 변경항번BitMap
	private String payerNumberSystemDesc1; // 납부자번호 체계 설명 1
	private String payerNumberSystemDesc2; // 납부자번호 체계 설명 2
	private String payerNumberSystemDesc3; // 납부자번호 체계 설명 3
	private String filler5; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataRecordType$; // Data Record 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeSeqBitMap$; // 변경항번BitMap
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystemDesc1$; // 납부자번호 체계 설명 1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystemDesc2$; // 납부자번호 체계 설명 2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystemDesc3$; // 납부자번호 체계 설명 3
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler5$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		dataRecordType$ = VOUtils.write(out, dataRecordType, 1); // Data Record 구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		changeSeqBitMap$ = VOUtils.write(out, changeSeqBitMap, 15); // 변경항번BitMap
		payerNumberSystemDesc1$ = VOUtils.write(out, payerNumberSystemDesc1, 70, "EUC-KR"); // 납부자번호 체계 설명 1
		payerNumberSystemDesc2$ = VOUtils.write(out, payerNumberSystemDesc2, 70, "EUC-KR"); // 납부자번호 체계 설명 2
		payerNumberSystemDesc3$ = VOUtils.write(out, payerNumberSystemDesc3, 70, "EUC-KR"); // 납부자번호 체계 설명 3
		filler5$ = VOUtils.write(out, filler5, 5); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		dataRecordType = VOUtils.toString(dataRecordType$ = VOUtils.read(in, 1)); // Data Record 구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		changeSeqBitMap = VOUtils.toString(changeSeqBitMap$ = VOUtils.read(in, 15)); // 변경항번BitMap
		payerNumberSystemDesc1 = VOUtils.toString(payerNumberSystemDesc1$ = VOUtils.read(in, 70, "EUC-KR")); // 납부자번호 체계 설명 1
		payerNumberSystemDesc2 = VOUtils.toString(payerNumberSystemDesc2$ = VOUtils.read(in, 70, "EUC-KR")); // 납부자번호 체계 설명 2
		payerNumberSystemDesc3 = VOUtils.toString(payerNumberSystemDesc3$ = VOUtils.read(in, 70, "EUC-KR")); // 납부자번호 체계 설명 3
		filler5 = VOUtils.toString(filler5$ = VOUtils.read(in, 5)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", dataRecordType=").append(dataRecordType).append(System.lineSeparator()); // Data Record 구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", changeSeqBitMap=").append(changeSeqBitMap).append(System.lineSeparator()); // 변경항번BitMap
		sb.append(", payerNumberSystemDesc1=").append(payerNumberSystemDesc1).append(System.lineSeparator()); // 납부자번호 체계 설명 1
		sb.append(", payerNumberSystemDesc2=").append(payerNumberSystemDesc2).append(System.lineSeparator()); // 납부자번호 체계 설명 2
		sb.append(", payerNumberSystemDesc3=").append(payerNumberSystemDesc3).append(System.lineSeparator()); // 납부자번호 체계 설명 3
		sb.append(", filler5=").append(filler5).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "dataRecordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "changeSeqBitMap", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "payerNumberSystemDesc1", "fldLen", "70", "defltVal", ""),
			Map.of("fld", "payerNumberSystemDesc2", "fldLen", "70", "defltVal", ""),
			Map.of("fld", "payerNumberSystemDesc3", "fldLen", "70", "defltVal", ""),
			Map.of("fld", "filler5", "fldLen", "5", "defltVal", "")
		);
	}

}
