package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90RA kftCmsEB90RA  = new KftCmsEB90RA(); // 이용기관정보통지
 * kftCmsEB90RA.setRecordType(""); // Record 구분
 * kftCmsEB90RA.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB90RA.setDataRecordType(""); // Data Record 구분코드
 * kftCmsEB90RA.setInstitutionCode(""); // 기관코드
 * kftCmsEB90RA.setNotificationSeqNo(""); // 통지일련번호
 * kftCmsEB90RA.setNotificationType(""); // 통지구분
 * kftCmsEB90RA.setStartDate(""); // 시행일
 * kftCmsEB90RA.setChangeSeqBitMap(""); // 변경항번BitMap
 * kftCmsEB90RA.setCorpTradeName(""); // 법인 상호명
 * kftCmsEB90RA.setCorpRepresentativeName(""); // 법인 대표자명
 * kftCmsEB90RA.setCorpBusinessNumber(""); // 법인 사업자등록번호
 * kftCmsEB90RA.setCorpAddress(""); // 법인 주소
 * kftCmsEB90RA.setDepositTransferService(""); // 입금이체 서비스
 * kftCmsEB90RA.setWithdrawalTransfer3DayService(""); // 출금이체(3일) 서비스
 * kftCmsEB90RA.setRealTimeTransferService(""); // 실시간 이체 서비스
 * kftCmsEB90RA.setRealTimeDepositWithdrawalNotificationService(""); // 입출금내역실시간단위통지 서비스
 * kftCmsEB90RA.setDepositWithdrawalBatchNotificationService(""); // 입출금내역일괄통지 서비스
 * kftCmsEB90RA.setRealTimeAccountHolderNameVerificationService(""); // 실시간계좌실명조회 서비스
 * kftCmsEB90RA.setRealTimeWithdrawalRequestService(""); // 실시간출금이체신청해지등록 서비스
 * kftCmsEB90RA.setWithdrawalTransferSameDayService(""); // 출금이체(당일) 서비스
 * kftCmsEB90RA.setDepositCustomerFeePerTransaction(0); // 입금이체 이체건당 고객 수수료
 * kftCmsEB90RA.setWithdrawal3DayCustomerFeePerRequestTransaction(0); // 출금이체(3일) 의뢰건당 고객 수수료
 * kftCmsEB90RA.setWithdrawal3DayCustomerFeePerTransaction(0); // 출금이체(3일) 이체건당 고객 수수료
 * kftCmsEB90RA.setWithdrawalSameDayCustomerFeePerRequestTransaction(0); // 출금이체(당일) 의뢰건당 고객 수수료
 * kftCmsEB90RA.setWithdrawalSameDayCustomerFeePerTransaction(0); // 출금이체(당일) 이체건당 고객 수수료
 * kftCmsEB90RA.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90RA implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String dataRecordType; // Data Record 구분코드
	private String institutionCode; // 기관코드
	private String notificationSeqNo; // 통지일련번호
	private String notificationType; // 통지구분
	private String startDate; // 시행일
	private String changeSeqBitMap; // 변경항번BitMap
	private String corpTradeName; // 법인 상호명
	private String corpRepresentativeName; // 법인 대표자명
	private String corpBusinessNumber; // 법인 사업자등록번호
	private String corpAddress; // 법인 주소
	private String depositTransferService; // 입금이체 서비스
	private String withdrawalTransfer3DayService; // 출금이체(3일) 서비스
	private String realTimeTransferService; // 실시간 이체 서비스
	private String realTimeDepositWithdrawalNotificationService; // 입출금내역실시간단위통지 서비스
	private String depositWithdrawalBatchNotificationService; // 입출금내역일괄통지 서비스
	private String realTimeAccountHolderNameVerificationService; // 실시간계좌실명조회 서비스
	private String realTimeWithdrawalRequestService; // 실시간출금이체신청해지등록 서비스
	private String withdrawalTransferSameDayService; // 출금이체(당일) 서비스
	private int depositCustomerFeePerTransaction; // 입금이체 이체건당 고객 수수료
	private int withdrawal3DayCustomerFeePerRequestTransaction; // 출금이체(3일) 의뢰건당 고객 수수료
	private int withdrawal3DayCustomerFeePerTransaction; // 출금이체(3일) 이체건당 고객 수수료
	private int withdrawalSameDayCustomerFeePerRequestTransaction; // 출금이체(당일) 의뢰건당 고객 수수료
	private int withdrawalSameDayCustomerFeePerTransaction; // 출금이체(당일) 이체건당 고객 수수료
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataRecordType$; // Data Record 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationSeqNo$; // 통지일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationType$; // 통지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String startDate$; // 시행일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeSeqBitMap$; // 변경항번BitMap
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpTradeName$; // 법인 상호명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpRepresentativeName$; // 법인 대표자명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpBusinessNumber$; // 법인 사업자등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpAddress$; // 법인 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositTransferService$; // 입금이체 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalTransfer3DayService$; // 출금이체(3일) 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeTransferService$; // 실시간 이체 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeDepositWithdrawalNotificationService$; // 입출금내역실시간단위통지 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositWithdrawalBatchNotificationService$; // 입출금내역일괄통지 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeAccountHolderNameVerificationService$; // 실시간계좌실명조회 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeWithdrawalRequestService$; // 실시간출금이체신청해지등록 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalTransferSameDayService$; // 출금이체(당일) 서비스
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositCustomerFeePerTransaction$; // 입금이체 이체건당 고객 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawal3DayCustomerFeePerRequestTransaction$; // 출금이체(3일) 의뢰건당 고객 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawal3DayCustomerFeePerTransaction$; // 출금이체(3일) 이체건당 고객 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalSameDayCustomerFeePerRequestTransaction$; // 출금이체(당일) 의뢰건당 고객 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalSameDayCustomerFeePerTransaction$; // 출금이체(당일) 이체건당 고객 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		dataRecordType$ = VOUtils.write(out, dataRecordType, 1); // Data Record 구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		notificationSeqNo$ = VOUtils.write(out, notificationSeqNo, 8); // 통지일련번호
		notificationType$ = VOUtils.write(out, notificationType, 1); // 통지구분
		startDate$ = VOUtils.write(out, startDate, 8); // 시행일
		changeSeqBitMap$ = VOUtils.write(out, changeSeqBitMap, 15); // 변경항번BitMap
		corpTradeName$ = VOUtils.write(out, corpTradeName, 30, "EUC-KR"); // 법인 상호명
		corpRepresentativeName$ = VOUtils.write(out, corpRepresentativeName, 30, "EUC-KR"); // 법인 대표자명
		corpBusinessNumber$ = VOUtils.write(out, corpBusinessNumber, 16); // 법인 사업자등록번호
		corpAddress$ = VOUtils.write(out, corpAddress, 60, "EUC-KR"); // 법인 주소
		depositTransferService$ = VOUtils.write(out, depositTransferService, 1); // 입금이체 서비스
		withdrawalTransfer3DayService$ = VOUtils.write(out, withdrawalTransfer3DayService, 1); // 출금이체(3일) 서비스
		realTimeTransferService$ = VOUtils.write(out, realTimeTransferService, 1); // 실시간 이체 서비스
		realTimeDepositWithdrawalNotificationService$ = VOUtils.write(out, realTimeDepositWithdrawalNotificationService, 1); // 입출금내역실시간단위통지 서비스
		depositWithdrawalBatchNotificationService$ = VOUtils.write(out, depositWithdrawalBatchNotificationService, 1); // 입출금내역일괄통지 서비스
		realTimeAccountHolderNameVerificationService$ = VOUtils.write(out, realTimeAccountHolderNameVerificationService, 1); // 실시간계좌실명조회 서비스
		realTimeWithdrawalRequestService$ = VOUtils.write(out, realTimeWithdrawalRequestService, 1); // 실시간출금이체신청해지등록 서비스
		withdrawalTransferSameDayService$ = VOUtils.write(out, withdrawalTransferSameDayService, 1); // 출금이체(당일) 서비스
		depositCustomerFeePerTransaction$ = VOUtils.write(out, depositCustomerFeePerTransaction, 3); // 입금이체 이체건당 고객 수수료
		withdrawal3DayCustomerFeePerRequestTransaction$ = VOUtils.write(out, withdrawal3DayCustomerFeePerRequestTransaction, 3); // 출금이체(3일) 의뢰건당 고객 수수료
		withdrawal3DayCustomerFeePerTransaction$ = VOUtils.write(out, withdrawal3DayCustomerFeePerTransaction, 3); // 출금이체(3일) 이체건당 고객 수수료
		withdrawalSameDayCustomerFeePerRequestTransaction$ = VOUtils.write(out, withdrawalSameDayCustomerFeePerRequestTransaction, 3); // 출금이체(당일) 의뢰건당 고객 수수료
		withdrawalSameDayCustomerFeePerTransaction$ = VOUtils.write(out, withdrawalSameDayCustomerFeePerTransaction, 3); // 출금이체(당일) 이체건당 고객 수수료
		filler2$ = VOUtils.write(out, filler2, 39); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		dataRecordType = VOUtils.toString(dataRecordType$ = VOUtils.read(in, 1)); // Data Record 구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		notificationSeqNo = VOUtils.toString(notificationSeqNo$ = VOUtils.read(in, 8)); // 통지일련번호
		notificationType = VOUtils.toString(notificationType$ = VOUtils.read(in, 1)); // 통지구분
		startDate = VOUtils.toString(startDate$ = VOUtils.read(in, 8)); // 시행일
		changeSeqBitMap = VOUtils.toString(changeSeqBitMap$ = VOUtils.read(in, 15)); // 변경항번BitMap
		corpTradeName = VOUtils.toString(corpTradeName$ = VOUtils.read(in, 30, "EUC-KR")); // 법인 상호명
		corpRepresentativeName = VOUtils.toString(corpRepresentativeName$ = VOUtils.read(in, 30, "EUC-KR")); // 법인 대표자명
		corpBusinessNumber = VOUtils.toString(corpBusinessNumber$ = VOUtils.read(in, 16)); // 법인 사업자등록번호
		corpAddress = VOUtils.toString(corpAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 법인 주소
		depositTransferService = VOUtils.toString(depositTransferService$ = VOUtils.read(in, 1)); // 입금이체 서비스
		withdrawalTransfer3DayService = VOUtils.toString(withdrawalTransfer3DayService$ = VOUtils.read(in, 1)); // 출금이체(3일) 서비스
		realTimeTransferService = VOUtils.toString(realTimeTransferService$ = VOUtils.read(in, 1)); // 실시간 이체 서비스
		realTimeDepositWithdrawalNotificationService = VOUtils.toString(realTimeDepositWithdrawalNotificationService$ = VOUtils.read(in, 1)); // 입출금내역실시간단위통지 서비스
		depositWithdrawalBatchNotificationService = VOUtils.toString(depositWithdrawalBatchNotificationService$ = VOUtils.read(in, 1)); // 입출금내역일괄통지 서비스
		realTimeAccountHolderNameVerificationService = VOUtils.toString(realTimeAccountHolderNameVerificationService$ = VOUtils.read(in, 1)); // 실시간계좌실명조회 서비스
		realTimeWithdrawalRequestService = VOUtils.toString(realTimeWithdrawalRequestService$ = VOUtils.read(in, 1)); // 실시간출금이체신청해지등록 서비스
		withdrawalTransferSameDayService = VOUtils.toString(withdrawalTransferSameDayService$ = VOUtils.read(in, 1)); // 출금이체(당일) 서비스
		depositCustomerFeePerTransaction = VOUtils.toInt(depositCustomerFeePerTransaction$ = VOUtils.read(in, 3)); // 입금이체 이체건당 고객 수수료
		withdrawal3DayCustomerFeePerRequestTransaction = VOUtils.toInt(withdrawal3DayCustomerFeePerRequestTransaction$ = VOUtils.read(in, 3)); // 출금이체(3일) 의뢰건당 고객 수수료
		withdrawal3DayCustomerFeePerTransaction = VOUtils.toInt(withdrawal3DayCustomerFeePerTransaction$ = VOUtils.read(in, 3)); // 출금이체(3일) 이체건당 고객 수수료
		withdrawalSameDayCustomerFeePerRequestTransaction = VOUtils.toInt(withdrawalSameDayCustomerFeePerRequestTransaction$ = VOUtils.read(in, 3)); // 출금이체(당일) 의뢰건당 고객 수수료
		withdrawalSameDayCustomerFeePerTransaction = VOUtils.toInt(withdrawalSameDayCustomerFeePerTransaction$ = VOUtils.read(in, 3)); // 출금이체(당일) 이체건당 고객 수수료
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 39)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", dataRecordType=").append(dataRecordType).append(System.lineSeparator()); // Data Record 구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", notificationSeqNo=").append(notificationSeqNo).append(System.lineSeparator()); // 통지일련번호
		sb.append(", notificationType=").append(notificationType).append(System.lineSeparator()); // 통지구분
		sb.append(", startDate=").append(startDate).append(System.lineSeparator()); // 시행일
		sb.append(", changeSeqBitMap=").append(changeSeqBitMap).append(System.lineSeparator()); // 변경항번BitMap
		sb.append(", corpTradeName=").append(corpTradeName).append(System.lineSeparator()); // 법인 상호명
		sb.append(", corpRepresentativeName=").append(corpRepresentativeName).append(System.lineSeparator()); // 법인 대표자명
		sb.append(", corpBusinessNumber=").append(corpBusinessNumber).append(System.lineSeparator()); // 법인 사업자등록번호
		sb.append(", corpAddress=").append(corpAddress).append(System.lineSeparator()); // 법인 주소
		sb.append(", depositTransferService=").append(depositTransferService).append(System.lineSeparator()); // 입금이체 서비스
		sb.append(", withdrawalTransfer3DayService=").append(withdrawalTransfer3DayService).append(System.lineSeparator()); // 출금이체(3일) 서비스
		sb.append(", realTimeTransferService=").append(realTimeTransferService).append(System.lineSeparator()); // 실시간 이체 서비스
		sb.append(", realTimeDepositWithdrawalNotificationService=").append(realTimeDepositWithdrawalNotificationService).append(System.lineSeparator()); // 입출금내역실시간단위통지 서비스
		sb.append(", depositWithdrawalBatchNotificationService=").append(depositWithdrawalBatchNotificationService).append(System.lineSeparator()); // 입출금내역일괄통지 서비스
		sb.append(", realTimeAccountHolderNameVerificationService=").append(realTimeAccountHolderNameVerificationService).append(System.lineSeparator()); // 실시간계좌실명조회 서비스
		sb.append(", realTimeWithdrawalRequestService=").append(realTimeWithdrawalRequestService).append(System.lineSeparator()); // 실시간출금이체신청해지등록 서비스
		sb.append(", withdrawalTransferSameDayService=").append(withdrawalTransferSameDayService).append(System.lineSeparator()); // 출금이체(당일) 서비스
		sb.append(", depositCustomerFeePerTransaction=").append(depositCustomerFeePerTransaction).append(System.lineSeparator()); // 입금이체 이체건당 고객 수수료
		sb.append(", withdrawal3DayCustomerFeePerRequestTransaction=").append(withdrawal3DayCustomerFeePerRequestTransaction).append(System.lineSeparator()); // 출금이체(3일) 의뢰건당 고객 수수료
		sb.append(", withdrawal3DayCustomerFeePerTransaction=").append(withdrawal3DayCustomerFeePerTransaction).append(System.lineSeparator()); // 출금이체(3일) 이체건당 고객 수수료
		sb.append(", withdrawalSameDayCustomerFeePerRequestTransaction=").append(withdrawalSameDayCustomerFeePerRequestTransaction).append(System.lineSeparator()); // 출금이체(당일) 의뢰건당 고객 수수료
		sb.append(", withdrawalSameDayCustomerFeePerTransaction=").append(withdrawalSameDayCustomerFeePerTransaction).append(System.lineSeparator()); // 출금이체(당일) 이체건당 고객 수수료
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "dataRecordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "notificationSeqNo", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "notificationType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "startDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "changeSeqBitMap", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "corpTradeName", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "corpRepresentativeName", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "corpBusinessNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "corpAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "depositTransferService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "withdrawalTransfer3DayService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "realTimeTransferService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "realTimeDepositWithdrawalNotificationService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "depositWithdrawalBatchNotificationService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "realTimeAccountHolderNameVerificationService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "realTimeWithdrawalRequestService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "withdrawalTransferSameDayService", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "depositCustomerFeePerTransaction", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "withdrawal3DayCustomerFeePerRequestTransaction", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "withdrawal3DayCustomerFeePerTransaction", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "withdrawalSameDayCustomerFeePerRequestTransaction", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "withdrawalSameDayCustomerFeePerTransaction", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "39", "defltVal", "")
		);
	}

}
