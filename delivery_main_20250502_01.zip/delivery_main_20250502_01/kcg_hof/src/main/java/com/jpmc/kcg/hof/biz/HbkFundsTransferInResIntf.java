package com.jpmc.kcg.hof.biz;

import java.time.Duration;

import org.apache.commons.lang3.ThreadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.hof.biz.vo.KftHof0210450000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0210450000;
import com.jpmc.kcg.hof.dto.HbkTrL;
import com.jpmc.kcg.hof.dto.HbkTransactionIn;
import com.jpmc.kcg.hof.dto.SelectHbkTransactionIn;
import com.jpmc.kcg.hof.enums.HbkConst;
import com.jpmc.kcg.hof.enums.HbkRespCdEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 이체거래 타발응답 (0210/450000) LVB -> KCG -> KFTC
 */
@Slf4j
@Component
public class HbkFundsTransferInResIntf extends FrwServiceBean<LvbHof0210450000> {

	@Autowired
	private FrwTemplate frwTemplate;

	@Autowired
	private HbkCom hbkCom;
	
	@Autowired
	private BizCom bizCom;

	@Autowired
	private FrwContext frwContext;
	
	@Autowired
	private HbkFundsTransferReversalTransactionOutReqIntf hbkFundsTransferReversalTransactionOutReqIntf;

	/**
	 * 처리
	 */
	@Override
	public void process(LvbHof0210450000 in) {
		
		log.debug("타발 이체거래 응답 LvbHof0210450000 in {}", in);
		
		/**
		 * 1. 요청거래 조회
		 * 2. 응답코드 변환 (9XX -> 413)
		 * 3. 거래내역 UPDATE
		 * 4. 응답 전문 조립
		 * 5. 000 정상응답 아닌경우 반대거래 요청
		 */

		// 1. 거래고유번호 요청중인 거래가 있는지 확인
		SelectHbkTransactionIn selectIn = new SelectHbkTransactionIn();
		selectIn.setTrDt(in.getTransactionDate().format(DateFormat.YYYYMMDD.getFormatter()));
		selectIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_02); // 타발
		selectIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0200);
		selectIn.setHbkTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());

		HbkTrL reqTrInfo = hbkCom.selectHBKTransaction(selectIn);
		
		// 2. HOST 응답코드 (9XX -> 413)
		if (in.getResponseCode().startsWith(ComConst.CHAR_9)) {
			in.setResponseCode(HbkRespCdEnum.RESP_CD_413.getCode());
		}

		// 3. 거래내역 UPDATE
		HbkTransactionIn updateIn = new HbkTransactionIn();
		updateIn.setTrDt(in.getTransactionDate().format(DateFormat.YYYYMMDD.getFormatter()));
		updateIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_02);
		updateIn.setTrUnqNo(in.getTransactionIdNumber());
		updateIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0210);
		//인바운드 거래는 LVB 처리 결과에 관계없이 정상으로 UPDATE, 에러일 경우 개설은행응답코드에 해당 에러코드 갱신
		updateIn.setRespCd(HbkRespCdEnum.RESP_CD_000.getCode());
		updateIn.setHbkInitInstRespCd(in.getResponseCode());
		updateIn.setTrStsCd(TrStsCdEnum.COMPLETE.getTrStsCd());

		hbkCom.updateHBKTransaction(updateIn);

		// 4. 응답 전문 조립 및 전송
		KftHof0210450000 respVo = VOUtils.toVo(frwContext.getOrgnTlgCtt(), KftHof0210450000.class);
		String respFlag = _getRespFlag(respVo.getSendReceiveFlag());
		String respCd = bizCom.getRespCdMap(ComConst.KFT, BizDvsnCdEnum.HOF.getValue(), in.getResponseCode());

		respVo.setMessageType(HbkConst.TLG_KND_DVSN_NO_0210);
		respVo.setResponseCode(respCd);
		respVo.setSendReceiveFlag(respFlag);
		respVo.setBeneficiaryBranchCode(HbkConst.JPMC_BANK_CD + HbkConst.JPMC_BRNCH_CD);
		respVo.setBeneficiaryAreaCode(HbkConst.NOTE_EX_CD_01);
		respVo.setBeneficiaryName(in.getBeneficiaryName());

		frwTemplate.send(FrwDestination.KFT_HOF, respVo);
		
		//거절일 경우 반대거래 (반대거래요청을 먼저 받을 경우 결제원 에러 -> 3초 sleep)
		if(!in.getResponseCode().equals(HbkRespCdEnum.RESP_CD_000.getCode())) {
			
			ThreadUtils.sleepQuietly(Duration.ofSeconds(3L));

			hbkFundsTransferReversalTransactionOutReqIntf.hbkFundsTransferReversalTransactionOutReq(reqTrInfo);
			
		}
		
	}


	/**
	 * 
	 * @param reqFlag
	 * @return respFlag
	 */
	public String _getRespFlag(String reqFlag) {

		String respFlag = "";

		int flag = Integer.parseInt(reqFlag);
		respFlag = String.valueOf(flag + 1);

		return respFlag;
	}
}
