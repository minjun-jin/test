package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 현금입금취소
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * prefixMessageCode prefix업무구분코드 prefix(000)업무별 거래유형 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * responseCode 응답코드 전문의 처리결과를 정의해 주는 코드
 * requestBankCode 취급은행 전문의 처리결과를 정의해 주는 코드
 * beneficiaryBankCode 수취은행 수취은행
 * transactionDate 전송일자 전문전송일자
 * transactionIdNumber 거래고유번호 취급기관의 전문관리번호(기관별 일련번호)
 * beneficiaryAccountNumber 수취계좌번호 수취계좌번호
 * totalAmount 총금액 의뢰한 총금액
 * beneficiaryName 수취인명 수취인명
 * senderName 송신자명 송신자명
 * realSenderName 송금인실명 송금인실명
 * cashAmount 현금금액 현금으로 입금의뢰한 금액
 * beneficiaryOrCancelAmount 수취/취소금액 수표금액/부도금액
 * originalDate 원거래일자 
 * originalMsgNo 원거래메시지번호 거래금액에 대한 암호
 * cancelDishonorReasonCode 취소부도사유코드 01예금부족 02무거래 03형식불비 04안내서미착 05사고신고서접수 06위조변조 07제시기간경과 08제시기간미도래 09인감서명상위 10지급지상위 11법적지급제한 12가계수표한도초과 13예금부족(사고신고서접수) 14기타
 * reservedInformationField10 예비 타점권 입금시 타점권 해당 지역코드
 * 
 * CqeIft0400200 cqeIft0400200 = new CqeIft0400200(); // 현금입금취소
 * cqeIft0400200.setMsgType("KCGCQE"); // 메시지구분
 * cqeIft0400200.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeIft0400200.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeIft0400200.setMessageType("0400"); // 전문종별구분코드
 * cqeIft0400200.setPrefixMessageCode("000"); // prefix업무구분코드
 * cqeIft0400200.setMessageCode("200"); // 업무구분코드
 * cqeIft0400200.setResponseCode("000"); // 응답코드
 * cqeIft0400200.setRequestBankCode(""); // 취급은행
 * cqeIft0400200.setBeneficiaryBankCode("000"); // 수취은행
 * cqeIft0400200.setTransactionDate(LocalDate.now()); // 전송일자
 * cqeIft0400200.setTransactionIdNumber("0000000000000"); // 거래고유번호
 * cqeIft0400200.setBeneficiaryAccountNumber("0000000000000000"); // 수취계좌번호
 * cqeIft0400200.setTotalAmount(0L); // 총금액
 * cqeIft0400200.setBeneficiaryName(""); // 수취인명
 * cqeIft0400200.setSenderName(""); // 송신자명
 * cqeIft0400200.setRealSenderName(""); // 송금인실명
 * cqeIft0400200.setCashAmount(0L); // 현금금액
 * cqeIft0400200.setBeneficiaryOrCancelAmount(0L); // 수취/취소금액
 * cqeIft0400200.setOriginalDate(LocalDate.now()); // 원거래일자
 * cqeIft0400200.setOriginalMsgNo("00000000"); // 원거래메시지번호
 * cqeIft0400200.setCancelDishonorReasonCode(""); // 취소부도사유코드
 * cqeIft0400200.setReservedInformationField10(""); // 예비
 * }</pre>
 */
@Data
public class CqeIft0400200 implements CqeIftComHdr, Vo {

	private String msgType = "KCGCQE"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0400"; // 전문종별구분코드
	private String prefixMessageCode = "000"; // prefix업무구분코드
	private String messageCode = "200"; // 업무구분코드
	private String responseCode = "000"; // 응답코드
	private String requestBankCode; // 취급은행
	private String beneficiaryBankCode = "000"; // 수취은행
	private LocalDate transactionDate; // 전송일자
	private String transactionIdNumber = "0000000000000"; // 거래고유번호
	private String beneficiaryAccountNumber = "0000000000000000"; // 수취계좌번호
	private long totalAmount; // 총금액
	private String beneficiaryName; // 수취인명
	private String senderName; // 송신자명
	private String realSenderName; // 송금인실명
	private long cashAmount; // 현금금액
	private long beneficiaryOrCancelAmount; // 수취/취소금액
	private LocalDate originalDate; // 원거래일자
	private String originalMsgNo = "00000000"; // 원거래메시지번호
	private String cancelDishonorReasonCode; // 취소부도사유코드
	private String reservedInformationField10; // 예비
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prefixMessageCode$; // prefix업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankCode$; // 취급은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 수취은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionDate$; // 전송일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalAmount$; // 총금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String senderName$; // 송신자명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realSenderName$; // 송금인실명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String cashAmount$; // 현금금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryOrCancelAmount$; // 수취/취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalDate$; // 원거래일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalMsgNo$; // 원거래메시지번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String cancelDishonorReasonCode$; // 취소부도사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField10$; // 예비

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		prefixMessageCode$ = VOUtils.write(out, prefixMessageCode, 3); // prefix업무구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBankCode$ = VOUtils.write(out, requestBankCode, 3); // 취급은행
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 수취은행
		transactionDate$ = VOUtils.write(out, transactionDate, 8, "yyyyMMdd"); // 전송일자
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취계좌번호
		totalAmount$ = VOUtils.write(out, totalAmount, 14); // 총금액
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인명
		senderName$ = VOUtils.write(out, senderName, 20, "EUC-KR"); // 송신자명
		realSenderName$ = VOUtils.write(out, realSenderName, 20, "EUC-KR"); // 송금인실명
		cashAmount$ = VOUtils.write(out, cashAmount, 12); // 현금금액
		beneficiaryOrCancelAmount$ = VOUtils.write(out, beneficiaryOrCancelAmount, 12); // 수취/취소금액
		originalDate$ = VOUtils.write(out, originalDate, 8, "yyyyMMdd"); // 원거래일자
		originalMsgNo$ = VOUtils.write(out, originalMsgNo, 8); // 원거래메시지번호
		cancelDishonorReasonCode$ = VOUtils.write(out, cancelDishonorReasonCode, 2); // 취소부도사유코드
		reservedInformationField10$ = VOUtils.write(out, reservedInformationField10, 50); // 예비
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		prefixMessageCode = VOUtils.toString(prefixMessageCode$ = VOUtils.read(in, 3)); // prefix업무구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBankCode = VOUtils.toString(requestBankCode$ = VOUtils.read(in, 3)); // 취급은행
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 수취은행
		transactionDate = VOUtils.toLocalDate(transactionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전송일자
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취계좌번호
		totalAmount = VOUtils.toLong(totalAmount$ = VOUtils.read(in, 14)); // 총금액
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인명
		senderName = VOUtils.toString(senderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송신자명
		realSenderName = VOUtils.toString(realSenderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송금인실명
		cashAmount = VOUtils.toLong(cashAmount$ = VOUtils.read(in, 12)); // 현금금액
		beneficiaryOrCancelAmount = VOUtils.toLong(beneficiaryOrCancelAmount$ = VOUtils.read(in, 12)); // 수취/취소금액
		originalDate = VOUtils.toLocalDate(originalDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 원거래일자
		originalMsgNo = VOUtils.toString(originalMsgNo$ = VOUtils.read(in, 8)); // 원거래메시지번호
		cancelDishonorReasonCode = VOUtils.toString(cancelDishonorReasonCode$ = VOUtils.read(in, 2)); // 취소부도사유코드
		reservedInformationField10 = VOUtils.toString(reservedInformationField10$ = VOUtils.read(in, 50)); // 예비
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", prefixMessageCode=").append(prefixMessageCode).append(System.lineSeparator()); // prefix업무구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBankCode=").append(requestBankCode).append(System.lineSeparator()); // 취급은행
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 수취은행
		sb.append(", transactionDate=").append(transactionDate).append(System.lineSeparator()); // 전송일자
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취계좌번호
		sb.append(", totalAmount=").append(totalAmount).append(System.lineSeparator()); // 총금액
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인명
		sb.append(", senderName=").append(senderName).append(System.lineSeparator()); // 송신자명
		sb.append(", realSenderName=").append(realSenderName).append(System.lineSeparator()); // 송금인실명
		sb.append(", cashAmount=").append(cashAmount).append(System.lineSeparator()); // 현금금액
		sb.append(", beneficiaryOrCancelAmount=").append(beneficiaryOrCancelAmount).append(System.lineSeparator()); // 수취/취소금액
		sb.append(", originalDate=").append(originalDate).append(System.lineSeparator()); // 원거래일자
		sb.append(", originalMsgNo=").append(originalMsgNo).append(System.lineSeparator()); // 원거래메시지번호
		sb.append(", cancelDishonorReasonCode=").append(cancelDishonorReasonCode).append(System.lineSeparator()); // 취소부도사유코드
		sb.append(", reservedInformationField10=").append(reservedInformationField10).append(System.lineSeparator()); // 예비
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "KCGCQE"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0400"),
			Map.of("fld", "prefixMessageCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "200"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "transactionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", "0000000000000"),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", "0000000000000000"),
			Map.of("fld", "totalAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "senderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "realSenderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "cashAmount", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "beneficiaryOrCancelAmount ", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "originalDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "originalMsgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "cancelDishonorReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "reservedInformationField10", "fldLen", "50", "defltVal", "")
		);
	}

}
