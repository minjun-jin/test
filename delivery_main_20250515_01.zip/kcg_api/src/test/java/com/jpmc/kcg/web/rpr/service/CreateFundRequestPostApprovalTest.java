package com.jpmc.kcg.web.rpr.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.rpr.biz.enums.RprConst;
import com.jpmc.kcg.rpr.biz.vo.KcgRpr0200300000;
import com.jpmc.kcg.rpr.dao.RprTrLDao;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HofTrLWebDao;
import com.jpmc.kcg.web.rpr.service.dto.CreateFundRequestApprovalIn;

import lombok.extern.slf4j.Slf4j;

@ExtendWith(MockitoExtension.class)
@Slf4j
class CreateFundRequestPostApprovalTest {

    @InjectMocks
    private CreateFundRequestPostApproval service;
    @Mock
    private FrwTemplate frwTemplate;
    @Mock
    private HofTrLWebDao hofTrLDao;
    @Mock
    private RprTrLDao rprTrLDao;
    @Mock
    private CommonApprovalSvc commonApprovalSvc;
    @Mock
    private Header header; // Mock Header
    
    @BeforeEach
    void setUp() {
        WebContextImpl webContextImpl = new WebContextImpl();
        header = new Header();
        header.setLngCd("en");
        header.setRoles(List.of("00", "02", "07", "08"));
        webContextImpl.setHeader(header);
        FrwContextHolder.setContext(webContextImpl);
    }

    @AfterEach
    void tearDown() {
        // 테스트가 끝나면 ThreadLocal을 정리하여 다른 테스트에 영향이 없도록 함
        FrwContextHolder.clearContext();
    }
    
    @Test
    @Order(1)
    void postRejectCreateFundRequest_01() {
        // Given
    	CreateFundRequestApprovalIn in = new CreateFundRequestApprovalIn();
        in.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
        in.setTrUnqNo("00000002");
        // Case 1: Post approval
        service.postReject("03", in);
        verify(hofTrLDao, times(1)).updateHofTrStsCd(any(HofTrL.class));
        
        System.out.print(">>>>>>> input ::" + in);
        System.out.print(">>>>>>>aprvStsCd :: 03");
    }
    
    @Test
    @Order(2)
    void testSendQueue() {
        // Arrange
    	CreateFundRequestApprovalIn input = new CreateFundRequestApprovalIn();
        input.setOrgnTrDt("20250320");
        input.setOrgnTrUnqNo("TRX9999");
        input.setRqstRtnTrAmt(BigDecimal.valueOf(5000));
        input.setHndlBnkCd("BANK001");
        input.setOrgnRcvAcctNo("ACC123456");
        input.setOnlineRqstYn("Y");
        input.setRtnYn(RprConst.N);
        input.setRtnRsnCd("R001");
        input.setRtnRsn("Reason");
        input.setRtnRjctRsnCd("RJ001");
        input.setRtnRjctRsn("RejectReason");
        input.setMgrTelNo("01011112222");
        input.setRqstDt("20250320");

        HofTrL dummyHof = new HofTrL();
        dummyHof.setTrDt("20250325");
        dummyHof.setTrUnqNo("DUMMY_TRUNQ");
        dummyHof.setHostNo("DUMMY_HOST");

        // Act: _sendQueue()가 예외 없이 실행되어야 함
        assertDoesNotThrow(() -> {
            service._sendQueue(input);
        });
    }
    
    @Test
    @Order(3)
    void postApproval_정상흐름() {
        // Given
        CreateFundRequestApprovalIn in = new CreateFundRequestApprovalIn();
        in.setHofTrDt("20250401");
        in.setHofOutinDvsnCd("I");
        in.setHofTrUnqNo("UNQ001");
        in.setHofHofTlgTrceNo("TLG001");
        in.setHofHostNo("HOST001");
        in.setRqstRtnTrAmt(new BigDecimal(10000));
		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
		in.setOrgnTrDt("20250401");
    	KcgRpr0200300000 vo = new KcgRpr0200300000();
		String dateStr = in.getOrgnTrDt();
    	vo.setOriginalDate(LocalDate.parse(dateStr, formatter));
    	vo.getAmount();
        // When
        Object result = service.postApproval("01", in);
        log.debug("result {}", result);
        // Then
        verify(hofTrLDao, times(1)).updateHofTrStsCd(any(HofTrL.class));
        assertDoesNotThrow(() -> service.postApproval("01", in));
    }

    @Test
    @Order(4)
    void createHofTrL_필드값검증() {
        // Given
        CreateFundRequestApprovalIn in = new CreateFundRequestApprovalIn();
        in.setHofTrDt("20250401");
        in.setHofOutinDvsnCd("I");
        in.setHofTrUnqNo("UNQ002");
        in.setHofHofTlgTrceNo("TLG002");
        in.setHofHostNo("HOST002");

        String staffId = "staff123";
        String guid = "guid-xyz";
        String timestamp = "20250401123000";

        // When
        HofTrL result = service._createHofTrL(in, "COMPLETE", "APPROVED", staffId, guid, timestamp);

        // Then
        assert result.getTrDt().equals("20250401");
        assert result.getTrUnqNo().equals("UNQ002");
        assert result.getTrStsCd().equals("COMPLETE");
        assert result.getAprvStsCd().equals("APPROVED");
        assert result.getChkId().equals(staffId);
        assert result.getLastChngGuid().equals(guid);
        assert result.getChkDttm().equals(timestamp);
    }

    @Test
    @Order(5)
    void sendQueue_예외케이스_날짜포맷이_틀린경우() {
        // Arrange
        CreateFundRequestApprovalIn input = new CreateFundRequestApprovalIn();
        input.setOrgnTrDt("2025-03-20"); // 잘못된 포맷

        // Act & Assert
        assertThrows(Exception.class, () -> service._sendQueue(input));
    }
    
    
    
}
