package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시 결과내역
 * <pre>{@code
 * KftEntES1105R kftEntES1105R  = new KftEntES1105R(); // 지급제시 결과내역
 * kftEntES1105R.setFileName(""); // 업무구분
 * kftEntES1105R.setDataType(""); // 데이터구분
 * kftEntES1105R.setSerialNumber(""); // 일련번호
 * kftEntES1105R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1105R.setBankCode(""); // 은행코드
 * kftEntES1105R.setPaymentPresentationDate(""); // 지급제시일자
 * kftEntES1105R.setPaymentPresentationNumber(""); // 지급제시번호
 * kftEntES1105R.setSettlementProcessDivisionCode(""); // 결제처리구분
 * kftEntES1105R.setEnoteNumber(""); // 어음번호
 * kftEntES1105R.setEnoteType(""); // 어음종류
 * kftEntES1105R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1105R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1105R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1105R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1105R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1105R.setPaymentBranchClearingHouseCode(""); // 지급점포 교환소 코드
 * kftEntES1105R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES1105R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES1105R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES1105R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES1105R.setIssuerAddress(""); // 발행인-주소
 * kftEntES1105R.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEntES1105R.setBeneficiaryCorpIndvSort(""); // 수취인-법인개인구분
 * kftEntES1105R.setBeneficiaryResidentBusinessNumber(""); // 수취인-주민사업자번호
 * kftEntES1105R.setBeneficiaryCorpName(""); // 수취인-법인명
 * kftEntES1105R.setBeneficiaryNameRepresentativeName(""); // 수취인-성명(대표자명)
 * kftEntES1105R.setBeneficiaryAddress(""); // 수취인-주소
 * kftEntES1105R.setBeneficiaryBankCode(""); // 수취인-은행코드
 * kftEntES1105R.setBeneficiaryAccountNumber(""); // 수취인-수취계좌번호
 * kftEntES1105R.setBeneficiarySplitEnoteAmount(0L); // 수취인-분할된 전자어음 금액
 * kftEntES1105R.setBeneficiarySplitNumber(""); // 수취인-분할번호
 * kftEntES1105R.setBeneficiaryEndorsementNumber(""); // 수취인-배서번호
 * kftEntES1105R.setEnoteMaturedSettlementDateTime(""); // 전자어음 만기 결제일시
 * kftEntES1105R.setDefaultDate(""); // 부도일
 * kftEntES1105R.setEnoteDefaultReason(""); // 전자어음 부도사유
 * kftEntES1105R.setAccidentReportReason(""); // 사고신고서 사유
 * kftEntES1105R.setPaymentSuspensionProvisionalDisposition(""); // 지급정지 가처분
 * kftEntES1105R.setSpecialDeposit(""); // 별단예금 입금
 * kftEntES1105R.setBankManagementCompanyYn(""); // 은행관리 기업여부
 * kftEntES1105R.setRestructuringTargetCompanyYn(""); // 구조조정대상기업여부
 * kftEntES1105R.setDepositShortageCause(""); // 예금부족 원인
 * kftEntES1105R.setDefaultDepositDateTime(""); // 부도 입금일시
 * kftEntES1105R.setDefaultDepositBankAndBranchCode(""); // 부도 입금은행 및 지점코드
 * kftEntES1105R.setDefaultReasonChangeYn(""); // 부도사유 변경여부
 * kftEntES1105R.setBeforeChangeEnoteDefaultReason(""); // 변경 전 전자저음 부도사유
 * kftEntES1105R.setAfterChangeENoteDefaultReason(""); // 변경 후 전자어음 부도사유
 * kftEntES1105R.setNotificationTarget(""); // 통지대상
 * kftEntES1105R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1105R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String paymentPresentationDate; // 지급제시일자
	private String paymentPresentationNumber; // 지급제시번호
	private String settlementProcessDivisionCode; // 결제처리구분
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String paymentBranchClearingHouseCode; // 지급점포 교환소 코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String beneficiaryCorpIndvSort; // 수취인-법인개인구분
	private String beneficiaryResidentBusinessNumber; // 수취인-주민사업자번호
	private String beneficiaryCorpName; // 수취인-법인명
	private String beneficiaryNameRepresentativeName; // 수취인-성명(대표자명)
	private String beneficiaryAddress; // 수취인-주소
	private String beneficiaryBankCode; // 수취인-은행코드
	private String beneficiaryAccountNumber; // 수취인-수취계좌번호
	private long beneficiarySplitEnoteAmount; // 수취인-분할된 전자어음 금액
	private String beneficiarySplitNumber; // 수취인-분할번호
	private String beneficiaryEndorsementNumber; // 수취인-배서번호
	private String enoteMaturedSettlementDateTime; // 전자어음 만기 결제일시
	private String defaultDate; // 부도일
	private String enoteDefaultReason; // 전자어음 부도사유
	private String accidentReportReason; // 사고신고서 사유
	private String paymentSuspensionProvisionalDisposition; // 지급정지 가처분
	private String specialDeposit; // 별단예금 입금
	private String bankManagementCompanyYn; // 은행관리 기업여부
	private String restructuringTargetCompanyYn; // 구조조정대상기업여부
	private String depositShortageCause; // 예금부족 원인
	private String defaultDepositDateTime; // 부도 입금일시
	private String defaultDepositBankAndBranchCode; // 부도 입금은행 및 지점코드
	private String defaultReasonChangeYn; // 부도사유 변경여부
	private String beforeChangeEnoteDefaultReason; // 변경 전 전자저음 부도사유
	private String afterChangeENoteDefaultReason; // 변경 후 전자어음 부도사유
	private String notificationTarget; // 통지대상
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationNumber$; // 지급제시번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String settlementProcessDivisionCode$; // 결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포 교환소 코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryCorpIndvSort$; // 수취인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryResidentBusinessNumber$; // 수취인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryCorpName$; // 수취인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryNameRepresentativeName$; // 수취인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAddress$; // 수취인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 수취인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취인-수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiarySplitEnoteAmount$; // 수취인-분할된 전자어음 금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiarySplitNumber$; // 수취인-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryEndorsementNumber$; // 수취인-배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedSettlementDateTime$; // 전자어음 만기 결제일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 부도일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteDefaultReason$; // 전자어음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportReason$; // 사고신고서 사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentSuspensionProvisionalDisposition$; // 지급정지 가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specialDeposit$; // 별단예금 입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankManagementCompanyYn$; // 은행관리 기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String restructuringTargetCompanyYn$; // 구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositShortageCause$; // 예금부족 원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositDateTime$; // 부도 입금일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositBankAndBranchCode$; // 부도 입금은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonChangeYn$; // 부도사유 변경여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeEnoteDefaultReason$; // 변경 전 전자저음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeENoteDefaultReason$; // 변경 후 전자어음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationTarget$; // 통지대상
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		paymentPresentationNumber$ = VOUtils.write(out, paymentPresentationNumber, 16); // 지급제시번호
		settlementProcessDivisionCode$ = VOUtils.write(out, settlementProcessDivisionCode, 2); // 결제처리구분
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포 교환소 코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		beneficiaryCorpIndvSort$ = VOUtils.write(out, beneficiaryCorpIndvSort, 1); // 수취인-법인개인구분
		beneficiaryResidentBusinessNumber$ = VOUtils.write(out, beneficiaryResidentBusinessNumber, 13); // 수취인-주민사업자번호
		beneficiaryCorpName$ = VOUtils.write(out, beneficiaryCorpName, 40, "EUC-KR"); // 수취인-법인명
		beneficiaryNameRepresentativeName$ = VOUtils.write(out, beneficiaryNameRepresentativeName, 20, "EUC-KR"); // 수취인-성명(대표자명)
		beneficiaryAddress$ = VOUtils.write(out, beneficiaryAddress, 60, "EUC-KR"); // 수취인-주소
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 수취인-은행코드
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취인-수취계좌번호
		beneficiarySplitEnoteAmount$ = VOUtils.write(out, beneficiarySplitEnoteAmount, 15); // 수취인-분할된 전자어음 금액
		beneficiarySplitNumber$ = VOUtils.write(out, beneficiarySplitNumber, 2); // 수취인-분할번호
		beneficiaryEndorsementNumber$ = VOUtils.write(out, beneficiaryEndorsementNumber, 2); // 수취인-배서번호
		enoteMaturedSettlementDateTime$ = VOUtils.write(out, enoteMaturedSettlementDateTime, 14); // 전자어음 만기 결제일시
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 부도일
		enoteDefaultReason$ = VOUtils.write(out, enoteDefaultReason, 2); // 전자어음 부도사유
		accidentReportReason$ = VOUtils.write(out, accidentReportReason, 1); // 사고신고서 사유
		paymentSuspensionProvisionalDisposition$ = VOUtils.write(out, paymentSuspensionProvisionalDisposition, 1); // 지급정지 가처분
		specialDeposit$ = VOUtils.write(out, specialDeposit, 1); // 별단예금 입금
		bankManagementCompanyYn$ = VOUtils.write(out, bankManagementCompanyYn, 1); // 은행관리 기업여부
		restructuringTargetCompanyYn$ = VOUtils.write(out, restructuringTargetCompanyYn, 1); // 구조조정대상기업여부
		depositShortageCause$ = VOUtils.write(out, depositShortageCause, 1); // 예금부족 원인
		defaultDepositDateTime$ = VOUtils.write(out, defaultDepositDateTime, 14); // 부도 입금일시
		defaultDepositBankAndBranchCode$ = VOUtils.write(out, defaultDepositBankAndBranchCode, 7); // 부도 입금은행 및 지점코드
		defaultReasonChangeYn$ = VOUtils.write(out, defaultReasonChangeYn, 1); // 부도사유 변경여부
		beforeChangeEnoteDefaultReason$ = VOUtils.write(out, beforeChangeEnoteDefaultReason, 2); // 변경 전 전자저음 부도사유
		afterChangeENoteDefaultReason$ = VOUtils.write(out, afterChangeENoteDefaultReason, 2); // 변경 후 전자어음 부도사유
		notificationTarget$ = VOUtils.write(out, notificationTarget, 1); // 통지대상
		filler2$ = VOUtils.write(out, filler2, 55); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		paymentPresentationNumber = VOUtils.toString(paymentPresentationNumber$ = VOUtils.read(in, 16)); // 지급제시번호
		settlementProcessDivisionCode = VOUtils.toString(settlementProcessDivisionCode$ = VOUtils.read(in, 2)); // 결제처리구분
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포 교환소 코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		beneficiaryCorpIndvSort = VOUtils.toString(beneficiaryCorpIndvSort$ = VOUtils.read(in, 1)); // 수취인-법인개인구분
		beneficiaryResidentBusinessNumber = VOUtils.toString(beneficiaryResidentBusinessNumber$ = VOUtils.read(in, 13)); // 수취인-주민사업자번호
		beneficiaryCorpName = VOUtils.toString(beneficiaryCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 수취인-법인명
		beneficiaryNameRepresentativeName = VOUtils.toString(beneficiaryNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인-성명(대표자명)
		beneficiaryAddress = VOUtils.toString(beneficiaryAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 수취인-주소
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 수취인-은행코드
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취인-수취계좌번호
		beneficiarySplitEnoteAmount = VOUtils.toLong(beneficiarySplitEnoteAmount$ = VOUtils.read(in, 15)); // 수취인-분할된 전자어음 금액
		beneficiarySplitNumber = VOUtils.toString(beneficiarySplitNumber$ = VOUtils.read(in, 2)); // 수취인-분할번호
		beneficiaryEndorsementNumber = VOUtils.toString(beneficiaryEndorsementNumber$ = VOUtils.read(in, 2)); // 수취인-배서번호
		enoteMaturedSettlementDateTime = VOUtils.toString(enoteMaturedSettlementDateTime$ = VOUtils.read(in, 14)); // 전자어음 만기 결제일시
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 부도일
		enoteDefaultReason = VOUtils.toString(enoteDefaultReason$ = VOUtils.read(in, 2)); // 전자어음 부도사유
		accidentReportReason = VOUtils.toString(accidentReportReason$ = VOUtils.read(in, 1)); // 사고신고서 사유
		paymentSuspensionProvisionalDisposition = VOUtils.toString(paymentSuspensionProvisionalDisposition$ = VOUtils.read(in, 1)); // 지급정지 가처분
		specialDeposit = VOUtils.toString(specialDeposit$ = VOUtils.read(in, 1)); // 별단예금 입금
		bankManagementCompanyYn = VOUtils.toString(bankManagementCompanyYn$ = VOUtils.read(in, 1)); // 은행관리 기업여부
		restructuringTargetCompanyYn = VOUtils.toString(restructuringTargetCompanyYn$ = VOUtils.read(in, 1)); // 구조조정대상기업여부
		depositShortageCause = VOUtils.toString(depositShortageCause$ = VOUtils.read(in, 1)); // 예금부족 원인
		defaultDepositDateTime = VOUtils.toString(defaultDepositDateTime$ = VOUtils.read(in, 14)); // 부도 입금일시
		defaultDepositBankAndBranchCode = VOUtils.toString(defaultDepositBankAndBranchCode$ = VOUtils.read(in, 7)); // 부도 입금은행 및 지점코드
		defaultReasonChangeYn = VOUtils.toString(defaultReasonChangeYn$ = VOUtils.read(in, 1)); // 부도사유 변경여부
		beforeChangeEnoteDefaultReason = VOUtils.toString(beforeChangeEnoteDefaultReason$ = VOUtils.read(in, 2)); // 변경 전 전자저음 부도사유
		afterChangeENoteDefaultReason = VOUtils.toString(afterChangeENoteDefaultReason$ = VOUtils.read(in, 2)); // 변경 후 전자어음 부도사유
		notificationTarget = VOUtils.toString(notificationTarget$ = VOUtils.read(in, 1)); // 통지대상
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 55)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", paymentPresentationNumber=").append(paymentPresentationNumber).append(System.lineSeparator()); // 지급제시번호
		sb.append(", settlementProcessDivisionCode=").append(settlementProcessDivisionCode).append(System.lineSeparator()); // 결제처리구분
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포 교환소 코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", beneficiaryCorpIndvSort=").append(beneficiaryCorpIndvSort).append(System.lineSeparator()); // 수취인-법인개인구분
		sb.append(", beneficiaryResidentBusinessNumber=").append(beneficiaryResidentBusinessNumber).append(System.lineSeparator()); // 수취인-주민사업자번호
		sb.append(", beneficiaryCorpName=").append(beneficiaryCorpName).append(System.lineSeparator()); // 수취인-법인명
		sb.append(", beneficiaryNameRepresentativeName=").append(beneficiaryNameRepresentativeName).append(System.lineSeparator()); // 수취인-성명(대표자명)
		sb.append(", beneficiaryAddress=").append(beneficiaryAddress).append(System.lineSeparator()); // 수취인-주소
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 수취인-은행코드
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취인-수취계좌번호
		sb.append(", beneficiarySplitEnoteAmount=").append(beneficiarySplitEnoteAmount).append(System.lineSeparator()); // 수취인-분할된 전자어음 금액
		sb.append(", beneficiarySplitNumber=").append(beneficiarySplitNumber).append(System.lineSeparator()); // 수취인-분할번호
		sb.append(", beneficiaryEndorsementNumber=").append(beneficiaryEndorsementNumber).append(System.lineSeparator()); // 수취인-배서번호
		sb.append(", enoteMaturedSettlementDateTime=").append(enoteMaturedSettlementDateTime).append(System.lineSeparator()); // 전자어음 만기 결제일시
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 부도일
		sb.append(", enoteDefaultReason=").append(enoteDefaultReason).append(System.lineSeparator()); // 전자어음 부도사유
		sb.append(", accidentReportReason=").append(accidentReportReason).append(System.lineSeparator()); // 사고신고서 사유
		sb.append(", paymentSuspensionProvisionalDisposition=").append(paymentSuspensionProvisionalDisposition).append(System.lineSeparator()); // 지급정지 가처분
		sb.append(", specialDeposit=").append(specialDeposit).append(System.lineSeparator()); // 별단예금 입금
		sb.append(", bankManagementCompanyYn=").append(bankManagementCompanyYn).append(System.lineSeparator()); // 은행관리 기업여부
		sb.append(", restructuringTargetCompanyYn=").append(restructuringTargetCompanyYn).append(System.lineSeparator()); // 구조조정대상기업여부
		sb.append(", depositShortageCause=").append(depositShortageCause).append(System.lineSeparator()); // 예금부족 원인
		sb.append(", defaultDepositDateTime=").append(defaultDepositDateTime).append(System.lineSeparator()); // 부도 입금일시
		sb.append(", defaultDepositBankAndBranchCode=").append(defaultDepositBankAndBranchCode).append(System.lineSeparator()); // 부도 입금은행 및 지점코드
		sb.append(", defaultReasonChangeYn=").append(defaultReasonChangeYn).append(System.lineSeparator()); // 부도사유 변경여부
		sb.append(", beforeChangeEnoteDefaultReason=").append(beforeChangeEnoteDefaultReason).append(System.lineSeparator()); // 변경 전 전자저음 부도사유
		sb.append(", afterChangeENoteDefaultReason=").append(afterChangeENoteDefaultReason).append(System.lineSeparator()); // 변경 후 전자어음 부도사유
		sb.append(", notificationTarget=").append(notificationTarget).append(System.lineSeparator()); // 통지대상
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentPresentationNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "settlementProcessDivisionCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneficiaryCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneficiaryResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneficiaryCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneficiaryNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneficiaryAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneficiarySplitEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "beneficiarySplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "beneficiaryEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "enoteMaturedSettlementDateTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "paymentSuspensionProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "specialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankManagementCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "restructuringTargetCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "depositShortageCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultDepositDateTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "defaultDepositBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "defaultReasonChangeYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeEnoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "afterChangeENoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "notificationTarget", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "55", "defltVal", "")
		);
	}

}
