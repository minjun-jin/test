package com.jpmc.kcg.bat.hof.job;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.jpmc.kcg.bat.TaskletBatJob;
import com.jpmc.kcg.bat.com.biz.ComFileTractLBean;
import com.jpmc.kcg.bat.hof.dao.BatHofSndRcvFileLDao;
import com.jpmc.kcg.com.dao.ComBnkBrnchMMapper;
import com.jpmc.kcg.com.dto.ComBnkBrnchM;
import com.jpmc.kcg.com.dto.ComFileTractL;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.hof.biz.vo.KftHofCC0011R;
import com.jpmc.kcg.hof.dto.HofSndRcvFileL;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class HofBnkBrnchCdJobBean extends TaskletBatJob {

	private final ComBnkBrnchMMapper comBnkBrnchMMapper;
	private final BatHofSndRcvFileLDao batHofSndRcvFileLDao;
	private final ComFileTractLBean comFileTractLBean;

	public HofBnkBrnchCdJobBean(ComBnkBrnchMMapper comBnkBrnchMMapper, BatHofSndRcvFileLDao batHofSndRcvFileLDao, ComFileTractLBean comFileTractLBean) {
		this.comBnkBrnchMMapper = comBnkBrnchMMapper;
		this.batHofSndRcvFileLDao = batHofSndRcvFileLDao;
		this.comFileTractLBean = comFileTractLBean;
	}

	@Override
	public void executeInternal(BatContext context) {
		String fileNm = context.getParam("fileNm"); // CC0011(매일) / CC0012(매월)
		String ordDt = context.getOrdDt(); // orderDate
        
		HofSndRcvFileL select = new HofSndRcvFileL();
		select.setFileNm(fileNm);
		select.setDataTp("22");
		select.setSrDt(ordDt);
		
		List<HofSndRcvFileL> tlgCttList =  batHofSndRcvFileLDao.selectHofSndRcvFileL(select);
		
		for(HofSndRcvFileL tlgCtt : tlgCttList) {
			
			log.debug("[I N F O] selectHofSndRcvFileL DATA tlgCtt : {}", tlgCtt);
			
			KftHofCC0011R data = VOUtils.toVo(tlgCtt.getTlgCtt(), KftHofCC0011R.class);
			String bnkCd = data.getBranchCode().substring(0,3); 
			String brnchCd1 = data.getBranchCode().substring(3,6);
			String brnchCd2 = data.getBranchCode().substring(6);
			
			// 기존 데이터 있는 경우 삭제 후 재적재
			ComBnkBrnchM selectData =  comBnkBrnchMMapper.selectByPrimaryKey(bnkCd, brnchCd1, brnchCd2);
			
			if (!ObjectUtils.isEmpty(selectData)) {
				int delCnt = comBnkBrnchMMapper.deleteByPrimaryKey(bnkCd, brnchCd1, brnchCd2);
				log.debug("[I N F O] deleteByPrimaryKey  DATA COUNT : {}", delCnt);
			}
			
			ComBnkBrnchM insert = new ComBnkBrnchM();
			insert.setBnkCd(bnkCd);											//은행코드
			insert.setBrnchCd1(brnchCd1);									//지점코드1
			insert.setBrnchCd2(brnchCd2);									//지점코드2
			insert.setBrnchStsCd(data.getDivCode());						//구분코드
			insert.setZipCd(data.getZipCode());								//우편번호
			insert.setAddr(data.getAddress());								//주소
			insert.setNoteExCd(data.getLocalCode());						//지역코드(어음교환소코드)
			insert.setBrnchNm(data.getBranchName());						//지점명
			insert.setAreaCd(data.getRegionCode());							//광역코드
			insert.setSubBrnchCd(data.getTellerCode());						//자점코드
			insert.setTelNo(data.getPhoneNumber());							//전화번호
			insert.setFaxNo(data.getFaxNumber());							//팩스번호
			insert.setEmailAddr(data.getEmail()); 			//이메일
			insert.setAddrCd(data.getAddressTypeCode());	//주소 구분코드
			insert.setTrDt(data.getApplyDate()); 							//적용일 
			insert.setFognExchBrnchCd(data.getForeignBranchCode());			//외국환점포코드 
			insert.setClsMgmtBrnchCd(data.getClosedBranchManagementCode());//폐쇄지점관리지점 
			if("*".equals(data.getDivCode())) {
				insert.setExprtnDt(data.getApplyDate());
			}
			
			comBnkBrnchMMapper.insert(insert);
			
		}
		
	    /**
         * file tracking 정보 저장. LOAD배치가 미수신 SKIP되어서 '완료'상태일 경우, 파일이 없기 때문에 fileTractId를 update하지 않음
         */
        ComFileTractL comFileTractL = comFileTractLBean.selectByPK(ordDt, fileNm);
        
        if (comFileTractL != null) {
            context.setFileTractId(comFileTractL.getTractId()); // "20250220", "CC0012"
        }
	}

}