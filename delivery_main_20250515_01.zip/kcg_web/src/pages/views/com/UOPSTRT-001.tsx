import { $eventUtils } from "@/utils/common.event"
/** ***********************************************************************
 * @ 서비스경로  : 운영화면 > 금결원 > 금결원 전문 송수신 로그
 * @ 페이지설명  : [UOPSTRT-001] 금결원 전문 송수신 로그
 * @ 파일명     : UOPSTRT-001.tsx
 * @ 작성자     : 이수현 (suehyun.lee@bankwareglobal.com)
 * @ 작성일     : 2023-06-05
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2023-06-05             이수현                 최초작성
 ************************************************************************ */
import useCode from "@/hooks/useCode"
import useModal from "@/hooks/useModal"
import useProxy from "@/hooks/useProxy"
import useForm from "@/hooks/useForm"
import { $dateUtils } from "@/utils/common.date"
import { $formatUtils } from "@/utils/common.format"
import { $i18nUtils } from "@/utils/common.i18n"
import { useCallback, useEffect, useRef, useState } from "react"

import Page from "@/components/Page"
import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import CardCol from "@/components/CardCol"
import CardRow from "@/components/CardRow"
import ContentToggle from "@/components/ContentToggle"
import DatePicker from "@/components/DatePicker"
import Grid from "@/components/Grid"
import IMask from "imask"
import InputBox from "@/components/InputBox"
import InputIconBox from "@/components/InputIconBox"
import LabelBox from "@/components/LabelBox"
import SelectBox from "@/components/SelectBox"
import TableBox from "@/components/TableBox"
import TableRow from "@/components/TableRow"

import { FrwMsg, PopupParam, TelegramLog } from "@/types/index"
import useParams from "@/hooks/useParams"
import useGrid from "@/hooks/useGrid"
import useDownloader from "@/hooks/useDownloader"

export function DirectionCellRenderer({ data, node }: any) {
  const $codeHooks = useCode()
  const { tractId, hostCd, bizDvsnCd, tractSortCd } = data
  const batchStr = "BAT"

  const isBatchTx = tractId && tractId.substring(6, 9) === batchStr

  const [departure, setDeparture] = useState("")
  const [leftArrow, setLeftArrow] = useState("")
  const [stopover, setStopover] = useState("")
  const [rightArrow, setRightArrow] = useState("")
  const [arrival, setArrival] = useState("")

  const makeDirection = (code: string) => {
    switch (code) {
      case "10":
        if (isBatchTx) setStopover(batchStr)
        else setStopover("WEB")
        break
      case "15":
        setStopover("WEB")
        break
      case "11":
        setDeparture(hostCd)
        setLeftArrow("→")
        setStopover("KCG")
        break
      case "12":
        setStopover("KCG")
        setRightArrow("→")
        setArrival(hostCd)
        break
      case "13":
        setArrival(hostCd)
        setRightArrow("←")
        setStopover("KCG")
        break
      case "14":
        setStopover("KCG")
        setLeftArrow("←")
        setDeparture(hostCd)
        break
      case "21":
        setArrival(hostCd)
        setRightArrow("←")
        setStopover("KCG")
        break
      case "22":
        setStopover("KCG")
        setLeftArrow("←")
        setDeparture(hostCd)
        break
      case "23":
        setDeparture(hostCd)
        setLeftArrow("→")
        setStopover("KCG")
        break
      case "24":
        setStopover("KCG")
        setRightArrow("→")
        setArrival(hostCd)
        break

      default:
        break
    }
  }

  useEffect(() => {
    makeDirection(tractSortCd)
  }, [tractSortCd])

  return (
    <div style={{ display: "flex", justifyContent: "space-evenly" }}>
      <p style={{ width: "30px" }}>{departure}</p>
      <p style={{ width: "15px" }}>{leftArrow}</p>
      <p style={{ width: "30px" }}>{stopover}</p>
      <p style={{ width: "15px" }}>{rightArrow}</p>
      <p style={{ width: "30px" }}>{arrival}</p>
    </div>
  )
}

function UOPSTRT001() {
  const $modalHooks = useModal()
  const $proxyHooks = useProxy()
  const $codeHooks = useCode()
  const { params } = useParams()

  // 조회 Form
  const { control, setValue, reset, getValues, validate } = useForm({
    formName: "searchForm",
    defaultValues: {
      trDt: $dateUtils.today(), // 거래일자
      appNm: "", // 연계시스템구분코드
      tlgKndDvsnCd: "", // 거래고유번호
      tlgBizDvsnCd: "", // 취급은행전문번호
      endTlgPrcsTm: "",
      startTlgPrcsTm: "",
    },
  })

  const getTxTime = () => {
    const now = new Date()
    const hours = now.getHours().toString().padStart(2, "0")
    const minutes = now.getMinutes().toString().padStart(2, "0")
    const seconds = now.getSeconds().toString().padStart(2, "0")
    const currentTime = `${hours}${minutes}${seconds}`

    now.setHours(now.getHours() - 1)
    const oneHourBefore = `${now
      .getHours()
      .toString()
      .padStart(2, "0")}${minutes}${seconds}`

    return [currentTime, oneHourBefore]
  }

  // 컴포넌트가 마운트될 때 데이터 조회
  useEffect(() => {
    if (params) {
      const { trcId, trDt, tlgKndTrDvsnCd, hostCd, hostNo } = params

      setValue("trDt", trDt)
      setValue("startTlgPrcsTm", "000000")
      setValue("endTlgPrcsTm", "235959")
      setValue("orgnTractId", trcId)

      selectComKftcLogL(1)
    } else {
      const [endTlgPrcsTm, startTlgPrcsTm] = getTxTime()

      setValue("endTlgPrcsTm", endTlgPrcsTm)
      setValue("startTlgPrcsTm", startTlgPrcsTm)
    }
  }, [params?.trcId, params?.trDt])

  // 상세 form
  const {
    control: control2,
    setValue: setValue2,
    reset: reset2,
    getValues: getValues2,
  } = useForm({
    formName: "detailForm",
    defaultValues: {
      orgnTractId: "", // 원거래ID
    },
  })

  // 9로 시작하는 전문 포맷팅 (하부장님)
  const tlgKndDvsnCdFormattting = (codeValue: string) => {
    const stringValue = codeValue.toString()

    // 조건: 길이가 4자리이고, 첫번째 숫자가 9일 때
    if (stringValue.length === 4 && stringValue.startsWith("9")) {
      return `${codeValue} Format Error`
    }

    return codeValue
  }

  /**
   * 금결원 전문 송수신 로그 목록 조회
   */
  const searchTelegramLogData = (event: any, pgNbr: number) => {
    $eventUtils.setEventContext(event)
    selectComKftcLogL(pgNbr)
    reset2()
    setGridTlgData([])
  }

  // 그리드 config
  const {
    gridConfig,
    gridCount,
    gridData,
    gridRef,
    pagingRef,
    resetGrid,
    setGridConfig,
    setGridCount,
    setGridData,
  } = useGrid({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#sndRcvTm") /* 송수신시간 */,
        field: "logDttm",
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#application",
        ) /* 어플리케이션명 */,
        field: "appNm",
        width: 100,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#hostCd") /* 호스트코드 */,
        field: "hostCd",
        codeValueOption: "name",
        width: 100,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#txDirection") /* 거래방향 */,
        field: "tractSortCd",
        cellRenderer: DirectionCellRenderer,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#bizDvsnCd") /* 업무구분코드 */,
        field: "bizDvsnCd",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tlgKndDvsnCd") /* 전문종별코드 */,
        field: "tlgKndDvsnCd",
        valueFormatter: (param: any) => {
          const codeValue = $codeHooks.codeValue("TLG_KND_DVSN_CD", param.value)
          return tlgKndDvsnCdFormattting(codeValue)
        },
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tlgBizDvsnCd",
        ) /* 전문업무구분코드 */,
        field: "tlgBizDvsnCd",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rspnsCd") /* 응답코드 */,
        field: "respCd",
        width: 100,
      },
      {
        headerName:
          $i18nUtils.trans("SCRNITM#hostMsgNo") /* 호스트 메시지 번호 */,
        field: "hostMsgNo",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#hndlInstCd") /* 처리기관코드 */,
        field: "hndlInstCd",
        width: 100,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#hndlMsgNo") /* 처리메시지번호 */,
        field: "hndlMsgNo",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#kftcMsgNo") /* KFTC메시지번호 */,
        field: "kftcMsgNo",
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tractSortCd",
        ) /* 당타발흐름구분코드 */,
        field: "tractSortCd",
        hide: true,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tractId") /* 거래ID */,
        field: "tractId",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#frstTractId") /* 최초거래ID */,
        field: "frstTractId",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#orgnTractId") /* 원거래ID */,
        field: "orgnTractId",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#usrId") /* 사용자 ID */,
        field: "usrId",
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tlgSndRcvDttm",
        ) /* 전문송수신시간 */,
        field: "tlgSndRcvDttm",
      },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#crltnId") /* 관련ID */,
      //   field: "crltnId",
      // },
    ],
    onRowClicked: useCallback((event: any) => {
      // showBox(true)
      // setDetailData(event.data)
      setValue2("orgnTractId", event.data.orgnTractId)
      getTlgProcessHisDtl(event.data.orgnTractId)
    }, []),
    suppressScrollOnNewData: true, // scroll position 유지 설정
    pagingSetParam: {
      apiFunction: searchTelegramLogData,
    },
  })

  const [totalCnt, setTotalCnt] = useState(0)

  const { gridConfig: gridTlgConfig } = useGrid({
    columnDefs: [
      // {
      //   headerName: $i18nUtils.trans(
      //     "SCRNITM#tlgSndRcvDttm",
      //   ) /* 전문송수신시간 */,
      //   field: "tlgSndRcvDttm",
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#sndRcvTm") /* 송수신시간 */,
        field: "logDttm",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tractId") /* 거래ID */,
        field: "tractId",
      },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#txDirection") /* 로깅위치 */,
      //   field: "msgTp",
      //
      //   hide: true,
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#txDirection") /* 거래방향 */,
        field: "tractSortCd",
        cellRenderer: DirectionCellRenderer,
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tractSortCd",
        ) /* 당타발흐름구분코드 */,
        field: "tractSortCd",
        hide: true,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#hostCd") /* 호스트코드 */,
        field: "hostCd",
        codeValueOption: "name",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#bizDvsnCd") /* 업무구분코드 */,
        field: "bizDvsnCd",
        codeValueOption: "code",
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tlgKndDvsnCd",
        ) /* 전문종별구분코드 */,
        field: "tlgKndDvsnCd",
        codeValueOption: "code",
        // valueFormatter: (param: any) => {
        //   const codeValue = $codeHooks.codeValue("TLG_KND_DVSN_CD", param.value)
        //   return tlgKndDvsnCdFormattting(codeValue)
        // },
      },
      {
        headerName: $i18nUtils.trans(
          "SCRNITM#tlgBizDvsnCd",
        ) /* 전문업무구분코드 */,
        field: "tlgBizDvsnCd",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#fixLenTlg") /* 고정길이전문 */,
        field: "tlgCtt",
        flex: 1,
        cellClass: "t-left",
        cellStyle: {
          whiteSpace: "pre",
        },
      },
    ],
    onRowClicked: useCallback((event: any) => {
      openPopup(event.data, gridTlgRef.current.getAllRows())
    }, []),
  })

  const [gridTlgData, setGridTlgData] = useState<FrwMsg[]>([])

  const gridTlgRef = useRef<any>()

  const [gridTlgTotalCnt, setGridTlgTotalCnt] = useState(0)

  const getTlgProcessHisDtl = (orgnTractId: string) => {
    const param = {
      interfaceCd: "frw",
      interfaceId: "getTlgProcessHisDtl",
      orgnTractId,
      fromDate: "",
      toDate: "",
    }
    $proxyHooks.async(param).then((response: any) => {
      setGridTlgData(() =>
        response.data.msgList.map((msg: FrwMsg) => ({
          ...msg,
        })),
      )
      setGridTlgTotalCnt(response.data.totLen)
    })
  }

  const openPopup = (data: FrwMsg, logList: FrwMsg[]) => {
    console.log("🚀 ~ openPopup ~ logList:", logList)
    const popupInfo: PopupParam = {
      screenId: "POPSTRT-004",
      instance: "pages/popup/bcm/POPSTRT-004",
      params: {
        frwMsg: data,
        logList,
      },
    }
    $modalHooks.openPopup(popupInfo).then((result: any) => {
      // setValue2("relatedTgmMgmtNo", tgmMgmtNo)
    })
  }

  /**
   * 초기화 버튼 클릭
   */
  const initClick = (e: any) => {
    $eventUtils.setEventContext(e)

    reset()
    reset2()
    setGridData([])
    setTotalCnt(0)
    setGridTlgData([])
    setGridTlgTotalCnt(0)
    setGridCount({ totalCnt: 0, currentCnt: 0 })
    pagingRef.current.setPgNbr(1)
    pagingRef.current.setLastPgNbr(1)

    const [endTlgPrcsTm, startTlgPrcsTm] = getTxTime()
    setValue("endTlgPrcsTm", endTlgPrcsTm)
    setValue("startTlgPrcsTm", startTlgPrcsTm)
  }

  const selectComKftcLogL = (pgNbr: number) => {
    validate().then((data: any) => {
      const param = {
        interfaceCd: "frw",
        interfaceId: "selectComKftcLogL",
        trDt: data.trDt,
        appNm: data.appNm,
        hostCd: data.hostCd,
        bizDvsnCd: data.bizDvsnCd,
        tlgKndDvsnCd: data.tlgKndDvsnCd,
        tlgBizDvsnCd: data.tlgBizDvsnCd,
        frstTractId: data.frstTractId,
        orgnTractId: data.orgnTractId,
        fromDate: `${data.trDt}${data.startTlgPrcsTm}`,
        toDate: `${data.trDt}${data.endTlgPrcsTm}`,
        pgNbr, // 페이지 번호
        pgCnt: pagingRef.current?.pgCnt,
      }
      $proxyHooks.async(param).then((response: any) => {
        if (pgNbr > 1) {
          // 스크롤이 전부 내려졌을 경우 데이터 추가

          setGridCount((prev) => ({
            ...prev,
            totalCnt: response.data?.totLen,
            currentCnt: prev.currentCnt + (response.data?.msgList?.length ?? 0),
          }))
          setGridData((prev) => [...prev, ...(response.data?.msgList ?? [])])
        } else {
          // 첫 회 조회
          setGridData(() => response.data?.msgList)
          setGridCount((prevState) => ({
            ...prevState,
            totalCnt: response.data?.totLen,
            currentCnt: response.data?.msgList?.length,
          }))

          pagingRef.current.setPgNbr(pgNbr) // 페이지 넘버 갱신!
          pagingRef.current.setLastPgNbr(response.data?.totLen)
        }
      })
    })
  }

  const { downloadExcel } = useDownloader(gridRef)

  /**
   * EXCEL 다운로드
   */
  const csvClick = (e: any) => {
    downloadExcel(e)
    // $eventUtils.setEventContext(e)

    // gridRef.current.exportCsv(
    //   {
    //     fileName: "test.csv",
    //   },
    //   () => {
    //     $modalHooks.alert({ content: $i18nUtils.trans("MSG#noOutputData") }) // 출력할 DATA 가 없습니다.
    //   },
    // )
  }

  return (
    <Page ctrlEnter={(event: any) => searchTelegramLogData(event, 1)}>
      <div className="row-group">
        {/** Sub Content S */}
        <div className="sub-content search-wrap">
          <h3 className="tit">{$i18nUtils.trans("SCRNITM#srchCndtn")}</h3>
          <ButtonGroup>
            <Button
              name="init"
              i18n={$i18nUtils.trans("SCRNITM#init")}
              color="white btn-lg"
              onClick={initClick}
            >
              초기화
            </Button>
            <Button
              name="search"
              i18n={$i18nUtils.trans("SCRNITM#search")}
              color="green"
              onClick={(event) => searchTelegramLogData(event, 1)}
              // onClick={setDummyGridData}
            >
              조회
            </Button>
          </ButtonGroup>
          <ContentToggle />
          <div className="view-box" data-form="searchForm">
            <CardRow cols={5}>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#txDt")} required>
                  거래일자
                </LabelBox>
                <DatePicker
                  control={control}
                  name="trDt"
                  i18n={$i18nUtils.trans("SCRNITM#txDt")}
                  rules={{
                    required: { value: true },
                  }}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTxTm")} required>
                  거래시간
                </LabelBox>
                <div className="unit timepicker-wrap">
                  <span className="half">
                    <InputIconBox
                      control={control}
                      name="startTlgPrcsTm"
                      i18n={$i18nUtils.trans("SCRNITM#exctStrtTm")}
                      icon="alram"
                      rules={{
                        required: { value: true },
                      }}
                      mask={{
                        mask: "HH:mm:dd",
                        lazy: false,
                        overwrite: "shift",
                        blocks: {
                          HH: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 23,
                          },
                          mm: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 59,
                          },
                          dd: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 59,
                          },
                        },
                      }}
                    />
                  </span>
                  <span className="half">
                    <InputIconBox
                      control={control}
                      name="endTlgPrcsTm"
                      i18n={$i18nUtils.trans("SCRNITM#exctEndTm")}
                      icon="alram"
                      rules={{
                        required: { value: true },
                      }}
                      mask={{
                        mask: "HH:mm:dd",
                        lazy: false,
                        overwrite: "shift",
                        blocks: {
                          HH: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 23,
                          },
                          mm: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 59,
                          },
                          dd: {
                            mask: IMask.MaskedRange,
                            from: 0,
                            to: 59,
                          },
                        },
                      }}
                    />
                  </span>
                </div>
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#frstTractId")}>
                  최초거래ID
                </LabelBox>
                <InputBox
                  control={control}
                  name="frstTractId"
                  i18n={$i18nUtils.trans("SCRNITM#frstTractId")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTractId")}>
                  원거래ID
                </LabelBox>
                <InputBox
                  control={control}
                  name="orgnTractId"
                  i18n={$i18nUtils.trans("SCRNITM#orgnTractId")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#hostCd")}>
                  호스트코드
                </LabelBox>
                <SelectBox
                  control={control}
                  name="hostCd"
                  i18n={$i18nUtils.trans("SCRNITM#hostCd")}
                  listPromise={$codeHooks.getCodeList("HOST_CD")}
                  visibleCode={false}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#bizDvsnCd")}>
                  업무구분코드
                </LabelBox>
                <SelectBox
                  control={control}
                  name="bizDvsnCd"
                  i18n={$i18nUtils.trans("SCRNITM#bizDvsnCd")}
                  listPromise={$codeHooks.getCodeList("BIZ_DVSN_CD")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#appNm")}>
                  어플리케이션명
                </LabelBox>
                <InputBox
                  control={control}
                  name="appNm"
                  i18n={$i18nUtils.trans("SCRNITM#appNm")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#tlgKndDvsnCd")}>
                  전문종별코드
                </LabelBox>
                <InputBox
                  control={control}
                  name="tlgKndDvsnCd"
                  i18n={$i18nUtils.trans("SCRNITM#tlgKndDvsnCd")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#tlgBizDvsnCd")}>
                  전문업무구분
                </LabelBox>
                <InputBox
                  control={control}
                  name="tlgBizDvsnCd"
                  i18n={$i18nUtils.trans("SCRNITM#tlgBizDvsnCd")}
                />
              </CardCol>
            </CardRow>
          </div>
        </div>
        {/** // Sub Content E */}

        {/** Sub Content S */}
        <div className="sub-content">
          <h3 className="tit">
            <LabelBox i18n={$i18nUtils.trans("SCRNITM#tgmTrnsRcvLst")} /> (
            {gridCount?.currentCnt} / {gridCount?.totalCnt}{" "}
            <LabelBox i18n={$i18nUtils.trans("SCRNITM#case")} />)
          </h3>
          <ButtonGroup className="m-right">
            <Button
              name="excel"
              i18n={$i18nUtils.trans("SCRNITM#excel")}
              color="white"
              icon="down"
              onClick={downloadExcel}
            >
              EXCEL
            </Button>
          </ButtonGroup>
          <div className="view-box active">
            <div className="col-01">
              <div className="cmm-table">
                <Grid
                  config={gridConfig}
                  rowData={gridData}
                  height={300}
                  ref={gridRef}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="detailListWrap">
          <div className="sub-content">
            <h3 className="tit">
              {$i18nUtils.trans("SCRNITM#tlgProcessHisDtl")}
            </h3>
            <div className="view-box active">
              <CardRow cols={4}>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTractId")}>
                    원거래ID
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="orgnTractId"
                    i18n={$i18nUtils.trans("SCRNITM#orgnTractId")}
                    disabled
                  />
                </CardCol>
              </CardRow>
            </div>
          </div>
          <div className="sub-content">
            <h3 className="tit">
              <LabelBox i18n={$i18nUtils.trans("SCRNITM#totCnt")} />{" "}
              {gridTlgTotalCnt}
              <LabelBox i18n={$i18nUtils.trans("SCRNITM#case")} />
            </h3>
            <div className="view-box active">
              <div className="col-01">
                <div className="cmm-table">
                  <Grid
                    config={gridTlgConfig}
                    rowData={gridTlgData}
                    height={300}
                    ref={gridTlgRef}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Page>
  )
}

export default UOPSTRT001
