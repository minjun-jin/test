package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 매월분 공동코드 변동분
 * <pre>{@code
 * KftHofCC0012R kftHofCC0012R  = new KftHofCC0012R(); // 매월분 공동코드 변동분
 * kftHofCC0012R.setFileName(""); // 업무구분
 * kftHofCC0012R.setDataType(""); // 데이타구분
 * kftHofCC0012R.setSerialNumber(""); // 일련번호
 * kftHofCC0012R.setDivCode(""); // 구분코드
 * kftHofCC0012R.setBranchCode(""); // 지점코드
 * kftHofCC0012R.setZipCode(""); // 우편번호
 * kftHofCC0012R.setAddress(""); // 주소
 * kftHofCC0012R.setLocalCode(""); // 지역코드
 * kftHofCC0012R.setBankName(""); // 은행명
 * kftHofCC0012R.setBranchName(""); // 지점명
 * kftHofCC0012R.setRegionCode(""); // 광역코드
 * kftHofCC0012R.setApplyDate(""); // 적용일자
 * kftHofCC0012R.setClosedMark(0); // 해지마크
 * kftHofCC0012R.setTellerCode(""); // 자점코드
 * kftHofCC0012R.setPhoneNumber(""); // 전화번호
 * kftHofCC0012R.setFaxNumber(""); // FAX번호
 * kftHofCC0012R.setForeignBranchCode(""); // 외국환점포코드
 * kftHofCC0012R.setClosedBranchManagementCode(""); // 폐쇄관리지점코드
 * kftHofCC0012R.setEmail(""); // email
 * kftHofCC0012R.setAddressTypeCode(""); // 주소구분코드
 * kftHofCC0012R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofCC0012R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String divCode; // 구분코드
	private String branchCode; // 지점코드
	private String zipCode; // 우편번호
	private String address; // 주소
	private String localCode; // 지역코드
	private String bankName; // 은행명
	private String branchName; // 지점명
	private String regionCode; // 광역코드
	private String applyDate; // 적용일자
	private int closedMark; // 해지마크
	private String tellerCode; // 자점코드
	private String phoneNumber; // 전화번호
	private String faxNumber; // FAX번호
	private String foreignBranchCode; // 외국환점포코드
	private String closedBranchManagementCode; // 폐쇄관리지점코드
	private String email; // email
	private String addressTypeCode; // 주소구분코드
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String divCode$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String branchCode$; // 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String zipCode$; // 우편번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String address$; // 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String localCode$; // 지역코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankName$; // 은행명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String branchName$; // 지점명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String regionCode$; // 광역코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String applyDate$; // 적용일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedMark$; // 해지마크
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tellerCode$; // 자점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String faxNumber$; // FAX번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String foreignBranchCode$; // 외국환점포코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedBranchManagementCode$; // 폐쇄관리지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String email$; // email
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String addressTypeCode$; // 주소구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		divCode$ = VOUtils.write(out, divCode, 1); // 구분코드
		branchCode$ = VOUtils.write(out, branchCode, 7); // 지점코드
		zipCode$ = VOUtils.write(out, zipCode, 6); // 우편번호
		address$ = VOUtils.write(out, address, 100, "EUC-KR"); // 주소
		localCode$ = VOUtils.write(out, localCode, 2); // 지역코드
		bankName$ = VOUtils.write(out, bankName, 20, "EUC-KR"); // 은행명
		branchName$ = VOUtils.write(out, branchName, 30, "EUC-KR"); // 지점명
		regionCode$ = VOUtils.write(out, regionCode, 2); // 광역코드
		applyDate$ = VOUtils.write(out, applyDate, 8); // 적용일자
		closedMark$ = VOUtils.write(out, closedMark, 2); // 해지마크
		tellerCode$ = VOUtils.write(out, tellerCode, 6); // 자점코드
		phoneNumber$ = VOUtils.write(out, phoneNumber, 12); // 전화번호
		faxNumber$ = VOUtils.write(out, faxNumber, 12); // FAX번호
		foreignBranchCode$ = VOUtils.write(out, foreignBranchCode, 4); // 외국환점포코드
		closedBranchManagementCode$ = VOUtils.write(out, closedBranchManagementCode, 7); // 폐쇄관리지점코드
		email$ = VOUtils.write(out, email, 40); // email
		addressTypeCode$ = VOUtils.write(out, addressTypeCode, 1); // 주소구분코드
		filler$ = VOUtils.write(out, filler, 25); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		divCode = VOUtils.toString(divCode$ = VOUtils.read(in, 1)); // 구분코드
		branchCode = VOUtils.toString(branchCode$ = VOUtils.read(in, 7)); // 지점코드
		zipCode = VOUtils.toString(zipCode$ = VOUtils.read(in, 6)); // 우편번호
		address = VOUtils.toString(address$ = VOUtils.read(in, 100, "EUC-KR")); // 주소
		localCode = VOUtils.toString(localCode$ = VOUtils.read(in, 2)); // 지역코드
		bankName = VOUtils.toString(bankName$ = VOUtils.read(in, 20, "EUC-KR")); // 은행명
		branchName = VOUtils.toString(branchName$ = VOUtils.read(in, 30, "EUC-KR")); // 지점명
		regionCode = VOUtils.toString(regionCode$ = VOUtils.read(in, 2)); // 광역코드
		applyDate = VOUtils.toString(applyDate$ = VOUtils.read(in, 8)); // 적용일자
		closedMark = VOUtils.toInt(closedMark$ = VOUtils.read(in, 2)); // 해지마크
		tellerCode = VOUtils.toString(tellerCode$ = VOUtils.read(in, 6)); // 자점코드
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 12)); // 전화번호
		faxNumber = VOUtils.toString(faxNumber$ = VOUtils.read(in, 12)); // FAX번호
		foreignBranchCode = VOUtils.toString(foreignBranchCode$ = VOUtils.read(in, 4)); // 외국환점포코드
		closedBranchManagementCode = VOUtils.toString(closedBranchManagementCode$ = VOUtils.read(in, 7)); // 폐쇄관리지점코드
		email = VOUtils.toString(email$ = VOUtils.read(in, 40)); // email
		addressTypeCode = VOUtils.toString(addressTypeCode$ = VOUtils.read(in, 1)); // 주소구분코드
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 25)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", divCode=").append(divCode).append(System.lineSeparator()); // 구분코드
		sb.append(", branchCode=").append(branchCode).append(System.lineSeparator()); // 지점코드
		sb.append(", zipCode=").append(zipCode).append(System.lineSeparator()); // 우편번호
		sb.append(", address=").append(address).append(System.lineSeparator()); // 주소
		sb.append(", localCode=").append(localCode).append(System.lineSeparator()); // 지역코드
		sb.append(", bankName=").append(bankName).append(System.lineSeparator()); // 은행명
		sb.append(", branchName=").append(branchName).append(System.lineSeparator()); // 지점명
		sb.append(", regionCode=").append(regionCode).append(System.lineSeparator()); // 광역코드
		sb.append(", applyDate=").append(applyDate).append(System.lineSeparator()); // 적용일자
		sb.append(", closedMark=").append(closedMark).append(System.lineSeparator()); // 해지마크
		sb.append(", tellerCode=").append(tellerCode).append(System.lineSeparator()); // 자점코드
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호
		sb.append(", faxNumber=").append(faxNumber).append(System.lineSeparator()); // FAX번호
		sb.append(", foreignBranchCode=").append(foreignBranchCode).append(System.lineSeparator()); // 외국환점포코드
		sb.append(", closedBranchManagementCode=").append(closedBranchManagementCode).append(System.lineSeparator()); // 폐쇄관리지점코드
		sb.append(", email=").append(email).append(System.lineSeparator()); // email
		sb.append(", addressTypeCode=").append(addressTypeCode).append(System.lineSeparator()); // 주소구분코드
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "divCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "branchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "zipCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "address", "fldLen", "100", "defltVal", ""),
			Map.of("fld", "localCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "bankName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "branchName", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "regionCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "applyDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "closedMark", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "tellerCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "faxNumber", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "foreignBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "closedBranchManagementCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "email", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "addressTypeCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "25", "defltVal", "")
		);
	}

}
