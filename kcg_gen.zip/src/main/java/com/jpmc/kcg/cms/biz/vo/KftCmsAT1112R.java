package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자동납부 등록정보 신규/해지 내역(은행공동CMS)
 * <pre>{@code
 * KftCmsAT1112R kftCmsAT1112R  = new KftCmsAT1112R(); // 자동납부 등록정보 신규/해지 내역(은행공동CMS)
 * kftCmsAT1112R.setFileName("AT1112"); // 업무구분
 * kftCmsAT1112R.setDataType("22"); // 데이타구분
 * kftCmsAT1112R.setSerialNumber("0000000"); // 일련번호
 * kftCmsAT1112R.setProcessingType("0000000"); // 처리구분
 * kftCmsAT1112R.setPaymentAccountNo("0000000"); // 출금계좌번호
 * kftCmsAT1112R.setInstitutionCode("057"); // 기관코드
 * kftCmsAT1112R.setPayerNumber(""); // 납부자번호
 * kftCmsAT1112R.setFiller2(""); // FILLER
 * kftCmsAT1112R.setAccountHolderID(""); // 예금주실명번호
 * kftCmsAT1112R.setAccountHolderName(""); // 계좌예금주명
 * kftCmsAT1112R.setSubInstitutionCode(""); // 하위이용기관코드
 * kftCmsAT1112R.setNewClosedStatus(""); // 신규/해지접수구분
 * kftCmsAT1112R.setNewClosedReason(""); // 신규/해지요청사유
 * kftCmsAT1112R.setNewClosedRequestDate(""); // 신규/해지신청일
 * kftCmsAT1112R.setNewClosedEffectiveDate(""); // 신규/해지적용일
 * kftCmsAT1112R.setNewClosedOffice(""); // 등록/해지사무소
 * kftCmsAT1112R.setBankCustomField(""); // 금융회사임의필드
 * kftCmsAT1112R.setLedgerChangeDate(""); // 원장변경일
 * kftCmsAT1112R.setAdditionalIDInfo(""); // 부가식별정보
 * kftCmsAT1112R.setFiller3(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsAT1112R implements Vo {

	private String fileName = "AT1112"; // 업무구분
	private String dataType = "22"; // 데이타구분
	private String serialNumber = "0000000"; // 일련번호
	private String processingType = "0000000"; // 처리구분
	private String paymentAccountNo = "0000000"; // 출금계좌번호
	private String institutionCode = "057"; // 기관코드
	private String payerNumber; // 납부자번호
	private String filler2; // FILLER
	private String accountHolderID; // 예금주실명번호
	private String accountHolderName; // 계좌예금주명
	private String subInstitutionCode; // 하위이용기관코드
	private String newClosedStatus; // 신규/해지접수구분
	private String newClosedReason; // 신규/해지요청사유
	private String newClosedRequestDate; // 신규/해지신청일
	private String newClosedEffectiveDate; // 신규/해지적용일
	private String newClosedOffice; // 등록/해지사무소
	private String bankCustomField; // 금융회사임의필드
	private String ledgerChangeDate; // 원장변경일
	private String additionalIDInfo; // 부가식별정보
	private String filler3; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingType$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentAccountNo$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumber$; // 납부자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderID$; // 예금주실명번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderName$; // 계좌예금주명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String subInstitutionCode$; // 하위이용기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedStatus$; // 신규/해지접수구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedReason$; // 신규/해지요청사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedRequestDate$; // 신규/해지신청일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedEffectiveDate$; // 신규/해지적용일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedOffice$; // 등록/해지사무소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCustomField$; // 금융회사임의필드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String ledgerChangeDate$; // 원장변경일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String additionalIDInfo$; // 부가식별정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		processingType$ = VOUtils.write(out, processingType, 2); // 처리구분
		paymentAccountNo$ = VOUtils.write(out, paymentAccountNo, 20); // 출금계좌번호
		institutionCode$ = VOUtils.write(out, institutionCode, 20); // 기관코드
		payerNumber$ = VOUtils.write(out, payerNumber, 30); // 납부자번호
		filler2$ = VOUtils.write(out, filler2, 1); // FILLER
		accountHolderID$ = VOUtils.write(out, accountHolderID, 13); // 예금주실명번호
		accountHolderName$ = VOUtils.write(out, accountHolderName, 20); // 계좌예금주명
		subInstitutionCode$ = VOUtils.write(out, subInstitutionCode, 10); // 하위이용기관코드
		newClosedStatus$ = VOUtils.write(out, newClosedStatus, 1); // 신규/해지접수구분
		newClosedReason$ = VOUtils.write(out, newClosedReason, 1); // 신규/해지요청사유
		newClosedRequestDate$ = VOUtils.write(out, newClosedRequestDate, 8); // 신규/해지신청일
		newClosedEffectiveDate$ = VOUtils.write(out, newClosedEffectiveDate, 8); // 신규/해지적용일
		newClosedOffice$ = VOUtils.write(out, newClosedOffice, 7); // 등록/해지사무소
		bankCustomField$ = VOUtils.write(out, bankCustomField, 10); // 금융회사임의필드
		ledgerChangeDate$ = VOUtils.write(out, ledgerChangeDate, 8); // 원장변경일
		additionalIDInfo$ = VOUtils.write(out, additionalIDInfo, 30); // 부가식별정보
		filler3$ = VOUtils.write(out, filler3, 196); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		processingType = VOUtils.toString(processingType$ = VOUtils.read(in, 2)); // 처리구분
		paymentAccountNo = VOUtils.toString(paymentAccountNo$ = VOUtils.read(in, 20)); // 출금계좌번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 20)); // 기관코드
		payerNumber = VOUtils.toString(payerNumber$ = VOUtils.read(in, 30)); // 납부자번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 1)); // FILLER
		accountHolderID = VOUtils.toString(accountHolderID$ = VOUtils.read(in, 13)); // 예금주실명번호
		accountHolderName = VOUtils.toString(accountHolderName$ = VOUtils.read(in, 20)); // 계좌예금주명
		subInstitutionCode = VOUtils.toString(subInstitutionCode$ = VOUtils.read(in, 10)); // 하위이용기관코드
		newClosedStatus = VOUtils.toString(newClosedStatus$ = VOUtils.read(in, 1)); // 신규/해지접수구분
		newClosedReason = VOUtils.toString(newClosedReason$ = VOUtils.read(in, 1)); // 신규/해지요청사유
		newClosedRequestDate = VOUtils.toString(newClosedRequestDate$ = VOUtils.read(in, 8)); // 신규/해지신청일
		newClosedEffectiveDate = VOUtils.toString(newClosedEffectiveDate$ = VOUtils.read(in, 8)); // 신규/해지적용일
		newClosedOffice = VOUtils.toString(newClosedOffice$ = VOUtils.read(in, 7)); // 등록/해지사무소
		bankCustomField = VOUtils.toString(bankCustomField$ = VOUtils.read(in, 10)); // 금융회사임의필드
		ledgerChangeDate = VOUtils.toString(ledgerChangeDate$ = VOUtils.read(in, 8)); // 원장변경일
		additionalIDInfo = VOUtils.toString(additionalIDInfo$ = VOUtils.read(in, 30)); // 부가식별정보
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 196)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", processingType=").append(processingType).append(System.lineSeparator()); // 처리구분
		sb.append(", paymentAccountNo=").append(paymentAccountNo).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", payerNumber=").append(payerNumber).append(System.lineSeparator()); // 납부자번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", accountHolderID=").append(accountHolderID).append(System.lineSeparator()); // 예금주실명번호
		sb.append(", accountHolderName=").append(accountHolderName).append(System.lineSeparator()); // 계좌예금주명
		sb.append(", subInstitutionCode=").append(subInstitutionCode).append(System.lineSeparator()); // 하위이용기관코드
		sb.append(", newClosedStatus=").append(newClosedStatus).append(System.lineSeparator()); // 신규/해지접수구분
		sb.append(", newClosedReason=").append(newClosedReason).append(System.lineSeparator()); // 신규/해지요청사유
		sb.append(", newClosedRequestDate=").append(newClosedRequestDate).append(System.lineSeparator()); // 신규/해지신청일
		sb.append(", newClosedEffectiveDate=").append(newClosedEffectiveDate).append(System.lineSeparator()); // 신규/해지적용일
		sb.append(", newClosedOffice=").append(newClosedOffice).append(System.lineSeparator()); // 등록/해지사무소
		sb.append(", bankCustomField=").append(bankCustomField).append(System.lineSeparator()); // 금융회사임의필드
		sb.append(", ledgerChangeDate=").append(ledgerChangeDate).append(System.lineSeparator()); // 원장변경일
		sb.append(", additionalIDInfo=").append(additionalIDInfo).append(System.lineSeparator()); // 부가식별정보
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", "AT1112"),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", "22"),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "processingType", "fldLen", "2", "defltVal", "0000000"),
			Map.of("fld", "paymentAccountNo", "fldLen", "20", "defltVal", "0000000"),
			Map.of("fld", "institutionCode", "fldLen", "20", "defltVal", "057"),
			Map.of("fld", "payerNumber", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "accountHolderID", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accountHolderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "subInstitutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "newClosedStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "newClosedReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "newClosedRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "newClosedEffectiveDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "newClosedOffice", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCustomField", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "ledgerChangeDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "additionalIDInfo", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "196", "defltVal", "")
		);
	}

}
