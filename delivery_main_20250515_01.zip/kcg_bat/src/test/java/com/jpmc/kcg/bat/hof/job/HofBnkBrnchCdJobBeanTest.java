package com.jpmc.kcg.bat.hof.job;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.bat.BatJobTestSupporter;
import com.jpmc.kcg.bat.com.biz.ComFileTractLBean;
import com.jpmc.kcg.bat.hof.dao.BatHofSndRcvFileLDao;
import com.jpmc.kcg.com.dao.ComBnkBrnchMMapper;
import com.jpmc.kcg.com.dto.ComBnkBrnchM;
import com.jpmc.kcg.com.dto.ComFileTractL;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.hof.biz.vo.KftHofCC0011R;
import com.jpmc.kcg.hof.dto.HofSndRcvFileL;

import lombok.extern.slf4j.Slf4j;


@Slf4j
@ExtendWith(MockitoExtension.class)
public class HofBnkBrnchCdJobBeanTest extends BatJobTestSupporter {
	
    @InjectMocks
    private HofBnkBrnchCdJobBean hofBnkBrnchCdJobBean;

    @Mock
    private ComBnkBrnchMMapper comBnkBrnchMMapper;

    @Mock
    private BatHofSndRcvFileLDao batHofSndRcvFileLDao;
    
    @Mock
    private ComFileTractLBean comFileTractLBean;
    
    @Mock
    private BatContext batContext;
    
	private static MockedStatic<VOUtils> voUtils;
	private static KftHofCC0011R kftHofCC0011R;
	

    @BeforeEach
    public void setUp() {
		voUtils = mockStatic(VOUtils.class);
		kftHofCC0011R = new KftHofCC0011R();
        kftHofCC0011R = new KftHofCC0011R();
        kftHofCC0011R.setBranchCode("123456789");
        kftHofCC0011R.setDivCode("*");
        kftHofCC0011R.setZipCode("00000");
        kftHofCC0011R.setAddress("Test Address");
        kftHofCC0011R.setLocalCode("LOC");
        kftHofCC0011R.setBranchName("Test Branch");
        kftHofCC0011R.setRegionCode("RCODE");
        kftHofCC0011R.setTellerCode("T001");
        kftHofCC0011R.setPhoneNumber("1234567890");
        kftHofCC0011R.setFaxNumber("0987654321");
        kftHofCC0011R.setEmail("test@example.com");
        kftHofCC0011R.setAddressTypeCode("ATC");
        kftHofCC0011R.setApplyDate("20231028");
        kftHofCC0011R.setForeignBranchCode("FBC");
        kftHofCC0011R.setClosedBranchManagementCode("CBC");
		voUtils.when(() -> VOUtils.toVo(Mockito.nullable(String.class), Mockito.eq(KftHofCC0011R.class))).thenReturn(kftHofCC0011R);
        
    }

    @Test
    public void testExecuteInternal() {
    	
        Map<String, Object> param = new HashMap<String, Object>();
        param.put("fileNm", "CC0012");
		setParamMap(param);
    	
    	List<HofSndRcvFileL> tlgCttList = new ArrayList<HofSndRcvFileL>();
    	HofSndRcvFileL hofSndRcvFileL = new HofSndRcvFileL();
        hofSndRcvFileL.setTlgCtt("mockedContent");
        tlgCttList.add(hofSndRcvFileL);
        
        ComBnkBrnchM comBnkBrnchM = new ComBnkBrnchM();
        comBnkBrnchM.setAddr("a");
    	
        // Mock 리턴값 설정
        when(batHofSndRcvFileLDao.selectHofSndRcvFileL(any())).thenReturn(tlgCttList);
        when(comBnkBrnchMMapper.selectByPrimaryKey(anyString(), anyString(), anyString())).thenReturn(comBnkBrnchM);
        when(comFileTractLBean.selectByPK(anyString(), anyString())).thenReturn(new ComFileTractL());
        
        execute(hofBnkBrnchCdJobBean);	

        // selectHofSndRcvFileL 호출 확인
        verify(batHofSndRcvFileLDao, times(1)).selectHofSndRcvFileL(any(HofSndRcvFileL.class));

        // 데이터 재적재 프로세스 확인
        verify(comBnkBrnchMMapper, times(1)).insert(any(ComBnkBrnchM.class));
        
        voUtils.close();
    }

	
}
