package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 일별 거래집계
 * <pre>{@code
 * KftEntES1108R kftEntES1108R  = new KftEntES1108R(); // 일별 거래집계
 * kftEntES1108R.setFileName(""); // 업무구분
 * kftEntES1108R.setDataType(""); // 데이터구분
 * kftEntES1108R.setSerialNumber(""); // 일련번호
 * kftEntES1108R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1108R.setBankCode(""); // 은행코드
 * kftEntES1108R.setEnoteType(""); // 어음종류
 * kftEntES1108R.setTransactionCode(""); // 거래구분
 * kftEntES1108R.setContentType(""); // 내용구분
 * kftEntES1108R.setCount(0L); // 건수
 * kftEntES1108R.setAmount(0L); // 금액
 * kftEntES1108R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1108R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String enoteType; // 어음종류
	private String transactionCode; // 거래구분
	private String contentType; // 내용구분
	private long count; // 건수
	private long amount; // 금액
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String contentType$; // 내용구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String count$; // 건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String amount$; // 금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		transactionCode$ = VOUtils.write(out, transactionCode, 1); // 거래구분
		contentType$ = VOUtils.write(out, contentType, 2); // 내용구분
		count$ = VOUtils.write(out, count, 10); // 건수
		amount$ = VOUtils.write(out, amount, 15); // 금액
		filler2$ = VOUtils.write(out, filler2, 12); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 1)); // 거래구분
		contentType = VOUtils.toString(contentType$ = VOUtils.read(in, 2)); // 내용구분
		count = VOUtils.toLong(count$ = VOUtils.read(in, 10)); // 건수
		amount = VOUtils.toLong(amount$ = VOUtils.read(in, 15)); // 금액
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 12)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분
		sb.append(", contentType=").append(contentType).append(System.lineSeparator()); // 내용구분
		sb.append(", count=").append(count).append(System.lineSeparator()); // 건수
		sb.append(", amount=").append(amount).append(System.lineSeparator()); // 금액
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "contentType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "count", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "amount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "12", "defltVal", "")
		);
	}

}
