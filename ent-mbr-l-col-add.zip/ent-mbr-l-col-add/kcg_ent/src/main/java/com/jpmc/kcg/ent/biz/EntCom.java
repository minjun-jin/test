package com.jpmc.kcg.ent.biz;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComBnkStsMMapper;
import com.jpmc.kcg.com.dto.ComBnkStsM;
import com.jpmc.kcg.com.enums.*;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.CqeEntComHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntComHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntMngHdr;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dao.*;
import com.jpmc.kcg.ent.dto.*;
import com.jpmc.kcg.ent.enums.EntRespCdEnum;
import com.jpmc.kcg.ent.enums.EntTlgKndDvsnCdEnum;
import com.jpmc.kcg.ent.enums.NotiTargetEnum;
import com.jpmc.kcg.ent.enums.SttlPrcsDvsnCdEnum;
import com.jpmc.kcg.ent.util.AlarmMessageBuilder;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwVault;
import com.jpmc.kcg.frw.Vo;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.Map;
import java.util.Optional;
import java.util.function.BiConsumer;
import java.util.function.Function;

@Slf4j
@Component
@RequiredArgsConstructor
public class EntCom {

    public static final int RESIDENT_ID_LENGTH = 13;
    private static final int RESIDENT_ID_CUT_LENGTH = 7; // 잘라낼 길이
    private static final int ALARM_MESSAGE_TEMPLATE_ID = 13; // 잘라낼 길이

    private final BizCom bizCom;
    private final ComPshMsgBean comPshMsgBean;
    private final FrwContext frwContext;
    private final FrwVault frwVault;
    private final EntEnoteLMapper entEnoteLMapper;
    private final EntGrntMgmtMMapper entGrntMgmtMMapper;
    private final EntGrntMgmtMDao entGrntMgmtMDao;
    private final EntEnoteMDao entEnoteMDao;
    private final EntEnoteMMapper entEnoteMMapper;
    private final EntSttlMgmtMDao entSttlMgmtMDao;
    private final EntEnoteLDao entEnoteLDao;
    private final EntEndrMDao entEndrMDao;
    private final EntEndrMMapper entEndrMMapper;
    private final EntSttlMgmtMMapper entSttlMgmtMMapper;
    private final EntSttlMgmtLDao entSttlMgmtLDao;
    private final EntRcrsMgmtLDao entRcrsMgmtLDao;
    private final EntRcrsMgmtLMapper entRcrsMgmtLMapper;
    private final EntMbrLDao entMbrLDao;
    private final EntCqeInqyLDao entCqeInqyLDao;
    private final EntSttlMgmtLMapper entSttlMgmtLMapper;
    private final ReleaseValidation releaseValidation;
    private final ComBnkStsMMapper comBnkStsMMapper;
    private final EntMbrLMapper entMbrLMapper;

    //////////////////////////////////////////////////////// 입력값 검증 ////////////////////////////////////////////////////////

    /**
     * input validation
     */
    public boolean nullCheckCqeInput(Vo in) {
        log.debug("----------------- VO : -----------------  {} ", in);
        /*
          입력값 검증
         */
        int fieldNo = in.validate();
        log.debug("----------------- field validation : -----------------  {} ", fieldNo);

        if (fieldNo > 0) {
            throw new InternalResponseException(EntConst.K99, "INVALID FORMAT:" + String.valueOf(fieldNo + 1));
        }
        return true;
    }

    /**
     * input validation
     */
    public boolean nullCheckKftInput(Vo in) {
        log.debug("----------------- VO : -----------------  {} ", in);
        /*
          입력값 검증
         */
        int fieldNo = in.validate();
        log.debug("----------------- field validation : -----------------  {} ", fieldNo);

        if (fieldNo > 0) {
            throw new InternalResponseException(EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), String.valueOf(fieldNo));
        }

        return true;
    }

    /**
     * input validation (Sending to KFTC)
     */
    public boolean validateOutboundInput(Vo in) {

        nullCheckCqeInput(in);    // null
        validateServiceHour();  // 서비스시간
        validateBankConnectivityStatusForOutbound(ComConst.JPMC_BANK_CD); // 은행상태

        return true;
    }

    public boolean validateInboundInput(KftEntComHdr in) {
        nullCheckKftInput(in);
        validateInboundHeader(in);
        validateBankConnectivityStatusForInbound(ComConst.KFTC_BANK_CD); // 은행상태 확인
        validateBankConnectivityStatusForInbound(ComConst.JPMC_BANK_CD); // 은행상태 확인

        return true;
    }

    public boolean validateInboundInput(KftEntMngHdr in) {
        nullCheckKftInput(in);
        validateInboundHeader(in);

        return true;
    }

    /**
     * Bank Connectivity Status validation For Outbound
     */
    public boolean validateBankConnectivityStatusForOutbound(String bnkCd) {

        /*
         * 개설은행상태 확인
         */
        String bnkStsCd = bizCom.getConnectivtyValidation(bnkCd, BizDvsnCdEnum.ENT.getValue(), ComConst.KFT);

        if (!StringUtils.equals(ComConst.NORMAL_RESPONSE_CODE, bnkStsCd)) {
            throw new InternalResponseException(EntConst.K99);
        }

        return true;
    }

    /**
     * Bank Connectivity Status validation For Inbound
     */
    public boolean validateBankConnectivityStatusForInbound(String bnkCd) {

        /*
         * 은행상태 확인
         */
        ComBnkStsM comBnkStsM = comBnkStsMMapper.selectByPrimaryKey(DateUtils.getISODate(), BizDvsnCdEnum.ENT.getValue(), bnkCd, "000000");
        BankStatusEnum bankStatusEnum = BankStatusEnum.findByCd(comBnkStsM.getBnkStsCd());

        if (bankStatusEnum == null) {
            // 099
            throw new InternalResponseException(EntRespCdEnum.OTHER_BANK_INQUIRY.getCode(), "BANK/KFTC STATUS CHECK FAILED");
        }

        switch (bankStatusEnum) {
            case START_V: // 개시
            case EXTD_V: { // 장운영연장
                return true;
            }
            case INIT_V: { // 미개시
                // 022
                throw new InternalResponseException(EntRespCdEnum.TRANSACTION_BEFORE_INITIATION.getCode(), "BANK/KFTC STATUS CHECK FAILED");
            }
            case BUSY_V: { // 망상태장애
                // KFTC - 018
                if (BankCodeEnum.KFTC.getBnkCode().equals(bnkCd)) {
                    throw new InternalResponseException(EntRespCdEnum.SYSTEM_ERROR_AT_CENTER.getCode(), "BANK/KFTC STATUS CHECK FAILED");
                }
                // JPMC - 097
                else if (BankCodeEnum.JPMC.getBnkCode().equals(bnkCd)) {
                    throw new InternalResponseException(EntRespCdEnum.BANK_FAILURE.getCode(), "BANK/KFTC STATUS CHECK FAILED");
                }
            }
            case PFNS_V: { // 종료예고
                // 909
                throw new InternalResponseException(EntRespCdEnum.CANNOT_TRANSACT_DUE_TO_TERMINATION_NOTICE.getCode(), "BANK/KFTC STATUS CHECK FAILED");
            }
            case FNSH_V: { // 종료
                // 910
                throw new InternalResponseException(EntRespCdEnum.CANNOT_TRANSACT_DUE_TO_TERMINATION.getCode(), "BANK/KFTC STATUS CHECK FAILED");
            }
            default: {
                return true;
            }
        }

    }

    /**
     * Service hour validation for ent outbound operations (Validating against service hours).
     */
    public void validateServiceHour() {
        // 현재 시간을 기반으로 서비스 시간 코드 가져오기
        String svsHourCd = this.releaseValidation.getReleaseServiceHour(
                SvcTmDvsnCdEnum.ENT_OUTBOUND_SERVICE_HOUR.getValue(),
                LocalDateTime.now()
        );

        // 서비스 시간 코드가 SERVICE_HOUR_BEFORE인 경우 예외 발생
        if (SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode().equals(svsHourCd)) {
            throw new InternalResponseException(EntConst.K99, "BEFORE SERVICE HOUR");
        }
        // 서비스 시간 코드가 SERVICE_HOUR_AFTER인 경우 예외 발생
        else if (SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode().equals(svsHourCd)) {
            throw new InternalResponseException(EntConst.K99, "AFTER SERVICE HOUR");
        }
    }

    /**
     * Bank Connectivity Status validation for screen (Sending to KFTC)
     */
    public boolean validateBankConnectivityStatusForScreen() {

        /*
         * 개설은행상태 확인
         */
        String bnkStsCd = bizCom.getConnectivtyValidation(ComConst.JPMC_BANK_CD, BizDvsnCdEnum.ENT.getValue(), ComConst.KFT);

        if (!StringUtils.equals(ComConst.NORMAL_RESPONSE_CODE, bnkStsCd)) {
            throw new BusinessException("MCMNI99998");
        }

        return true;
    }

    /**
     * header validation (Receiving from KFTC)
     *
     * @param - KftEntComHdr
     */
    public boolean validateReceivingHeader(KftEntComHdr header) {
        // 시스템 ID 확인
        if (!EntConst.SYS_ID.equals(header.getSystemId())) {
            throw new InternalResponseException(
                    EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "001"
            );
        }

        // 은행 코드 확인
        if (!ComConst.JPMC_BANK_CD.equals(header.getBnkCd())) {
            throw new InternalResponseException(
                    EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "002"
            );
        }

        // 메시지 타입 확인: RESPONSE 또는 REQUEST 에러 코드여야 함
        String msgType = header.getMessageType();
        if (!EntTlgKndDvsnCdEnum.RESPONSE.getCode().equals(msgType) &&
                !EntTlgKndDvsnCdEnum.REQUEST.getErrorCode().equals(msgType)) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "003"
            );
        }

        // 거래코드가 숫자로 구성되어 있는지 확인
        if (!StringUtils.isNumeric(header.getTransactionCode())) {
            throw new InternalResponseException(
                    EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "004"
            );
        }

        // 상태 코드가 숫자로 구성되어 있는지 확인
        if (!StringUtils.isNumeric(header.getStatus())) {
            throw new InternalResponseException(
                    EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "008"
            );
        }

        // 메시지 전송 시간이 null이거나 공백이면 안 됨
        if (header.getMessageSendTime() == null ||
                StringUtils.isBlank(header.getMessageSendTime().toString())) {
            throw new InternalResponseException(
                    EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "011"
            );
        }

        return true;
    }

    /**
     * header validation (Inbound from KFTC) : 타발
     *
     * @param - KftEntComHdr
     */
    public boolean validateInboundHeader(KftEntComHdr header) {
        // 시스템 ID 검증
        if (!EntConst.SYS_ID.equals(header.getSystemId())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "001"
            );
        }

        // 메시지 타입이 요청 코드(Request)여야 함 (isRequestCd 메서드를 통해 검증)
        if (!EntTlgKndDvsnCdEnum.isRequestCd(header.getMessageType())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "003"
            );
        }

        // 거래코드가 숫자인지 검증
        if (!StringUtils.isNumeric(header.getTransactionCode())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "004"
            );
        }

        // 상태 코드가 숫자인지 검증
        if (!StringUtils.isNumeric(header.getStatus())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "008"
            );
        }

        // 메시지 전송 시간이 null이거나 공백이면 안 됨
        if (header.getMessageSendTime() == null ||
                StringUtils.isBlank(header.getMessageSendTime().toString())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "011"
            );
        }

        return true;
    }


    public boolean validateInboundHeader(KftEntMngHdr header) {
        // 시스템 ID 검증
        if (!EntConst.SYS_ID.equals(header.getSystemId())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "001"
            );
        }

        // 유지보수용 요청 메시지 타입인지 확인 (isMaintenanceRequestCd 사용)
        if (!EntTlgKndDvsnCdEnum.isMaintenanceRequestCd(header.getMessageType())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "003"
            );
        }

        // 거래코드가 숫자로 구성되어 있는지 검증
        if (!StringUtils.isNumeric(header.getTransactionCode())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "004"
            );
        }

        // 상태 코드가 숫자로 구성되어 있는지 검증
        if (!StringUtils.isNumeric(header.getStatus())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "008"
            );
        }

        // 메시지 전송 시간이 null이거나 공백이면 안 됨
        if (header.getMessageSendTime() == null ||
                StringUtils.isBlank(header.getMessageSendTime().toString())) {
            throw new InternalResponseException(
                    EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR.getCode(), "011"
            );
        }

        return true;
    }

    //////////////////////////////////////////////////////// handle error ////////////////////////////////////////////////////////
    /**
     * 타발요청서비스 handleError 메서드에서 사용하는 set ErrorVo (Send to KFTC)
     */
    public <I extends KftEntComHdr, O extends KftEntComHdr> void setInboundRequestErrorVo(
            I in, O sendVo, Throwable t, String sendReceiveFlag) {
        String respCd;
        String respMsg = "";
        // 기본적으로 msgTp는 RESPONSE 코드로 설정함
        String msgTp = EntTlgKndDvsnCdEnum.RESPONSE.getCode();
        String status = "";

        if (t instanceof InternalResponseException e) {
            respCd = e.getRespCd();
            respMsg = e.getRespMessage();

            if (StringUtils.isBlank(respCd)) {
                // 응답 코드가 없을 경우 SYSTEM_ERROR로 설정
                respCd = EntConst.SYSTEM_ERROR;
            } else if (EntRespCdEnum.fromCode(respCd) == EntRespCdEnum.SYSTEM_TYPE_CODE_ERROR) {
                // 시스템 구분 코드 오류인 경우, 원래 메시지 타입에 따른 오류 코드로 재설정하고,
                // 상세 메시지를 status에 할당
                msgTp = EntTlgKndDvsnCdEnum.getErrorCodeByMessageType(in.getMessageType());
                status = respMsg;
            }
            // 그 외의 경우 msgTp는 기본값(RESPONSE 코드) 그대로 유지됨
        } else {
            respCd = EntConst.SYSTEM_ERROR;
            log.info(Arrays.toString(t.getStackTrace()));
        }

        sendVo.setSendReceiveFlag(sendReceiveFlag);
        sendVo.setMessageType(msgTp);
        sendVo.setResponseCode1(respCd);
        sendVo.setStatus(status);

        /*
         * 알람 메세지 발송
         * 조건: 내부 Exception 발생
         */
        sendAlarm(AlarmMessageBuilder.buildInboundRequestError(respCd, respMsg));
        log.debug("Error Inbound Request respCd: {},  respMsg: {}", respCd, respMsg);
    }

    /**
     * 당발요청서비스 handleError 메서드에서 사용하는 set ErrorVo (Send to CQE)
     */
    public <I extends CqeEntComHdr, O extends CqeEntComHdr> void setOutboundRequestErrorVo(
            I in, O sendVo, Throwable t) {
        String respCd = "";
        String respMsg = "";

        if (t instanceof InternalResponseException e) {
            respCd = e.getRespCd();
            respMsg = e.getRespMessage();
        } else {
            respCd = EntConst.K99;
            respMsg = "ETC ERR";
            log.info(Arrays.toString(t.getStackTrace()));
        }

        sendVo.setResponseCode1(respCd);
        sendVo.setResponseCode2(respMsg);

        /*
         * 알람 메세지 발송
         * 조건: 내부 Exception 발생
         */
        sendAlarm(AlarmMessageBuilder.buildOutboundRequestError(respCd, respMsg));
        log.debug("Error Outbound Request respCd: {}, respMsg: {}", respCd, respMsg);
    }

    /**
     * 당발응답서비스 handleError 메서드에서 사용하는 set ErrorVo (Send to KFTC)
     */
    public <O extends KftEntComHdr> void setOutboundResponseErrorVo(O sendVo, Throwable t) {
        String respCd = "";
        String respMsg = "";

        if (t instanceof InternalResponseException e) {
            // 입력 메시지 포맷 에러(9210)인 경우
            if (StringUtils.equals(EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), e.getRespCd())) {
                respCd = e.getRespCd();
                respMsg = e.getRespMessage();

                sendVo.setMessageType(EntTlgKndDvsnCdEnum.RESPONSE.getErrorCode()); // 9210 에러 타입 지정
                sendVo.setResponseCode1(respCd);
                sendVo.setStatus(respMsg);
            }
        } else {
            respMsg = "ETC ERR";
            log.info(Arrays.toString(t.getStackTrace()));
        }

        /*
         * 알람 메세지 발송
         * 조건: 내부 Exception 발생
         */
        sendAlarm(AlarmMessageBuilder.buildOutboundResponseError(respCd, respMsg));
        log.debug("Error Outbound Response respCd: {}, respMsg: {}", respCd, respMsg);
    }

    //////////////////////////////////////////////////////// table update ////////////////////////////////////////////////////////

    /**
     * 원거래조회
     *
     * @param msgTracNo
     * @param traxIdNo
     * @return
     */
    public EntEnoteL getOriginalEntEnoteL(String msgTracNo, String traxIdNo) {

        EntEnoteL entEnoteL = new EntEnoteL();
        entEnoteL.setTrDt(DateUtils.getISODate());
        entEnoteL.setEntTlgTrceNo(msgTracNo);
        entEnoteL.setTrUnqNo(traxIdNo);

        log.debug("----------------- getOriginalEntEnoteL EntEnoteL -----------------: {}", entEnoteL);
        Optional<EntEnoteL> originTrax = entEnoteLDao.selectOriginalTransaction(entEnoteL);

        return originTrax.orElse(null);

    }

    /**
     * 원거래조회
     *
     * @param msgTracNo
     * @param traxIdNo
     * @return
     */
    public EntRcrsMgmtL getOriginalEntRcrsMgmtL(String msgTracNo, String traxIdNo) {

        EntRcrsMgmtL rcrsMgmtL = new EntRcrsMgmtL();
        rcrsMgmtL.setTrDt(DateUtils.getISODate());
        rcrsMgmtL.setTrUnqNo(traxIdNo); // 거래고유번호
        rcrsMgmtL.setEntTlgTrceNo(msgTracNo);

        log.debug("----------------- getOriginalEntRcrsMgmtL EntRcrsMgmtL -----------------: {}", rcrsMgmtL);
        Optional<EntRcrsMgmtL> originTrax = entRcrsMgmtLDao.selectOriginalTransaction(rcrsMgmtL);

        return originTrax.orElse(null);

    }

    /**
     * 원거래조회
     *
     * @param msgTracNo
     * @param traxIdNo
     * @return
     */
    public EntSttlMgmtL getOriginalEntSttlMgmtL(String msgTracNo, String traxIdNo) {

        EntSttlMgmtL sttlMgmtL = new EntSttlMgmtL();
        sttlMgmtL.setTrDt(DateUtils.getISODate());
        sttlMgmtL.setTrUnqNo(traxIdNo); // 거래고유번호
        sttlMgmtL.setEntTlgTrceNo(msgTracNo);

        log.debug("----------------- getOriginalEntSttlMgmtL EntSttlMgmtL -----------------: {}", sttlMgmtL);
        Optional<EntSttlMgmtL> originTrax = entSttlMgmtLDao.selectOriginalTransaction(sttlMgmtL);

        return originTrax.orElse(null);

    }

    /**
     * 원거래 조회
     *
     * @param msgTracNo
     * @param traxIdNo
     * @return
     */
    public EntMbrL getOriginTraxEntMbrL(String msgTracNo, String traxIdNo) {

        EntMbrL entMbrL = new EntMbrL();
        entMbrL.setTrDt(DateUtils.getISODate());
        entMbrL.setTrUnqNo(traxIdNo); // 거래고유번호
        entMbrL.setEntTlgTrceNo(msgTracNo);

        Optional<EntMbrL> originTrax = entMbrLDao.selectOriginalTransaction(entMbrL);

        return originTrax.orElse(null);

    }

    /**
     * 원거래 조회
     *
     * @param msgTracNo
     * @param traxIdNo
     * @return
     */
    public EntCqeInqyL getOriginTraxEntCqeInqyL(String msgTracNo, String traxIdNo) {

        /*
         * 원거래내역 조회
         */
        EntCqeInqyL entCqeInqyL = new EntCqeInqyL();
        entCqeInqyL.setTrDt(DateUtils.getISODate());
        entCqeInqyL.setEntTlgTrceNo(msgTracNo);
        entCqeInqyL.setTrUnqNo(traxIdNo);

        Optional<EntCqeInqyL> originTrax = entCqeInqyLDao.selectOriginalTransaction(entCqeInqyL);

        return originTrax.orElse(null);

    }

    /*
     * 중복거래 체크
     */
    public boolean hasDuplicatedTransaction(String traxIdNo, String outInDvsnCd) {
        EntEnoteL entLIn = new EntEnoteL();
        entLIn.setTrDt(DateUtils.getISODate());
        entLIn.setTrUnqNo(traxIdNo);
        entLIn.setEntOutinDvsnCd(outInDvsnCd);

        Optional<EntEnoteL> entL = entEnoteLDao.selectLastTransaction(entLIn);

        return entL.isPresent();
    }

    /*
     * 중복거래 체크
     */
    public boolean hasDuplicatedSettlement(String traxIdNo, String outInDvsnCd) {
        EntSttlMgmtL sttlMgmt = new EntSttlMgmtL();
        sttlMgmt.setTrDt(DateUtils.getISODate());
        sttlMgmt.setTrUnqNo(traxIdNo); // 거래고유번호
        sttlMgmt.setEntOutinDvsnCd(outInDvsnCd);

        log.debug("----------------- hasDuplicatedSettlement EntSttlMgmtL -----------------: {}", sttlMgmt);
        Optional<EntSttlMgmtL> originalTransaction = entSttlMgmtLDao.selectOriginalTransaction(sttlMgmt);

        return originalTransaction.isPresent();
    }

    /*
     * 중복거래 체크
     */
    public boolean hasDuplicatedRecourse(String traxIdNo, String outInDvsnCd) {
        EntRcrsMgmtL rcrsMgmtL = new EntRcrsMgmtL();
        rcrsMgmtL.setTrDt(DateUtils.getISODate());
        rcrsMgmtL.setTrUnqNo(traxIdNo); // 거래고유번호
        rcrsMgmtL.setEntOutinDvsnCd(outInDvsnCd);

        log.debug("----------------- hasDuplicatedRecourse EntRcrsMgmtL -----------------: {}", rcrsMgmtL);
        Optional<EntRcrsMgmtL> originalTransaction = entRcrsMgmtLDao.selectOriginalTransaction(rcrsMgmtL);

        return originalTransaction.isPresent();
    }

    /*
     * 주민번호 슬라이스 & 암호화 처리
     */
    public <T> void sliceAndEncryptCtzBizNo(
            T record,
            Function<T, String> getter,
            BiConsumer<T, String> setterSlice,
            BiConsumer<T, String> setterEnc
    ) {
        String value = getter.apply(record);
        setterSlice.accept(record, sliceCtzBizNo(value));
        setterEnc.accept(record, encryptCtzBizNo(value));
    }

    /**
     * 회원내역 table insert
     */
    public void insertMemberLog(EntMbrL entMbrL, String traxIdNo, String tlgmTraxIdNo) {
        entMbrL.setTrDt(DateUtils.getISODate());
        entMbrL.setTrUnqNo(traxIdNo);
        entMbrL.setEntTlgTrceNo(tlgmTraxIdNo);

        sliceAndEncryptCtzBizNo(
                entMbrL,
                EntMbrL::getCtzBizNo,
                EntMbrL::setCtzBizNo,
                EntMbrL::setCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entMbrL,
                EntMbrL::getCtzBizNo2,
                EntMbrL::setCtzBizNo2,
                EntMbrL::setCtzBizNoEnc2
        );

        sliceAndEncryptCtzBizNo(
                entMbrL,
                EntMbrL::getCondCtzBizNo,
                EntMbrL::setCondCtzBizNo,
                EntMbrL::setCondCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entMbrL,
                EntMbrL::getCondCtzBizNo2,
                EntMbrL::setCondCtzBizNo2,
                EntMbrL::setCondCtzBizNoEnc2
        );

        log.debug("----------------- insert EntMbrL -----------------: {}", entMbrL);
        entMbrLMapper.insert(entMbrL);
    }

    /**
     * 전자어음 거래내역 table insert
     */
    public void insertEnoteTransactionLog(EntEnoteL eNote, String traxIdNo, String tlgmTraxIdNo) {
        eNote.setTrDt(DateUtils.getISODate());
        eNote.setTrUnqNo(traxIdNo); // 거래고유번호
        eNote.setEntTlgTrceNo(tlgmTraxIdNo); // 전문추적번호

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getIssurCtzBizNo,
                EntEnoteL::setIssurCtzBizNo,
                EntEnoteL::setIssurCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getBeneCtzBizNo,
                EntEnoteL::setBeneCtzBizNo,
                EntEnoteL::setBeneCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getGrntCtzBizNo,
                EntEnoteL::setGrntCtzBizNo,
                EntEnoteL::setGrntCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getEndrCtzBizNo,
                EntEnoteL::setEndrCtzBizNo,
                EntEnoteL::setEndrCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getEndrsrCtzBizNo,
                EntEnoteL::setEndrsrCtzBizNo,
                EntEnoteL::setEndrsrCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getRcpntChgNewCtzBizNo,
                EntEnoteL::setRcpntChgNewCtzBizNo,
                EntEnoteL::setRcpntChgNewCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                eNote,
                EntEnoteL::getRcpntChgOldCtzBizNo,
                EntEnoteL::setRcpntChgOldCtzBizNo,
                EntEnoteL::setRcpntChgOldCtzBizNoEnc
        );

        log.debug("----------------- insert EntEnoteL -----------------: {}", eNote);
        entEnoteLMapper.insert(eNote);
    }

    /*
     * 보증관리 update
     */
    public void updateEnoteGuaranteeManagement(String entNo, EntGrntMgmtM entGrntM) {
        EntGrntMgmtM grnt = entGrntMgmtMMapper.selectByPrimaryKey(entNo, entGrntM.getEnotHstSpltNo(), entGrntM.getEndtNo(), entGrntM.getGrntDvsnCd());

        sliceAndEncryptCtzBizNo(
                entGrntM,
                EntGrntMgmtM::getGrntCtzBizNo,
                EntGrntMgmtM::setGrntCtzBizNo,
                EntGrntMgmtM::setGrntCtzBizNoEnc
        );

        log.debug("----------------- EntGrntMgmtM merge -----------------: {} ", entGrntM);
        if (grnt == null) {
            entGrntMgmtMMapper.insert(entGrntM);
        } else {
            entGrntMgmtMDao.updateEntGrntMgmtM(entGrntM);
        }
    }

    /*
     * 전자어음관리 update
     */
    public void updateEnoteManagement(String entNo, EntEnoteM entEnoteM) {
        EntEnoteM enote = entEnoteMMapper.selectByPrimaryKey(entNo);

        sliceAndEncryptCtzBizNo(
                entEnoteM,
                EntEnoteM::getIssurCtzBizNo,
                EntEnoteM::setIssurCtzBizNo,
                EntEnoteM::setIssurCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entEnoteM,
                EntEnoteM::getBeneCtzBizNo,
                EntEnoteM::setBeneCtzBizNo,
                EntEnoteM::setBeneCtzBizNoEnc
        );

        log.debug("----------------- EntEnoteM merge ----------------- : {} ", entEnoteM);
        if (enote == null) {
            entEnoteMMapper.insert(entEnoteM);
        } else {
            entEnoteMDao.updateEntEnoteM(entEnoteM);
        }
    }

    /*
     * 배서관리 merge
     */
    public void updateEnoteEndorsement(String entNo, EntEndrM entEndrM) {
        EntEndrM endr = entEndrMMapper.selectByPrimaryKey(entNo, entEndrM.getSpltNo(), entEndrM.getEndtNo());

        sliceAndEncryptCtzBizNo(
                entEndrM,
                EntEndrM::getEndrsrCtzBizNo,
                EntEndrM::setEndrsrCtzBizNo,
                EntEndrM::setEndrsrCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entEndrM,
                EntEndrM::getEndrCtzBizNo,
                EntEndrM::setEndrCtzBizNo,
                EntEndrM::setEndrCtzBizNoEnc
        );

        log.debug("----------------- EntEndrM merge : {} -----------------", entEndrM);
        if (endr == null) {
            entEndrMMapper.insert(entEndrM);
        } else {
            entEndrMDao.updateEntEndrM(entEndrM);
        }
    }

    /*
     * 배서관리 update
     */
    public void updateEnoteEndorsement(EntEndrM entEndrM) {
        sliceAndEncryptCtzBizNo(
                entEndrM,
                EntEndrM::getEndrsrCtzBizNo,
                EntEndrM::setEndrsrCtzBizNo,
                EntEndrM::setEndrsrCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entEndrM,
                EntEndrM::getEndrCtzBizNo,
                EntEndrM::setEndrCtzBizNo,
                EntEndrM::setEndrCtzBizNoEnc
        );

        log.debug("----------------- EntEndrM update : {} -----------------", entEndrM);
        entEndrMDao.updateEntEndrM(entEndrM);
    }

    /*
     * 상환청구 거래내역 update
     */
    public void updateEnoteRecourseManagementLog(EntRcrsMgmtL entRcrsMgmtL, String traxIdNo) {
        entRcrsMgmtL.setTrDt(DateUtils.getISODate());
        entRcrsMgmtL.setTrUnqNo(traxIdNo);

        sliceAndEncryptCtzBizNo(
                entRcrsMgmtL,
                EntRcrsMgmtL::getRcrsClaimCtzBizNo,
                EntRcrsMgmtL::setRcrsClaimCtzBizNo,
                EntRcrsMgmtL::setRcrsClaimCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entRcrsMgmtL,
                EntRcrsMgmtL::getPrsnWrpymntObligCtzBizNo,
                EntRcrsMgmtL::setPrsnWrpymntObligCtzBizNo,
                EntRcrsMgmtL::setPrsnWrpymntObligCtzBizNoEnc
        );

        log.debug("----------------- EntRcrsMgmtL update : {} -----------------", entRcrsMgmtL);
        entRcrsMgmtLDao.updateOriginalTransaction(entRcrsMgmtL);
    }

    /**
     * 결제관리 merge (Settlement Management M)
     */
    public void updateEnoteSettleManagementM(String entNo, String notiTgt, EntSttlMgmtM entSttlMgmtM) {
    	
    	// notiTgt 값이 없으면 NotiTargetEnum에서 기본값(NOTI_TO_RECIPIENT의 코드)으로 처리
        String entSndRcvDvsnCd = NotiTargetEnum.getEntSndRcvDvsnCdByNotiCode(notiTgt);
        
        updateEntSttlMgmt(entNo, entSndRcvDvsnCd, entSttlMgmtM);
    }

    /**
     * 결제관리 merge (Settlement Management M) (배치용)
     */
    public void updateEnoteSettleManagementM(String entNo, EntSttlMgmtM entSttlMgmtM) {
        // 엔티티 내부의 entSndRcvDvsnCd이 설정되어 있으면 판단하지 않고 값을 그대로 사용
        updateEntSttlMgmt(entNo, entSttlMgmtM.getEntSndRcvDvsnCd(), entSttlMgmtM);
    }

    /**
     * 공통 결제관리 merge 로직
     *
     * @param entNo            어음번호
     * @param entSndRcvDvsnCd  ent 송수신구분코드
     * @param entSttlMgmtM     결제관리 DTO
     */
    public void updateEntSttlMgmt(String entNo, String entSndRcvDvsnCd, EntSttlMgmtM entSttlMgmtM) {

        entSttlMgmtM.setEntSndRcvDvsnCd(entSndRcvDvsnCd);

        // notiTgt를 이용하여 기존 데이터 조회
        EntSttlMgmtM sttlMgmt = entSttlMgmtMMapper.selectByPrimaryKey(
                entNo,
                entSttlMgmtM.getAddRequSpltNo(),
                entSttlMgmtM.getAddRequEndtNo(),
                entSndRcvDvsnCd
        );

        // 첫 번째 사업자번호 필드 암호화 처리
        sliceAndEncryptCtzBizNo(
                entSttlMgmtM,
                EntSttlMgmtM::getIssurCtzBizNo,
                EntSttlMgmtM::setIssurCtzBizNo,
                EntSttlMgmtM::setIssurCtzBizNoEnc
        );

        // 두 번째 사업자번호 필드 암호화 처리 (필요한 경우)
        sliceAndEncryptCtzBizNo(
                entSttlMgmtM,
                EntSttlMgmtM::getRcpntCtzBizNo,
                EntSttlMgmtM::setRcpntCtzBizNo,
                EntSttlMgmtM::setRcpntCtzBizNoEnc
        );

        // 결제처리 구분이 '만기일에 전자어음 부도'(DEFAULT_ON_MATURED_DATE)인 경우 관련 필드를 공백 처리
        if (!StringUtils.equals(SttlPrcsDvsnCdEnum.DEFAULT_ON_MATURED_DATE.getCode(), entSttlMgmtM.getSttlPrcsDvsn())) {
            entSttlMgmtM.setAcdntRptRsnCd(" ");
            entSttlMgmtM.setDfltRsnStopPymntInjctCd(" ");
            entSttlMgmtM.setDfltRsnSpclDepoCrdtCd(" ");
            entSttlMgmtM.setDfltRsnCorpMgmtBnkCd(" ");
            entSttlMgmtM.setDfltRsnRstrctTgtCmpnyCd(" ");
            entSttlMgmtM.setDfltRsnDpstSrtRsnCd(" ");
        }

        log.debug("----------------- EntSttlMgmtM merge : {} -----------------", entSttlMgmtM);
        // 원거래가 없고
        if (sttlMgmt == null) {
            // 271000 전문일 때 sttlPrcsDvsn이 null 이므로 sttlSts = 00 설정
            if (entSttlMgmtM.getSttlPrcsDvsn() == null) {
                entSttlMgmtM.setSttlSts(EntConst.DEFAULT_NO);
            }
            entSttlMgmtMMapper.insert(entSttlMgmtM);
        } else {
            entSttlMgmtMDao.updateEntSttlMgmtM(entSttlMgmtM);
        }
    }

    public void insertEnoteRecourseManagementLog(EntRcrsMgmtL entRcrsMgmtL, String traxIdNo, String tlgmTraxIdNo) {
        entRcrsMgmtL.setTrDt(DateUtils.getISODate());
        entRcrsMgmtL.setTrUnqNo(traxIdNo);
        entRcrsMgmtL.setEntTlgTrceNo(tlgmTraxIdNo);

        sliceAndEncryptCtzBizNo(
                entRcrsMgmtL,
                EntRcrsMgmtL::getRcrsClaimCtzBizNo,
                EntRcrsMgmtL::setRcrsClaimCtzBizNo,
                EntRcrsMgmtL::setRcrsClaimCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                entRcrsMgmtL,
                EntRcrsMgmtL::getPrsnWrpymntObligCtzBizNo,
                EntRcrsMgmtL::setPrsnWrpymntObligCtzBizNo,
                EntRcrsMgmtL::setPrsnWrpymntObligCtzBizNoEnc
        );

        log.debug("----------------- EntRcrsMgmtL insert : {} -----------------", entRcrsMgmtL);
        entRcrsMgmtLMapper.insert(entRcrsMgmtL);
    }

    /*
     * 결제관리 update
     */
    public void updateEnoteSettleManagementLog(EntSttlMgmtL sttlMgmt, String trUnqNo) {
        sttlMgmt.setTrDt(DateUtils.getISODate());
        sttlMgmt.setTrUnqNo(trUnqNo);

        sliceAndEncryptCtzBizNo(
                sttlMgmt,
                EntSttlMgmtL::getIssurCtzBizNo,
                EntSttlMgmtL::setIssurCtzBizNo,
                EntSttlMgmtL::setIssurCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                sttlMgmt,
                EntSttlMgmtL::getRcpntCtzBizNo,
                EntSttlMgmtL::setRcpntCtzBizNo,
                EntSttlMgmtL::setRcpntCtzBizNoEnc
        );

        log.debug("----------------- EntSttlMgmtL Update : {} -----------------", sttlMgmt);
        entSttlMgmtLDao.updateOriginalTransaction(sttlMgmt);
    }

    /*
     * 결제관리 update
     */
    public void updateEnoteSettleManagementM(EntSttlMgmtM sttlMgmt) {
        log.debug("----------------- EntSttlMgmtM update : {} -----------------", sttlMgmt);

        entSttlMgmtMDao.updateEntSttlMgmtM(sttlMgmt);
    }

    /**
     * 전자어음 거래내역 table insert
     */
    public void insertEnoteSettleManagementLog(EntSttlMgmtL sttlMgmt, String traxIdNo, String tlgmTraxIdNo) {
        sttlMgmt.setTrDt(DateUtils.getISODate());
        sttlMgmt.setTrUnqNo(traxIdNo); // 거래고유번호
        sttlMgmt.setEntTlgTrceNo(tlgmTraxIdNo);

        sliceAndEncryptCtzBizNo(
                sttlMgmt,
                EntSttlMgmtL::getIssurCtzBizNo,
                EntSttlMgmtL::setIssurCtzBizNo,
                EntSttlMgmtL::setIssurCtzBizNoEnc
        );

        sliceAndEncryptCtzBizNo(
                sttlMgmt,
                EntSttlMgmtL::getRcpntCtzBizNo,
                EntSttlMgmtL::setRcpntCtzBizNo,
                EntSttlMgmtL::setRcpntCtzBizNoEnc
        );

        log.debug("----------------- insert EntSttlMgmtL -----------------: {}", sttlMgmt);
        entSttlMgmtLMapper.insert(sttlMgmt);
    }

    //////////////////////////////////////////////////////// 공통 로직 ////////////////////////////////////////////////////////

    /**
     * 주민등록번호만 암호화 o, 사업자번호는 암호화 x
     */
    public String encryptCtzBizNo(String ctzBizNo) {
        if (StringUtils.length(ctzBizNo) == RESIDENT_ID_LENGTH) {

            // TODO. key 수정
            return frwVault.encHexStr("test1", ctzBizNo);
        }
        return ctzBizNo;
    }

    /**
     * 주민등록번호만 복호화
     */
    public String decryptCtzBizNo(String entCtzBizNo) {

        // TODO. key 수정
        return frwVault.decHexStr("test1", entCtzBizNo);
    }

    /**
     * 주민등록번호 6자리 slice
     */
    public String sliceCtzBizNo(String ctzBizNo) {
        if (StringUtils.length(ctzBizNo) == RESIDENT_ID_LENGTH) {
            // 주민등록번호일 경우 앞 6자리만 반환
            return ctzBizNo.substring(0, RESIDENT_ID_CUT_LENGTH);
        }
        // 사업자번호일 경우 원본 반환
        return ctzBizNo;
    }

    /**
     * KFTC -> CQE 계좌번호 앞자리에서 00 제거
     * CQE -> KFTC 00 + 계좌번호
     */
    public String convertKftcToCqeAcctNo(String accountNo) {
        if (StringUtils.startsWith(accountNo, ComConst.CHAR_00)) {
            return StringUtils.substring(accountNo, 2);
        }
        return ComConst.CHAR_00.concat(accountNo);
    }

    /**
     * 알람 전송 메소드
     */
    public void sendAlarm(AlarmInfo alarmInfo) {
        try {
            Map<String, Object> paramValList = new Hashtable<>();
            paramValList.put("errTlgId", alarmInfo.errTlgId());
            paramValList.put("errCtt", alarmInfo.errMsg());

            // ALARM_MESSAGE_TEMPLATE_ID, 에러 전문 ID, 파라미터 해시테이블 등 전달
            comPshMsgBean.sendAlarm(ALARM_MESSAGE_TEMPLATE_ID, alarmInfo.errTlgId(), paramValList, null, true);
            log.debug("Alarm sent successfully for id: {}", alarmInfo.errTlgId());
        } catch (Exception e) {
            log.error("Message Request Fail", e);
        }
    }
}
