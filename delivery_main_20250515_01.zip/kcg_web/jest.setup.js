// Optional: configure or set up a testing framework before each test.
// If you delete this file, remove `setupFilesAfterEnv` from `jest.config.js`

// Used for __tests__/testing-library.js
// Learn more: https://github.com/testing-library/jest-dom
import "@testing-library/jest-dom"
import { TextEncoder, TextDecoder } from "util"
import React from "react"
import sampleCode from "./__tests__/sampleCode.json"

Object.assign(global, { TextDecoder, TextEncoder })
// 오래 걸리는 테스트를 위해 타임아웃을 임의로 늘림
jest.setTimeout(600000)

beforeEach(() => {
  jest.clearAllMocks()
  mockUseProxy.mockAsync.mockRestore()
  sessionStorage.clear()
  global.pagingHandling = []
})

afterAll(() => {
  jest.restoreAllMocks()
})

// useProxy 전역 모킹
const mockAsync = jest.fn()
const mockSubmitMultipart = jest.fn()
const mockDownload = jest.fn()
const mockPromiseAllSettled = jest.fn()

jest.mock("@/hooks/useProxy", () => () => ({
  async: mockAsync,
  submitMultipart: mockSubmitMultipart,
  download: mockDownload,
  promiseAllSettled: mockPromiseAllSettled,
}))

global.mockUseProxy = {
  mockAsync,
  mockSubmitMultipart,
  mockDownload,
  mockPromiseAllSettled,
}

// useCode 전역 모킹
const mockGetAllCodeList = jest.fn()
const mockGetCodeList = jest.fn((key) => {
  return new Promise((resolve, reject) => {
    if (Object.keys(sampleCode).includes(key)) {
      resolve(sampleCode[key])
    } else {
      resolve([])
    }
  })
})
const mockGetBankCodeList = jest.fn()
const mockCodeValue = jest.fn((key, value) => {
  return value
})
const mockGetMsgTemplateList = jest.fn()
const mockValueList = jest.fn()
const mockGetAllBankCodeList = jest.fn()
const mockGetIftBankCodeList = jest.fn()
const mockGetHofBankCodeList = jest.fn()
const mockGetHbkBankCodeList = jest.fn()
const mockGetRprBankCodeList = jest.fn()
const mockGetCmsBankCodeList = jest.fn()
const mockGetEntBankCodeList = jest.fn()
const mockGetResponseCodeList = jest.fn()
const mockGetIftResponseCodeList = jest.fn()
const mockGetHofResponseCodeList = jest.fn()
const mockGetHbkResponseCodeList = jest.fn()
const mockGetCmsResponseCodeList = jest.fn()
const mockGetRprResponseCodeList = jest.fn()
const mockGetEntResponseCodeList = jest.fn()
const mockInitAllCodeList = jest.fn().mockResolvedValue({})

jest.mock("@/hooks/useCode", () => () => ({
  initAllCodeList: mockInitAllCodeList,
  getCodeList: mockGetCodeList,
  codeValue: mockCodeValue,
  getAllCodeList: mockGetAllCodeList,
  getAllBankCodeList: mockGetAllBankCodeList,
  getBankCodeList: mockGetBankCodeList,
  getMsgTemplateList: mockGetMsgTemplateList,
  valueList: mockValueList,
  getIftBankCodeList: mockGetIftBankCodeList,
  getHofBankCodeList: mockGetHofBankCodeList,
  getHbkBankCodeList: mockGetHbkBankCodeList,
  getRprBankCodeList: mockGetRprBankCodeList,
  getCmsBankCodeList: mockGetCmsBankCodeList,
  getEntBankCodeList: mockGetEntBankCodeList,
  getResponseCodeList: mockGetResponseCodeList,
  getIftResponseCodeList: mockGetIftResponseCodeList,
  getHofResponseCodeList: mockGetHofResponseCodeList,
  getHbkResponseCodeList: mockGetHbkResponseCodeList,
  getCmsResponseCodeList: mockGetCmsResponseCodeList,
  getRprResponseCodeList: mockGetRprResponseCodeList,
  getEntResponseCodeList: mockGetEntResponseCodeList,
}))

global.mockUseCode = {
  mockInitAllCodeList,
  mockGetCodeList,
  mockCodeValue,
  mockGetAllCodeList,
  mockGetBankCodeList,
  mockGetMsgTemplateList,
  mockValueList,
  mockGetIftBankCodeList,
  mockGetHofBankCodeList,
  mockGetHbkBankCodeList,
  mockGetRprBankCodeList,
  mockGetCmsBankCodeList,
  mockGetEntBankCodeList,
  mockGetResponseCodeList,
  mockGetIftResponseCodeList,
  mockGetHofResponseCodeList,
  mockGetHbkResponseCodeList,
  mockGetCmsResponseCodeList,
  mockGetRprResponseCodeList,
  mockGetEntResponseCodeList,
}

// useModal 전역 모킹
const mockToast = jest.fn()
const mockAlert = jest.fn()
const mockConfirm = jest.fn()
const mockValid = jest.fn()
const mockError = jest.fn()
const mockOpenPopup = jest.fn()
const mockClosePopup = jest.fn()
const mockCommonMenuSearch = jest.fn()
const mockCommonShortCut = jest.fn()
const mockRequestApprovalAlert = jest
  .fn()
  .mockImplementation(
    ({ cond: cond, showBox: showBox, postFunction: postFunction }) => {
      showBox(false)
      postFunction()
    },
  )

jest.mock("@/hooks/useModal", () => () => {
  const originalUseModalFunctions = jest.requireActual("@/hooks/useModal")
  return {
    toast: mockToast,
    alert: mockAlert,
    confirm: mockConfirm,
    valid: mockValid,
    error: mockError,
    openPopup: mockOpenPopup,
    closePopup: mockClosePopup,
    commonMenuSearch: mockCommonMenuSearch,
    commonShortCut: mockCommonShortCut,
    requestApprovalAlert: mockRequestApprovalAlert,
  }
})

global.mockUseModal = {
  mockToast,
  mockAlert,
  mockConfirm,
  mockValid,
  mockError,
  mockOpenPopup,
  mockClosePopup,
  mockCommonMenuSearch,
  mockCommonShortCut,
  mockRequestApprovalAlert,
}

// useMenu 전역 모킹
const mockOpenMenu = jest.fn()
const mockOpenMenuByScrnId = jest.fn()
const mockModifyFavoriteMenu = jest.fn()
const mockLogOut = jest.fn()
const mockGetFavoriteList = jest.fn()
const mockSetSelectMenuList = jest.fn()
const mockSelectMyMenuListForOutSideClick = jest.fn()
const mockSelectMyMenuList = jest.fn()

jest.mock("@/hooks/useMenu", () => () => {
  const originalUseMenuFunctions = jest.requireActual("@/hooks/useMenu")
  return {
    ...originalUseMenuFunctions.default(),
    openMenu: mockOpenMenu,
    openMenuByScrnId: mockOpenMenuByScrnId,
    modifyFavoriteMenu: mockModifyFavoriteMenu,
    logout: mockLogOut,
    getFavoriteList: mockGetFavoriteList,
    setSelectMenuList: mockSetSelectMenuList,
    selectMyMenuListForOutSideClick: mockSelectMyMenuListForOutSideClick,
    selectMyMenuList: mockSelectMyMenuList,
  }
})

global.mockUseMenu = {
  mockOpenMenu,
  mockOpenMenuByScrnId,
  mockModifyFavoriteMenu,
  mockLogOut,
  mockGetFavoriteList,
  mockSetSelectMenuList,
  mockSelectMyMenuListForOutSideClick,
  mockSelectMyMenuList,
}

// useForm 전역 모킹
const mockValidate = jest.fn().mockResolvedValue({})
const mockGetValues = jest.fn()
jest.mock("@/hooks/useForm", () => () => {
  const originalUseFormFunctions = jest.requireActual("@/hooks/useForm")
  return {
    ...originalUseFormFunctions.default(),
    validate: mockValidate,
    getValues: mockGetValues,
  }
})

global.mockUseForm = {
  mockValidate,
  mockGetValues,
}

jest.mock("@/hooks/useGrid", (initConfig) => (initConfig) => {
  const originaluseGridFunctions = jest.requireActual("@/hooks/useGrid")
  global.pagingHandling = global.pagingHandling || []
  if (initConfig.pagingSetParam?.apiFunction) {
    global.pagingHandling.push(initConfig.pagingSetParam.apiFunction)
  } else {
    global.pagingHandling.push(jest.fn())
  }
  return {
    ...originaluseGridFunctions.default(initConfig),
  }
})

// useParam 전역 모킹
global.mockUseParams = jest.fn()
jest.mock("@/hooks/useParams", () => mockUseParams)

// session util 전역 모킹
const mockRoleList = jest.fn()
const mockTxDt = jest.fn()
jest.mock("@/utils/common.storage", () => {
  const originStorageUtils = jest.requireActual("@/utils/common.storage")
  const mockedUtils = {
    ...originStorageUtils.$storageUtils,
    session: (value) => {
      if (value === "roleList") {
        return mockRoleList()
      }
      if (value === "txDt") {
        return mockTxDt()
      }
      return originStorageUtils.$storageUtils.session(value)
    },
  }

  // 모킹된 모듈을 반환합니다
  return {
    $storageUtils: mockedUtils,
  }
})

global.mockStorageUtils = {
  mockRoleList,
  mockTxDt,
}

const mockToday = jest.fn()
jest.mock("@/utils/common.date", () => {
  const originalDateUtils = jest.requireActual("@/utils/common.date")
  const mockedUtils = {
    ...originalDateUtils.$dateUtils,
    today: mockToday,
  }
  return {
    $dateUtils: mockedUtils,
  }
})

global.mockDateUtils = {
  mockToday,
}

const mockTrans = jest.fn().mockImplementation((key) => key)
const mockGetDataByLanguage = jest.fn()
jest.mock("@/utils/common.i18n", () => {
  const originalI18nUtils = jest.requireActual("@/utils/common.i18n")
  const mockedUtils = {
    ...originalI18nUtils.$i18nUtils,
    trans: mockTrans,
    getDataByLanguage: mockGetDataByLanguage,
  }
  return {
    $i18nUtils: mockedUtils,
  }
})

global.mockTrans = mockTrans
global.mockGetDataByLanguage = mockGetDataByLanguage

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

global.delay = delay

const mockSubject = {
  subscribe: jest.fn(),
  next: jest.fn(),
  complete: jest.fn(),
  unsubscribe: jest.fn(),
}

const mockControl = {
  _subjects: {
    watch: mockSubject,
    control: mockSubject,
    array: mockSubject,
    state: mockSubject,
  },
  _removeUnmounted: jest.fn(),
  _names: {
    mount: new Set(),
    unMount: new Set(),
    array: new Set(),
    watch: new Set(),
  },
  _state: {
    mount: true,
    action: false,
    watch: true,
  },
  _reset: jest.fn(),
  _options: {
    mode: "onSubmit",
    reValidateMode: "onChange",
    defaultValues: {},
    shouldFocusError: true,
  },
  _getDirty: jest.fn(),
  _resetDefaultValues: jest.fn(),
  _formState: {
    isDirty: false,
    isValid: false,
    isSubmitted: false,
    isSubmitting: false,
    isSubmitSuccessful: false,
    submitCount: 0,
    touchedFields: {},
    dirtyFields: {},
    errors: {},
  },
  _updateValid: jest.fn(),
  _updateFormState: jest.fn(),
  _fields: {},
  _formValues: {},
  _proxyFormState: {
    isDirty: false,
    isValid: false,
  },
  _defaultValues: {},
  _getWatch: jest.fn(),
  _updateFieldArray: jest.fn(),
  _getFieldArray: jest.fn(),
  _updateDisabledField: jest.fn(),
  _executeSchema: jest.fn().mockResolvedValue({ errors: {} }),
  register: jest.fn(),
  handleSubmit: jest.fn(),
  unregister: jest.fn(),
  getFieldState: jest.fn(),
  setError: jest.fn(),
}

global.mockControl = mockControl

// grid component mocking
const mockExportExcel = jest.fn()
const mockExportCsv = jest.fn()
const mockImportCsv = jest.fn()
const mockImportExcel = jest.fn()
const mockAddRow = jest.fn()
const mockDelRow = jest.fn()
const mockDelRowByIndex = jest.fn()
const mockDelRowByCondition = jest.fn()
const mockUpdateRowByIndex = jest.fn()
const mockUpdateRowByCondition = jest.fn()
const mockGetAllRows = jest.fn()
const mockGetSelectedIndexes = jest.fn()
const mockGetSelectedRows = jest.fn()
const mockGetRowByIndex = jest.fn()
const mockGetRowByCondition = jest.fn()
const mockSetSelectedRowByIndex = jest.fn()
const mockSetSelectedRowByCondition = jest.fn()
const mockScrollToRowIndex = jest.fn()
const mockDeSelectedRow = jest.fn()
const mockChangeCrudType = jest.fn()
const mockRefreshCells = jest.fn()
const mockSetColumnsVisible = jest.fn()
const mockGetGridContainerRef = jest.fn()

jest.mock("@/components/Grid", () => {
  const { forwardRef, useState, createElement } = jest.requireActual("react")
  // Grid 모킹을 위한 forwardRef 정의
  const MockedGrid = forwardRef((props, ref) => {
    const [renderedDivs, setRenderedDivs] = useState([])

    // ref 세팅
    if (ref) {
      ref.current = {
        addRow: mockAddRow,
        changeCrudType: mockChangeCrudType,
        delRow: mockDelRow,
        delRowByCondition: mockDelRowByCondition,
        delRowByIndex: mockDelRowByIndex,
        deSelectedRow: mockDeSelectedRow,
        exportCsv: mockExportCsv,
        exportExcel: mockExportExcel, // exportExcel 함수 모킹
        getAllRows: mockGetAllRows,
        getGridContainerRef: mockGetGridContainerRef,
        getRowByCondition: mockGetRowByCondition,
        getRowByIndex: mockGetRowByIndex,
        getSelectedIndexes: mockGetSelectedIndexes,
        getSelectedRows: mockGetSelectedRows,
        importCsv: mockImportCsv,
        importExcel: mockImportExcel,
        refreshCells: mockRefreshCells,
        scrollToRowIndex: mockScrollToRowIndex,
        setColumnsVisible: mockSetColumnsVisible,
        setSelectedRowByCondition: mockSetSelectedRowByCondition,
        setSelectedRowByIndex: mockSetSelectedRowByIndex,
        updateRowByCondition: mockUpdateRowByCondition,
        updateRowByIndex: mockUpdateRowByIndex,
      }
    }
    const executeFunction = (target, param) => {
      if (target === undefined || target === null) {
        return
      }

      if (
        target !== undefined &&
        target.$$typeof === Symbol.for("react.forward_ref")
      ) {
        return
      }

      if (typeof target === "function") {
        executeFunction(
          target.name
            ? target.apply(
                null,
                param
                  ? Array.isArray(param[target.name])
                    ? param[target.name]
                    : [param[target.name]]
                  : [undefined],
              )
            : target.apply(null, [undefined]),
          param,
        )
        return
      }

      if (target instanceof Promise) {
        try {
          target.then((obj) => {
            executeFunction(obj)
          })
        } catch (error) {
          console.error(error)
        }

        return
      }

      if (typeof target === "object") {
        Object.keys(target).forEach((key) => {
          executeFunction(target[key], param)
        })
        return
      }
    }

    // 각 props 에 대한 테스트를 위한 함수 선언부
    const { config, rowData } = props
    const cellEditorParams = (event) => {
      const rowData = event.target.data || {}
      config.columnDefs.forEach((value) => {
        if (value["cellEditorParams"]) {
          executeFunction(value["cellEditorParams"], rowData)
        }
        // if (typeof value["cellEditorParams"] === "object") {
        //   Object.keys(value["cellEditorParams"]).forEach((key) => {
        //     if (typeof value["cellEditorParams"][key] === "function") {
        //       value["cellEditorParams"][key](0, rowData)
        //     }
        //     if (key === "listPromise") {
        //       value["cellEditorParams"][key].then((obj) => {
        //         if (typeof obj === "function") obj()
        //       })
        //     }

        //     if (key === "conditionListPromise") {
        //       value["cellEditorParams"][key].forEach((value) => {
        //         try {
        //           value["condition"]({})
        //           value["listPromise"]().then(() => {})
        //         } catch (error) {
        //           console.error(error)
        //         }
        //       })
        //     }

        //     if (key === "maskPromise") {
        //       value["cellEditorParams"][key](rowData).then((obj) => {
        //         if (typeof obj === "object") {
        //           Object.keys(obj).forEach((key) => {
        //             if (typeof obj[key] === "function") {
        //               obj[key]()
        //             }
        //           })
        //         }
        //       })
        //     }
        //   })
        // }
      })
    }

    const cellEditorSelector = (event) => {
      const rowData = event.target.data || {}
      config.columnDefs.forEach((value) => {
        if (value["cellEditorSelector"]) {
          executeFunction(value["cellEditorSelector"], rowData)
        }
      })
    }

    const cellRenderer = (event) => {
      const rowData = event.target.data
      // 혹시나... 싶어 초기화 시켜줌
      setRenderedDivs([])
      if (rowData) {
        config.columnDefs.forEach((value) => {
          if (typeof value["cellRenderer"] === "function") {
            const field = value["field"]
            let renderTarget
            if (value["cellRendererParams"]) {
              renderTarget = createElement(value["cellRenderer"], {
                ...value["cellRendererParams"],
                value: rowData[field],
                data: rowData,
                node: {
                  rowIndex: 0,
                },
              })
            } else {
              renderTarget = createElement(value["cellRenderer"], {
                value: rowData[field],
                data: rowData,
                node: {
                  rowIndex: 0,
                },
              })
            }
            if (!renderedDivs.includes(renderTarget)) {
              setRenderedDivs((prev) => [...prev, renderTarget])
            }
          }
        })
      } else {
        console.error("row Data 값은 반드시 주어야함.")
      }
    }

    const cellStyle = (event) => {
      config.columnDefs.forEach((value) => {
        if (typeof value.cellStyle === "function") {
          value.cellStyle({
            data: event.target.data,
            value: event.target.data[value.field],
          })
        }
      })
    }

    const editable = (event) => {
      config.columnDefs.forEach((value) => {
        if (typeof value["editable"] === "function") {
          const field = value["field"]
          value["editable"]({ data: { crudType: "C" } })
        }
      })
    }

    const onCellClicked = (event) => {
      config.onCellClicked({ ...event, data: event.target.data })
    }

    const onCellValueChanged = (event) => {
      const rowData = event.target.data || {}
      config.columnDefs.forEach((value) => {
        if (value["onCellValueChanged"]) {
          executeFunction(value["onCellValueChanged"], rowData)
        }
      })
    }

    const onRowClicked = (event) => {
      if (event.target) {
        // event.data 설정
        event.data = event.target.data
        event.node = { rowIndex: 0 }
        return config.onRowClicked(event)
      }
    }

    const onRowDoubleClicked = (event) => {
      if (event.target) {
        event.data = event.target.data
        return config.onRowDoubleClicked(event)
      }
    }

    const selectableCheckFn = (event) => {
      if (event.target) {
        config.columnDefs.forEach((value) => {
          if (typeof value["selectableCheckFn"] === "function") {
            const field = value["field"]
            value["selectableCheckFn"](event.target)
          }
        })
      }
    }

    const rowClassRules = (event) => {
      Object.keys(config.rowClassRules).forEach((value) => {
        if (typeof config.rowClassRules[value] === "function") {
          config.rowClassRules[value](event.target.data)
        }
      })
    }

    const rowDataCheck = (event) => {
      return event.target.data === rowData
    }

    const valueFormatter = (event) => {
      const rowData = event.target.data
      if (rowData) {
        config.columnDefs.forEach((value) => {
          if (typeof value["valueFormatter"] === "function") {
            const field = value["field"]
            value["valueFormatter"]({ value: rowData[field], data: rowData })
          }
        })
      } else {
        console.error("row Data 값은 반드시 주어야함.")
      }
    }

    const valueGetter = (event) => {
      const rowData = event.target.data
      if (rowData) {
        config.columnDefs.forEach((value) => {
          if (typeof value["valueGetter"] === "function") {
            const field = value["field"]
            value["valueGetter"]({ value: rowData[field], data: rowData })
          }
        })
      } else {
        console.error("row Data 값은 반드시 주어야함.")
      }
    }

    return (
      <div>
        <h3>Mocked Grid Component</h3>
        <div onClick={cellEditorParams}>cellEditorParams Test</div>
        <divv onClick={cellEditorSelector}>cellEditorSelector Test</divv>
        <div onClick={cellRenderer}>cellRenderer Test</div>
        <div onClick={cellStyle}>cellStyle Test</div>
        <div onClick={editable}>editable Test</div>
        <div onClick={onCellClicked}>onCellClicked Test</div>
        <div onClick={onCellValueChanged}>onCellValueChanged Test</div>
        <div onClick={onRowClicked}>onRowClicked Test</div>
        <div onClick={onRowDoubleClicked}>onRowDoubleClicked Test</div>
        <div onClick={selectableCheckFn}>selectableCheckFn Test</div>
        <div onClick={rowClassRules}>rowClassRules Test</div>
        <div onClick={rowDataCheck}>rowDataCheck Test</div>
        <div onClick={valueFormatter}>valueFormatter Test</div>
        <div onClick={valueGetter}>valueGetter Test</div>
        <div>{renderedDivs.length == 0 ? "" : renderedDivs}</div>
        {props.children}
      </div>
    )
  })
  return MockedGrid
})

global.mockGrid = {
  mockExportExcel,
  mockExportCsv,
  mockImportCsv,
  mockImportExcel,
  mockAddRow,
  mockDelRow,
  mockDelRowByIndex,
  mockDelRowByCondition,
  mockUpdateRowByIndex,
  mockUpdateRowByCondition,
  mockGetAllRows,
  mockGetSelectedIndexes,
  mockGetSelectedRows,
  mockGetRowByIndex,
  mockGetRowByCondition,
  mockSetSelectedRowByIndex,
  mockSetSelectedRowByCondition,
  mockScrollToRowIndex,
  mockDeSelectedRow,
  mockChangeCrudType,
  mockRefreshCells,
  mockSetColumnsVisible,
  mockGetGridContainerRef,
}

const MockedInputBox = (props, ref) => {
  const {
    control,
    name,
    i18n,
    disabled,
    onChange,
    onKeyDown,
    onBlur,
    onPaste,
    rules,
    onClick,
    mask,
  } = props

  if (ref) {
    ref.current = {
      select: () => {},
      copy: () => {},
      getValue: mockGetValue,
    }
  }

  return (
    <div data-testid={i18n}>
      <div
        data-testid="onChange"
        onClick={(event) => {
          if (typeof onChange === "function") {
            onChange(event.target.data)
            mockOnChange(event.target.data)
          }
        }}
      >
        onChange Test
      </div>
      <div
        data-testid="validate"
        onClick={(event) => {
          if (rules["validate"]) {
            Object.keys(rules["validate"]).forEach((key) => {
              if (typeof rules["validate"][key] === "function") {
                rules["validate"][key](event.target.data)
              }
            })
          }
        }}
      >
        validate Test
      </div>
      <div data-testid="onClick" onClick={onClick}>
        onClick Test
      </div>
      <div
        data-testid="onKeyDown"
        onClick={(event) => {
          event.key = event.target.key
          onKeyDown(event)
        }}
      >
        onKeyDown Test
      </div>
      <div
        data-testid="onPaste"
        onClick={(event) => {
          onPaste(event, event.target.data)
        }}
      >
        onPaste Test
      </div>
      <div
        data-testid="onBlur"
        onClick={(event) => {
          onBlur(event, event.target.data)
        }}
      >
        onBlur Test
      </div>

      <div
        data-testid="mask"
        onClick={(event) => {
          function recursive(input, data) {
            if (typeof input === "object") {
              Object.keys(input).forEach((key) => {
                recursive(input[key], data)
              })
            } else if (typeof input === "function") {
              input(data)
            } else {
              return
            }
          }
          recursive(mask, event.target.data)
        }}
      ></div>
    </div>
  )
}

// input|select component mocking
const mockOnChange = jest.fn()
const mockGetValue = jest.fn()

jest.mock("@/components/InputBox", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

jest.mock("@/components/InputIconBox", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

jest.mock("@/components/SelectBox", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

jest.mock("@/components/RadioBox", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

jest.mock("@/components/Switch", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

jest.mock("@/components/TextAreaBox", () => {
  const { forwardRef } = jest.requireActual("react")
  // InputBox 모킹을 위한 forwardRef 정의
  const InputBox = forwardRef(MockedInputBox)

  return InputBox
})

// CheckBox 모킹을 위한 forwardRef 정의

jest.mock("@/components/CheckBox", () => {
  const MockedCheckBox = (props) => {
    const {
      control,
      name,
      i18n,
      rules,
      list,
      listPromise,
      disabled,
      className,
      onChange,
    } = props

    return (
      <div data-testid={i18n ? i18n : name}>
        <div onClick={(event) => listPromise} data-testid="listPromise">
          listPromise Test
        </div>
        <div
          onClick={(event) => {
            onChange(event.target.data)
          }}
          data-testid="onChange"
        >
          onChange Test
        </div>
        <div>rules Test</div>
      </div>
    )
  }
  return MockedCheckBox
})

jest.mock("@/components/DatePicker", () => {
  // DatePicker 모킹을 위한 function 정의
  const MockedDatePicker = (props) => {
    const {
      control,
      name,
      i18n,
      rules,
      inputMode,
      fromDate,
      toDate,
      readOnly,
      disabled,
      autoComplete,
      autoFocus,
      dateFormat,
      onSelect,
      onBlur,
    } = props

    return (
      <div data-testid={i18n}>
        <div
          data-testid="onSelect"
          onClick={(event) => {
            onSelect(event.target?.data)
          }}
        >
          onSelect Test
        </div>
        <div
          data-testid="validate"
          onClick={(event) => {
            if (rules["validate"]) {
              Object.keys(rules["validate"]).forEach((key) => {
                if (typeof rules["validate"][key] === "function") {
                  rules["validate"][key](event.target.data)
                }
              })
            }
          }}
        >
          validate Test
        </div>
      </div>
    )
  }
  return MockedDatePicker
})

jest.mock("@/components/PagingBox", () => {
  const { forwardRef } = jest.requireActual("react")
  const MockedPagingBox = forwardRef((props, ref) => {
    const { onChange, rowCount } = props

    if (ref) {
      ref.current = {
        init: () => {},
      }
    }
    return (
      <>
        <div>Mocked PagingBox</div>
        <div onClick={onChange} data-testid="onChange">
          Go Next
        </div>
      </>
    )
  })
  return MockedPagingBox
})

global.mockInputBox = {
  mockOnChange,
  mockGetValue,
}
