package com.jpmc.kcg.web.hof.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.jpmc.kcg.com.dao.ComAcctNoMMapper;
import com.jpmc.kcg.com.dto.ComAcctNoM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.hof.dao.HofAcctOpnMgmtMMapper;
import com.jpmc.kcg.hof.dto.HofAcctOpnMgmtM;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HofAcctOpnMgmtMWebDao;
import com.jpmc.kcg.web.hof.service.dto.CreateHofAcctOpnMgmtIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHofAccountStartTimeOut;
import com.jpmc.kcg.web.hof.service.dto.GetListHofAccountStartTimeVipIn;

class HofAccountTimeVipManagementSvcTest {

	@Mock
	private HofAcctOpnMgmtMMapper hofAcctOpnMgmtMMapper;

	@Mock
	private HofAcctOpnMgmtMWebDao hofAcctOpnWebDao;

	@Mock
	private CommonApprovalSvc commonApprovalSvc;
	
	@Mock
    private ComAcctNoMMapper comAcctNoMDao;

	@InjectMocks
	private HofAccountTimeVipManagementSvc svc;

	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetListHofAccountStartTimeVipAccount() throws Exception {
		// Given
		GetListHofAccountStartTimeVipIn in = new GetListHofAccountStartTimeVipIn();
		in.setAcctNo("12345");
		in.setAcctStaTm("1200");
		in.setPgNbr(1);
		in.setPgCnt(10);

		HofAcctOpnMgmtM hofAcct = new HofAcctOpnMgmtM();
		hofAcct.setAcctNo("12345");

		List<HofAcctOpnMgmtM> hofAcctList = new ArrayList<>();
		hofAcctList.add(hofAcct);

		when(hofAcctOpnWebDao.selectListHofAcctOpnVipInfo(any())).thenReturn(hofAcctList);
		when(hofAcctOpnWebDao.selectListHofAcctOpnVipInfoCnt(any())).thenReturn(1);

		// When
		GetListHofAccountStartTimeOut result = svc.getListHofAccountStartTimeVipAccount(in);

		// Then
		assertNotNull(result);
		assertEquals(1, result.getTotCnt());
		verify(hofAcctOpnWebDao, times(1)).selectListHofAcctOpnVipInfoCnt(any());
		verify(hofAcctOpnWebDao, times(1)).selectListHofAcctOpnVipInfo(any());

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + result);
	}

	@Test
	void testCreateHofAccountStartTimeVipAccount_NewInsert() {
		// Given
		CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
		in.setAcctNo("12345");
		in.setAcctStaTm("1200");
		in.setVipAcctYn("Y");
		in.setVipAmt(new BigDecimal("10000"));
		in.setMakeId("testUser");

		when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(anyString())).thenReturn(null);

		// When
		svc.createHofAccountStartTimeVipAccount(in);

		// Then
		verify(hofAcctOpnMgmtMMapper, times(1)).insert(any(HofAcctOpnMgmtM.class));
		verify(commonApprovalSvc, times(1)).requestApproval(any(ComAprvHIn.class), any(), any());

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + "success");
	}

	@Test
	void testCreateHofAccountStartTimeVipAccount_Update() {
		// Given
		CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
		in.setAcctNo("12345");
		in.setAcctStaTm("1200");
		in.setVipAcctYn("Y");
		in.setVipAmt(new BigDecimal("10000"));
		in.setMakeId("testUser");

		HofAcctOpnMgmtM existingAcct = new HofAcctOpnMgmtM();
		existingAcct.setAcctNo("12345");

		when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(anyString())).thenReturn(existingAcct);

		// When
		svc.createHofAccountStartTimeVipAccount(in);

		// Then
		verify(hofAcctOpnMgmtMMapper, times(1)).updateByPrimaryKey(any(HofAcctOpnMgmtM.class));
		verify(commonApprovalSvc, times(1)).requestApproval(any(ComAprvHIn.class), any(), any());

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + "success");
	}

	@Test
	void testRemoveHofAccountStartTimeVipAccount_update() {
		// Given
		CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
		in.setAcctStaTm("1200");
		in.setVipAcctYn("Y");
		in.setVipAmt(new BigDecimal("10000"));
		in.setMakeId("testUser");

		HofAcctOpnMgmtM existingAcct = new HofAcctOpnMgmtM();
		existingAcct.setAcctNo("12345");

		when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(anyString())).thenReturn(existingAcct);

		// Act & Assert
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			// When
			svc.createHofAccountStartTimeVipAccount(in);
		});

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + exception.getErrorCode());

	}

	@Test
	void testRemoveHofAccountStartTimeVipAccount() {
		// Given
		GetListHofAccountStartTimeVipIn in = new GetListHofAccountStartTimeVipIn();
		in.setAcctNo("12345");

		HofAcctOpnMgmtM existingAcct = new HofAcctOpnMgmtM();
		existingAcct.setAcctNo("12345");

		when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(anyString())).thenReturn(existingAcct);

		// When
		svc.removeHofAccountStartTimeVipAccount(in);

		// Then
		verify(hofAcctOpnMgmtMMapper, times(1)).updateByPrimaryKey(any(HofAcctOpnMgmtM.class));
		verify(commonApprovalSvc, times(1)).requestApproval(any(ComAprvHIn.class), any(), any());

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + "success");

	}

	@Test
	void testRemoveHofAccountStartTimeVipAccount_fail() {
		// Given
		GetListHofAccountStartTimeVipIn in = new GetListHofAccountStartTimeVipIn();

		HofAcctOpnMgmtM existingAcct = new HofAcctOpnMgmtM();
		existingAcct.setAcctNo("12345");

		when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(anyString())).thenReturn(existingAcct);

		// Act & Assert
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			// When
			svc.removeHofAccountStartTimeVipAccount(in);
		});

		System.out.println(">>>>input Value ::" + in);
		System.out.println(">>>>out Value ::" + exception.getErrorCode());

	}
	
	 @Test
	 void testMissingAcctNoThrowsException() {
	 
		 CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
		 in.setAcctNo("");
		
		 BusinessException ex = assertThrows(BusinessException.class,
		    () -> svc.createHofAccountStartTimeVipAccount(in));
		
		 assertEquals("MCMNE01002", ex.getErrorCode());
	 }

    @Test
    void testInvalidAccountThrowsException() {
    	CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
        in.setAcctNo("12345");
        when(comAcctNoMDao.selectByPrimaryKey("12345")).thenReturn(null);

        BusinessException ex = assertThrows(BusinessException.class,
            () -> svc.createHofAccountStartTimeVipAccount(in));

        assertEquals("MCMNE08004", ex.getErrorCode());
    }

    @Test
    void testUpdateWhenBeforeDtoExists() {
        // given
        CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
        in.setAcctNo("12345678");
        in.setAcctStaTm("20250429");
        in.setVipAcctYn("Y");
        in.setVipAmt(BigDecimal.valueOf(100000));
        in.setMakeId("testMakeId");
        in.setChkId("testChkId");
        in.setChkDttm("20250429120000");

        ComAcctNoM comAcctNoM = new ComAcctNoM();
        comAcctNoM.setAcctStsCd("01");
        when(comAcctNoMDao.selectByPrimaryKey(in.getAcctNo())).thenReturn(comAcctNoM);

        HofAcctOpnMgmtM beforeDto = new HofAcctOpnMgmtM();
        when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(in.getAcctNo())).thenReturn(beforeDto);

        Header header = new Header();
        header.setGuid("GUID123");
        header.setStaffId("STAFFID123");
//        WebApplicationContext.setHeader(header);

        // when
        svc.createHofAccountStartTimeVipAccount(in);

        // then
        verify(hofAcctOpnMgmtMMapper).updateByPrimaryKey(any(HofAcctOpnMgmtM.class));
        verify(commonApprovalSvc).requestApproval(any(ComAprvHIn.class), any(HofAcctOpnMgmtM.class), any(HofAcctOpnMgmtM.class));
    }

    @Test
    void testInsertWhenBeforeDtoIsNull() {
        // given
        CreateHofAcctOpnMgmtIn in = new CreateHofAcctOpnMgmtIn();
        in.setAcctNo("87654321");
        in.setAcctStaTm("20250429");
        in.setVipAcctYn("N");
        in.setVipAmt(BigDecimal.valueOf(50000));
        in.setMakeId("testMakeId2");
        in.setChkId("testChkId2");
        in.setChkDttm("20250429123000");

        ComAcctNoM comAcctNoM = new ComAcctNoM();
        comAcctNoM.setAcctStsCd("01");
        when(comAcctNoMDao.selectByPrimaryKey(in.getAcctNo())).thenReturn(comAcctNoM);

        when(hofAcctOpnMgmtMMapper.selectByPrimaryKey(in.getAcctNo())).thenReturn(null);

        Header header = new Header();
        header.setGuid("GUID456");
        header.setStaffId("STAFFID456");
//        WebApplicationContext.setHeader(header);

        // when
        svc.createHofAccountStartTimeVipAccount(in);

        // then
        verify(hofAcctOpnMgmtMMapper).insert(any(HofAcctOpnMgmtM.class));
        verify(commonApprovalSvc).requestApproval(any(ComAprvHIn.class), isNull(), any(HofAcctOpnMgmtM.class));
    }
}
