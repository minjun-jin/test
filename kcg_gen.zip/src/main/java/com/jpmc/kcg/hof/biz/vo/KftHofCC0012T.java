package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 매월분 공동코드 변동분
 * <pre>{@code
 * KftHofCC0012T kftHofCC0012T  = new KftHofCC0012T(); // 매월분 공동코드 변동분
 * kftHofCC0012T.setFileName(""); // 업무구분
 * kftHofCC0012T.setDataType(""); // 데이타구분
 * kftHofCC0012T.setSerialNumber(""); // 일련번호
 * kftHofCC0012T.setInstitutionCode(""); // 기관코드
 * kftHofCC0012T.setTotalDataRecordCount(""); // 총DATARECORD수
 * kftHofCC0012T.setTransactionYearMonth(""); // 거래발생년월
 * kftHofCC0012T.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofCC0012T implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String totalDataRecordCount; // 총DATARECORD수
	private String transactionYearMonth; // 거래발생년월
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총DATARECORD수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionYearMonth$; // 거래발생년월
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 7); // 총DATARECORD수
		transactionYearMonth$ = VOUtils.write(out, transactionYearMonth, 4); // 거래발생년월
		filler2$ = VOUtils.write(out, filler2, 271); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		totalDataRecordCount = VOUtils.toString(totalDataRecordCount$ = VOUtils.read(in, 7)); // 총DATARECORD수
		transactionYearMonth = VOUtils.toString(transactionYearMonth$ = VOUtils.read(in, 4)); // 거래발생년월
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 271)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총DATARECORD수
		sb.append(", transactionYearMonth=").append(transactionYearMonth).append(System.lineSeparator()); // 거래발생년월
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionYearMonth", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "271", "defltVal", "")
		);
	}

}
