package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 발행 후 분할기준 분할내역 조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * userSort 이용자구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * currentCreditAccountNumber 당좌(입금)계좌번호 
 * noteInfoEnoteNumber 어음정보-전자어음번호 
 * noteInfoNoteType 어음정보-어음종류 
 * noteInfoEnoteIssueDate 어음정보-전자어음발행일자 
 * noteInfoEnoteIssuePlace 어음정보-전자어음발행지 
 * noteInfoEnoteAmount 어음정보-전자어음금액 
 * noteInfoEnoteMaturedDate 어음정보-전자어음만기일자 
 * noteInfopaymentBankBranchCode 어음정보-지급은행및점포코드 
 * issuerInfoIndvCorpSort 발행인정보-개인법인구분 
 * issuerInfoResidentBusinessNumber 발행인정보-주민사업자번호 
 * issuerInfoCorpName 발행인정보-법인명 
 * issuerInfoNameRepresentative 발행인정보-성명(대표자명) 
 * issuerInfoAddress 발행인정보주소 
 * issuerInfoBankCode 발행인정보-은행코드 
 * issuerInfoDepositAccountNumber 발행인정보-입금계좌번호 
 * beneCorpIndvSortCode 수취인법인개인구분코드 
 * beneResidentBusinessNumber 수취인주민사업자번호 
 * beneCorpName 수취인법인명 
 * beneNameRepresentativeName 수취인성명(대표자명) 
 * beneAddress 수취인주소 
 * beneBankCode 수취인은행코드 
 * beneDepositAccountNumber 수취인입금계좌번호 
 * prohibitedInstructionYn 지시금지여부 
 * issuanceGuaranteeYn 발행보증여부 
 * splitCount 분할횟수 
 * splitDetailsArray 분할내역Array 
 * splitDetailsArray.splitDate (분할내역)분할일자 
 * splitDetailsArray.splitNumber (분할내역)분할번호 
 * splitDetailsArray.endorsementAmountRemainingAmount (분할내역)배서금액(잔존금액) 
 * splitDetailsArray.eNoteProcessStatus (분할내역)전자어음처리상태 
 * 
 * KftEnt0200530000 kftEnt0200530000 = new KftEnt0200530000(); // 발행 후 분할기준 분할내역 조회 요청
 * kftEnt0200530000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200530000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200530000.setBnkCd("057"); // 은행코드
 * kftEnt0200530000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200530000.setTransactionCode("530000"); // 거래구분코드
 * kftEnt0200530000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200530000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200530000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200530000.setStatus("000"); // STATUS
 * kftEnt0200530000.setResponseCode1(""); // 응답코드1
 * kftEnt0200530000.setResponseCode2(""); // 응답코드2
 * kftEnt0200530000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200530000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200530000.setUserSort(""); // 이용자구분
 * kftEnt0200530000.setENoteNumber(""); // 전자어음번호
 * kftEnt0200530000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200530000.setCurrentCreditAccountNumber(""); // 당좌(입금)계좌번호
 * kftEnt0200530000.setNoteInfoEnoteNumber(""); // 어음정보-전자어음번호
 * kftEnt0200530000.setNoteInfoNoteType(""); // 어음정보-어음종류
 * kftEnt0200530000.setNoteInfoEnoteIssueDate(""); // 어음정보-전자어음발행일자
 * kftEnt0200530000.setNoteInfoEnoteIssuePlace(""); // 어음정보-전자어음발행지
 * kftEnt0200530000.setNoteInfoEnoteAmount(0L); // 어음정보-전자어음금액
 * kftEnt0200530000.setNoteInfoEnoteMaturedDate(""); // 어음정보-전자어음만기일자
 * kftEnt0200530000.setNoteInfopaymentBankBranchCode(""); // 어음정보-지급은행및점포코드
 * kftEnt0200530000.setIssuerInfoIndvCorpSort(""); // 발행인정보-개인법인구분
 * kftEnt0200530000.setIssuerInfoResidentBusinessNumber(""); // 발행인정보-주민사업자번호
 * kftEnt0200530000.setIssuerInfoCorpName(""); // 발행인정보-법인명
 * kftEnt0200530000.setIssuerInfoNameRepresentative(""); // 발행인정보-성명(대표자명)
 * kftEnt0200530000.setIssuerInfoAddress(""); // 발행인정보주소
 * kftEnt0200530000.setIssuerInfoBankCode(""); // 발행인정보-은행코드
 * kftEnt0200530000.setIssuerInfoDepositAccountNumber(""); // 발행인정보-입금계좌번호
 * kftEnt0200530000.setBeneCorpIndvSortCode(""); // 수취인법인개인구분코드
 * kftEnt0200530000.setBeneResidentBusinessNumber(""); // 수취인주민사업자번호
 * kftEnt0200530000.setBeneCorpName(""); // 수취인법인명
 * kftEnt0200530000.setBeneNameRepresentativeName(""); // 수취인성명(대표자명)
 * kftEnt0200530000.setBeneAddress(""); // 수취인주소
 * kftEnt0200530000.setBeneBankCode(""); // 수취인은행코드
 * kftEnt0200530000.setBeneDepositAccountNumber(""); // 수취인입금계좌번호
 * kftEnt0200530000.setProhibitedInstructionYn(""); // 지시금지여부
 * kftEnt0200530000.setIssuanceGuaranteeYn(""); // 발행보증여부
 * kftEnt0200530000.setSplitCount(0); // 분할횟수
 * KftEnt0200530000.SplitDetails splitDetails = new KftEnt0200530000.SplitDetails(); // 분할내역Array
 * splitDetails.setSplitDate(""); // (분할내역)분할일자
 * splitDetails.setSplitNumber(""); // (분할내역)분할번호
 * splitDetails.setEndorsementAmountRemainingAmount(0L); // (분할내역)배서금액(잔존금액)
 * splitDetails.setENoteProcessStatus(""); // (분할내역)전자어음처리상태
 * kftEnt0200530000.getSplitDetailsArray().add(splitDetails); // 분할내역Array
 * }</pre>
 */
@Data
public class KftEnt0200530000 implements KftEntComHdr, Vo {

	/**
	 * 분할내역Array
	 * <pre>{@code
	 * splitDate (분할내역)분할일자 
	 * splitNumber (분할내역)분할번호 
	 * endorsementAmountRemainingAmount (분할내역)배서금액(잔존금액) 
	 * eNoteProcessStatus (분할내역)전자어음처리상태 
	 * 
	 * KftEnt0200530000.SplitDetails splitDetails = new KftEnt0200530000.SplitDetails(); // 분할내역Array
	 * splitDetails.setSplitDate(""); // (분할내역)분할일자
	 * splitDetails.setSplitNumber(""); // (분할내역)분할번호
	 * splitDetails.setEndorsementAmountRemainingAmount(0L); // (분할내역)배서금액(잔존금액)
	 * splitDetails.setENoteProcessStatus(""); // (분할내역)전자어음처리상태
	 * }</pre>
	 */
	@Data
	public static class SplitDetails implements Vo {

		private String splitDate; // (분할내역)분할일자
		private String splitNumber; // (분할내역)분할번호
		private long endorsementAmountRemainingAmount; // (분할내역)배서금액(잔존금액)
		private String eNoteProcessStatus; // (분할내역)전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String splitDate$; // (분할내역)분할일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String splitNumber$; // (분할내역)분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementAmountRemainingAmount$; // (분할내역)배서금액(잔존금액)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String eNoteProcessStatus$; // (분할내역)전자어음처리상태

		@Override
		public void write(OutputStream out) throws IOException {
			splitDate$ = VOUtils.write(out, splitDate, 8); // (분할내역)분할일자
			splitNumber$ = VOUtils.write(out, splitNumber, 2); // (분할내역)분할번호
			endorsementAmountRemainingAmount$ = VOUtils.write(out, endorsementAmountRemainingAmount, 15); // (분할내역)배서금액(잔존금액)
			eNoteProcessStatus$ = VOUtils.write(out, eNoteProcessStatus, 2); // (분할내역)전자어음처리상태
		}

		@Override
		public void read(InputStream in) throws IOException {
			splitDate = VOUtils.toString(splitDate$ = VOUtils.read(in, 8)); // (분할내역)분할일자
			splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // (분할내역)분할번호
			endorsementAmountRemainingAmount = VOUtils.toLong(endorsementAmountRemainingAmount$ = VOUtils.read(in, 15)); // (분할내역)배서금액(잔존금액)
			eNoteProcessStatus = VOUtils.toString(eNoteProcessStatus$ = VOUtils.read(in, 2)); // (분할내역)전자어음처리상태
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", splitDate=").append(splitDate).append(System.lineSeparator()); // (분할내역)분할일자
			sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // (분할내역)분할번호
			sb.append(", endorsementAmountRemainingAmount=").append(endorsementAmountRemainingAmount).append(System.lineSeparator()); // (분할내역)배서금액(잔존금액)
			sb.append(", eNoteProcessStatus=").append(eNoteProcessStatus).append(System.lineSeparator()); // (분할내역)전자어음처리상태
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "530000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String userSort; // 이용자구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String currentCreditAccountNumber; // 당좌(입금)계좌번호
	private String noteInfoEnoteNumber; // 어음정보-전자어음번호
	private String noteInfoNoteType; // 어음정보-어음종류
	private String noteInfoEnoteIssueDate; // 어음정보-전자어음발행일자
	private String noteInfoEnoteIssuePlace; // 어음정보-전자어음발행지
	private long noteInfoEnoteAmount; // 어음정보-전자어음금액
	private String noteInfoEnoteMaturedDate; // 어음정보-전자어음만기일자
	private String noteInfopaymentBankBranchCode; // 어음정보-지급은행및점포코드
	private String issuerInfoIndvCorpSort; // 발행인정보-개인법인구분
	private String issuerInfoResidentBusinessNumber; // 발행인정보-주민사업자번호
	private String issuerInfoCorpName; // 발행인정보-법인명
	private String issuerInfoNameRepresentative; // 발행인정보-성명(대표자명)
	private String issuerInfoAddress; // 발행인정보주소
	private String issuerInfoBankCode; // 발행인정보-은행코드
	private String issuerInfoDepositAccountNumber; // 발행인정보-입금계좌번호
	private String beneCorpIndvSortCode; // 수취인법인개인구분코드
	private String beneResidentBusinessNumber; // 수취인주민사업자번호
	private String beneCorpName; // 수취인법인명
	private String beneNameRepresentativeName; // 수취인성명(대표자명)
	private String beneAddress; // 수취인주소
	private String beneBankCode; // 수취인은행코드
	private String beneDepositAccountNumber; // 수취인입금계좌번호
	private String prohibitedInstructionYn; // 지시금지여부
	private String issuanceGuaranteeYn; // 발행보증여부
	private int splitCount; // 분할횟수
	private List<KftEnt0200530000.SplitDetails> splitDetailsArray = new ArrayList<>(); // 분할내역Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String userSort$; // 이용자구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCreditAccountNumber$; // 당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteNumber$; // 어음정보-전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoNoteType$; // 어음정보-어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteIssueDate$; // 어음정보-전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteIssuePlace$; // 어음정보-전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteAmount$; // 어음정보-전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteMaturedDate$; // 어음정보-전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfopaymentBankBranchCode$; // 어음정보-지급은행및점포코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoIndvCorpSort$; // 발행인정보-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoResidentBusinessNumber$; // 발행인정보-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpName$; // 발행인정보-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoNameRepresentative$; // 발행인정보-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoAddress$; // 발행인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoBankCode$; // 발행인정보-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoDepositAccountNumber$; // 발행인정보-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpIndvSortCode$; // 수취인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneResidentBusinessNumber$; // 수취인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpName$; // 수취인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneNameRepresentativeName$; // 수취인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneAddress$; // 수취인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneBankCode$; // 수취인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneDepositAccountNumber$; // 수취인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prohibitedInstructionYn$; // 지시금지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeYn$; // 발행보증여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitCount$; // 분할횟수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(userSort$)) { // 이용자구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(currentCreditAccountNumber$)) { // 당좌(입금)계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(noteInfoEnoteNumber$)) { // 어음정보-전자어음번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoResidentBusinessNumber$)) { // 발행인정보-주민사업자번호
			return 25;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoDepositAccountNumber$)) { // 발행인정보-입금계좌번호
			return 30;
		}
		if (VOUtils.isNotAlphanumericSpace(beneResidentBusinessNumber$)) { // 수취인주민사업자번호
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(beneDepositAccountNumber$)) { // 수취인입금계좌번호
			return 37;
		}
		if (VOUtils.isNotAlphanumericSpace(prohibitedInstructionYn$)) { // 지시금지여부
			return 38;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuaranteeYn$)) { // 발행보증여부
			return 39;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		splitCount = splitDetailsArray.size(); // 분할내역Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		userSort$ = VOUtils.write(out, userSort, 1); // 이용자구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentCreditAccountNumber$ = VOUtils.write(out, currentCreditAccountNumber, 16); // 당좌(입금)계좌번호
		noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // 어음정보-전자어음번호
		noteInfoNoteType$ = VOUtils.write(out, noteInfoNoteType, 1); // 어음정보-어음종류
		noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // 어음정보-전자어음발행일자
		noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // 어음정보-전자어음발행지
		noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // 어음정보-전자어음금액
		noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // 어음정보-전자어음만기일자
		noteInfopaymentBankBranchCode$ = VOUtils.write(out, noteInfopaymentBankBranchCode, 7); // 어음정보-지급은행및점포코드
		issuerInfoIndvCorpSort$ = VOUtils.write(out, issuerInfoIndvCorpSort, 1); // 발행인정보-개인법인구분
		issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // 발행인정보-주민사업자번호
		issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // 발행인정보-법인명
		issuerInfoNameRepresentative$ = VOUtils.write(out, issuerInfoNameRepresentative, 20, "EUC-KR"); // 발행인정보-성명(대표자명)
		issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // 발행인정보주소
		issuerInfoBankCode$ = VOUtils.write(out, issuerInfoBankCode, 3); // 발행인정보-은행코드
		issuerInfoDepositAccountNumber$ = VOUtils.write(out, issuerInfoDepositAccountNumber, 16); // 발행인정보-입금계좌번호
		beneCorpIndvSortCode$ = VOUtils.write(out, beneCorpIndvSortCode, 1); // 수취인법인개인구분코드
		beneResidentBusinessNumber$ = VOUtils.write(out, beneResidentBusinessNumber, 13); // 수취인주민사업자번호
		beneCorpName$ = VOUtils.write(out, beneCorpName, 40, "EUC-KR"); // 수취인법인명
		beneNameRepresentativeName$ = VOUtils.write(out, beneNameRepresentativeName, 20, "EUC-KR"); // 수취인성명(대표자명)
		beneAddress$ = VOUtils.write(out, beneAddress, 60, "EUC-KR"); // 수취인주소
		beneBankCode$ = VOUtils.write(out, beneBankCode, 3); // 수취인은행코드
		beneDepositAccountNumber$ = VOUtils.write(out, beneDepositAccountNumber, 16); // 수취인입금계좌번호
		prohibitedInstructionYn$ = VOUtils.write(out, prohibitedInstructionYn, 1); // 지시금지여부
		issuanceGuaranteeYn$ = VOUtils.write(out, issuanceGuaranteeYn, 1); // 발행보증여부
		splitCount$ = VOUtils.write(out, splitCount, 2); // 분할횟수
		VOUtils.write(out, splitDetailsArray, 5, KftEnt0200530000.SplitDetails::new); // 분할내역Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		userSort = VOUtils.toString(userSort$ = VOUtils.read(in, 1)); // 이용자구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentCreditAccountNumber = VOUtils.toString(currentCreditAccountNumber$ = VOUtils.read(in, 16)); // 당좌(입금)계좌번호
		noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // 어음정보-전자어음번호
		noteInfoNoteType = VOUtils.toString(noteInfoNoteType$ = VOUtils.read(in, 1)); // 어음정보-어음종류
		noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음발행일자
		noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음정보-전자어음발행지
		noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // 어음정보-전자어음금액
		noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음만기일자
		noteInfopaymentBankBranchCode = VOUtils.toString(noteInfopaymentBankBranchCode$ = VOUtils.read(in, 7)); // 어음정보-지급은행및점포코드
		issuerInfoIndvCorpSort = VOUtils.toString(issuerInfoIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인정보-개인법인구분
		issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인정보-주민사업자번호
		issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인정보-법인명
		issuerInfoNameRepresentative = VOUtils.toString(issuerInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인정보-성명(대표자명)
		issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인정보주소
		issuerInfoBankCode = VOUtils.toString(issuerInfoBankCode$ = VOUtils.read(in, 3)); // 발행인정보-은행코드
		issuerInfoDepositAccountNumber = VOUtils.toString(issuerInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // 발행인정보-입금계좌번호
		beneCorpIndvSortCode = VOUtils.toString(beneCorpIndvSortCode$ = VOUtils.read(in, 1)); // 수취인법인개인구분코드
		beneResidentBusinessNumber = VOUtils.toString(beneResidentBusinessNumber$ = VOUtils.read(in, 13)); // 수취인주민사업자번호
		beneCorpName = VOUtils.toString(beneCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 수취인법인명
		beneNameRepresentativeName = VOUtils.toString(beneNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인성명(대표자명)
		beneAddress = VOUtils.toString(beneAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 수취인주소
		beneBankCode = VOUtils.toString(beneBankCode$ = VOUtils.read(in, 3)); // 수취인은행코드
		beneDepositAccountNumber = VOUtils.toString(beneDepositAccountNumber$ = VOUtils.read(in, 16)); // 수취인입금계좌번호
		prohibitedInstructionYn = VOUtils.toString(prohibitedInstructionYn$ = VOUtils.read(in, 1)); // 지시금지여부
		issuanceGuaranteeYn = VOUtils.toString(issuanceGuaranteeYn$ = VOUtils.read(in, 1)); // 발행보증여부
		splitCount = VOUtils.toInt(splitCount$ = VOUtils.read(in, 2)); // 분할횟수
		splitDetailsArray = VOUtils.toVoList(in, splitCount, KftEnt0200530000.SplitDetails.class); // 분할내역Array
	}

	@Override
	public String toString() {
		splitCount = splitDetailsArray.size(); // 분할내역Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", userSort=").append(userSort).append(System.lineSeparator()); // 이용자구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentCreditAccountNumber=").append(currentCreditAccountNumber).append(System.lineSeparator()); // 당좌(입금)계좌번호
		sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // 어음정보-전자어음번호
		sb.append(", noteInfoNoteType=").append(noteInfoNoteType).append(System.lineSeparator()); // 어음정보-어음종류
		sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // 어음정보-전자어음발행일자
		sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // 어음정보-전자어음발행지
		sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // 어음정보-전자어음금액
		sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // 어음정보-전자어음만기일자
		sb.append(", noteInfopaymentBankBranchCode=").append(noteInfopaymentBankBranchCode).append(System.lineSeparator()); // 어음정보-지급은행및점포코드
		sb.append(", issuerInfoIndvCorpSort=").append(issuerInfoIndvCorpSort).append(System.lineSeparator()); // 발행인정보-개인법인구분
		sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행인정보-주민사업자번호
		sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // 발행인정보-법인명
		sb.append(", issuerInfoNameRepresentative=").append(issuerInfoNameRepresentative).append(System.lineSeparator()); // 발행인정보-성명(대표자명)
		sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // 발행인정보주소
		sb.append(", issuerInfoBankCode=").append(issuerInfoBankCode).append(System.lineSeparator()); // 발행인정보-은행코드
		sb.append(", issuerInfoDepositAccountNumber=").append(issuerInfoDepositAccountNumber).append(System.lineSeparator()); // 발행인정보-입금계좌번호
		sb.append(", beneCorpIndvSortCode=").append(beneCorpIndvSortCode).append(System.lineSeparator()); // 수취인법인개인구분코드
		sb.append(", beneResidentBusinessNumber=").append(beneResidentBusinessNumber).append(System.lineSeparator()); // 수취인주민사업자번호
		sb.append(", beneCorpName=").append(beneCorpName).append(System.lineSeparator()); // 수취인법인명
		sb.append(", beneNameRepresentativeName=").append(beneNameRepresentativeName).append(System.lineSeparator()); // 수취인성명(대표자명)
		sb.append(", beneAddress=").append(beneAddress).append(System.lineSeparator()); // 수취인주소
		sb.append(", beneBankCode=").append(beneBankCode).append(System.lineSeparator()); // 수취인은행코드
		sb.append(", beneDepositAccountNumber=").append(beneDepositAccountNumber).append(System.lineSeparator()); // 수취인입금계좌번호
		sb.append(", prohibitedInstructionYn=").append(prohibitedInstructionYn).append(System.lineSeparator()); // 지시금지여부
		sb.append(", issuanceGuaranteeYn=").append(issuanceGuaranteeYn).append(System.lineSeparator()); // 발행보증여부
		sb.append(", splitCount=").append(splitCount).append(System.lineSeparator()); // 분할횟수
		sb.append(", splitDetailsArray=").append(splitDetailsArray).append(System.lineSeparator()); // 분할내역Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "530000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "userSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfopaymentBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prohibitedInstructionYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "splitCount", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "splitDetailsArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "splitDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementAmountRemainingAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteProcessStatus", "fldLen", "2", "defltVal", "")
		);
	}

}
