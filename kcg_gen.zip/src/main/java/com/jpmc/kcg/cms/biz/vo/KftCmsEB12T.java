package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (은행접수)출금이체신청결과내역
 * <pre>{@code
 * KftCmsEB12T kftCmsEB12T  = new KftCmsEB12T(); // (은행접수)출금이체신청결과내역
 * kftCmsEB12T.setRecordType(""); // Record 구분
 * kftCmsEB12T.setSerialNumber(""); // 일련번호
 * kftCmsEB12T.setInstitutionCode(""); // 기관코드
 * kftCmsEB12T.setFileName(""); // File 이름
 * kftCmsEB12T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEB12T.setRegisterFailedCountRegistration(0); // 등록불능건수-신규등록
 * kftCmsEB12T.setRegisterFailedCountModification(0); // 등록불능건수-변경등록
 * kftCmsEB12T.setRegisterFailedCountTermination(0); // 등록불능건수-해지등록
 * kftCmsEB12T.setRegisterFailedCountArbitraryTermination(0); // 등록불능건수-임의해지
 * kftCmsEB12T.setFiller2(""); // FILLER
 * kftCmsEB12T.setMacValue(""); // MAC 검증값
 * }</pre>
 */
@Data
public class KftCmsEB12T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int registerFailedCountRegistration; // 등록불능건수-신규등록
	private int registerFailedCountModification; // 등록불능건수-변경등록
	private int registerFailedCountTermination; // 등록불능건수-해지등록
	private int registerFailedCountArbitraryTermination; // 등록불능건수-임의해지
	private String filler2; // FILLER
	private String macValue; // MAC 검증값
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerFailedCountRegistration$; // 등록불능건수-신규등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerFailedCountModification$; // 등록불능건수-변경등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerFailedCountTermination$; // 등록불능건수-해지등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerFailedCountArbitraryTermination$; // 등록불능건수-임의해지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		registerFailedCountRegistration$ = VOUtils.write(out, registerFailedCountRegistration, 8); // 등록불능건수-신규등록
		registerFailedCountModification$ = VOUtils.write(out, registerFailedCountModification, 8); // 등록불능건수-변경등록
		registerFailedCountTermination$ = VOUtils.write(out, registerFailedCountTermination, 8); // 등록불능건수-해지등록
		registerFailedCountArbitraryTermination$ = VOUtils.write(out, registerFailedCountArbitraryTermination, 8); // 등록불능건수-임의해지
		filler2$ = VOUtils.write(out, filler2, 43); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		registerFailedCountRegistration = VOUtils.toInt(registerFailedCountRegistration$ = VOUtils.read(in, 8)); // 등록불능건수-신규등록
		registerFailedCountModification = VOUtils.toInt(registerFailedCountModification$ = VOUtils.read(in, 8)); // 등록불능건수-변경등록
		registerFailedCountTermination = VOUtils.toInt(registerFailedCountTermination$ = VOUtils.read(in, 8)); // 등록불능건수-해지등록
		registerFailedCountArbitraryTermination = VOUtils.toInt(registerFailedCountArbitraryTermination$ = VOUtils.read(in, 8)); // 등록불능건수-임의해지
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 43)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", registerFailedCountRegistration=").append(registerFailedCountRegistration).append(System.lineSeparator()); // 등록불능건수-신규등록
		sb.append(", registerFailedCountModification=").append(registerFailedCountModification).append(System.lineSeparator()); // 등록불능건수-변경등록
		sb.append(", registerFailedCountTermination=").append(registerFailedCountTermination).append(System.lineSeparator()); // 등록불능건수-해지등록
		sb.append(", registerFailedCountArbitraryTermination=").append(registerFailedCountArbitraryTermination).append(System.lineSeparator()); // 등록불능건수-임의해지
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerFailedCountRegistration", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerFailedCountModification", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerFailedCountTermination", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerFailedCountArbitraryTermination", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "43", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
