package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금융공동망 수수료 차감표
 * <pre>{@code
 * KftHofEL0044R kftHofEL0044R  = new KftHofEL0044R(); // 전자금융공동망 수수료 차감표
 * kftHofEL0044R.setFileName(""); // 업무구분
 * kftHofEL0044R.setDataType(""); // 데이타구분
 * kftHofEL0044R.setSerialNumber(""); // 일련번호
 * kftHofEL0044R.setContentType(""); // 내용구분
 * kftHofEL0044R.setTransactionCode(""); // 거래구분코드
 * kftHofEL0044R.setBnkCd1(""); // 은행코드
 * kftHofEL0044R.setCreditDifference(""); // 차변차액
 * kftHofEL0044R.setCreditFeeAmount(0L); // 차변수수료금액
 * kftHofEL0044R.setCreditCount(0L); // 차변건수
 * kftHofEL0044R.setDebitCount(0L); // 대변건수
 * kftHofEL0044R.setDebitFeeAmount(0L); // 대변수수료금액
 * kftHofEL0044R.setDebitDifference(""); // 대변차액
 * kftHofEL0044R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0044R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String contentType; // 내용구분
	private String transactionCode; // 거래구분코드
	private String bnkCd1; // 은행코드
	private String creditDifference; // 차변차액
	private long creditFeeAmount; // 차변수수료금액
	private long creditCount; // 차변건수
	private long debitCount; // 대변건수
	private long debitFeeAmount; // 대변수수료금액
	private String debitDifference; // 대변차액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String contentType$; // 내용구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd1$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditDifference$; // 차변차액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditFeeAmount$; // 차변수수료금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCount$; // 차변건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCount$; // 대변건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitFeeAmount$; // 대변수수료금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitDifference$; // 대변차액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		contentType$ = VOUtils.write(out, contentType, 1); // 내용구분
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		bnkCd1$ = VOUtils.write(out, bnkCd1, 3); // 은행코드
		creditDifference$ = VOUtils.write(out, creditDifference, 16); // 차변차액
		creditFeeAmount$ = VOUtils.write(out, creditFeeAmount, 16); // 차변수수료금액
		creditCount$ = VOUtils.write(out, creditCount, 10); // 차변건수
		debitCount$ = VOUtils.write(out, debitCount, 10); // 대변건수
		debitFeeAmount$ = VOUtils.write(out, debitFeeAmount, 16); // 대변수수료금액
		debitDifference$ = VOUtils.write(out, debitDifference, 16); // 대변차액
		filler$ = VOUtils.write(out, filler, 1); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		contentType = VOUtils.toString(contentType$ = VOUtils.read(in, 1)); // 내용구분
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		bnkCd1 = VOUtils.toString(bnkCd1$ = VOUtils.read(in, 3)); // 은행코드
		creditDifference = VOUtils.toString(creditDifference$ = VOUtils.read(in, 16)); // 차변차액
		creditFeeAmount = VOUtils.toLong(creditFeeAmount$ = VOUtils.read(in, 16)); // 차변수수료금액
		creditCount = VOUtils.toLong(creditCount$ = VOUtils.read(in, 10)); // 차변건수
		debitCount = VOUtils.toLong(debitCount$ = VOUtils.read(in, 10)); // 대변건수
		debitFeeAmount = VOUtils.toLong(debitFeeAmount$ = VOUtils.read(in, 16)); // 대변수수료금액
		debitDifference = VOUtils.toString(debitDifference$ = VOUtils.read(in, 16)); // 대변차액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 1)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", contentType=").append(contentType).append(System.lineSeparator()); // 내용구분
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", bnkCd1=").append(bnkCd1).append(System.lineSeparator()); // 은행코드
		sb.append(", creditDifference=").append(creditDifference).append(System.lineSeparator()); // 차변차액
		sb.append(", creditFeeAmount=").append(creditFeeAmount).append(System.lineSeparator()); // 차변수수료금액
		sb.append(", creditCount=").append(creditCount).append(System.lineSeparator()); // 차변건수
		sb.append(", debitCount=").append(debitCount).append(System.lineSeparator()); // 대변건수
		sb.append(", debitFeeAmount=").append(debitFeeAmount).append(System.lineSeparator()); // 대변수수료금액
		sb.append(", debitDifference=").append(debitDifference).append(System.lineSeparator()); // 대변차액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "contentType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "bnkCd1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "creditDifference", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditFeeAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitFeeAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitDifference", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "1", "defltVal", "")
		);
	}

}
