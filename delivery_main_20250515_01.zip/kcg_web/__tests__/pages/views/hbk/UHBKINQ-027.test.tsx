import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// UHBKINQ027 컴포넌트를 불러옵니다.
import UHBKINQ027 from "@/pages/views/hbk/UHBKINQ-027"
import { Component } from "@/hoc/TestUtil"

const component = Component(UHBKINQ027)

describe("[UHBKINQ-027] 거래내역조회", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValueOnce("20240101")
  })

  beforeEach(() => {
    mockUseParams.mockReturnValue({
      params: undefined,
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        codeList: [
          {
            codeField: "test",
            labelField: "test",
          },
        ],
      },
    })
  })

  it("useEffect Test", async () => {
    mockUseProxy.mockAsync.mockRestore()
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          codeList: undefined,
        },
      })
      .mockResolvedValueOnce({
        data: {
          listOut: undefined,
          totCnt: 0,
          sumOut: {},
        },
      })

    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {},
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it.each(["01", "02", "03", "04", "05", "06", "07", "08", "09"])(
    "handleSrchCondChange Test",
    async (srchCondDvsn) => {
      const { findByTestId } = render(component)
      const srchCondDvsnTestBtn = await within(
        await findByTestId(/SCRNITM#srchCondDvsn/),
      ).findByTestId("onChange")
      fireEvent.click(srchCondDvsnTestBtn, { target: { data: srchCondDvsn } })
    },
  )

  it("searchListTransaction Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totCnt: 0,
        sumOut: {},
        listOut: [],
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totCnt: 0,
        sumOut: {},
        listOut: undefined,
      },
    })
    render(component)
    pagingHandling[0](null, 2)
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)

    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {},
      },
    })
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each([
    {
      respCd: "01",
      hbkInitInstRespCd: "01",
      hbkRespCd: "01",
    },
    {
      respCd: null,
      hbkInitInstRespCd: null,
      hbkRespCd: null,
    },
  ])("valueGetter Test", async (param) => {
    const { findByText } = render(component)

    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: param,
      },
    })
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each([
    {
      trStsCd: "91",
    },
    {
      trStsCd: "01",
      outinDvsnCd: "01",
    },
    {
      trStsCd: "03",
      outinDvsnCd: "01",
    },

    {
      trStsCd: "04",
      outinDvsnCd: "01",
    },
    {
      trStsCd: "03",
      outinDvsnCd: "02",
    },
    {
      trStsCd: "04",
      outinDvsnCd: "02",
    },
    {
      trStsCd: "03",
      outinDvsnCd: "03",
    },
  ])("cellStyle Test", async (param) => {
    const { findByText } = render(component)

    const cellStyleTestBtn = await findByText(/cellStyle Test/)
    fireEvent.click(cellStyleTestBtn, {
      target: {
        data: param,
      },
    })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each(["XXXX451000", "XXXX451001"])(
    "onRowClicked Test",
    async (tlgKndTrDvsnCd) => {
      const { findByText } = render(component)
      const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
      fireEvent.click(onRowClickedTestBtn, {
        target: {
          data: {
            tlgKndTrDvsnCd: tlgKndTrDvsnCd,
          },
        },
      })

      await waitFor(() => {
        expect(mockUseProxy.mockAsync).toHaveBeenCalled()
      })
    },
  )

  it("onRowDoubleClicked Test", async () => {
    const { findByText } = render(component)

    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {},
      },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("downloadHbkTransactionExcelList Test", async () => {
    mockUseForm.mockValidate.mockResolvedValueOnce({})

    const { findByText } = render(component)
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - selectedRows.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const pdfBtn = await findByText(/^pdf$/)
    fireEvent.click(pdfBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - download resolved", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        trDt: "",
        outinDvsnCd: "",
        totTrAmt: "",
        opnBnkCd: "",
        rcvAcctNo: "",
        whdrwlAcctNo: "",
        hndlBnkCd: "",
        rcpntNm: "",
        respCd: "",
        rqerNm: "",
        sndrRealNm: "",
        respMsg: "",
      },
    ])
    mockUseProxy.mockDownload.mockResolvedValueOnce({})
    const { findByText } = render(component)
    const pdfBtn = await findByText(/^pdf$/)
    fireEvent.click(pdfBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - download rejected", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        trDt: "",
        outinDvsnCd: "",
        totTrAmt: "",
        opnBnkCd: "",
        rcvAcctNo: "",
        whdrwlAcctNo: "",
        hndlBnkCd: "",
        rcpntNm: "",
        respCd: "",
        rqerNm: "",
        sndrRealNm: "",
        respMsg: "",
      },
    ])
    mockUseProxy.mockDownload.mockRejectedValueOnce({})
    const { findByText } = render(component)
    const pdfBtn = await findByText(/^pdf$/)
    fireEvent.click(pdfBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - selectedRows.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const receiptBtn = await findByText(/^SCRNITM#receipt$/)
    fireEvent.click(receiptBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - download resolved", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        trDt: "",
        outinDvsnCd: "",
        totTrAmt: "",
        opnBnkCd: "",
        rcvAcctNo: "",
        whdrwlAcctNo: "",
        hndlBnkCd: "",
        rcpntNm: "",
        respCd: "",
        rqerNm: "",
        sndrRealNm: "",
        respMsg: "",
      },
    ])
    mockUseProxy.mockDownload.mockResolvedValueOnce({})
    const { findByText } = render(component)
    const receiptBtn = await findByText(/^SCRNITM#receipt$/)
    fireEvent.click(receiptBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - download rejected", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        trDt: "",
        outinDvsnCd: "",
        totTrAmt: "",
        opnBnkCd: "",
        rcvAcctNo: "",
        whdrwlAcctNo: "",
        hndlBnkCd: "",
        rcpntNm: "",
        respCd: "",
        rqerNm: "",
        sndrRealNm: "",
        respMsg: "",
      },
    ])
    mockUseProxy.mockDownload.mockRejectedValueOnce({})
    const { findByText } = render(component)
    const receiptBtn = await findByText(/^SCRNITM#receipt$/)
    fireEvent.click(receiptBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("getDisplayText Test", async () => {
    const { findAllByTestId } = render(component)
    const outInDvsnCdTestBtn = await within(
      (
        await findAllByTestId(/SCRNITM#tp/)
      )[0],
    ).findByTestId("onChange")
    fireEvent.click(outInDvsnCdTestBtn, {
      target: {
        data: "01",
      },
    })

    fireEvent.click(outInDvsnCdTestBtn, {
      target: {
        data: "02",
      },
    })
  })

  // sendAlarm 주석 처리
  // it("sendAlarm Test - confirm", async () => {
  //   mockUseModal.mockConfirm.mockResolvedValueOnce(true)
  //   mockUseProxy.mockAsync.mockResolvedValueOnce({})
  //   const { findByText } = render(component)
  //   const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
  //   fireEvent.click(onRowClickedTestBtn, {
  //     target: {
  //       data: {
  //         tlgKndTrDvsnCd: "0101451000",
  //       },
  //     },
  //   })

  //   const actBtn = await findByText(/SCRNITM#act/)
  //   fireEvent.click(actBtn)

  //   await waitFor(() => {
  //     expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
  //   })
  // })

  // it("sendAlarm Test - not confirm", async () => {
  //   mockUseModal.mockConfirm.mockResolvedValueOnce(false)

  //   const { findByText } = render(component)
  //   const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
  //   fireEvent.click(onRowClickedTestBtn, {
  //     target: {
  //       data: {
  //         tlgKndTrDvsnCd: "0101451000",
  //       },
  //     },
  //   })

  //   const actBtn = await findByText(/SCRNITM#act/)
  //   fireEvent.click(actBtn)

  //   await waitFor(() => {
  //     expect(mockUseProxy.mockAsync).not.toHaveBeenCalledTimes(2)
  //   })
  // })

  it("onChange Test", async () => {
    const { findAllByTestId } = render(component)

    const onChangeTestBtns = await findAllByTestId("onChange")
    onChangeTestBtns.forEach((onChangeTestBtn) => {
      fireEvent.click(onChangeTestBtn, { target: { data: "01" } })
    })
  })

  it.each([
    {
      mocking: () => {
        mockUseForm.mockGetValues.mockImplementation((param) => {
          switch (param) {
            case "trStrDt":
              return "20240101"
            case "trEndDt":
              return "20241231"
            default:
              return param
          }
        })
      },
      expect: () => {
        expect(mockUseForm.mockGetValues).toHaveReturnedWith("20240101")
        expect(mockUseForm.mockGetValues).toHaveReturnedWith("20241231")
      },
    },
  ])("validItem Test", async (param) => {
    param.mocking()
    const { findByTestId } = render(component)

    const srchToDtEl = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(srchToDtEl, {
      target: {
        data: "",
      },
    })

    await waitFor(() => {
      param.expect()
    })
  })
})
