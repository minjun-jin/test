package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 발행인 신용조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 440000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * residentBusinessNumber 주민사업자번호 
 * currentAccountNumber 당좌계좌번호 
 * corpIndvSort (조회결과)개인법인구분 
 * corpName (조회결과)법인명 
 * nameRepresentativeName (조회결과)성명(대표자명) 
 * defaultYn (조회결과)부도여부 
 * defaultNumber (조회결과)부도회차 
 * currentTransactionStopYn (조회결과)당좌거래정지여부 
 * currentTransactionStopDate (조회결과)당좌거래정지일자 
 * companySize (조회결과)기업규모 
 * bizType (조회결과)업종 
 * paymentBankCode (조회결과)지급은행코드 
 * paymentBankBranchCode (조회결과)지급은행지점코드 
 * paymentBranchClearingHouseCode (조회결과)지급점포어음교환소코드 
 * issuanceLimitAmount (조회결과)발행한도금액 
 * currentTransactionStartDate (조회결과)당좌거래개시일 
 * currentTransactionTerminationYn (조회결과)당좌거래해지여부 
 * currentTransactionTerminationDate (조회결과)당좌거래해지일자 
 * 
 * KftEnt0200440000 kftEnt0200440000 = new KftEnt0200440000(); // 발행인 신용조회 요청
 * kftEnt0200440000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200440000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200440000.setBnkCd("057"); // 은행코드
 * kftEnt0200440000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200440000.setTransactionCode("440000"); // 거래구분코드
 * kftEnt0200440000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200440000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200440000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200440000.setStatus("000"); // STATUS
 * kftEnt0200440000.setResponseCode1(""); // 응답코드1
 * kftEnt0200440000.setResponseCode2(""); // 응답코드2
 * kftEnt0200440000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200440000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200440000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200440000.setCurrentAccountNumber(""); // 당좌계좌번호
 * kftEnt0200440000.setCorpIndvSort(""); // (조회결과)개인법인구분
 * kftEnt0200440000.setCorpName(""); // (조회결과)법인명
 * kftEnt0200440000.setNameRepresentativeName(""); // (조회결과)성명(대표자명)
 * kftEnt0200440000.setDefaultYn(""); // (조회결과)부도여부
 * kftEnt0200440000.setDefaultNumber(""); // (조회결과)부도회차
 * kftEnt0200440000.setCurrentTransactionStopYn(""); // (조회결과)당좌거래정지여부
 * kftEnt0200440000.setCurrentTransactionStopDate(""); // (조회결과)당좌거래정지일자
 * kftEnt0200440000.setCompanySize(""); // (조회결과)기업규모
 * kftEnt0200440000.setBizType(""); // (조회결과)업종
 * kftEnt0200440000.setPaymentBankCode(""); // (조회결과)지급은행코드
 * kftEnt0200440000.setPaymentBankBranchCode(""); // (조회결과)지급은행지점코드
 * kftEnt0200440000.setPaymentBranchClearingHouseCode(""); // (조회결과)지급점포어음교환소코드
 * kftEnt0200440000.setIssuanceLimitAmount(0L); // (조회결과)발행한도금액
 * kftEnt0200440000.setCurrentTransactionStartDate(""); // (조회결과)당좌거래개시일
 * kftEnt0200440000.setCurrentTransactionTerminationYn(""); // (조회결과)당좌거래해지여부
 * kftEnt0200440000.setCurrentTransactionTerminationDate(""); // (조회결과)당좌거래해지일자
 * }</pre>
 */
@Data
public class KftEnt0200440000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "440000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String residentBusinessNumber; // 주민사업자번호
	private String currentAccountNumber; // 당좌계좌번호
	private String corpIndvSort; // (조회결과)개인법인구분
	private String corpName; // (조회결과)법인명
	private String nameRepresentativeName; // (조회결과)성명(대표자명)
	private String defaultYn; // (조회결과)부도여부
	private String defaultNumber; // (조회결과)부도회차
	private String currentTransactionStopYn; // (조회결과)당좌거래정지여부
	private String currentTransactionStopDate; // (조회결과)당좌거래정지일자
	private String companySize; // (조회결과)기업규모
	private String bizType; // (조회결과)업종
	private String paymentBankCode; // (조회결과)지급은행코드
	private String paymentBankBranchCode; // (조회결과)지급은행지점코드
	private String paymentBranchClearingHouseCode; // (조회결과)지급점포어음교환소코드
	private long issuanceLimitAmount; // (조회결과)발행한도금액
	private String currentTransactionStartDate; // (조회결과)당좌거래개시일
	private String currentTransactionTerminationYn; // (조회결과)당좌거래해지여부
	private String currentTransactionTerminationDate; // (조회결과)당좌거래해지일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentAccountNumber$; // 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpIndvSort$; // (조회결과)개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpName$; // (조회결과)법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nameRepresentativeName$; // (조회결과)성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultYn$; // (조회결과)부도여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultNumber$; // (조회결과)부도회차
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentTransactionStopYn$; // (조회결과)당좌거래정지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentTransactionStopDate$; // (조회결과)당좌거래정지일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String companySize$; // (조회결과)기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bizType$; // (조회결과)업종
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // (조회결과)지급은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankBranchCode$; // (조회결과)지급은행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // (조회결과)지급점포어음교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceLimitAmount$; // (조회결과)발행한도금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentTransactionStartDate$; // (조회결과)당좌거래개시일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentTransactionTerminationYn$; // (조회결과)당좌거래해지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentTransactionTerminationDate$; // (조회결과)당좌거래해지일자

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(currentAccountNumber$)) { // 당좌계좌번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(defaultYn$)) { // (조회결과)부도여부
			return 18;
		}
		if (VOUtils.isNotAlphanumericSpace(currentTransactionStopYn$)) { // (조회결과)당좌거래정지여부
			return 20;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentAccountNumber$ = VOUtils.write(out, currentAccountNumber, 16); // 당좌계좌번호
		corpIndvSort$ = VOUtils.write(out, corpIndvSort, 1); // (조회결과)개인법인구분
		corpName$ = VOUtils.write(out, corpName, 40, "EUC-KR"); // (조회결과)법인명
		nameRepresentativeName$ = VOUtils.write(out, nameRepresentativeName, 20, "EUC-KR"); // (조회결과)성명(대표자명)
		defaultYn$ = VOUtils.write(out, defaultYn, 1); // (조회결과)부도여부
		defaultNumber$ = VOUtils.write(out, defaultNumber, 1); // (조회결과)부도회차
		currentTransactionStopYn$ = VOUtils.write(out, currentTransactionStopYn, 1); // (조회결과)당좌거래정지여부
		currentTransactionStopDate$ = VOUtils.write(out, currentTransactionStopDate, 8); // (조회결과)당좌거래정지일자
		companySize$ = VOUtils.write(out, companySize, 1); // (조회결과)기업규모
		bizType$ = VOUtils.write(out, bizType, 2); // (조회결과)업종
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 3); // (조회결과)지급은행코드
		paymentBankBranchCode$ = VOUtils.write(out, paymentBankBranchCode, 4); // (조회결과)지급은행지점코드
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // (조회결과)지급점포어음교환소코드
		issuanceLimitAmount$ = VOUtils.write(out, issuanceLimitAmount, 15); // (조회결과)발행한도금액
		currentTransactionStartDate$ = VOUtils.write(out, currentTransactionStartDate, 8); // (조회결과)당좌거래개시일
		currentTransactionTerminationYn$ = VOUtils.write(out, currentTransactionTerminationYn, 1); // (조회결과)당좌거래해지여부
		currentTransactionTerminationDate$ = VOUtils.write(out, currentTransactionTerminationDate, 8); // (조회결과)당좌거래해지일자
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentAccountNumber = VOUtils.toString(currentAccountNumber$ = VOUtils.read(in, 16)); // 당좌계좌번호
		corpIndvSort = VOUtils.toString(corpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)개인법인구분
		corpName = VOUtils.toString(corpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)법인명
		nameRepresentativeName = VOUtils.toString(nameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)성명(대표자명)
		defaultYn = VOUtils.toString(defaultYn$ = VOUtils.read(in, 1)); // (조회결과)부도여부
		defaultNumber = VOUtils.toString(defaultNumber$ = VOUtils.read(in, 1)); // (조회결과)부도회차
		currentTransactionStopYn = VOUtils.toString(currentTransactionStopYn$ = VOUtils.read(in, 1)); // (조회결과)당좌거래정지여부
		currentTransactionStopDate = VOUtils.toString(currentTransactionStopDate$ = VOUtils.read(in, 8)); // (조회결과)당좌거래정지일자
		companySize = VOUtils.toString(companySize$ = VOUtils.read(in, 1)); // (조회결과)기업규모
		bizType = VOUtils.toString(bizType$ = VOUtils.read(in, 2)); // (조회결과)업종
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 3)); // (조회결과)지급은행코드
		paymentBankBranchCode = VOUtils.toString(paymentBankBranchCode$ = VOUtils.read(in, 4)); // (조회결과)지급은행지점코드
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // (조회결과)지급점포어음교환소코드
		issuanceLimitAmount = VOUtils.toLong(issuanceLimitAmount$ = VOUtils.read(in, 15)); // (조회결과)발행한도금액
		currentTransactionStartDate = VOUtils.toString(currentTransactionStartDate$ = VOUtils.read(in, 8)); // (조회결과)당좌거래개시일
		currentTransactionTerminationYn = VOUtils.toString(currentTransactionTerminationYn$ = VOUtils.read(in, 1)); // (조회결과)당좌거래해지여부
		currentTransactionTerminationDate = VOUtils.toString(currentTransactionTerminationDate$ = VOUtils.read(in, 8)); // (조회결과)당좌거래해지일자
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentAccountNumber=").append(currentAccountNumber).append(System.lineSeparator()); // 당좌계좌번호
		sb.append(", corpIndvSort=").append(corpIndvSort).append(System.lineSeparator()); // (조회결과)개인법인구분
		sb.append(", corpName=").append(corpName).append(System.lineSeparator()); // (조회결과)법인명
		sb.append(", nameRepresentativeName=").append(nameRepresentativeName).append(System.lineSeparator()); // (조회결과)성명(대표자명)
		sb.append(", defaultYn=").append(defaultYn).append(System.lineSeparator()); // (조회결과)부도여부
		sb.append(", defaultNumber=").append(defaultNumber).append(System.lineSeparator()); // (조회결과)부도회차
		sb.append(", currentTransactionStopYn=").append(currentTransactionStopYn).append(System.lineSeparator()); // (조회결과)당좌거래정지여부
		sb.append(", currentTransactionStopDate=").append(currentTransactionStopDate).append(System.lineSeparator()); // (조회결과)당좌거래정지일자
		sb.append(", companySize=").append(companySize).append(System.lineSeparator()); // (조회결과)기업규모
		sb.append(", bizType=").append(bizType).append(System.lineSeparator()); // (조회결과)업종
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // (조회결과)지급은행코드
		sb.append(", paymentBankBranchCode=").append(paymentBankBranchCode).append(System.lineSeparator()); // (조회결과)지급은행지점코드
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // (조회결과)지급점포어음교환소코드
		sb.append(", issuanceLimitAmount=").append(issuanceLimitAmount).append(System.lineSeparator()); // (조회결과)발행한도금액
		sb.append(", currentTransactionStartDate=").append(currentTransactionStartDate).append(System.lineSeparator()); // (조회결과)당좌거래개시일
		sb.append(", currentTransactionTerminationYn=").append(currentTransactionTerminationYn).append(System.lineSeparator()); // (조회결과)당좌거래해지여부
		sb.append(", currentTransactionTerminationDate=").append(currentTransactionTerminationDate).append(System.lineSeparator()); // (조회결과)당좌거래해지일자
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "440000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "corpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "corpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "nameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "defaultYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultNumber", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "currentTransactionStopYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "currentTransactionStopDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "companySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bizType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "paymentBankBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuanceLimitAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "currentTransactionStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "currentTransactionTerminationYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "currentTransactionTerminationDate", "fldLen", "8", "defltVal", "")
		);
	}

}
