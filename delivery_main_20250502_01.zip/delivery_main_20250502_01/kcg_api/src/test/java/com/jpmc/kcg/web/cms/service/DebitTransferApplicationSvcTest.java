package com.jpmc.kcg.web.cms.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.cms.dao.CmsWhdrwlTrnAplyMMapper;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.cms.dao.CmsWhdrwlTrnAplyMWebDao;
import com.jpmc.kcg.web.cms.dto.CmsWhdrwlTrnAplyMWeb;
import com.jpmc.kcg.web.cms.service.dto.DebitTransferApplicationLedgerIn;
import com.jpmc.kcg.web.cms.service.dto.DebitTransferApplicationLedgerOut;
import com.jpmc.kcg.web.com.constants.BCMN01;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.utils.JwtUtils;

import lombok.extern.slf4j.Slf4j;

@ExtendWith(MockitoExtension.class)
@Slf4j
class DebitTransferApplicationSvcTest {

    @Mock
    private CmsWhdrwlTrnAplyMWebDao cmsWhdrwlTrnAplyMWebDao;

    @Mock
    private CmsWhdrwlTrnAplyMMapper cmsWhdrwlTrnAplyMMapper;

    @Mock
    private CommonApprovalSvc commonApprovalSvc;

    @Mock
    private JwtUtils jwtUtils;

    @InjectMocks
    private DebitTransferApplicationSvc debitTransferApplicationSvc;

    private static com.jpmc.kcg.web.frw.dto.Header header;

    private static MockedStatic<WebApplicationContext> webApplicationContext;

    @BeforeAll
    static void setup() {
        if (webApplicationContext == null) {
            webApplicationContext = mockStatic(WebApplicationContext.class);
            header = new Header();
            header.setStaffId("JUNIT");
            webApplicationContext.when(WebApplicationContext::getHeader).thenReturn(header);
        }
    }

    @AfterAll
    static void tearDown() {
        if (webApplicationContext != null) {
            webApplicationContext.close();
        }
    }

    @Test
    void test_valid_input_returns_correct_DebitTransferApplicationLedgerOut() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setRegStsCd("1");
        in.setRegDvsnCd("3");
        in.setAcctNo("1234567890");
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setStrtDt("20230101");
        in.setEndDt("20231231");

        lenient().when(jwtUtils.hasAnyStaticMakerRole()).thenReturn(true);

        List<CmsWhdrwlTrnAplyMWeb> mockList = List.of(new CmsWhdrwlTrnAplyMWeb(), new CmsWhdrwlTrnAplyMWeb());
        when(cmsWhdrwlTrnAplyMWebDao.selectCmsWhdrwlTrnAplyMList(any(CmsWhdrwlTrnAplyMWeb.class), anyString(), anyString(), anyBoolean())).thenReturn(mockList);

        // When
        DebitTransferApplicationLedgerOut result = debitTransferApplicationSvc.getListDebitTransferApplicationLedger(in);

        // Then
        assertNotNull(result);
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
        assertEquals(mockList.size(), result.getTotLen().intValue());
        assertEquals(2, result.getOutList().size());  // Assuming the count of the mocked list
    }

    //    필수값 체크 로직은 있으나 하지 않음.
//    @Test
//    void test_invalid_input_throws_BusinessException() {
//        // Given
//        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
//        in.setCorpCd(""); // Invalid input
//        in.setRtpyrId("RTP001");
//
//        // When & Then
//        assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.getListDebitTransferApplicationLedger(in));
//    }

    @Test
    void test_processDebitTransferApplication_create_success() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setRegStsCd("1");
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setTelNo("1234567890");
        in.setCrudType(BCMN01.CREATE);

        ComAprvHIn comAprvHIn = new ComAprvHIn();
        comAprvHIn.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());
        comAprvHIn.setAprvRqstDvsnCd(AprvRqstDvsnCdEnum.INSERT.getValue());
        comAprvHIn.setAprvKeyVal(StringUtils.join(in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()));

        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()))
                .thenReturn(null); // No existing record
        when(commonApprovalSvc.requestApproval(any(ComAprvHIn.class), any(), any(DebitTransferApplicationLedgerIn.class))).thenReturn(1);

        // When
        DebitTransferApplicationLedgerOut result = debitTransferApplicationSvc.processDebitTransferApplication(in);

        // Then
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
//        verify(commonApprovalSvc, times(1)).requestApproval(any(), isNull(), eq(in));
        verify(cmsWhdrwlTrnAplyMMapper, times(1)).insert(any());
    }

@Test
void test_processDebitTransferApplication_update_ERROR() {
    // Given
    DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
    in.setCorpCd("CORP001");
    in.setRtpyrId("RTP001");
    in.setAcctNo("1234567890");
    in.setRegStsCd("1");
    in.setAcctNm("John Doe");
    in.setCtzBizNo("123456789");
    in.setTelNo("1234567890");
    in.setCrudType(BCMN01.UPDATE);

    CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
    existingRecord.setRegStsCd("1");

    // When

    // Then
    assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.processDebitTransferApplication(in));
}

    @Test
    void test_processDebitTransferApplication_create_duplicate() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setRegStsCd("1");
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setTelNo("1234567890");
        in.setCrudType(BCMN01.CREATE);

        CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()))
                .thenReturn(existingRecord); // Existing record found

        // When & Then
        assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.processDebitTransferApplication(in));
    }

    @Test
    void test_processDebitTransferApplication_update_change_success() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("0987654321"); // 변경할 계좌번호
        in.setBeforeAcctNo("1234567890"); // 기존 계좌번호
        in.setRegStsCd("3"); // 변경 요청
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setCrudType(BCMN01.UPDATE);
    
        CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
        existingRecord.setAcctNo("1234567890");
        existingRecord.setRegStsCd("1");
    
        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(anyString(), anyString(), anyString()))
            .thenReturn(existingRecord);
    
        lenient().when(commonApprovalSvc.requestApproval(any(), any(), any())).thenReturn(1);
    
        // When
        DebitTransferApplicationLedgerOut result = debitTransferApplicationSvc.processDebitTransferApplication(in);
    
        // Then
        assertNotNull(result);
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
        verify(cmsWhdrwlTrnAplyMWebDao, times(1)).updateCmsWhdrwlTrnAplyM(any());
    }
    
    @Test
    void test_processDebitTransferApplication_default_case() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setRegStsCd("3");
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setCrudType("UNKNOWN"); // CREATE/UPDATE가 아님
    
        // When
        DebitTransferApplicationLedgerOut result = debitTransferApplicationSvc.processDebitTransferApplication(in);
    
        // Then
        assertNotNull(result);
        assertEquals(BCMN01.FAIL, result.getRsltCode());
    }

    @Test
    void test_processDebitTransferApplication_terminate_existing() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setRegStsCd("3"); // Termination status
        in.setCrudType(BCMN01.UPDATE);

        CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
        existingRecord.setRegStsCd("3"); // Already terminated

//        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()))
//                .thenReturn(existingRecord); // Existing record found

        // When & Then
        assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.processDebitTransferApplication(in));
    }
    
    @Test
    void test_processDebitTransferApplication_update_terminate_twice_error() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setBeforeAcctNo("1234567890");
        in.setRegStsCd("3"); // TERMINATION 요청
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setCrudType(BCMN01.UPDATE);
    
        CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
        existingRecord.setAcctNo("1234567890");
        existingRecord.setRegStsCd("3"); // 이미 TERMINATION 상태
    
        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(anyString(), anyString(), anyString()))
            .thenReturn(existingRecord);
    
        // When & Then
        BusinessException ex = assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.processDebitTransferApplication(in));
        assertEquals("MCMNI01017", ex.getErrorCode()); // 해지건에 대해 또 해지하려 할 때
    }

    @Test
    void test_processDebitTransferApplication_update_same_account_error() {
        // Given
        DebitTransferApplicationLedgerIn in = new DebitTransferApplicationLedgerIn();
        in.setCorpCd("CORP001");
        in.setRtpyrId("RTP001");
        in.setAcctNo("1234567890");
        in.setBeforeAcctNo("1234567890");
        in.setRegStsCd("2"); // 변경 요청
        in.setAcctNm("John Doe");
        in.setCtzBizNo("123456789");
        in.setCrudType(BCMN01.UPDATE);
    
        CmsWhdrwlTrnAplyM existingRecord = new CmsWhdrwlTrnAplyM();
        existingRecord.setAcctNo("1234567890");
        existingRecord.setRegStsCd("1"); // 정상 등록 상태
    
        when(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(anyString(), anyString(), anyString()))
            .thenReturn(existingRecord);
    
        // When & Then
        BusinessException ex = assertThrows(BusinessException.class, () -> debitTransferApplicationSvc.processDebitTransferApplication(in));
        assertEquals("MCMNE11014", ex.getErrorCode()); // 기존 계좌와 변경 계좌가 같을 때 발생
    }
}
