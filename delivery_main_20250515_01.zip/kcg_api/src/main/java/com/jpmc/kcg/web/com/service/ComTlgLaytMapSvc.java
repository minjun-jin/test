package com.jpmc.kcg.web.com.service;

import java.util.*;

import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.com.dto.CmnTlgLaytMapD;
import com.jpmc.kcg.web.com.dto.ComTlgLaytMapAprv;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.com.enums.AprvTpCdEnum;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import org.springframework.beans.BeanUtils;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmc.kcg.com.dto.ComTlgLaytMapD;
import com.jpmc.kcg.com.dto.ComTlgLaytMapM;
import com.jpmc.kcg.web.com.constants.BCMN01;
import com.jpmc.kcg.web.com.dao.ComTlgLaytMapDao;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapJoinOut;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapSvcIn;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapSvcOut;
import com.jpmc.kcg.web.utils.CpgObjectUtils;

@Service
public class ComTlgLaytMapSvc {

    private final CommonApprovalSvc commonApprovalSvc;
    private final ComTlgLaytMapDao comTlgLaytMapDao;

    public ComTlgLaytMapSvc(CommonApprovalSvc commonApprovalSvc, ComTlgLaytMapDao comTlgLaytMapDao) {
        this.commonApprovalSvc = commonApprovalSvc;
        this.comTlgLaytMapDao = comTlgLaytMapDao;
    }

    public ComTlgLaytMapSvcOut getTlgMapMList(ComTlgLaytMapM in) {
        List<ComTlgLaytMapM> comTlgLaytMapMList = comTlgLaytMapDao.selectComTlgLaytMapMList(in);

        ComTlgLaytMapSvcOut out = new ComTlgLaytMapSvcOut();
        out.setRsltCode(BCMN01.SUCCESS);
        out.setTotLen(comTlgLaytMapMList.size());
        out.setMapMList(comTlgLaytMapMList);
        return out;
    }

    public ComTlgLaytMapSvcOut getTlgMapInfo(ComTlgLaytMapSvcIn in) {
        List<ComTlgLaytMapJoinOut> mapJoinOuts = comTlgLaytMapDao.selectComTlgLaytMapJoinOutList(in.getTrgtTlgLaytId(), in.getSorcTlgLaytId());

        ComTlgLaytMapSvcOut out = new ComTlgLaytMapSvcOut();
        out.setRsltCode(BCMN01.SUCCESS);
        out.setTotLen(mapJoinOuts.size());
        out.setJoinOutList(mapJoinOuts);

        return out;
    }

    @Transactional
    public ComTlgLaytMapSvcOut saveTlgMap(ComTlgLaytMapSvcIn in) {
        int rslt = 0;

        CpgObjectUtils.isDtoValid(in, "tlgLaytMapId", "trgtTlgLaytId");

        String staffId = WebApplicationContext.getHeader().getStaffId();
        String dttm = DateUtils.getDttm();
        String tlgLaytMapId = in.getTlgLaytMapId();

        // comAprvHIn에 승인유형코드, 승인요청구분코드, 승인유형별 키값을 세팅
        ComAprvHIn aprvIn = new ComAprvHIn();
        aprvIn.setAprvTpCd(AprvTpCdEnum.TLG_LAYT_MAP.getValue()); // 승인요청유형
        aprvIn.setAprvRqstDvsnCd(AprvRqstDvsnCdEnum.INSERT.getValue()); // 신규 등록
        aprvIn.setAprvKeyVal(tlgLaytMapId); // 테이블의 key값
        aprvIn.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue()); // 신규 승인전

        try {
            ComTlgLaytMapM comTlgLaytMapM = new ComTlgLaytMapM();
            comTlgLaytMapM.setTlgLaytMapId(tlgLaytMapId);
            comTlgLaytMapM.setTrgtTlgLaytId(in.getTrgtTlgLaytId());
            comTlgLaytMapM.setSorcTlgLaytId(in.getSorcTlgLaytId());
            comTlgLaytMapM.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());
            comTlgLaytMapM.setMakeId(staffId);
            comTlgLaytMapM.setMakeDttm(dttm);

            rslt = comTlgLaytMapDao.insertTlgMapM(comTlgLaytMapM);

            List<ComTlgLaytMapD> tlgLaytMapDList = in.getTlgLaytMapDList();

            for (ComTlgLaytMapD comTlgLaytMapD : tlgLaytMapDList) {
                comTlgLaytMapD.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());
                comTlgLaytMapD.setMakeId(staffId);
                comTlgLaytMapD.setMakeDttm(dttm);
                rslt = comTlgLaytMapDao.insertTlgMapD(comTlgLaytMapD);
            }

            ComTlgLaytMapAprv comTlgLaytMapAprv = new ComTlgLaytMapAprv();
            // 필드 복사
            BeanUtils.copyProperties(comTlgLaytMapM, comTlgLaytMapAprv);
            comTlgLaytMapAprv.setComTlgLaytMapDList(tlgLaytMapDList);

            commonApprovalSvc.requestApproval(aprvIn, null, comTlgLaytMapAprv);

        } catch (DataIntegrityViolationException e) {
            throw new BusinessException("MCMNE01003", String.valueOf(tlgLaytMapId));
        }

        ComTlgLaytMapSvcOut out = new ComTlgLaytMapSvcOut();
        out.setRsltCode(BCMN01.SUCCESS);
        out.setTotLen(rslt);

        return out;
    }

    @Transactional
    public ComTlgLaytMapSvcOut updateTlgMap(ComTlgLaytMapSvcIn in) {
        String staffId = WebApplicationContext.getHeader().getStaffId();
        String dttm = DateUtils.getDttm();
        String tlgLaytMapId = in.getTlgLaytMapId();
        List<ComTlgLaytMapD> tlgLaytMapDList = in.getTlgLaytMapDList();
        List<CmnTlgLaytMapD> cmnTlgLaytMapDList = in.getCmnTlgLaytMapDList();
        int rslt = 0;

        CpgObjectUtils.isDtoValid(in, "tlgLaytMapId");

        // comAprvHIn에 승인유형코드, 승인요청구분코드, 승인유형별 키값을 세팅
        ComAprvHIn aprvIn = new ComAprvHIn();
        aprvIn.setAprvTpCd(AprvTpCdEnum.TLG_LAYT_MAP.getValue()); // 승인요청유형
        aprvIn.setAprvRqstDvsnCd(AprvRqstDvsnCdEnum.UPDATE.getValue()); // 신규 등록
        aprvIn.setAprvKeyVal(tlgLaytMapId); // 테이블의 key값
        aprvIn.setAprvStsCd(AprvStsCdEnum.NOT_APPROVED.getValue()); // 신규 승인전

        ComTlgLaytMapAprv beforeDto = new ComTlgLaytMapAprv();
        beforeDto.setTlgLaytMapId(tlgLaytMapId);

//        ComTlgLaytMapD request = new ComTlgLaytMapD();
//        request.setTlgLaytMapId(tlgLaytMapId);
        List<ComTlgLaytMapD> findComTlgLaytMapDList = comTlgLaytMapDao.selectComTlgLaytMapDList(tlgLaytMapId);
        beforeDto.setComTlgLaytMapDList(findComTlgLaytMapDList);

        // MapM 데이터 승인상태코드 변경
        ComTlgLaytMapM updateDto = new ComTlgLaytMapM();
        updateDto.setAprvStsCd(AprvStsCdEnum.NOT_APPROVED.getValue());
        updateDto.setTlgLaytMapId(tlgLaytMapId);
        updateDto.setMakeId(staffId);
        comTlgLaytMapDao.updateTlgMapMRequestApproval(updateDto);

        for (ComTlgLaytMapD comTlgLaytMapD : tlgLaytMapDList) {
            ComTlgLaytMapD findComTlgLaytMapD = comTlgLaytMapDao.selectTlgMapD(comTlgLaytMapD);
            int count = comTlgLaytMapDao.selectTlgMapDCount(
                    comTlgLaytMapD.getTlgLaytMapId(),
                    comTlgLaytMapD.getTrgtTlgLaytId(),
                    comTlgLaytMapD.getTrgtTlgFld()
            );

            comTlgLaytMapD.setMakeId(WebApplicationContext.getHeader().getStaffId());
            comTlgLaytMapD.setMakeDttm(DateUtils.getDttm());

            // 매핑된 필드가 하나도 없을 때 (매핑정보 추가)
            if (count == 0) {
                comTlgLaytMapD.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());
                rslt = comTlgLaytMapDao.insertTlgMapD(comTlgLaytMapD);
            }
            // 매핑된 필드는 있으나 소스전문필드가 일치하지 않을 때 (매핑정보 수정)
            else if (count == 1 && findComTlgLaytMapD == null) {
                // 화면에서 매핑 취소(Reject)한 데이터가 있다면 Reject 상태로 수정
                boolean isDeleted = Optional.ofNullable(cmnTlgLaytMapDList)
                        .orElse(Collections.emptyList())
                        .stream()
                        .anyMatch(d ->
                                Objects.equals(d.getTlgLaytMapId(), comTlgLaytMapD.getTlgLaytMapId()) &&
                                        Objects.equals(d.getTrgtTlgLaytId(), comTlgLaytMapD.getTrgtTlgLaytId()) &&
                                        Objects.equals(d.getTrgtTlgFld(),    comTlgLaytMapD.getTrgtTlgFld()) &&
                                        BCMN01.DELETE.equals(d.getCrudType())
                        );

                comTlgLaytMapD.setAprvStsCd(
                        isDeleted
                                ? AprvStsCdEnum.REJECTED.getValue()
                                : AprvStsCdEnum.NOT_APPROVED.getValue()
                );
                rslt = comTlgLaytMapDao.updateTlgMapDRequestApproval(comTlgLaytMapD);
            }
        }

        ComTlgLaytMapAprv afterDto = new ComTlgLaytMapAprv();
        afterDto.setTlgLaytMapId(tlgLaytMapId);
        afterDto.setComTlgLaytMapDList(tlgLaytMapDList);

        commonApprovalSvc.requestApproval(aprvIn, beforeDto, afterDto);

        ComTlgLaytMapSvcOut out = new ComTlgLaytMapSvcOut();
        out.setRsltCode(BCMN01.SUCCESS);
        out.setTotLen(rslt);

        return out;
    }
}
