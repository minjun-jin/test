package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 사고신고 등록 요청내역
 * <pre>{@code
 * KftEntES2220R kftEntES2220R  = new KftEntES2220R(); // 사고신고 등록 요청내역
 * kftEntES2220R.setFileName(""); // 업무구분
 * kftEntES2220R.setDataType(""); // 데이터구분
 * kftEntES2220R.setSerialNumber(""); // 일련번호
 * kftEntES2220R.setBankCode(""); // 은행코드
 * kftEntES2220R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES2220R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES2220R.setAccidentReportEnoteNumber(""); // 사고신고-전자어음번호
 * kftEntES2220R.setAccidentReportSplitNumber(""); // 사고신고-분할번호
 * kftEntES2220R.setAccidentReportStatus(""); // 사고신고여부
 * kftEntES2220R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES2220R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String bankCode; // 은행코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String accidentReportEnoteNumber; // 사고신고-전자어음번호
	private String accidentReportSplitNumber; // 사고신고-분할번호
	private String accidentReportStatus; // 사고신고여부
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportEnoteNumber$; // 사고신고-전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportSplitNumber$; // 사고신고-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportStatus$; // 사고신고여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		accidentReportEnoteNumber$ = VOUtils.write(out, accidentReportEnoteNumber, 20); // 사고신고-전자어음번호
		accidentReportSplitNumber$ = VOUtils.write(out, accidentReportSplitNumber, 2); // 사고신고-분할번호
		accidentReportStatus$ = VOUtils.write(out, accidentReportStatus, 1); // 사고신고여부
		filler2$ = VOUtils.write(out, filler2, 25); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		accidentReportEnoteNumber = VOUtils.toString(accidentReportEnoteNumber$ = VOUtils.read(in, 20)); // 사고신고-전자어음번호
		accidentReportSplitNumber = VOUtils.toString(accidentReportSplitNumber$ = VOUtils.read(in, 2)); // 사고신고-분할번호
		accidentReportStatus = VOUtils.toString(accidentReportStatus$ = VOUtils.read(in, 1)); // 사고신고여부
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 25)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", accidentReportEnoteNumber=").append(accidentReportEnoteNumber).append(System.lineSeparator()); // 사고신고-전자어음번호
		sb.append(", accidentReportSplitNumber=").append(accidentReportSplitNumber).append(System.lineSeparator()); // 사고신고-분할번호
		sb.append(", accidentReportStatus=").append(accidentReportStatus).append(System.lineSeparator()); // 사고신고여부
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accidentReportEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "accidentReportSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "25", "defltVal", "")
		);
	}

}
