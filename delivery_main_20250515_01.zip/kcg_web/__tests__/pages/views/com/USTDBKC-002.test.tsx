import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// USTDBKC002 컴포넌트를 불러옵니다.
import USTDBKC002 from "@/pages/views/com/USTDBKC-002"
import { Component } from "@/hoc/TestUtil"

const component = Component(USTDBKC002)

describe("[USTDBKC-002] 은행지점코드 조회", () => {
  it("searchBankBranchCode Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bnkBrnchCdMList: [],
        totLen: 0,
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bnkBrnchCdMList: undefined,
      },
    })
    render(component)

    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)

    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {
          noteExCd: "test",
        },
      },
    })

    await waitFor(() => {
      expect(mockUseCode.mockCodeValue).toHaveBeenCalledWith(
        "NOTE_EX_CD",
        "test",
        {
          visibleCode: true,
          visibleName: true,
        },
      )
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchBankBranchCodeLabel Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        codeList: [],
      },
    })
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#bnkNm/),
    ).findByTestId("onChange")
    fireEvent.click(onChangeTestBtn, {
      target: {
        data: "test",
      },
    })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("xlsxClick Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bnkBrnchCdMList: [
          {
            bnkCd: "",
            brnchCd1: null,
            brnchCd2: null,
            brnchStsCd: "\u3000\u3000\uFF01",
            zipCd: "",
            addr: "\uFF01",
            noteExCd: "",
            brnchNm: "",
            onlineCd: "",
            areaCd: "",
            exprtnDt: "",
            subBrnchCd: "",
            rcptStsCd: "",
            telNo: "",
            faxNo: "",
            emailAddr: "",
            addrCd: "",
            trDt: "",
            trTm: "",
            fognExchBrnchCd: "",
            clsMgmtBrnchCd: "",
          },
        ],
      },
    })
    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })
    const { findByText } = render(component)
    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("ctrlEnter Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bnkBrnchCdMList: [],
        totLen: 0,
      },
    })

    const { container } = render(component)
    fireEvent.keyDown(container, { key: "Enter", ctrlKey: true, keyCode: 13 })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it.each([/SCRNITM#finInstCd/, /SCRNITM#brnchCd/, /SCRNITM#brnchNm/])(
    "onChange Test",
    async (regex) => {
      const { findByTestId } = render(component)
      const onChangeTestBtn = await within(
        await findByTestId(regex),
      ).findByTestId("onChange")
      fireEvent.click(onChangeTestBtn, { target: { data: "Test" } })
    },
  )
})
