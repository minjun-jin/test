package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * LCR산정관련 순이체한도 일괄전송
 * <pre>{@code
 * KftHofLC0011R kftHofLC0011R  = new KftHofLC0011R(); // LCR산정관련 순이체한도 일괄전송
 * kftHofLC0011R.setFileName(""); // 업무 구분
 * kftHofLC0011R.setDataType(0); // 데이터 구분
 * kftHofLC0011R.setSerialNumber(""); // 일련번호
 * kftHofLC0011R.setInstitutionCode(""); // 기관코드
 * kftHofLC0011R.setRegisterTransferLimitAmount(0L); // 순채무한도금액
 * kftHofLC0011R.setRemainedAmountOfNetTransferLimit(0L); // 채무한도잔여금액
 * kftHofLC0011R.setSpentRate(0); // 채무한도 소진율
 * kftHofLC0011R.setFiller(""); // filler
 * }</pre>
 */
@Data
public class KftHofLC0011R implements Vo {

	private String fileName; // 업무 구분
	private int dataType; // 데이터 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private long registerTransferLimitAmount; // 순채무한도금액
	private long remainedAmountOfNetTransferLimit; // 채무한도잔여금액
	private int spentRate; // 채무한도 소진율
	private String filler; // filler
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerTransferLimitAmount$; // 순채무한도금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String remainedAmountOfNetTransferLimit$; // 채무한도잔여금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String spentRate$; // 채무한도 소진율
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // filler

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무 구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		registerTransferLimitAmount$ = VOUtils.write(out, registerTransferLimitAmount, 14); // 순채무한도금액
		remainedAmountOfNetTransferLimit$ = VOUtils.write(out, remainedAmountOfNetTransferLimit, 14); // 채무한도잔여금액
		spentRate$ = VOUtils.write(out, spentRate, 5); // 채무한도 소진율
		filler$ = VOUtils.write(out, filler, 49); // filler
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무 구분
		dataType = VOUtils.toInt(dataType$ = VOUtils.read(in, 2)); // 데이터 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		registerTransferLimitAmount = VOUtils.toLong(registerTransferLimitAmount$ = VOUtils.read(in, 14)); // 순채무한도금액
		remainedAmountOfNetTransferLimit = VOUtils.toLong(remainedAmountOfNetTransferLimit$ = VOUtils.read(in, 14)); // 채무한도잔여금액
		spentRate = VOUtils.toInt(spentRate$ = VOUtils.read(in, 5)); // 채무한도 소진율
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 49)); // filler
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무 구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", registerTransferLimitAmount=").append(registerTransferLimitAmount).append(System.lineSeparator()); // 순채무한도금액
		sb.append(", remainedAmountOfNetTransferLimit=").append(remainedAmountOfNetTransferLimit).append(System.lineSeparator()); // 채무한도잔여금액
		sb.append(", spentRate=").append(spentRate).append(System.lineSeparator()); // 채무한도 소진율
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // filler
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "registerTransferLimitAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "remainedAmountOfNetTransferLimit", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "spentRate", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "49", "defltVal", "")
		);
	}

}
