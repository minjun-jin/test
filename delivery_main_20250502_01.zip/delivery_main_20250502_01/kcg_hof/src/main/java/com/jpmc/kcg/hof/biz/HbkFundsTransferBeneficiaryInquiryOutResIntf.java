package com.jpmc.kcg.hof.biz;

import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.hof.biz.vo.KftHof0210350000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200400000;
import com.jpmc.kcg.hof.dto.HbkTrL;
import com.jpmc.kcg.hof.dto.HbkTransactionIn;
import com.jpmc.kcg.hof.dto.SelectHbkTransactionIn;
import com.jpmc.kcg.hof.enums.HbkConst;
import com.jpmc.kcg.hof.enums.HbkRespCdEnum;
import com.jpmc.kcg.hof.enums.HofConst;

import lombok.extern.slf4j.Slf4j;

/**
 * 거액타행이체수취조회 당발응답 (0210/350000)
 */
@Slf4j
@Component
public class HbkFundsTransferBeneficiaryInquiryOutResIntf extends FrwServiceBean<KftHof0210350000> {

	@Autowired
	private FrwTemplate frwTemplate;

	@Autowired
	private HbkCom hbkCom;

	@Autowired
	private HofCom hofCom;

	@Autowired
	private FrwContext frwContext;

	@Autowired
	private HbkFundsTransferOutReqIntf hbkFundsTransferOutReqIntf;

	/**
	 * 제어
	 */
	@Override
	public boolean control(KftHof0210350000 in) {

		// 전문 format validation check
		int fieldNo = in.validate();
		
		if (fieldNo > 0) {
			String errCd = StringUtils.leftPad(String.valueOf(fieldNo), 3, ComConst.CHAR_0);
			throw new InternalResponseException(errCd);
		}

		// 전문시간 현재시간과 비교 체크.
		if (!in.getMessageTransmissionDate().format(DateTimeFormatter.BASIC_ISO_DATE)
				.equals(frwContext.getSysTmstmp().format(DateTimeFormatter.BASIC_ISO_DATE))) {
			throw new InternalResponseException(HbkRespCdEnum.RESP_CD_007.getCode());
		}

		return super.control(in);
	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftHof0210350000 in) {

		log.debug("당발 이체수취조회 응답 KftHof0210350000 in {}", in);

		/**
		 * 1. 포맷에러      -> KFT 9210 전송
		 * 2. 원거래 없음   -> HOF분할거래
		 * 3. 정상응답 아님 -> HOF분할거래 & HBK거래원장 UPDATE(91)
		 */

		_processFundTr(in);

	}


	@Override
	public void handleError(KftHof0210350000 in, Throwable t) {

		if (t instanceof InternalResponseException e) {
			String respCd = e.getRespCd();
			in.setResponseCode(respCd);

			// field값 에러인 경우 전문종별 : 9210으로 전송한다.
			if (respCd.startsWith(ComConst.CHAR_0)) {
				in.setMessageType(HofConst.TLG_KND_DVSN_NO_9210);
				frwTemplate.send(FrwDestination.KFT_HOF, in);
			}

		} else { // 그외 오류 모두 HOF거래
			in.setResponseCode(HbkRespCdEnum.RESP_CD_413.getCode());
			_processFundTr(in);

		}

		return;
	}

	private void _hofiRouting() {
		log.debug("#########[HOFI-ROUTING] 수취조회 오류");
		Map<String, String> tlgHdr = new HashMap<String, String>();
		tlgHdr.put(HofConst.HBK_ERR_TR_YN, ComConst.Y);
		tlgHdr.put(ComConst.ORGN_TRACT_ID, frwContext.getOrgnTractId());
		
		frwTemplate.send(FrwDestination.KCG_HOF, frwContext.getOrgnTlgCtt(), tlgHdr);
	}

	
	private void _processFundTr(KftHof0210350000 in) {

		SelectHbkTransactionIn selectIn = new SelectHbkTransactionIn();
		selectIn.setTrDt(in.getTraxOccurredDate().format(DateFormat.YYYYMMDD.getFormatter())); // 거래발생일
		selectIn.setHbkTlgTrceNo(in.getMessageTrackingNumber()); // 전문추적번호
		selectIn.setHbkRcvInqryUnqNo(in.getTransactionIdNumber()); // 거래고유번호
		selectIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_01); // 당발
		selectIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0200); // 요청
		selectIn.setHbkTlgTrDvsnCd(HbkConst.TR_DVSN_350000);

		HbkTrL out = hbkCom.selectHBKTransaction(selectIn);
		
		//원거래 없음
		if(out == null) {
			_hofiRouting();
			
		//정상응답
		} else if(HbkRespCdEnum.RESP_CD_000.getCode().equals(in.getResponseCode())) {
			hbkFundsTransferOutReqIntf.hbkFundsTransferOutReq(out);
			
		//그외 오류응답
		} else {
			_hofiRouting();
			
			HbkTransactionIn updateIn = new HbkTransactionIn();
			updateIn.setTrDt(in.getMessageTransmissionDate().format(DateTimeFormatter.BASIC_ISO_DATE));
			updateIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_01);
			updateIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0200);
			updateIn.setHbkTlgTrDvsnCd(HbkConst.TR_DVSN_450000);
			updateIn.setTrUnqNo(out.getTrUnqNo());
			updateIn.setHbkTlgTrceNo(in.getMessageTrackingNumber());
			updateIn.setTrStsCd(TrStsCdEnum.BENE_INQ_ERROR.getTrStsCd());   //수취조회에러
			updateIn.setHbkRqstTm(frwContext.getSysTmstmp().format(DateFormat.HHMMSS.getFormatter()));
			updateIn.setRespCd(in.getResponseCode());
			hbkCom.updateHBKTransaction(updateIn);
		}
	}


}
