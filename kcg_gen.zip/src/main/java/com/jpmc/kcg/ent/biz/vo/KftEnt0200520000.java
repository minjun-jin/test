package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 상환청구관련 어음정보 조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 520000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * userSort 이용자구분 
 * searchConditionSort 검색조건구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * currentCreditAccountNumber 당좌(입금)계좌번호 
 * recourseClaimDateInquiryStartDate 상환청구일기준조회시작일 
 * recourseClaimDateInquiryEndDate 상환청구일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.noteInfoEnoteNumber (조회결과)어음정보-전자어음번호 
 * queryResultArray.noteInfoNoteType (조회결과)어음정보-어음종류 
 * queryResultArray.noteInfoEnoteIssueDate (조회결과)어음정보-전자어음발행일자 
 * queryResultArray.noteInfoEnoteIssuePlace (조회결과)어음정보-전자어음발행지 
 * queryResultArray.noteInfoEnoteAmount (조회결과)어음정보-전자어음금액 
 * queryResultArray.noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
 * queryResultArray.noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
 * queryResultArray.defaultDetailsDefaultReasonCode (조회결과)부도내역-부도사유코드 
 * queryResultArray.defaultDetailsDefaultDate (조회결과)부도내역-부도일자 
 * queryResultArray.repaymentObligationsIndvCorpSort (조회결과)상환의무인-개인법인구분 
 * queryResultArray.repaymentObligationsResidentBusinessNumber (조회결과)상환의무인-주민사업자번호 
 * queryResultArray.repaymentObligationsCorpName (조회결과)상환의무인-법인명 
 * queryResultArray.repaymentObligationsNameRepresentative (조회결과)상환의무인-성명(대표자명) 
 * queryResultArray.repaymentObligationsAddress (조회결과)상환의무인-주소 
 * queryResultArray.repaymentObligationsBankCode (조회결과)상환의무인-은행코드 
 * queryResultArray.repaymentObligationsDepositAccountNumber (조회결과)상환의무인-입금계좌번호 
 * queryResultArray.repaymentObligationsSplitNumber (조회결과)상환의무인-분할번호 
 * queryResultArray.repaymentObligationsEndorsementNumber (조회결과)상환의무인-배서번호 
 * queryResultArray.unsecuredEndorsementYn (조회결과)무담보배서여부 
 * queryResultArray.endorsementProhibitionEndorsementYn (조회결과)배서금지배서여부 
 * queryResultArray.recourseClaimantIndvCorpSort (조회결과)상환청구인-개인법인구분 
 * queryResultArray.recourseClaimantResidentBusinessNumber (조회결과)상환청구인-주민사업자번호 
 * queryResultArray.recourseClaimantCorpName (조회결과)상환청구인-법인명 
 * queryResultArray.recourseClaimantNameRepresentative (조회결과)상환청구인-성명(대표자명) 
 * queryResultArray.recourseClaimantAddress (조회결과)상환청구인-주소 
 * queryResultArray.recourseClaimantBankCode (조회결과)상환청구인-은행코드 
 * queryResultArray.recourseClaimantDepositAccountNumber (조회결과)상환청구인-입금계좌번호 
 * queryResultArray.recourseClaimantSplitNumber (조회결과)상환청구인-분할번호 
 * queryResultArray.recourseClaimantEndorsementNumber (조회결과)상환청구인-배서번호 
 * queryResultArray.recourseClaimAmount (조회결과)상환청구금액 
 * 
 * KftEnt0200520000 kftEnt0200520000 = new KftEnt0200520000(); // 상환청구관련 어음정보 조회 요청
 * kftEnt0200520000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200520000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200520000.setBnkCd("057"); // 은행코드
 * kftEnt0200520000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200520000.setTransactionCode("520000"); // 거래구분코드
 * kftEnt0200520000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200520000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200520000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200520000.setStatus("000"); // STATUS
 * kftEnt0200520000.setResponseCode1(""); // 응답코드1
 * kftEnt0200520000.setResponseCode2(""); // 응답코드2
 * kftEnt0200520000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200520000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200520000.setUserSort(""); // 이용자구분
 * kftEnt0200520000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0200520000.setENoteNumber(""); // 전자어음번호
 * kftEnt0200520000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200520000.setCurrentCreditAccountNumber(""); // 당좌(입금)계좌번호
 * kftEnt0200520000.setRecourseClaimDateInquiryStartDate(""); // 상환청구일기준조회시작일
 * kftEnt0200520000.setRecourseClaimDateInquiryEndDate(""); // 상환청구일기준조회종료일
 * kftEnt0200520000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0200520000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0200520000.setCurrentCount(0); // 현재건수
 * KftEnt0200520000.QueryResult queryResult = new KftEnt0200520000.QueryResult(); // 조회결과Array
 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-전자어음번호
 * queryResult.setNoteInfoNoteType(""); // (조회결과)어음정보-어음종류
 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-전자어음발행일자
 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-전자어음발행지
 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-전자어음금액
 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
 * queryResult.setDefaultDetailsDefaultReasonCode(""); // (조회결과)부도내역-부도사유코드
 * queryResult.setDefaultDetailsDefaultDate(""); // (조회결과)부도내역-부도일자
 * queryResult.setRepaymentObligationsIndvCorpSort(""); // (조회결과)상환의무인-개인법인구분
 * queryResult.setRepaymentObligationsResidentBusinessNumber(""); // (조회결과)상환의무인-주민사업자번호
 * queryResult.setRepaymentObligationsCorpName(""); // (조회결과)상환의무인-법인명
 * queryResult.setRepaymentObligationsNameRepresentative(""); // (조회결과)상환의무인-성명(대표자명)
 * queryResult.setRepaymentObligationsAddress(""); // (조회결과)상환의무인-주소
 * queryResult.setRepaymentObligationsBankCode(""); // (조회결과)상환의무인-은행코드
 * queryResult.setRepaymentObligationsDepositAccountNumber(""); // (조회결과)상환의무인-입금계좌번호
 * queryResult.setRepaymentObligationsSplitNumber(""); // (조회결과)상환의무인-분할번호
 * queryResult.setRepaymentObligationsEndorsementNumber(""); // (조회결과)상환의무인-배서번호
 * queryResult.setUnsecuredEndorsementYn(""); // (조회결과)무담보배서여부
 * queryResult.setEndorsementProhibitionEndorsementYn(""); // (조회결과)배서금지배서여부
 * queryResult.setRecourseClaimantIndvCorpSort(""); // (조회결과)상환청구인-개인법인구분
 * queryResult.setRecourseClaimantResidentBusinessNumber(""); // (조회결과)상환청구인-주민사업자번호
 * queryResult.setRecourseClaimantCorpName(""); // (조회결과)상환청구인-법인명
 * queryResult.setRecourseClaimantNameRepresentative(""); // (조회결과)상환청구인-성명(대표자명)
 * queryResult.setRecourseClaimantAddress(""); // (조회결과)상환청구인-주소
 * queryResult.setRecourseClaimantBankCode(""); // (조회결과)상환청구인-은행코드
 * queryResult.setRecourseClaimantDepositAccountNumber(""); // (조회결과)상환청구인-입금계좌번호
 * queryResult.setRecourseClaimantSplitNumber(""); // (조회결과)상환청구인-분할번호
 * queryResult.setRecourseClaimantEndorsementNumber(""); // (조회결과)상환청구인-배서번호
 * queryResult.setRecourseClaimAmount(0L); // (조회결과)상환청구금액
 * kftEnt0200520000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0200520000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * noteInfoEnoteNumber (조회결과)어음정보-전자어음번호 
	 * noteInfoNoteType (조회결과)어음정보-어음종류 
	 * noteInfoEnoteIssueDate (조회결과)어음정보-전자어음발행일자 
	 * noteInfoEnoteIssuePlace (조회결과)어음정보-전자어음발행지 
	 * noteInfoEnoteAmount (조회결과)어음정보-전자어음금액 
	 * noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
	 * noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
	 * defaultDetailsDefaultReasonCode (조회결과)부도내역-부도사유코드 
	 * defaultDetailsDefaultDate (조회결과)부도내역-부도일자 
	 * repaymentObligationsIndvCorpSort (조회결과)상환의무인-개인법인구분 
	 * repaymentObligationsResidentBusinessNumber (조회결과)상환의무인-주민사업자번호 
	 * repaymentObligationsCorpName (조회결과)상환의무인-법인명 
	 * repaymentObligationsNameRepresentative (조회결과)상환의무인-성명(대표자명) 
	 * repaymentObligationsAddress (조회결과)상환의무인-주소 
	 * repaymentObligationsBankCode (조회결과)상환의무인-은행코드 
	 * repaymentObligationsDepositAccountNumber (조회결과)상환의무인-입금계좌번호 
	 * repaymentObligationsSplitNumber (조회결과)상환의무인-분할번호 
	 * repaymentObligationsEndorsementNumber (조회결과)상환의무인-배서번호 
	 * unsecuredEndorsementYn (조회결과)무담보배서여부 
	 * endorsementProhibitionEndorsementYn (조회결과)배서금지배서여부 
	 * recourseClaimantIndvCorpSort (조회결과)상환청구인-개인법인구분 
	 * recourseClaimantResidentBusinessNumber (조회결과)상환청구인-주민사업자번호 
	 * recourseClaimantCorpName (조회결과)상환청구인-법인명 
	 * recourseClaimantNameRepresentative (조회결과)상환청구인-성명(대표자명) 
	 * recourseClaimantAddress (조회결과)상환청구인-주소 
	 * recourseClaimantBankCode (조회결과)상환청구인-은행코드 
	 * recourseClaimantDepositAccountNumber (조회결과)상환청구인-입금계좌번호 
	 * recourseClaimantSplitNumber (조회결과)상환청구인-분할번호 
	 * recourseClaimantEndorsementNumber (조회결과)상환청구인-배서번호 
	 * recourseClaimAmount (조회결과)상환청구금액 
	 * 
	 * KftEnt0200520000.QueryResult queryResult = new KftEnt0200520000.QueryResult(); // 조회결과Array
	 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-전자어음번호
	 * queryResult.setNoteInfoNoteType(""); // (조회결과)어음정보-어음종류
	 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-전자어음발행일자
	 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-전자어음발행지
	 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-전자어음금액
	 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
	 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
	 * queryResult.setDefaultDetailsDefaultReasonCode(""); // (조회결과)부도내역-부도사유코드
	 * queryResult.setDefaultDetailsDefaultDate(""); // (조회결과)부도내역-부도일자
	 * queryResult.setRepaymentObligationsIndvCorpSort(""); // (조회결과)상환의무인-개인법인구분
	 * queryResult.setRepaymentObligationsResidentBusinessNumber(""); // (조회결과)상환의무인-주민사업자번호
	 * queryResult.setRepaymentObligationsCorpName(""); // (조회결과)상환의무인-법인명
	 * queryResult.setRepaymentObligationsNameRepresentative(""); // (조회결과)상환의무인-성명(대표자명)
	 * queryResult.setRepaymentObligationsAddress(""); // (조회결과)상환의무인-주소
	 * queryResult.setRepaymentObligationsBankCode(""); // (조회결과)상환의무인-은행코드
	 * queryResult.setRepaymentObligationsDepositAccountNumber(""); // (조회결과)상환의무인-입금계좌번호
	 * queryResult.setRepaymentObligationsSplitNumber(""); // (조회결과)상환의무인-분할번호
	 * queryResult.setRepaymentObligationsEndorsementNumber(""); // (조회결과)상환의무인-배서번호
	 * queryResult.setUnsecuredEndorsementYn(""); // (조회결과)무담보배서여부
	 * queryResult.setEndorsementProhibitionEndorsementYn(""); // (조회결과)배서금지배서여부
	 * queryResult.setRecourseClaimantIndvCorpSort(""); // (조회결과)상환청구인-개인법인구분
	 * queryResult.setRecourseClaimantResidentBusinessNumber(""); // (조회결과)상환청구인-주민사업자번호
	 * queryResult.setRecourseClaimantCorpName(""); // (조회결과)상환청구인-법인명
	 * queryResult.setRecourseClaimantNameRepresentative(""); // (조회결과)상환청구인-성명(대표자명)
	 * queryResult.setRecourseClaimantAddress(""); // (조회결과)상환청구인-주소
	 * queryResult.setRecourseClaimantBankCode(""); // (조회결과)상환청구인-은행코드
	 * queryResult.setRecourseClaimantDepositAccountNumber(""); // (조회결과)상환청구인-입금계좌번호
	 * queryResult.setRecourseClaimantSplitNumber(""); // (조회결과)상환청구인-분할번호
	 * queryResult.setRecourseClaimantEndorsementNumber(""); // (조회결과)상환청구인-배서번호
	 * queryResult.setRecourseClaimAmount(0L); // (조회결과)상환청구금액
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String noteInfoEnoteNumber; // (조회결과)어음정보-전자어음번호
		private String noteInfoNoteType; // (조회결과)어음정보-어음종류
		private String noteInfoEnoteIssueDate; // (조회결과)어음정보-전자어음발행일자
		private String noteInfoEnoteIssuePlace; // (조회결과)어음정보-전자어음발행지
		private long noteInfoEnoteAmount; // (조회결과)어음정보-전자어음금액
		private String noteInfoEnoteMaturedDate; // (조회결과)어음정보-전자어음만기일자
		private String noteInfoPaymentBankAndBranchCode; // (조회결과)어음정보-지급은행및점포코드
		private String defaultDetailsDefaultReasonCode; // (조회결과)부도내역-부도사유코드
		private String defaultDetailsDefaultDate; // (조회결과)부도내역-부도일자
		private String repaymentObligationsIndvCorpSort; // (조회결과)상환의무인-개인법인구분
		private String repaymentObligationsResidentBusinessNumber; // (조회결과)상환의무인-주민사업자번호
		private String repaymentObligationsCorpName; // (조회결과)상환의무인-법인명
		private String repaymentObligationsNameRepresentative; // (조회결과)상환의무인-성명(대표자명)
		private String repaymentObligationsAddress; // (조회결과)상환의무인-주소
		private String repaymentObligationsBankCode; // (조회결과)상환의무인-은행코드
		private String repaymentObligationsDepositAccountNumber; // (조회결과)상환의무인-입금계좌번호
		private String repaymentObligationsSplitNumber; // (조회결과)상환의무인-분할번호
		private String repaymentObligationsEndorsementNumber; // (조회결과)상환의무인-배서번호
		private String unsecuredEndorsementYn; // (조회결과)무담보배서여부
		private String endorsementProhibitionEndorsementYn; // (조회결과)배서금지배서여부
		private String recourseClaimantIndvCorpSort; // (조회결과)상환청구인-개인법인구분
		private String recourseClaimantResidentBusinessNumber; // (조회결과)상환청구인-주민사업자번호
		private String recourseClaimantCorpName; // (조회결과)상환청구인-법인명
		private String recourseClaimantNameRepresentative; // (조회결과)상환청구인-성명(대표자명)
		private String recourseClaimantAddress; // (조회결과)상환청구인-주소
		private String recourseClaimantBankCode; // (조회결과)상환청구인-은행코드
		private String recourseClaimantDepositAccountNumber; // (조회결과)상환청구인-입금계좌번호
		private String recourseClaimantSplitNumber; // (조회결과)상환청구인-분할번호
		private String recourseClaimantEndorsementNumber; // (조회결과)상환청구인-배서번호
		private long recourseClaimAmount; // (조회결과)상환청구금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteNumber$; // (조회결과)어음정보-전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoNoteType$; // (조회결과)어음정보-어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssueDate$; // (조회결과)어음정보-전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssuePlace$; // (조회결과)어음정보-전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteAmount$; // (조회결과)어음정보-전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteMaturedDate$; // (조회결과)어음정보-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoPaymentBankAndBranchCode$; // (조회결과)어음정보-지급은행및점포코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String defaultDetailsDefaultReasonCode$; // (조회결과)부도내역-부도사유코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String defaultDetailsDefaultDate$; // (조회결과)부도내역-부도일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsIndvCorpSort$; // (조회결과)상환의무인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsResidentBusinessNumber$; // (조회결과)상환의무인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsCorpName$; // (조회결과)상환의무인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsNameRepresentative$; // (조회결과)상환의무인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsAddress$; // (조회결과)상환의무인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsBankCode$; // (조회결과)상환의무인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsDepositAccountNumber$; // (조회결과)상환의무인-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsSplitNumber$; // (조회결과)상환의무인-분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsEndorsementNumber$; // (조회결과)상환의무인-배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String unsecuredEndorsementYn$; // (조회결과)무담보배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementProhibitionEndorsementYn$; // (조회결과)배서금지배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantIndvCorpSort$; // (조회결과)상환청구인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantResidentBusinessNumber$; // (조회결과)상환청구인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantCorpName$; // (조회결과)상환청구인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantNameRepresentative$; // (조회결과)상환청구인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantAddress$; // (조회결과)상환청구인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantBankCode$; // (조회결과)상환청구인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantDepositAccountNumber$; // (조회결과)상환청구인-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantSplitNumber$; // (조회결과)상환청구인-분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimantEndorsementNumber$; // (조회결과)상환청구인-배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recourseClaimAmount$; // (조회결과)상환청구금액

		@Override
		public void write(OutputStream out) throws IOException {
			noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // (조회결과)어음정보-전자어음번호
			noteInfoNoteType$ = VOUtils.write(out, noteInfoNoteType, 1); // (조회결과)어음정보-어음종류
			noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // (조회결과)어음정보-전자어음발행일자
			noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음정보-전자어음발행지
			noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // (조회결과)어음정보-전자어음금액
			noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // (조회결과)어음정보-전자어음만기일자
			noteInfoPaymentBankAndBranchCode$ = VOUtils.write(out, noteInfoPaymentBankAndBranchCode, 7); // (조회결과)어음정보-지급은행및점포코드
			defaultDetailsDefaultReasonCode$ = VOUtils.write(out, defaultDetailsDefaultReasonCode, 2); // (조회결과)부도내역-부도사유코드
			defaultDetailsDefaultDate$ = VOUtils.write(out, defaultDetailsDefaultDate, 8); // (조회결과)부도내역-부도일자
			repaymentObligationsIndvCorpSort$ = VOUtils.write(out, repaymentObligationsIndvCorpSort, 1); // (조회결과)상환의무인-개인법인구분
			repaymentObligationsResidentBusinessNumber$ = VOUtils.write(out, repaymentObligationsResidentBusinessNumber, 13); // (조회결과)상환의무인-주민사업자번호
			repaymentObligationsCorpName$ = VOUtils.write(out, repaymentObligationsCorpName, 40, "EUC-KR"); // (조회결과)상환의무인-법인명
			repaymentObligationsNameRepresentative$ = VOUtils.write(out, repaymentObligationsNameRepresentative, 20, "EUC-KR"); // (조회결과)상환의무인-성명(대표자명)
			repaymentObligationsAddress$ = VOUtils.write(out, repaymentObligationsAddress, 60, "EUC-KR"); // (조회결과)상환의무인-주소
			repaymentObligationsBankCode$ = VOUtils.write(out, repaymentObligationsBankCode, 3); // (조회결과)상환의무인-은행코드
			repaymentObligationsDepositAccountNumber$ = VOUtils.write(out, repaymentObligationsDepositAccountNumber, 16); // (조회결과)상환의무인-입금계좌번호
			repaymentObligationsSplitNumber$ = VOUtils.write(out, repaymentObligationsSplitNumber, 2); // (조회결과)상환의무인-분할번호
			repaymentObligationsEndorsementNumber$ = VOUtils.write(out, repaymentObligationsEndorsementNumber, 2); // (조회결과)상환의무인-배서번호
			unsecuredEndorsementYn$ = VOUtils.write(out, unsecuredEndorsementYn, 1); // (조회결과)무담보배서여부
			endorsementProhibitionEndorsementYn$ = VOUtils.write(out, endorsementProhibitionEndorsementYn, 1); // (조회결과)배서금지배서여부
			recourseClaimantIndvCorpSort$ = VOUtils.write(out, recourseClaimantIndvCorpSort, 1); // (조회결과)상환청구인-개인법인구분
			recourseClaimantResidentBusinessNumber$ = VOUtils.write(out, recourseClaimantResidentBusinessNumber, 13); // (조회결과)상환청구인-주민사업자번호
			recourseClaimantCorpName$ = VOUtils.write(out, recourseClaimantCorpName, 40, "EUC-KR"); // (조회결과)상환청구인-법인명
			recourseClaimantNameRepresentative$ = VOUtils.write(out, recourseClaimantNameRepresentative, 20, "EUC-KR"); // (조회결과)상환청구인-성명(대표자명)
			recourseClaimantAddress$ = VOUtils.write(out, recourseClaimantAddress, 60, "EUC-KR"); // (조회결과)상환청구인-주소
			recourseClaimantBankCode$ = VOUtils.write(out, recourseClaimantBankCode, 3); // (조회결과)상환청구인-은행코드
			recourseClaimantDepositAccountNumber$ = VOUtils.write(out, recourseClaimantDepositAccountNumber, 16); // (조회결과)상환청구인-입금계좌번호
			recourseClaimantSplitNumber$ = VOUtils.write(out, recourseClaimantSplitNumber, 2); // (조회결과)상환청구인-분할번호
			recourseClaimantEndorsementNumber$ = VOUtils.write(out, recourseClaimantEndorsementNumber, 2); // (조회결과)상환청구인-배서번호
			recourseClaimAmount$ = VOUtils.write(out, recourseClaimAmount, 15); // (조회결과)상환청구금액
		}

		@Override
		public void read(InputStream in) throws IOException {
			noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음정보-전자어음번호
			noteInfoNoteType = VOUtils.toString(noteInfoNoteType$ = VOUtils.read(in, 1)); // (조회결과)어음정보-어음종류
			noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음발행일자
			noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음정보-전자어음발행지
			noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음정보-전자어음금액
			noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음만기일자
			noteInfoPaymentBankAndBranchCode = VOUtils.toString(noteInfoPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음정보-지급은행및점포코드
			defaultDetailsDefaultReasonCode = VOUtils.toString(defaultDetailsDefaultReasonCode$ = VOUtils.read(in, 2)); // (조회결과)부도내역-부도사유코드
			defaultDetailsDefaultDate = VOUtils.toString(defaultDetailsDefaultDate$ = VOUtils.read(in, 8)); // (조회결과)부도내역-부도일자
			repaymentObligationsIndvCorpSort = VOUtils.toString(repaymentObligationsIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)상환의무인-개인법인구분
			repaymentObligationsResidentBusinessNumber = VOUtils.toString(repaymentObligationsResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)상환의무인-주민사업자번호
			repaymentObligationsCorpName = VOUtils.toString(repaymentObligationsCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)상환의무인-법인명
			repaymentObligationsNameRepresentative = VOUtils.toString(repaymentObligationsNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)상환의무인-성명(대표자명)
			repaymentObligationsAddress = VOUtils.toString(repaymentObligationsAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)상환의무인-주소
			repaymentObligationsBankCode = VOUtils.toString(repaymentObligationsBankCode$ = VOUtils.read(in, 3)); // (조회결과)상환의무인-은행코드
			repaymentObligationsDepositAccountNumber = VOUtils.toString(repaymentObligationsDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)상환의무인-입금계좌번호
			repaymentObligationsSplitNumber = VOUtils.toString(repaymentObligationsSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)상환의무인-분할번호
			repaymentObligationsEndorsementNumber = VOUtils.toString(repaymentObligationsEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)상환의무인-배서번호
			unsecuredEndorsementYn = VOUtils.toString(unsecuredEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)무담보배서여부
			endorsementProhibitionEndorsementYn = VOUtils.toString(endorsementProhibitionEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)배서금지배서여부
			recourseClaimantIndvCorpSort = VOUtils.toString(recourseClaimantIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)상환청구인-개인법인구분
			recourseClaimantResidentBusinessNumber = VOUtils.toString(recourseClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)상환청구인-주민사업자번호
			recourseClaimantCorpName = VOUtils.toString(recourseClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)상환청구인-법인명
			recourseClaimantNameRepresentative = VOUtils.toString(recourseClaimantNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)상환청구인-성명(대표자명)
			recourseClaimantAddress = VOUtils.toString(recourseClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)상환청구인-주소
			recourseClaimantBankCode = VOUtils.toString(recourseClaimantBankCode$ = VOUtils.read(in, 3)); // (조회결과)상환청구인-은행코드
			recourseClaimantDepositAccountNumber = VOUtils.toString(recourseClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)상환청구인-입금계좌번호
			recourseClaimantSplitNumber = VOUtils.toString(recourseClaimantSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)상환청구인-분할번호
			recourseClaimantEndorsementNumber = VOUtils.toString(recourseClaimantEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)상환청구인-배서번호
			recourseClaimAmount = VOUtils.toLong(recourseClaimAmount$ = VOUtils.read(in, 15)); // (조회결과)상환청구금액
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // (조회결과)어음정보-전자어음번호
			sb.append(", noteInfoNoteType=").append(noteInfoNoteType).append(System.lineSeparator()); // (조회결과)어음정보-어음종류
			sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음발행일자
			sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음정보-전자어음발행지
			sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // (조회결과)어음정보-전자어음금액
			sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음만기일자
			sb.append(", noteInfoPaymentBankAndBranchCode=").append(noteInfoPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음정보-지급은행및점포코드
			sb.append(", defaultDetailsDefaultReasonCode=").append(defaultDetailsDefaultReasonCode).append(System.lineSeparator()); // (조회결과)부도내역-부도사유코드
			sb.append(", defaultDetailsDefaultDate=").append(defaultDetailsDefaultDate).append(System.lineSeparator()); // (조회결과)부도내역-부도일자
			sb.append(", repaymentObligationsIndvCorpSort=").append(repaymentObligationsIndvCorpSort).append(System.lineSeparator()); // (조회결과)상환의무인-개인법인구분
			sb.append(", repaymentObligationsResidentBusinessNumber=").append(repaymentObligationsResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)상환의무인-주민사업자번호
			sb.append(", repaymentObligationsCorpName=").append(repaymentObligationsCorpName).append(System.lineSeparator()); // (조회결과)상환의무인-법인명
			sb.append(", repaymentObligationsNameRepresentative=").append(repaymentObligationsNameRepresentative).append(System.lineSeparator()); // (조회결과)상환의무인-성명(대표자명)
			sb.append(", repaymentObligationsAddress=").append(repaymentObligationsAddress).append(System.lineSeparator()); // (조회결과)상환의무인-주소
			sb.append(", repaymentObligationsBankCode=").append(repaymentObligationsBankCode).append(System.lineSeparator()); // (조회결과)상환의무인-은행코드
			sb.append(", repaymentObligationsDepositAccountNumber=").append(repaymentObligationsDepositAccountNumber).append(System.lineSeparator()); // (조회결과)상환의무인-입금계좌번호
			sb.append(", repaymentObligationsSplitNumber=").append(repaymentObligationsSplitNumber).append(System.lineSeparator()); // (조회결과)상환의무인-분할번호
			sb.append(", repaymentObligationsEndorsementNumber=").append(repaymentObligationsEndorsementNumber).append(System.lineSeparator()); // (조회결과)상환의무인-배서번호
			sb.append(", unsecuredEndorsementYn=").append(unsecuredEndorsementYn).append(System.lineSeparator()); // (조회결과)무담보배서여부
			sb.append(", endorsementProhibitionEndorsementYn=").append(endorsementProhibitionEndorsementYn).append(System.lineSeparator()); // (조회결과)배서금지배서여부
			sb.append(", recourseClaimantIndvCorpSort=").append(recourseClaimantIndvCorpSort).append(System.lineSeparator()); // (조회결과)상환청구인-개인법인구분
			sb.append(", recourseClaimantResidentBusinessNumber=").append(recourseClaimantResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)상환청구인-주민사업자번호
			sb.append(", recourseClaimantCorpName=").append(recourseClaimantCorpName).append(System.lineSeparator()); // (조회결과)상환청구인-법인명
			sb.append(", recourseClaimantNameRepresentative=").append(recourseClaimantNameRepresentative).append(System.lineSeparator()); // (조회결과)상환청구인-성명(대표자명)
			sb.append(", recourseClaimantAddress=").append(recourseClaimantAddress).append(System.lineSeparator()); // (조회결과)상환청구인-주소
			sb.append(", recourseClaimantBankCode=").append(recourseClaimantBankCode).append(System.lineSeparator()); // (조회결과)상환청구인-은행코드
			sb.append(", recourseClaimantDepositAccountNumber=").append(recourseClaimantDepositAccountNumber).append(System.lineSeparator()); // (조회결과)상환청구인-입금계좌번호
			sb.append(", recourseClaimantSplitNumber=").append(recourseClaimantSplitNumber).append(System.lineSeparator()); // (조회결과)상환청구인-분할번호
			sb.append(", recourseClaimantEndorsementNumber=").append(recourseClaimantEndorsementNumber).append(System.lineSeparator()); // (조회결과)상환청구인-배서번호
			sb.append(", recourseClaimAmount=").append(recourseClaimAmount).append(System.lineSeparator()); // (조회결과)상환청구금액
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "520000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String userSort; // 이용자구분
	private String searchConditionSort; // 검색조건구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String currentCreditAccountNumber; // 당좌(입금)계좌번호
	private String recourseClaimDateInquiryStartDate; // 상환청구일기준조회시작일
	private String recourseClaimDateInquiryEndDate; // 상환청구일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0200520000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String userSort$; // 이용자구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCreditAccountNumber$; // 당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recourseClaimDateInquiryStartDate$; // 상환청구일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recourseClaimDateInquiryEndDate$; // 상환청구일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(userSort$)) { // 이용자구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(currentCreditAccountNumber$)) { // 당좌(입금)계좌번호
			return 17;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		userSort$ = VOUtils.write(out, userSort, 1); // 이용자구분
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentCreditAccountNumber$ = VOUtils.write(out, currentCreditAccountNumber, 16); // 당좌(입금)계좌번호
		recourseClaimDateInquiryStartDate$ = VOUtils.write(out, recourseClaimDateInquiryStartDate, 8); // 상환청구일기준조회시작일
		recourseClaimDateInquiryEndDate$ = VOUtils.write(out, recourseClaimDateInquiryEndDate, 8); // 상환청구일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0200520000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		userSort = VOUtils.toString(userSort$ = VOUtils.read(in, 1)); // 이용자구분
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentCreditAccountNumber = VOUtils.toString(currentCreditAccountNumber$ = VOUtils.read(in, 16)); // 당좌(입금)계좌번호
		recourseClaimDateInquiryStartDate = VOUtils.toString(recourseClaimDateInquiryStartDate$ = VOUtils.read(in, 8)); // 상환청구일기준조회시작일
		recourseClaimDateInquiryEndDate = VOUtils.toString(recourseClaimDateInquiryEndDate$ = VOUtils.read(in, 8)); // 상환청구일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0200520000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", userSort=").append(userSort).append(System.lineSeparator()); // 이용자구분
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentCreditAccountNumber=").append(currentCreditAccountNumber).append(System.lineSeparator()); // 당좌(입금)계좌번호
		sb.append(", recourseClaimDateInquiryStartDate=").append(recourseClaimDateInquiryStartDate).append(System.lineSeparator()); // 상환청구일기준조회시작일
		sb.append(", recourseClaimDateInquiryEndDate=").append(recourseClaimDateInquiryEndDate).append(System.lineSeparator()); // 상환청구일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "520000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "userSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recourseClaimDateInquiryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "recourseClaimDateInquiryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "defaultDetailsDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultDetailsDefaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationsIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentObligationsResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentObligationsCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentObligationsNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentObligationsAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentObligationsBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentObligationsDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentObligationsSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentObligationsEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "unsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementProhibitionEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recourseClaimantIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recourseClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recourseClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recourseClaimantNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recourseClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "recourseClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "recourseClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recourseClaimantSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recourseClaimantEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recourseClaimAmount", "fldLen", "15", "defltVal", "")
		);
	}

}
