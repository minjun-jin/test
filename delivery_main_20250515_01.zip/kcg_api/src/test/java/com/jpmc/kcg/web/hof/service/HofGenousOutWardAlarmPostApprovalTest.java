package com.jpmc.kcg.web.hof.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;

import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.jpmc.kcg.com.dao.ComAcctAlarmMMapper;
import com.jpmc.kcg.com.dto.ComAcctAlarmM;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.com.dao.ComAcctAlarmMWebDao;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.frw.dto.Header;

class HofGenousOutWardAlarmPostApprovalTest {
	@InjectMocks
	private HofGenousOutWardAlarmPostApproval postApprovalService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Mock
    private ComAcctAlarmMMapper comAcctAlarmMMapper;

    @Mock
    private ComAcctAlarmMWebDao comAcctAlarmWebDao;

    @Mock
    private WebApplicationContext WebApplicationContext;

    @BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}
    
    private ComAcctAlarmM createDto() {
        ComAcctAlarmM dto = new ComAcctAlarmM();
        dto.setAcctNo("1234567890");
        dto.setPshMsgTmpltId(17);
        return dto;
    }

    @Test
    void testPostApprovalForInsert() {
        // given
        ComAcctAlarmM dto = createDto();

        // when
        Object result = postApprovalService.postApproval("I", dto);

        // then
        assertEquals(dto, result);
        verify(comAcctAlarmMMapper).updateByPrimaryKey(any(ComAcctAlarmM.class));
    }

    @Test
    void testPostApprovalForUpdate() {
        // given
        ComAcctAlarmM dto = createDto();

        // when
        Object result = postApprovalService.postApproval("U", dto);

        // then
        assertEquals(dto, result);
        verify(comAcctAlarmMMapper).updateByPrimaryKey(any(ComAcctAlarmM.class));
    }

    @Test
    void testPostApprovalForDelete() {
        // given
        ComAcctAlarmM dto = createDto();

        // when
        Object result = postApprovalService.postApproval("D", dto);

        // then
        assertEquals(dto, result);
        verify(comAcctAlarmMMapper).deleteByPrimaryKey(eq(dto.getAcctNo()), eq(dto.getPshMsgTmpltId()));
    }

    @Test
    void testPostRejectForInsert() {
        // given
        ComAcctAlarmM dto = createDto();

        // when
        Object result = postApprovalService.postReject("I", dto);

        // then
        assertEquals(dto, result);
        verify(comAcctAlarmMMapper).deleteByPrimaryKey(eq(dto.getAcctNo()), eq(dto.getPshMsgTmpltId()));
    }

    @Test
    void testPostRejectForUpdate() {
        // given
        ComAcctAlarmM dto = createDto();

        // when
        Object result = postApprovalService.postReject("U", dto);

        // then
        assertEquals(dto, result);
        verify(comAcctAlarmWebDao).updateComAcctAlarmMAprvStsCd(any(ComAcctAlarmM.class));
    }
    
    @Test
    void testPostApprovalWithUpdate_shouldUpdate() {
        // given
        ComAcctAlarmM dto = createDto();

        // 정확한 enum 값 사용
        String aprvRqstDvsnCd = AprvRqstDvsnCdEnum.UPDATE.getValue(); // 일반적으로 "U"
        
        // when
        Object result = postApprovalService.postApproval(aprvRqstDvsnCd, dto);

        // then
        assertEquals(dto, result);
        assertEquals(AprvStsCdEnum.APPROVED.getValue(), dto.getAprvStsCd());
        assertEquals("testStaff", dto.getChkId());
        assertNotNull(dto.getChkDttm());

        verify(comAcctAlarmMMapper).updateByPrimaryKey(dto);
    }
}
