package com.jpmc.kcg.web.cms.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.cms.biz.vo.*;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.web.cms.dao.CmsSndRcvFileLWebDao;
import com.jpmc.kcg.web.cms.dto.CmsSndRcvFileLWeb;
import com.jpmc.kcg.web.cms.service.dto.CountEB2030FeeDataOut;
import com.jpmc.kcg.web.cms.service.dto.ReconciliationKcgKftcIn;
import com.jpmc.kcg.web.cms.service.dto.ReconciliationKcgKftcOut;
import com.jpmc.kcg.web.com.constants.BCMN01;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
class ReconciliationKcgKftcSvcTest {

	@Mock
	private CmsSndRcvFileLWebDao cmsSndRcvFileLWebDao;
    
    @Mock
    private BizDate bizDate;

    @InjectMocks
    private ReconciliationKcgKftcSvc service;
    
    private ReconciliationKcgKftcIn input;
    private MockedStatic<VOUtils> mockStatic;
    
    @BeforeEach
    void setUp() {
    	// Initialization code if needed
    	input = new ReconciliationKcgKftcIn();
    	mockStatic = Mockito.mockStatic(VOUtils.class);
    }

    @AfterEach
    public void afterEach() {
    	// VOUtils static mock 해제
    	if (mockStatic != null) {
    		mockStatic.close();
    	}
    }
    
    @Test
    void getReconciliationKCGKFTC_Success01() {
    	input.setTrDt("20240910");

    	List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        // Populate with mock data for different file names as needed
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setFileNm("EB00" + "0910");
        mockData.setTlgCtt("R000000010000000057EB300000000001111000000345620000000000578633200000000005630000000001204550000000067600000000000000700000000000001100D000000000000800         ");
        mockDataList.add(mockData);

        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);

        KftCmsEB00R mockVO= new KftCmsEB00R();
        mockVO.setSettlementOrderTypeCode("EB30"); 
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB00R.class)))
        .thenReturn(mockVO);

//        when(bizDate.getPrevBizDay(anyString(), anyInt())).thenReturn("20240909");
        // Act
        ReconciliationKcgKftcOut output = service.getReconciliationKCGKFTC(input);

        // Assert
        assertNotNull(output);
        assertEquals(BCMN01.SUCCESS, output.getRsltCode());
        
    }
    
    @Test
    void getReconciliationKCGKFTC_Success02() {
    	input.setTrDt("20240910");

    	List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        // Populate with mock data for different file names as needed
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setFileNm("EB00" + "0910");
        mockData.setTlgCtt("R000000010000000057EB600000000000001560000012320000000000948730000000000034530000000000009350000000567600000000000012700000009493921100D000000000000800         ");
        mockDataList.add(mockData);

        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);

        
        KftCmsEB00R mockVO= new KftCmsEB00R();
        mockVO.setSettlementOrderTypeCode("EB60"); 
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB00R.class)))
        .thenReturn(mockVO);

//        when(bizDate.getPrevBizDay(anyString(), anyInt())).thenReturn("20240909");
        // Act
        ReconciliationKcgKftcOut output = service.getReconciliationKCGKFTC(input);

        // Assert
        assertNotNull(output);
        assertEquals(BCMN01.SUCCESS, output.getRsltCode());
    }
    @Test
    void getReconciliationKCGKFTC_Success03() {
    	input.setTrDt("20240910");

    	List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        // Populate with mock data for different file names as needed
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setFileNm("EB00" + "0910");
        mockData.setTlgCtt("R000000010000000057EB2000000000560781000000009820000000000235430000000000034030000000000000052000000987600000000000099700000000000001100D000000000000800         ");
        mockDataList.add(mockData);

        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);

        
        KftCmsEB00R mockVO= new KftCmsEB00R();
        mockVO.setSettlementOrderTypeCode("EB20"); 
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB00R.class)))
        .thenReturn(mockVO);

//        when(bizDate.getPrevBizDay(anyString(), anyInt())).thenReturn("20240909");
        // Act
        ReconciliationKcgKftcOut output = service.getReconciliationKCGKFTC(input);

        // Assert
        assertNotNull(output);
        assertEquals(BCMN01.SUCCESS, output.getRsltCode());
    }
    
    @Test
    void getReconciliationKCGKFTC_settlementOrderTypeCode_default_case() {
        input.setTrDt("20240910");
        
        List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setFileNm("EB00" + "0910");
        mockData.setTlgCtt("mockTlgCtt");
        mockDataList.add(mockData);
        
        KftCmsEB00R voOut = mock(KftCmsEB00R.class);
        when(voOut.getSettlementOrderTypeCode()).thenReturn("UNKNOWN"); // Unknown case
        when(VOUtils.toVo(any(String.class), eq(KftCmsEB00R.class))).thenReturn(voOut);
        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);
    
        ReconciliationKcgKftcOut result = service.getReconciliationKCGKFTC(input);
    
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
        // settlementOrderTypeCode default branch까지 탐
    }
    
    @Test
    void getReconciliationKCGKFTC_no_eb2030_list() {
        input.setTrDt("20240910");
    
        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(new ArrayList<>());
        when(cmsSndRcvFileLWebDao.selectEB2030List(any())).thenReturn(new ArrayList<>());
        when(cmsSndRcvFileLWebDao.countEB2030FeeData(any())).thenReturn(null);
    
        ReconciliationKcgKftcOut result = service.getReconciliationKCGKFTC(input);
    
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
        // EB2030 파일이 없을 때도 정상 성공
    }
    
    @Test
    void getReconciliationKCGKFTC_feeData_null() {
        input.setTrDt("20240910");
    
        List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setFileNm("EB00" + "0910");
        mockData.setTlgCtt("mockTlgCtt");
        mockDataList.add(mockData);
        
        KftCmsEB00R voOut = mock(KftCmsEB00R.class);
        when(voOut.getSettlementOrderTypeCode()).thenReturn("EB20");
        when(VOUtils.toVo(any(String.class), eq(KftCmsEB00R.class))).thenReturn(voOut);
    
        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);
        when(cmsSndRcvFileLWebDao.selectEB2030List(any())).thenReturn(new ArrayList<>());
        when(cmsSndRcvFileLWebDao.countEB2030FeeData(any())).thenReturn(null);
    
        ReconciliationKcgKftcOut result = service.getReconciliationKCGKFTC(input);
    
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
        // feeData가 null이어도 성공해야 한다
    }
    
    @Test
    void getReconciliationKCGKFTC_eb00list_null() {
        input.setTrDt("20240910");
    
        when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(null);
        when(cmsSndRcvFileLWebDao.selectEB2030List(any())).thenReturn(new ArrayList<>());
        when(cmsSndRcvFileLWebDao.countEB2030FeeData(any())).thenReturn(null);
    
        ReconciliationKcgKftcOut result = service.getReconciliationKCGKFTC(input);
    
        assertEquals(BCMN01.SUCCESS, result.getRsltCode());
    }

  
  @Test
  void getReconciliationKCGKFTC_Success05() {
  	input.setTrDt("20240910");
  	
  	CountEB2030FeeDataOut mockData = new CountEB2030FeeDataOut();
  	mockData.setCrditTrDepositFeeKcgA(new BigDecimal(1));
  	mockData.setCrditTrDepositFeeKcgB(new BigDecimal(0));
  	mockData.setDailyDebitTrDepositFeeKcgA(new BigDecimal(1));
  	mockData.setDailyDebitTrDepositFeeKcgB(new BigDecimal(0));
  	mockData.setDailyDebitTrDepositFeeKcgC(new BigDecimal(1));
  	mockData.setDebitTrferDepositFeeKcgA(new BigDecimal(1));
  	mockData.setDebitTrferDepositFeeKcgB(new BigDecimal(0));
  	mockData.setDebitTrferDepositFeeKcgC(new BigDecimal(1));
  	
  	when(cmsSndRcvFileLWebDao.countEB2030FeeData(any())).thenReturn(mockData);
  	
  	// Act
      ReconciliationKcgKftcOut output = service.getReconciliationKCGKFTC(input);

      // Assert
      assertEquals(BCMN01.SUCCESS, output.getRsltCode());
      assertEquals(BigDecimal.valueOf(200), output.getDebitTrferDepositFeeKcg());
      assertEquals(BigDecimal.valueOf(100), output.getCrditTrDepositFeeKcg());
      assertEquals(BigDecimal.valueOf(380), output.getDailyDebitTrDepositFeeKcg());
  }
    
  @Test
  void getReconciliationKCGKFTC_Success06() {
  	input.setTrDt("20240910");
  	List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
    // Populate with mock data for different file names as needed
  	CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
    mockData.setFileNm("EB00" + "0910");
    mockData.setTlgCtt("R000000010000000057EB9900000000560781000000009820000000000235430000000000034030000000000000052000000987600000000000099700000000000001100D000000000000800         ");
    mockDataList.add(mockData);
    
    KftCmsEB00R voOut = mock(KftCmsEB00R.class);
    when(voOut.getSettlementOrderTypeCode()).thenReturn("EB99");
    when(VOUtils.toVo(any(String.class), eq(KftCmsEB00R.class))).thenReturn(voOut);
    when(cmsSndRcvFileLWebDao.selectEB00List(any())).thenReturn(mockDataList);
//    when(bizDate.getPrevBizDay(anyString(), anyInt())).thenReturn("20240909");
    
  	// Act
    ReconciliationKcgKftcOut output = service.getReconciliationKCGKFTC(input);

      // Assert
      assertEquals(BCMN01.SUCCESS, output.getRsltCode());
      assertNull(output.getDebitTrferDepositAmtKftc());
  } 
  
    @Test
    void getReconciliationKCGKFTC_ValidInput() {
    	input.setTrDt(null);
    	
    	BusinessException exception = assertThrows(BusinessException.class, () -> {
            service.getReconciliationKCGKFTC(input);
        });

    	assertEquals("MCMNE01002", exception.getErrorCode());
    }

}
