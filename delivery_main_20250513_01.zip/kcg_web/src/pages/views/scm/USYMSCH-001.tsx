import { $eventUtils } from "@/utils/common.event"
/** ***********************************************************************
 * @ 서비스경로  : 시스템 > 배치 > 배치작업관리
 * @ 페이지설명  : [USYMSCH-001] 배치작업관리
 * @ 파일명     : USYMSCH-001.tsx
 * @ 작성자     : 이수현 (suehyun.lee@bankwareglobal.com)
 * @ 작성일     : 2023-05-24
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2023-05-24             이수현                 최초작성
 * 2024-04-24             조인근                 화면전면수정
 ************************************************************************ */
import CONFIG from "@/config/siteConfig"
import useCode from "@/hooks/useCode"
import useModal from "@/hooks/useModal"
import useProxy from "@/hooks/useProxy"
import useForm from "@/hooks/useForm"
import { $i18nUtils } from "@/utils/common.i18n"
import { useCallback, useMemo, useRef, useState } from "react"

import Page from "@/components/Page"
import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import CardCol from "@/components/CardCol"
import CardRow from "@/components/CardRow"
import ContentToggle from "@/components/ContentToggle"
import Grid from "@/components/Grid"
import GridCount from "@/components/GridCount"
import IMask from "imask"
import InputBox from "@/components/InputBox"
import InputIconBox from "@/components/InputIconBox"
import LabelBox from "@/components/LabelBox"
import SelectBox from "@/components/SelectBox"

import { Batch, CodeItem, PopupParam } from "@/types/index"
import useGrid from "@/hooks/useGrid"
import AuthButton from "@/components/AuthButton"
import useDownloader from "@/hooks/useDownloader"
import useRequiredStatus from "@/hooks/useRequireStatus"
import cronstrue from "cronstrue"

function USYMSCH001() {
  const $codeHooks = useCode()
  const $proxyHooks = useProxy()
  const $modalHooks = useModal()

  const [selectedDate, setSelectedDate] = useState("")
  const [selectedCron, setSelectedCron] = useState("")
  const [isDateDisabled, setIsDateDisabled] = useState(false)
  const [isCronDisabled, setIsCronDisabled] = useState(false)

  // 조회 Form
  const { control, setValue, reset, validate } = useForm({
    mode: "onChange",
    formName: "searchForm",
    shouldFocusError: false,
    defaultValues: {
      btWrkId: "",
      btWrkNm: "",
      btWrkDsc: "",
      bizGbCd: "",
      useFl: CONFIG.BOOLEAN.Y,
    },
  })

  // 등록 Form
  const {
    control: control2,
    setValue: setValue2,
    reset: reset2,
    getValues: getValues2,
    validate: validate2,
  } = useForm({
    mode: "onChange",
    formName: "updateForm",
    shouldFocusError: false,
    defaultValues: {
      btWrkId: "",
      // btSysVal: "",
      bizGbCd: "",
      bizGbNm: "",
      // btExsvrNm: "",
      btWrkNm: "",
      btPgmExpl: "",
      // paramCd: "",
      paramVal: "",
      cronCmd: "",
      useFl: "",
      btWrkDsc: "",
      btPrvYn: "",
      schdDvsnCd: "",
      dtDvsnCd: "",
      schdStaTm: "",
      schdEndTm: "",
    },
  })

  // 선배치작업등록 Form
  const {
    control: control3,
    setValue: setValue3,
    reset: reset3,
    getValues: getValues3,
    validate: validate3,
  } = useForm({
    mode: "onChange",
    formName: "regPrevBatchForm",
    shouldFocusError: false,
    defaultValues: {
      btWrkId: "",
    },
  })

  /**
   * 배치작업선택 팝업 열기
   */
  const openBatchJobSelectionPopup = (e: any) => {
    $eventUtils.setEventContext(e)

    const popupInfo: PopupParam = {
      screenId: "PSYMSCH-010",
      instance: "pages/popup/scm/PSYMSCH-010",
    }
    $modalHooks.openPopup(popupInfo).then((result: any) => {
      if (result.btWrkId === getValues2("btWrkId")) {
        // 동일한 배치작업ID는 선배치로 등록할 수 없습니다.
        $modalHooks.alert({
          content: $i18nUtils.trans("MSG#cannotEnrlSameBtch"),
        })
        return
      }

      const isSamePreBatchExist = gridPreBatchRef.current
        .getAllRows()
        .filter((item: any) => item.btWrkId === result.btWrkId)

      if (isSamePreBatchExist.length > 0) {
        $modalHooks.alert({
          content: $i18nUtils.trans("MSG#cannotEnrlSamePrevBtch"),
        })
        return
      }

      if (result && Object.keys(result).length !== 0) {
        gridPreBatchRef.current.addRow(result)
        const count = gridPreBatchRef.current.getAllRows().length
        setPreBatchTotalCnt(count)
        setValue3("btWrkId", result.btWrkId)
      }
    })
  }

  // 배치작업 수정/등록 가능 여부
  const [isEditable, setIsEditable] = useState(false)

  // 그리드 config
  const {
    gridConfig,
    gridCount,
    gridData,
    gridRef,
    pagingRef,
    resetGrid,
    setGridConfig,
    setGridCount,
    setGridData,
  } = useGrid({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkId"), // 배치작업ID
        field: "btWrkId",
        flex: 0.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#bizDvsn"), // 업무구분
        field: "bizGbCd",
        flex: 0.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkNm"), // 배치작업명
        field: "btWrkNm",
        flex: 1.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkDsc"), // 배치작업설명
        field: "btWrkDsc",
        cellClass: "t-left",
        flex: 1.6,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchPgmNm"), // 배치프로그램명
        field: "btPgmExpl",
        cellClass: "t-left",
        flex: 2.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#schdlJobName"), // 스케줄작업명
        field: "schdlJobName",
        flex: 0.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#schdDvsnCd"), // 스케줄구분코드
        field: "schdDvsnCd",
        codeValueOption: "name",
        flex: 1.6,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tractDtDvsnCd"), // 거래일자구분코드
        field: "dtDvsnCd",
        codeValueOption: "name",
        flex: 0.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#cronCmd"), // 크론 명령어
        field: "cronCmd",
        flex: 0.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#useYn"), // 사용여부
        field: "useFl",
        flex: 0.6,
      },
    ],
    rowClassRules: {
      // apply amber 2004
      "rag-amber-outer": (params: { data: { aprvStsCd: string } }) =>
        params.data.aprvStsCd !== "02",
    },
    allFlexOption: "auto",
    onRowClicked: useCallback((event: any) => {
      const { data } = event

      setIsEditable(true)

      setValue2("btWrkId", data.btWrkId)
      setValue2("btSysVal", data.btSysVal)
      setValue2("bizGbCd", data.bizGbCd)
      setValue2("bizGbNm", data.bizGbNm)
      setValue2("btExsvrNm", data.btExsvrNm)
      setValue2("btWrkNm", data.btWrkNm)
      setValue2("btPgmExpl", data.btPgmExpl)
      setValue2("paramCd", data.paramCd || "")
      setValue2("paramVal", data.paramVal)
      setValue2("cronCmd", data.cronCmd)
      setValue2("cronStr", formattingCronExpr(data.cronCmd))
      setValue2("useFl", data.useFl)
      setValue2("btWrkDsc", data.btWrkDsc)
      setValue2("btPrvYn", data.btPrvYn)
      setValue2("schdDvsnCd", data.schdDvsnCd)
      setValue2("dtDvsnCd", data.dtDvsnCd)
      setValue2("schdStaTm", data.schdStaTm)
      setValue2("schdEndTm", data.schdEndTm)
      // 배치 강제 실행 가능 여부
      setValue2("btchExecYn", data.useFl)

      // setValueSchd("schdDvsnCd", data.schdDvsnCd)
      // setValueSchd("dtDvsnCd", data.dtDvsnCd)
      // setValueSchd("schdStaTm", data.schdStaTm)
      // setValueSchd("schdEndTm", data.schdEndTm)

      // setValueCron("cronCmd", data.cronCmd)

      setGridPreBatchData([])
      setPreBatchTotalCnt(0)
      setGridUsingBatchData([])
      setUsingBatchTotalCnt(0)
      setDeletePreBatchData([])
      reset3()

      // 선배치작업 조회
      searchPreBatchData(data.btWrkId)
      searchUsingBatchData(data.btWrkId)
    }, []),
  })
  // 그리드 건수
  // const [totalCnt, setTotalCnt] = useState(0)

  // 선배치작업 그리드 config
  const {
    gridConfig: gridPreBatchConfig,
    setGridConfig: setGridPreBatchConfig,
  } = useGrid({
    crud: {
      width: 80,
      maxWidth: 80,
    },
    columnDefs: [
      {
        headerName: "",
        field: "check",
        headerCheckboxSelection: true,
        checkboxSelection: true,
        showDisabledCheckboxes: true,
        width: 50,
        maxWidth: 50,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkId"), // 배치작업ID
        field: "btWrkId",
        flex: 0.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#bizDvsn"), // 업무구분
        field: "bizGbCd",
        flex: 0.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkNm"), // 배치작업명
        field: "btWrkNm",
        filter: true,
        flex: 1,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchPgmNm"), // 배치프로그램명
        field: "btPgmExpl",
        cellClass: "t-left",
        flex: 1.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#cronCmd"), // 크론 명령어
        field: "cronCmd",
        flex: 0.9,
      },
    ],
  })
  // 선배치작업 그리드 data
  const [gridPreBatchData, setGridPreBatchData] = useState<Batch[]>([])
  // 선배치작업 그리드 Ref
  const gridPreBatchRef = useRef<any>()
  // 선배치작업 그리드 건수
  const [preBatchTotalCnt, setPreBatchTotalCnt] = useState(0)

  // 후배치작업 그리드 config
  const {
    gridConfig: gridAfterBatchConfig,
    setGridConfig: setGridAfterBatchConfig,
  } = useGrid({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkId"), // 배치작업ID
        field: "btWrkId",
        flex: 0.8,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#bizDvsn"), // 업무구분
        field: "bizGbCd",
        flex: 0.9,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchWrkNm"), // 배치작업명
        field: "btWrkNm",
        filter: true,
        flex: 1,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#btchPgmNm"), // 배치프로그램명
        field: "btPgmExpl",
        cellClass: "t-left",
        flex: 2.0,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#cronCmd"), // 크론 명령어
        field: "cronCmd",
        flex: 0.9,
      },
    ],
    // onRowDoubleClicked: useCallback((event: any) => {
    //   const { data } = event

    //   if (data.btWrkId === getValues2("btWrkId")) {
    //     // 동일한 배치작업ID는 선배치로 등록할 수 없습니다.
    //     $modalHooks.alert({
    //       content: $i18nUtils.trans("MSG#cannotEnrlSameBtch"),
    //     })
    //     return
    //   }

    //   gridPreBatchRef.current.addRow(data)
    //   const count = gridPreBatchRef.current.getAllRows().length
    //   setPreBatchTotalCnt(count)
    // }, []),
  })

  // 후배치작업 그리드 data
  const [gridUsingBatchData, setGridUsingBatchData] = useState<Batch[]>([])

  // 후배치작업 그리드 Ref
  const gridUsingBatchRef = useRef<any>()

  // 후배치작업 그리드 건수
  const [usingBatchTotalCnt, setUsingBatchTotalCnt] = useState(0)

  // 삭제할 선배치작업 data
  const [deletePreBatchData, setDeletePreBatchData] = useState<Batch[]>([])

  const { isRequired, resetIsRequired, updateSchdDvsnCdStatus } =
    useRequiredStatus(getValues2)

  /**
   * 초기화 버튼 클릭
   */
  const initClick = (e: any) => {
    $eventUtils.setEventContext(e)
    resetGrid()
    setGridPreBatchData([])
    setPreBatchTotalCnt(0)
    setGridUsingBatchData([])
    setUsingBatchTotalCnt(0)
    setDeletePreBatchData([])
    reset()
    reset2()
    reset3()
    resetIsRequired()
    setIsEditable(true)
  }

  /**
   * 배치작업 등록 클릭
   */
  const addNewData = (e: any) => {
    $eventUtils.setEventContext(e)

    setGridPreBatchData([])
    setPreBatchTotalCnt(0)
    setGridUsingBatchData([])
    setUsingBatchTotalCnt(0)
    setDeletePreBatchData([])
    reset2()
    reset3()
    setIsEditable(false)
  }

  /**
   * 배치작업 목록 조회
   */
  const searchBatchData = (e: any) => {
    $eventUtils.setEventContext(e)

    validate().then((data: any) => {
      const param = {
        interfaceCd: "cmn",
        interfaceId: "getBtchWrkList",
        btWrkId: data.btWrkId,
        btWrkNm: data.btWrkNm,
        btWrkDsc: data.btWrkDsc,
        bizGbCd: data.bizGbCd,
        useFl: data.useFl,
      }
      $proxyHooks.async(param).then((response: any) => {
        setGridCount({
          totalCnt: response.data.totLen,
          currentCnt: response.data.totLen,
        })
        setGridData(() => response.data.subOutList)
        setGridPreBatchData([])
        setPreBatchTotalCnt(0)
        setGridUsingBatchData([])
        setUsingBatchTotalCnt(0)
        setDeletePreBatchData([])
        reset2()
        reset3()
        setIsEditable(false)
      })
    })
  }

  const { downloadExcel } = useDownloader(gridRef)

  /**
   * 배치작업 저장 클릭
   */
  const saveBatchClick = (e: any) => {
    $eventUtils.setEventContext(e)

    const prevBatchList = gridPreBatchRef.current
      .getAllRows()
      .map((batch: Batch) => ({
        crudType: batch.crudType ?? "",
        // crudType: batch.crudType,
        btPrevWrkId: batch.btWrkId,
        btPrevWrkNm: batch.btWrkNm,
      }))

    if (isEditable) {
      saveBatch(e, "modifyBtchWrk", [...prevBatchList, ...deletePreBatchData])
      return
    }

    saveBatch(e, "registerBtchWrk", prevBatchList)
  }

  /**
   * 배치작업 저장
   */
  const saveBatch = (e: any, interfaceId: string, prevBatchList?: Batch[]) => {
    validate2().then((data: any) => {
      $modalHooks
        .confirm({ content: $i18nUtils.trans("MSG#saveCnfMsg") }) // 내용을 저장하시겠습니까?
        .then((ok) => {
          if (ok) {
            const param = {
              interfaceCd: "cmn",
              interfaceId,
              btWrkId: data.btWrkId,
              btSysVal: data.btSysVal,
              bizGbCd: data.bizGbCd,
              btExsvrNm: data.btExsvrNm,
              btWrkNm: data.btWrkNm,
              btPgmExpl: data.btPgmExpl,
              paramCd: data.paramCd,
              paramVal: data.paramVal,
              cronCmd: data.cronCmd,
              useFl: data.useFl,
              btWrkDsc: data.btWrkDsc,
              schdDvsnCd: data.schdDvsnCd,
              dtDvsnCd: data.dtDvsnCd,
              schdStaTm: data.schdStaTm,
              schdEndTm: data.schdEndTm,
              btPrevWrk: prevBatchList,
            }
            $proxyHooks.async(param).then((response: any) => {
              // 배치작업 목록을 재조회
              searchBatchData(e)
            })
          }
        })
    })
  }

  /**
   * 선배치작업 목록 조회
   */
  const searchPreBatchData = (btWrkId: string) => {
    const param = {
      interfaceCd: "cmn",
      interfaceId: "getPrevBtchWrkList",
      btWrkId,
    }
    $proxyHooks.async(param).then((response: any) => {
      setGridPreBatchData(() => response.data.subOutList)
      setPreBatchTotalCnt(response.data.totLen)
    })
  }

  /**
   * 선작업배치 목록 삭제
   */
  const deletePreBatch = (e: any) => {
    $eventUtils.setEventContext(e)

    // check box 선택된 Row
    const selectRowList = gridPreBatchRef.current.getSelectedRows()

    if (selectRowList.length === 0) {
      $modalHooks.alert({ content: $i18nUtils.trans("MSG#noDelRow") }) // 삭제할 행을 선택해주세요.
      return
    }

    const deleteRowList: Batch[] = selectRowList
      .filter((item: Batch) => item.crudType !== CONFIG.CRUD.CREATE)
      .map((row: Batch) => {
        const deleteBatch: Batch = {
          crudType: CONFIG.CRUD.DELETE,
          btPrevWrkId: row.btWrkId,
          btPrevWrkNm: row.btWrkNm,
        }
        return deleteBatch
      })

    setDeletePreBatchData(deleteRowList)
    gridPreBatchRef.current.delRow(
      false,
      () => {
        $modalHooks.alert({ content: $i18nUtils.trans("MSG#noDelRow") }) // 삭제할 행을 선택해주세요.
      },
      () => {
        $modalHooks.alert({ content: $i18nUtils.trans("MSG#cannotDelRow") }) // 해당 행을 삭제할수 없습니다.
      },
    )
    setPreBatchTotalCnt(gridPreBatchRef.current.getAllRows().length)
  }

  /**
   * 후배치작업 목록 조회
   */

  const searchUsingBatchData = (btWrkId: string) => {
    const param = {
      interfaceCd: "cmn",
      interfaceId: "getAfBtchWrkList",
      btWrkId,
    }
    $proxyHooks.async(param).then((response: any) => {
      setGridUsingBatchData(() => response.data.subOutList)
      setUsingBatchTotalCnt(response.data.totLen)
    })
  }

  const handleSelectSchdDvsnCd = () => {
    setValue2("dtDvsnCd", "")
    setValue2("schdStaTm", "")
    setValue2("schdEndTm", "")
    setValue2("cronCmd", "")
    setValue2("cronStr", "")
    updateSchdDvsnCdStatus("schdDvsnCd")
  }

  const shouldDisabledDtDvsnCdSchdTime = useMemo(() => {
    const schdDvsnCdValue = getValues2("schdDvsnCd")
    if (schdDvsnCdValue == "00" || schdDvsnCdValue == "01") {
      return true
    }
    return false
  }, [getValues2("schdDvsnCd")])

  const shouldDisabledCronCmd = useMemo(() => {
    const schdDvsnCdValue = getValues2("schdDvsnCd")
    if (schdDvsnCdValue !== "00") {
      return true
    }
    return false
  }, [getValues2("schdDvsnCd")])

  const shouldShowForcedBtchBtn = useMemo(() => {
    const btWrkIdValue = getValues2("btWrkId")
    const btchExecYnValue = getValues2("btchExecYn")
    if (btWrkIdValue && btchExecYnValue == CONFIG.BOOLEAN.Y) {
      return true
    }
    return false
  }, [getValues2("btWrkId"), getValues2("btchExecYn")])

  // 배치 강제 실행
  const forcedBtch = async (e: any) => {
    const btWrkId = getValues2("btWrkId")
    const schdDvsnCdValue = getValues2("schdDvsnCd")

    // 0. 입력값 검증
    if (!btWrkId) {
      $modalHooks.alert({
        content: $i18nUtils.trans("MSG#checkInputValue"),
      })
      return
    }

    // 1. 배치작업테이블에 등록이 되어있지 않거나(or 승인코드 != 02) 사용여부가 N인 경우
    const findBtch = gridData.find((btch: any) => btch.btWrkId === btWrkId)
    if (
      !findBtch ||
      findBtch.useFl === "N" ||
      !findBtch.useFl ||
      findBtch.aprvStsCd !== "02"
    ) {
      $modalHooks.alert({ content: $i18nUtils.trans("MSG#notFoundBtch") })
      return
    }

    // // 2. 선배치 또는 후배치가 있는 경우
    // if (preBatchTotalCnt > 0 || usingBatchTotalCnt > 0) {
    //   $modalHooks.alert({ content: $i18nUtils.trans("MSG#isExistPrevOrUsing") })
    //   return
    // }

    // 2. Cron batch인 경우
    if (schdDvsnCdValue === "00") {
      $modalHooks.alert({ content: $i18nUtils.trans("MSG#notExecBtch") })
      return
    }

    // 3. 오늘 날짜 배치작업결과(최신순 정렬)에 있는 경우, 최신 결과의 작업완료상태를 보여줌 ok 하면 진행
    const param = {
      interfaceCd: "cmn",
      interfaceId: "getSpecificBtchWrkExecRsltList",
      btWrkId,
    }
    const response: any = await $proxyHooks.async(param, {
      toastLoading: false,
    })
    const btchWrkExecRsltList: Batch[] = response.data?.subOutList

    $eventUtils.setEventContext(e)

    if (btchWrkExecRsltList && btchWrkExecRsltList.length > 0) {
      // 내림차순
      btchWrkExecRsltList.sort((a: any, b: any) => {
        return b.execEdtm - a.execEdtm
      })

      const cmpltStsCd = btchWrkExecRsltList[0].cmpltStsCd

      const codeLabel = cmpltStsCd
        ? $codeHooks.codeValue("CMPLT_STS_CD", cmpltStsCd, {
            visibleCode: false,
            visibleName: true,
          })
        : null

      $modalHooks
        .confirm({
          content: $i18nUtils.trans("MSG#forcedBtchStatus", { 0: codeLabel }),
          // content: $i18nUtils.trans("MSG#exctConfirm"),
        })
        .then((ok: boolean | unknown) => {
          if (ok) {
            const param = {
              interfaceCd: "cmn",
              interfaceId: "forcedBtch",
              btWrkId,
              bizGbCd: getValues2("bizGbCd"),
              paramVal: getValues2("paramVal"),
            }
            $proxyHooks.async(param).then((response: any) => {})
          }
        })
    } else {
      $modalHooks
        .confirm({ content: $i18nUtils.trans("MSG#forcedBtch") })
        // .confirm({ content: $i18nUtils.trans("MSG#exctConfirm") })
        .then((ok: boolean | unknown) => {
          if (ok) {
            const param = {
              interfaceCd: "cmn",
              interfaceId: "forcedBtch",
              btWrkId,
              bizGbCd: getValues2("bizGbCd"),
              paramVal: getValues2("paramVal"),
            }
            $proxyHooks.async(param).then((response: any) => {})
          }
        })
    }
  }

  const openCronGenPopup = () => {
    const popupInfo: PopupParam = {
      screenId: "PSYMGEN-001",
      instance: "pages/popup/scm/PSYMGEN-001",
    }
    $modalHooks.openPopup(popupInfo).then((result: any) => {
      const { cronExpr } = result
      if (cronExpr) {
        setValue2("cronCmd", cronExpr)
        setValue2("cronStr", formattingCronExpr(cronExpr))
      }
    })
  }

  const formattingCronExpr = (cronExpr: string) => {
    const fields = cronExpr.trim().split(/\s+/)
    const dayOfMonth = fields[3]

    const isEveryDay = ["*", "1/1", "*/1"].includes(dayOfMonth)

    const description = cronstrue.toString(cronExpr)

    return isEveryDay ? `Every day, ${description}` : description
  }

  // const filterDtDvsnCdList = (): Promise<CodeItem[]> =>
  //   new Promise((resolve, reject) => {
  //     $codeHooks
  //       .getCodeList("DT_DVSN_CD")
  //       .then((codeList: CodeItem[]) => {
  //         const filteredList = codeList.filter(
  //           (item) =>
  //             item.codeField.trim() === "D" ||
  //             item.codeField.trim() === "-1" ||
  //             item.codeField.trim() === "-2" ||
  //             item.codeField.trim() === "+1" ||
  //             item.codeField.trim() === "31",
  //         )
  //         resolve(filteredList)
  //       })
  //       .catch((error) => {
  //         reject(error)
  //       })
  //   })

  /**
   * 사용중인 배치작업 목록 조회
   */
  // const searchUsingBatchData = () => {
  //   validate3().then((data: any) => {
  //     const param = {
  //       interfaceCd: "cmn",
  //       interfaceId: "getAfBtchWrkList",
  //       btWrkId: data.btWrkId,
  //       useFl: CONFIG.BOOLEAN.Y, // 사용중인 배치만 조회
  //     }
  //     $proxyHooks.async(param).then((response: any) => {
  //       setUsingBatchTotalCnt(response.data.totLen)
  //       setGridUsingBatchData(() => response.data.subOutList)
  //     })
  //   })
  // }

  return (
    <Page ctrlEnter={searchBatchData}>
      <div className="row-group">
        {/** Sub Content S */}
        <div className="sub-content search-wrap">
          <h3 className="tit">{$i18nUtils.trans("SCRNITM#srchCndtn")}</h3>
          <ButtonGroup>
            <Button
              name="init"
              i18n={$i18nUtils.trans("SCRNITM#init")}
              color="white btn-lg"
              onClick={initClick}
            >
              초기화
            </Button>
            <Button
              name="search"
              i18n={$i18nUtils.trans("SCRNITM#search")}
              color="green"
              onClick={searchBatchData}
            >
              조회
            </Button>
          </ButtonGroup>
          <ContentToggle />
          <div className="view-box" data-form="searchForm">
            <CardRow cols={5}>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#btchWrkId")}>
                  배치작업ID
                </LabelBox>
                <InputBox
                  control={control}
                  name="btWrkId"
                  i18n={$i18nUtils.trans("SCRNITM#btchWrkId")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#btchWrkNm")}>
                  배치작업명
                </LabelBox>
                <InputBox
                  control={control}
                  name="btWrkNm"
                  i18n={$i18nUtils.trans("SCRNITM#btchWrkNm")}
                  mask={{
                    mask: /^.{1,100}$/,
                  }}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#btchWrkDsc")}>
                  배치작업설명
                </LabelBox>
                <InputBox
                  control={control}
                  name="btWrkDsc"
                  i18n={$i18nUtils.trans("SCRNITM#btchWrkDsc")}
                  mask={{
                    mask: /^.{1,500}$/,
                  }}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#bizDvsn")}>
                  업무구분
                </LabelBox>
                <SelectBox
                  control={control}
                  name="bizGbCd"
                  i18n={$i18nUtils.trans("SCRNITM#bizDvsn")}
                  listPromise={$codeHooks.getCodeList("BIZ_DVSN_CD")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#useYn")}>
                  사용여부
                </LabelBox>
                <SelectBox
                  control={control}
                  name="useFl"
                  i18n={$i18nUtils.trans("SCRNITM#useYn")}
                  listPromise={$codeHooks.getCodeList("USE_YN_CD")}
                  // blankType="all"
                />
              </CardCol>
            </CardRow>
          </div>
        </div>
        {/** // Sub Content E */}

        {/** Sub Content S */}
        <div className="sub-content">
          <GridCount
            i18n={$i18nUtils.trans("SCRNITM#btchLst")}
            count={gridCount.totalCnt}
          />
          <ButtonGroup>
            <Button
              name="excel"
              i18n={$i18nUtils.trans("SCRNITM#excel")}
              color="white"
              icon="down"
              onClick={downloadExcel}
            >
              Excel
            </Button>
          </ButtonGroup>
          <ContentToggle />
          <div className="view-box">
            <div className="col-01">
              <div className="cmm-table">
                <Grid
                  config={gridConfig}
                  rowData={gridData}
                  height={300}
                  ref={gridRef}
                />
              </div>
            </div>
          </div>
        </div>
        {/** // Sub Content E */}

        {/** Sub Content S */}
        <div className="detailListWrap">
          <div className="sub-content">
            <h3 className="tit">{$i18nUtils.trans("SCRNITM#btchWrkMng")}</h3>
            <ButtonGroup>
              <AuthButton
                name="new"
                i18n={$i18nUtils.trans("SCRNITM#new")}
                color="white"
                icon="add"
                onClick={addNewData}
                roles={[
                  CONFIG.ROLE_CD.ALL,
                  // CONFIG.ROLE_CD.KCG_OPS_STATIC_MAKER,
                  // CONFIG.ROLE_CD.KCG_OPS_STATIC_CHECKER,
                  CONFIG.ROLE_CD.KCG_TECH_SUPPORT,
                ]}
              >
                신규
              </AuthButton>
              {/* <Button name="modify"
                i18n={$i18nUtils.trans("SCRNITM#modify")}
                color="white"
                icon="modify"
                onClick={updateBatchClick}
                disabled={!isEditable}
              >
                수정
              </Button> */}
              <AuthButton
                name="save"
                i18n={$i18nUtils.trans("SCRNITM#save")}
                color="green"
                onClick={saveBatchClick}
                roles={[
                  CONFIG.ROLE_CD.ALL,
                  // CONFIG.ROLE_CD.KCG_OPS_STATIC_MAKER,
                  // CONFIG.ROLE_CD.KCG_OPS_STATIC_CHECKER,
                  CONFIG.ROLE_CD.KCG_TECH_SUPPORT,
                ]}
              >
                저장
              </AuthButton>
              {shouldShowForcedBtchBtn && (
                <AuthButton
                  name="run"
                  i18n={$i18nUtils.trans("SCRNITM#run")}
                  color="dark btn-lg"
                  onClick={forcedBtch}
                  roles={[
                    CONFIG.ROLE_CD.ALL,
                    // CONFIG.ROLE_CD.KCG_OPS_STATIC_MAKER,
                    // CONFIG.ROLE_CD.KCG_OPS_STATIC_CHECKER,
                    CONFIG.ROLE_CD.KCG_TECH_SUPPORT,
                  ]}
                >
                  실행
                </AuthButton>
              )}
            </ButtonGroup>
            <ContentToggle />
            <div className="view-box" data-form="updateForm">
              <CardRow cols={5}>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#btchWrkId")}>
                    배치작업ID
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="btWrkId"
                    i18n={$i18nUtils.trans("SCRNITM#btchWrkId")}
                    disabled
                  />
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#btchBizDvsn")}
                    required
                  >
                    배치업무구분
                  </LabelBox>
                  <SelectBox
                    control={control2}
                    name="bizGbCd"
                    i18n={$i18nUtils.trans("SCRNITM#btchBizDvsn")}
                    listPromise={$codeHooks.getCodeList("BIZ_DVSN_CD")}
                    rules={{
                      required: {
                        value: true,
                      },
                    }}
                    blankType={$i18nUtils.trans("SCRNITM#slct")}
                    disabled={isEditable}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#btchWrkNm")}
                    required
                  >
                    배치작업명
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="btWrkNm"
                    i18n={$i18nUtils.trans("SCRNITM#btchWrkNm")}
                    mask={{
                      mask: /^.{1,100}$/,
                    }}
                    rules={{
                      required: {
                        value: true,
                      },
                      maxLength: {
                        value: 100,
                      },
                    }}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#btchWrkDsc")}>
                    배치작업설명
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="btWrkDsc"
                    i18n={$i18nUtils.trans("SCRNITM#btchWrkDsc")}
                    mask={{
                      mask: /^.{1,500}$/,
                    }}
                    rules={{
                      maxLength: {
                        value: 500,
                      },
                    }}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#pgmNm")} required>
                    프로그램명
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="btPgmExpl"
                    i18n={$i18nUtils.trans("SCRNITM#pgmNm")}
                    mask={{
                      mask: /^.{1,200}$/,
                    }}
                    rules={{
                      required: {
                        value: true,
                      },
                      maxLength: {
                        value: 200,
                      },
                    }}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#paramVal")}>
                    파라미터값
                  </LabelBox>
                  <InputBox
                    control={control2}
                    name="paramVal"
                    i18n={$i18nUtils.trans("SCRNITM#paramVal")}
                    rules={{
                      maxLength: {
                        value: 500,
                      },
                    }}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#schdDvsnCd")}
                    required
                  >
                    스케줄구분코드
                  </LabelBox>
                  <SelectBox
                    control={control2}
                    name="schdDvsnCd"
                    i18n={$i18nUtils.trans("SCRNITM#schdDvsnCd")}
                    listPromise={$codeHooks.getCodeList("SCHD_DVSN_CD")}
                    rules={{
                      required: {
                        value: true,
                      },
                    }}
                    visibleCode={false}
                    blankType={$i18nUtils.trans("SCRNITM#slct")}
                    onChange={handleSelectSchdDvsnCd}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#tractDtDvsnCd")}
                    required={isRequired[0]}
                  >
                    거래일자구분코드
                  </LabelBox>
                  <SelectBox
                    control={control2}
                    name="dtDvsnCd"
                    i18n={$i18nUtils.trans("SCRNITM#tractDtDvsnCd")}
                    listPromise={$codeHooks.getCodeList("DT_DVSN_CD")}
                    rules={{
                      required: {
                        value: isRequired[0],
                      },
                    }}
                    visibleCode={false}
                    disabled={shouldDisabledDtDvsnCdSchdTime}
                    blankType={$i18nUtils.trans("SCRNITM#slct")}
                  />
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#shcdExecTm")}
                    required={isRequired[0]}
                  >
                    스케줄실행시간
                  </LabelBox>
                  <div className="unit timepicker-wrap">
                    <span className="half">
                      <InputIconBox
                        control={control2}
                        name="schdStaTm"
                        i18n={$i18nUtils.trans("SCRNITM#schdStaTm")}
                        icon="alram"
                        mask={{
                          mask: "HH:mm:dd",
                          lazy: false,
                          overwrite: "shift",
                          blocks: {
                            HH: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 23,
                            },
                            mm: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 59,
                            },
                            dd: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 59,
                            },
                          },
                        }}
                        rules={{
                          required: {
                            value: isRequired[0],
                          },
                        }}
                        disabled={shouldDisabledDtDvsnCdSchdTime}
                      />
                    </span>
                    <span className="half">
                      <InputIconBox
                        control={control2}
                        name="schdEndTm"
                        i18n={$i18nUtils.trans("SCRNITM#schdEndTm")}
                        icon="alram"
                        mask={{
                          mask: "HH:mm:dd",
                          lazy: false,
                          overwrite: "shift",
                          blocks: {
                            HH: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 23,
                            },
                            mm: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 59,
                            },
                            dd: {
                              mask: IMask.MaskedRange,
                              from: 0,
                              to: 59,
                            },
                          },
                        }}
                        rules={{
                          required: {
                            value: isRequired[0],
                          },
                        }}
                        disabled={shouldDisabledDtDvsnCdSchdTime}
                      />
                    </span>
                  </div>
                </CardCol>
                <CardCol>
                  <LabelBox
                    i18n={$i18nUtils.trans("SCRNITM#cronCmd")}
                    required={isRequired[1]}
                  >
                    크론 명령어
                  </LabelBox>
                  <span className="unit">
                    <span style={{ width: "70%" }}>
                      <InputIconBox
                        icon="search"
                        control={control2}
                        name="cronCmd"
                        i18n={$i18nUtils.trans("SCRNITM#cronCmd")}
                        mask={{
                          mask: /^.{1,500}$/,
                        }}
                        rules={{
                          required: {
                            value: isRequired[1],
                          },
                          maxLength: {
                            value: 500,
                          },
                        }}
                        disabled={shouldDisabledCronCmd}
                        onClick={openCronGenPopup}
                      />
                    </span>
                    <InputBox
                      control={control2}
                      name="cronStr"
                      i18n={$i18nUtils.trans("SCRNITM#cronCmd")}
                      disabled
                    />
                  </span>
                </CardCol>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#useYn")} required>
                    사용여부
                  </LabelBox>
                  <SelectBox
                    control={control2}
                    name="useFl"
                    i18n={$i18nUtils.trans("SCRNITM#useYn")}
                    listPromise={$codeHooks.getCodeList("USE_YN_CD")}
                    rules={{
                      required: { value: true },
                    }}
                    blankType={$i18nUtils.trans("SCRNITM#slct")}
                  />
                </CardCol>
              </CardRow>
            </div>
          </div>
          <div className="row">
            <div className="col-xl-6" data-form="regPrevBatchForm">
              <div className="sub-content">
                <GridCount
                  i18n={$i18nUtils.trans("SCRNITM#prevBtchWrkLst")}
                  count={preBatchTotalCnt}
                />
                <ButtonGroup className="m-right">
                  <Button
                    name="addPrevBtchJob"
                    i18n={$i18nUtils.trans("SCRNITM#addPrevBtchJob")}
                    color="white"
                    icon="add"
                    onClick={openBatchJobSelectionPopup}
                  >
                    선배치작업추가
                  </Button>
                  <Button
                    name="delPrevBtchJob"
                    i18n={$i18nUtils.trans("SCRNITM#delPrevBtchJob")}
                    color="white"
                    icon="delRow"
                    onClick={deletePreBatch}
                  >
                    선배치작업삭제
                  </Button>
                </ButtonGroup>
                <div className="view-box active">
                  <div className="col-01">
                    <div className="cmm-table">
                      <Grid
                        config={gridPreBatchConfig}
                        rowData={gridPreBatchData}
                        height={200}
                        ref={gridPreBatchRef}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-xl-6">
              <div className="sub-content">
                <GridCount
                  i18n={$i18nUtils.trans("SCRNITM#afBtchWrkLst")}
                  count={usingBatchTotalCnt}
                />
                <div className="view-box active">
                  <div className="col-01">
                    <div className="cmm-table">
                      <Grid
                        config={gridAfterBatchConfig}
                        rowData={gridUsingBatchData}
                        height={200}
                        ref={gridUsingBatchRef}
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/** // Sub Content E */}
      </div>
    </Page>
  )
}

export default USYMSCH001
