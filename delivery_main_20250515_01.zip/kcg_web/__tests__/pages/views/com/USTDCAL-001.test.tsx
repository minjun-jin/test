import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// USTDCAL001 컴포넌트를 불러옵니다.
import USTDCAL001 from "@/pages/views/com/USTDCAL-001"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(USTDCAL001)

describe("[USTDCAL-001] 휴일관리", () => {
  const txDt = "20240701"

  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue(txDt)
  })

  beforeEach(() => {
    mockUseParams.mockReturnValue({
      params: {},
    })
  })

  it("useEffect Test - baseDt is acceptable", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        baseDt: "20200101",
      },
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        comDateMList: [],
        totLen: 0,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("useEffect Test - baseDt is not acceptable", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        baseDt: false,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("rowClassRules Test", async () => {
    const { findByText } = render(component)
    const rowClassRulesTestBtn = await findByText(/rowClassRules Test/)
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: {
          data: {
            aprvStsCd: "02",
          },
        },
      },
    })
  })

  it("onRowClicked Test", async () => {
    const { findByText } = render(component)
    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: "test" } })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 01", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "01",
        },
      },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 02", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "02",
        },
      },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchGridData Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        comDateMList: [],
        totLen: 0,
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("xlsxClick Test", async () => {
    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        comDateMList: [
          {
            baseDt: "",
            holiDvsnCd: "",
            holiNm: "",
            dayCd: "",
          },
        ],
        totLen: 1,
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it.each(["MCMNI01001", "MCMNI01002"])(
    "updateHolidayInformation Test - confirm",
    async (msg) => {
      mockStorageUtils.mockRoleList.mockReturnValue([
        {
          roleCd: CONFIG.ROLE_CD.ALL,
        },
      ])

      mockUseModal.mockConfirm.mockResolvedValueOnce(true)
      mockUseProxy.mockAsync.mockResolvedValueOnce({
        header: {
          returnMessage: {
            msgId: msg,
          },
        },
      })

      msg === "MCMNI01001"
        ? mockUseProxy.mockAsync.mockResolvedValueOnce({
            data: {
              comDateMList: [],
              totLen: 0,
            },
          })
        : null

      const { findByText } = render(component)

      const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
      fireEvent.click(onRowClickedTestBtn, { target: { data: "test" } })

      const saveBtn = await findByText(/SCRNITM#save/)
      fireEvent.click(saveBtn)

      await waitFor(() => {
        expect(mockUseModal.mockConfirm).toHaveBeenCalled()

        if (msg === "MCMNI01001") {
          expect(mockUseModal.mockRequestApprovalAlert).toHaveBeenCalled()
        } else {
          expect(mockUseModal.mockRequestApprovalAlert).not.toHaveBeenCalled()
        }
      })

      await waitFor(() => {
        msg === "MCMNI01001"
          ? expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
          : expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
      })
    },
  )

  it("updateHolidayInformation Test - not confirm", async () => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: "test" } })

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("closeClick Test - not confirm", async () => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])

    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: "test" } })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })
})
