import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// UHOFINQ019 컴포넌트를 불러옵니다.
import UHOFINQ019 from "@/pages/views/hof/UHOFINQ-019"
import { Component } from "@/hoc/TestUtil"

const component = Component(UHOFINQ019)

describe("[UHOFINQ-019] 순이체한도조회", () => {
  beforeEach(() => {
    mockUseParams.mockReturnValue({
      params: {},
    })
  })

  it("useEffect Test - isDashboard is false", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: false,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("useEffect Test - isDashboard is true", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
      },
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("searchListHofNetDebitCap Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it.each([
    {
      target: {
        data: {
          respCd: null,
        },
      },
    },
    {
      target: {
        data: {
          respCd: "not null",
        },
      },
    },
  ])("valueGetter Test", async (param) => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, param)
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("sendClick Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 1,
      },
    })
    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })

    const { findByText } = render(component)
    const rqstBtn = await findByText(/SCRNITM#rqst/)
    fireEvent.click(rqstBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })
})
