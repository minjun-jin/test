package com.jpmc.kcg.ift.biz;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.ift.biz.vo.KftIft0210200;
import com.jpmc.kcg.ift.biz.vo.LvbIft0200200;
import com.jpmc.kcg.ift.biz.vo.LvbIft0210200;
import com.jpmc.kcg.ift.biz.vo.LvbIft0400200;
import com.jpmc.kcg.ift.dto.IftTrL;
import com.jpmc.kcg.ift.dto.SelectIftTransactionIn;
import com.jpmc.kcg.ift.dto.UpdateIftTransactionIn;
import com.jpmc.kcg.ift.enums.IftConst;
import com.jpmc.kcg.ift.enums.IftRespCdEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 2024.04.08 한성흔 현금입금 당발요청응답 (0210/200) 
 * KFTC -> KCG 전문수신 후 전문양식을 변경하여 
 * KCG-> LVB 응답전송
 */
@Slf4j
@Component
public class IftInterbankDepositOutResIntf extends FrwServiceBean<KftIft0210200> {

	@Autowired
	private FrwMapper frwMapper;
	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private IftCom iftCom;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private BizCom bizCom;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private ReleaseValidation releaseValidation;
	@Autowired
	private ComPshMsgBean comPshMsgBean;

	/**
	 * 제어
	 */
	@Override
	public boolean control(KftIft0210200 in) {

		if (!IftConst.TLG_KND_DVSN_NO_9200.equals(in.getMessageType())) {
			// 전문 format validation check
			if (in.validate() > 0) {
				String errCd = String.valueOf(200 + in.validate()); // 실제 필드번호이다.
				throw new InternalResponseException(errCd);
			}

			if (!ComConst.CHAR_2.equals(in.getSendReceiveFlag())
					&& !ComConst.CHAR_5.equals(in.getSendReceiveFlag())) {
				throw new InternalResponseException(IftRespCdEnum.RESP_CD_205.getCode());
			}

			String hostRespCd = bizCom.getRespCdMap(ComConst.HST, BizDvsnCdEnum.IFT.getValue(),
					in.getResponseCode());
			in.setResponseCode(hostRespCd);

			//2024-10-24추가: 중복요청거래일때, return한다.
			boolean isKftcTransactionDup = iftCom.isKftcTransactionDup(
					in.getKftcMessageTime().format(DateFormat.YYYYMMDD.getFormatter()),
					in.getKftcMessageNumber(), in.getRequestMessageNumber());

			if (isKftcTransactionDup) {
				return false;
			}

		} else {
			throw new InternalResponseException(in.getResponseCode());
		}

		return super.control(in);
	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftIft0210200 in) {
		if (log.isDebugEnabled()) {
			String inToSting = VOUtils.toString(in);
			log.debug("응답전문 역직렬화 {}", inToSting);
		}

		/**
		 * 취급전문번호로 요청한 거래가 있는지 확인
		 */
		SelectIftTransactionIn selectIn = new SelectIftTransactionIn();
		selectIn.setOutinDvsnCd(IftConst.OUTIN_DVSN_CD_01); // 당발
		if (in.getSendReceiveFlag().equals(ComConst.CHAR_5)) {
			selectIn.setTlgKndDvsnCd(IftConst.TLG_KND_DVSN_NO_0210);
		} else {
			selectIn.setTlgKndDvsnCd(IftConst.TLG_KND_DVSN_NO_0200);
		}
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setHndlBnkTlgNo(in.getRequestMessageNumber());

		IftTrL reqTrInfo = iftCom.selectIftTransaction(selectIn);
		String reqStsCd = reqTrInfo.getTrStsCd();

		if (reqStsCd.equals(TrStsCdEnum.ERROR.getTrStsCd())) { //03:오류 일때의 모든응답 무시
			log.debug("이미 불능 종료된 거래이기 때문에 종료합니다.");
			return;
		} else if (reqStsCd.equals(TrStsCdEnum.COMPLETE.getTrStsCd())
				&& !in.getSendReceiveFlag().equals(ComConst.CHAR_5)) { //02:완료 일때의 5번 아닌 응답은 무시
			log.debug("정상 종료된 거래에 대해 정상 응답 중복이라 종료합니다.");
			return;
		}

		if (log.isDebugEnabled()) {
			log.debug("요청거래 상태코드 reqStsCd {}", reqStsCd);
		}

		if (in.getSendReceiveFlag().equals(ComConst.CHAR_5)) {
			try {
				/* 송금거래에 대한 추가 응답 수신 시, TIVOLI ALERT 발생 */
				Map<String, Object> paramValList = new Hashtable<>();
				paramValList.put("errTlgId", IftConst.OUT_PAYMENT_ERROR_TITLE);
				String errorMessage = String.format("81 [I N F O] IFT FUND TRANSFER ERROR RESPONSE[DATE=%s][HOST_NO=%s][BANK_CD=%s][ACCT_NO=%s][TOT_AEK=%s]"
						                           , reqTrInfo.getTrDt(), reqTrInfo.getHostNo(), reqTrInfo.getOpnBnkCd(), reqTrInfo.getRcvAcctNo(), reqTrInfo.getTotTrAmt());
				paramValList.put("errCtt", errorMessage);
				comPshMsgBean.sendAlarm(7, paramValList.get("errTlgId").toString() , paramValList, null, true);
			} catch (Exception e) {
				log.error("Message Request Fail", e);
			}

		}
		// 거래내역, 거래집계 UPDATE
		_updateTransaction(in, reqTrInfo);

		FrwMsgL frwMsgL = frwMapper.selectFrwMsgL(reqTrInfo.getTrcId());
		String requestTlgCtnt = frwMsgL.getTlgCtt();

		/**
		 * 단일거래인 경우.
		 */
		if (!ComConst.Y.equals(reqTrInfo.getLrgAmtSplitTrYn())) {

			// 응답전문송신
			LvbIft0200200 rqerVo = VOUtils.toVo(requestTlgCtnt, LvbIft0200200.class);
			LvbIft0210200 respVo = conversionService.convert(rqerVo, LvbIft0210200.class);
			respVo.setResponseCode(in.getResponseCode());
			respVo.setTransactionIdNumber(in.getKftcMessageNumber());
			String tlgCtt = VOUtils.toString(respVo);
			log.info("========tlgCtt {}", tlgCtt);
			// 응답코드 결과 HOLD대상이 아닌 경우만 전문전송 처리
			if (!_isHoldTarget(in, rqerVo.getMsgNo(), tlgCtt)) {
				frwTemplate.send(FrwDestination.LVB_IFT, respVo);
			}
			/**
			 * 거액거래인 경우 응답코드 HOLD 체크 하지 않음. 분할된 전체 거래에 대한 후속프로세스를 마지막 거래가 들어온 시점에 판단하기 때문에
			 * 분할된 거래를 개별로 HOLD시킬 수 없음.
			 */
		} else {

			/*
			 * hostNo로 거래목록 조회
			 */
			String orgnMsgNo = reqTrInfo.getHostNo();
			List<IftTrL> orgnTrList = iftCom.selectOrgnTrListByHostNo(orgnMsgNo,
					reqTrInfo.getTrDt(), IftConst.OUTIN_DVSN_CD_01);

			int splitCnt = orgnTrList.size(); 	//분할된 거래수
			int respDoneCnt = 0; 				//분할된 응답완료 거래수
			int respNormalCnt = 0; 		//분할된 정상완료 거래수
			int respErrorCnt = 0;            //분할된 에러종료 거래수
			String respCd = IftRespCdEnum.RESP_CD_000.getCode(); //응답 return할때 코드

			log.info(">>>>> done split Count {}/{}", respDoneCnt, splitCnt);
			log.info(">>>>> normal Count {}", respNormalCnt);
			log.info(">>>>> error Count {}", respErrorCnt);

			for (IftTrL orgnTr : orgnTrList) {
				if (!orgnTr.getTrStsCd().equals(TrStsCdEnum.REQUEST.getTrStsCd())) {
					respDoneCnt++;

					if (orgnTr.getTrStsCd().equals(TrStsCdEnum.COMPLETE.getTrStsCd())) {
						respNormalCnt++;
					} else {
						respErrorCnt++;
						respCd = orgnTr.getRespCd();
					}
				}
			}

			if (splitCnt == respDoneCnt) { //분할거래 전부 응답이 완료
				if (splitCnt == respNormalCnt || splitCnt == respErrorCnt) { //분할거래 전부 정상응답 또는 전부 비정상응답
					// 응답전문송신 (1회)
					LvbIft0200200 rqerVo = VOUtils.toVo(requestTlgCtnt, LvbIft0200200.class);
					LvbIft0210200 respVo = conversionService.convert(rqerVo, LvbIft0210200.class);
					respVo.setResponseCode(respCd);
					respVo.setTransactionIdNumber(in.getKftcMessageNumber());
					frwTemplate.send(FrwDestination.LVB_IFT, respVo);

				} else { //분할거래 중 비정상응답이 있음
					LvbIft0400200 cancelIn = conversionService.convert(in, LvbIft0400200.class);
					String msgNo = bizCom.getNumbering(BizDvsnCdEnum.IFT.toString(),
							NumberingEnum.IFTLVB01.toString()); // hostNo 채번
					msgNo = "57".concat(msgNo.substring(2));   // 실제 host 채번과 중복되지 않도록 처리.
					cancelIn.setMsgNo(msgNo);
					cancelIn.setTotalAmount(reqTrInfo.getSplitOrgnTrTotAmt().longValue());
					cancelIn.setCashAmount(reqTrInfo.getSplitOrgnTrTotAmt().longValue());
					cancelIn.setTransactionDate(LocalDate.now());
					cancelIn.setOriginalDate(LocalDate.parse(reqTrInfo.getTrDt(),
							DateFormat.YYYYMMDD.getFormatter()));
					cancelIn.setSystemSendReceiveTime(LocalDateTime.now());
					cancelIn.setCancelDishonorReasonCode("05"); //기타송금취소
					log.info("#############거액거래 현금입금 자동취소 input {}", cancelIn);
					// 현금입금취소 당발요청
					frwTemplate.send(FrwDestination.KCG_IFT, cancelIn);

				}

			}
		}

		// 결번update
		if (StringUtils.isNotBlank(in.getKftcMessageNumber())) {
			iftCom.updateMissingNumber(in.getKftcMessageNumber());
		}
	}

	private void _updateTransaction(KftIft0210200 in, IftTrL reqTrInfo) {

		if (!in.getResponseCode().equals(IftRespCdEnum.RESP_CD_000.getCode())) {
			//순이체한도(-)
			releaseValidation.insertNetDebitCap(reqTrInfo.getTotTrAmt().negate()); // 순이체한도 insert
		}

		/**
		 * IFT_TR_L UPDATE
		 */
		UpdateIftTransactionIn updateIn = new UpdateIftTransactionIn();
		updateIn.setTrDt(reqTrInfo.getTrDt());
		updateIn.setTrSeq(reqTrInfo.getTrSeq().longValue());
		updateIn.setOutinDvsnCd(IftConst.OUTIN_DVSN_CD_01);
		updateIn.setTlgKndDvsnCd(IftConst.TLG_KND_DVSN_NO_0210);
		updateIn.setRespCd(in.getResponseCode());
		updateIn.setRcpntNm(in.getBeneficiaryName());
		updateIn.setKftcTlgNo(in.getKftcMessageNumber());
		updateIn.setOpnBnkTlgNo(in.getBeneficiaryMessageNumber());
		updateIn.setOpnBnkBrchCd(in.getBeneficiaryBranchCode());
		updateIn.setKftcTlgTrTm(in.getKftcMessageTime());
		updateIn.setOpnBnkTlgTrTm(in.getBeneficiaryMessageSendTime());
		iftCom.updateIftTransaction(updateIn);
	}

	private boolean _isHoldTarget(KftIft0210200 in, String hostNo, String tlgCtt) {

		boolean isHoldTarget = false;

		// hold대상 응답코드인지 확인
		boolean isHoldRespCd = releaseValidation.getReleaseResponseCode(ComConst.KFT,
				BizDvsnCdEnum.IFT.getValue(), in.getResponseCode());

		//해당값이 없거나, HOLD_RSN_CD != 05 이면, 응답코드로 인해 HOLD테이블에 입력되어야하는 거래이다.
		String holdRsnCd = frwContext.getTlgHdr().get(ComConst.HOLD_RSN_CD);
		if (isHoldRespCd) {
			if (StringUtils.isEmpty(holdRsnCd)
					|| !holdRsnCd.equals(HoldRsnCdEnum.RESPONSE_CODE.getCode())) {

				// 2024.08.08 추가 해당 거래가 hold테이블에 있는 경우 release로 변경 후 insert
				bizCom.setComHoldStatusDone(hostNo);

				isHoldTarget = true;
				/**
				 * 홀드 처리
				 */
				ComTrHoldL holdIn = new ComTrHoldL();
				holdIn.setBizDvsnCd(BizDvsnCdEnum.IFT.getValue());
				holdIn.setOutinDvsnCd(IftConst.OUTIN_DVSN_CD_01);
				holdIn.setTlgKndDvsnCd(in.getMessageType());
				holdIn.setTlgTrDvsnCd(in.getMessageCode());
				holdIn.setRcvBnkCd(in.getBeneficiaryBankCode());
				holdIn.setRcvAcctNo(in.getBeneficiaryAccountNumber());
				holdIn.setRqerInfo(in.getSenderName());
				holdIn.setSndrRealNm(in.getRealSenderName());
				holdIn.setTrAmt(new BigDecimal(in.getTotalAmount()));
				holdIn.setHoldRsnCd(HoldRsnCdEnum.RESPONSE_CODE.getCode());
				holdIn.setTrUnqNo(in.getKftcMessageNumber());
				holdIn.setHostNo(hostNo);
				holdIn.setTlgCtt(tlgCtt);
				holdIn.setRespCd(in.getResponseCode());
				holdIn.setTrcId(frwContext.getOrgnTractId());
				bizCom.createHoldTransaction(frwContext, holdIn);

			}
		}

		return isHoldTarget;
	}

	/**
	 * 예외
	 */
	@Override
	public void handleError(KftIft0210200 in, Throwable t) {
		if (t instanceof InternalResponseException e) {
			String respCd = e.getRespCd();
			int flag = Integer.parseInt(in.getSendReceiveFlag());
			in.setSendReceiveFlag(String.valueOf(flag + 1));

			//요청에 대해 전문에러받은 경우 바로 host로 내려준다.
			if (IftConst.TLG_KND_DVSN_NO_9200.equals(in.getMessageType())) {

				LvbIft0200200 lvbReq = VOUtils.toVo(frwContext.getOrgnTlgCtt(),
						LvbIft0200200.class);

				String reqMsgNo = lvbReq.getMsgNo();
				List<IftTrL> reqTrList = iftCom.selectOrgnTrListByHostNo(reqMsgNo,
						lvbReq.getTransactionDate().format(DateFormat.YYYYMMDD.getFormatter()),
						IftConst.OUTIN_DVSN_CD_01);
				for (IftTrL reqTr : reqTrList) {
					if (reqTr.getHndlBnkTlgNo().equals(in.getRequestMessageNumber())) {
						UpdateIftTransactionIn updateIn = new UpdateIftTransactionIn();
						//조회key값
						updateIn.setTrDt(reqTr.getTrDt());
						updateIn.setTrSeq(reqTr.getTrSeq());
						updateIn.setHndlBnkTlgNo(reqTr.getHndlBnkTlgNo());

						//update값
						updateIn.setTlgKndDvsnCd(IftConst.TLG_KND_DVSN_NO_9200);
						updateIn.setRespCd(respCd);

						//update호출
						iftCom.updateIftTransaction(updateIn);

						//host로 전문전송
						LvbIft0210200 lvbRes = conversionService.convert(lvbReq,
								LvbIft0210200.class);
						lvbRes.setResponseCode(respCd);
						frwTemplate.send(FrwDestination.LVB_IFT, lvbRes);
					}
				}

				// 받은 응답이 field값 에러인 경우 전문종별 : 9210으로 전송한다.
			} else if (respCd.startsWith(ComConst.CHAR_2)) {
				log.info("**** IFTTransactionError");
				in.setMessageType(IftConst.TLG_KND_DVSN_NO_9210);
				in.setResponseCode(respCd);
				frwTemplate.send(FrwDestination.KFT_IFT, in);

				// 결번update
				if (StringUtils.isNotBlank(in.getKftcMessageNumber())) {
					iftCom.updateMissingNumber(in.getKftcMessageNumber());
				}
			}
		} else {
			t.printStackTrace();
		}

		return;
	}
}
