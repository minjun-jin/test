package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 출금취소지시
 * <pre>{@code
 * KftCmsEB35T kftCmsEB35T  = new KftCmsEB35T(); // 출금취소지시
 * kftCmsEB35T.setRecordType(""); // Record 구분
 * kftCmsEB35T.setSerialNumber(""); // 일련번호
 * kftCmsEB35T.setInstitutionCode(""); // 기관코드
 * kftCmsEB35T.setFileName(""); // File 이름
 * kftCmsEB35T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEB35T.setTotalFailedDepositCount(0); // 총입금불능건수
 * kftCmsEB35T.setTotalFailedDepositAmount(0L); // 총입금불능금액
 * kftCmsEB35T.setFiller3(""); // FILLER
 * kftCmsEB35T.setMacValue(""); // MAC 검증값 
 * }</pre>
 */
@Data
public class KftCmsEB35T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int totalFailedDepositCount; // 총입금불능건수
	private long totalFailedDepositAmount; // 총입금불능금액
	private String filler3; // FILLER
	private String macValue; // MAC 검증값 
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFailedDepositCount$; // 총입금불능건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFailedDepositAmount$; // 총입금불능금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값 

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		totalFailedDepositCount$ = VOUtils.write(out, totalFailedDepositCount, 8); // 총입금불능건수
		totalFailedDepositAmount$ = VOUtils.write(out, totalFailedDepositAmount, 13); // 총입금불능금액
		filler3$ = VOUtils.write(out, filler3, 84); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값 
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		totalFailedDepositCount = VOUtils.toInt(totalFailedDepositCount$ = VOUtils.read(in, 8)); // 총입금불능건수
		totalFailedDepositAmount = VOUtils.toLong(totalFailedDepositAmount$ = VOUtils.read(in, 13)); // 총입금불능금액
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 84)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값 
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", totalFailedDepositCount=").append(totalFailedDepositCount).append(System.lineSeparator()); // 총입금불능건수
		sb.append(", totalFailedDepositAmount=").append(totalFailedDepositAmount).append(System.lineSeparator()); // 총입금불능금액
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값 
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalFailedDepositCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalFailedDepositAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "84", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
