package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 반환관련 어음정보 조회 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * searchConditionSort 검색조건구분 
 * processSort 처리구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * depositAccountNumber 입금계좌번호 
 * lastTransactionDateInquiryStartDate 최종거래일기준조회시작일 
 * lastTransactionDateInquiryEndDate 최종거래일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.noteInfoEnoteNumber (조회결과)어음정보-전자어음번호 
 * queryResultArray.noteInfoNoteType (조회결과)어음정보-어음종류 
 * queryResultArray.noteInfoEnoteProcessStatus (조회결과)어음정보-전자어음처리상태 
 * queryResultArray.noteInfoEnoteIssueDate (조회결과)어음정보-전자어음발행일자 
 * queryResultArray.noteInfoEnoteIssuePlace (조회결과)어음정보-전자어음발행지 
 * queryResultArray.noteInfoEnoteAmount (조회결과)어음정보-전자어음금액 
 * queryResultArray.noteInfoDefaultReasonCode (조회결과)어음정보-부도사유코드 
 * queryResultArray.noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
 * queryResultArray.noteInfoEnoteDefaultDate (조회결과)어음정보-전자어음부도일자 
 * queryResultArray.noteInfoEnoteFinalSettlementDate (조회결과)어음정보-전자어음최종결제일자 
 * queryResultArray.noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
 * queryResultArray.noteInfoEndorsementCount (조회결과)어음정보-배서횟수 
 * queryResultArray.otherPartyInfoIndvCorpSort (조회결과)상대방정보-개인법인구분 
 * queryResultArray.otherPartyInfoResidentBusinessNumber (조회결과)상대방정보-주민사업자번호 
 * queryResultArray.otherPartyInfoCorpName (조회결과)상대방정보-법인명 
 * queryResultArray.otherPartyInfoNameRepresentative (조회결과)상대방정보-성명(대표자명) 
 * queryResultArray.otherPartyInfoAddress (조회결과)상대방정보-주소 
 * queryResultArray.otherPartyInfoBankCode (조회결과)상대방정보-은행코드 
 * queryResultArray.otherPartyInfoDepositAccountNumber (조회결과)상대방정보-입금계좌번호 
 * queryResultArray.requesterInfoIndvCorpSort (조회결과)요청인정보-개인법인구분 
 * queryResultArray.requesterInfoResidentBusinessNumber (조회결과)요청인정보-주민사업자번호 
 * queryResultArray.requesterInfoCorpName (조회결과)요청인정보-법인명 
 * queryResultArray.requesterInfoNameRepresentative (조회결과)요청인정보-성명(대표자명) 
 * queryResultArray.requesterInfoAddress (조회결과)요청인정보-주소 
 * queryResultArray.requesterInfoBankCode (조회결과)요청인정보-은행코드 
 * queryResultArray.requesterInfoDepositAccountNumber (조회결과)요청인정보-입금계좌번호 
 * queryResultArray.splitNumber (조회결과)분할번호 
 * queryResultArray.endorsementNumber (조회결과)배서번호 
 * queryResultArray.queryAmount (조회결과)금액 
 * queryResultArray.defaultNoteReturnSpecifiedDate (조회결과)부도어음반환지정일자 
 * queryResultArray.defaultNoteReturnRequestDate (조회결과)부도어음반환요청일자 
 * queryResultArray.repaymentObligationsRegistrationDate (조회결과)상환의무이행등록일자 
 * queryResultArray.repaymentObligationsConfirmationDate (조회결과)상환의무이행확인일자 
 * queryResultArray.returnRejectRequestDate (조회결과)반환.수령거부요청일자 
 * queryResultArray.postmaturedEndorsementYn (조회결과)기한후배서여부 
 * queryResultArray.filler (조회결과)FILLER 
 * 
 * KftEnt0210500000 kftEnt0210500000 = new KftEnt0210500000(); // 반환관련 어음정보 조회 응답
 * kftEnt0210500000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210500000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210500000.setBnkCd("057"); // 은행코드
 * kftEnt0210500000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210500000.setTransactionCode("500000"); // 거래구분코드
 * kftEnt0210500000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210500000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210500000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210500000.setStatus("000"); // STATUS
 * kftEnt0210500000.setResponseCode1(""); // 응답코드1
 * kftEnt0210500000.setResponseCode2(""); // 응답코드2
 * kftEnt0210500000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210500000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210500000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0210500000.setProcessSort(""); // 처리구분
 * kftEnt0210500000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210500000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0210500000.setDepositAccountNumber(""); // 입금계좌번호
 * kftEnt0210500000.setLastTransactionDateInquiryStartDate(""); // 최종거래일기준조회시작일
 * kftEnt0210500000.setLastTransactionDateInquiryEndDate(""); // 최종거래일기준조회종료일
 * kftEnt0210500000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0210500000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0210500000.setCurrentCount(0); // 현재건수
 * KftEnt0210500000.QueryResult queryResult = new KftEnt0210500000.QueryResult(); // 조회결과Array
 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-전자어음번호
 * queryResult.setNoteInfoNoteType(""); // (조회결과)어음정보-어음종류
 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-전자어음처리상태
 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-전자어음발행일자
 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-전자어음발행지
 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-전자어음금액
 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-부도사유코드
 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
 * queryResult.setNoteInfoEnoteDefaultDate(""); // (조회결과)어음정보-전자어음부도일자
 * queryResult.setNoteInfoEnoteFinalSettlementDate(""); // (조회결과)어음정보-전자어음최종결제일자
 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
 * queryResult.setNoteInfoEndorsementCount(0); // (조회결과)어음정보-배서횟수
 * queryResult.setOtherPartyInfoIndvCorpSort(""); // (조회결과)상대방정보-개인법인구분
 * queryResult.setOtherPartyInfoResidentBusinessNumber(""); // (조회결과)상대방정보-주민사업자번호
 * queryResult.setOtherPartyInfoCorpName(""); // (조회결과)상대방정보-법인명
 * queryResult.setOtherPartyInfoNameRepresentative(""); // (조회결과)상대방정보-성명(대표자명)
 * queryResult.setOtherPartyInfoAddress(""); // (조회결과)상대방정보-주소
 * queryResult.setOtherPartyInfoBankCode(""); // (조회결과)상대방정보-은행코드
 * queryResult.setOtherPartyInfoDepositAccountNumber(""); // (조회결과)상대방정보-입금계좌번호
 * queryResult.setRequesterInfoIndvCorpSort(""); // (조회결과)요청인정보-개인법인구분
 * queryResult.setRequesterInfoResidentBusinessNumber(""); // (조회결과)요청인정보-주민사업자번호
 * queryResult.setRequesterInfoCorpName(""); // (조회결과)요청인정보-법인명
 * queryResult.setRequesterInfoNameRepresentative(""); // (조회결과)요청인정보-성명(대표자명)
 * queryResult.setRequesterInfoAddress(""); // (조회결과)요청인정보-주소
 * queryResult.setRequesterInfoBankCode(""); // (조회결과)요청인정보-은행코드
 * queryResult.setRequesterInfoDepositAccountNumber(""); // (조회결과)요청인정보-입금계좌번호
 * queryResult.setSplitNumber(""); // (조회결과)분할번호
 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
 * queryResult.setQueryAmount(0L); // (조회결과)금액
 * queryResult.setDefaultNoteReturnSpecifiedDate(""); // (조회결과)부도어음반환지정일자
 * queryResult.setDefaultNoteReturnRequestDate(""); // (조회결과)부도어음반환요청일자
 * queryResult.setRepaymentObligationsRegistrationDate(""); // (조회결과)상환의무이행등록일자
 * queryResult.setRepaymentObligationsConfirmationDate(""); // (조회결과)상환의무이행확인일자
 * queryResult.setReturnRejectRequestDate(""); // (조회결과)반환.수령거부요청일자
 * queryResult.setPostmaturedEndorsementYn(""); // (조회결과)기한후배서여부
 * queryResult.setFiller(""); // (조회결과)FILLER
 * kftEnt0210500000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0210500000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * noteInfoEnoteNumber (조회결과)어음정보-전자어음번호 
	 * noteInfoNoteType (조회결과)어음정보-어음종류 
	 * noteInfoEnoteProcessStatus (조회결과)어음정보-전자어음처리상태 
	 * noteInfoEnoteIssueDate (조회결과)어음정보-전자어음발행일자 
	 * noteInfoEnoteIssuePlace (조회결과)어음정보-전자어음발행지 
	 * noteInfoEnoteAmount (조회결과)어음정보-전자어음금액 
	 * noteInfoDefaultReasonCode (조회결과)어음정보-부도사유코드 
	 * noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
	 * noteInfoEnoteDefaultDate (조회결과)어음정보-전자어음부도일자 
	 * noteInfoEnoteFinalSettlementDate (조회결과)어음정보-전자어음최종결제일자 
	 * noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
	 * noteInfoEndorsementCount (조회결과)어음정보-배서횟수 
	 * otherPartyInfoIndvCorpSort (조회결과)상대방정보-개인법인구분 
	 * otherPartyInfoResidentBusinessNumber (조회결과)상대방정보-주민사업자번호 
	 * otherPartyInfoCorpName (조회결과)상대방정보-법인명 
	 * otherPartyInfoNameRepresentative (조회결과)상대방정보-성명(대표자명) 
	 * otherPartyInfoAddress (조회결과)상대방정보-주소 
	 * otherPartyInfoBankCode (조회결과)상대방정보-은행코드 
	 * otherPartyInfoDepositAccountNumber (조회결과)상대방정보-입금계좌번호 
	 * requesterInfoIndvCorpSort (조회결과)요청인정보-개인법인구분 
	 * requesterInfoResidentBusinessNumber (조회결과)요청인정보-주민사업자번호 
	 * requesterInfoCorpName (조회결과)요청인정보-법인명 
	 * requesterInfoNameRepresentative (조회결과)요청인정보-성명(대표자명) 
	 * requesterInfoAddress (조회결과)요청인정보-주소 
	 * requesterInfoBankCode (조회결과)요청인정보-은행코드 
	 * requesterInfoDepositAccountNumber (조회결과)요청인정보-입금계좌번호 
	 * splitNumber (조회결과)분할번호 
	 * endorsementNumber (조회결과)배서번호 
	 * queryAmount (조회결과)금액 
	 * defaultNoteReturnSpecifiedDate (조회결과)부도어음반환지정일자 
	 * defaultNoteReturnRequestDate (조회결과)부도어음반환요청일자 
	 * repaymentObligationsRegistrationDate (조회결과)상환의무이행등록일자 
	 * repaymentObligationsConfirmationDate (조회결과)상환의무이행확인일자 
	 * returnRejectRequestDate (조회결과)반환.수령거부요청일자 
	 * postmaturedEndorsementYn (조회결과)기한후배서여부 
	 * filler (조회결과)FILLER 
	 * 
	 * KftEnt0210500000.QueryResult queryResult = new KftEnt0210500000.QueryResult(); // 조회결과Array
	 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-전자어음번호
	 * queryResult.setNoteInfoNoteType(""); // (조회결과)어음정보-어음종류
	 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-전자어음처리상태
	 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-전자어음발행일자
	 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-전자어음발행지
	 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-전자어음금액
	 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-부도사유코드
	 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
	 * queryResult.setNoteInfoEnoteDefaultDate(""); // (조회결과)어음정보-전자어음부도일자
	 * queryResult.setNoteInfoEnoteFinalSettlementDate(""); // (조회결과)어음정보-전자어음최종결제일자
	 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
	 * queryResult.setNoteInfoEndorsementCount(0); // (조회결과)어음정보-배서횟수
	 * queryResult.setOtherPartyInfoIndvCorpSort(""); // (조회결과)상대방정보-개인법인구분
	 * queryResult.setOtherPartyInfoResidentBusinessNumber(""); // (조회결과)상대방정보-주민사업자번호
	 * queryResult.setOtherPartyInfoCorpName(""); // (조회결과)상대방정보-법인명
	 * queryResult.setOtherPartyInfoNameRepresentative(""); // (조회결과)상대방정보-성명(대표자명)
	 * queryResult.setOtherPartyInfoAddress(""); // (조회결과)상대방정보-주소
	 * queryResult.setOtherPartyInfoBankCode(""); // (조회결과)상대방정보-은행코드
	 * queryResult.setOtherPartyInfoDepositAccountNumber(""); // (조회결과)상대방정보-입금계좌번호
	 * queryResult.setRequesterInfoIndvCorpSort(""); // (조회결과)요청인정보-개인법인구분
	 * queryResult.setRequesterInfoResidentBusinessNumber(""); // (조회결과)요청인정보-주민사업자번호
	 * queryResult.setRequesterInfoCorpName(""); // (조회결과)요청인정보-법인명
	 * queryResult.setRequesterInfoNameRepresentative(""); // (조회결과)요청인정보-성명(대표자명)
	 * queryResult.setRequesterInfoAddress(""); // (조회결과)요청인정보-주소
	 * queryResult.setRequesterInfoBankCode(""); // (조회결과)요청인정보-은행코드
	 * queryResult.setRequesterInfoDepositAccountNumber(""); // (조회결과)요청인정보-입금계좌번호
	 * queryResult.setSplitNumber(""); // (조회결과)분할번호
	 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
	 * queryResult.setQueryAmount(0L); // (조회결과)금액
	 * queryResult.setDefaultNoteReturnSpecifiedDate(""); // (조회결과)부도어음반환지정일자
	 * queryResult.setDefaultNoteReturnRequestDate(""); // (조회결과)부도어음반환요청일자
	 * queryResult.setRepaymentObligationsRegistrationDate(""); // (조회결과)상환의무이행등록일자
	 * queryResult.setRepaymentObligationsConfirmationDate(""); // (조회결과)상환의무이행확인일자
	 * queryResult.setReturnRejectRequestDate(""); // (조회결과)반환.수령거부요청일자
	 * queryResult.setPostmaturedEndorsementYn(""); // (조회결과)기한후배서여부
	 * queryResult.setFiller(""); // (조회결과)FILLER
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String noteInfoEnoteNumber; // (조회결과)어음정보-전자어음번호
		private String noteInfoNoteType; // (조회결과)어음정보-어음종류
		private String noteInfoEnoteProcessStatus; // (조회결과)어음정보-전자어음처리상태
		private String noteInfoEnoteIssueDate; // (조회결과)어음정보-전자어음발행일자
		private String noteInfoEnoteIssuePlace; // (조회결과)어음정보-전자어음발행지
		private long noteInfoEnoteAmount; // (조회결과)어음정보-전자어음금액
		private String noteInfoDefaultReasonCode; // (조회결과)어음정보-부도사유코드
		private String noteInfoEnoteMaturedDate; // (조회결과)어음정보-전자어음만기일자
		private String noteInfoEnoteDefaultDate; // (조회결과)어음정보-전자어음부도일자
		private String noteInfoEnoteFinalSettlementDate; // (조회결과)어음정보-전자어음최종결제일자
		private String noteInfoPaymentBankAndBranchCode; // (조회결과)어음정보-지급은행및점포코드
		private int noteInfoEndorsementCount; // (조회결과)어음정보-배서횟수
		private String otherPartyInfoIndvCorpSort; // (조회결과)상대방정보-개인법인구분
		private String otherPartyInfoResidentBusinessNumber; // (조회결과)상대방정보-주민사업자번호
		private String otherPartyInfoCorpName; // (조회결과)상대방정보-법인명
		private String otherPartyInfoNameRepresentative; // (조회결과)상대방정보-성명(대표자명)
		private String otherPartyInfoAddress; // (조회결과)상대방정보-주소
		private String otherPartyInfoBankCode; // (조회결과)상대방정보-은행코드
		private String otherPartyInfoDepositAccountNumber; // (조회결과)상대방정보-입금계좌번호
		private String requesterInfoIndvCorpSort; // (조회결과)요청인정보-개인법인구분
		private String requesterInfoResidentBusinessNumber; // (조회결과)요청인정보-주민사업자번호
		private String requesterInfoCorpName; // (조회결과)요청인정보-법인명
		private String requesterInfoNameRepresentative; // (조회결과)요청인정보-성명(대표자명)
		private String requesterInfoAddress; // (조회결과)요청인정보-주소
		private String requesterInfoBankCode; // (조회결과)요청인정보-은행코드
		private String requesterInfoDepositAccountNumber; // (조회결과)요청인정보-입금계좌번호
		private String splitNumber; // (조회결과)분할번호
		private String endorsementNumber; // (조회결과)배서번호
		private long queryAmount; // (조회결과)금액
		private String defaultNoteReturnSpecifiedDate; // (조회결과)부도어음반환지정일자
		private String defaultNoteReturnRequestDate; // (조회결과)부도어음반환요청일자
		private String repaymentObligationsRegistrationDate; // (조회결과)상환의무이행등록일자
		private String repaymentObligationsConfirmationDate; // (조회결과)상환의무이행확인일자
		private String returnRejectRequestDate; // (조회결과)반환.수령거부요청일자
		private String postmaturedEndorsementYn; // (조회결과)기한후배서여부
		private String filler; // (조회결과)FILLER
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteNumber$; // (조회결과)어음정보-전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoNoteType$; // (조회결과)어음정보-어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteProcessStatus$; // (조회결과)어음정보-전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssueDate$; // (조회결과)어음정보-전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssuePlace$; // (조회결과)어음정보-전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteAmount$; // (조회결과)어음정보-전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoDefaultReasonCode$; // (조회결과)어음정보-부도사유코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteMaturedDate$; // (조회결과)어음정보-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteDefaultDate$; // (조회결과)어음정보-전자어음부도일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteFinalSettlementDate$; // (조회결과)어음정보-전자어음최종결제일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoPaymentBankAndBranchCode$; // (조회결과)어음정보-지급은행및점포코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEndorsementCount$; // (조회결과)어음정보-배서횟수
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoIndvCorpSort$; // (조회결과)상대방정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoResidentBusinessNumber$; // (조회결과)상대방정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoCorpName$; // (조회결과)상대방정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoNameRepresentative$; // (조회결과)상대방정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoAddress$; // (조회결과)상대방정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoBankCode$; // (조회결과)상대방정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String otherPartyInfoDepositAccountNumber$; // (조회결과)상대방정보-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoIndvCorpSort$; // (조회결과)요청인정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoResidentBusinessNumber$; // (조회결과)요청인정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoCorpName$; // (조회결과)요청인정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoNameRepresentative$; // (조회결과)요청인정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoAddress$; // (조회결과)요청인정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoBankCode$; // (조회결과)요청인정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String requesterInfoDepositAccountNumber$; // (조회결과)요청인정보-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String splitNumber$; // (조회결과)분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementNumber$; // (조회결과)배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String queryAmount$; // (조회결과)금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String defaultNoteReturnSpecifiedDate$; // (조회결과)부도어음반환지정일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String defaultNoteReturnRequestDate$; // (조회결과)부도어음반환요청일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsRegistrationDate$; // (조회결과)상환의무이행등록일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String repaymentObligationsConfirmationDate$; // (조회결과)상환의무이행확인일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String returnRejectRequestDate$; // (조회결과)반환.수령거부요청일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String postmaturedEndorsementYn$; // (조회결과)기한후배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String filler$; // (조회결과)FILLER

		@Override
		public void write(OutputStream out) throws IOException {
			noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // (조회결과)어음정보-전자어음번호
			noteInfoNoteType$ = VOUtils.write(out, noteInfoNoteType, 1); // (조회결과)어음정보-어음종류
			noteInfoEnoteProcessStatus$ = VOUtils.write(out, noteInfoEnoteProcessStatus, 2); // (조회결과)어음정보-전자어음처리상태
			noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // (조회결과)어음정보-전자어음발행일자
			noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음정보-전자어음발행지
			noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // (조회결과)어음정보-전자어음금액
			noteInfoDefaultReasonCode$ = VOUtils.write(out, noteInfoDefaultReasonCode, 2); // (조회결과)어음정보-부도사유코드
			noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // (조회결과)어음정보-전자어음만기일자
			noteInfoEnoteDefaultDate$ = VOUtils.write(out, noteInfoEnoteDefaultDate, 8); // (조회결과)어음정보-전자어음부도일자
			noteInfoEnoteFinalSettlementDate$ = VOUtils.write(out, noteInfoEnoteFinalSettlementDate, 8); // (조회결과)어음정보-전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode$ = VOUtils.write(out, noteInfoPaymentBankAndBranchCode, 7); // (조회결과)어음정보-지급은행및점포코드
			noteInfoEndorsementCount$ = VOUtils.write(out, noteInfoEndorsementCount, 2); // (조회결과)어음정보-배서횟수
			otherPartyInfoIndvCorpSort$ = VOUtils.write(out, otherPartyInfoIndvCorpSort, 1); // (조회결과)상대방정보-개인법인구분
			otherPartyInfoResidentBusinessNumber$ = VOUtils.write(out, otherPartyInfoResidentBusinessNumber, 13); // (조회결과)상대방정보-주민사업자번호
			otherPartyInfoCorpName$ = VOUtils.write(out, otherPartyInfoCorpName, 40, "EUC-KR"); // (조회결과)상대방정보-법인명
			otherPartyInfoNameRepresentative$ = VOUtils.write(out, otherPartyInfoNameRepresentative, 20, "EUC-KR"); // (조회결과)상대방정보-성명(대표자명)
			otherPartyInfoAddress$ = VOUtils.write(out, otherPartyInfoAddress, 60, "EUC-KR"); // (조회결과)상대방정보-주소
			otherPartyInfoBankCode$ = VOUtils.write(out, otherPartyInfoBankCode, 3); // (조회결과)상대방정보-은행코드
			otherPartyInfoDepositAccountNumber$ = VOUtils.write(out, otherPartyInfoDepositAccountNumber, 16); // (조회결과)상대방정보-입금계좌번호
			requesterInfoIndvCorpSort$ = VOUtils.write(out, requesterInfoIndvCorpSort, 1); // (조회결과)요청인정보-개인법인구분
			requesterInfoResidentBusinessNumber$ = VOUtils.write(out, requesterInfoResidentBusinessNumber, 13); // (조회결과)요청인정보-주민사업자번호
			requesterInfoCorpName$ = VOUtils.write(out, requesterInfoCorpName, 40, "EUC-KR"); // (조회결과)요청인정보-법인명
			requesterInfoNameRepresentative$ = VOUtils.write(out, requesterInfoNameRepresentative, 20, "EUC-KR"); // (조회결과)요청인정보-성명(대표자명)
			requesterInfoAddress$ = VOUtils.write(out, requesterInfoAddress, 60, "EUC-KR"); // (조회결과)요청인정보-주소
			requesterInfoBankCode$ = VOUtils.write(out, requesterInfoBankCode, 3); // (조회결과)요청인정보-은행코드
			requesterInfoDepositAccountNumber$ = VOUtils.write(out, requesterInfoDepositAccountNumber, 16); // (조회결과)요청인정보-입금계좌번호
			splitNumber$ = VOUtils.write(out, splitNumber, 2); // (조회결과)분할번호
			endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // (조회결과)배서번호
			queryAmount$ = VOUtils.write(out, queryAmount, 15); // (조회결과)금액
			defaultNoteReturnSpecifiedDate$ = VOUtils.write(out, defaultNoteReturnSpecifiedDate, 8); // (조회결과)부도어음반환지정일자
			defaultNoteReturnRequestDate$ = VOUtils.write(out, defaultNoteReturnRequestDate, 8); // (조회결과)부도어음반환요청일자
			repaymentObligationsRegistrationDate$ = VOUtils.write(out, repaymentObligationsRegistrationDate, 8); // (조회결과)상환의무이행등록일자
			repaymentObligationsConfirmationDate$ = VOUtils.write(out, repaymentObligationsConfirmationDate, 8); // (조회결과)상환의무이행확인일자
			returnRejectRequestDate$ = VOUtils.write(out, returnRejectRequestDate, 8); // (조회결과)반환.수령거부요청일자
			postmaturedEndorsementYn$ = VOUtils.write(out, postmaturedEndorsementYn, 1); // (조회결과)기한후배서여부
			filler$ = VOUtils.write(out, filler, 12); // (조회결과)FILLER
		}

		@Override
		public void read(InputStream in) throws IOException {
			noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음정보-전자어음번호
			noteInfoNoteType = VOUtils.toString(noteInfoNoteType$ = VOUtils.read(in, 1)); // (조회결과)어음정보-어음종류
			noteInfoEnoteProcessStatus = VOUtils.toString(noteInfoEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음정보-전자어음처리상태
			noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음발행일자
			noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음정보-전자어음발행지
			noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음정보-전자어음금액
			noteInfoDefaultReasonCode = VOUtils.toString(noteInfoDefaultReasonCode$ = VOUtils.read(in, 2)); // (조회결과)어음정보-부도사유코드
			noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음만기일자
			noteInfoEnoteDefaultDate = VOUtils.toString(noteInfoEnoteDefaultDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음부도일자
			noteInfoEnoteFinalSettlementDate = VOUtils.toString(noteInfoEnoteFinalSettlementDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode = VOUtils.toString(noteInfoPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음정보-지급은행및점포코드
			noteInfoEndorsementCount = VOUtils.toInt(noteInfoEndorsementCount$ = VOUtils.read(in, 2)); // (조회결과)어음정보-배서횟수
			otherPartyInfoIndvCorpSort = VOUtils.toString(otherPartyInfoIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)상대방정보-개인법인구분
			otherPartyInfoResidentBusinessNumber = VOUtils.toString(otherPartyInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)상대방정보-주민사업자번호
			otherPartyInfoCorpName = VOUtils.toString(otherPartyInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)상대방정보-법인명
			otherPartyInfoNameRepresentative = VOUtils.toString(otherPartyInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)상대방정보-성명(대표자명)
			otherPartyInfoAddress = VOUtils.toString(otherPartyInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)상대방정보-주소
			otherPartyInfoBankCode = VOUtils.toString(otherPartyInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)상대방정보-은행코드
			otherPartyInfoDepositAccountNumber = VOUtils.toString(otherPartyInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)상대방정보-입금계좌번호
			requesterInfoIndvCorpSort = VOUtils.toString(requesterInfoIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)요청인정보-개인법인구분
			requesterInfoResidentBusinessNumber = VOUtils.toString(requesterInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)요청인정보-주민사업자번호
			requesterInfoCorpName = VOUtils.toString(requesterInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)요청인정보-법인명
			requesterInfoNameRepresentative = VOUtils.toString(requesterInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)요청인정보-성명(대표자명)
			requesterInfoAddress = VOUtils.toString(requesterInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)요청인정보-주소
			requesterInfoBankCode = VOUtils.toString(requesterInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)요청인정보-은행코드
			requesterInfoDepositAccountNumber = VOUtils.toString(requesterInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)요청인정보-입금계좌번호
			splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // (조회결과)분할번호
			endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)배서번호
			queryAmount = VOUtils.toLong(queryAmount$ = VOUtils.read(in, 15)); // (조회결과)금액
			defaultNoteReturnSpecifiedDate = VOUtils.toString(defaultNoteReturnSpecifiedDate$ = VOUtils.read(in, 8)); // (조회결과)부도어음반환지정일자
			defaultNoteReturnRequestDate = VOUtils.toString(defaultNoteReturnRequestDate$ = VOUtils.read(in, 8)); // (조회결과)부도어음반환요청일자
			repaymentObligationsRegistrationDate = VOUtils.toString(repaymentObligationsRegistrationDate$ = VOUtils.read(in, 8)); // (조회결과)상환의무이행등록일자
			repaymentObligationsConfirmationDate = VOUtils.toString(repaymentObligationsConfirmationDate$ = VOUtils.read(in, 8)); // (조회결과)상환의무이행확인일자
			returnRejectRequestDate = VOUtils.toString(returnRejectRequestDate$ = VOUtils.read(in, 8)); // (조회결과)반환.수령거부요청일자
			postmaturedEndorsementYn = VOUtils.toString(postmaturedEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)기한후배서여부
			filler = VOUtils.toString(filler$ = VOUtils.read(in, 12)); // (조회결과)FILLER
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // (조회결과)어음정보-전자어음번호
			sb.append(", noteInfoNoteType=").append(noteInfoNoteType).append(System.lineSeparator()); // (조회결과)어음정보-어음종류
			sb.append(", noteInfoEnoteProcessStatus=").append(noteInfoEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음정보-전자어음처리상태
			sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음발행일자
			sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음정보-전자어음발행지
			sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // (조회결과)어음정보-전자어음금액
			sb.append(", noteInfoDefaultReasonCode=").append(noteInfoDefaultReasonCode).append(System.lineSeparator()); // (조회결과)어음정보-부도사유코드
			sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음만기일자
			sb.append(", noteInfoEnoteDefaultDate=").append(noteInfoEnoteDefaultDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음부도일자
			sb.append(", noteInfoEnoteFinalSettlementDate=").append(noteInfoEnoteFinalSettlementDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음최종결제일자
			sb.append(", noteInfoPaymentBankAndBranchCode=").append(noteInfoPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음정보-지급은행및점포코드
			sb.append(", noteInfoEndorsementCount=").append(noteInfoEndorsementCount).append(System.lineSeparator()); // (조회결과)어음정보-배서횟수
			sb.append(", otherPartyInfoIndvCorpSort=").append(otherPartyInfoIndvCorpSort).append(System.lineSeparator()); // (조회결과)상대방정보-개인법인구분
			sb.append(", otherPartyInfoResidentBusinessNumber=").append(otherPartyInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)상대방정보-주민사업자번호
			sb.append(", otherPartyInfoCorpName=").append(otherPartyInfoCorpName).append(System.lineSeparator()); // (조회결과)상대방정보-법인명
			sb.append(", otherPartyInfoNameRepresentative=").append(otherPartyInfoNameRepresentative).append(System.lineSeparator()); // (조회결과)상대방정보-성명(대표자명)
			sb.append(", otherPartyInfoAddress=").append(otherPartyInfoAddress).append(System.lineSeparator()); // (조회결과)상대방정보-주소
			sb.append(", otherPartyInfoBankCode=").append(otherPartyInfoBankCode).append(System.lineSeparator()); // (조회결과)상대방정보-은행코드
			sb.append(", otherPartyInfoDepositAccountNumber=").append(otherPartyInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)상대방정보-입금계좌번호
			sb.append(", requesterInfoIndvCorpSort=").append(requesterInfoIndvCorpSort).append(System.lineSeparator()); // (조회결과)요청인정보-개인법인구분
			sb.append(", requesterInfoResidentBusinessNumber=").append(requesterInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)요청인정보-주민사업자번호
			sb.append(", requesterInfoCorpName=").append(requesterInfoCorpName).append(System.lineSeparator()); // (조회결과)요청인정보-법인명
			sb.append(", requesterInfoNameRepresentative=").append(requesterInfoNameRepresentative).append(System.lineSeparator()); // (조회결과)요청인정보-성명(대표자명)
			sb.append(", requesterInfoAddress=").append(requesterInfoAddress).append(System.lineSeparator()); // (조회결과)요청인정보-주소
			sb.append(", requesterInfoBankCode=").append(requesterInfoBankCode).append(System.lineSeparator()); // (조회결과)요청인정보-은행코드
			sb.append(", requesterInfoDepositAccountNumber=").append(requesterInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)요청인정보-입금계좌번호
			sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // (조회결과)분할번호
			sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // (조회결과)배서번호
			sb.append(", queryAmount=").append(queryAmount).append(System.lineSeparator()); // (조회결과)금액
			sb.append(", defaultNoteReturnSpecifiedDate=").append(defaultNoteReturnSpecifiedDate).append(System.lineSeparator()); // (조회결과)부도어음반환지정일자
			sb.append(", defaultNoteReturnRequestDate=").append(defaultNoteReturnRequestDate).append(System.lineSeparator()); // (조회결과)부도어음반환요청일자
			sb.append(", repaymentObligationsRegistrationDate=").append(repaymentObligationsRegistrationDate).append(System.lineSeparator()); // (조회결과)상환의무이행등록일자
			sb.append(", repaymentObligationsConfirmationDate=").append(repaymentObligationsConfirmationDate).append(System.lineSeparator()); // (조회결과)상환의무이행확인일자
			sb.append(", returnRejectRequestDate=").append(returnRejectRequestDate).append(System.lineSeparator()); // (조회결과)반환.수령거부요청일자
			sb.append(", postmaturedEndorsementYn=").append(postmaturedEndorsementYn).append(System.lineSeparator()); // (조회결과)기한후배서여부
			sb.append(", filler=").append(filler).append(System.lineSeparator()); // (조회결과)FILLER
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "500000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String searchConditionSort; // 검색조건구분
	private String processSort; // 처리구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String depositAccountNumber; // 입금계좌번호
	private String lastTransactionDateInquiryStartDate; // 최종거래일기준조회시작일
	private String lastTransactionDateInquiryEndDate; // 최종거래일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0210500000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processSort$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String lastTransactionDateInquiryStartDate$; // 최종거래일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String lastTransactionDateInquiryEndDate$; // 최종거래일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 17;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		processSort$ = VOUtils.write(out, processSort, 1); // 처리구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		lastTransactionDateInquiryStartDate$ = VOUtils.write(out, lastTransactionDateInquiryStartDate, 8); // 최종거래일기준조회시작일
		lastTransactionDateInquiryEndDate$ = VOUtils.write(out, lastTransactionDateInquiryEndDate, 8); // 최종거래일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0210500000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		processSort = VOUtils.toString(processSort$ = VOUtils.read(in, 1)); // 처리구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		lastTransactionDateInquiryStartDate = VOUtils.toString(lastTransactionDateInquiryStartDate$ = VOUtils.read(in, 8)); // 최종거래일기준조회시작일
		lastTransactionDateInquiryEndDate = VOUtils.toString(lastTransactionDateInquiryEndDate$ = VOUtils.read(in, 8)); // 최종거래일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0210500000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", processSort=").append(processSort).append(System.lineSeparator()); // 처리구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", lastTransactionDateInquiryStartDate=").append(lastTransactionDateInquiryStartDate).append(System.lineSeparator()); // 최종거래일기준조회시작일
		sb.append(", lastTransactionDateInquiryEndDate=").append(lastTransactionDateInquiryEndDate).append(System.lineSeparator()); // 최종거래일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "500000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "processSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "lastTransactionDateInquiryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "lastTransactionDateInquiryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteDefaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteFinalSettlementDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "noteInfoEndorsementCount", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "otherPartyInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "otherPartyInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "otherPartyInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "otherPartyInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "otherPartyInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "otherPartyInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "requesterInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "requesterInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "requesterInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "requesterInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "requesterInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requesterInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "queryAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "defaultNoteReturnSpecifiedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "defaultNoteReturnRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationsRegistrationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationsConfirmationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "returnRejectRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "postmaturedEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "12", "defltVal", "")
		);
	}

}
