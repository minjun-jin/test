package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 사고신고 등록 처리내역
 * <pre>{@code
 * KftEntES2221H kftEntES2221H  = new KftEntES2221H(); // 사고신고 등록 처리내역
 * kftEntES2221H.setFileName(""); // 업무구분
 * kftEntES2221H.setDataType(""); // 데이터구분
 * kftEntES2221H.setSerialNumber(""); // 일련번호
 * kftEntES2221H.setBankCode(""); // 은행코드
 * kftEntES2221H.setTotalCount(0); // 총DataRecord수
 * kftEntES2221H.setTransactionDate(""); // 전송일자
 * kftEntES2221H.setTransactionOccurredDate(""); // 거래발생일자
 * kftEntES2221H.setFiller1(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES2221H implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String bankCode; // 은행코드
	private int totalCount; // 총DataRecord수
	private String transactionDate; // 전송일자
	private String transactionOccurredDate; // 거래발생일자
	private String filler1; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalCount$; // 총DataRecord수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionDate$; // 전송일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionOccurredDate$; // 거래발생일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		totalCount$ = VOUtils.write(out, totalCount, 7); // 총DataRecord수
		transactionDate$ = VOUtils.write(out, transactionDate, 8); // 전송일자
		transactionOccurredDate$ = VOUtils.write(out, transactionOccurredDate, 8); // 거래발생일자
		filler1$ = VOUtils.write(out, filler1, 39); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		totalCount = VOUtils.toInt(totalCount$ = VOUtils.read(in, 7)); // 총DataRecord수
		transactionDate = VOUtils.toString(transactionDate$ = VOUtils.read(in, 8)); // 전송일자
		transactionOccurredDate = VOUtils.toString(transactionOccurredDate$ = VOUtils.read(in, 8)); // 거래발생일자
		filler1 = VOUtils.toString(filler1$ = VOUtils.read(in, 39)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", totalCount=").append(totalCount).append(System.lineSeparator()); // 총DataRecord수
		sb.append(", transactionDate=").append(transactionDate).append(System.lineSeparator()); // 전송일자
		sb.append(", transactionOccurredDate=").append(transactionOccurredDate).append(System.lineSeparator()); // 거래발생일자
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "totalCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "transactionOccurredDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler1", "fldLen", "39", "defltVal", "")
		);
	}

}
