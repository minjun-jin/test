package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 출금통보
 * <pre>{@code
 * KftCmsEB34T kftCmsEB34T  = new KftCmsEB34T(); // 출금통보
 * kftCmsEB34T.setRecordType(""); // Record 구분
 * kftCmsEB34T.setSerialNumber(""); // 일련번호
 * kftCmsEB34T.setInstitutionCode(""); // 기관코드
 * kftCmsEB34T.setFileName(""); // File 이름
 * kftCmsEB34T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEB34T.setRequestedWithdrawalCount(0); // 출금의뢰건수
 * kftCmsEB34T.setRequestedWithdrawalAmount(0L); // 출금의뢰금액
 * kftCmsEB34T.setNormalWithdrawalCount(0); // 출금정상건수
 * kftCmsEB34T.setNormalWithdrawalAmount(0L); // 출금정상금액
 * kftCmsEB34T.setFailedWithdrawalCount(0); // 출금불능건수
 * kftCmsEB34T.setFailedWithdrawalAmount(0L); // 출금불능금액
 * kftCmsEB34T.setFiller3(""); // FILLER
 * kftCmsEB34T.setMacValue(""); // MAC 검증값
 * }</pre>
 */
@Data
public class KftCmsEB34T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int requestedWithdrawalCount; // 출금의뢰건수
	private long requestedWithdrawalAmount; // 출금의뢰금액
	private int normalWithdrawalCount; // 출금정상건수
	private long normalWithdrawalAmount; // 출금정상금액
	private int failedWithdrawalCount; // 출금불능건수
	private long failedWithdrawalAmount; // 출금불능금액
	private String filler3; // FILLER
	private String macValue; // MAC 검증값
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalCount$; // 출금의뢰건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalAmount$; // 출금의뢰금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String normalWithdrawalCount$; // 출금정상건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String normalWithdrawalAmount$; // 출금정상금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failedWithdrawalCount$; // 출금불능건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failedWithdrawalAmount$; // 출금불능금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		requestedWithdrawalCount$ = VOUtils.write(out, requestedWithdrawalCount, 8); // 출금의뢰건수
		requestedWithdrawalAmount$ = VOUtils.write(out, requestedWithdrawalAmount, 13); // 출금의뢰금액
		normalWithdrawalCount$ = VOUtils.write(out, normalWithdrawalCount, 8); // 출금정상건수
		normalWithdrawalAmount$ = VOUtils.write(out, normalWithdrawalAmount, 13); // 출금정상금액
		failedWithdrawalCount$ = VOUtils.write(out, failedWithdrawalCount, 8); // 출금불능건수
		failedWithdrawalAmount$ = VOUtils.write(out, failedWithdrawalAmount, 13); // 출금불능금액
		filler3$ = VOUtils.write(out, filler3, 42); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		requestedWithdrawalCount = VOUtils.toInt(requestedWithdrawalCount$ = VOUtils.read(in, 8)); // 출금의뢰건수
		requestedWithdrawalAmount = VOUtils.toLong(requestedWithdrawalAmount$ = VOUtils.read(in, 13)); // 출금의뢰금액
		normalWithdrawalCount = VOUtils.toInt(normalWithdrawalCount$ = VOUtils.read(in, 8)); // 출금정상건수
		normalWithdrawalAmount = VOUtils.toLong(normalWithdrawalAmount$ = VOUtils.read(in, 13)); // 출금정상금액
		failedWithdrawalCount = VOUtils.toInt(failedWithdrawalCount$ = VOUtils.read(in, 8)); // 출금불능건수
		failedWithdrawalAmount = VOUtils.toLong(failedWithdrawalAmount$ = VOUtils.read(in, 13)); // 출금불능금액
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 42)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", requestedWithdrawalCount=").append(requestedWithdrawalCount).append(System.lineSeparator()); // 출금의뢰건수
		sb.append(", requestedWithdrawalAmount=").append(requestedWithdrawalAmount).append(System.lineSeparator()); // 출금의뢰금액
		sb.append(", normalWithdrawalCount=").append(normalWithdrawalCount).append(System.lineSeparator()); // 출금정상건수
		sb.append(", normalWithdrawalAmount=").append(normalWithdrawalAmount).append(System.lineSeparator()); // 출금정상금액
		sb.append(", failedWithdrawalCount=").append(failedWithdrawalCount).append(System.lineSeparator()); // 출금불능건수
		sb.append(", failedWithdrawalAmount=").append(failedWithdrawalAmount).append(System.lineSeparator()); // 출금불능금액
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "normalWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "normalWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "failedWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "failedWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "42", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
