package com.jpmc.kcg.web.rpr.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.rpr.dao.RprTrLMapper;
import com.jpmc.kcg.rpr.dto.RprTrL;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.com.enums.AprvTpCdEnum;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.rpr.dao.RprTrLWebDao;
import com.jpmc.kcg.web.rpr.dto.SelectListRprTrDaoIn;
import com.jpmc.kcg.web.rpr.service.dto.CreateFundReturnIn;
import com.jpmc.kcg.web.rpr.service.dto.GetFundReturnTargetOut;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundReturnIn;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundReturnOut;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundReturnTargetIn;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundReturnTargetOut;

@ExtendWith(MockitoExtension.class)
class RprFundReturnSvcTest {

	@Mock
	private RprTrLWebDao rprTrLWebDao;
	@Mock
	private RprTrLMapper rprTrLMapper;
	@Mock
	private CommonApprovalSvc commonApprovalSvc;
	@Mock
	private BizCom bizCom;
	
	@InjectMocks
	private RprFundReturnSvc rprFundReturnSvc;	
	
    private static com.jpmc.kcg.web.frw.dto.Header header;

    private static MockedStatic<WebApplicationContext> webApplicationContext;

    @BeforeAll
    static void setup() {
        if (webApplicationContext == null) {
            webApplicationContext = mockStatic(WebApplicationContext.class);
            header = new Header();
    		header.setLngCd("en");
            header.setStaffId("JUNIT");
            webApplicationContext.when(WebApplicationContext::getHeader).thenReturn(header);
        }
    }
    
    @AfterAll
    static void tearDown() {
        if (webApplicationContext != null) {
            webApplicationContext.close();
        }
    }
    
    @Test
	@Order(1)
    public void testGetListFundReturnTarget_001() {
    	
    	GetListFundReturnTargetIn input = new GetListFundReturnTargetIn();
        input.setTrStrDt("2024-09-24");
        input.setTrEndDt("2024-09-24");
        
        SelectListRprTrDaoIn daoIn = new SelectListRprTrDaoIn();
        daoIn.setTrStrDt(input.getTrStrDt());
        daoIn.setTrEndDt(input.getTrEndDt());
    	
		List<RprTrL> listInfoOut = new ArrayList<RprTrL>();
		
		RprTrL listInfo = new RprTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("01");

        listInfoOut.add(listInfo);
        
        when(rprTrLWebDao.selectListRprReturnCnt(any(SelectListRprTrDaoIn.class))).thenReturn(1);
     
        GetListFundReturnTargetOut result = rprFundReturnSvc.getListFundReturnTarget(input);
        
        // Then: 결과 값 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());
		
        System.out.println("성공 조회건수 === " + result.getTotCnt());
        
        // DAO 메서드가 호출되었는지 확인
        verify(rprTrLWebDao, times(1)).selectListRprReturnCnt(any(SelectListRprTrDaoIn.class));

	}
    
    @Test
	@Order(2)
    public void testGetListFundReturnTarget_002() {
    	
        // Given
    	GetListFundReturnTargetIn input = new GetListFundReturnTargetIn();
    	
    	// 거래 시작일,종료일을 설정하지 않음

        // When
        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	rprFundReturnSvc.getListFundReturnTarget(input);
        });

        // Then: BusinessException 예외가 발생해야 함
        assertTrue("MCMNI01003".contains(exception.getErrorCode()));
        System.out.println("에러 MCMNI01003 === " + exception.getErrorCode());
    }

    @Test
	@Order(3)
    public void testGetListFundReturn_01() {
    	
    	GetListFundReturnIn input = new GetListFundReturnIn();
        input.setTrStrDt("2024-09-24");
        input.setTrEndDt("2024-09-24");
        
        
        SelectListRprTrDaoIn daoIn = new SelectListRprTrDaoIn();
        daoIn.setTrStrDt(input.getTrStrDt());
        daoIn.setTrEndDt(input.getTrEndDt());
        
		List<RprTrL> listInfoOut = new ArrayList<RprTrL>();
        
		RprTrL listInfo = new RprTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("01");

        listInfoOut.add(listInfo);
        
        when(rprTrLWebDao.selectListRprReturnCnt(any(SelectListRprTrDaoIn.class))).thenReturn(1);
     
        GetListFundReturnOut result = rprFundReturnSvc.getListFundReturn(input);
        
        // Then: 결과 값 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());
		
        System.out.println("성공 조회건수 === " + result.getTotCnt());
        
        // DAO 메서드가 호출되었는지 확인
        verify(rprTrLWebDao, times(1)).selectListRprReturnCnt(any(SelectListRprTrDaoIn.class));
    }
    
    @Test
	@Order(4)
    public void testGetListFundReturn_02() {
    	
        // Given
    	GetListFundReturnIn input = new GetListFundReturnIn();
    	
    	// 거래 시작일,종료일을 설정하지 않음

        // When
        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	rprFundReturnSvc.getListFundReturn(input);
        });

        // Then: BusinessException 예외가 발생해야 함
        assertTrue("MCMNI01003".contains(exception.getErrorCode()));
        System.out.println("에러 MCMNI01003 === " + exception.getErrorCode());
    }
    
    @Test
    @Order(5)
    public void testSetOutPut() {
    	
    	GetFundReturnTargetOut listInfo = new GetFundReturnTargetOut();
    	listInfo.setRqerNm("출금인명");
    	listInfo.setRtnAmt(new BigDecimal (100));
    	listInfo.setRqstAmt(new BigDecimal (100));
    	listInfo.setRtnAmt(new BigDecimal (100));
    	rprFundReturnSvc._setOutPut(listInfo);
    }
    
    @Test
    @Order(6)
    public void testCreateFundRetrun() {
    	
    	CreateFundReturnIn svcIn = new CreateFundReturnIn();
    	svcIn.setTrDt("20250324");
    	svcIn.setOutinDvsnCd("01");
    	svcIn.setTrUnqNo("0001");
    	svcIn.setHostNo("0001");;
    	RprTrL rprTrL= new RprTrL();
    	rprTrL.setTrDt("20250324");
    	rprTrL.setOutinDvsnCd("01");
    	rprTrL.setTrUnqNo("0001");
    	rprTrL.setHostNo("0001");
    	
		when(rprTrLMapper.selectByPrimaryKey(svcIn.getTrDt(), svcIn.getOutinDvsnCd(), svcIn.getTrUnqNo(), svcIn.getHostNo())).thenReturn(rprTrL);
    	rprFundReturnSvc.createFundRetrun(svcIn);
    }
    
    @Test
    @Order(6)
    void testCreateFundRetrun_success() {
        CreateFundReturnIn svcIn = new CreateFundReturnIn();
        svcIn.setTrDt("20250324");
        svcIn.setOutinDvsnCd("01");
        svcIn.setTrUnqNo("0001");
        svcIn.setHostNo("0001");

        svcIn.setFullRtnYn("Y");
        svcIn.setRtnYn("Y");
        svcIn.setRtnRsnCd("R01");
        svcIn.setRtnRsn("테스트사유");
        svcIn.setRtnRjctRsnCd("RJ01");
        svcIn.setRtnRjctRsn("거부사유");
        svcIn.setRqstRtnTrAmt(BigDecimal.valueOf(100000));
        svcIn.setMgrTelNo("01012345678");
        svcIn.setOnlineRqstYn("Y");

        RprTrL rprTrL = new RprTrL();
        rprTrL.setTrDt("20250324");
        rprTrL.setOutinDvsnCd("01");
        rprTrL.setTrUnqNo("0001");
        rprTrL.setHostNo("0001");
        rprTrL.setOpnBnkCd("001");
        rprTrL.setHndlBnkCd("002");
        rprTrL.setOrgnTrDt("20250320");
        rprTrL.setOrgnTrDvsnCd("01");
        rprTrL.setOrgnTrUnqNo("TRX1234");
        rprTrL.setOrgnTrAmt(BigDecimal.valueOf(100000));
        rprTrL.setOrgnRcvAcctNo("111122223333");
        rprTrL.setRqstDt("20250321");
        rprTrL.setRqstTrUnqNo("TRQ9876");

        // mocking
        when(rprTrLMapper.selectByPrimaryKey(
                svcIn.getTrDt(), svcIn.getOutinDvsnCd(), svcIn.getTrUnqNo(), svcIn.getHostNo()
        )).thenReturn(rprTrL);

		ComAprvHIn aprvIn = new ComAprvHIn();
		aprvIn.setAprvTpCd(AprvTpCdEnum.RPR_FUND_RETURN.getValue());
		aprvIn.setAprvRqstDvsnCd(AprvRqstDvsnCdEnum.INSERT.getValue());
		aprvIn.setAprvKeyVal(String.format("%s %s %s %s", svcIn.getTrDt(), svcIn.getOutinDvsnCd(), svcIn.getTrUnqNo(), svcIn.getHostNo()));
		aprvIn.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());

//        when(commonApprovalSvc.requestApproval(aprvIn, null, rprTrL));
//        when(rprTrLWebDao.updateRprAprvStsCd(rprTrL)).thenReturn(1);

        // when
        assertDoesNotThrow(() -> rprFundReturnSvc.createFundRetrun(svcIn));
    }
    
    
	@Test
	@Order(7)
	public void testCreateFundRetrunError() {
		CreateFundReturnIn svcIn = new CreateFundReturnIn();

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundReturnSvc.createFundRetrun(svcIn);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
	}
	
	@Test
	@Order(8)
	public void testGetCdNm() {
	    String cd = "000";

	    ComRespCdM out = new ComRespCdM();
	    out.setRespCd("000");

	    when(bizCom.getRespCode(any(), any(), eq(cd))).thenReturn(out);

	    ComRespCdM result = rprFundReturnSvc._getCdNm(cd);
	    
	    assertNotNull(result);
	    assertEquals("000", result.getRespCd());
	}
	
	@Test
	@Order(10)
	void testGetListFundReturnTarget_enResponse() {
	    // Given
	    GetListFundReturnTargetIn input = new GetListFundReturnTargetIn();
	    input.setTrStrDt("20240924");
	    input.setTrEndDt("20240924");

	    GetFundReturnTargetOut dto = new GetFundReturnTargetOut();
	    dto.setRespCd("999");
	    ComRespCdM cdM = new ComRespCdM();
	    cdM.setRespCdEngNm("ENG MSG");
	    cdM.setRespCdNm("한글메시지");

	    header.setLngCd("en");
	    when(rprTrLWebDao.selectListRprReturnCnt(any())).thenReturn(1);
	    when(rprTrLWebDao.selectListRprReturnTarget(any())).thenReturn(List.of(dto));
	    when(bizCom.getRespCode(any(), any(), eq("999"))).thenReturn(cdM);

	    // When
	    GetListFundReturnTargetOut out = rprFundReturnSvc.getListFundReturnTarget(input);

	    // Then
	    assertEquals("ENG MSG", out.getListOut().get(0).getRespMsg());
	}
	
	@Test
	@Order(11)
	void testGetListFundReturn_rprReturnTrYn_Y() {
	    GetListFundReturnIn input = new GetListFundReturnIn();
	    input.setTrStrDt("20240924");
	    input.setTrEndDt("20240924");
	    input.setRprReturnTrYn("Y");

	    GetFundReturnTargetOut dto = new GetFundReturnTargetOut();

	    when(rprTrLWebDao.selectListRprReturnCnt(any())).thenReturn(1);
	    when(rprTrLWebDao.selectFundReturnList(any())).thenReturn(List.of(dto));

	    GetListFundReturnOut out = rprFundReturnSvc.getListFundReturn(input);
	    assertEquals(1, out.getTotCnt());
	}

	@Test
	@Order(12)
	void testGetListFundReturn_respCdEngMessage() {
	    // Given
	    GetListFundReturnIn input = new GetListFundReturnIn();
	    input.setTrStrDt("20240924");
	    input.setTrEndDt("20240924");

	    // 응답 객체 설정
	    GetFundReturnTargetOut dto = new GetFundReturnTargetOut();
	    dto.setRespCd("R001");

	    // 응답 메시지 설정
	    ComRespCdM respCdM = new ComRespCdM();
	    respCdM.setRespCdEngNm("Test English Message");
	    respCdM.setRespCdNm("테스트 한글 메시지");

	    // 헤더 언어를 EN으로 설정
	    header.setLngCd("en");

	    // mocking
	    when(rprTrLWebDao.selectListRprReturnCnt(any())).thenReturn(1);
	    when(rprTrLWebDao.selectFundReturnList(any())).thenReturn(List.of(dto));
	    when(bizCom.getRespCode(any(), any(), eq("R001"))).thenReturn(respCdM);

	    // When
	    GetListFundReturnOut result = rprFundReturnSvc.getListFundReturn(input);

	    // Then
	    assertEquals("R001", result.getListOut().get(0).getRespCd());
	    assertEquals("Test English Message", result.getListOut().get(0).getRespMsg());

	    System.out.println(">>> 영어 메시지 분기 커버 완료 :: " + result.getListOut().get(0).getRespMsg());
	}


}
