package com.jpmc.kcg.com.biz;

import com.jpmc.kcg.com.BatJobForTest;
import com.jpmc.kcg.com.ComQuartzJob;
import com.jpmc.kcg.com.dao.ComDateMDao;
import com.jpmc.kcg.com.dao.ComDateMMapper;
import com.jpmc.kcg.com.dto.ComDateM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwContextImpl;
import com.jpmc.kcg.frw.FrwTractId;
import com.jpmc.kcg.frw.bat.enums.BatCmpltStsCdEnum;
import com.jpmc.kcg.frw.dao.FrwBatExtDao;
import com.jpmc.kcg.frw.dao.FrwBatRsltLMapper;
import com.jpmc.kcg.frw.dao.FrwBatWorkMMapper;
import com.jpmc.kcg.frw.dto.FrwBatRsltL;
import com.jpmc.kcg.frw.dto.FrwBatWorkM;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.*;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class BatScheduleBeanTest {
    @InjectMocks
    BatScheduleBean batScheduleBean;

    @Mock
    BizDate bizDate;

    @Mock
    FrwBatRsltLMapper frwBatRsltLMapper;

    @Mock
    FrwBatWorkMMapper frwBatWorkMMapper;

    @Mock
    FrwTractId frwTractId;

    @Mock
    Scheduler scheduler;

    @Mock
    SimpleTrigger simpleTrigger;

    @Mock
    CronTrigger cronTrigger;

    @Mock
    private ComDateMMapper comDateMMapper;

    @Mock
    private ComDateMDao comDateMDao;

    @Mock
    private FrwBatExtDao frwBatExtDao;

    @BeforeEach
    void eachSetup() throws SchedulerException {
        FrwContextImpl frwContext = new FrwContextImpl();
        frwContext.setTractId("1");
        frwContext.setUsrId("JUNIT");
        frwContext.setEnvCd("D");
        FrwContextHolder.setContext(frwContext);
    }

    @Test
    void test_addJobWithCronExpr() {
        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("NewBatWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setUseYn("Y");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());

        JobDetail jobDetail = batScheduleBean.addJobWithCronExpr(frwBatWorkM);

        assertEquals(frwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }

    @Test
    void test_addJobWithCronExpr_hasCronCmd() throws SchedulerException {

//		lenient().doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
        when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("NewBatWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setUseYn("Y");
        frwBatWorkM.setSchdDvsnCd("00");
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());

        JobDetail jobDetail = batScheduleBean.addJobWithCronExpr(frwBatWorkM);

        assertEquals(frwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }

    @Test
    void test_addJobWithCronExpr_exception() throws SchedulerException {
        // Scheduler를 mock 처리
        when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenThrow(new SchedulerException("Test Exception"));

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("NewBatWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setUseYn("Y");
        frwBatWorkM.setSchdDvsnCd("00");
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());

        // 예외가 발생하는지 테스트 (SchedulerException이 발생하여 BusinessException으로 래핑될 것으로 예상)
        assertThrows(BusinessException.class, () -> {
            batScheduleBean.addJobWithCronExpr(frwBatWorkM);
        });
    }

    @Test
    void test_modifyJobWithCronExpr_useY() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("N");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertNull(jobDetail);
    }

    @Test
    void test_modifyJobWithCronExpr_useN() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("N");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }

    @Test
    void test_modifyJobWithCronExpr_changeBizDvsnCd() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("IFT");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBizDvsnCd(), jobDetail.getKey().getGroup());
    }

    @Test
    void test_modifyJobWithCronExpr_changeSchdDvsnCd() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("00");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("11");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }

    @Test
    void test_modifyJobWithCronExpr_changeParmVal() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("11");
        bfFrwBatWorkM.setParmVal("param=1");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("11");
        afFrwBatWorkM.setParmVal("param=2");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }
    
    @Test
    void test_modifyJobWithCronExpr_changeEmptyCronCmd() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("00");
        bfFrwBatWorkM.setCronCmd("0 0 0 ? * *");
        bfFrwBatWorkM.setParmVal("param=1");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("00");
        afFrwBatWorkM.setCronCmd("");
        afFrwBatWorkM.setParmVal("param=1");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }


    @Test
    void test_modifyJobWithCronExpr_changeEtc() {
        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("00");
        bfFrwBatWorkM.setCronCmd("0 0 0 ? * *");
        bfFrwBatWorkM.setParmVal("param=1");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("00");
        afFrwBatWorkM.setCronCmd("0 30 5 20 * ?");
        afFrwBatWorkM.setParmVal("param=1");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setUseYn("Y");

        JobDetail jobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), jobDetail.getKey().getName());
    }

    @Test
    void test_modifyJobWithCronExpr_changeCronCmd() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
        when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);

        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("11");
        bfFrwBatWorkM.setParmVal("param=1");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setCronCmd("0 0 13 ? * *");
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("11");
        afFrwBatWorkM.setParmVal("param=1");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setCronCmd("0 0 12 ? * *");
        afFrwBatWorkM.setUseYn("Y");

        JobDetail rtnJobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), rtnJobDetail.getKey().getName());
    }

    @Test
    void test_modifyJobWithCronExpr_changeCronCmd2() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.getTrigger(any(TriggerKey.class))).thenReturn(cronTrigger);
        when(cronTrigger.getCronExpression()).thenReturn("0 0 13 ? * *");
        when(cronTrigger.getJobDataMap()).thenReturn(new JobDataMap());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);


        FrwBatWorkM bfFrwBatWorkM = new FrwBatWorkM();
        bfFrwBatWorkM.setBatWrkId("batWrkId");
        bfFrwBatWorkM.setBizDvsnCd("COM");
        bfFrwBatWorkM.setSchdDvsnCd("11");
        bfFrwBatWorkM.setParmVal("param=1");
        bfFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        bfFrwBatWorkM.setCronCmd("0 0 13 ? * *");
        bfFrwBatWorkM.setUseYn("Y");

        FrwBatWorkM afFrwBatWorkM = new FrwBatWorkM();
        afFrwBatWorkM.setBatWrkId("batWrkId");
        afFrwBatWorkM.setBizDvsnCd("COM");
        afFrwBatWorkM.setSchdDvsnCd("11");
        afFrwBatWorkM.setParmVal("param=1");
        afFrwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        afFrwBatWorkM.setCronCmd("0 0 12 ? * *");
        afFrwBatWorkM.setUseYn("Y");

        JobDetail rtnJobDetail = batScheduleBean.modifyJobWithCronExpr(bfFrwBatWorkM, afFrwBatWorkM);

        assertEquals(afFrwBatWorkM.getBatWrkId(), rtnJobDetail.getKey().getName());
    }
    
    @Test
    void test_runJobNow_MultiBatWrks() throws SchedulerException {
    	List<FrwBatWorkM> list = new ArrayList<>();
        
		FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("000");
		frwBatWorkM.setSchdDvsnCd("00");
		frwBatWorkM.setCronCmd("0 0 12 ? * *");
//		frwBatWorkM.setDtDvsnCd("");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("001");
		frwBatWorkM.setSchdDvsnCd("00");
		frwBatWorkM.setCronCmd("0 30 5 20 * ?");
//		frwBatWorkM.setDtDvsnCd("");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("011");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("D");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);

		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("012");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("102");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("102");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("-1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);

		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("012");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("31");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("001");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("001");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("-1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("101");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("D");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("003");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("31");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("027");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);

		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("103");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("103");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("-1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("103");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("31");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);

		////////////////////// dumy scheduler setting ////////////////////
        when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(null);
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);
        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");
		////////////////////// dumy scheduler setting ////////////////////
        lenient().when(bizDate.getPrevBizDay(any(), anyInt())).thenReturn("19990101");
        lenient().when(bizDate.getNextBizDay(any(), anyInt())).thenReturn("19990101");
        lenient().when(bizDate.getPrevWorkingDay(any(), anyInt())).thenReturn("19990101");
        lenient().when(bizDate.getNextWorkingDay(any(), anyInt())).thenReturn("19990101");
		
		for (FrwBatWorkM obj : list) {
	        
	        when(frwBatWorkMMapper.selectByPrimaryKey(any(String.class))).thenReturn(obj);

	        batScheduleBean.runJobNow(obj.getBatWrkId());
		}

        verify(scheduler, times(list.size())).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }

    @Test
    void test_runJobNow_1args() throws SchedulerException {

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");

//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(null);
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);
        when(frwBatWorkMMapper.selectByPrimaryKey(any(String.class))).thenReturn(frwBatWorkM);
        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        batScheduleBean.runJobNow(frwBatWorkM.getBatWrkId());

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }

    @Test
    void test_runJobNow_4args() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(new Date());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);

        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");        
        when(frwBatWorkMMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatWorkM);

        batScheduleBean.runJobNow(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "20240101", frwBatWorkM.getParmVal());

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }

    @Test
    void test_runJobNow_exception() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(new Date());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);

        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");
        when(frwBatWorkMMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatWorkM);

        batScheduleBean.runJobNow(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "20240101", frwBatWorkM.getParmVal());

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }
    

    @Test
    void test_runJobNow_invalid_BatSchdDvsnCdEnum() throws SchedulerException {
        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("DDDDD");
		frwBatWorkM.setDtDvsnCd("31");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setUseYn("Y");
        when(frwBatWorkMMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatWorkM);

        BusinessException businessException = assertThrows(BusinessException.class, () -> {
        	batScheduleBean.runJobNow(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "20240101", frwBatWorkM.getParmVal());
        });
        assertEquals("MCMNE01016", businessException.getErrorCode());
    }
    
    @Test
    void test_runJobNow_invalid_BatDtDvsnCdEnum() throws SchedulerException {
        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("9999");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setUseYn("Y");
        when(frwBatWorkMMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatWorkM);

        BusinessException businessException = assertThrows(BusinessException.class, () -> {
        	batScheduleBean.runJobNow(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "20240101", frwBatWorkM.getParmVal());
        });
        assertEquals("MCMNE01015", businessException.getErrorCode());
    }
    
    @Test
    void test_runJobAtStartDatetime_hasNot_StartDttm() throws SchedulerException {
    	when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(new Date());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);

        when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");
        when(frwBatWorkMMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatWorkM);

        batScheduleBean.runJobAtStartDatetime(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(),  "20240101", null, null, new Date());

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }


    @Test
    void test_runTriggerAtStartDttm() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.rescheduleJob(any(TriggerKey.class), any(Trigger.class))).thenReturn(new Date());
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);
//		when(frwTractId.newTractId(any(LocalDateTime.class))).thenReturn("1");

        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");

        batScheduleBean.runTriggerAtStartDttm(frwBatWorkM.getBatWrkId(), "1", frwBatWorkM.getBizDvsnCd(), new Hashtable<String,Object>(), "20240101130000");

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }

    @Test
    void test_runTrigger_MCMNE11007_exception() throws SchedulerException {
        // Mock된 scheduler로 동작을 정의
        String batWrkId = "testBatWrkId";
        String batRsltId = "testBatRsltId";
        String bizDvsnCd = "COM";
        Date startAt = new Date();
        Map<String, Object> overwriteJobDataMap = new HashMap<>();

        JobKey jobKey = new JobKey(batWrkId, bizDvsnCd);

        // Mock 설정: scheduler.getJobDetail()에서 예외가 발생하도록 설정
        when(scheduler.getJobDetail(jobKey)).thenThrow(new SchedulerException("Test Scheduler Exception"));

        // 예외가 발생하는지 테스트 (scheduler에서 발생한 예외가 BusinessException으로 변환되어 발생하는지 확인)
        assertThrows(BusinessException.class, () -> {
            batScheduleBean.runTrigger(batWrkId, batRsltId, bizDvsnCd, overwriteJobDataMap, startAt);
        });
    }

    @Test
    void test_runTriggerAtStartDttm_MCMNE09004_exception() {
        // 테스트에 필요한 데이터 설정
        String batWrkId = "testBatWrkId";
        String batRsltId = "testBatRsltId";
        String bizDvsnCd = "COM";
        String invalidDate = "invalidDate"; // 유효하지 않은 날짜 문자열
        Map<String, Object> overwriteJobDataMap = new HashMap<>();

        // 예외가 발생하는지 테스트 (날짜 포맷이 잘못되어 발생하는 예외를 catch하고 BusinessException이 발생하는지 확인)
        assertThrows(BusinessException.class, () -> {
            batScheduleBean.runTriggerAtStartDttm(batWrkId, batRsltId, bizDvsnCd, overwriteJobDataMap, invalidDate);
        });
    }

    @Test
    void test_replaceSimpleTrigger_nullTrigger() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
        when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.getTrigger(any(TriggerKey.class))).thenReturn(null);
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);
        
        
        FrwBatRsltL frwBatRsltL = new FrwBatRsltL();
        frwBatRsltL.setBatRsltId("batRsltId1");
        when(frwBatRsltLMapper.selectByPrimaryKey(anyString())).thenReturn(frwBatRsltL);
        
        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");
        //String batWrkId, String bizDvsnCd, String batRsltId, String strtDttm, String endDttm
        batScheduleBean.replaceSimpleTrigger(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "batRsltId1", "20240101120000", "20240101130000");

        verify(scheduler, times(1)).scheduleJob(any(Trigger.class));
    }

    @Test
    void test_replaceSimpleTrigger_withSimpleTrigger() throws SchedulerException {
//		doNothing().when(scheduler).addJob(any(JobDetail.class), any(Boolean.class));
//		when(scheduler.scheduleJob(any(JobDetail.class), any(Trigger.class))).thenReturn(new Date());
//		when(scheduler.scheduleJob(any(Trigger.class))).thenReturn(new Date());
        when(scheduler.getTrigger(any(TriggerKey.class))).thenReturn(simpleTrigger);
        JobDetail jobDetail = JobBuilder.newJob(ComQuartzJob.class).withIdentity("batWrkId", "COM").build();
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(jobDetail);
        when(simpleTrigger.getJobDataMap()).thenReturn(new JobDataMap());
        
        FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
        frwBatWorkM.setBatWrkId("batWrkId");
        frwBatWorkM.setBizDvsnCd("COM");
        frwBatWorkM.setSchdDvsnCd("11");
        frwBatWorkM.setParmVal("param=1");
        frwBatWorkM.setBatPgmNm(BatJobForTest.class.getCanonicalName());
        frwBatWorkM.setCronCmd("0 0 13 ? * *");
        frwBatWorkM.setUseYn("Y");
        //String batWrkId, String bizDvsnCd, String batRsltId, String strtDttm, String endDttm
        batScheduleBean.replaceSimpleTrigger(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd(), "batRsltId1", "20240101120000", "20240101130000");

        verify(scheduler, times(1)).rescheduleJob(any(TriggerKey.class), any(Trigger.class));
    }

    @Test
    void test_replaceSimpleTrigger_ParseException() throws SchedulerException {
        // 테스트에 필요한 값 설정
        String batWrkId = "testBatWrkId";
        String bizDvsnCd = "COM";
        String batRsltId = "testBatRsltId";
        String invalidStrtDttm = "invalidDate"; // 유효하지 않은 날짜 문자열
        String endDttm = "20231014120000";  // 끝나는 시간은 정상 값

        // 스케줄러의 Mock 설정: jobDetail과 trigger가 반환되도록 설정
        when(scheduler.getJobDetail(any(JobKey.class))).thenReturn(mock(JobDetail.class));
        when(scheduler.getTrigger(any(TriggerKey.class))).thenReturn(null);  // oldTrigger가 없을 때 null 반환

        // 예외가 발생하는지 테스트 (잘못된 날짜 형식이 들어가서 ParseException -> BusinessException으로 변환되는지 확인)
        assertThrows(BusinessException.class, () -> {
            batScheduleBean.replaceSimpleTrigger(batWrkId, bizDvsnCd, batRsltId, invalidStrtDttm, endDttm);
        });
    }

    @Test
    void test_parseParmVal_with_blank_param() {
        // 공백과 빈 문자열이 포함된 입력값 설정
        String parmVal = "key1=value1,,   ,key2=value2";

        // 실제로 parseParmVal을 호출
        Map<String, Object> result = batScheduleBean.parseParmVal(parmVal);

        // 결과에 빈 문자열이나 공백이 포함된 파라미터는 무시되므로 key1과 key2만 있어야 함
        assertEquals(2, result.size());
        assertEquals("value1", result.get("key1"));
        assertEquals("value2", result.get("key2"));
    }

    @Test
    void test_parseParmVal_with_invalid_format_no_dependency() {
        // 잘못된 형식의 파라미터 설정 (key=value 형식이 아닌 경우)
        String parmVal = "key1=value1,keyWithoutEquals,key2=value2";

        // 실제로 parseParmVal 호출
        Map<String, Object> result = batScheduleBean.parseParmVal(parmVal);

        // 결과에 keyWithoutEquals는 포함되지 않아야 함
        assertEquals(2, result.size());
        assertEquals("value1", result.get("key1"));
        assertEquals("value2", result.get("key2"));

        // 로깅을 직접 검증하지는 않지만, 파라미터 파싱이 잘못된 항목을 무시했는지 검증
        assertFalse(result.containsKey("keyWithoutEquals"));
    }

    @Test
    void test_getListPlanBatWork_holidayFromComDateM() throws ParseException {
        // 오늘이 법정 공휴일인 경우 테스트
        String ordDt = "20231015";  // 예시 날짜
        ComDateM comDateM = new ComDateM();
        comDateM.setUseYn("Y");
        comDateM.setHoliDvsnCd("01"); // 법정 공휴일

        when(comDateMMapper.selectByPrimaryKey(ordDt)).thenReturn(comDateM);

        // DAO의 다른 메서드들은 기본 설정
        when(frwBatExtDao.selectListBySchdDvsnCd(anyString(), anyList(), anyList())).thenReturn(new ArrayList<>());

        // 메서드 호출
        List<FrwBatWorkM> result = batScheduleBean.getListPlanBatWork(ordDt);

        // 결과 검증
        assertNotNull(result);
        verify(comDateMMapper).selectByPrimaryKey(ordDt);
        verify(frwBatExtDao).selectListBySchdDvsnCd(anyString(), anyList(), anyList());
    }

    @Test
    void test_getListPlanBatWork_holidayFromWeekend() throws ParseException {
        // 오늘이 주말인 경우 테스트
        String ordDt = "20231015"; // 예시 날짜 (일요일)

        when(comDateMMapper.selectByPrimaryKey(ordDt)).thenReturn(null);

        // DAO의 다른 메서드들은 기본 설정
        when(frwBatExtDao.selectListBySchdDvsnCd(anyString(), anyList(), anyList())).thenReturn(new ArrayList<>());

        // 메서드 호출
        List<FrwBatWorkM> result = batScheduleBean.getListPlanBatWork(ordDt, "N");

        // 결과 검증
        assertNotNull(result);
        verify(comDateMMapper).selectByPrimaryKey(ordDt);
        verify(frwBatExtDao).selectListBySchdDvsnCd(anyString(), anyList(), anyList());
    }

    @Test
    void test_getListPlanBatWork_previousBusinessDay() throws ParseException {
        // 직전 영업일 조건이 충족되는 경우 테스트
        String ordDt = "20231016"; // 예시 날짜 (월요일)

        // ComDateM이 없거나 휴일 아님
        when(comDateMMapper.selectByPrimaryKey(ordDt)).thenReturn(null);
        when(comDateMDao.selectBizDtCount(anyString(), anyString())).thenReturn(5);  // 5번째 영업일
        when(comDateMDao.selectPreviousBizDt(anyString(), anyInt())).thenReturn("20231015");  // 직전 영업일은 10월 15일
        
        List<FrwBatWorkM> list = new ArrayList<>();
        
		FrwBatWorkM frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("000");
		frwBatWorkM.setSchdDvsnCd("00");
		frwBatWorkM.setCronCmd("0 30 5 20 * ?");
//		frwBatWorkM.setDtDvsnCd("D");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("001");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("D");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("001");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("COM");
		frwBatWorkM.setBatWrkId("002");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("-1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);

		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("003");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("31");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("101");
		frwBatWorkM.setSchdDvsnCd("21");
		frwBatWorkM.setDtDvsnCd("D");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("102");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("+1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("102");
		frwBatWorkM.setSchdDvsnCd("11");
		frwBatWorkM.setDtDvsnCd("-1");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
		frwBatWorkM = new FrwBatWorkM();
		frwBatWorkM.setBizDvsnCd("CMS");
		frwBatWorkM.setBatWrkId("103");
		frwBatWorkM.setSchdDvsnCd("27");
		frwBatWorkM.setDtDvsnCd("31");
		frwBatWorkM.setParmVal("a=b");
		frwBatWorkM.setSchdStaTm("100000");
		frwBatWorkM.setSchdEndTm("110000");
		list.add(frwBatWorkM);
		
        when(frwBatExtDao.selectListBySchdDvsnCd(anyString(), anyList(), anyList())).thenReturn(list);

        // 메서드 호출
        List<FrwBatWorkM> result = batScheduleBean.getListPlanBatWork(ordDt);

        // 결과 검증
        assertNotNull(result);
        verify(comDateMMapper).selectByPrimaryKey(ordDt);
        verify(comDateMDao).selectPreviousBizDt(anyString(), anyInt());
        verify(frwBatExtDao).selectListBySchdDvsnCd(anyString(), anyList(), anyList());
    }

    @Test
    void test_listPrevDelayedBat_with_completed_and_delayed_tasks() {
        // 테스트에 필요한 데이터 설정
        String ordDt = "20231014";  // 임의의 작업일
        String batWrkId = "testBatWrkId";  // 임의의 배치 작업 ID

        // Mock 데이터를 설정 - 완료된 작업과 지연된 작업 혼합
        List<FrwBatRsltL> mockPrevBatList = new ArrayList<>();

        FrwBatRsltL completedTask = new FrwBatRsltL();
        completedTask.setCmpltStsCd(BatCmpltStsCdEnum.COMPLETED.getValue()); // 완료된 작업

        FrwBatRsltL delayedTask = new FrwBatRsltL();
        delayedTask.setCmpltStsCd(BatCmpltStsCdEnum.WAITING.getValue()); // 지연된 작업

        mockPrevBatList.add(completedTask);
        mockPrevBatList.add(delayedTask);

        // Mock 설정
        when(frwBatExtDao.selectListPrevBatLtstRslt(ordDt, batWrkId)).thenReturn(mockPrevBatList);

        // 메서드 호출
        List<FrwBatRsltL> result = batScheduleBean.listPrevDelayedBat(ordDt, batWrkId);

        // 결과 검증 - 지연된 작업만 반환되어야 함
        assertEquals(1, result.size());
        assertEquals(BatCmpltStsCdEnum.WAITING.getValue(), result.get(0).getCmpltStsCd());
    }

    @Test
    void test_listPrevDelayedBat_with_all_completed_tasks() {
        // 테스트에 필요한 데이터 설정
        String ordDt = "20231014";
        String batWrkId = "testBatWrkId";

        // Mock 데이터 설정 - 모든 작업이 완료된 상태
        List<FrwBatRsltL> mockPrevBatList = new ArrayList<>();

        FrwBatRsltL completedTask1 = new FrwBatRsltL();
        completedTask1.setCmpltStsCd(BatCmpltStsCdEnum.COMPLETED.getValue());

        FrwBatRsltL completedTask2 = new FrwBatRsltL();
        completedTask2.setCmpltStsCd(BatCmpltStsCdEnum.COMPLETED.getValue());

        mockPrevBatList.add(completedTask1);
        mockPrevBatList.add(completedTask2);

        // Mock 설정
        when(frwBatExtDao.selectListPrevBatLtstRslt(ordDt, batWrkId)).thenReturn(mockPrevBatList);

        // 메서드 호출
        List<FrwBatRsltL> result = batScheduleBean.listPrevDelayedBat(ordDt, batWrkId);

        // 결과 검증 - 모든 작업이 완료된 경우 지연된 작업은 없어야 함
        assertEquals(0, result.size());
    }

    @Test
    void test_listPrevDelayedBat_with_all_delayed_tasks() {
        // 테스트에 필요한 데이터 설정
        String ordDt = "20231014";
        String batWrkId = "testBatWrkId";

        // Mock 데이터 설정 - 모든 작업이 지연된 상태
        List<FrwBatRsltL> mockPrevBatList = new ArrayList<>();

        FrwBatRsltL delayedTask1 = new FrwBatRsltL();
        delayedTask1.setCmpltStsCd(BatCmpltStsCdEnum.WAITING.getValue());

        FrwBatRsltL delayedTask2 = new FrwBatRsltL();
        delayedTask2.setCmpltStsCd(BatCmpltStsCdEnum.FAILED.getValue());  // 실패한 작업도 지연으로 간주

        mockPrevBatList.add(delayedTask1);
        mockPrevBatList.add(delayedTask2);

        // Mock 설정
        when(frwBatExtDao.selectListPrevBatLtstRslt(ordDt, batWrkId)).thenReturn(mockPrevBatList);

        // 메서드 호출
        List<FrwBatRsltL> result = batScheduleBean.listPrevDelayedBat(ordDt, batWrkId);

        // 결과 검증 - 모든 작업이 지연되었으므로 결과는 2개
        assertEquals(2, result.size());
        assertEquals(BatCmpltStsCdEnum.WAITING.getValue(), result.get(0).getCmpltStsCd());
        assertEquals(BatCmpltStsCdEnum.FAILED.getValue(), result.get(1).getCmpltStsCd());
    }

}
