package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 매일분 공동코드 변동분
 * <pre>{@code
 * KftHofCC0011T kftHofCC0011T  = new KftHofCC0011T(); // 매일분 공동코드 변동분
 * kftHofCC0011T.setFileName(""); // 업무구분
 * kftHofCC0011T.setDataType(""); // 데이타구분
 * kftHofCC0011T.setSerialNumber(""); // 일련번호
 * kftHofCC0011T.setInstitutionCode(""); // 기관코드
 * kftHofCC0011T.setTotalDataRecordCount(""); // 총DATARECORD수
 * kftHofCC0011T.setTransactionDate(""); // 거래발생일
 * kftHofCC0011T.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofCC0011T implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String totalDataRecordCount; // 총DATARECORD수
	private String transactionDate; // 거래발생일
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총DATARECORD수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionDate$; // 거래발생일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 7); // 총DATARECORD수
		transactionDate$ = VOUtils.write(out, transactionDate, 6); // 거래발생일
		filler2$ = VOUtils.write(out, filler2, 269); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		totalDataRecordCount = VOUtils.toString(totalDataRecordCount$ = VOUtils.read(in, 7)); // 총DATARECORD수
		transactionDate = VOUtils.toString(transactionDate$ = VOUtils.read(in, 6)); // 거래발생일
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 269)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총DATARECORD수
		sb.append(", transactionDate=").append(transactionDate).append(System.lineSeparator()); // 거래발생일
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionDate", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "269", "defltVal", "")
		);
	}

}
