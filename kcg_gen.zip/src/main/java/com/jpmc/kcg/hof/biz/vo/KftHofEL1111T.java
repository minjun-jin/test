package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금음공동망 월간 은행별 거래집계현황
 * <pre>{@code
 * KftHofEL1111T kftHofEL1111T  = new KftHofEL1111T(); // 전자금음공동망 월간 은행별 거래집계현황
 * kftHofEL1111T.setFileName("EL1111"); // 업무구분
 * kftHofEL1111T.setDataType("33"); // 데이타구분
 * kftHofEL1111T.setSerialNumber(""); // 일련번호
 * kftHofEL1111T.setBnkCd("057"); // 은행코드
 * kftHofEL1111T.setTotalDataRecordCount(0); // 총DATARECORD수
 * kftHofEL1111T.setFiller3(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL1111T implements Vo {

	private String fileName = "EL1111"; // 업무구분
	private String dataType = "33"; // 데이타구분
	private String serialNumber; // 일련번호
	private String bnkCd = "057"; // 은행코드
	private int totalDataRecordCount; // 총DATARECORD수
	private String filler3; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총DATARECORD수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 7); // 총DATARECORD수
		filler3$ = VOUtils.write(out, filler3, 155); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 7)); // 총DATARECORD수
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 155)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총DATARECORD수
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", "EL1111"),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", "33"),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "totalDataRecordCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "155", "defltVal", "")
		);
	}

}
