package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금용공동망 개설 미완료거래통지표
 * <pre>{@code
 * KftHofEL0022R kftHofEL0022R  = new KftHofEL0022R(); // 전자금용공동망 개설 미완료거래통지표
 * kftHofEL0022R.setFileName(""); // 업무구분
 * kftHofEL0022R.setDataType(""); // 데이타구분
 * kftHofEL0022R.setSerialNumber(""); // 일련번호
 * kftHofEL0022R.setTransactionIdNumber(""); // 거래고유번호
 * kftHofEL0022R.setOpeningBankCode(""); // 개설은행코드
 * kftHofEL0022R.setTransactionCode(""); // 거래구분코드
 * kftHofEL0022R.setAccountNumber(""); // 계좌번호
 * kftHofEL0022R.setAmount(""); // 금액
 * kftHofEL0022R.setHandlingBankCode(""); // 취급기관코드
 * kftHofEL0022R.setRequestBranchCode(""); // 취급지점코드
 * kftHofEL0022R.setWithdrawer(""); // 출금인
 * kftHofEL0022R.setRequestorInformation(""); // 의뢰인정보
 * kftHofEL0022R.setWithdrawalInfo(""); // 출금인정보
 * kftHofEL0022R.setRealSenderName(""); // 송금인실명
 * kftHofEL0022R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0022R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String transactionIdNumber; // 거래고유번호
	private String openingBankCode; // 개설은행코드
	private String transactionCode; // 거래구분코드
	private String accountNumber; // 계좌번호
	private String amount; // 금액
	private String handlingBankCode; // 취급기관코드
	private String requestBranchCode; // 취급지점코드
	private String withdrawer; // 출금인
	private String requestorInformation; // 의뢰인정보
	private String withdrawalInfo; // 출금인정보
	private String realSenderName; // 송금인실명
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String openingBankCode$; // 개설은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountNumber$; // 계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String amount$; // 금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingBankCode$; // 취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawer$; // 출금인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestorInformation$; // 의뢰인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalInfo$; // 출금인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realSenderName$; // 송금인실명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		openingBankCode$ = VOUtils.write(out, openingBankCode, 3); // 개설은행코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		accountNumber$ = VOUtils.write(out, accountNumber, 16); // 계좌번호
		amount$ = VOUtils.write(out, amount, 14); // 금액
		handlingBankCode$ = VOUtils.write(out, handlingBankCode, 3); // 취급기관코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급지점코드
		withdrawer$ = VOUtils.write(out, withdrawer, 20, "EUC-KR"); // 출금인
		requestorInformation$ = VOUtils.write(out, requestorInformation, 32); // 의뢰인정보
		withdrawalInfo$ = VOUtils.write(out, withdrawalInfo, 16); // 출금인정보
		realSenderName$ = VOUtils.write(out, realSenderName, 20, "EUC-KR"); // 송금인실명
		filler$ = VOUtils.write(out, filler, 135); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		openingBankCode = VOUtils.toString(openingBankCode$ = VOUtils.read(in, 3)); // 개설은행코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		accountNumber = VOUtils.toString(accountNumber$ = VOUtils.read(in, 16)); // 계좌번호
		amount = VOUtils.toString(amount$ = VOUtils.read(in, 14)); // 금액
		handlingBankCode = VOUtils.toString(handlingBankCode$ = VOUtils.read(in, 3)); // 취급기관코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급지점코드
		withdrawer = VOUtils.toString(withdrawer$ = VOUtils.read(in, 20, "EUC-KR")); // 출금인
		requestorInformation = VOUtils.toString(requestorInformation$ = VOUtils.read(in, 32)); // 의뢰인정보
		withdrawalInfo = VOUtils.toString(withdrawalInfo$ = VOUtils.read(in, 16)); // 출금인정보
		realSenderName = VOUtils.toString(realSenderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송금인실명
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 135)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", openingBankCode=").append(openingBankCode).append(System.lineSeparator()); // 개설은행코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", accountNumber=").append(accountNumber).append(System.lineSeparator()); // 계좌번호
		sb.append(", amount=").append(amount).append(System.lineSeparator()); // 금액
		sb.append(", handlingBankCode=").append(handlingBankCode).append(System.lineSeparator()); // 취급기관코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급지점코드
		sb.append(", withdrawer=").append(withdrawer).append(System.lineSeparator()); // 출금인
		sb.append(", requestorInformation=").append(requestorInformation).append(System.lineSeparator()); // 의뢰인정보
		sb.append(", withdrawalInfo=").append(withdrawalInfo).append(System.lineSeparator()); // 출금인정보
		sb.append(", realSenderName=").append(realSenderName).append(System.lineSeparator()); // 송금인실명
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "openingBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "accountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "amount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "handlingBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "withdrawer", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "requestorInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "withdrawalInfo", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "realSenderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "135", "defltVal", "")
		);
	}

}
