#!/bin/sh
set +v
sh gradlew generateMybatis
