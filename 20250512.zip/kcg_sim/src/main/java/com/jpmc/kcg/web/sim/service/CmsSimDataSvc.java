package com.jpmc.kcg.web.sim.service;

import org.springframework.stereotype.Service;

import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.web.sim.dao.SimCmsSndRcvFileLDao;
import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileL;
import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileLIn;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CmsSimDataSvc {
	
	private final BizDate bizDate;
	private SimCmsSndRcvFileLDao simCmsSndRcvFileLDao;
	
	public CmsSimDataSvc(SimCmsSndRcvFileLDao simCmsSndRcvFileLDao, BizDate bizDate) {
		this.simCmsSndRcvFileLDao = simCmsSndRcvFileLDao;
		this.bizDate = bizDate;
	}
	
	public void saveCmsSimData(SimCmsSndRcvFileLIn svcIn) {
		
		svcIn.getSimCmsSndRcvFilelIn().stream().forEach(e -> {
			e.setSrDt(bizDate.getNextBizDay(e.getSrDt(), 1));
			e.setTrDt(bizDate.getNextBizDay(e.getTrDt(), 1));
			simCmsSndRcvFileLDao.insertSimCmsSndRcvFileL(e);
		});
	}
	
	public void deleteCmsSimData(SimCmsSndRcvFileLIn svcIn) {
		
		svcIn.getSimCmsSndRcvFilelIn().stream().forEach(e -> {
			simCmsSndRcvFileLDao.deleteSimCmsSndRcvFileL(e);
		});
	}
	
	public void modifyCmsSimData(SimCmsSndRcvFileL svcIn) {
		
		simCmsSndRcvFileLDao.updateSimCmsSndRcvFileL(svcIn);
		
	}
}