package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자기앞수표조회
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 전문의 처리결과를 정의해 주는 코드
 * requestBankCode 취급기관코드 취급기관 구분코드
 * requestBranchCode 취급지점코드 취급기관의 해당영업점코드
 * requestMessageNumber 취급전문관리번호 취급기관의 전문관리번호(기관별 일련번호)
 * requestMessageSendTime 취급전문전송시간 취급기관센터에서의 해당 전문의 전송시간
 * kftcMessageNumber 중계센터전문관리번호 중계센터에서의 전문관리번호(기관코드(3) + 기관별 일련번호(6))
 * kftcMessageTime 중계센터전문전송시간 중계센터에서의 해당 전문 전송시간
 * beneficiaryBankCode 개설기관코드 개설기관 구분코드
 * beneficiaryBranchCode 개설지점코드 개설기관의 해당 영업점코드
 * beneficiaryMessageNumber 개설전문관리번호 개설기관의 전문관리번호(기관별 일련번호)
 * beneficiaryMessageSendTime 개설전문전송시간 개설기관센터에서의 해당 전문의 전송시간
 * reservedInformationField1 예비정보FIELD 중계센터 및 참가기관에서 임의 사용 가능한 FIELD
 * chequeIssuanceDate 수표발행일자 수표발행점에서 수표가 발행된 일자
 * reservedInformationField2 예비정보FIELD 중계센터 및 참가기관에서 임의 사용 가능한 FIELD
 * chequeSerialNumber 수표번호(일련번호) 수표의 일련번호
 * chequeTypeNumber 수표분류번호 수표의 종류별코드
 * chequeAmount 수표금액 수표금액
 * accountNumber 계좌번호 수표 계좌번호
 * chequeStatus1 수표상태코드1 수표조회 처리결과 내용을 표기
 * chequeStatus2 수표상태코드2 수표조회 처리결과 내용을 표기
 * chequeStatus3 수표상태코드3 수표조회 처리결과 내용을 표기
 * chequeIssuanceBranchCode 수표발행지점코드 수표에 인자된 지로코드 7자리를 SET한다.
 * reservedInformationField11 예비정보FIELD 최초 전문발생기관(취급기관)에서 임의 사용 가능한 FIELD
 * 
 * KftIft0200300 kftIft0200300 = new KftIft0200300(); // 자기앞수표조회
 * kftIft0200300.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftIft0200300.setSystemId("03"); // 시스템-ID
 * kftIft0200300.setInstitutionCode("057"); // 기관코드
 * kftIft0200300.setMessageType("0200"); // 전문종별구분코드
 * kftIft0200300.setMessageCode("300"); // 업무구분코드
 * kftIft0200300.setSendReceiveFlag("1"); // 송수신FLAG
 * kftIft0200300.setResponseCode(""); // 응답코드
 * kftIft0200300.setRequestBankCode("000"); // 취급기관코드
 * kftIft0200300.setRequestBranchCode("0000"); // 취급지점코드
 * kftIft0200300.setRequestMessageNumber("000000"); // 취급전문관리번호
 * kftIft0200300.setRequestMessageSendTime(LocalDateTime.now()); // 취급전문전송시간
 * kftIft0200300.setKftcMessageNumber("000000000"); // 중계센터전문관리번호
 * kftIft0200300.setKftcMessageTime(LocalDateTime.now()); // 중계센터전문전송시간
 * kftIft0200300.setBeneficiaryBankCode("000"); // 개설기관코드
 * kftIft0200300.setBeneficiaryBranchCode("0000"); // 개설지점코드
 * kftIft0200300.setBeneficiaryMessageNumber("000000"); // 개설전문관리번호
 * kftIft0200300.setBeneficiaryMessageSendTime(LocalDateTime.now()); // 개설전문전송시간
 * kftIft0200300.setReservedInformationField1(""); // 예비정보FIELD
 * kftIft0200300.setChequeIssuanceDate("000000"); // 수표발행일자
 * kftIft0200300.setReservedInformationField2(""); // 예비정보FIELD
 * kftIft0200300.setChequeSerialNumber("00000000"); // 수표번호(일련번호)
 * kftIft0200300.setChequeTypeNumber("00"); // 수표분류번호
 * kftIft0200300.setChequeAmount(0L); // 수표금액
 * kftIft0200300.setAccountNumber("000000"); // 계좌번호
 * kftIft0200300.setChequeStatus1(""); // 수표상태코드1
 * kftIft0200300.setChequeStatus2(""); // 수표상태코드2
 * kftIft0200300.setChequeStatus3(""); // 수표상태코드3
 * kftIft0200300.setChequeIssuanceBranchCode("0000000"); // 수표발행지점코드
 * kftIft0200300.setReservedInformationField11(""); // 예비정보FIELD
 * }</pre>
 */
@Data
public class KftIft0200300 implements KftIftComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0200"; // 전문종별구분코드
	private String messageCode = "300"; // 업무구분코드
	private String sendReceiveFlag = "1"; // 송수신FLAG
	private String responseCode; // 응답코드
	private String requestBankCode = "000"; // 취급기관코드
	private String requestBranchCode = "0000"; // 취급지점코드
	private String requestMessageNumber = "000000"; // 취급전문관리번호
	private LocalDateTime requestMessageSendTime; // 취급전문전송시간
	private String kftcMessageNumber = "000000000"; // 중계센터전문관리번호
	private LocalDateTime kftcMessageTime; // 중계센터전문전송시간
	private String beneficiaryBankCode = "000"; // 개설기관코드
	private String beneficiaryBranchCode = "0000"; // 개설지점코드
	private String beneficiaryMessageNumber = "000000"; // 개설전문관리번호
	private LocalDateTime beneficiaryMessageSendTime; // 개설전문전송시간
	private String reservedInformationField1; // 예비정보FIELD
	private String chequeIssuanceDate = "000000"; // 수표발행일자
	private String reservedInformationField2; // 예비정보FIELD
	private String chequeSerialNumber = "00000000"; // 수표번호(일련번호)
	private String chequeTypeNumber = "00"; // 수표분류번호
	private long chequeAmount; // 수표금액
	private String accountNumber = "000000"; // 계좌번호
	private String chequeStatus1; // 수표상태코드1
	private String chequeStatus2; // 수표상태코드2
	private String chequeStatus3; // 수표상태코드3
	private String chequeIssuanceBranchCode = "0000000"; // 수표발행지점코드
	private String reservedInformationField11; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankCode$; // 취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageNumber$; // 취급전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageSendTime$; // 취급전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageNumber$; // 중계센터전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageTime$; // 중계센터전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageNumber$; // 개설전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageSendTime$; // 개설전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField1$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeIssuanceDate$; // 수표발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField2$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeSerialNumber$; // 수표번호(일련번호)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeTypeNumber$; // 수표분류번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeAmount$; // 수표금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountNumber$; // 계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeStatus1$; // 수표상태코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeStatus2$; // 수표상태코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeStatus3$; // 수표상태코드3
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeIssuanceBranchCode$; // 수표발행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 업무구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(requestBankCode$)) { // 취급기관코드
			return 7;
		}
		if (VOUtils.isWhitespace(requestBranchCode$)) { // 취급지점코드
			return 8;
		}
		if (VOUtils.isWhitespace(requestMessageNumber$)) { // 취급전문관리번호
			return 9;
		}
		if (VOUtils.isWhitespace(requestMessageSendTime$)) { // 취급전문전송시간
			return 10;
		}
		if (VOUtils.isWhitespace(beneficiaryBankCode$)) { // 개설기관코드
			return 13;
		}
		if (VOUtils.isNotNumeric(chequeIssuanceDate$)) { // 수표발행일자
			return 18;
		}
		if (VOUtils.isNotNumeric(chequeSerialNumber$)) { // 수표번호(일련번호)
			return 20;
		}
		if (VOUtils.isNotNumeric(chequeTypeNumber$)) { // 수표분류번호
			return 21;
		}
		if (VOUtils.isNotNumeric(chequeAmount$)) { // 수표금액
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(chequeStatus1$)) { // 수표상태코드1
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(chequeStatus2$)) { // 수표상태코드2
			return 25;
		}
		if (VOUtils.isNotAlphanumericSpace(chequeStatus3$)) { // 수표상태코드3
			return 26;
		}
		if (VOUtils.isWhitespace(chequeIssuanceBranchCode$)) { // 수표발행지점코드
			return 27;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBankCode$ = VOUtils.write(out, requestBankCode, 3); // 취급기관코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 4); // 취급지점코드
		requestMessageNumber$ = VOUtils.write(out, requestMessageNumber, 6); // 취급전문관리번호
		requestMessageSendTime$ = VOUtils.write(out, requestMessageSendTime, 12, "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber$ = VOUtils.write(out, kftcMessageNumber, 9); // 중계센터전문관리번호
		kftcMessageTime$ = VOUtils.write(out, kftcMessageTime, 12, "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 4); // 개설지점코드
		beneficiaryMessageNumber$ = VOUtils.write(out, beneficiaryMessageNumber, 6); // 개설전문관리번호
		beneficiaryMessageSendTime$ = VOUtils.write(out, beneficiaryMessageSendTime, 12, "yyMMddHHmmss"); // 개설전문전송시간
		reservedInformationField1$ = VOUtils.write(out, reservedInformationField1, 4); // 예비정보FIELD
		chequeIssuanceDate$ = VOUtils.write(out, chequeIssuanceDate, 6); // 수표발행일자
		reservedInformationField2$ = VOUtils.write(out, reservedInformationField2, 4); // 예비정보FIELD
		chequeSerialNumber$ = VOUtils.write(out, chequeSerialNumber, 8); // 수표번호(일련번호)
		chequeTypeNumber$ = VOUtils.write(out, chequeTypeNumber, 2); // 수표분류번호
		chequeAmount$ = VOUtils.write(out, chequeAmount, 10); // 수표금액
		accountNumber$ = VOUtils.write(out, accountNumber, 6); // 계좌번호
		chequeStatus1$ = VOUtils.write(out, chequeStatus1, 3); // 수표상태코드1
		chequeStatus2$ = VOUtils.write(out, chequeStatus2, 3); // 수표상태코드2
		chequeStatus3$ = VOUtils.write(out, chequeStatus3, 3); // 수표상태코드3
		chequeIssuanceBranchCode$ = VOUtils.write(out, chequeIssuanceBranchCode, 7); // 수표발행지점코드
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 11); // 예비정보FIELD
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBankCode = VOUtils.toString(requestBankCode$ = VOUtils.read(in, 3)); // 취급기관코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 4)); // 취급지점코드
		requestMessageNumber = VOUtils.toString(requestMessageNumber$ = VOUtils.read(in, 6)); // 취급전문관리번호
		requestMessageSendTime = VOUtils.toLocalDateTime(requestMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber = VOUtils.toString(kftcMessageNumber$ = VOUtils.read(in, 9)); // 중계센터전문관리번호
		kftcMessageTime = VOUtils.toLocalDateTime(kftcMessageTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 4)); // 개설지점코드
		beneficiaryMessageNumber = VOUtils.toString(beneficiaryMessageNumber$ = VOUtils.read(in, 6)); // 개설전문관리번호
		beneficiaryMessageSendTime = VOUtils.toLocalDateTime(beneficiaryMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 개설전문전송시간
		reservedInformationField1 = VOUtils.toString(reservedInformationField1$ = VOUtils.read(in, 4)); // 예비정보FIELD
		chequeIssuanceDate = VOUtils.toString(chequeIssuanceDate$ = VOUtils.read(in, 6)); // 수표발행일자
		reservedInformationField2 = VOUtils.toString(reservedInformationField2$ = VOUtils.read(in, 4)); // 예비정보FIELD
		chequeSerialNumber = VOUtils.toString(chequeSerialNumber$ = VOUtils.read(in, 8)); // 수표번호(일련번호)
		chequeTypeNumber = VOUtils.toString(chequeTypeNumber$ = VOUtils.read(in, 2)); // 수표분류번호
		chequeAmount = VOUtils.toLong(chequeAmount$ = VOUtils.read(in, 10)); // 수표금액
		accountNumber = VOUtils.toString(accountNumber$ = VOUtils.read(in, 6)); // 계좌번호
		chequeStatus1 = VOUtils.toString(chequeStatus1$ = VOUtils.read(in, 3)); // 수표상태코드1
		chequeStatus2 = VOUtils.toString(chequeStatus2$ = VOUtils.read(in, 3)); // 수표상태코드2
		chequeStatus3 = VOUtils.toString(chequeStatus3$ = VOUtils.read(in, 3)); // 수표상태코드3
		chequeIssuanceBranchCode = VOUtils.toString(chequeIssuanceBranchCode$ = VOUtils.read(in, 7)); // 수표발행지점코드
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 11)); // 예비정보FIELD
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBankCode=").append(requestBankCode).append(System.lineSeparator()); // 취급기관코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급지점코드
		sb.append(", requestMessageNumber=").append(requestMessageNumber).append(System.lineSeparator()); // 취급전문관리번호
		sb.append(", requestMessageSendTime=").append(requestMessageSendTime).append(System.lineSeparator()); // 취급전문전송시간
		sb.append(", kftcMessageNumber=").append(kftcMessageNumber).append(System.lineSeparator()); // 중계센터전문관리번호
		sb.append(", kftcMessageTime=").append(kftcMessageTime).append(System.lineSeparator()); // 중계센터전문전송시간
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설지점코드
		sb.append(", beneficiaryMessageNumber=").append(beneficiaryMessageNumber).append(System.lineSeparator()); // 개설전문관리번호
		sb.append(", beneficiaryMessageSendTime=").append(beneficiaryMessageSendTime).append(System.lineSeparator()); // 개설전문전송시간
		sb.append(", reservedInformationField1=").append(reservedInformationField1).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", chequeIssuanceDate=").append(chequeIssuanceDate).append(System.lineSeparator()); // 수표발행일자
		sb.append(", reservedInformationField2=").append(reservedInformationField2).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", chequeSerialNumber=").append(chequeSerialNumber).append(System.lineSeparator()); // 수표번호(일련번호)
		sb.append(", chequeTypeNumber=").append(chequeTypeNumber).append(System.lineSeparator()); // 수표분류번호
		sb.append(", chequeAmount=").append(chequeAmount).append(System.lineSeparator()); // 수표금액
		sb.append(", accountNumber=").append(accountNumber).append(System.lineSeparator()); // 계좌번호
		sb.append(", chequeStatus1=").append(chequeStatus1).append(System.lineSeparator()); // 수표상태코드1
		sb.append(", chequeStatus2=").append(chequeStatus2).append(System.lineSeparator()); // 수표상태코드2
		sb.append(", chequeStatus3=").append(chequeStatus3).append(System.lineSeparator()); // 수표상태코드3
		sb.append(", chequeIssuanceBranchCode=").append(chequeIssuanceBranchCode).append(System.lineSeparator()); // 수표발행지점코드
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "300"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "1"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requestBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBranchCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "requestMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "requestMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "kftcMessageNumber", "fldLen", "9", "defltVal", "000000000"),
			Map.of("fld", "kftcMessageTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "beneficiaryMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "beneficiaryMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "reservedInformationField1", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "chequeIssuanceDate", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "reservedInformationField2", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "chequeSerialNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "chequeTypeNumber", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "chequeAmount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "accountNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "chequeStatus1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "chequeStatus2", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "chequeStatus3", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "chequeIssuanceBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "reservedInformationField11", "fldLen", "11", "defltVal", "")
		);
	}

}
