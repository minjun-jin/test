import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// URPRINQ007 컴포넌트를 불러옵니다.
import URPRINQ007 from "@/pages/views/rpr/URPRINQ-007"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(URPRINQ007)

describe("[URPRINQ-007] 거래내역조회", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("19900101")
  })

  beforeEach(() => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        orgnTrUnqNo: "1",
      },
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
        sumOut: {},
      },
    })
  })

  it.each([
    {
      orgnTrUnqNo: undefined,
      isDashboard: true,
      trStsCd: "02",
    },
    { orgnTrUnqNo: undefined, isDashboard: true, trStsCd: "03" },
    { orgnTrUnqNo: undefined, isDashboard: true, trStsCd: "04" },
  ])("useEffect Test - isDashboard is true", async (params) => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: params,
    })

    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("useEffect Test - isDashboard is false", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        orgnTrUnqNo: undefined,
        isDashboard: false,
      },
    })
    mockUseProxy.mockAsync.mockRestore()

    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("valueGetter Test", async () => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: null,
        },
      },
    })

    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: "01",
        },
      },
    })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each([
    {
      outinDvsnCd: "01",
      trStsCd: "13",
    },
    {
      outinDvsnCd: "01",
      trStsCd: "19",
      tlgKndDvsnCd: "0210",
    },
    {
      outinDvsnCd: "01",
      trStsCd: "19",
      tlgKndDvsnCd: "0200",
    },
    {
      outinDvsnCd: "01",
      trStsCd: "00",
    },
    {
      outinDvsnCd: "02",
      trStsCd: "19",
    },
    {
      outinDvsnCd: "02",
      trStsCd: "00",
    },
    {
      outinDvsnCd: "03",
      trStsCd: "00",
    },
  ])("cellStyle Test", async (param) => {
    const { findByText } = render(component)
    const cellStyleTestBtn = await findByText(/cellStyle Test/)

    fireEvent.click(cellStyleTestBtn, {
      target: {
        data: param,
      },
    })
  })

  it("onRowClicked Test", async () => {
    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: {} } })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })

  it("onRowDoubleClicked Test", async () => {
    const { findByText } = render(component)

    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, { target: { data: {} } })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("searchClick Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
        sumOut: {},
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
        sumOut: {},
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it.each(["01", "02", "03"])("getDisplayText Test", async (outinDvsnCd) => {
    const { findAllByTestId } = render(component)
    const onChangeTestBtn = await within(
      (
        await findAllByTestId(/SCRNITM#inOutBSort/)
      )[0],
    ).findByTestId("onChange")
    fireEvent.click(onChangeTestBtn, { target: { data: outinDvsnCd } })
  })

  it("ctrlEnter Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
        sumOut: {},
      },
    })
    const { container } = render(component)

    fireEvent.keyDown(container, { key: "Enter", ctrlKey: true, keyCode: 13 })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("validate Test", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(1).mockReturnValueOnce(0)
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(validateTestBtn, { target: { data: {} } })
  })
})
