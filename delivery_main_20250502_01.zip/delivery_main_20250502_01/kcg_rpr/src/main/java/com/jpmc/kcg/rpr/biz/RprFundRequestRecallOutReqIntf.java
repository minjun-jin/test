package com.jpmc.kcg.rpr.biz;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Service;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.SvcHourStsCdEnum;
import com.jpmc.kcg.com.enums.SvcTmDvsnCdEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.enums.TrmnlDvsnCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.hof.dao.HofTrLDao;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTransactionDaoIn;
import com.jpmc.kcg.hof.enums.HofConst;
import com.jpmc.kcg.ift.dao.IftTrLDao;
import com.jpmc.kcg.ift.dto.IftTrL;
import com.jpmc.kcg.ift.dto.SelectIftTransactionDaoIn;
import com.jpmc.kcg.rpr.biz.enums.RprAprvStsCdEnum;
import com.jpmc.kcg.rpr.biz.enums.RprConst;
import com.jpmc.kcg.rpr.biz.enums.RprRespCdEnum;
import com.jpmc.kcg.rpr.biz.vo.CqeRpr0200400000;
import com.jpmc.kcg.rpr.biz.vo.KftRpr0200400000;
import com.jpmc.kcg.rpr.dto.InsertRprTransactionIn;
import com.jpmc.kcg.rpr.dto.RprTrL;
import com.jpmc.kcg.rpr.dto.SelectRprTransactionIn;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * 자금반환요청 당발요청 (0200/400000)
 * LVB(HOST) -> KFTC(금융결제원)
 * param : CqeRpr0200400000
 * send  : KftRpr0200400000
 */
@Slf4j
@Service
public class RprFundRequestRecallOutReqIntf extends FrwServiceBean<CqeRpr0200400000> {

	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private RprCom rprCom;
	@Autowired
	private BizCom bizCom;
	@Autowired
	private BizDate bizDate;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private ReleaseValidation releaseValidation;
	@Autowired
	private IftTrLDao iftTrLDao;
	@Autowired
	private HofTrLDao hofTrLDao;
	@Autowired
	private FrwContext frwContext;
	@Override
	public boolean control(CqeRpr0200400000 in) {
		
		// 전문 format validation check
		if (in.validate() > 0) {
			String fieldNo = String.valueOf(in.validate());
			String errCd = StringUtils.leftPad(fieldNo, 3, ComConst.CHAR_0); // 000 ~ 필드번호가 응답코드로 리턴.
			throw new InternalResponseException(errCd);
		}
		
	    /* 1. 타행환 01 은 영업일만 처리가능 
	     * 	  전자금융 03 은 연중무휴 
	     * */
		if (ComConst.CHAR_1.equals(in.getWireType())) {
			 if (!bizDate.isWeekdayBizDay()) { //영업일(주말제외) 검증
		           throw new InternalResponseException(RprRespCdEnum.RESP_CD_312.getCode(), "영업일이 아닙니다.");
			 }
			 
				/*
				 * 2. 처리시간 체크
				 */
				// 서비스시간체크하여 거절응답을 반환한다.
				String svsHourCd = releaseValidation.getReleaseServiceHour(
						SvcTmDvsnCdEnum.RPR_INBOUND_SERVICE_HOUR.getValue(), LocalDateTime.now());
				if (SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode().equals(svsHourCd)) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_142.getCode(), "개설기관 개시 이전");
																											
				} else if (SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode().equals(svsHourCd)) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_143.getCode(), "개설기관 업무 종료");
				}

			} else if (ComConst.CHAR_3.equals(in.getWireType())) {
				/*
				 * 2. 처리시간 체크
				 */
				// 서비스시간체크하여 거절응답을 반환한다.
				String svsHourCd = releaseValidation.getReleaseServiceHour(
						SvcTmDvsnCdEnum.RPR_INBOUND_SERVICE_HOUR.getValue(), LocalDateTime.now());
				if (SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode().equals(svsHourCd)) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_142.getCode(), "개설기관 개시 이전");
				} else if (SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode().equals(svsHourCd)) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_143.getCode(), "개설기관 업무 종료");
				}
			}

		/*
		 * 3. 취급기관(반환기관) 개시상태 체크
		 */
//		boolean bnkStsCd = rprCom.validateBankConnectivityStatus(in.getBeneficiaryBankCode());
//		
//		if (!bnkStsCd) {
//			throw new InternalResponseException(RprRespCdEnum.RESP_CD_143.getCode(), "개설기관 업무 종료"); //개설기관 업무 종료
//		}
//		
		
		return super.control(in);
	}

	@Override
	public void process(CqeRpr0200400000 in) {
		
		log.debug("#@@# RprFundRequestRecallOutReqIntf CqeRpr0200400000 {}", in);

		// 1. 원거래 일자로부터 1일 이상 경과된 반환요청 여부 검증
		// 날짜 간의 차이를 일(day) 단위로 계산 원거래일자, 현재일자
		long daysBetween = ChronoUnit.DAYS.between(in.getOriginalDate(), LocalDate.now());

		if (daysBetween < 1) {
		    throw new InternalResponseException(RprRespCdEnum.RESP_CD_406.getCode(), "원거래 일자 이상");
		}
		
		KftRpr0200400000 kftIn = new KftRpr0200400000();
		String trcId = "";
		InsertRprTransactionIn insertIn = new InsertRprTransactionIn();
		
		kftIn = conversionService.convert(in, KftRpr0200400000.class);
		LocalDate originalDate = in.getOriginalDate();
		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
		kftIn.setOriginalTraxdate(DateUtils.formatDate(formatter, originalDate) ); //원거래일자

		// 2. 원거래 및 청구내역 존재여부 검증
		//FAX 반환은 원거래 및 청구내역 검증X
		if (!RprConst.N.equals(in.getOnlineRequestYn())) {
			RprTrL rprTrL  = _checkRequestTr(in);
			kftIn.setOriginalTransactionIDCode(rprTrL.getOrgnTrDvsnCd()); //원거래거래구분코드
			kftIn.setOriginalKFTCMsgNo(rprTrL.getOrgnTrUnqNo()); //원거래고유번호
			kftIn.setOriginalBeneficiaryAccountNumber(rprTrL.getOrgnRcvAcctNo()); //원거래수취계좌번호
			kftIn.setRequestDate(rprTrL.getRqstDt()); //청구일자
			kftIn.setRequestKFTCMsgNo(rprTrL.getRqstTrUnqNo()); //청구거래고유번호
			if (BigDecimal.valueOf(kftIn.getRequestReturnTraxAmount()).compareTo(rprTrL.getOrgnTrAmt()) == 0) {
				kftIn.setReturnInFullYn(RprConst.Y); // 전액반환여부 두 값이 같으면 Y
			} else if (BigDecimal.valueOf(kftIn.getRequestReturnTraxAmount()).compareTo(rprTrL.getOrgnTrAmt()) < 0) {
				kftIn.setReturnInFullYn(RprConst.N); // 전액반환여부 long 값이 BigDecimal 값보다 작으면 N
			}
			insertIn.setOrgnTrAmt(rprTrL.getOrgnTrAmt());
			insertIn.setOrgnTrUnqNo(rprTrL.getOrgnTrUnqNo());
		} else { //FAX반환
			kftIn.setOriginalTransactionIDCode(HofConst.TR_DVSN_400000); //원거래거래구분코드 HOFI 타행이체
			kftIn.setOriginalKFTCMsgNo(in.getTransactionIdNumber()); //원거래고유번호
			kftIn.setOriginalBeneficiaryAccountNumber(in.getBeneficiaryAccountNumber()); //원거래수취계좌번호
			kftIn.setRequestDate(in.getRequestDate()); //청구일자
			kftIn.setRequestKFTCMsgNo(""); //청구거래고유번호 space
			kftIn.setReturnInFullYn(frwContext.getTlgHdr().get("fullRtnYn")); //전액반환여부
			insertIn.setOrgnTrAmt(new BigDecimal(frwContext.getTlgHdr().get("orgnTrAmt")));
			insertIn.setOrgnTrUnqNo(in.getTransactionIdNumber());
		}
		kftIn.setOnlineRequestYn(in.getOnlineRequestYn()); //온라인청구여부
		kftIn.setReturnReasonCode(in.getReasonCode()); //청구반환사유코드
		kftIn.setReturnReason(in.getReason()); //청구반환사유
		kftIn.setReturnYn(in.getReturnYn()); //반환여부
		if (RprConst.Y.equals(in.getReturnYn())) { //반환여부 Y이면 반환거부사유코드 기본값
		} else { //반환여부 N이면 KcgRpr0200400000에 사유(코드)에 반환거절(거부)사유(코드)가 들어있음
			kftIn.setReturnRejectReasonCode(in.getReasonCode()); //반환거부사유코드
			kftIn.setReturnRejectReason(in.getReason()); //반환거부사유
		}
		kftIn.setRequestReturnTraxAmount(in.getAmount()); //거래금액
        String msgTrcNumber = StringUtils.repeat(RprConst.CHAR_ZERO, 8);
		if (ComConst.CHAR_3.equals(in.getWireType())) { //공동망종류3 HOF
			kftIn.setWireType(RprConst.KFTC_BIZ_DVSN_CD_03);
			msgTrcNumber = bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKFT01.toString());
			insertIn.setHostCd(ComConst.KCG);
			insertIn.setTrmnlDvsnCd(TrmnlDvsnCdEnum.UI.getCode());
			/*
			 * HOFI 당발반환 거래 시 maker, chekcer 정보가 web Svc에서 insert되지 않아
			 * rpr 서비스에서 insert 
			 */
			insertIn.setMakeId(frwContext.getTlgHdr().get("makeId"));
			insertIn.setMakeDttm(frwContext.getTlgHdr().get("makeDttm"));
			insertIn.setChkId(frwContext.getTlgHdr().get("chkId"));
			insertIn.setChkDttm(frwContext.getTlgHdr().get("chkDttm"));
			insertIn.setAprvStsCd(RprAprvStsCdEnum.APPROVED.getValue());
			
        } else { //공동망구분1
        	kftIn.setWireType(RprConst.KFTC_BIZ_DVSN_CD_01);
        	msgTrcNumber = bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRCQE01.toString());
			insertIn.setHostCd(ComConst.CQE);
			insertIn.setTrmnlDvsnCd(TrmnlDvsnCdEnum.CQE.getCode());
		}
		
		String trSeq = bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKCG01.toString()); 
		kftIn.setTransactionIdNumber(ComConst.JPMC_BANK_CD + trSeq); //거래고유번호 13자리 : 057 + 10자리
		kftIn.setMessageTrackingNumber(msgTrcNumber); // 8자리
		log.debug("#@@# trSeq {}", trSeq);
		log.debug("#@@# msgTrcNumber {}", msgTrcNumber);
    	// KFTC QUEUE에 송신 
    	log.debug("#@@# frwTemplate.send kftIn {}", kftIn);
    	trcId = frwTemplate.send(FrwDestination.KFT_RPR, kftIn);
    	
    	// 4. 거래내역 생성
    	insertIn = _setInsertRprTrL(insertIn, in, kftIn, trcId, msgTrcNumber);
        log.debug("#@@# rprTrL insertIn {}", insertIn);
		rprCom.insertRPRTransaction(insertIn);
		
	}

	@Override
	public void handleError(CqeRpr0200400000 in, Throwable t) {
		
		String respCd;
		String instErrMsg = "";
	
		if (t instanceof InternalResponseException e) {
			respCd = e.getRespCd();
			instErrMsg = e.getRespMessage();
		} else {
			respCd = RprRespCdEnum.RESP_CD_312.getCode(); /* 기타에러 */
			log.info(t.getStackTrace().toString());
		}
		
		InsertRprTransactionIn insertIn = new InsertRprTransactionIn();
		if(in.getMsgType().contains("CQE")) {
			in.setMsgType(RprConst.KCGCQE);
			if (respCd.startsWith(ComConst.CHAR_0)) {
				in.setMessageType(RprConst.TLG_KND_DVSN_NO_9200);
				in.setResponseCode(respCd);
				String trcId = frwTemplate.send(FrwDestination.CQE_RPR, in);
				insertIn.setTlgKndDvsnCd(RprConst.TLG_KND_DVSN_NO_9200);
				insertIn.setTrcId(trcId);
			}else {
				in.setResponseCode(respCd);
				in.setMessageType(RprConst.TLG_KND_DVSN_NO_0210);
				String trcId = frwTemplate.send(FrwDestination.CQE_RPR, in);
				insertIn.setTlgKndDvsnCd(RprConst.TLG_KND_DVSN_NO_0210);
				insertIn.setTrcId(trcId);
			}
		}
		String trSeq = ComConst.JPMC_BANK_CD + bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKCG01.toString());
		String rprTlgTrceNo = bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKFT01.toString());
		insertIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_01);
		insertIn.setTlgKndDvsnCd(in.getMessageType());
		insertIn.setTlgTrDvsnCd(in.getMessageCode());
		insertIn.setRqstRtnDvsnCd(RprConst.RQST_RTN_DVSN_CD_02);//반환
		insertIn.setTrDt(in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));
		insertIn.setTrUnqNo(trSeq);
		insertIn.setRprTlgTrceNo(rprTlgTrceNo);
		insertIn.setHostNo(in.getOriginalMsgNo());
		insertIn.setAprvStsCd(RprAprvStsCdEnum.APPROVED.getValue());
		insertIn.setTrStsCd(TrStsCdEnum.RECALL_REJECTION.getTrStsCd());
		insertIn.setRespCd(respCd);
		insertIn.setInstErrMsg(instErrMsg);
		if (ComConst.CHAR_3.equals(in.getWireType())) {
			insertIn.setKftcBizDvsnCd(RprConst.KFTC_BIZ_DVSN_CD_03);
			insertIn.setHostCd(ComConst.KCG);
			insertIn.setTrmnlDvsnCd(TrmnlDvsnCdEnum.UI.getCode());
			insertIn.setMakeId(frwContext.getTlgHdr().get("makeId"));
			insertIn.setMakeDttm(frwContext.getTlgHdr().get("makeDttm"));
			insertIn.setChkId(frwContext.getTlgHdr().get("chkId"));
			insertIn.setChkDttm(frwContext.getTlgHdr().get("chkDttm"));
			insertIn.setAprvStsCd(RprAprvStsCdEnum.APPROVED.getValue());
		} else {
			insertIn.setKftcBizDvsnCd(RprConst.KFTC_BIZ_DVSN_CD_01);
			insertIn.setHostCd(ComConst.CQE);
			insertIn.setTrmnlDvsnCd(TrmnlDvsnCdEnum.CQE.getCode());
		}
		rprCom.insertRPRTransaction(insertIn);
	}

	/**
	 * 30일 이내 청구내역 존재여부 검증(온라인청구여부 필드가 Y일때만 검증)
	 * @param in
	 * @Param today
	 * @return
	 */
	public RprTrL _checkRequestTr(CqeRpr0200400000 in) {
		
		if (ComConst.CHAR_3.equals(in.getWireType())) { // 공동망종류3 HOF

			SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
			hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
			hofDaoIn.setTrDt(in.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
			hofDaoIn.setTrUnqNo(in.getTransactionIdNumber());
			hofDaoIn.setHostNo(in.getOriginalMsgNo());
			HofTrL hofTrL = hofTrLDao.selectHofTransaction(hofDaoIn);
			if (hofTrL == null) {
				throw new InternalResponseException(RprRespCdEnum.RESP_CD_312.getCode(), "원거래 없음");
			} else {
				SelectRprTransactionIn selectIn = new SelectRprTransactionIn();
				selectIn.setTrDt(in.getRequestDate());
				selectIn.setOrgnTrUnqNo(in.getTransactionIdNumber());
				selectIn.setTlgKndDvsnCd(RprConst.TLG_KND_DVSN_NO_0210);
				selectIn.setTlgTrDvsnCd(RprConst.TLG_TR_DVSN_NO_300000);
				selectIn.setRespCd(RprRespCdEnum.RESP_CD_000.getCode());
				RprTrL requestRprTr = rprCom.selectRPRTransaction(selectIn);
				if (requestRprTr == null) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_312.getCode(), "청구거래 조회실패");
				}
				return requestRprTr;
			}

		} else { // 공동망구분1 IFT

			/*
			 * 타발 자금청구접수 응답 0210 / 300000 응답코드 정상 000인 내역 조회
			 */
			SelectIftTransactionDaoIn iftDaoIn = new SelectIftTransactionDaoIn();
			iftDaoIn.setTrDt(in.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
			iftDaoIn.setHostNo(in.getOriginalMsgNo());
			IftTrL iftTrL = iftTrLDao.selectIftTransaction(iftDaoIn);
			if (iftTrL == null) {
				throw new InternalResponseException(RprRespCdEnum.RESP_CD_312.getCode(), "원거래 없음");
			} else {
				SelectRprTransactionIn selectIn = new SelectRprTransactionIn();
				selectIn.setTrDt(in.getRequestDate());
				selectIn.setOrgnTrUnqNo(iftTrL.getHndlBnkCd() + iftTrL.getHndlBnkTlgNo());
				selectIn.setTlgKndDvsnCd(RprConst.TLG_KND_DVSN_NO_0210);
				selectIn.setTlgTrDvsnCd(RprConst.TLG_TR_DVSN_NO_300000);
				selectIn.setRespCd(RprRespCdEnum.RESP_CD_000.getCode());
				RprTrL requestRprTr = rprCom.selectRPRTransaction(selectIn);
				if (requestRprTr == null) {
					throw new InternalResponseException(RprRespCdEnum.RESP_CD_312.getCode(), "청구거래 조회실패");
				}
				return requestRprTr;
			}
		}

	}

	/**
	 * RPR_TR_L 거래내역 생성
	 */
	public InsertRprTransactionIn _setInsertRprTrL(InsertRprTransactionIn insertIn, CqeRpr0200400000 in, KftRpr0200400000 kftIn, String trcId, String msgTrcNumber) {
        log.debug("#@@# _setInsertRprTrL CqeRpr0200400000{}", in);
		DateTimeFormatter formatter = DateTimeFormatter.BASIC_ISO_DATE;
		insertIn.setTrDt(DateUtils.formatDate(formatter, in.getMessageTransmissionDate()));
		insertIn.setTrUnqNo(kftIn.getTransactionIdNumber()); //trSeq채번값 13자리
		insertIn.setHostNo(msgTrcNumber); //msgTrcNumber 8자리
		insertIn.setRprTlgTrceNo(msgTrcNumber); //msgTrcNumber 8자리
		insertIn.setTlgKndDvsnCd(RprConst.TLG_KND_DVSN_NO_0200);
		insertIn.setTlgTrDvsnCd(RprConst.TLG_TR_DVSN_NO_400000);
		insertIn.setRqstRtnDvsnCd(RprConst.RQST_RTN_DVSN_CD_02);//반환
		insertIn.setTrStsCd(TrStsCdEnum.RECALL_IN_PROGRESS.getTrStsCd()); //자금반환중
		insertIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_01); //당발
		insertIn.setRqstRtnTrAmt(new BigDecimal(in.getAmount()));
		insertIn.setRtnRsnCd(in.getReasonCode()); //반환사유코드
		insertIn.setRtnRsn(in.getReason()); //반환사유
		insertIn.setMgrTelNo(in.getEmployeeContact()); //담당자연락처
		insertIn.setOpnBnkCd(kftIn.getBeneficiaryBankCode()); //개설은행, 수취은행
		insertIn.setOpnBnkBrnchCd(kftIn.getBeneficiaryBranchCode().substring(3)); //개설지점코드
		insertIn.setKftcBizDvsnCd(kftIn.getWireType()); //공동망종류
		insertIn.setOrgnTrDt(in.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));//원거래일자
		insertIn.setOrgnTrDvsnCd(kftIn.getOriginalTransactionIDCode()); //원거래거래구분코드
		insertIn.setOrgnRcvAcctNo(kftIn.getOriginalBeneficiaryAccountNumber()); //원거래수취계좌번호
		insertIn.setOnlineRqstYn(kftIn.getOnlineRequestYn()); //온라인청구여부
		insertIn.setRqstDt(kftIn.getRequestDate()); //청구일자
		insertIn.setRqstTrUnqNo(kftIn.getRequestKFTCMsgNo()); //청구거래고유번호
		insertIn.setRtnYn(kftIn.getReturnYn()); //반환여부
		insertIn.setRtnRjctRsnCd(kftIn.getReturnRejectReasonCode()); //반환거부사유코드
		insertIn.setRtnRjctRsn(kftIn.getReturnRejectReason()); //반환거부사유
		insertIn.setFullRtnYn(kftIn.getReturnInFullYn()); //전액반환여부
		insertIn.setTrcId(trcId);
		
		LocalTime currentTime = LocalTime.now();
		insertIn.setRqstTm(kftIn.getMessageSendTime() != null ? kftIn.getMessageSendTime() : currentTime);
		insertIn.setRespTm(kftIn.getMessageSendTime() != null ? kftIn.getMessageSendTime() : currentTime);
		insertIn.setKftcTlgTm(kftIn.getMessageSendTime() != null ? kftIn.getMessageSendTime() : currentTime);
		return insertIn;
	}

}
