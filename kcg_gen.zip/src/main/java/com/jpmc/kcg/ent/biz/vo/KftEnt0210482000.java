package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 소지인 어음번호별 어음정보 조회 응답 C
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 전자어음시스템을 구분하기 위해'EBS'사용
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0210
 * messageTrackingNumber 전문추적번호 482000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * residentBusinessNumber 주민사업자번호 
 * eNoteNumber 전자어음번호 
 * splitNumber 분할번호 
 * endorsementNumber 배서번호 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * noteInfoEnoteNumber 어음정보-전자어음번호 
 * noteInfoEnoteType 어음정보-전자어음종류 
 * noteInfoEnoteProcessStatus 어음정보-전자어음처리상태 
 * noteInfoEnoteIssueDate 어음정보-전자어음발행일자 
 * noteInfoEnoteIssuePlace 어음정보-전자어음발행지 
 * noteInfoEnoteAmount 어음정보-전자어음금액 
 * noteInfoDefaultReasonCode 어음정보-부도사유코드 
 * noteInfoEnoteMaturedDate 어음정보-전자어음만기일자 
 * noteInfoEnoteDefaultProcessingDate 어음정보-전자어음부도처리일자 
 * noteInfoEnoteFinalPaymentDate 어음정보-전자어음최종결제일자 
 * noteInfopaymentBankBranchCode 어음정보-지급은행및지점코드 
 * noteInfoEndorsementCount 어음정보-배서횟수 
 * noteInfoInstructionProhibited 어음정보-지시금지여부 
 * issuerIndvCorpSort 발행인-개인법인구분 
 * issuerResidentBusinessNumber 발행인-주민사업자번호 
 * issuerCorpName 발행인-법인명 
 * issuerNameRepresentativeName 발행인-성명(대표자명) 
 * issuerAddress 발행인-주소 
 * issuerCurrentAccountNumber 발행인-당좌계좌번호 
 * issuerGuaranteePresence 발행인-발행보증여부 
 * issuanceGuaranteeInfoAssuredIndvCorpSort 발행보증정보-(피보증인)개인법인구분 
 * issuanceGuaranteeInfoAssuredResidentBusinessNumber 발행보증정보-(피보증인)주민사업자번호 
 * issuanceGuaranteeInfoAssuredCorpName 발행보증정보-(피보증인)법인명 
 * issuanceGuaranteeInfoAssuredNameRepresentative 발행보증정보-(피보증인)성명(대표자명) 
 * issuanceGuaranteeInfoAssuredAddress 발행보증정보-(피보증인)주소 
 * issuanceGuaranteeInfoAssuredBankCode 발행보증정보-(피보증인)은행코드 
 * issuanceGuaranteeInfoAssuredCurrentAccountNumber 발행보증정보-(피보증인)당좌계좌번호 
 * issuanceGuaranteeInfoGuarantorIndvCorpSort 발행보증정보-(보증인)개인법인구분 
 * issuanceGuaranteeInfoGuarantorResidentBusinessNumber 발행보증정보-(보증인)주민사업자번호 
 * issuanceGuaranteeInfoGuarantorCorpName 발행보증정보-(보증인)법인명 
 * issuanceGuaranteeInfoGuarantorNameRepresentative 발행보증정보-(보증인)성명(대표자명) 
 * issuanceGuaranteeInfoGuarantorAddress 발행보증정보-(보증인)주소 
 * issuanceGuaranteeInfoGuarantorBankCode 발행보증정보-(보증인)은행코드 
 * issuanceGuaranteeInfoGuarantorDepositAccountNumber 발행보증정보-(보증인)입금계좌번호 
 * issuanceGuaranteeInfoGuaranteeTargetSplitNumber 발행보증정보-보증대상분할번호 
 * issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber 발행보증정보-보증대상배서번호 
 * issuanceGuaranteeInfoGuaranteeNumber 발행보증정보-보증번호 
 * queryResultArray 조회결과Array 
 * queryResultArray.endorsementInfoIndvCorpSort (조회결과)배서정보-개인법인구분 
 * queryResultArray.endorsementInfoResidentBusinessNumber (조회결과)배서정보-주민사업자번호 
 * queryResultArray.endorsementInfoCorpName (조회결과)배서정보-법인명 
 * queryResultArray.endorsementInfoNameRepresentative (조회결과)배서정보-성명(대표자명) 
 * queryResultArray.endorsementInfoAddress (조회결과)배서정보-주소 
 * queryResultArray.endorsementInfoBankCode (조회결과)배서정보-은행코드 
 * queryResultArray.endorsementInfoDepositAccountNumber (조회결과)배서정보-입금계좌번호 
 * queryResultArray.endorsementInfoSplitNumber (조회결과)배서정보-분할번호 
 * queryResultArray.endorsementInfoEndorsementNumber (조회결과)배서정보-배서번호 
 * queryResultArray.endorsementInfoEndorsementDate (조회결과)배서정보-배서일자 
 * queryResultArray.endorsementInfoEndorsementAmount (조회결과)배서정보-배서금액 
 * queryResultArray.endorsementInfoNonCollateralEndorsement (조회결과)배서정보-무담보배서여부 
 * queryResultArray.endorsementInfoProhibitedEndorsement (조회결과)배서정보-배서금지배서여부 
 * queryResultArray.endorsementInfoGuaranteeEndorsement (조회결과)배서정보-배서보증여부 
 * queryResultArray.endorsementInfoDefaultNoteReturn (조회결과)배서정보-부도어음반환여부 
 * queryResultArray.endorsementInfoPostmaturedEndorsement (조회결과)배서정보-기한후배서여부 
 * 
 * KftEnt0210482000 kftEnt0210482000 = new KftEnt0210482000(); // 소지인 어음번호별 어음정보 조회 응답 C
 * kftEnt0210482000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210482000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210482000.setBnkCd("057"); // 은행코드
 * kftEnt0210482000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210482000.setTransactionCode("482000"); // 거래구분코드
 * kftEnt0210482000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210482000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210482000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210482000.setStatus("000"); // STATUS
 * kftEnt0210482000.setResponseCode1(""); // 응답코드1
 * kftEnt0210482000.setResponseCode2(""); // 응답코드2
 * kftEnt0210482000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210482000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210482000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0210482000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210482000.setSplitNumber(""); // 분할번호
 * kftEnt0210482000.setEndorsementNumber(""); // 배서번호
 * kftEnt0210482000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0210482000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0210482000.setCurrentCount(0); // 현재건수
 * kftEnt0210482000.setNoteInfoEnoteNumber(""); // 어음정보-전자어음번호
 * kftEnt0210482000.setNoteInfoEnoteType(""); // 어음정보-전자어음종류
 * kftEnt0210482000.setNoteInfoEnoteProcessStatus(""); // 어음정보-전자어음처리상태
 * kftEnt0210482000.setNoteInfoEnoteIssueDate(""); // 어음정보-전자어음발행일자
 * kftEnt0210482000.setNoteInfoEnoteIssuePlace(""); // 어음정보-전자어음발행지
 * kftEnt0210482000.setNoteInfoEnoteAmount(0L); // 어음정보-전자어음금액
 * kftEnt0210482000.setNoteInfoDefaultReasonCode(""); // 어음정보-부도사유코드
 * kftEnt0210482000.setNoteInfoEnoteMaturedDate(""); // 어음정보-전자어음만기일자
 * kftEnt0210482000.setNoteInfoEnoteDefaultProcessingDate(""); // 어음정보-전자어음부도처리일자
 * kftEnt0210482000.setNoteInfoEnoteFinalPaymentDate(""); // 어음정보-전자어음최종결제일자
 * kftEnt0210482000.setNoteInfopaymentBankBranchCode(""); // 어음정보-지급은행및지점코드
 * kftEnt0210482000.setNoteInfoEndorsementCount(0); // 어음정보-배서횟수
 * kftEnt0210482000.setNoteInfoInstructionProhibited(""); // 어음정보-지시금지여부
 * kftEnt0210482000.setIssuerIndvCorpSort(""); // 발행인-개인법인구분
 * kftEnt0210482000.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEnt0210482000.setIssuerCorpName(""); // 발행인-법인명
 * kftEnt0210482000.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEnt0210482000.setIssuerAddress(""); // 발행인-주소
 * kftEnt0210482000.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEnt0210482000.setIssuerGuaranteePresence(""); // 발행인-발행보증여부
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredIndvCorpSort(""); // 발행보증정보-(피보증인)개인법인구분
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredResidentBusinessNumber(""); // 발행보증정보-(피보증인)주민사업자번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredCorpName(""); // 발행보증정보-(피보증인)법인명
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredNameRepresentative(""); // 발행보증정보-(피보증인)성명(대표자명)
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredAddress(""); // 발행보증정보-(피보증인)주소
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredBankCode(""); // 발행보증정보-(피보증인)은행코드
 * kftEnt0210482000.setIssuanceGuaranteeInfoAssuredCurrentAccountNumber(""); // 발행보증정보-(피보증인)당좌계좌번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorIndvCorpSort(""); // 발행보증정보-(보증인)개인법인구분
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorResidentBusinessNumber(""); // 발행보증정보-(보증인)주민사업자번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorCorpName(""); // 발행보증정보-(보증인)법인명
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorNameRepresentative(""); // 발행보증정보-(보증인)성명(대표자명)
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorAddress(""); // 발행보증정보-(보증인)주소
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorBankCode(""); // 발행보증정보-(보증인)은행코드
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuarantorDepositAccountNumber(""); // 발행보증정보-(보증인)입금계좌번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuaranteeTargetSplitNumber(""); // 발행보증정보-보증대상분할번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuaranteeTargetEndorsementNumber(""); // 발행보증정보-보증대상배서번호
 * kftEnt0210482000.setIssuanceGuaranteeInfoGuaranteeNumber(""); // 발행보증정보-보증번호
 * KftEnt0210482000.QueryResult queryResult = new KftEnt0210482000.QueryResult(); // 조회결과Array
 * queryResult.setEndorsementInfoIndvCorpSort(""); // (조회결과)배서정보-개인법인구분
 * queryResult.setEndorsementInfoResidentBusinessNumber(""); // (조회결과)배서정보-주민사업자번호
 * queryResult.setEndorsementInfoCorpName(""); // (조회결과)배서정보-법인명
 * queryResult.setEndorsementInfoNameRepresentative(""); // (조회결과)배서정보-성명(대표자명)
 * queryResult.setEndorsementInfoAddress(""); // (조회결과)배서정보-주소
 * queryResult.setEndorsementInfoBankCode(""); // (조회결과)배서정보-은행코드
 * queryResult.setEndorsementInfoDepositAccountNumber(""); // (조회결과)배서정보-입금계좌번호
 * queryResult.setEndorsementInfoSplitNumber(""); // (조회결과)배서정보-분할번호
 * queryResult.setEndorsementInfoEndorsementNumber(""); // (조회결과)배서정보-배서번호
 * queryResult.setEndorsementInfoEndorsementDate(""); // (조회결과)배서정보-배서일자
 * queryResult.setEndorsementInfoEndorsementAmount(0L); // (조회결과)배서정보-배서금액
 * queryResult.setEndorsementInfoNonCollateralEndorsement(""); // (조회결과)배서정보-무담보배서여부
 * queryResult.setEndorsementInfoProhibitedEndorsement(""); // (조회결과)배서정보-배서금지배서여부
 * queryResult.setEndorsementInfoGuaranteeEndorsement(""); // (조회결과)배서정보-배서보증여부
 * queryResult.setEndorsementInfoDefaultNoteReturn(""); // (조회결과)배서정보-부도어음반환여부
 * queryResult.setEndorsementInfoPostmaturedEndorsement(""); // (조회결과)배서정보-기한후배서여부
 * kftEnt0210482000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0210482000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * endorsementInfoIndvCorpSort (조회결과)배서정보-개인법인구분 
	 * endorsementInfoResidentBusinessNumber (조회결과)배서정보-주민사업자번호 
	 * endorsementInfoCorpName (조회결과)배서정보-법인명 
	 * endorsementInfoNameRepresentative (조회결과)배서정보-성명(대표자명) 
	 * endorsementInfoAddress (조회결과)배서정보-주소 
	 * endorsementInfoBankCode (조회결과)배서정보-은행코드 
	 * endorsementInfoDepositAccountNumber (조회결과)배서정보-입금계좌번호 
	 * endorsementInfoSplitNumber (조회결과)배서정보-분할번호 
	 * endorsementInfoEndorsementNumber (조회결과)배서정보-배서번호 
	 * endorsementInfoEndorsementDate (조회결과)배서정보-배서일자 
	 * endorsementInfoEndorsementAmount (조회결과)배서정보-배서금액 
	 * endorsementInfoNonCollateralEndorsement (조회결과)배서정보-무담보배서여부 
	 * endorsementInfoProhibitedEndorsement (조회결과)배서정보-배서금지배서여부 
	 * endorsementInfoGuaranteeEndorsement (조회결과)배서정보-배서보증여부 
	 * endorsementInfoDefaultNoteReturn (조회결과)배서정보-부도어음반환여부 
	 * endorsementInfoPostmaturedEndorsement (조회결과)배서정보-기한후배서여부 
	 * 
	 * KftEnt0210482000.QueryResult queryResult = new KftEnt0210482000.QueryResult(); // 조회결과Array
	 * queryResult.setEndorsementInfoIndvCorpSort(""); // (조회결과)배서정보-개인법인구분
	 * queryResult.setEndorsementInfoResidentBusinessNumber(""); // (조회결과)배서정보-주민사업자번호
	 * queryResult.setEndorsementInfoCorpName(""); // (조회결과)배서정보-법인명
	 * queryResult.setEndorsementInfoNameRepresentative(""); // (조회결과)배서정보-성명(대표자명)
	 * queryResult.setEndorsementInfoAddress(""); // (조회결과)배서정보-주소
	 * queryResult.setEndorsementInfoBankCode(""); // (조회결과)배서정보-은행코드
	 * queryResult.setEndorsementInfoDepositAccountNumber(""); // (조회결과)배서정보-입금계좌번호
	 * queryResult.setEndorsementInfoSplitNumber(""); // (조회결과)배서정보-분할번호
	 * queryResult.setEndorsementInfoEndorsementNumber(""); // (조회결과)배서정보-배서번호
	 * queryResult.setEndorsementInfoEndorsementDate(""); // (조회결과)배서정보-배서일자
	 * queryResult.setEndorsementInfoEndorsementAmount(0L); // (조회결과)배서정보-배서금액
	 * queryResult.setEndorsementInfoNonCollateralEndorsement(""); // (조회결과)배서정보-무담보배서여부
	 * queryResult.setEndorsementInfoProhibitedEndorsement(""); // (조회결과)배서정보-배서금지배서여부
	 * queryResult.setEndorsementInfoGuaranteeEndorsement(""); // (조회결과)배서정보-배서보증여부
	 * queryResult.setEndorsementInfoDefaultNoteReturn(""); // (조회결과)배서정보-부도어음반환여부
	 * queryResult.setEndorsementInfoPostmaturedEndorsement(""); // (조회결과)배서정보-기한후배서여부
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String endorsementInfoIndvCorpSort; // (조회결과)배서정보-개인법인구분
		private String endorsementInfoResidentBusinessNumber; // (조회결과)배서정보-주민사업자번호
		private String endorsementInfoCorpName; // (조회결과)배서정보-법인명
		private String endorsementInfoNameRepresentative; // (조회결과)배서정보-성명(대표자명)
		private String endorsementInfoAddress; // (조회결과)배서정보-주소
		private String endorsementInfoBankCode; // (조회결과)배서정보-은행코드
		private String endorsementInfoDepositAccountNumber; // (조회결과)배서정보-입금계좌번호
		private String endorsementInfoSplitNumber; // (조회결과)배서정보-분할번호
		private String endorsementInfoEndorsementNumber; // (조회결과)배서정보-배서번호
		private String endorsementInfoEndorsementDate; // (조회결과)배서정보-배서일자
		private long endorsementInfoEndorsementAmount; // (조회결과)배서정보-배서금액
		private String endorsementInfoNonCollateralEndorsement; // (조회결과)배서정보-무담보배서여부
		private String endorsementInfoProhibitedEndorsement; // (조회결과)배서정보-배서금지배서여부
		private String endorsementInfoGuaranteeEndorsement; // (조회결과)배서정보-배서보증여부
		private String endorsementInfoDefaultNoteReturn; // (조회결과)배서정보-부도어음반환여부
		private String endorsementInfoPostmaturedEndorsement; // (조회결과)배서정보-기한후배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoIndvCorpSort$; // (조회결과)배서정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoResidentBusinessNumber$; // (조회결과)배서정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoCorpName$; // (조회결과)배서정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoNameRepresentative$; // (조회결과)배서정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoAddress$; // (조회결과)배서정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoBankCode$; // (조회결과)배서정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoDepositAccountNumber$; // (조회결과)배서정보-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoSplitNumber$; // (조회결과)배서정보-분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementNumber$; // (조회결과)배서정보-배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementDate$; // (조회결과)배서정보-배서일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementAmount$; // (조회결과)배서정보-배서금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoNonCollateralEndorsement$; // (조회결과)배서정보-무담보배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoProhibitedEndorsement$; // (조회결과)배서정보-배서금지배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoGuaranteeEndorsement$; // (조회결과)배서정보-배서보증여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoDefaultNoteReturn$; // (조회결과)배서정보-부도어음반환여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoPostmaturedEndorsement$; // (조회결과)배서정보-기한후배서여부

		@Override
		public void write(OutputStream out) throws IOException {
			endorsementInfoIndvCorpSort$ = VOUtils.write(out, endorsementInfoIndvCorpSort, 1); // (조회결과)배서정보-개인법인구분
			endorsementInfoResidentBusinessNumber$ = VOUtils.write(out, endorsementInfoResidentBusinessNumber, 13); // (조회결과)배서정보-주민사업자번호
			endorsementInfoCorpName$ = VOUtils.write(out, endorsementInfoCorpName, 40, "EUC-KR"); // (조회결과)배서정보-법인명
			endorsementInfoNameRepresentative$ = VOUtils.write(out, endorsementInfoNameRepresentative, 20, "EUC-KR"); // (조회결과)배서정보-성명(대표자명)
			endorsementInfoAddress$ = VOUtils.write(out, endorsementInfoAddress, 60, "EUC-KR"); // (조회결과)배서정보-주소
			endorsementInfoBankCode$ = VOUtils.write(out, endorsementInfoBankCode, 3); // (조회결과)배서정보-은행코드
			endorsementInfoDepositAccountNumber$ = VOUtils.write(out, endorsementInfoDepositAccountNumber, 16); // (조회결과)배서정보-입금계좌번호
			endorsementInfoSplitNumber$ = VOUtils.write(out, endorsementInfoSplitNumber, 2); // (조회결과)배서정보-분할번호
			endorsementInfoEndorsementNumber$ = VOUtils.write(out, endorsementInfoEndorsementNumber, 2); // (조회결과)배서정보-배서번호
			endorsementInfoEndorsementDate$ = VOUtils.write(out, endorsementInfoEndorsementDate, 8); // (조회결과)배서정보-배서일자
			endorsementInfoEndorsementAmount$ = VOUtils.write(out, endorsementInfoEndorsementAmount, 15); // (조회결과)배서정보-배서금액
			endorsementInfoNonCollateralEndorsement$ = VOUtils.write(out, endorsementInfoNonCollateralEndorsement, 1); // (조회결과)배서정보-무담보배서여부
			endorsementInfoProhibitedEndorsement$ = VOUtils.write(out, endorsementInfoProhibitedEndorsement, 1); // (조회결과)배서정보-배서금지배서여부
			endorsementInfoGuaranteeEndorsement$ = VOUtils.write(out, endorsementInfoGuaranteeEndorsement, 1); // (조회결과)배서정보-배서보증여부
			endorsementInfoDefaultNoteReturn$ = VOUtils.write(out, endorsementInfoDefaultNoteReturn, 1); // (조회결과)배서정보-부도어음반환여부
			endorsementInfoPostmaturedEndorsement$ = VOUtils.write(out, endorsementInfoPostmaturedEndorsement, 1); // (조회결과)배서정보-기한후배서여부
		}

		@Override
		public void read(InputStream in) throws IOException {
			endorsementInfoIndvCorpSort = VOUtils.toString(endorsementInfoIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)배서정보-개인법인구분
			endorsementInfoResidentBusinessNumber = VOUtils.toString(endorsementInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)배서정보-주민사업자번호
			endorsementInfoCorpName = VOUtils.toString(endorsementInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)배서정보-법인명
			endorsementInfoNameRepresentative = VOUtils.toString(endorsementInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)배서정보-성명(대표자명)
			endorsementInfoAddress = VOUtils.toString(endorsementInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)배서정보-주소
			endorsementInfoBankCode = VOUtils.toString(endorsementInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)배서정보-은행코드
			endorsementInfoDepositAccountNumber = VOUtils.toString(endorsementInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)배서정보-입금계좌번호
			endorsementInfoSplitNumber = VOUtils.toString(endorsementInfoSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)배서정보-분할번호
			endorsementInfoEndorsementNumber = VOUtils.toString(endorsementInfoEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)배서정보-배서번호
			endorsementInfoEndorsementDate = VOUtils.toString(endorsementInfoEndorsementDate$ = VOUtils.read(in, 8)); // (조회결과)배서정보-배서일자
			endorsementInfoEndorsementAmount = VOUtils.toLong(endorsementInfoEndorsementAmount$ = VOUtils.read(in, 15)); // (조회결과)배서정보-배서금액
			endorsementInfoNonCollateralEndorsement = VOUtils.toString(endorsementInfoNonCollateralEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-무담보배서여부
			endorsementInfoProhibitedEndorsement = VOUtils.toString(endorsementInfoProhibitedEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-배서금지배서여부
			endorsementInfoGuaranteeEndorsement = VOUtils.toString(endorsementInfoGuaranteeEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-배서보증여부
			endorsementInfoDefaultNoteReturn = VOUtils.toString(endorsementInfoDefaultNoteReturn$ = VOUtils.read(in, 1)); // (조회결과)배서정보-부도어음반환여부
			endorsementInfoPostmaturedEndorsement = VOUtils.toString(endorsementInfoPostmaturedEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-기한후배서여부
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", endorsementInfoIndvCorpSort=").append(endorsementInfoIndvCorpSort).append(System.lineSeparator()); // (조회결과)배서정보-개인법인구분
			sb.append(", endorsementInfoResidentBusinessNumber=").append(endorsementInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)배서정보-주민사업자번호
			sb.append(", endorsementInfoCorpName=").append(endorsementInfoCorpName).append(System.lineSeparator()); // (조회결과)배서정보-법인명
			sb.append(", endorsementInfoNameRepresentative=").append(endorsementInfoNameRepresentative).append(System.lineSeparator()); // (조회결과)배서정보-성명(대표자명)
			sb.append(", endorsementInfoAddress=").append(endorsementInfoAddress).append(System.lineSeparator()); // (조회결과)배서정보-주소
			sb.append(", endorsementInfoBankCode=").append(endorsementInfoBankCode).append(System.lineSeparator()); // (조회결과)배서정보-은행코드
			sb.append(", endorsementInfoDepositAccountNumber=").append(endorsementInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)배서정보-입금계좌번호
			sb.append(", endorsementInfoSplitNumber=").append(endorsementInfoSplitNumber).append(System.lineSeparator()); // (조회결과)배서정보-분할번호
			sb.append(", endorsementInfoEndorsementNumber=").append(endorsementInfoEndorsementNumber).append(System.lineSeparator()); // (조회결과)배서정보-배서번호
			sb.append(", endorsementInfoEndorsementDate=").append(endorsementInfoEndorsementDate).append(System.lineSeparator()); // (조회결과)배서정보-배서일자
			sb.append(", endorsementInfoEndorsementAmount=").append(endorsementInfoEndorsementAmount).append(System.lineSeparator()); // (조회결과)배서정보-배서금액
			sb.append(", endorsementInfoNonCollateralEndorsement=").append(endorsementInfoNonCollateralEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-무담보배서여부
			sb.append(", endorsementInfoProhibitedEndorsement=").append(endorsementInfoProhibitedEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-배서금지배서여부
			sb.append(", endorsementInfoGuaranteeEndorsement=").append(endorsementInfoGuaranteeEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-배서보증여부
			sb.append(", endorsementInfoDefaultNoteReturn=").append(endorsementInfoDefaultNoteReturn).append(System.lineSeparator()); // (조회결과)배서정보-부도어음반환여부
			sb.append(", endorsementInfoPostmaturedEndorsement=").append(endorsementInfoPostmaturedEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-기한후배서여부
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "482000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String residentBusinessNumber; // 주민사업자번호
	private String eNoteNumber; // 전자어음번호
	private String splitNumber; // 분할번호
	private String endorsementNumber; // 배서번호
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private String noteInfoEnoteNumber; // 어음정보-전자어음번호
	private String noteInfoEnoteType; // 어음정보-전자어음종류
	private String noteInfoEnoteProcessStatus; // 어음정보-전자어음처리상태
	private String noteInfoEnoteIssueDate; // 어음정보-전자어음발행일자
	private String noteInfoEnoteIssuePlace; // 어음정보-전자어음발행지
	private long noteInfoEnoteAmount; // 어음정보-전자어음금액
	private String noteInfoDefaultReasonCode; // 어음정보-부도사유코드
	private String noteInfoEnoteMaturedDate; // 어음정보-전자어음만기일자
	private String noteInfoEnoteDefaultProcessingDate; // 어음정보-전자어음부도처리일자
	private String noteInfoEnoteFinalPaymentDate; // 어음정보-전자어음최종결제일자
	private String noteInfopaymentBankBranchCode; // 어음정보-지급은행및지점코드
	private int noteInfoEndorsementCount; // 어음정보-배서횟수
	private String noteInfoInstructionProhibited; // 어음정보-지시금지여부
	private String issuerIndvCorpSort; // 발행인-개인법인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String issuerGuaranteePresence; // 발행인-발행보증여부
	private String issuanceGuaranteeInfoAssuredIndvCorpSort; // 발행보증정보-(피보증인)개인법인구분
	private String issuanceGuaranteeInfoAssuredResidentBusinessNumber; // 발행보증정보-(피보증인)주민사업자번호
	private String issuanceGuaranteeInfoAssuredCorpName; // 발행보증정보-(피보증인)법인명
	private String issuanceGuaranteeInfoAssuredNameRepresentative; // 발행보증정보-(피보증인)성명(대표자명)
	private String issuanceGuaranteeInfoAssuredAddress; // 발행보증정보-(피보증인)주소
	private String issuanceGuaranteeInfoAssuredBankCode; // 발행보증정보-(피보증인)은행코드
	private String issuanceGuaranteeInfoAssuredCurrentAccountNumber; // 발행보증정보-(피보증인)당좌계좌번호
	private String issuanceGuaranteeInfoGuarantorIndvCorpSort; // 발행보증정보-(보증인)개인법인구분
	private String issuanceGuaranteeInfoGuarantorResidentBusinessNumber; // 발행보증정보-(보증인)주민사업자번호
	private String issuanceGuaranteeInfoGuarantorCorpName; // 발행보증정보-(보증인)법인명
	private String issuanceGuaranteeInfoGuarantorNameRepresentative; // 발행보증정보-(보증인)성명(대표자명)
	private String issuanceGuaranteeInfoGuarantorAddress; // 발행보증정보-(보증인)주소
	private String issuanceGuaranteeInfoGuarantorBankCode; // 발행보증정보-(보증인)은행코드
	private String issuanceGuaranteeInfoGuarantorDepositAccountNumber; // 발행보증정보-(보증인)입금계좌번호
	private String issuanceGuaranteeInfoGuaranteeTargetSplitNumber; // 발행보증정보-보증대상분할번호
	private String issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber; // 발행보증정보-보증대상배서번호
	private String issuanceGuaranteeInfoGuaranteeNumber; // 발행보증정보-보증번호
	private List<KftEnt0210482000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementNumber$; // 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteNumber$; // 어음정보-전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteType$; // 어음정보-전자어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteProcessStatus$; // 어음정보-전자어음처리상태
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteIssueDate$; // 어음정보-전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteIssuePlace$; // 어음정보-전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteAmount$; // 어음정보-전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoDefaultReasonCode$; // 어음정보-부도사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteMaturedDate$; // 어음정보-전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteDefaultProcessingDate$; // 어음정보-전자어음부도처리일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEnoteFinalPaymentDate$; // 어음정보-전자어음최종결제일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfopaymentBankBranchCode$; // 어음정보-지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoEndorsementCount$; // 어음정보-배서횟수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteInfoInstructionProhibited$; // 어음정보-지시금지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerIndvCorpSort$; // 발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerGuaranteePresence$; // 발행인-발행보증여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredIndvCorpSort$; // 발행보증정보-(피보증인)개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredResidentBusinessNumber$; // 발행보증정보-(피보증인)주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredCorpName$; // 발행보증정보-(피보증인)법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredNameRepresentative$; // 발행보증정보-(피보증인)성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredAddress$; // 발행보증정보-(피보증인)주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredBankCode$; // 발행보증정보-(피보증인)은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoAssuredCurrentAccountNumber$; // 발행보증정보-(피보증인)당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorIndvCorpSort$; // 발행보증정보-(보증인)개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorResidentBusinessNumber$; // 발행보증정보-(보증인)주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorCorpName$; // 발행보증정보-(보증인)법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorNameRepresentative$; // 발행보증정보-(보증인)성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorAddress$; // 발행보증정보-(보증인)주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorBankCode$; // 발행보증정보-(보증인)은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuarantorDepositAccountNumber$; // 발행보증정보-(보증인)입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuaranteeTargetSplitNumber$; // 발행보증정보-보증대상분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber$; // 발행보증정보-보증대상배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuaranteeInfoGuaranteeNumber$; // 발행보증정보-보증번호

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(noteInfoEnoteNumber$)) { // 어음정보-전자어음번호
			return 20;
		}
		if (VOUtils.isNotAlphanumericSpace(noteInfoDefaultReasonCode$)) { // 어음정보-부도사유코드
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(noteInfoInstructionProhibited$)) { // 어음정보-지시금지여부
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerResidentBusinessNumber$)) { // 발행인-주민사업자번호
			return 34;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerCurrentAccountNumber$)) { // 발행인-당좌계좌번호
			return 38;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerGuaranteePresence$)) { // 발행인-발행보증여부
			return 39;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuaranteeInfoAssuredResidentBusinessNumber$)) { // 발행보증정보-(피보증인)주민사업자번호
			return 41;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuaranteeInfoAssuredCurrentAccountNumber$)) { // 발행보증정보-(피보증인)당좌계좌번호
			return 46;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuaranteeInfoGuarantorResidentBusinessNumber$)) { // 발행보증정보-(보증인)주민사업자번호
			return 48;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuaranteeInfoGuarantorDepositAccountNumber$)) { // 발행보증정보-(보증인)입금계좌번호
			return 53;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // 배서번호
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // 어음정보-전자어음번호
		noteInfoEnoteType$ = VOUtils.write(out, noteInfoEnoteType, 1); // 어음정보-전자어음종류
		noteInfoEnoteProcessStatus$ = VOUtils.write(out, noteInfoEnoteProcessStatus, 2); // 어음정보-전자어음처리상태
		noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // 어음정보-전자어음발행일자
		noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // 어음정보-전자어음발행지
		noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // 어음정보-전자어음금액
		noteInfoDefaultReasonCode$ = VOUtils.write(out, noteInfoDefaultReasonCode, 2); // 어음정보-부도사유코드
		noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // 어음정보-전자어음만기일자
		noteInfoEnoteDefaultProcessingDate$ = VOUtils.write(out, noteInfoEnoteDefaultProcessingDate, 8); // 어음정보-전자어음부도처리일자
		noteInfoEnoteFinalPaymentDate$ = VOUtils.write(out, noteInfoEnoteFinalPaymentDate, 8); // 어음정보-전자어음최종결제일자
		noteInfopaymentBankBranchCode$ = VOUtils.write(out, noteInfopaymentBankBranchCode, 7); // 어음정보-지급은행및지점코드
		noteInfoEndorsementCount$ = VOUtils.write(out, noteInfoEndorsementCount, 4); // 어음정보-배서횟수
		noteInfoInstructionProhibited$ = VOUtils.write(out, noteInfoInstructionProhibited, 1); // 어음정보-지시금지여부
		issuerIndvCorpSort$ = VOUtils.write(out, issuerIndvCorpSort, 1); // 발행인-개인법인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		issuerGuaranteePresence$ = VOUtils.write(out, issuerGuaranteePresence, 1); // 발행인-발행보증여부
		issuanceGuaranteeInfoAssuredIndvCorpSort$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredIndvCorpSort, 1); // 발행보증정보-(피보증인)개인법인구분
		issuanceGuaranteeInfoAssuredResidentBusinessNumber$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredResidentBusinessNumber, 13); // 발행보증정보-(피보증인)주민사업자번호
		issuanceGuaranteeInfoAssuredCorpName$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredCorpName, 40, "EUC-KR"); // 발행보증정보-(피보증인)법인명
		issuanceGuaranteeInfoAssuredNameRepresentative$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredNameRepresentative, 20, "EUC-KR"); // 발행보증정보-(피보증인)성명(대표자명)
		issuanceGuaranteeInfoAssuredAddress$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredAddress, 60, "EUC-KR"); // 발행보증정보-(피보증인)주소
		issuanceGuaranteeInfoAssuredBankCode$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredBankCode, 3); // 발행보증정보-(피보증인)은행코드
		issuanceGuaranteeInfoAssuredCurrentAccountNumber$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredCurrentAccountNumber, 16); // 발행보증정보-(피보증인)당좌계좌번호
		issuanceGuaranteeInfoGuarantorIndvCorpSort$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorIndvCorpSort, 1); // 발행보증정보-(보증인)개인법인구분
		issuanceGuaranteeInfoGuarantorResidentBusinessNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorResidentBusinessNumber, 13); // 발행보증정보-(보증인)주민사업자번호
		issuanceGuaranteeInfoGuarantorCorpName$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorCorpName, 40, "EUC-KR"); // 발행보증정보-(보증인)법인명
		issuanceGuaranteeInfoGuarantorNameRepresentative$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorNameRepresentative, 20, "EUC-KR"); // 발행보증정보-(보증인)성명(대표자명)
		issuanceGuaranteeInfoGuarantorAddress$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorAddress, 60, "EUC-KR"); // 발행보증정보-(보증인)주소
		issuanceGuaranteeInfoGuarantorBankCode$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorBankCode, 3); // 발행보증정보-(보증인)은행코드
		issuanceGuaranteeInfoGuarantorDepositAccountNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorDepositAccountNumber, 16); // 발행보증정보-(보증인)입금계좌번호
		issuanceGuaranteeInfoGuaranteeTargetSplitNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuaranteeTargetSplitNumber, 2); // 발행보증정보-보증대상분할번호
		issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber, 2); // 발행보증정보-보증대상배서번호
		issuanceGuaranteeInfoGuaranteeNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuaranteeNumber, 4); // 발행보증정보-보증번호
		VOUtils.write(out, queryResultArray, 15, KftEnt0210482000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // 배서번호
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // 어음정보-전자어음번호
		noteInfoEnoteType = VOUtils.toString(noteInfoEnoteType$ = VOUtils.read(in, 1)); // 어음정보-전자어음종류
		noteInfoEnoteProcessStatus = VOUtils.toString(noteInfoEnoteProcessStatus$ = VOUtils.read(in, 2)); // 어음정보-전자어음처리상태
		noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음발행일자
		noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음정보-전자어음발행지
		noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // 어음정보-전자어음금액
		noteInfoDefaultReasonCode = VOUtils.toString(noteInfoDefaultReasonCode$ = VOUtils.read(in, 2)); // 어음정보-부도사유코드
		noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음만기일자
		noteInfoEnoteDefaultProcessingDate = VOUtils.toString(noteInfoEnoteDefaultProcessingDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음부도처리일자
		noteInfoEnoteFinalPaymentDate = VOUtils.toString(noteInfoEnoteFinalPaymentDate$ = VOUtils.read(in, 8)); // 어음정보-전자어음최종결제일자
		noteInfopaymentBankBranchCode = VOUtils.toString(noteInfopaymentBankBranchCode$ = VOUtils.read(in, 7)); // 어음정보-지급은행및지점코드
		noteInfoEndorsementCount = VOUtils.toInt(noteInfoEndorsementCount$ = VOUtils.read(in, 4)); // 어음정보-배서횟수
		noteInfoInstructionProhibited = VOUtils.toString(noteInfoInstructionProhibited$ = VOUtils.read(in, 1)); // 어음정보-지시금지여부
		issuerIndvCorpSort = VOUtils.toString(issuerIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인-개인법인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		issuerGuaranteePresence = VOUtils.toString(issuerGuaranteePresence$ = VOUtils.read(in, 1)); // 발행인-발행보증여부
		issuanceGuaranteeInfoAssuredIndvCorpSort = VOUtils.toString(issuanceGuaranteeInfoAssuredIndvCorpSort$ = VOUtils.read(in, 1)); // 발행보증정보-(피보증인)개인법인구분
		issuanceGuaranteeInfoAssuredResidentBusinessNumber = VOUtils.toString(issuanceGuaranteeInfoAssuredResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행보증정보-(피보증인)주민사업자번호
		issuanceGuaranteeInfoAssuredCorpName = VOUtils.toString(issuanceGuaranteeInfoAssuredCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행보증정보-(피보증인)법인명
		issuanceGuaranteeInfoAssuredNameRepresentative = VOUtils.toString(issuanceGuaranteeInfoAssuredNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 발행보증정보-(피보증인)성명(대표자명)
		issuanceGuaranteeInfoAssuredAddress = VOUtils.toString(issuanceGuaranteeInfoAssuredAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행보증정보-(피보증인)주소
		issuanceGuaranteeInfoAssuredBankCode = VOUtils.toString(issuanceGuaranteeInfoAssuredBankCode$ = VOUtils.read(in, 3)); // 발행보증정보-(피보증인)은행코드
		issuanceGuaranteeInfoAssuredCurrentAccountNumber = VOUtils.toString(issuanceGuaranteeInfoAssuredCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행보증정보-(피보증인)당좌계좌번호
		issuanceGuaranteeInfoGuarantorIndvCorpSort = VOUtils.toString(issuanceGuaranteeInfoGuarantorIndvCorpSort$ = VOUtils.read(in, 1)); // 발행보증정보-(보증인)개인법인구분
		issuanceGuaranteeInfoGuarantorResidentBusinessNumber = VOUtils.toString(issuanceGuaranteeInfoGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행보증정보-(보증인)주민사업자번호
		issuanceGuaranteeInfoGuarantorCorpName = VOUtils.toString(issuanceGuaranteeInfoGuarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행보증정보-(보증인)법인명
		issuanceGuaranteeInfoGuarantorNameRepresentative = VOUtils.toString(issuanceGuaranteeInfoGuarantorNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 발행보증정보-(보증인)성명(대표자명)
		issuanceGuaranteeInfoGuarantorAddress = VOUtils.toString(issuanceGuaranteeInfoGuarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행보증정보-(보증인)주소
		issuanceGuaranteeInfoGuarantorBankCode = VOUtils.toString(issuanceGuaranteeInfoGuarantorBankCode$ = VOUtils.read(in, 3)); // 발행보증정보-(보증인)은행코드
		issuanceGuaranteeInfoGuarantorDepositAccountNumber = VOUtils.toString(issuanceGuaranteeInfoGuarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // 발행보증정보-(보증인)입금계좌번호
		issuanceGuaranteeInfoGuaranteeTargetSplitNumber = VOUtils.toString(issuanceGuaranteeInfoGuaranteeTargetSplitNumber$ = VOUtils.read(in, 2)); // 발행보증정보-보증대상분할번호
		issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber = VOUtils.toString(issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber$ = VOUtils.read(in, 2)); // 발행보증정보-보증대상배서번호
		issuanceGuaranteeInfoGuaranteeNumber = VOUtils.toString(issuanceGuaranteeInfoGuaranteeNumber$ = VOUtils.read(in, 4)); // 발행보증정보-보증번호
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0210482000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // 배서번호
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // 어음정보-전자어음번호
		sb.append(", noteInfoEnoteType=").append(noteInfoEnoteType).append(System.lineSeparator()); // 어음정보-전자어음종류
		sb.append(", noteInfoEnoteProcessStatus=").append(noteInfoEnoteProcessStatus).append(System.lineSeparator()); // 어음정보-전자어음처리상태
		sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // 어음정보-전자어음발행일자
		sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // 어음정보-전자어음발행지
		sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // 어음정보-전자어음금액
		sb.append(", noteInfoDefaultReasonCode=").append(noteInfoDefaultReasonCode).append(System.lineSeparator()); // 어음정보-부도사유코드
		sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // 어음정보-전자어음만기일자
		sb.append(", noteInfoEnoteDefaultProcessingDate=").append(noteInfoEnoteDefaultProcessingDate).append(System.lineSeparator()); // 어음정보-전자어음부도처리일자
		sb.append(", noteInfoEnoteFinalPaymentDate=").append(noteInfoEnoteFinalPaymentDate).append(System.lineSeparator()); // 어음정보-전자어음최종결제일자
		sb.append(", noteInfopaymentBankBranchCode=").append(noteInfopaymentBankBranchCode).append(System.lineSeparator()); // 어음정보-지급은행및지점코드
		sb.append(", noteInfoEndorsementCount=").append(noteInfoEndorsementCount).append(System.lineSeparator()); // 어음정보-배서횟수
		sb.append(", noteInfoInstructionProhibited=").append(noteInfoInstructionProhibited).append(System.lineSeparator()); // 어음정보-지시금지여부
		sb.append(", issuerIndvCorpSort=").append(issuerIndvCorpSort).append(System.lineSeparator()); // 발행인-개인법인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", issuerGuaranteePresence=").append(issuerGuaranteePresence).append(System.lineSeparator()); // 발행인-발행보증여부
		sb.append(", issuanceGuaranteeInfoAssuredIndvCorpSort=").append(issuanceGuaranteeInfoAssuredIndvCorpSort).append(System.lineSeparator()); // 발행보증정보-(피보증인)개인법인구분
		sb.append(", issuanceGuaranteeInfoAssuredResidentBusinessNumber=").append(issuanceGuaranteeInfoAssuredResidentBusinessNumber).append(System.lineSeparator()); // 발행보증정보-(피보증인)주민사업자번호
		sb.append(", issuanceGuaranteeInfoAssuredCorpName=").append(issuanceGuaranteeInfoAssuredCorpName).append(System.lineSeparator()); // 발행보증정보-(피보증인)법인명
		sb.append(", issuanceGuaranteeInfoAssuredNameRepresentative=").append(issuanceGuaranteeInfoAssuredNameRepresentative).append(System.lineSeparator()); // 발행보증정보-(피보증인)성명(대표자명)
		sb.append(", issuanceGuaranteeInfoAssuredAddress=").append(issuanceGuaranteeInfoAssuredAddress).append(System.lineSeparator()); // 발행보증정보-(피보증인)주소
		sb.append(", issuanceGuaranteeInfoAssuredBankCode=").append(issuanceGuaranteeInfoAssuredBankCode).append(System.lineSeparator()); // 발행보증정보-(피보증인)은행코드
		sb.append(", issuanceGuaranteeInfoAssuredCurrentAccountNumber=").append(issuanceGuaranteeInfoAssuredCurrentAccountNumber).append(System.lineSeparator()); // 발행보증정보-(피보증인)당좌계좌번호
		sb.append(", issuanceGuaranteeInfoGuarantorIndvCorpSort=").append(issuanceGuaranteeInfoGuarantorIndvCorpSort).append(System.lineSeparator()); // 발행보증정보-(보증인)개인법인구분
		sb.append(", issuanceGuaranteeInfoGuarantorResidentBusinessNumber=").append(issuanceGuaranteeInfoGuarantorResidentBusinessNumber).append(System.lineSeparator()); // 발행보증정보-(보증인)주민사업자번호
		sb.append(", issuanceGuaranteeInfoGuarantorCorpName=").append(issuanceGuaranteeInfoGuarantorCorpName).append(System.lineSeparator()); // 발행보증정보-(보증인)법인명
		sb.append(", issuanceGuaranteeInfoGuarantorNameRepresentative=").append(issuanceGuaranteeInfoGuarantorNameRepresentative).append(System.lineSeparator()); // 발행보증정보-(보증인)성명(대표자명)
		sb.append(", issuanceGuaranteeInfoGuarantorAddress=").append(issuanceGuaranteeInfoGuarantorAddress).append(System.lineSeparator()); // 발행보증정보-(보증인)주소
		sb.append(", issuanceGuaranteeInfoGuarantorBankCode=").append(issuanceGuaranteeInfoGuarantorBankCode).append(System.lineSeparator()); // 발행보증정보-(보증인)은행코드
		sb.append(", issuanceGuaranteeInfoGuarantorDepositAccountNumber=").append(issuanceGuaranteeInfoGuarantorDepositAccountNumber).append(System.lineSeparator()); // 발행보증정보-(보증인)입금계좌번호
		sb.append(", issuanceGuaranteeInfoGuaranteeTargetSplitNumber=").append(issuanceGuaranteeInfoGuaranteeTargetSplitNumber).append(System.lineSeparator()); // 발행보증정보-보증대상분할번호
		sb.append(", issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber=").append(issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber).append(System.lineSeparator()); // 발행보증정보-보증대상배서번호
		sb.append(", issuanceGuaranteeInfoGuaranteeNumber=").append(issuanceGuaranteeInfoGuaranteeNumber).append(System.lineSeparator()); // 발행보증정보-보증번호
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "482000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteDefaultProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteFinalPaymentDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfopaymentBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "noteInfoEndorsementCount", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "noteInfoInstructionProhibited", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuerGuaranteePresence", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuaranteeTargetSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuaranteeTargetEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuaranteeNumber", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "endorsementInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorsementInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorsementInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorsementInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorsementInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorsementInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorsementInfoSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "endorsementInfoNonCollateralEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoProhibitedEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoGuaranteeEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoDefaultNoteReturn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoPostmaturedEndorsement", "fldLen", "1", "defltVal", "")
		);
	}

}
