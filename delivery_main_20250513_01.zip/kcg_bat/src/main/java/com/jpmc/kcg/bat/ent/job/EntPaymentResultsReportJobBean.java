package com.jpmc.kcg.bat.ent.job;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.jpmc.kcg.bat.TaskletBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.ent.dao.BatEntSndRcvFileLDao;
import com.jpmc.kcg.cms.constants.CmsConst;
import com.jpmc.kcg.ent.biz.EntCom;
import com.jpmc.kcg.ent.biz.vo.KftEntES1105R;
import com.jpmc.kcg.ent.dto.EntSndRcvFileL;
import com.jpmc.kcg.ent.dto.EntSttlMgmtM;
import com.jpmc.kcg.ent.enums.SttlPrcsDvsnCdEnum;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;

import lombok.extern.slf4j.Slf4j;

/**
 * ES1105 지급제시결과내역 파일송수신내역을 지급제시결과내역에 저장한다.
 */
@Component
@Slf4j
public class EntPaymentResultsReportJobBean extends TaskletBatJob {
    
    public static final String FILE_NM = "ES1105";
    private final BatEntSndRcvFileLDao batEntSndRcvFileLDao;
    private final EntCom entCom;
    private final CmsCom cmsCom;

    public EntPaymentResultsReportJobBean(BatEntSndRcvFileLDao batEntSndRcvFileLDao, EntCom entCom, CmsCom cmsCom) {
        this.batEntSndRcvFileLDao = batEntSndRcvFileLDao;
        this.entCom = entCom;
        this.cmsCom = cmsCom;
    }

    @Override
    public void executeInternal(BatContext batContext) {
        BatCmsContextVo cmsContextVo = new BatCmsContextVo();
        cmsContextVo.initializeContext(batContext, FILE_NM);
		
		// 적재 테이블에서 데이터 조회
        List<EntSndRcvFileL> entFileList = batEntSndRcvFileLDao.selectEntFileList(cmsContextVo.getTrDt(), FILE_NM, CmsConst.DATA);
        
        if (CollectionUtils.isEmpty(entFileList)) {
            log.debug("ENT_SND_RVC_FILE_L SELECT NO DATA FOUND TR_DT = {} , FILE_NM = {}", cmsContextVo.getTrDt(), FILE_NM);
            return;
        }

        entFileList.forEach(entFile -> {
            KftEntES1105R kftEntES1105R = VOUtils.toVo(entFile.getTlgCtt(), KftEntES1105R.class);
            
            EntSttlMgmtM entSttlMgmtM = new EntSttlMgmtM();
            entSttlMgmtM.setEntNo                   (kftEntES1105R.getEnoteNumber()                            ); // 전자어음번호
            entSttlMgmtM.setAddRequSpltNo           (kftEntES1105R.getBeneficiarySplitNumber()                 ); // 부가요건-분할번호
            entSttlMgmtM.setAddRequEndtNo           (kftEntES1105R.getBeneficiaryEndorsementNumber()           ); // 부가요건-배서번호
            entSttlMgmtM.setEntSndRcvDvsnCd         (kftEntES1105R.getSendReceiveFlag()                        ); // 송수신 구분
            entSttlMgmtM.setPymntDt                 (kftEntES1105R.getPaymentPresentationDate()                ); // 지급제시일자
            entSttlMgmtM.setPymntNo                 (kftEntES1105R.getPaymentPresentationNumber()              ); // 지급제시번호
            entSttlMgmtM.setSttlPrcsDvsn            (kftEntES1105R.getSettlementProcessDivisionCode()          ); // 결제처리구분
            entSttlMgmtM.setSttlSts                 (SttlPrcsDvsnCdEnum.getStatusCodeByCode(kftEntES1105R.getSettlementProcessDivisionCode())); // 결제상태
            entSttlMgmtM.setEntTp                   (kftEntES1105R.getEnoteType()                              ); // 어음종류
            entSttlMgmtM.setEntIssueDt              (kftEntES1105R.getEnoteIssueDate()                         ); // 어음발행일자
            entSttlMgmtM.setEntIssueAreaNm          (kftEntES1105R.getEnoteIssuePlace()                        ); // 어음발행지
            entSttlMgmtM.setEntAmt                  (BigDecimal.valueOf(kftEntES1105R.getEnoteIssueAmount())   ); // 어음발행금액
            entSttlMgmtM.setEntMatDt                (kftEntES1105R.getEnoteMaturedDate()                       ); // 어음만기일자
            entSttlMgmtM.setPymntBnkBrnchCd         (kftEntES1105R.getPaymentBankCode()                        ); // 지급은행 및 지점코드
            entSttlMgmtM.setPymntExCd               (kftEntES1105R.getPaymentBranchClearingHouseCode()         ); // 지급점포 교환소 코드
            entSttlMgmtM.setIssurCorpIndvDvsnCd     (kftEntES1105R.getIssuerCorpIndvSort()                     ); // 발행인-법인개인구분
            entSttlMgmtM.setIssurCtzBizNo           (kftEntES1105R.getIssuerResidentBusinessNumber()           ); // 발행인-주민사업자번호
            entSttlMgmtM.setIssurCorpNm             (kftEntES1105R.getIssuerCorpName()                         ); // 발행인-법인명
            entSttlMgmtM.setIssurRepNm              (kftEntES1105R.getIssuerNameRepresentativeName()           ); // 발행인-대표자명
            entSttlMgmtM.setIssurAddr               (kftEntES1105R.getIssuerAddress()                          ); // 발행인-주소
            entSttlMgmtM.setIssurCurrAcctNo         (kftEntES1105R.getIssuerCurrentAccountNumber()             ); // 발행인-당좌계좌번호
            entSttlMgmtM.setRcpntCorpIndvDvsnCd     (kftEntES1105R.getBeneficiaryCorpIndvSort()                ); // 소지인-법인개인구분
            entSttlMgmtM.setRcpntCtzBizNo           (kftEntES1105R.getBeneficiaryResidentBusinessNumber()      ); // 소지인-주민사업자번호
            entSttlMgmtM.setRcpntCorpNm             (kftEntES1105R.getBeneficiaryCorpName()                    ); // 소지인-법인명
            entSttlMgmtM.setRcpntRepNm              (kftEntES1105R.getBeneficiaryNameRepresentativeName()      ); // 소지인-대표자명
            entSttlMgmtM.setRcpntAddr               (kftEntES1105R.getBeneficiaryAddress()                     ); // 소지인-주소
            entSttlMgmtM.setRcpntBnkCd              (kftEntES1105R.getBeneficiaryBankCode()                    ); // 소지인-은행코드
            entSttlMgmtM.setRcpntDpstAcctNo         (kftEntES1105R.getBeneficiaryAccountNumber()               ); // 소지인-입금계좌번호
            entSttlMgmtM.setRcpntSpltNo             (kftEntES1105R.getBeneficiarySplitNumber()                 ); // 소지인-분할번호
            entSttlMgmtM.setRcpntEndtNo             (kftEntES1105R.getBeneficiaryEndorsementNumber()           ); // 소지인-배서번호
            entSttlMgmtM.setRcpntSpltEntAmt         (BigDecimal.valueOf(kftEntES1105R.getBeneficiarySplitEnoteAmount()));//소지인-분할 전자어음 금액
            entSttlMgmtM.setEntMatSttlDttm          (kftEntES1105R.getEnoteMaturedSettlementDateTime()         ); //  전자어음 만기 결제일시
            entSttlMgmtM.setDfltDt                  (kftEntES1105R.getDefaultDate()                            ); // 부도일
            entSttlMgmtM.setDfltRsnEntDfltRsn       (kftEntES1105R.getEnoteDefaultReason()                     ); // 전자어음 부도사유
            entSttlMgmtM.setAcdntRptRsnCd           (kftEntES1105R.getAccidentReportReason()                   ); // 사고신고서 사유
            entSttlMgmtM.setDfltRsnStopPymntInjctCd (kftEntES1105R.getPaymentSuspensionProvisionalDisposition()); // 지급정지 가처분
            entSttlMgmtM.setDfltRsnSpclDepoCrdtCd   (kftEntES1105R.getSpecialDeposit()                         ); // 별단예금 입금
            entSttlMgmtM.setDfltRsnCorpMgmtBnkCd    (kftEntES1105R.getBankManagementCompanyYn()                ); // 은행관리 기업여부
            entSttlMgmtM.setDfltRsnRstrctTgtCmpnyCd (kftEntES1105R.getRestructuringTargetCompanyYn()           ); // 구조조정 대상기업여부
            entSttlMgmtM.setDfltRsnDpstSrtRsnCd     (kftEntES1105R.getDepositShortageCause()                   ); // 예금부족 원인
            entSttlMgmtM.setDfltDpstDpstDttm        (kftEntES1105R.getDefaultDepositDateTime()                 ); // 부도 입금일시
            entSttlMgmtM.setDfltDpstBnkBrnchCd      (kftEntES1105R.getDefaultDepositBankAndBranchCode()        ); // 부도 입금은행 및 지점코드
            entSttlMgmtM.setDfltRsnChgYn            (kftEntES1105R.getDefaultReasonChangeYn()                  ); // 부도사유 변경여부
            entSttlMgmtM.setChgBfEntDfltRsnCd       (kftEntES1105R.getBeforeChangeEnoteDefaultReason()         ); // 변경 전 전자어음 부도사유
            entSttlMgmtM.setChgAfEntDfltRsnCd       (kftEntES1105R.getAfterChangeENoteDefaultReason()          ); // 변경 후 전자어음 부도사유
            entSttlMgmtM.setNotiTgt                 (kftEntES1105R.getNotificationTarget()                     ); // 통지대상
            
            entCom.updateEnoteSettleManagementM(kftEntES1105R.getEnoteNumber(), entSttlMgmtM);
        });

        log.debug("[I N F O]  ====================================================================] ");
        log.debug("[I N F O]  =                      ES1105_PROC COMPLETE                      =] ");
        log.debug("[I N F O]  --------------------------------------------------------------------] ");
        log.debug("[I N F O]  【SIZE = {}】", entFileList.size());
        
        /**
         * file tracking 정보 저장
         */
        batContext.setFileTractId(cmsCom.getFileTractId(cmsContextVo.getSrDt(), FILE_NM));
    }
}
