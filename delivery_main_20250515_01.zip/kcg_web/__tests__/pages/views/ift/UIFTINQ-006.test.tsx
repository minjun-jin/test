import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// UIFTINQ006 컴포넌트를 불러옵니다.
import UIFTINQ006 from "@/pages/views/ift/UIFTINQ-006"
import { Component } from "@/hoc/TestUtil"

const component = Component(UIFTINQ006)

describe("[UIFTINQ-006] 거래내역조회", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("20240101")
  })

  beforeEach(() => {
    mockUseParams.mockReturnValue({
      params: undefined,
    })
    mockUseProxy.mockDownload.mockRestore()
  })

  it("useEffect Test - trStsCd is 02", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        trStsCd: "02",
      },
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })

    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("useEffect Test - trStsCd is 03", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        trStsCd: "03",
      },
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })

    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("useEffect Test - trStsCd is 04", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        trStsCd: "04",
      },
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
          sumOut: {},
        },
      })

    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("searchListTransaction Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
        sumOut: {},
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
        sumOut: {},
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {},
      },
    })
  })

  it("valueGetter Test", async () => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)

    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: { respCd: null },
      },
    })

    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: { respCd: "test" },
      },
    })
  })

  it.each([
    {
      outinDvsnCd: "01",
      trStsCd: "01",
    },
    {
      outinDvsnCd: "01",
      trStsCd: "03",
    },
    {
      outinDvsnCd: "01",
      trStsCd: "02",
    },
    {
      outinDvsnCd: "02",
      trStsCd: "03",
    },
    {
      outinDvsnCd: "02",
      trStsCd: "04",
    },
    {
      outinDvsnCd: "03",
      trStsCd: "03",
      tlgKndTrDvsnCd: "0000500",
    },
    {
      outinDvsnCd: "04",
      trStsCd: "05",
      tlgKndTrDvsnCd: "0000500",
    },
  ])("cellStyle Test", async (param) => {
    const { findByText } = render(component)
    const cellStyleTestBtn = await findByText(/cellStyle Test/)

    fireEvent.click(cellStyleTestBtn, {
      target: {
        data: param,
      },
    })
  })

  it("onRowClicked Test", async () => {
    const { findByText } = render(component)
    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          kftcTlgTrTm: undefined,
        },
      },
    })

    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          kftcTlgTrTm: "test",
        },
      },
    })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })

  it("onRowDoubleClicked Test", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {},
      },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init$/)
    fireEvent.click(initBtn)
  })

  it("getListTransactionExcel Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [
          {
            trDt: "20240101",
            kftcTlgTrTm: "000000",
            outinDvsnCd: "",
            tlgKndTrDvsnCd: "",
            trStsCd: "",
            respCd: "051",
            respMsg: "",
            hostNo: "",
            hndlBnkTlgNo: "",
            kftcTlgNo: "",
            rcvAcctNo: "",
            rqerNm: "",
            sndrRealNm: "",
            totTrAmt: "10",
            cashAmt: "10",
            chequeAmt: "10",
            dfltWhdrwlAmt: "110",
            dfltWhdrwlRsnCd: "",
            payerBnkCd: "",
            rcvBnkCd: "",
            rcpntNm: "",
            chnlTp: "",
          },
          {
            trDt: "20240101",
            kftcTlgTrTm: "000000",
            outinDvsnCd: "",
            tlgKndTrDvsnCd: "",
            trStsCd: "",
            respCd: undefined,
            respMsg: "",
            hostNo: "",
            hndlBnkTlgNo: "",
            kftcTlgNo: "",
            rcvAcctNo: "",
            rqerNm: "",
            sndrRealNm: "",
            totTrAmt: undefined,
            cashAmt: undefined,
            chequeAmt: undefined,
            dfltWhdrwlAmt: undefined,
            dfltWhdrwlRsnCd: "",
            payerBnkCd: "",
            rcvBnkCd: "",
            rcpntNm: "",
            chnlTp: "",
          },
        ],
      },
    })

    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })

    const { findByText } = render(component)
    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - selectedRows.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)

    const pdfBtn = await findByText(/pdf/)
    fireEvent.click(pdfBtn)
    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - download resolved", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([{}])
    mockUseProxy.mockDownload.mockResolvedValue({})
    const { findByText } = render(component)

    const pdfBtn = await findByText(/pdf/)
    fireEvent.click(pdfBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceiptPdf Test - download rejected", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([{}])
    mockUseProxy.mockDownload.mockRejectedValueOnce({})
    const { findByText } = render(component)

    const pdfBtn = await findByText(/pdf/)
    fireEvent.click(pdfBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - selectedRows.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)

    const receiptBtn = await findByText(/SCRNITM#receipt/)
    fireEvent.click(receiptBtn)
    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - download resolved", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([{}])
    mockUseProxy.mockDownload.mockResolvedValue({})
    const { findByText } = render(component)

    const receiptBtn = await findByText(/SCRNITM#receipt/)
    fireEvent.click(receiptBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it("saveReceipt Test - download rejected", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([{}])
    mockUseProxy.mockDownload.mockRejectedValueOnce({})
    const { findByText } = render(component)

    const receiptBtn = await findByText(/SCRNITM#receipt/)
    fireEvent.click(receiptBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockDownload).toHaveBeenCalled()
    })
  })

  it.each(["01", "02", "03"])("getDisplayText Test", async (outinDvsnCd) => {
    const { findAllByTestId } = render(component)
    const onChangeTestBtn = await within(
      (
        await findAllByTestId(/SCRNITM#tp/)
      )[0],
    ).findByTestId("onChange")
    fireEvent.click(onChangeTestBtn, { target: { data: outinDvsnCd } })
  })

  it("validate Test", async () => {
    mockUseForm.mockGetValues
      .mockReturnValueOnce("20240101")
      .mockReturnValueOnce("20241231")
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")

    fireEvent.click(validateTestBtn, { target: { data: {} } })
  })

  it("onChagne Test", async () => {
    const { findAllByTestId } = render(component)
    const onChangeTestBtns = await findAllByTestId("onChange")
    onChangeTestBtns.forEach((onChangeTestBtn) => {
      fireEvent.click(onChangeTestBtn, { target: { data: {} } })
    })
  })
})
