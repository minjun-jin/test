package com.jpmc.kcg.web.sim.controller;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileL;
import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileLIn;
import com.jpmc.kcg.web.sim.service.CmsSimDataSvc;
import com.jpmc.kcg.web.sim.service.CommonSimExecutionMessageParseSvc;
import com.jpmc.kcg.web.sim.service.CommonSimFieldInputTypeSvc;
import com.jpmc.kcg.web.sim.service.CommonSimFieldSvc;
import com.jpmc.kcg.web.sim.service.CommonSimFileSvc;
import com.jpmc.kcg.web.sim.service.DateManagementSvc;
import com.jpmc.kcg.web.sim.service.dto.ApplyExecutionMessageByFieldIn;
import com.jpmc.kcg.web.sim.service.dto.ApplyExecutionMessageByFieldOut;
import com.jpmc.kcg.web.sim.service.dto.ConvertToExecutionMessageIn;
import com.jpmc.kcg.web.sim.service.dto.ConvertToExecutionMessageOut;
import com.jpmc.kcg.web.sim.service.dto.GetDateFieldListOut;
import com.jpmc.kcg.web.sim.service.dto.GetDateMgmtListOut;
import com.jpmc.kcg.web.sim.service.dto.GetEffectiveDateMgmtListOut;
import com.jpmc.kcg.web.sim.service.dto.GetExecutionMessageParseResultIn;
import com.jpmc.kcg.web.sim.service.dto.GetExecutionMessageParseResultOut;
import com.jpmc.kcg.web.sim.service.dto.GetFieldDataListIn;
import com.jpmc.kcg.web.sim.service.dto.GetFieldListIn;
import com.jpmc.kcg.web.sim.service.dto.GetFieldListOut;
import com.jpmc.kcg.web.sim.service.dto.GetSampleExecutionMessageIn;
import com.jpmc.kcg.web.sim.service.dto.GetSampleExecutionMessageOut;
import com.jpmc.kcg.web.sim.service.dto.ReadTemplateMessageOut;
import com.jpmc.kcg.web.sim.service.dto.SaveEffectiveDateIn;
import com.jpmc.kcg.web.sim.service.dto.SaveEffectiveDateOut;
import com.jpmc.kcg.web.sim.service.dto.SaveFieldInputTypeIn;
import com.jpmc.kcg.web.sim.service.dto.SaveFieldInputTypeOut;
import com.jpmc.kcg.web.sim.service.dto.SaveOrUpdateDateMgmtIn;
import com.jpmc.kcg.web.sim.service.dto.SaveOrUpdateDateMgmtOut;
import com.jpmc.kcg.web.sim.service.dto.SearchFieldInputTypesIn;
import com.jpmc.kcg.web.sim.service.dto.SearchFieldInputTypesOut;

import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@Transactional
@RequestMapping("/api/v1/cpg/sim")
public class SimComController {

	private CommonSimFieldSvc commonSimFieldSvc;
	private CommonSimExecutionMessageParseSvc commonSimExecutionMessageParseSvc;
	private CommonSimFieldInputTypeSvc commonSimFieldInputTypeSvc;
	private CommonSimFileSvc commonSimFileSvc;
	private DateManagementSvc dateManagementSvc;
	private CmsSimDataSvc cmsSimDataSvc;

	public SimComController(CommonSimFieldSvc commonSimFieldSvc,
			CommonSimExecutionMessageParseSvc commonSimExecutionMessageParseSvc,
			CommonSimFieldInputTypeSvc commonSimFieldInputTypeSvc, CommonSimFileSvc commonSimFileSvc,
			DateManagementSvc dateManagementSvc, CmsSimDataSvc cmsSimDataSvc) {
		this.commonSimFieldSvc = commonSimFieldSvc;
		this.commonSimExecutionMessageParseSvc = commonSimExecutionMessageParseSvc;
		this.commonSimFieldInputTypeSvc = commonSimFieldInputTypeSvc;
		this.commonSimFileSvc = commonSimFileSvc;
		this.dateManagementSvc = dateManagementSvc;
		this.dateManagementSvc = dateManagementSvc;
		this.cmsSimDataSvc = cmsSimDataSvc;

	}

	@PostMapping("/getFieldList")
	public GetFieldListOut getFieldList(@RequestBody GetFieldListIn in) {
		log.debug("POST getFieldList in dto : {}", in);

		return commonSimFieldSvc.getFieldList(in);
	}

	@PostMapping("/getExecutionMessageParseResult")
	public GetExecutionMessageParseResultOut getExecutionMessageParseResult(
			@RequestBody GetExecutionMessageParseResultIn in) {
		log.debug("POST getExecutionMessageParseResult in dto : {}", in);

		return commonSimExecutionMessageParseSvc.getExecutionMessageParseResult(in);
	}

	@PostMapping("/convertToExecutionMessage")
	public ConvertToExecutionMessageOut convertToExecutionMessage(@RequestBody ConvertToExecutionMessageIn in) {
		log.debug("POST convertToExecutionMessage in dto : {}", in);

		return commonSimExecutionMessageParseSvc.convertToExecutionMessage(in);
	}

	@PostMapping("/applyExecutionMessageByField")
	public ApplyExecutionMessageByFieldOut applyExecutionMessageByField(
			@RequestBody ApplyExecutionMessageByFieldIn in) {
		log.debug("POST applyExecutionMessageByField in dto : {}", in);

		return commonSimExecutionMessageParseSvc.applyExecutionMessageByField(in);
	}

	@PostMapping("/getSampleExecutionMessage")
	public GetSampleExecutionMessageOut getSampleExecutionMessage(@RequestBody GetSampleExecutionMessageIn in) {
		log.debug("POST getSampleExecutionMessage in dto : {}", in);

		return commonSimExecutionMessageParseSvc.getSampleExecutionMessage(in);
	}

	@PostMapping("/searchFieldInputTypes")
	public SearchFieldInputTypesOut searchFieldInputTypes(@RequestBody SearchFieldInputTypesIn in) {
		log.debug("POST searchFieldInputTypes in dto : {}", in);

		return commonSimFieldInputTypeSvc.searchFieldInputTypes(in);
	}

	@PostMapping("/saveFieldInputType")
	public SaveFieldInputTypeOut saveFieldInputType(@RequestBody SaveFieldInputTypeIn in) {
		log.debug("POST searchFieldInputTypes in dto : {}", in);

		return commonSimFieldInputTypeSvc.saveFieldInputType(in);
	}

	@PostMapping("/getTemplateDirectorypath")
	public void getTemplateDirectorypath(HttpServletResponse response) {
		log.debug("POST getTemplateDirectorypath in response : {}", response);
		commonSimFileSvc.getTemplateDirectorypath(response);
	}

	@PostMapping("/readTemplateMessage")
	public ReadTemplateMessageOut readTemplateMessage(MultipartFile file) {
		log.debug("POST readTemplateMessage in messageFile {}", file);

		return commonSimFileSvc.readTemplateMessage(file);

	}

	@PostMapping("/getDateMgmtList")
	public GetDateMgmtListOut getDateMgmtList() {
		log.debug("POST getDateMgmtList");

		return dateManagementSvc.getDateMgmtList();
	}

	@PostMapping("/saveOrUpdateDateMgmt")
	public SaveOrUpdateDateMgmtOut saveOrUpdateDateMgmt(@RequestBody SaveOrUpdateDateMgmtIn in) {
		log.debug("POST saveOrUpdateDateMgmt in dto : {}", in);

		return dateManagementSvc.saveOrUpdateDateMgmt(in);
	}

	@PostMapping("/getEffectiveDateMgmtList")
	public GetEffectiveDateMgmtListOut getEffectiveDateMgmtListOut() {
		log.debug("POST getEffectiveDateMgmtList");

		return dateManagementSvc.getEffectiveDateMgmtList();
	}

	@PostMapping("/getDateFieldList")
	public GetDateFieldListOut getDateFieldList(@RequestBody GetFieldDataListIn in) {
		log.debug("POST getDateFieldList");

		return dateManagementSvc.getDateFieldList(in);
	}

	@PostMapping("/saveEffectiveDate")
	public SaveEffectiveDateOut saveEffectiveDate(@RequestBody SaveEffectiveDateIn in) {
		log.debug("POST saveEffectiveDate in dto : {}", in);

		return dateManagementSvc.saveEffectiveDate(in);
	}
	
	@PostMapping("/saveCmsSimData")
	public void saveCmsSimData(@RequestBody SimCmsSndRcvFileLIn in) {
		log.debug("POST saveCmsSimData in dto : {}", in);
		
		cmsSimDataSvc.saveCmsSimData(in);
	}
	
	@PostMapping("/deleteCmsSimData")
	public void deleteCmsSimData(@RequestBody SimCmsSndRcvFileLIn in) {
		log.debug("POST deleteCmsSimData in dto : {}", in);
		
		cmsSimDataSvc.deleteCmsSimData(in);
	}
	
	@PostMapping("/modifyCmsSimData")
	public void modifyCmsSimData(@RequestBody SimCmsSndRcvFileL in) {
		log.debug("POST modifyCmsSimData in dto : {}", in);
		
		cmsSimDataSvc.modifyCmsSimData(in);
	}

}
