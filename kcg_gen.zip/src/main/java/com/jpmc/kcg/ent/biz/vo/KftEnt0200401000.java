package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 발행인별 발행정보 조회 요청 B
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 401000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * sortCondition 정렬조건 
 * searchConditionSort 검색조건구분 
 * queryPeriodBasisSort 조회기간기준구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * currentAccountNumber 당좌계좌번호 
 * queryStartDate 조회시작일 
 * queryEndDate 조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.noteInfoEnoteNumber (조회결과)어음정보-01전자어음번호 
 * queryResultArray.noteInfoEnoteType (조회결과)어음정보-02어음종류 
 * queryResultArray.noteInfoEnoteProcessStatus (조회결과)어음정보-03전자어음처리상태 
 * queryResultArray.noteInfoEnoteIssueDate (조회결과)어음정보-04전자어음발행일자 
 * queryResultArray.noteInfoEnoteIssuePlace (조회결과)어음정보-05전자어음발행지 
 * queryResultArray.noteInfoEnoteAmount (조회결과)어음정보-06전자어음금액 
 * queryResultArray.noteInfoDefaultReasonCode (조회결과)어음정보-부도사유코드 
 * queryResultArray.noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
 * queryResultArray.noteInfoEnoteInitialdefaultProcessingDate (조회결과)어음정보-전자어음최초부도처리일자 
 * queryResultArray.noteInfoEnoteFinalSettlementDate (조회결과)어음정보-전자어음최종결제일자 
 * queryResultArray.noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
 * queryResultArray.issuerInfoCorpIndvSort (조회결과)발행인정보-개인법인구분 
 * queryResultArray.issuerInfoResidentBusinessNumber (조회결과)발행인정보-주민사업자번호 
 * queryResultArray.issuerInfoCorpName (조회결과)발행인정보-법인명 
 * queryResultArray.issuerInfoNameRepresentativeName (조회결과)발행인정보-성명(대표자명) 
 * queryResultArray.issuerInfoAddress (조회결과)발행인정보-주소 
 * queryResultArray.issuerInfoBankCode (조회결과)발행인정보-은행코드 
 * queryResultArray.issuerInfoDepositAccountNumber (조회결과)발행인정보-입금계좌번호 
 * queryResultArray.beneInfoCorpIndvSort (조회결과)수취인인정보-개인법인구분 
 * queryResultArray.beneInfoResidentBusinessNumber (조회결과)수취인인정보-주민사업자번호 
 * queryResultArray.beneInfoCorpName (조회결과)수취인인정보-법인명 
 * queryResultArray.beneInfoNameRepresentativeName (조회결과)수취인인정보-성명(대표자명) 
 * queryResultArray.beneInfoAddress (조회결과)수취인인정보-주소 
 * queryResultArray.beneInfoBankCode (조회결과)수취인인정보-은행코드 
 * queryResultArray.beneInfoDepositAccountNumber (조회결과)수취인인정보-계좌번호 
 * queryResultArray.prohibitedInstructionYn (조회결과)지시금지여부 
 * queryResultArray.issuanceGuaranteeYn (조회결과)발행보증여부 
 * queryResultArray.beforeAfterIssueSort (조회결과)발행전후구분 
 * queryResultArray.issuanceGuarantorCorpIndvSort (조회결과)발행보증인-개인법인구분 
 * queryResultArray.issuanceGuarantorResidentBusinessNumber (조회결과)발행보증인-주민사업자번호 
 * queryResultArray.issuanceGuarantorCorpName (조회결과)발행보증인-법인명 
 * queryResultArray.issuanceGuarantorNameRepresentativeName (조회결과)발행보증인-성명(대표자명) 
 * queryResultArray.issuanceGuarantorAddress (조회결과)발행보증인-주소 
 * queryResultArray.issuanceGuarantorBankCode (조회결과)발행보증인-은행코드 
 * queryResultArray.issuanceGuarantorCurrentAccountNumber (조회결과)발행보증인-당좌계좌번호 
 * 
 * KftEnt0200401000 kftEnt0200401000 = new KftEnt0200401000(); // 발행인별 발행정보 조회 요청 B
 * kftEnt0200401000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200401000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200401000.setBnkCd("057"); // 은행코드
 * kftEnt0200401000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200401000.setTransactionCode("401000"); // 거래구분코드
 * kftEnt0200401000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200401000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200401000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200401000.setStatus("000"); // STATUS
 * kftEnt0200401000.setResponseCode1(""); // 응답코드1
 * kftEnt0200401000.setResponseCode2(""); // 응답코드2
 * kftEnt0200401000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200401000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200401000.setSortCondition(""); // 정렬조건
 * kftEnt0200401000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0200401000.setQueryPeriodBasisSort(""); // 조회기간기준구분
 * kftEnt0200401000.setENoteNumber(""); // 전자어음번호
 * kftEnt0200401000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200401000.setCurrentAccountNumber(""); // 당좌계좌번호
 * kftEnt0200401000.setQueryStartDate(""); // 조회시작일
 * kftEnt0200401000.setQueryEndDate(""); // 조회종료일
 * kftEnt0200401000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0200401000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0200401000.setCurrentCount(0); // 현재건수
 * KftEnt0200401000.QueryResult queryResult = new KftEnt0200401000.QueryResult(); // 조회결과Array
 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-01전자어음번호
 * queryResult.setNoteInfoEnoteType(""); // (조회결과)어음정보-02어음종류
 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-03전자어음처리상태
 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-04전자어음발행일자
 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-05전자어음발행지
 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-06전자어음금액
 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-부도사유코드
 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
 * queryResult.setNoteInfoEnoteInitialdefaultProcessingDate(""); // (조회결과)어음정보-전자어음최초부도처리일자
 * queryResult.setNoteInfoEnoteFinalSettlementDate(""); // (조회결과)어음정보-전자어음최종결제일자
 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
 * queryResult.setIssuerInfoCorpIndvSort(""); // (조회결과)발행인정보-개인법인구분
 * queryResult.setIssuerInfoResidentBusinessNumber(""); // (조회결과)발행인정보-주민사업자번호
 * queryResult.setIssuerInfoCorpName(""); // (조회결과)발행인정보-법인명
 * queryResult.setIssuerInfoNameRepresentativeName(""); // (조회결과)발행인정보-성명(대표자명)
 * queryResult.setIssuerInfoAddress(""); // (조회결과)발행인정보-주소
 * queryResult.setIssuerInfoBankCode(""); // (조회결과)발행인정보-은행코드
 * queryResult.setIssuerInfoDepositAccountNumber(""); // (조회결과)발행인정보-입금계좌번호
 * queryResult.setBeneInfoCorpIndvSort(""); // (조회결과)수취인인정보-개인법인구분
 * queryResult.setBeneInfoResidentBusinessNumber(""); // (조회결과)수취인인정보-주민사업자번호
 * queryResult.setBeneInfoCorpName(""); // (조회결과)수취인인정보-법인명
 * queryResult.setBeneInfoNameRepresentativeName(""); // (조회결과)수취인인정보-성명(대표자명)
 * queryResult.setBeneInfoAddress(""); // (조회결과)수취인인정보-주소
 * queryResult.setBeneInfoBankCode(""); // (조회결과)수취인인정보-은행코드
 * queryResult.setBeneInfoDepositAccountNumber(""); // (조회결과)수취인인정보-계좌번호
 * queryResult.setProhibitedInstructionYn(""); // (조회결과)지시금지여부
 * queryResult.setIssuanceGuaranteeYn(""); // (조회결과)발행보증여부
 * queryResult.setBeforeAfterIssueSort(""); // (조회결과)발행전후구분
 * queryResult.setIssuanceGuarantorCorpIndvSort(""); // (조회결과)발행보증인-개인법인구분
 * queryResult.setIssuanceGuarantorResidentBusinessNumber(""); // (조회결과)발행보증인-주민사업자번호
 * queryResult.setIssuanceGuarantorCorpName(""); // (조회결과)발행보증인-법인명
 * queryResult.setIssuanceGuarantorNameRepresentativeName(""); // (조회결과)발행보증인-성명(대표자명)
 * queryResult.setIssuanceGuarantorAddress(""); // (조회결과)발행보증인-주소
 * queryResult.setIssuanceGuarantorBankCode(""); // (조회결과)발행보증인-은행코드
 * queryResult.setIssuanceGuarantorCurrentAccountNumber(""); // (조회결과)발행보증인-당좌계좌번호
 * kftEnt0200401000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0200401000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * noteInfoEnoteNumber (조회결과)어음정보-01전자어음번호 
	 * noteInfoEnoteType (조회결과)어음정보-02어음종류 
	 * noteInfoEnoteProcessStatus (조회결과)어음정보-03전자어음처리상태 
	 * noteInfoEnoteIssueDate (조회결과)어음정보-04전자어음발행일자 
	 * noteInfoEnoteIssuePlace (조회결과)어음정보-05전자어음발행지 
	 * noteInfoEnoteAmount (조회결과)어음정보-06전자어음금액 
	 * noteInfoDefaultReasonCode (조회결과)어음정보-부도사유코드 
	 * noteInfoEnoteMaturedDate (조회결과)어음정보-전자어음만기일자 
	 * noteInfoEnoteInitialdefaultProcessingDate (조회결과)어음정보-전자어음최초부도처리일자 
	 * noteInfoEnoteFinalSettlementDate (조회결과)어음정보-전자어음최종결제일자 
	 * noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
	 * issuerInfoCorpIndvSort (조회결과)발행인정보-개인법인구분 
	 * issuerInfoResidentBusinessNumber (조회결과)발행인정보-주민사업자번호 
	 * issuerInfoCorpName (조회결과)발행인정보-법인명 
	 * issuerInfoNameRepresentativeName (조회결과)발행인정보-성명(대표자명) 
	 * issuerInfoAddress (조회결과)발행인정보-주소 
	 * issuerInfoBankCode (조회결과)발행인정보-은행코드 
	 * issuerInfoDepositAccountNumber (조회결과)발행인정보-입금계좌번호 
	 * beneInfoCorpIndvSort (조회결과)수취인인정보-개인법인구분 
	 * beneInfoResidentBusinessNumber (조회결과)수취인인정보-주민사업자번호 
	 * beneInfoCorpName (조회결과)수취인인정보-법인명 
	 * beneInfoNameRepresentativeName (조회결과)수취인인정보-성명(대표자명) 
	 * beneInfoAddress (조회결과)수취인인정보-주소 
	 * beneInfoBankCode (조회결과)수취인인정보-은행코드 
	 * beneInfoDepositAccountNumber (조회결과)수취인인정보-계좌번호 
	 * prohibitedInstructionYn (조회결과)지시금지여부 
	 * issuanceGuaranteeYn (조회결과)발행보증여부 
	 * beforeAfterIssueSort (조회결과)발행전후구분 
	 * issuanceGuarantorCorpIndvSort (조회결과)발행보증인-개인법인구분 
	 * issuanceGuarantorResidentBusinessNumber (조회결과)발행보증인-주민사업자번호 
	 * issuanceGuarantorCorpName (조회결과)발행보증인-법인명 
	 * issuanceGuarantorNameRepresentativeName (조회결과)발행보증인-성명(대표자명) 
	 * issuanceGuarantorAddress (조회결과)발행보증인-주소 
	 * issuanceGuarantorBankCode (조회결과)발행보증인-은행코드 
	 * issuanceGuarantorCurrentAccountNumber (조회결과)발행보증인-당좌계좌번호 
	 * 
	 * KftEnt0200401000.QueryResult queryResult = new KftEnt0200401000.QueryResult(); // 조회결과Array
	 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-01전자어음번호
	 * queryResult.setNoteInfoEnoteType(""); // (조회결과)어음정보-02어음종류
	 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-03전자어음처리상태
	 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-04전자어음발행일자
	 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-05전자어음발행지
	 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-06전자어음금액
	 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-부도사유코드
	 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-전자어음만기일자
	 * queryResult.setNoteInfoEnoteInitialdefaultProcessingDate(""); // (조회결과)어음정보-전자어음최초부도처리일자
	 * queryResult.setNoteInfoEnoteFinalSettlementDate(""); // (조회결과)어음정보-전자어음최종결제일자
	 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
	 * queryResult.setIssuerInfoCorpIndvSort(""); // (조회결과)발행인정보-개인법인구분
	 * queryResult.setIssuerInfoResidentBusinessNumber(""); // (조회결과)발행인정보-주민사업자번호
	 * queryResult.setIssuerInfoCorpName(""); // (조회결과)발행인정보-법인명
	 * queryResult.setIssuerInfoNameRepresentativeName(""); // (조회결과)발행인정보-성명(대표자명)
	 * queryResult.setIssuerInfoAddress(""); // (조회결과)발행인정보-주소
	 * queryResult.setIssuerInfoBankCode(""); // (조회결과)발행인정보-은행코드
	 * queryResult.setIssuerInfoDepositAccountNumber(""); // (조회결과)발행인정보-입금계좌번호
	 * queryResult.setBeneInfoCorpIndvSort(""); // (조회결과)수취인인정보-개인법인구분
	 * queryResult.setBeneInfoResidentBusinessNumber(""); // (조회결과)수취인인정보-주민사업자번호
	 * queryResult.setBeneInfoCorpName(""); // (조회결과)수취인인정보-법인명
	 * queryResult.setBeneInfoNameRepresentativeName(""); // (조회결과)수취인인정보-성명(대표자명)
	 * queryResult.setBeneInfoAddress(""); // (조회결과)수취인인정보-주소
	 * queryResult.setBeneInfoBankCode(""); // (조회결과)수취인인정보-은행코드
	 * queryResult.setBeneInfoDepositAccountNumber(""); // (조회결과)수취인인정보-계좌번호
	 * queryResult.setProhibitedInstructionYn(""); // (조회결과)지시금지여부
	 * queryResult.setIssuanceGuaranteeYn(""); // (조회결과)발행보증여부
	 * queryResult.setBeforeAfterIssueSort(""); // (조회결과)발행전후구분
	 * queryResult.setIssuanceGuarantorCorpIndvSort(""); // (조회결과)발행보증인-개인법인구분
	 * queryResult.setIssuanceGuarantorResidentBusinessNumber(""); // (조회결과)발행보증인-주민사업자번호
	 * queryResult.setIssuanceGuarantorCorpName(""); // (조회결과)발행보증인-법인명
	 * queryResult.setIssuanceGuarantorNameRepresentativeName(""); // (조회결과)발행보증인-성명(대표자명)
	 * queryResult.setIssuanceGuarantorAddress(""); // (조회결과)발행보증인-주소
	 * queryResult.setIssuanceGuarantorBankCode(""); // (조회결과)발행보증인-은행코드
	 * queryResult.setIssuanceGuarantorCurrentAccountNumber(""); // (조회결과)발행보증인-당좌계좌번호
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String noteInfoEnoteNumber; // (조회결과)어음정보-01전자어음번호
		private String noteInfoEnoteType; // (조회결과)어음정보-02어음종류
		private String noteInfoEnoteProcessStatus; // (조회결과)어음정보-03전자어음처리상태
		private String noteInfoEnoteIssueDate; // (조회결과)어음정보-04전자어음발행일자
		private String noteInfoEnoteIssuePlace; // (조회결과)어음정보-05전자어음발행지
		private long noteInfoEnoteAmount; // (조회결과)어음정보-06전자어음금액
		private String noteInfoDefaultReasonCode; // (조회결과)어음정보-부도사유코드
		private String noteInfoEnoteMaturedDate; // (조회결과)어음정보-전자어음만기일자
		private String noteInfoEnoteInitialdefaultProcessingDate; // (조회결과)어음정보-전자어음최초부도처리일자
		private String noteInfoEnoteFinalSettlementDate; // (조회결과)어음정보-전자어음최종결제일자
		private String noteInfoPaymentBankAndBranchCode; // (조회결과)어음정보-지급은행및점포코드
		private String issuerInfoCorpIndvSort; // (조회결과)발행인정보-개인법인구분
		private String issuerInfoResidentBusinessNumber; // (조회결과)발행인정보-주민사업자번호
		private String issuerInfoCorpName; // (조회결과)발행인정보-법인명
		private String issuerInfoNameRepresentativeName; // (조회결과)발행인정보-성명(대표자명)
		private String issuerInfoAddress; // (조회결과)발행인정보-주소
		private String issuerInfoBankCode; // (조회결과)발행인정보-은행코드
		private String issuerInfoDepositAccountNumber; // (조회결과)발행인정보-입금계좌번호
		private String beneInfoCorpIndvSort; // (조회결과)수취인인정보-개인법인구분
		private String beneInfoResidentBusinessNumber; // (조회결과)수취인인정보-주민사업자번호
		private String beneInfoCorpName; // (조회결과)수취인인정보-법인명
		private String beneInfoNameRepresentativeName; // (조회결과)수취인인정보-성명(대표자명)
		private String beneInfoAddress; // (조회결과)수취인인정보-주소
		private String beneInfoBankCode; // (조회결과)수취인인정보-은행코드
		private String beneInfoDepositAccountNumber; // (조회결과)수취인인정보-계좌번호
		private String prohibitedInstructionYn; // (조회결과)지시금지여부
		private String issuanceGuaranteeYn; // (조회결과)발행보증여부
		private String beforeAfterIssueSort; // (조회결과)발행전후구분
		private String issuanceGuarantorCorpIndvSort; // (조회결과)발행보증인-개인법인구분
		private String issuanceGuarantorResidentBusinessNumber; // (조회결과)발행보증인-주민사업자번호
		private String issuanceGuarantorCorpName; // (조회결과)발행보증인-법인명
		private String issuanceGuarantorNameRepresentativeName; // (조회결과)발행보증인-성명(대표자명)
		private String issuanceGuarantorAddress; // (조회결과)발행보증인-주소
		private String issuanceGuarantorBankCode; // (조회결과)발행보증인-은행코드
		private String issuanceGuarantorCurrentAccountNumber; // (조회결과)발행보증인-당좌계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteNumber$; // (조회결과)어음정보-01전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteType$; // (조회결과)어음정보-02어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteProcessStatus$; // (조회결과)어음정보-03전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssueDate$; // (조회결과)어음정보-04전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssuePlace$; // (조회결과)어음정보-05전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteAmount$; // (조회결과)어음정보-06전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoDefaultReasonCode$; // (조회결과)어음정보-부도사유코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteMaturedDate$; // (조회결과)어음정보-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteInitialdefaultProcessingDate$; // (조회결과)어음정보-전자어음최초부도처리일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteFinalSettlementDate$; // (조회결과)어음정보-전자어음최종결제일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoPaymentBankAndBranchCode$; // (조회결과)어음정보-지급은행및점포코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoCorpIndvSort$; // (조회결과)발행인정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoResidentBusinessNumber$; // (조회결과)발행인정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoCorpName$; // (조회결과)발행인정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoNameRepresentativeName$; // (조회결과)발행인정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoAddress$; // (조회결과)발행인정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoBankCode$; // (조회결과)발행인정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoDepositAccountNumber$; // (조회결과)발행인정보-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoCorpIndvSort$; // (조회결과)수취인인정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoResidentBusinessNumber$; // (조회결과)수취인인정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoCorpName$; // (조회결과)수취인인정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoNameRepresentativeName$; // (조회결과)수취인인정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoAddress$; // (조회결과)수취인인정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoBankCode$; // (조회결과)수취인인정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneInfoDepositAccountNumber$; // (조회결과)수취인인정보-계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String prohibitedInstructionYn$; // (조회결과)지시금지여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeYn$; // (조회결과)발행보증여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beforeAfterIssueSort$; // (조회결과)발행전후구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorCorpIndvSort$; // (조회결과)발행보증인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorResidentBusinessNumber$; // (조회결과)발행보증인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorCorpName$; // (조회결과)발행보증인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorNameRepresentativeName$; // (조회결과)발행보증인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorAddress$; // (조회결과)발행보증인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorBankCode$; // (조회결과)발행보증인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorCurrentAccountNumber$; // (조회결과)발행보증인-당좌계좌번호

		@Override
		public void write(OutputStream out) throws IOException {
			noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // (조회결과)어음정보-01전자어음번호
			noteInfoEnoteType$ = VOUtils.write(out, noteInfoEnoteType, 1); // (조회결과)어음정보-02어음종류
			noteInfoEnoteProcessStatus$ = VOUtils.write(out, noteInfoEnoteProcessStatus, 2); // (조회결과)어음정보-03전자어음처리상태
			noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // (조회결과)어음정보-04전자어음발행일자
			noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음정보-05전자어음발행지
			noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // (조회결과)어음정보-06전자어음금액
			noteInfoDefaultReasonCode$ = VOUtils.write(out, noteInfoDefaultReasonCode, 2); // (조회결과)어음정보-부도사유코드
			noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // (조회결과)어음정보-전자어음만기일자
			noteInfoEnoteInitialdefaultProcessingDate$ = VOUtils.write(out, noteInfoEnoteInitialdefaultProcessingDate, 8); // (조회결과)어음정보-전자어음최초부도처리일자
			noteInfoEnoteFinalSettlementDate$ = VOUtils.write(out, noteInfoEnoteFinalSettlementDate, 8); // (조회결과)어음정보-전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode$ = VOUtils.write(out, noteInfoPaymentBankAndBranchCode, 7); // (조회결과)어음정보-지급은행및점포코드
			issuerInfoCorpIndvSort$ = VOUtils.write(out, issuerInfoCorpIndvSort, 1); // (조회결과)발행인정보-개인법인구분
			issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // (조회결과)발행인정보-주민사업자번호
			issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // (조회결과)발행인정보-법인명
			issuerInfoNameRepresentativeName$ = VOUtils.write(out, issuerInfoNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인정보-성명(대표자명)
			issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // (조회결과)발행인정보-주소
			issuerInfoBankCode$ = VOUtils.write(out, issuerInfoBankCode, 3); // (조회결과)발행인정보-은행코드
			issuerInfoDepositAccountNumber$ = VOUtils.write(out, issuerInfoDepositAccountNumber, 16); // (조회결과)발행인정보-입금계좌번호
			beneInfoCorpIndvSort$ = VOUtils.write(out, beneInfoCorpIndvSort, 1); // (조회결과)수취인인정보-개인법인구분
			beneInfoResidentBusinessNumber$ = VOUtils.write(out, beneInfoResidentBusinessNumber, 13); // (조회결과)수취인인정보-주민사업자번호
			beneInfoCorpName$ = VOUtils.write(out, beneInfoCorpName, 40, "EUC-KR"); // (조회결과)수취인인정보-법인명
			beneInfoNameRepresentativeName$ = VOUtils.write(out, beneInfoNameRepresentativeName, 20, "EUC-KR"); // (조회결과)수취인인정보-성명(대표자명)
			beneInfoAddress$ = VOUtils.write(out, beneInfoAddress, 60, "EUC-KR"); // (조회결과)수취인인정보-주소
			beneInfoBankCode$ = VOUtils.write(out, beneInfoBankCode, 3); // (조회결과)수취인인정보-은행코드
			beneInfoDepositAccountNumber$ = VOUtils.write(out, beneInfoDepositAccountNumber, 16); // (조회결과)수취인인정보-계좌번호
			prohibitedInstructionYn$ = VOUtils.write(out, prohibitedInstructionYn, 1); // (조회결과)지시금지여부
			issuanceGuaranteeYn$ = VOUtils.write(out, issuanceGuaranteeYn, 1); // (조회결과)발행보증여부
			beforeAfterIssueSort$ = VOUtils.write(out, beforeAfterIssueSort, 1); // (조회결과)발행전후구분
			issuanceGuarantorCorpIndvSort$ = VOUtils.write(out, issuanceGuarantorCorpIndvSort, 1); // (조회결과)발행보증인-개인법인구분
			issuanceGuarantorResidentBusinessNumber$ = VOUtils.write(out, issuanceGuarantorResidentBusinessNumber, 13); // (조회결과)발행보증인-주민사업자번호
			issuanceGuarantorCorpName$ = VOUtils.write(out, issuanceGuarantorCorpName, 40, "EUC-KR"); // (조회결과)발행보증인-법인명
			issuanceGuarantorNameRepresentativeName$ = VOUtils.write(out, issuanceGuarantorNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행보증인-성명(대표자명)
			issuanceGuarantorAddress$ = VOUtils.write(out, issuanceGuarantorAddress, 60, "EUC-KR"); // (조회결과)발행보증인-주소
			issuanceGuarantorBankCode$ = VOUtils.write(out, issuanceGuarantorBankCode, 3); // (조회결과)발행보증인-은행코드
			issuanceGuarantorCurrentAccountNumber$ = VOUtils.write(out, issuanceGuarantorCurrentAccountNumber, 16); // (조회결과)발행보증인-당좌계좌번호
		}

		@Override
		public void read(InputStream in) throws IOException {
			noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음정보-01전자어음번호
			noteInfoEnoteType = VOUtils.toString(noteInfoEnoteType$ = VOUtils.read(in, 1)); // (조회결과)어음정보-02어음종류
			noteInfoEnoteProcessStatus = VOUtils.toString(noteInfoEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음정보-03전자어음처리상태
			noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-04전자어음발행일자
			noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음정보-05전자어음발행지
			noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음정보-06전자어음금액
			noteInfoDefaultReasonCode = VOUtils.toString(noteInfoDefaultReasonCode$ = VOUtils.read(in, 2)); // (조회결과)어음정보-부도사유코드
			noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음만기일자
			noteInfoEnoteInitialdefaultProcessingDate = VOUtils.toString(noteInfoEnoteInitialdefaultProcessingDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음최초부도처리일자
			noteInfoEnoteFinalSettlementDate = VOUtils.toString(noteInfoEnoteFinalSettlementDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode = VOUtils.toString(noteInfoPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음정보-지급은행및점포코드
			issuerInfoCorpIndvSort = VOUtils.toString(issuerInfoCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인정보-개인법인구분
			issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인정보-주민사업자번호
			issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인정보-법인명
			issuerInfoNameRepresentativeName = VOUtils.toString(issuerInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인정보-성명(대표자명)
			issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인정보-주소
			issuerInfoBankCode = VOUtils.toString(issuerInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행인정보-은행코드
			issuerInfoDepositAccountNumber = VOUtils.toString(issuerInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행인정보-입금계좌번호
			beneInfoCorpIndvSort = VOUtils.toString(beneInfoCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)수취인인정보-개인법인구분
			beneInfoResidentBusinessNumber = VOUtils.toString(beneInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)수취인인정보-주민사업자번호
			beneInfoCorpName = VOUtils.toString(beneInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)수취인인정보-법인명
			beneInfoNameRepresentativeName = VOUtils.toString(beneInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)수취인인정보-성명(대표자명)
			beneInfoAddress = VOUtils.toString(beneInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)수취인인정보-주소
			beneInfoBankCode = VOUtils.toString(beneInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)수취인인정보-은행코드
			beneInfoDepositAccountNumber = VOUtils.toString(beneInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)수취인인정보-계좌번호
			prohibitedInstructionYn = VOUtils.toString(prohibitedInstructionYn$ = VOUtils.read(in, 1)); // (조회결과)지시금지여부
			issuanceGuaranteeYn = VOUtils.toString(issuanceGuaranteeYn$ = VOUtils.read(in, 1)); // (조회결과)발행보증여부
			beforeAfterIssueSort = VOUtils.toString(beforeAfterIssueSort$ = VOUtils.read(in, 1)); // (조회결과)발행전후구분
			issuanceGuarantorCorpIndvSort = VOUtils.toString(issuanceGuarantorCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행보증인-개인법인구분
			issuanceGuarantorResidentBusinessNumber = VOUtils.toString(issuanceGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행보증인-주민사업자번호
			issuanceGuarantorCorpName = VOUtils.toString(issuanceGuarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행보증인-법인명
			issuanceGuarantorNameRepresentativeName = VOUtils.toString(issuanceGuarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행보증인-성명(대표자명)
			issuanceGuarantorAddress = VOUtils.toString(issuanceGuarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행보증인-주소
			issuanceGuarantorBankCode = VOUtils.toString(issuanceGuarantorBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행보증인-은행코드
			issuanceGuarantorCurrentAccountNumber = VOUtils.toString(issuanceGuarantorCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행보증인-당좌계좌번호
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // (조회결과)어음정보-01전자어음번호
			sb.append(", noteInfoEnoteType=").append(noteInfoEnoteType).append(System.lineSeparator()); // (조회결과)어음정보-02어음종류
			sb.append(", noteInfoEnoteProcessStatus=").append(noteInfoEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음정보-03전자어음처리상태
			sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음정보-04전자어음발행일자
			sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음정보-05전자어음발행지
			sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // (조회결과)어음정보-06전자어음금액
			sb.append(", noteInfoDefaultReasonCode=").append(noteInfoDefaultReasonCode).append(System.lineSeparator()); // (조회결과)어음정보-부도사유코드
			sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음만기일자
			sb.append(", noteInfoEnoteInitialdefaultProcessingDate=").append(noteInfoEnoteInitialdefaultProcessingDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음최초부도처리일자
			sb.append(", noteInfoEnoteFinalSettlementDate=").append(noteInfoEnoteFinalSettlementDate).append(System.lineSeparator()); // (조회결과)어음정보-전자어음최종결제일자
			sb.append(", noteInfoPaymentBankAndBranchCode=").append(noteInfoPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음정보-지급은행및점포코드
			sb.append(", issuerInfoCorpIndvSort=").append(issuerInfoCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인정보-개인법인구분
			sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인정보-주민사업자번호
			sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // (조회결과)발행인정보-법인명
			sb.append(", issuerInfoNameRepresentativeName=").append(issuerInfoNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인정보-성명(대표자명)
			sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // (조회결과)발행인정보-주소
			sb.append(", issuerInfoBankCode=").append(issuerInfoBankCode).append(System.lineSeparator()); // (조회결과)발행인정보-은행코드
			sb.append(", issuerInfoDepositAccountNumber=").append(issuerInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)발행인정보-입금계좌번호
			sb.append(", beneInfoCorpIndvSort=").append(beneInfoCorpIndvSort).append(System.lineSeparator()); // (조회결과)수취인인정보-개인법인구분
			sb.append(", beneInfoResidentBusinessNumber=").append(beneInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)수취인인정보-주민사업자번호
			sb.append(", beneInfoCorpName=").append(beneInfoCorpName).append(System.lineSeparator()); // (조회결과)수취인인정보-법인명
			sb.append(", beneInfoNameRepresentativeName=").append(beneInfoNameRepresentativeName).append(System.lineSeparator()); // (조회결과)수취인인정보-성명(대표자명)
			sb.append(", beneInfoAddress=").append(beneInfoAddress).append(System.lineSeparator()); // (조회결과)수취인인정보-주소
			sb.append(", beneInfoBankCode=").append(beneInfoBankCode).append(System.lineSeparator()); // (조회결과)수취인인정보-은행코드
			sb.append(", beneInfoDepositAccountNumber=").append(beneInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)수취인인정보-계좌번호
			sb.append(", prohibitedInstructionYn=").append(prohibitedInstructionYn).append(System.lineSeparator()); // (조회결과)지시금지여부
			sb.append(", issuanceGuaranteeYn=").append(issuanceGuaranteeYn).append(System.lineSeparator()); // (조회결과)발행보증여부
			sb.append(", beforeAfterIssueSort=").append(beforeAfterIssueSort).append(System.lineSeparator()); // (조회결과)발행전후구분
			sb.append(", issuanceGuarantorCorpIndvSort=").append(issuanceGuarantorCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행보증인-개인법인구분
			sb.append(", issuanceGuarantorResidentBusinessNumber=").append(issuanceGuarantorResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행보증인-주민사업자번호
			sb.append(", issuanceGuarantorCorpName=").append(issuanceGuarantorCorpName).append(System.lineSeparator()); // (조회결과)발행보증인-법인명
			sb.append(", issuanceGuarantorNameRepresentativeName=").append(issuanceGuarantorNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행보증인-성명(대표자명)
			sb.append(", issuanceGuarantorAddress=").append(issuanceGuarantorAddress).append(System.lineSeparator()); // (조회결과)발행보증인-주소
			sb.append(", issuanceGuarantorBankCode=").append(issuanceGuarantorBankCode).append(System.lineSeparator()); // (조회결과)발행보증인-은행코드
			sb.append(", issuanceGuarantorCurrentAccountNumber=").append(issuanceGuarantorCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행보증인-당좌계좌번호
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "401000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String sortCondition; // 정렬조건
	private String searchConditionSort; // 검색조건구분
	private String queryPeriodBasisSort; // 조회기간기준구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String currentAccountNumber; // 당좌계좌번호
	private String queryStartDate; // 조회시작일
	private String queryEndDate; // 조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0200401000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sortCondition$; // 정렬조건
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String queryPeriodBasisSort$; // 조회기간기준구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentAccountNumber$; // 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String queryStartDate$; // 조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String queryEndDate$; // 조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(currentAccountNumber$)) { // 당좌계좌번호
			return 18;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		sortCondition$ = VOUtils.write(out, sortCondition, 2); // 정렬조건
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		queryPeriodBasisSort$ = VOUtils.write(out, queryPeriodBasisSort, 1); // 조회기간기준구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentAccountNumber$ = VOUtils.write(out, currentAccountNumber, 16); // 당좌계좌번호
		queryStartDate$ = VOUtils.write(out, queryStartDate, 8); // 조회시작일
		queryEndDate$ = VOUtils.write(out, queryEndDate, 8); // 조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0200401000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		sortCondition = VOUtils.toString(sortCondition$ = VOUtils.read(in, 2)); // 정렬조건
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		queryPeriodBasisSort = VOUtils.toString(queryPeriodBasisSort$ = VOUtils.read(in, 1)); // 조회기간기준구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentAccountNumber = VOUtils.toString(currentAccountNumber$ = VOUtils.read(in, 16)); // 당좌계좌번호
		queryStartDate = VOUtils.toString(queryStartDate$ = VOUtils.read(in, 8)); // 조회시작일
		queryEndDate = VOUtils.toString(queryEndDate$ = VOUtils.read(in, 8)); // 조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0200401000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", sortCondition=").append(sortCondition).append(System.lineSeparator()); // 정렬조건
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", queryPeriodBasisSort=").append(queryPeriodBasisSort).append(System.lineSeparator()); // 조회기간기준구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentAccountNumber=").append(currentAccountNumber).append(System.lineSeparator()); // 당좌계좌번호
		sb.append(", queryStartDate=").append(queryStartDate).append(System.lineSeparator()); // 조회시작일
		sb.append(", queryEndDate=").append(queryEndDate).append(System.lineSeparator()); // 조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "401000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "sortCondition", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "queryPeriodBasisSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "queryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "queryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteInitialdefaultProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteFinalSettlementDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneInfoCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prohibitedInstructionYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeAfterIssueSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorCurrentAccountNumber", "fldLen", "16", "defltVal", "")
		);
	}

}
