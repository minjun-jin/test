package com.jpmc.kcg.web.sim.dao;

import org.apache.ibatis.annotations.Mapper;

import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileL;

@Mapper
public interface SimCmsSndRcvFileLDao {
	void insertSimCmsSndRcvFileL(SimCmsSndRcvFileL in);
	void deleteSimCmsSndRcvFileL(SimCmsSndRcvFileL in);
	int updateSimCmsSndRcvFileL(SimCmsSndRcvFileL in);
}
