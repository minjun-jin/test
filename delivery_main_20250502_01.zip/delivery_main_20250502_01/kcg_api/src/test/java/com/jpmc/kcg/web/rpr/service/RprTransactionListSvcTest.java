package com.jpmc.kcg.web.rpr.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.rpr.dto.RprTrL;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.rpr.dao.RprTrLWebDao;
import com.jpmc.kcg.web.rpr.dto.SelectListRprTrDaoIn;
import com.jpmc.kcg.web.rpr.dto.SelectRprTrDetailSumDaoOut;
import com.jpmc.kcg.web.rpr.service.dto.GetListRprTransactionIn;
import com.jpmc.kcg.web.rpr.service.dto.GetListRprTransactionOut;
import com.jpmc.kcg.web.rpr.service.dto.GetRprTransactionOut;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(OrderAnnotation.class)
class RprTransactionListSvcTest {

	@Mock
	private RprTrLWebDao rprTrLWebDao;
	
	@Mock
	private BizCom bizCom;
	
    private static MockedStatic<WebApplicationContext> webApplicationContext;
	
	@InjectMocks
	private RprTransactionListSvc rprTransactionListSvc;
	
	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}
	
    @AfterAll
    static void tearDown() {
        if (webApplicationContext != null) {
            webApplicationContext.close();
        }
    }

	
    @Test
    @Order(1)
    public void testGetListRprTransaction_001() {
    	
        // Given
    	GetListRprTransactionIn input = new GetListRprTransactionIn(); 
        input.setTrStrDt("2024-09-24");
        input.setTrEndDt("2024-09-24");
        
        SelectListRprTrDaoIn daoIn = new SelectListRprTrDaoIn();
        daoIn.setTrStrDt(input.getTrStrDt());
        daoIn.setTrEndDt(input.getTrEndDt());
        
		List<RprTrL> listInfoOut = new ArrayList<RprTrL>();
		
		RprTrL listInfo = new RprTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("01");
		listInfo.setIncmpltYn("Y");

        listInfoOut.add(listInfo);
        
        
        SelectRprTrDetailSumDaoOut sumOut = new SelectRprTrDetailSumDaoOut();
        sumOut.setClaimNormalAmt(new BigDecimal("10000"));
        sumOut.setClaimNormalCnt(1);
        
        // When: 목 객체로 DAO 메서드의 동작을 설정
        when(rprTrLWebDao.selectListRprTrCnt(any(SelectListRprTrDaoIn.class))).thenReturn(10);
        when(rprTrLWebDao.selectRprTransactionDetailSum(any(SelectListRprTrDaoIn.class))).thenReturn(sumOut);
        
        // 메서드 실행
        GetListRprTransactionOut result = rprTransactionListSvc.getListRprTransaction(input);

        // Then: 결과 값 검증
        assertNotNull(result);
        assertEquals(10, result.getTotCnt());
        
        System.out.println("성공 조회건수 === " + result.getTotCnt());
        
        // DAO 메서드가 호출되었는지 확인
        verify(rprTrLWebDao, times(1)).selectListRprTrCnt(any(SelectListRprTrDaoIn.class));
        verify(rprTrLWebDao, times(1)).selectRprTransactionDetailSum(any(SelectListRprTrDaoIn.class));
    }

	
    @Test
    @Order(2)
    public void testGetListRprTransaction_002() {
    	
        // Given
    	GetListRprTransactionIn input = new GetListRprTransactionIn(); 
    	
    	// 거래 시작일,종료일을 설정하지 않음

        // When
        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	rprTransactionListSvc.getListRprTransaction(input);
        });

        // Then: BusinessException 예외가 발생해야 함
        assertTrue("MCMNI01003".contains(exception.getErrorCode()));
        System.out.println("에러 MCMNI01003 === " + exception.getErrorCode());
    }
    
    @Test
    @Order(3)
    void getListRprTransaction_respCd_1정상코드() {
        GetListRprTransactionIn input = new GetListRprTransactionIn();
        input.setTrStrDt("20240101");
        input.setTrEndDt("20240101");
        input.setRespCd("1");

        mockRprListAndSum();

        GetListRprTransactionOut result = rprTransactionListSvc.getListRprTransaction(input);
        assertEquals(1, result.getTotCnt());
    }

    @Test
    @Order(4)
    void getListRprTransaction_respCd_2에러코드() {
        GetListRprTransactionIn input = new GetListRprTransactionIn();
        input.setTrStrDt("20240101");
        input.setTrEndDt("20240101");
        input.setRespCd("2");

        mockRprListAndSum();

        GetListRprTransactionOut result = rprTransactionListSvc.getListRprTransaction(input);
        assertEquals(1, result.getTotCnt());
    }

    @Test
    @Order(5)
    void getListRprTransaction_respCd_3미응답() {
        GetListRprTransactionIn input = new GetListRprTransactionIn();
        input.setTrStrDt("20240101");
        input.setTrEndDt("20240101");
        input.setRespCd("3");

        mockRprListAndSum();

        GetListRprTransactionOut result = rprTransactionListSvc.getListRprTransaction(input);
        assertEquals(1, result.getTotCnt());
    }

    @Test
    @Order(6)
    void getListRprTransaction_respCd_null() {
        GetListRprTransactionIn input = new GetListRprTransactionIn();
        input.setTrStrDt("20240101");
        input.setTrEndDt("20240101");
        input.setRespCd(null);

        mockRprListAndSum();

        GetListRprTransactionOut result = rprTransactionListSvc.getListRprTransaction(input);
        assertEquals(1, result.getTotCnt());
    }
    
    @Test
    @Order(7)
    void getCdNm_정상조회() {
        ComRespCdM dummyResp = new ComRespCdM();
        dummyResp.setRespCdNm("성공");

        when(bizCom.getRespCode(any(), any(), any())).thenReturn(dummyResp);

        ComRespCdM result = rprTransactionListSvc._getCdNm("00");
        assertEquals("성공", result.getRespCdNm());
    }

    @Test
    @Order(8)
    void setOutputDto_필드매핑확인() {
        RprTrL rprTrL = new RprTrL();
        rprTrL.setTrDt("20240101");
        rprTrL.setTlgKndDvsnCd("02");
        rprTrL.setTlgTrDvsnCd("100000");
        rprTrL.setHndlAgncFee(100L);

        GetRprTransactionOut result = rprTransactionListSvc._setOutputDto(rprTrL);

        assertEquals("20240101", result.getTrDt());
        assertEquals("02100000", result.getTlgKndTrDvsnCd());
    }


	private void mockRprListAndSum() {
	    RprTrL rprTrL = new RprTrL();
	    rprTrL.setTrDt("20240101");
	    rprTrL.setRespCd("00");
        rprTrL.setHndlAgncFee(100L);
        
	    ComRespCdM resp = new ComRespCdM();
	    resp.setRespCdEngNm("Success");
	    resp.setRespCdNm("성공");
	
	    when(rprTrLWebDao.selectListRprTrCnt(any())).thenReturn(1);
	    when(rprTrLWebDao.selectListRprTr(any())).thenReturn(List.of(rprTrL));
	    when(rprTrLWebDao.selectRprTransactionDetailSum(any())).thenReturn(new SelectRprTrDetailSumDaoOut());
	    when(bizCom.getRespCode(any(), any(), any())).thenReturn(resp);
	}




}
