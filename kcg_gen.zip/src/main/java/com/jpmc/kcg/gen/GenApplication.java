package com.jpmc.kcg.gen;

import org.apache.commons.lang3.StringUtils;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.FullyQualifiedAnnotationBeanNameGenerator;

import com.jpmc.kcg.com.dao.ComMapper;
import com.jpmc.kcg.com.dto.ComFileLaytM;
import com.jpmc.kcg.com.dto.ComTlgLaytM;
import com.jpmc.kcg.gen.dao.GenMapper;

@MapperScan(basePackageClasses = {
	ComMapper.class,
	GenMapper.class,
}, nameGenerator = FullyQualifiedAnnotationBeanNameGenerator.class)
@SpringBootApplication(scanBasePackageClasses = {
	GenApplication.class,
})
public class GenApplication implements CommandLineRunner {

	@Autowired
	private GenMapper genMapper;
	@Autowired
	private VoZipGenerator voZipGenerator;

	@Override
	public void run(String... args) throws Exception {
		for (ComFileLaytM comFileLaytM : genMapper.selectComFileLaytMList()) {
			voZipGenerator.generateFileVo(comFileLaytM, "H");
			voZipGenerator.generateFileVoTest(comFileLaytM, "H");
			if (StringUtils.endsWith(comFileLaytM.getFileLaytId(), "CMSEB90")) {
				voZipGenerator.generateFileVo(comFileLaytM, "RA");
				voZipGenerator.generateFileVo(comFileLaytM, "RB");
				voZipGenerator.generateFileVo(comFileLaytM, "RC");
				voZipGenerator.generateFileVo(comFileLaytM, "RD");
				voZipGenerator.generateFileVo(comFileLaytM, "RE");
				voZipGenerator.generateFileVoTest(comFileLaytM, "RA");
				voZipGenerator.generateFileVoTest(comFileLaytM, "RB");
				voZipGenerator.generateFileVoTest(comFileLaytM, "RC");
				voZipGenerator.generateFileVoTest(comFileLaytM, "RD");
				voZipGenerator.generateFileVoTest(comFileLaytM, "RE");
			} else {
				voZipGenerator.generateFileVo(comFileLaytM, "R");
				voZipGenerator.generateFileVoTest(comFileLaytM, "R");
			}
			voZipGenerator.generateFileVo(comFileLaytM, "T");
			voZipGenerator.generateFileVoTest(comFileLaytM, "T");
		}
		for (ComTlgLaytM comTlgLaytM : genMapper.selectComTlgLaytMList()) {
			voZipGenerator.generateVo(comTlgLaytM);
			voZipGenerator.generateVoTest(comTlgLaytM);
		}
//		{
//			byte[] byteArray = voZipGenerator.generateVoZip("KFTENT0210420000");
//			File file = FileUtils.getFile("KFTENT0210420000.zip");
//			FileUtils.writeByteArrayToFile(file, byteArray);
//		}
//		{
//			byte[] byteArray = voZipGenerator.generateFileVoZip("FENTES1113");
//			File file = FileUtils.getFile("FENTES1113.zip");
//			FileUtils.writeByteArrayToFile(file, byteArray);
//		}
	}

	public static void main(String[] args) {
		SpringApplication.run(GenApplication.class, args);
	}

}
