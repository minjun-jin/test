import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// UHOFINQ020 컴포넌트를 불러옵니다.
import UHOFINQ020 from "@/pages/views/hof/UHOFINQ-020"
import { Component } from "@/hoc/TestUtil"

const component = Component(UHOFINQ020)

describe("[UHOFINQ-020] 순이체한도조회(차트)", () => {
  it("searchListHofNetDebitCap Test", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each([
    {
      mocking: () => {
        mockUseForm.mockGetValues.mockImplementation((key) => {
          if (key === "inqrClass") return "01"
          return undefined
        })
      },
      value: {
        respCd: null,
      },
    },
    {
      mocking: () => {
        mockUseForm.mockGetValues.mockImplementation((key) => {
          if (key === "inqrClass") return "01"
          return undefined
        })
      },
      value: {
        respCd: null,
      },
    },
    {
      mocking: () => {
        mockUseForm.mockGetValues.mockImplementation((key) => {
          if (key === "inqrClass") return "02"
          return undefined
        })
      },
      value: {
        respCd: "02",
        respMsg: "test",
      },
    },
  ])("valueGetter Test", async (param) => {
    param.mocking()
    const { findByText } = render(component)

    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, { target: { data: param.value } })
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {
          netDebitLmtAmt: "0",
        },
      },
    })
  })

  it("resetVisible Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it.each(["01", "02"])(
    "openChartPopUp Test - openPopup",
    async (inqrClassSts) => {
      mockUseForm.mockGetValues.mockReturnValueOnce(inqrClassSts)
      mockUseProxy.mockAsync.mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 2,
        },
      })
      mockUseModal.mockOpenPopup.mockResolvedValueOnce({})
      const { findByText } = render(component)

      const searchBtn = await findByText(/SCRNITM#search/)
      fireEvent.click(searchBtn)

      await waitFor(() => {
        expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
      })

      const chartBtn = await findByText(/SCRNITM#chart/)
      fireEvent.click(chartBtn)

      await waitFor(() => {
        expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
      })
    },
  )

  it("openChartPopUp Test - gridCount.totalCnt is 0", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("03")
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })

    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })

    const chartBtn = await findByText(/SCRNITM#chart/)
    fireEvent.click(chartBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).not.toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("handleInqrClassChange Test", async () => {
    mockUseForm.mockGetValues
      .mockReturnValueOnce("02")
      .mockReturnValueOnce(undefined)
    const { findByTestId, findByText } = render(component)

    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#inqrClass/),
    ).findByTestId("onChange")
    fireEvent.click(onChangeTestBtn, {
      target: {
        data: {},
      },
    })
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {
          netDebitLmtAmt: "0",
        },
      },
    })

    fireEvent.click(onChangeTestBtn, {
      target: {
        data: {},
      },
    })
  })
})
