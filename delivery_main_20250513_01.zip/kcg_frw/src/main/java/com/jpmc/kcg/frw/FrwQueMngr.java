package com.jpmc.kcg.frw;

import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.mq.MQException;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.spring.boot.MQConfigurationProperties;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class FrwQueMngr {

	@Data
	public static class QueInqr {

		private String queNm;
		private int crntDpth;
		private int mxmmDpth;

	}

	@Autowired
	private SystemProperties systemProperties;
	@Autowired(required = false)
	private MQConfigurationProperties mqConfigurationProperties;
	private MQQueueManager newMQQueueManager() throws MQException {
		Properties properties = new Properties();
		properties.setProperty(MQConstants.HOST_NAME_PROPERTY, StringUtils.substringBefore(mqConfigurationProperties.getConnName(), '('));
		properties.put(MQConstants.PORT_PROPERTY, NumberUtils.createInteger(StringUtils.substringBetween(mqConfigurationProperties.getConnName(), "(", ")")));
		properties.setProperty(MQConstants.CHANNEL_PROPERTY, mqConfigurationProperties.getChannel());
		properties.setProperty(MQConstants.USER_ID_PROPERTY, mqConfigurationProperties.getUser());
		properties.setProperty(MQConstants.PASSWORD_PROPERTY, mqConfigurationProperties.getPassword());
		if (StringUtils.isNotEmpty(mqConfigurationProperties.getSslCipherSuite())) {
			properties.setProperty(MQConstants.SSL_CIPHER_SUITE_PROPERTY, mqConfigurationProperties.getSslCipherSuite());
		}
		return new MQQueueManager(mqConfigurationProperties.getQueueManager(), properties);
	}

	/**
	 * 
	 */
	public QueInqr getQueInqr(String queNm) throws MQException {
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 개발우회 ///////////////////////////////////////////////////////////////
		if (null == mqConfigurationProperties) {
			return new QueInqr();
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		MQQueueManager mqQueueManager = newMQQueueManager();
		try {
			QueInqr queInqr = new QueInqr();
			queInqr.setQueNm(queNm);
			try {
				log.trace("queNm = {}", queNm);
				MQQueue mqQueue = mqQueueManager.accessQueue(queNm, MQConstants.MQOO_BROWSE + MQConstants.MQOO_INQUIRE);
				if (mqQueue.getQueueType() == MQConstants.MQQT_ALIAS) {
					String orgnQueNm = mqQueue.getResolvedQName();
					mqQueue.close();
					log.trace("orgnQueNm = {}", orgnQueNm);
					mqQueue = mqQueueManager.accessQueue(orgnQueNm, MQConstants.MQOO_BROWSE + MQConstants.MQOO_INQUIRE); 
				}
				try {
					queInqr.setCrntDpth(mqQueue.getCurrentDepth());
					queInqr.setMxmmDpth(mqQueue.getMaximumDepth());
				} finally {
					mqQueue.close();
				}
			} catch (MQException e) {
				log.error(queNm, e);
			}
			return queInqr;
		} finally {
			try {
				mqQueueManager.close();
			} finally {
				mqQueueManager.disconnect();
			}
		}
	}

	/**
	 * 
	 */
	public Map<String, QueInqr> getQueInqrMap(String ... queNms) throws MQException {
		Map<String, QueInqr> queInqrMap = new TreeMap<>();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 개발우회 ///////////////////////////////////////////////////////////////
		if (null == mqConfigurationProperties) {
			return queInqrMap;
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		MQQueueManager mqQueueManager = newMQQueueManager();
		try {
			for (String queNm : queNms) {
				QueInqr queInqr = new QueInqr();
				queInqr.setQueNm(queNm);
				try {
					log.trace("queNm = {}", queNm);
					MQQueue mqQueue = mqQueueManager.accessQueue(queNm, MQConstants.MQOO_BROWSE + MQConstants.MQOO_INQUIRE);
					if (mqQueue.getQueueType() == MQConstants.MQQT_ALIAS) {
						String orgnQueNm = mqQueue.getResolvedQName();
						mqQueue.close();
						log.trace("orgnQueNm = {}", orgnQueNm);
						mqQueue = mqQueueManager.accessQueue(orgnQueNm, MQConstants.MQOO_BROWSE + MQConstants.MQOO_INQUIRE); 
					}
					try {
						queInqr.setCrntDpth(mqQueue.getCurrentDepth());
						queInqr.setMxmmDpth(mqQueue.getMaximumDepth());
					} finally {
						mqQueue.close();
					}
				} catch (MQException e) {
					log.error(queNm, e);
				}
				queInqrMap.put(queNm, queInqr);
			}
		} finally {
			try {
				mqQueueManager.close();
			} finally {
				mqQueueManager.disconnect();
			}
		}
		return queInqrMap;
	}

	/**
	 * 
	 */
	public Map<String, QueInqr> getQueInqrMap() throws MQException {
		return getQueInqrMap(
			systemProperties.getCqe().getEnt().getRcv(),
//			systemProperties.getCqe().getEnt().getSnd(),
			systemProperties.getCqe().getIft().getRcv(),
//			systemProperties.getCqe().getIft().getSnd(),
			systemProperties.getCqe().getRpr().getRcv(),
//			systemProperties.getCqe().getRpr().getSnd(),
			systemProperties.getGch().getHof().getRcv(),
//			systemProperties.getGch().getHof().getSnd(),
//			systemProperties.getKcg().getBft().getCmn(),
			systemProperties.getKcg().getCms().getCmn(),
			systemProperties.getKcg().getEnt().getCmn(),
			systemProperties.getKcg().getHof().getCmn(),
			systemProperties.getKcg().getIft().getCmn(),
			systemProperties.getKcg().getRpr().getCmn(),
//			systemProperties.getKcg().getFrw().getCmn(),
//			systemProperties.getKcg().getSim().getCmn(),
			systemProperties.getKft().getEnt().getRcv(),
			systemProperties.getKft().getEnt().getSnd(),
			systemProperties.getKft().getHof().getRcv(),
			systemProperties.getKft().getHof().getSnd(),
			systemProperties.getKft().getIft().getRcv(),
			systemProperties.getKft().getIft().getSnd(),
			systemProperties.getKft().getLcr().getRcv(),
			systemProperties.getKft().getLcr().getSnd(),
			systemProperties.getKft().getRpr().getRcv(),
			systemProperties.getKft().getRpr().getSnd(),
			systemProperties.getKib().getHof().getRcv(),
//			systemProperties.getKib().getHof().getSnd(),
			systemProperties.getLvb().getCms().getRcv(),
//			systemProperties.getLvb().getCms().getSnd(),
			systemProperties.getLvb().getHof().getRcv(),
//			systemProperties.getLvb().getHof().getAck(),
//			systemProperties.getLvb().getHof().getSnd(),
			systemProperties.getLvb().getIft().getRcv(),
//			systemProperties.getLvb().getIft().getSnd(),
			systemProperties.getLvb().getRpr().getRcv()
//			systemProperties.getLvb().getRpr().getSnd(),
		);
	}

}
