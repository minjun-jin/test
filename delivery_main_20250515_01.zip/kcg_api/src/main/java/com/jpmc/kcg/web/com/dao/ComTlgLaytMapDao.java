package com.jpmc.kcg.web.com.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.jpmc.kcg.com.dto.ComTlgLaytMapD;
import com.jpmc.kcg.com.dto.ComTlgLaytMapM;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapJoinOut;

@Mapper
public interface ComTlgLaytMapDao {
    List<ComTlgLaytMapM> selectComTlgLaytMapMList(ComTlgLaytMapM in);

    List<ComTlgLaytMapJoinOut> selectComTlgLaytMapJoinOutList(String trgtTlgLaytId, String sorcTlgLaytId);

    int insertTlgMapM(ComTlgLaytMapM in);

    int selectTlgMapDCount(String tlgLaytMapId, String trgtTlgLaytId, String trgtTlgFld);

    List<ComTlgLaytMapD> selectComTlgLaytMapDList(String tlgLaytMapId);

    ComTlgLaytMapD selectTlgMapD(ComTlgLaytMapD in);

    int insertTlgMapD(ComTlgLaytMapD in);

    int updateTlgMapD(ComTlgLaytMapD in);

    int insertTlgMapDPostApproval(ComTlgLaytMapD in);

    int updateTlgMapMRequestApproval(ComTlgLaytMapM in);

    int updateTlgMapMPostApproval(ComTlgLaytMapM in);

    int updateTlgMapDRequestApproval(ComTlgLaytMapD in);

    int updateTlgMapDPostApproval(ComTlgLaytMapD in);

    int deleteTlgMapM(ComTlgLaytMapM in);

    int deleteTlgMapD(ComTlgLaytMapD in);

    int deleteRejectTlgMapD(ComTlgLaytMapD in);
}
