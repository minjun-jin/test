package com.jpmc.kcg.com.biz;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComAcctStsDao;
import com.jpmc.kcg.com.dao.ComBnkBrnchCdMDao;
import com.jpmc.kcg.com.dao.ComBnkCdMDao;
import com.jpmc.kcg.com.dao.ComBnkCdMMapper;
import com.jpmc.kcg.com.dao.ComBnkStsMDao;
import com.jpmc.kcg.com.dao.ComCdDMapper;
import com.jpmc.kcg.com.dao.ComChequeInfoMgmtMDao;
import com.jpmc.kcg.com.dao.ComNbrgMDao;
import com.jpmc.kcg.com.dao.ComRespCdMDao;
import com.jpmc.kcg.com.dao.ComRespCdMMapper;
import com.jpmc.kcg.com.dao.ComRespCdMapMDao;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dao.ComTrHoldLMapper;
import com.jpmc.kcg.com.dto.CheckChequeStatusIn;
import com.jpmc.kcg.com.dto.ComAcctStsIn;
import com.jpmc.kcg.com.dto.ComAcctStsOut;
import com.jpmc.kcg.com.dto.ComBnkBrnchCdM;
import com.jpmc.kcg.com.dto.ComBnkCdM;
import com.jpmc.kcg.com.dto.ComBnkStsM;
import com.jpmc.kcg.com.dto.ComBnkStsMIn;
import com.jpmc.kcg.com.dto.ComBnkStsMOut;
import com.jpmc.kcg.com.dto.ComCdD;
import com.jpmc.kcg.com.dto.ComChequeInfoMgmtM;
import com.jpmc.kcg.com.dto.ComNbrgM;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.dto.ComRespCdMapM;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.dto.ComTrHoldLIn;
import com.jpmc.kcg.com.enums.BankCodeEnum;
import com.jpmc.kcg.com.enums.BankStatusEnum;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class BizCom {

	private final ComBnkCdMDao comBnkCdMDao;
	private final ComBnkBrnchCdMDao comBnkBrnchCdMDao;
	private final ComBnkStsMDao comBnkStsMDao;
	private final ComNbrgMDao comNbrgMDao;
	private final ComAcctStsDao comAcctStsDao;
	private final ComRespCdMMapper comRespCdMMapper;
	private final ComTrHoldLMapper comTrHoldLMapper;
	private final ComBnkCdMMapper comBnkCdMMapper;
	private final ComChequeInfoMgmtMDao comChequeInfoMgmtMDao;
	private final ComRespCdMapMDao comRespCdMapMDao;
	private final ComRespCdMDao comRespCdMDao;
	private final ComTrHoldLDao comTrHoldLDao;
	private final FrwContext frwContext;
	private final BizDate bizDate;
	private final ComCdDMapper comCdDMapper;

	public BizCom(ComBnkCdMDao comBnkCdMDao, ComBnkBrnchCdMDao comBnkBrnchCdMDao,
			ComBnkStsMDao comBnkStsMDao, ComNbrgMDao comNbrgMDao, ComAcctStsDao comAcctStsDao,
			ComRespCdMMapper comRespCdMMapper, ComTrHoldLMapper comTrHoldLMapper,
			ComBnkCdMMapper comBnkCdMMapper, ComChequeInfoMgmtMDao comChequeInfoMgmtMDao,
			ComRespCdMapMDao comRespCdMapMDao, ComRespCdMDao comRespCdMDao,
			ComTrHoldLDao comTrHoldLDao,
			FrwContext frwContext,     
			BizDate bizDate,           
			ComCdDMapper comCdDMapper) {
		this.comBnkCdMDao = comBnkCdMDao;
		this.comBnkBrnchCdMDao = comBnkBrnchCdMDao;
		this.comBnkStsMDao = comBnkStsMDao;
		this.comNbrgMDao = comNbrgMDao;
		this.comAcctStsDao = comAcctStsDao;
		this.comRespCdMMapper = comRespCdMMapper;
		this.comTrHoldLMapper = comTrHoldLMapper;
		this.comBnkCdMMapper = comBnkCdMMapper;
		this.comChequeInfoMgmtMDao = comChequeInfoMgmtMDao;
		this.comRespCdMapMDao = comRespCdMapMDao;
		this.comRespCdMDao = comRespCdMDao;
		this.comTrHoldLDao = comTrHoldLDao;
		this.frwContext = frwContext;
		this.bizDate = bizDate;
		this.comCdDMapper = comCdDMapper;
	}

	public boolean getBankCodeValidation(String bnkCd) {
		if (StringUtils.isBlank(bnkCd))
			throw new BusinessException("MCMNE01001");
		ComBnkCdM mapperIn = new ComBnkCdM();
		mapperIn.setBnkCd(bnkCd);

		List<ComBnkCdM> comBnkCdMList = comBnkCdMDao.selectComBnkCdList(mapperIn);
		log.debug("comBnkCdMList : {} ", comBnkCdMList);
		String selectedBnkCd = null;
		if (!CollectionUtils.isEmpty(comBnkCdMList)) {
			ComBnkCdM comBnkCdM = comBnkCdMList.get(0);
			selectedBnkCd = comBnkCdM.getBnkCd();
		}
		if (StringUtils.isBlank(selectedBnkCd)) {
			return false;
		}
		return true;
	}

	/**
	 * 사용여부가 Y인 은행코드 중,
	 * 입력된 업무구분코드의 플래그를 Y로 입력하여 조회한다.
	 * @param bnkCd
	 * @param bizDvsnCdEnums
	 * @return
	 */
	public boolean getBankCodeValidation(String bnkCd, List<BizDvsnCdEnum> bizDvsnCdEnumList) {

		ComBnkCdM mapperIn = new ComBnkCdM();
		mapperIn.setBnkCd(bnkCd);
		mapperIn.setUseYn(ComConst.Y);

		for (BizDvsnCdEnum bizDvsnCdEnum : bizDvsnCdEnumList) {
			switch (bizDvsnCdEnum) {
			case HOF:
				mapperIn.setHofYn(ComConst.Y);
				break;
			case HBK:
				mapperIn.setHbkYn(ComConst.Y);
				break;
			case IFT:
				mapperIn.setIftYn(ComConst.Y);
				break;
			case RPR:
				mapperIn.setRprYn(ComConst.Y);
				break;
			case CMS:
				mapperIn.setCmsYn(ComConst.Y);
				break;
			case ENT:
				mapperIn.setEntYn(ComConst.Y);
				break;
			default:
				log.warn("Unhandled BizDvsnCdEnum: {}", bizDvsnCdEnum);
				break;
			}
		}

		List<ComBnkCdM> comBnkCdMList = comBnkCdMDao.selectComBnkCdList(mapperIn);
		log.debug("comBnkCdMList : {} ", comBnkCdMList);
		String selectedBnkCd = null;
		if (!CollectionUtils.isEmpty(comBnkCdMList)) {
			ComBnkCdM comBnkCdM = comBnkCdMList.get(0);
			selectedBnkCd = comBnkCdM.getBnkCd();
		}
		if (StringUtils.isBlank(selectedBnkCd)) {
			return false;
		}
		return true;
	}

	/**
	 * 수취계좌 Validation
	 * @param acctNo
	 * @param bizDvsnCd
	 * @param trgtHostCd
	 * @return
	 */
	public Map<String, String> getAccountValidation(String acctNo, String bizDvsnCd,
			String trgtHostCd) {

		Map<String, String> acctInfo = new HashMap<>();
		String rtnAcctStsCd = "";
		String rtnAcctNm = "";

		if (StringUtils.isBlank(acctNo)) {
			throw new BusinessException("MCMNE01001", acctNo);
		}

		ComAcctStsIn mapperIn = new ComAcctStsIn();
		mapperIn.setAcctNo(acctNo); // 계좌번호
		mapperIn.setVrtlAcctNo(acctNo); // 가상계좌번호

		// 계좌번호 정보 조회 (COM_ACCT_NO_M)
		ComAcctStsOut acctInfoOut = comAcctStsDao.selectAcctNoInfo_1(mapperIn);

		// 계좌번호 아닌 가상계좌 정보 조회 (COM_ACCT_NO_M)
		if (acctInfoOut == null || StringUtils.isBlank(acctInfoOut.getAcctNo())) {
			acctInfoOut = comAcctStsDao.selectAcctNoInfo_2(mapperIn);

			// 가상계좌 관리 테이블 조회 (COM_VRTL_ACCT_NO_M)
			if (acctInfoOut == null || StringUtils.isBlank(acctInfoOut.getAcctNm())) {
				ComAcctStsOut vrtInfoOut = comAcctStsDao.selectAcctNoInfo_3(mapperIn);

				if (vrtInfoOut != null) {
					mapperIn.setAcctNo(vrtInfoOut.getMthrAcctNo());  //가상계좌테이블에 모계좌 번호 pk이다.
					// 모계좌 정보 조회 (COM_ACCT_NO_M)
					acctInfoOut = comAcctStsDao.selectAcctNoInfo_1(mapperIn);

					//가상계좌테이블에 모계좌가 KRW가 아닌 경우 null 체크
					if (acctInfoOut != null) {
						acctInfoOut.setAcctStsCd(StringUtils.defaultIfBlank(
								vrtInfoOut.getAcctStsCd(), acctInfoOut.getAcctStsCd()));
						acctInfoOut.setAcctNm(StringUtils.defaultIfBlank(vrtInfoOut.getVrtlAcctNm(),
								acctInfoOut.getAcctNm()));
					} else {
						rtnAcctStsCd = "413"; // 계좌정보 없음
					}
				}
			}
		}

		log.info(">>>>>>>>>>>>>>>>>>>>> acctInfoOut {}", acctInfoOut);

		// 계좌명 및 상태 Set
		if (acctInfoOut != null) {
			rtnAcctNm = StringUtils.defaultIfBlank(acctInfoOut.getAcctNm(), rtnAcctNm);
			String acctStsCd = acctInfoOut.getAcctStsCd();
			String ddaCd = acctInfoOut.getDdaCd();

			log.info(">>>>>>>>>>>>>>>>>>>>> acctStsCd {}", acctStsCd);
			log.info(">>>>>>>>>>>>>>>>>>>>> ddaCd {}", ddaCd);

			if (ComConst.CHAR_01.equals(acctStsCd)) {
				if (StringUtils.equalsAny(ddaCd, ComConst.CHAR_2, ComConst.CHAR_5)
						|| StringUtils.isBlank(ddaCd)) {
					rtnAcctStsCd = "000"; // 정상계좌
				}
			} else if (ComConst.CHAR_02.equals(acctStsCd)) {
				rtnAcctStsCd = "403"; // 휴면계좌
			} else if (ComConst.CHAR_03.equals(acctStsCd)) {
				rtnAcctStsCd = "411"; // 해지계좌
			} else if (ComConst.CHAR_04.equals(acctStsCd)) {
				rtnAcctStsCd = "409"; // 제한계좌
			} else {
				log.info(">>>>>>>>>>>>>>>>>>>>> acctStsCd is not 1,2,3,4");
				rtnAcctStsCd = "413"; // 계좌정보 없음
			}
		} else {
			log.info(">>>>>>>>>>>>>>>>>>>>> acctInfoResult is null");
			rtnAcctStsCd = "401"; // 계좌정보 없음
		}

		rtnAcctStsCd = this.getRespCdMap(trgtHostCd, bizDvsnCd, rtnAcctStsCd);
		acctInfo.put("rtnAcctStsCd", rtnAcctStsCd);
		acctInfo.put("rtnAcctNm", rtnAcctNm);

		return acctInfo;
	}

	public boolean getBankBranchCodeValidation(String bnkBrnchCd) {
		if (StringUtils.isBlank(bnkBrnchCd))
			throw new BusinessException("MCMNE01001", bnkBrnchCd);

		String bnkCd = bnkBrnchCd.substring(0, 3);
		String bnkBrnchCd1 = bnkBrnchCd.substring(3, 6);
		String bnkBrnchCd2 = bnkBrnchCd.substring(6);

		ComBnkBrnchCdM mapperIn = new ComBnkBrnchCdM();
		mapperIn.setBnkCd(bnkCd);
		mapperIn.setBrnchCd1(bnkBrnchCd1);
		mapperIn.setBrnchCd2(bnkBrnchCd2);

		List<ComBnkBrnchCdM> comBnkBrnchCdMList = comBnkBrnchCdMDao.selectListBnkBrnchCdM(mapperIn);

		String selectedBnkCd = null;
		String selectedBnkBrnchCd1 = null;
		String selectedBnkBrnchCd2 = null;
		if (!CollectionUtils.isEmpty(comBnkBrnchCdMList)) {
			ComBnkBrnchCdM comBnkBrnchCdM = comBnkBrnchCdMList.get(0);
			selectedBnkCd = comBnkBrnchCdM.getBnkCd();
			selectedBnkBrnchCd1 = comBnkBrnchCdM.getBrnchCd1();
			selectedBnkBrnchCd2 = comBnkBrnchCdM.getBrnchCd2();
		}
		if (!StringUtils.isBlank(selectedBnkCd) && !StringUtils.isBlank(selectedBnkBrnchCd1)
				&& !StringUtils.isBlank(selectedBnkBrnchCd2)) {
			return true;
		} else {
			throw new BusinessException("MCMNE01001", selectedBnkCd, selectedBnkBrnchCd1,
					selectedBnkBrnchCd2);
		}
	}

	public String getConnectivtyValidation(String bnkCd, String bizDvsnCd, String trgtHostCd) {

		if (StringUtils.isBlank(bnkCd)) {
			throw new BusinessException("MCMNE01002", bnkCd);
		}

		if (StringUtils.isBlank(bizDvsnCd)) {
			throw new BusinessException("MCMNE01002", bizDvsnCd);
		}

		ComBnkStsMIn comBnkStsMIn = new ComBnkStsMIn();
		comBnkStsMIn.setBnkCd(bnkCd);
		comBnkStsMIn.setBizDvsnCd(bizDvsnCd);

		ComBnkStsMOut comBnkStsMOut = comBnkStsMDao.selectConnectivityStatus(comBnkStsMIn);

		String respCd = ComConst.NORMAL_RESPONSE_CODE;

		if (comBnkStsMOut != null) {

			if (!ComConst.NORMAL_RESPONSE_CODE.equals(comBnkStsMOut.getKtfcNetStatus())) {
				respCd = comBnkStsMOut.getKtfcNetStatus();
			} else if (!ComConst.NORMAL_RESPONSE_CODE.equals(comBnkStsMOut.getJpmcNetStatus())) {
				respCd = comBnkStsMOut.getJpmcNetStatus();
			} else if (!ComConst.NORMAL_RESPONSE_CODE.equals(comBnkStsMOut.getBnkNetStatus())) {
				respCd = comBnkStsMOut.getBnkNetStatus();
			}
		} else {
			respCd = ComConst.ERROR_RESPONSE_CODE;
		}

		respCd = this.getRespCdMap(trgtHostCd, bizDvsnCd, respCd);

		return respCd;
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public String getNumbering(String bizDvsnCd, String nbrgId) {
		if (StringUtils.isBlank(bizDvsnCd) || StringUtils.isBlank(nbrgId))
			throw new BusinessException("MCMNE01001", bizDvsnCd, nbrgId);

		ComNbrgM mapperIn = new ComNbrgM();
		mapperIn.setBizDvsnCd(bizDvsnCd);
		mapperIn.setNbrgId(nbrgId);

		log.debug("mapperin : {}, {}", mapperIn.getBizDvsnCd(), mapperIn.getNbrgId());
		ComNbrgM comNbrgM = comNbrgMDao.selectListComNbrgM(mapperIn);

		if (!"COMSEQ01".equals(nbrgId) && comNbrgM == null)
			throw new BusinessException("MCMNE01001");

		NumberingEnum e = NumberingEnum.findByName(nbrgId);
		if (e == null)
			throw new BusinessException("MCMNE01001", "Wrong NbrgId");

		Long nbrgNo = 0L;
		Long nextNbrgNo = 0L;

		if ("COMSEQ01".equals(nbrgId)) { // 오라클 시퀀스 사용 2024-06-14
			nbrgNo = comNbrgMDao.selectComTrHoldSeq(mapperIn);
		} else if (!"1".equals(comNbrgM.getNbrgNo()) && "IFTKFT02".equals(nbrgId)) {
			nbrgNo = Long.parseLong(comNbrgM.getNbrgNo().substring(3));
		} else {
			nbrgNo = Long.parseLong(comNbrgM.getNbrgNo());
		}

		nextNbrgNo = nbrgNo + 1;

		if (log.isDebugEnabled()) {
			log.debug("e.getSubStrPos() {} ,{} ,{}", e.getSubStrPos(), e.getFormat(), nbrgNo);
		}
		/*
		 * COMSEQ01 의 분기 처리를 위해 아래 로직으로 변경 2024-06-14 String formattedNbrgNo =
		 * String.format(e.getFormat(), nbrgNo);
		 * mapperIn.setNbrgNo(String.format(e.getFormat(), nextNbrgNo));
		 * 
		 * int updateNbrgNo = comNbrgMDao.updateComNbrgM(mapperIn);
		 * 
		 * if (updateNbrgNo < 1) throw new BusinessException("MCMNE01001",
		 * formattedNbrgNo);
		 */

		String formattedNbrgNo = String.format(e.getFormat(), nbrgNo);

		// COMSEQ01 가 아닐 경우만 COM_NBRG_M 테이블에서 관리 2024-06-14
		if (!"COMSEQ01".equals(nbrgId)) {
			nextNbrgNo = nbrgNo + 1;
			mapperIn.setNbrgNo(
					String.format(e.getFormat(), nextNbrgNo).substring(e.getSubStrPos()));

			int updateNbrgNo = comNbrgMDao.updateComNbrgM(mapperIn);

			if (updateNbrgNo < 1)
				throw new BusinessException("MCMNE01001", formattedNbrgNo);
		}

		return formattedNbrgNo;
	}

	public ComRespCdM getRespCode(String hostCd, String bizDvsnCd, String respCd) {
		log.debug("hostCd : {} ", hostCd);
		log.debug("bizDvsnCd : {} ", bizDvsnCd);
		log.debug("respCd : {} ", respCd);

		if (StringUtils.isEmpty(hostCd) || StringUtils.isEmpty(bizDvsnCd)
				|| StringUtils.isEmpty(respCd))
			throw new BusinessException("MCMNE01001");

		ComRespCdM out = comRespCdMMapper.selectByPrimaryKey(hostCd, bizDvsnCd, respCd);

		return out;
	}
	
	public void updateBank(String bnkCd, String status, int idx, String extTime, String bizDvsnCd)
			throws BusinessException {

		this.updateBank(bnkCd, status, idx, extTime, bizDvsnCd,
				StringUtils.rightPad("", 6, ComConst.CHAR_0), "02"); //AprvStsCdEnum APPROVED("02")
	}
	
	public void updateBank(String bnkCd, String status, int idx, String extTime, String bizDvsnCd,
			String tlgTrDvsnCd) throws BusinessException {
		
		this.updateBank(bnkCd, status, idx, extTime, bizDvsnCd, tlgTrDvsnCd, "02"); //AprvStsCdEnum APPROVED("02")
		
	}

	public void updateBank(String bnkCd, String status, int idx, String extTime, String bizDvsnCd,
			String tlgTrDvsnCd, String aprvStsCd) throws BusinessException {

		if (StringUtils.isEmpty(bnkCd))
			throw new BusinessException("bnkCd is empty");

		String[] bnkCdArr = bnkCd.split(";");
		List<String> bnkCdList = new ArrayList<String>();
		// 현재 시간 가져오기
		LocalDateTime currentTime = LocalDateTime.now();

		if (idx == 9)
			return;

		for (String bnkCdOne : bnkCdArr) {
			// Lock the row for Update
			ComBnkStsM comBnkStsM = new ComBnkStsM();
			comBnkStsM.setBnkCd(bnkCdOne);
			comBnkStsM.setBizDvsnCd(bizDvsnCd);
			comBnkStsM.setTlgTrDvsnCd(tlgTrDvsnCd);

			ComBnkStsM bnkStatus = comBnkStsMDao.selectBnkCd(comBnkStsM);

			if (bnkStatus == null)
				throw new BusinessException("MCMNE01001");

			bnkCdList.add(bnkCdOne);
		}
		// 연장은행과, 결제원까지 연장시간 Update 202408-28
		if (BankStatusEnum.CPED_V.getStatus().equals(status)
				|| BankStatusEnum.EXTD_V.getStatus().equals(status)) {
			bnkCdList.add(BankCodeEnum.KFTC.getBnkCode()); // KFTC("099")
		}

		Map<String, Object> parameterMap = new HashMap<>();
		parameterMap.put("bnkCdList", bnkCdList);
		parameterMap.put("bizDvsnCd", bizDvsnCd);
		parameterMap.put("aprvStsCd", aprvStsCd);
		// TODO : 정해지면 넣어야할 것
		parameterMap.put("lastChngGuid", frwContext.getSvcGuid());
		parameterMap.put("lastChngStaffId", frwContext.getUsrId());

		//		if (status.equals(BankStatusEnum.EXTD_V.getStatus())) {
		//			// 장운영 연장인 경우 개시 상태로 둔다. 하창범부장님 요청 20270716
		//			parameterMap.put("bnkStsCd", BankStatusEnum.START_V.getCode());
		//		} else {
		//			BankStatusEnum bankStatusEnum = BankStatusEnum.findByStatus(status);
		//			if (null != bankStatusEnum) {
		//				parameterMap.put("bnkStsCd", bankStatusEnum.getCode());
		//			}
		//		}

		BankStatusEnum bankStatusEnum = BankStatusEnum.findByStatus(status);
		if (null != bankStatusEnum) {
			parameterMap.put("bnkStsCd", bankStatusEnum.getCode());
		}

		if (status.equals(BankStatusEnum.BUSY_V.getStatus())) { // 시스템장애(0800400)
			parameterMap.put("trTm", currentTime.format(DateTimeFormatter.ofPattern("HHmm")));
		} else if (status.equals(BankStatusEnum.EXTD_V.getStatus())) { // 운영시간연장(0800600)
			parameterMap.put("operExtTm", extTime);
		} else if (status.equals(BankStatusEnum.CPED_V.getStatus())) { // 자금화연장(0800904/0800905)
			parameterMap.put("cashExtTm", extTime);
		}
		//거래구분코드
		parameterMap.put("tlgTrDvsnCd", tlgTrDvsnCd);

		log.info("parameterMap {}", parameterMap);
		comBnkStsMDao.updateBnkStsM(parameterMap);
	}

	public void updateAllBnkStsStart(String bizDvsnCd) {

		LocalDateTime currentTime = LocalDateTime.now();

		/**
		 * 1. 기준일자가 금일 && 은행상태가 00 미개시인 경우
		 * 개시상태로 변경, 자금화연장시각, 운영연장시각 초기화
		 **/
		ComBnkStsM comBnkStsM = new ComBnkStsM();
		comBnkStsM.setBnkStsCd(BankStatusEnum.START_V.getCode());
		comBnkStsM.setBizDvsnCd(bizDvsnCd);
		comBnkStsM.setBaseDt(currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		comBnkStsM.setCashExtTm(""); //자금화연장시각 초기화
		comBnkStsM.setOperExtTm(""); //운영연장시각 초기화
		comBnkStsM.setAprvStsCd(ComConst.CHAR_02); //APRV_STS_CD 02 : 승인

		log.info("업무구분코드 : {}", bizDvsnCd);
		log.info("은행상태코드 comBnkStsM.getBnkStsCd : {}", comBnkStsM.getBnkStsCd());
		log.info("기준일자 : {}", comBnkStsM.getBaseDt());
		comBnkStsMDao.updateAllBnkStat(comBnkStsM);

		/**
		 * 2. 기준일자를 쿼리 조건에 넣어서 금일날짜가 아닌 것들을 모두 update
		 * 기준일자 != 금일이면 금일&개시상태로 변경, 자금화연장시각, 운영연장시각 초기화
		 **/

		ComBnkStsM comBnkStsMPrevBizDay = new ComBnkStsM();
		comBnkStsMPrevBizDay.setBnkStsCd(BankStatusEnum.START_V.getCode());
		comBnkStsMPrevBizDay.setBizDvsnCd(bizDvsnCd);
		comBnkStsMPrevBizDay.setBaseDt(currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		comBnkStsMPrevBizDay.setCashExtTm(""); //자금화연장시각 초기화
		comBnkStsMPrevBizDay.setOperExtTm(""); //운영연장시각 초기화
		comBnkStsMPrevBizDay.setAprvStsCd(ComConst.CHAR_02); //APRV_STS_CD 02 : 승인
		comBnkStsMDao.updateAllBnkStsStart(comBnkStsMPrevBizDay);

	}

	/**
	 * 2024.04.29 한성흔 농협은행은 계좌번호에 따른 대표은행코드 조회 타은행은 대표은행코드를 조회한다.
	 * 
	 * @param orgnBnkCd
	 * @param acctNo
	 * @return
	 * @throws BusinessException
	 */
	public String getNHAcctBnkCd(String orgnBnkCd, String acctNo) throws BusinessException {
		String bnkCd = "";

		acctNo = acctNo.trim();
		int accountLen = acctNo.length();
		
		// IFTBANKINF 테이블에서 BANK_CD 에 해당하는 KFTC_CD 를 조회해서 전송해야함
		ComBnkCdM bnkCdOut = comBnkCdMMapper.selectByPrimaryKey(orgnBnkCd);
		bnkCd = bnkCdOut.getKftcBnkCd();

		// 농협은행인경우에는 별도로 대표은행을 조회해야함.
		if (bnkCd.equals(BankCodeEnum.NH01.getBnkCode())
				|| bnkCd.equals(BankCodeEnum.NH02.getBnkCode())) {
			switch (accountLen) {
			case 12:
				bnkCd = BankCodeEnum.NH01.getBnkCode(); // 12자리이면 농협은행 11로 세팅
				break;
			case 11:
				bnkCd = BankCodeEnum.NH01.getBnkCode(); // 11자리이면 농협은행 11로 세팅
				break;
			case 10:
				if (acctNo.endsWith(ComConst.CHAR_8)) {
					bnkCd = BankCodeEnum.NH01.getBnkCode(); // 마지막자리가 8이면 농협은행 코드 11로 세팅
				} else if (acctNo.endsWith(ComConst.CHAR_9)) {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 마지막자리가 9이면 농협은행 코드 12로 세팅
				}
				break;
			case 13:
				String lastChar = acctNo.substring(accountLen - 1);
				if (lastChar.equals(ComConst.CHAR_1) || lastChar.equals(ComConst.CHAR_2)) {
					bnkCd = BankCodeEnum.NH01.getBnkCode(); // 마지막자리가 1,2이면 농협은행 11 세팅
				} else if (lastChar.equals(ComConst.CHAR_3) || lastChar.equals(ComConst.CHAR_4)
						|| lastChar.equals(ComConst.CHAR_5)) {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 마지막자리가 3,4,5이면 지역농협 12 세팅
				} else if (lastChar.equals(ComConst.CHAR_8)) {
					bnkCd = BankCodeEnum.NH01.getBnkCode(); // 마지막자리가 8,9이면 농협은행 11로 세팅
				} else if (acctNo.endsWith(ComConst.CHAR_9)) {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 마지막자리가 9이면 농협은행 코드 12로 세팅
				}
				break;
			case 14:
				String first3Chars = acctNo.substring(0, 3);
				String mid2Chars = acctNo.substring(6, 8);
				if (first3Chars.equals(ComConst.NH_ACCT_790)
						|| first3Chars.equals(ComConst.NH_ACCT_791)) {
					bnkCd = BankCodeEnum.NH01.getBnkCode(); // 앞자리 3자리 코드가 790이나 791이면 농협은행 11로 세팅
				} else if (first3Chars.equals(ComConst.NH_ACCT_792)) {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 앞자리 3자리 코드가 792이면 지역농협 12로 세팅
				} else if (mid2Chars.equals(ComConst.NH_ACCT_64)
						|| mid2Chars.equals(ComConst.NH_ACCT_65)) {
					bnkCd = BankCodeEnum.NH01.getBnkCode(); // 중간 2자리 코드가 64나 65이면 농협은행 11로 세팅
				} else if (mid2Chars.equals(ComConst.NH_ACCT_66)
						|| mid2Chars.equals(ComConst.NH_ACCT_67)) {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 중간 2자리 코드가 66나 67이면 지역농협 12로 세팅
				} else {
					bnkCd = BankCodeEnum.NH02.getBnkCode(); // 그 외의 경우는 지역농협 12로 세팅
				}
				break;
			default:
				break;
			}
		}
		return bnkCd;
	}

	/**
	 * 2024.05.09 hold 테이블에 입력하는 공통서비스 신규
	 */
	public void createHoldTransaction(FrwContext frwContext, ComTrHoldL holdIn) {

		ComTrHoldL comTrHoldL = new ComTrHoldL();
		String trSeq = this.getNumbering(holdIn.getBizDvsnCd(), NumberingEnum.COMSEQ01.toString());
		comTrHoldL.setTrSeq(Long.valueOf(trSeq));
		comTrHoldL.setTrDt(LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE)); // yyyyMMdd
		comTrHoldL.setBizDvsnCd(holdIn.getBizDvsnCd());
		comTrHoldL.setOutinDvsnCd(holdIn.getOutinDvsnCd());
		comTrHoldL.setTlgKndDvsnCd(holdIn.getTlgKndDvsnCd());
		comTrHoldL.setTlgTrDvsnCd(holdIn.getTlgTrDvsnCd());
		comTrHoldL.setHostNo(holdIn.getHostNo());
		comTrHoldL.setTrUnqNo(holdIn.getTrUnqNo());
		comTrHoldL.setRcvBnkCd(holdIn.getRcvBnkCd());
		comTrHoldL.setRcvAcctNo(holdIn.getRcvAcctNo());
		comTrHoldL.setWhdrwlBnkCd(holdIn.getWhdrwlBnkCd());
		comTrHoldL.setWhdrwlNm(holdIn.getWhdrwlNm());
		comTrHoldL.setWhdrwlAcctNo(holdIn.getWhdrwlAcctNo());
		comTrHoldL.setSndrRealNm(holdIn.getSndrRealNm());
		comTrHoldL.setRqerInfo(holdIn.getRqerInfo());
		comTrHoldL.setTrAmt(holdIn.getTrAmt());
		comTrHoldL.setTrPrord(holdIn.getTrPrord());
		comTrHoldL.setRespCd(holdIn.getRespCd());
		if (StringUtils.isEmpty(holdIn.getTlgCtt())) { // 지정된 tlgCtt가 없는 경우 자동 셋팅
			if (holdIn.getTlgKndDvsnCd().contains(ComConst.CHAR_00)) { // 요청전문에서 대기로 들어온경우
				comTrHoldL.setTlgCtt(frwContext.getTlgCtt());
				comTrHoldL.setTrcId(frwContext.getTractId());
			} else {// 응답전문에서 대기로 들어온경우
				comTrHoldL.setTlgCtt(frwContext.getOrgnTlgCtt());
				comTrHoldL.setTrcId(frwContext.getOrgnTractId());
			}
		} else {
			comTrHoldL.setTlgCtt(holdIn.getTlgCtt());
			comTrHoldL.setTrcId(holdIn.getTrcId());
		}
		comTrHoldL.setHoldRsnCd(holdIn.getHoldRsnCd());
		comTrHoldL.setHoldStsCd(TrStsCdEnum.REQUEST.getTrStsCd()); // 01: hold
		comTrHoldL.setHoldTm(LocalDateTime.now().format(DateFormat.HHMMSSSSS.getFormatter()));
		comTrHoldL.setFrstChngGuid(frwContext.getTractId());
		comTrHoldL.setFrstChngStaffId(frwContext.getUsrId());
		comTrHoldL.setFrstChngTmstmp(LocalDateTime.now());
		comTrHoldL.setLastChngGuid(frwContext.getTractId());
		comTrHoldL.setLastChngStaffId(frwContext.getUsrId());
		comTrHoldL.setLastChngTmstmp(LocalDateTime.now());
		
		_setHoldTrRelsStaDttm(holdIn);	// 2025.03.26 대기거래 시작(예상)일자,시간 설정 추가
		comTrHoldL.setRelsStaDt(holdIn.getRelsStaDt());
		comTrHoldL.setRelsStaTm(holdIn.getRelsStaTm());
		
		comTrHoldLMapper.insert(comTrHoldL);
	}

	/**
	 * 2024.06.05 
	 * 한성흔 당행의 수표상태를 체크하는 로직이다.
	 */
	public String checkChequeStatus(CheckChequeStatusIn in, String bizDvsnCd, String trgtHostCd) {

		String respCd = "";

		if (StringUtils.isEmpty(in.getChequeTp()) || StringUtils.isEmpty(in.getChequeNo())
				|| StringUtils.isEmpty(in.getChequeKindCd()) || StringUtils.isEmpty(in.getIssueDt())
				|| in.getChequeAmt() == null)
			throw new BusinessException("MCMNE01001");

		log.info(">>>>>> bizCom.checkChequeStatus() input :: {}", in);

		ComChequeInfoMgmtM selectIn = new ComChequeInfoMgmtM();
		selectIn.setChequeKindCd(in.getChequeKindCd());
		selectIn.setChequeNo(in.getChequeNo());
		selectIn.setChequeTp(in.getChequeTp());

		ComChequeInfoMgmtM selectOut = comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(selectIn);
		log.info(">>>>>> selectComChequeInfoMgmtM :: {}", selectOut);

		if (selectOut == null) {
			respCd = "506"; // "미발행 수표"
		} else {
			String chequeStsCd = selectOut.getChequeStsCd();
			if (chequeStsCd.equals(ComConst.CHAR_00)) {
				String issueDt = selectOut.getIssueDt();
				if (in.getIssueDt().length() == 6) {
					issueDt = selectOut.getIssueDt().substring(2);
				}
				log.info(">>>>>> issueDt :: {}", issueDt);
				if (!issueDt.equals(in.getIssueDt())) {
					respCd = "506"; // "미발행 수표"
					log.info(">>>>>> 일자에러:: {}", issueDt);
				} else if (!ComConst.JPMC_BANK_CD.concat(ComConst.JPMC_BRNCH_CD)
						.equals(in.getChequeBranchCd())) {
					respCd = "506"; // "미발행 수표"
					log.info(">>>>>> 브랜치에러:: {}", in.getChequeBranchCd());
				} else if (!selectOut.getChequeAmt().equals(in.getChequeAmt())) {
					respCd = "503"; // "수표금액 상이"
				} else {
					respCd = "000";
					selectOut.setRemark(in.getRemark());
					comChequeInfoMgmtMDao.updateComChequeInfoRemark(selectOut);
				}
			} else if (chequeStsCd.equals("09")) {
				respCd = "505"; // "지급 수표"
			} else if (chequeStsCd.equals("04")) {
				respCd = "508"; // "부도 수표"
			} else {
				respCd = "506"; // "미발행 수표"
				log.info(">>>>>> 기타에러:: {}", chequeStsCd);
			}
		}

		respCd = this.getRespCdMap(trgtHostCd, bizDvsnCd, respCd);

		return respCd;
	}

	/**
	 * @description 응답코드매핑이 되어있는 응답코드일 경우 매핑된 응답코드를 반환한다. 없으면 대표응답코드를 반환한다.
	 */
	public String getRespCdMap(String mapHostCd, String bizDvsnCd, String respCd) {

		if (StringUtils.isAnyEmpty(mapHostCd, bizDvsnCd, respCd)) {
			return respCd;
		}

		ComRespCdMapM in = new ComRespCdMapM();
		in.setHostCd(ComConst.KCG);
		in.setMapHostCd(mapHostCd);
		in.setBizDvsnCd(bizDvsnCd);
		in.setRespCd(respCd);

		// 응답코드매핑 테이블 조회
		ComRespCdMapM comRespCdMapM = comRespCdMapMDao.selectResponseCodeMapping(in);

		if (comRespCdMapM != null) {
			// 응답코드 매핑 테이블에 있을 경우 매핑된 응답코드를 반환한다.
			log.info("{} 응답코드매핑: KCG {} -> {} {}", bizDvsnCd, respCd, mapHostCd,
					comRespCdMapM.getMapRespCd());
			return comRespCdMapM.getMapRespCd();
		}

		// 응답코드 매핑 테이블에 없을 경우 대표 응답코드를 반환한다.
		ComRespCdM comRespCdM = new ComRespCdM();
		comRespCdM.setHostCd(mapHostCd);
		comRespCdM.setBizDvsnCd(bizDvsnCd);
		String repRespCd = comRespCdMDao.selectRepRespCd(comRespCdM);

		if (StringUtils.isNotEmpty(repRespCd)) {
			log.info("대표응답코드: {}", repRespCd);
			return repRespCd;
		}

		// 대표응답코드도 없으면 오류
		// BusinessException인지 InternalResponseException인지 확인 필요
		// throw new BusinessException("응답코드가 없음");
		return respCd;
		// TODO : 오류 반환 삭제, 각 업무의 default 오류코드 정의
	}
	
	/**
	 * 입력받은 HOST 계좌번호 양식을 KFTC 양식에 맞게 변경한다.
	 * 
	 * @param hostAcctNo
	 * @return kftcAcctNo : 앞 "00" 두자리 제거
	 */
	public String getAcctNoToKftcFormat(String hostAcctNo) {
		log.info("//////////// 변경 전 acctNo : {}", hostAcctNo);
		;

		String kftcAcctNo = hostAcctNo;
		if (!StringUtils.isEmpty(hostAcctNo) && hostAcctNo.length() == 12
				&& hostAcctNo.startsWith(ComConst.CHAR_00)) {
			kftcAcctNo = hostAcctNo.substring(2);
		} else {
			log.trace("===계좌번호 양식 변경 HOST -> KFTC ::: 입력된 계좌번호가 올바르지 않습니다.");
			log.trace(hostAcctNo);
		}

		log.info("//////////// 변경 후 acctNo : {}", kftcAcctNo);
		return kftcAcctNo;
	}
	
	/**
	 * hostNo또는 trUnqNo를 키값으로 당일자에COM_TR_HOLD_L 테이블을 조회한다. 
	 * 01 대기상태인 거래가 조회되는 경우, 02 RELEASE상태로 변경한다.
	 * hostNo: 당발요청/당발응답 (8자리 이하)
	 * trUnqNo: 타발요청 (13자리) - HOF만 해당
	 * hostNo+trUnqNo: HOF 당발응답 (21자리)
	 * @param keyValue
	 */
	public void setComHoldStatusDone(String keyValue) {

		if (StringUtils.isEmpty(keyValue)) {
			throw new BusinessException("HOST 또는 결제원 거래일련번호는 필수값입니다.");
		}
		
		String trUnqNO = "";
		if (null != keyValue && keyValue.length() == 21) { // hostNo(8) + trUnqNo (13)
			trUnqNO = keyValue.substring(8);		// trUnqNo
			keyValue = keyValue.substring(0,8);		// hostNo
		}

		// hostNo 로 당일 대기중인 거래 조회
		ComTrHoldL holdingTr = comTrHoldLDao.selectHoldingTrByKeyValue(keyValue, null);

		// 대기거래가 있는 경우
		if (holdingTr != null) {
			// 해당거래의 상태를 '02 : release' 로 변경한다.
			ComTrHoldL updateIn = new ComTrHoldL();
			updateIn.setTrDt(holdingTr.getTrDt());
			updateIn.setTrSeq(holdingTr.getTrSeq());
			updateIn.setHoldRsnCd(holdingTr.getHoldRsnCd());
			updateIn.setHoldStsCd("02");
			updateIn.setRtryCnt(1L);
			// 2025.03.26 대기거래 처리일자,시간 설정 / 거래고유번호 추가
			updateIn.setTrUnqNo(trUnqNO);
			updateIn.setRelsPrcsDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
			updateIn.setRelsPrcsTm(LocalDateTime.now().format(DateFormat.HHMMSS.getFormatter()));
			
			comTrHoldLDao.updateHoldStatus(updateIn);
			log.info("=======대기상태업데이트 판단 : 완료 상태로 변경");
		} else {
			log.info("=======대기상태업데이트 판단 : 대기 상태 거래가 아니었음");
		}

	}

	/**
	 * hostNo또는 trUnqNo를 키값으로 
	 * 입력된 trDt에 COM_TR_HOLD_L 테이블을 조회한다. 
	 * 01 대기상태인 거래가 조회되는 경우, 02 RELEASE상태로 변경한다.
	 * @param ComTrHoldL
	 */
	public ComTrHoldL setComHoldStatusDone(ComTrHoldLIn in) {

		log.debug("====== selectHoldingTr In : {}", in);
		
		ComTrHoldL comTrHoldL = new ComTrHoldL();
		comTrHoldL.setTrDt(in.getTrDt());
		comTrHoldL.setHostNo(in.getHostNo());
		comTrHoldL.setTrUnqNo(in.getSelTrUnqNo());
		
		// hostNo / trUnqNo 로 당일 대기중인 거래 조회
		ComTrHoldL holdingTr = comTrHoldLDao.selectHoldingTr(comTrHoldL);

		// 대기거래가 있는 경우
		if (holdingTr != null) {
			boolean isUpdate = true;
			if(!StringUtils.isEmpty(in.getHoldRsnCd()) && 
					holdingTr.getHoldRsnCd().equals(in.getHoldRsnCd())) isUpdate = false;		// 동일 대기사유면 release 하지 않음
			
			if(isUpdate) {
				// 해당거래의 상태를 '02 : release' 로 변경한다.
				ComTrHoldL updateIn = new ComTrHoldL();
				updateIn.setTrDt(holdingTr.getTrDt());
				updateIn.setTrSeq(holdingTr.getTrSeq());
				updateIn.setHoldRsnCd(holdingTr.getHoldRsnCd());
				updateIn.setHoldStsCd("02");
				updateIn.setRtryCnt(1L);
				
				// 2025.03.26 대기거래 처리일자,시간 설정 / 거래고유번호 추가
				updateIn.setTrUnqNo(in.getUpTrUnqNo());		// 업데이트 trUnqNo
				updateIn.setRelsPrcsDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
				updateIn.setRelsPrcsTm(LocalDateTime.now().format(DateFormat.HHMMSS.getFormatter()));
				// 2025.03.31 대기거래 중복 방지를 위해 999로 업데이트 로직 추가
				updateIn.setRespCd(in.getRespCd());
				
				comTrHoldLDao.updateHoldStatus(updateIn);
				log.info("=======대기상태업데이트 판단 : 완료 상태로 변경");
			} else {
				log.info("=======동일 대기사유코드로 미처리");
			}
		} else {
			log.info("=======대기상태업데이트 판단 : 대기 상태 거래가 아니었음");
		}
		
		return holdingTr;
	}
	
	/**
	 * hostNo또는 trUnqNo를 키값으로 
	 * 입력된 trDt에 COM_TR_HOLD_L 테이블을 조회한다. 
	 * 01 대기상태인 거래가 조회되는 경우, 02 RELEASE상태로 변경한다.
	 * hostNo: 당발요청/당발응답 (8자리 이하)
	 * trUnqNo: 타발요청 (13자리) - HOF만 해당
	 * hostNo+trUnqNo: HOF 당발응답 (21자리)
	 * @param keyValue
	 */
	public void setComHoldStatusDone(String keyValue, String trDt) {
		
		if (StringUtils.isEmpty(keyValue) || StringUtils.isEmpty(trDt)) {
			throw new BusinessException("파라미터는 모두 필수값 입니다.");
		}
		
		// hostNo 로 당일 대기중인 거래 조회
		ComTrHoldL holdingTr = comTrHoldLDao.selectHoldingTrByKeyValue(keyValue, trDt);
		
		// 대기거래가 있는 경우
		if (holdingTr != null) {
			// 해당거래의 상태를 '02 : release' 로 변경한다.
			ComTrHoldL updateIn = new ComTrHoldL();
			updateIn.setTrDt(holdingTr.getTrDt());
			updateIn.setTrSeq(holdingTr.getTrSeq());
			updateIn.setHoldRsnCd(holdingTr.getHoldRsnCd());
			updateIn.setHoldStsCd("02");
			updateIn.setRtryCnt(1L);
			
			// 2025.03.26 대기거래 처리일자,시간 설정 추가
			updateIn.setRelsPrcsDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
			updateIn.setRelsPrcsTm(LocalDateTime.now().format(DateFormat.HHMMSS.getFormatter()));
			
			comTrHoldLDao.updateHoldStatus(updateIn);
			log.info("=======대기상태업데이트 판단 : 완료 상태로 변경");
		} else {
			log.info("=======대기상태업데이트 판단 : 대기 상태 거래가 아니었음");
		}
		
	}

	/**
	 * 2024.09.06 한성흔
	 * 입력받은 key값과 테이블의 채번에서 관리하는 key값의
	 * 최대값을 비교해
	 * 최대값으로 테이블의 채번값을 update한다.
	 * @param nbrgId
	 * @param keyNo
	 */
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateMaxNumId(String bizDvsnCd, NumberingEnum nbrgId, String keyNo) {
		ComNbrgM nbrgIn = new ComNbrgM();
		nbrgIn.setBizDvsnCd(bizDvsnCd);
		nbrgIn.setNbrgId(nbrgId.getName());
		ComNbrgM nbrgOut = comNbrgMDao.selectListComNbrgM(nbrgIn);

		if (nbrgOut != null) {
			int tableMaxNum = Integer.parseInt(nbrgOut.getNbrgNo()) + 1;
			int msgMaxNum = Integer.parseInt(keyNo) + 1;

			int nextExpectedNo = tableMaxNum <= msgMaxNum ? msgMaxNum : tableMaxNum;

			nbrgOut.setNbrgNo(String.format(nbrgId.getFormat(), nextExpectedNo));
			log.info("==================채번테이블 업데이트 {} ", nbrgOut.getNbrgNo());
			comNbrgMDao.updateComNbrgM(nbrgOut);
		}
	}

	/**
	 * HOF채번 ENUM으로 변경
	 * @param nbrEnum
	 * @return
	 */
	public String getHofOracleSeqNo(NumberingEnum nbrgEnum) {
		long nextSeqNo = 0;

		if (nbrgEnum.equals(NumberingEnum.HOFKFT01)) {
			nextSeqNo = comNbrgMDao.selectHofTrUnqNoSeq();
		} else if (nbrgEnum.equals(NumberingEnum.HOFLVB01)) {
			nextSeqNo = comNbrgMDao.selectHofMsgNoSeq();
		}
		
		String formattedNbrgNo = String.format(nbrgEnum.getFormat(), nextSeqNo);

		return formattedNbrgNo;
	}
	
	/**
	 * 대기거래 시작일자/시간(예정) 설정
	 * @param holdIn
	 */
	private void _setHoldTrRelsStaDttm(ComTrHoldL holdIn) {
		String today = LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter());
		String abizDt = bizDate.getNextBizDay(today, 1);
	    log.info("익영업일::", abizDt);
	    
	    try {
	    	ComCdD comCdD = new ComCdD();
	    	switch(HoldRsnCdEnum.findByCode(holdIn.getHoldRsnCd())) {
	    	// KCG서비스시간 [01]
	    	case KCG_SERVICE_HOUR:
	    		
	    		comCdD = comCdDMapper.selectByPrimaryKey("SVC_TM_DVSN_CD", ComConst.CHAR_01);

	    		holdIn.setRelsStaDt(today);
	    		holdIn.setRelsStaTm(comCdD.getSubCdChar1().replace(":", "").concat(ComConst.CHAR_00));	// 당발 영업일시
	    		
	    		break;
	    		
    		// 공휴일 [02]
	    	case HOLIDAY:
	    		
	    		comCdD = comCdDMapper.selectByPrimaryKey("SVC_TM_DVSN_CD", ComConst.CHAR_03);

	    		holdIn.setRelsStaDt(abizDt);	// 익영업일
	    		holdIn.setRelsStaTm(comCdD.getSubCdChar1().replace(":", "").concat(ComConst.CHAR_00));	// 타발 영업일시
	    		
	    		break;
	    		
    		// 계좌 서비스 시간 [03]
	    	case ACCOUNT_SERVICE_HOUR:
	    		
	    		ComTrHoldL comTrHoldL = new ComTrHoldL();

	    		comTrHoldL.setRcvAcctNo(holdIn.getWhdrwlAcctNo());
	    		
	    		List<ComTrHoldL> releaseTraget = comTrHoldLDao.selectAcctStatmReleaseTarget(comTrHoldL);

	    		if (!ObjectUtils.isEmpty(releaseTraget)) {
	    			String staTime = releaseTraget.get(0).getRelsStaTm();
	    			log.debug("staTime  : {} ", staTime);
    				holdIn.setRelsStaDt(today);
    				holdIn.setRelsStaTm(staTime);
	    		}
	    		break;
			default:
				holdIn.setRelsStaDt(today);	// 외 대기사유코드는 당일로 설정
				break;
			}
		} catch (Exception e) {
			log.error("==== setHoldTrRelsStaDttm Error!!", e);
		}
    }
}
