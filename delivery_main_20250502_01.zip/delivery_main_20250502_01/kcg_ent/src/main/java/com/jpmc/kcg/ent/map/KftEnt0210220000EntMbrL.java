package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.KftEnt0210220000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {LocalDateTime.class, BigDecimal.class, DateUtils.class, EntConst.class, ComConst.class})
public interface KftEnt0210220000EntMbrL extends Converter<KftEnt0210220000, EntMbrL> {

    @Override
    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())")
    @Mapping(target = "entTlgTrceNo", source = "messageTrackingNumber")
    @Mapping(target = "trUnqNo", source = "transactionIdNumber")
    @Mapping(target = "hostNo", ignore = true)
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.INBOUND_CD)")
    @Mapping(target = "othrPartyBnkCd", ignore = true)
    @Mapping(target = "sysDvsn", source = "systemId")
    @Mapping(target = "bnkCd", source = "bnkCd")
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType")
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode")
    @Mapping(target = "sndRcvDvsnCd", source = "sendReceiveFlag")
    @Mapping(target = "trSts", source = "status")
    @Mapping(target = "respCd1", source = "responseCode1")
    @Mapping(target = "respCd2", source = "responseCode2")
    @Mapping(target = "tlgTrDt", source = "messageSendTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "messageSendTime", dateFormat = "HHmmss")
    @Mapping(target = "kftcStattcCd", source = "kftcStatisticsCode")
    // 조건 관련
    @Mapping(target = "srchCondSort", source = "conditionSearchConditionSort")
    @Mapping(target = "condCtzBizNoEnc", source = "conditionResidentBusinessNumber")
    @Mapping(target = "condBnkCd", source = "conditionBankCode")
    @Mapping(target = "condDpstAcctNo", source = "conditionDepositAccountNumber")
    // 결과 관련
    @Mapping(target = "corpIndvDvsnCd", source = "resultCorpIndvSort")
    @Mapping(target = "repNm", source = "resultNameRepresentativeName")
    @Mapping(target = "corpNm", source = "resultCorpName")
    @Mapping(target = "mbrAddr", source = "resultAddress")
    @Mapping(target = "mbrTelNo", source = "resultPhoneNumber")
    @Mapping(target = "mbrMobileNo", source = "resultMobilePhoneNumber")
    @Mapping(target = "mbrEmail", source = "resultEmail")
    @Mapping(target = "mbrDvsnCd", source = "resultMemberSort")
    @Mapping(target = "corpSizeCd", source = "resultCompanySize")
    @Mapping(target = "bizCd", source = "resultIndustryCode")
    EntMbrL convert(KftEnt0210220000 source);
}