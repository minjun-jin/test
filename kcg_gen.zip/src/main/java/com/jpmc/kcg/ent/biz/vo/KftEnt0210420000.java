package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 발행보증인별 발행보증내역 조회 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * sortCondition 정렬조건 
 * searchConditionSort 검색조건구분 
 * inquiryNoteGuaranteeStatusSort 조회전자어음보증상태구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * depositAccountNumber 입금계좌번호 
 * guaranteeRequestDateBasisQueryStartDate 보증요청일기준조회시작일 
 * guaranteeRequestDateBasisQueryEndDate 보증요청일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.guaranteeDetailsIssuanceGuaranteeSort (조회결과)보증내역-01발행보증구분 
 * queryResultArray.guaranteeDetailsBeforeAfterIssueSort (조회결과)보증내역-02발행전/후구분 
 * queryResultArray.guaranteeDetailsGuaranteeRequestDate (조회결과)보증내역-03보증요청일자 
 * queryResultArray.guaranteeDetailsGuaranteeProcessingDate (조회결과)보증내역-04보증처리일자 
 * queryResultArray.guaranteeDetailsGuaranteeProcessSort (조회결과)보증내역-05보증처리구분 
 * queryResultArray.noteDetailsEnoteNumber (조회결과)어음내역-06전자어음번호 
 * queryResultArray.noteDetailsEnoteType (조회결과)어음내역-07전자어음종류 
 * queryResultArray.noteDetailsEnoteProcessStatus (조회결과)어음내역-08전자어음처리상태 
 * queryResultArray.noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
 * queryResultArray.noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
 * queryResultArray.noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
 * queryResultArray.noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
 * queryResultArray.noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
 * queryResultArray.issuerCorpIndvSort (조회결과)발행인-개인법인구분 
 * queryResultArray.issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
 * queryResultArray.issuerCorpName (조회결과)발행인-법인명 
 * queryResultArray.issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
 * queryResultArray.issuerAddress (조회결과)발행인-주소 
 * queryResultArray.issuerBankCode (조회결과)발행인-은행코드 
 * queryResultArray.issuerCurrentAccountNumber (조회결과)발행인-당좌계좌번호 
 * queryResultArray.beneCorpIndvSort (조회결과)수취인-개인법인구분 
 * queryResultArray.beneResidentBusinessNumber (조회결과)수취인-주민사업자번호 
 * queryResultArray.beneCorpName (조회결과)수취인-법인명 
 * queryResultArray.beneNameRepresentativeName (조회결과)수취인-성명(대표자명) 
 * queryResultArray.beneAddress (조회결과)수취인-주소 
 * queryResultArray.beneBankCode (조회결과)수취인-은행코드 
 * queryResultArray.beneDepositAccountNumber (조회결과)수취인-입금계좌번호 
 * queryResultArray.issuanceProvisionConditionsNonTransferableSplitNumber (조회결과)발행부기요건-지시금지여부분할번호 
 * queryResultArray.issuanceGuarantorCorpIndvSort (조회결과)발행보증인-개인법인구분 
 * queryResultArray.issuanceGuarantorResidentBusinessNumber (조회결과)발행보증인-주민사업자번호 
 * queryResultArray.issuanceGuarantorCorpName (조회결과)발행보증인-법인명 
 * queryResultArray.issuanceGuarantorNameRepresentativeName (조회결과)발행보증인-성명(대표자명) 
 * queryResultArray.issuanceGuarantorAddress (조회결과)발행보증인-주소 
 * queryResultArray.issuanceGuarantorBankCode (조회결과)발행보증인-은행코드 
 * queryResultArray.issuanceGuarantorDepositAccountNumber (조회결과)발행보증인-입금계좌번호 
 * queryResultArray.guaranteeTargetSplitNumber (조회결과)보증대상분할번호 
 * queryResultArray.guaranteeTargetEndorsementNumber (조회결과)보증대상배서번호 
 * queryResultArray.guaranteeNumber (조회결과)보증번호 
 * 
 * KftEnt0210420000 kftEnt0210420000 = new KftEnt0210420000(); // 발행보증인별 발행보증내역 조회 응답
 * kftEnt0210420000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210420000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210420000.setBnkCd("057"); // 은행코드
 * kftEnt0210420000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210420000.setTransactionCode("420000"); // 거래구분코드
 * kftEnt0210420000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210420000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210420000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210420000.setStatus("000"); // STATUS
 * kftEnt0210420000.setResponseCode1(""); // 응답코드1
 * kftEnt0210420000.setResponseCode2(""); // 응답코드2
 * kftEnt0210420000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210420000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210420000.setSortCondition(""); // 정렬조건
 * kftEnt0210420000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0210420000.setInquiryNoteGuaranteeStatusSort(""); // 조회전자어음보증상태구분
 * kftEnt0210420000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210420000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0210420000.setDepositAccountNumber(""); // 입금계좌번호
 * kftEnt0210420000.setGuaranteeRequestDateBasisQueryStartDate(""); // 보증요청일기준조회시작일
 * kftEnt0210420000.setGuaranteeRequestDateBasisQueryEndDate(""); // 보증요청일기준조회종료일
 * kftEnt0210420000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0210420000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0210420000.setCurrentCount(0); // 현재건수
 * KftEnt0210420000.QueryResult queryResult = new KftEnt0210420000.QueryResult(); // 조회결과Array
 * queryResult.setGuaranteeDetailsIssuanceGuaranteeSort(""); // (조회결과)보증내역-01발행보증구분
 * queryResult.setGuaranteeDetailsBeforeAfterIssueSort(""); // (조회결과)보증내역-02발행전/후구분
 * queryResult.setGuaranteeDetailsGuaranteeRequestDate(""); // (조회결과)보증내역-03보증요청일자
 * queryResult.setGuaranteeDetailsGuaranteeProcessingDate(""); // (조회결과)보증내역-04보증처리일자
 * queryResult.setGuaranteeDetailsGuaranteeProcessSort(""); // (조회결과)보증내역-05보증처리구분
 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-06전자어음번호
 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-07전자어음종류
 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-08전자어음처리상태
 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
 * queryResult.setIssuerBankCode(""); // (조회결과)발행인-은행코드
 * queryResult.setIssuerCurrentAccountNumber(""); // (조회결과)발행인-당좌계좌번호
 * queryResult.setBeneCorpIndvSort(""); // (조회결과)수취인-개인법인구분
 * queryResult.setBeneResidentBusinessNumber(""); // (조회결과)수취인-주민사업자번호
 * queryResult.setBeneCorpName(""); // (조회결과)수취인-법인명
 * queryResult.setBeneNameRepresentativeName(""); // (조회결과)수취인-성명(대표자명)
 * queryResult.setBeneAddress(""); // (조회결과)수취인-주소
 * queryResult.setBeneBankCode(""); // (조회결과)수취인-은행코드
 * queryResult.setBeneDepositAccountNumber(""); // (조회결과)수취인-입금계좌번호
 * queryResult.setIssuanceProvisionConditionsNonTransferableSplitNumber(""); // (조회결과)발행부기요건-지시금지여부분할번호
 * queryResult.setIssuanceGuarantorCorpIndvSort(""); // (조회결과)발행보증인-개인법인구분
 * queryResult.setIssuanceGuarantorResidentBusinessNumber(""); // (조회결과)발행보증인-주민사업자번호
 * queryResult.setIssuanceGuarantorCorpName(""); // (조회결과)발행보증인-법인명
 * queryResult.setIssuanceGuarantorNameRepresentativeName(""); // (조회결과)발행보증인-성명(대표자명)
 * queryResult.setIssuanceGuarantorAddress(""); // (조회결과)발행보증인-주소
 * queryResult.setIssuanceGuarantorBankCode(""); // (조회결과)발행보증인-은행코드
 * queryResult.setIssuanceGuarantorDepositAccountNumber(""); // (조회결과)발행보증인-입금계좌번호
 * queryResult.setGuaranteeTargetSplitNumber(""); // (조회결과)보증대상분할번호
 * queryResult.setGuaranteeTargetEndorsementNumber(""); // (조회결과)보증대상배서번호
 * queryResult.setGuaranteeNumber(""); // (조회결과)보증번호
 * kftEnt0210420000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0210420000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * guaranteeDetailsIssuanceGuaranteeSort (조회결과)보증내역-01발행보증구분 
	 * guaranteeDetailsBeforeAfterIssueSort (조회결과)보증내역-02발행전/후구분 
	 * guaranteeDetailsGuaranteeRequestDate (조회결과)보증내역-03보증요청일자 
	 * guaranteeDetailsGuaranteeProcessingDate (조회결과)보증내역-04보증처리일자 
	 * guaranteeDetailsGuaranteeProcessSort (조회결과)보증내역-05보증처리구분 
	 * noteDetailsEnoteNumber (조회결과)어음내역-06전자어음번호 
	 * noteDetailsEnoteType (조회결과)어음내역-07전자어음종류 
	 * noteDetailsEnoteProcessStatus (조회결과)어음내역-08전자어음처리상태 
	 * noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
	 * noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
	 * noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
	 * noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
	 * noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
	 * issuerCorpIndvSort (조회결과)발행인-개인법인구분 
	 * issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
	 * issuerCorpName (조회결과)발행인-법인명 
	 * issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
	 * issuerAddress (조회결과)발행인-주소 
	 * issuerBankCode (조회결과)발행인-은행코드 
	 * issuerCurrentAccountNumber (조회결과)발행인-당좌계좌번호 
	 * beneCorpIndvSort (조회결과)수취인-개인법인구분 
	 * beneResidentBusinessNumber (조회결과)수취인-주민사업자번호 
	 * beneCorpName (조회결과)수취인-법인명 
	 * beneNameRepresentativeName (조회결과)수취인-성명(대표자명) 
	 * beneAddress (조회결과)수취인-주소 
	 * beneBankCode (조회결과)수취인-은행코드 
	 * beneDepositAccountNumber (조회결과)수취인-입금계좌번호 
	 * issuanceProvisionConditionsNonTransferableSplitNumber (조회결과)발행부기요건-지시금지여부분할번호 
	 * issuanceGuarantorCorpIndvSort (조회결과)발행보증인-개인법인구분 
	 * issuanceGuarantorResidentBusinessNumber (조회결과)발행보증인-주민사업자번호 
	 * issuanceGuarantorCorpName (조회결과)발행보증인-법인명 
	 * issuanceGuarantorNameRepresentativeName (조회결과)발행보증인-성명(대표자명) 
	 * issuanceGuarantorAddress (조회결과)발행보증인-주소 
	 * issuanceGuarantorBankCode (조회결과)발행보증인-은행코드 
	 * issuanceGuarantorDepositAccountNumber (조회결과)발행보증인-입금계좌번호 
	 * guaranteeTargetSplitNumber (조회결과)보증대상분할번호 
	 * guaranteeTargetEndorsementNumber (조회결과)보증대상배서번호 
	 * guaranteeNumber (조회결과)보증번호 
	 * 
	 * KftEnt0210420000.QueryResult queryResult = new KftEnt0210420000.QueryResult(); // 조회결과Array
	 * queryResult.setGuaranteeDetailsIssuanceGuaranteeSort(""); // (조회결과)보증내역-01발행보증구분
	 * queryResult.setGuaranteeDetailsBeforeAfterIssueSort(""); // (조회결과)보증내역-02발행전/후구분
	 * queryResult.setGuaranteeDetailsGuaranteeRequestDate(""); // (조회결과)보증내역-03보증요청일자
	 * queryResult.setGuaranteeDetailsGuaranteeProcessingDate(""); // (조회결과)보증내역-04보증처리일자
	 * queryResult.setGuaranteeDetailsGuaranteeProcessSort(""); // (조회결과)보증내역-05보증처리구분
	 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-06전자어음번호
	 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-07전자어음종류
	 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-08전자어음처리상태
	 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
	 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
	 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
	 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
	 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
	 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
	 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
	 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
	 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
	 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
	 * queryResult.setIssuerBankCode(""); // (조회결과)발행인-은행코드
	 * queryResult.setIssuerCurrentAccountNumber(""); // (조회결과)발행인-당좌계좌번호
	 * queryResult.setBeneCorpIndvSort(""); // (조회결과)수취인-개인법인구분
	 * queryResult.setBeneResidentBusinessNumber(""); // (조회결과)수취인-주민사업자번호
	 * queryResult.setBeneCorpName(""); // (조회결과)수취인-법인명
	 * queryResult.setBeneNameRepresentativeName(""); // (조회결과)수취인-성명(대표자명)
	 * queryResult.setBeneAddress(""); // (조회결과)수취인-주소
	 * queryResult.setBeneBankCode(""); // (조회결과)수취인-은행코드
	 * queryResult.setBeneDepositAccountNumber(""); // (조회결과)수취인-입금계좌번호
	 * queryResult.setIssuanceProvisionConditionsNonTransferableSplitNumber(""); // (조회결과)발행부기요건-지시금지여부분할번호
	 * queryResult.setIssuanceGuarantorCorpIndvSort(""); // (조회결과)발행보증인-개인법인구분
	 * queryResult.setIssuanceGuarantorResidentBusinessNumber(""); // (조회결과)발행보증인-주민사업자번호
	 * queryResult.setIssuanceGuarantorCorpName(""); // (조회결과)발행보증인-법인명
	 * queryResult.setIssuanceGuarantorNameRepresentativeName(""); // (조회결과)발행보증인-성명(대표자명)
	 * queryResult.setIssuanceGuarantorAddress(""); // (조회결과)발행보증인-주소
	 * queryResult.setIssuanceGuarantorBankCode(""); // (조회결과)발행보증인-은행코드
	 * queryResult.setIssuanceGuarantorDepositAccountNumber(""); // (조회결과)발행보증인-입금계좌번호
	 * queryResult.setGuaranteeTargetSplitNumber(""); // (조회결과)보증대상분할번호
	 * queryResult.setGuaranteeTargetEndorsementNumber(""); // (조회결과)보증대상배서번호
	 * queryResult.setGuaranteeNumber(""); // (조회결과)보증번호
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String guaranteeDetailsIssuanceGuaranteeSort; // (조회결과)보증내역-01발행보증구분
		private String guaranteeDetailsBeforeAfterIssueSort; // (조회결과)보증내역-02발행전/후구분
		private String guaranteeDetailsGuaranteeRequestDate; // (조회결과)보증내역-03보증요청일자
		private String guaranteeDetailsGuaranteeProcessingDate; // (조회결과)보증내역-04보증처리일자
		private String guaranteeDetailsGuaranteeProcessSort; // (조회결과)보증내역-05보증처리구분
		private String noteDetailsEnoteNumber; // (조회결과)어음내역-06전자어음번호
		private String noteDetailsEnoteType; // (조회결과)어음내역-07전자어음종류
		private String noteDetailsEnoteProcessStatus; // (조회결과)어음내역-08전자어음처리상태
		private String noteDetailsEnoteIssueDate; // (조회결과)어음내역-전자어음발행일자
		private String noteDetailsEnoteIssuePlace; // (조회결과)어음내역-전자어음발행지
		private long noteDetailsEnoteAmount; // (조회결과)어음내역-전자어음금액
		private String noteDetailsEnoteMaturedDate; // (조회결과)어음내역-전자어음만기일자
		private String noteDetailsPaymentBankAndBranchCode; // (조회결과)어음내역-지급은행및지점코드
		private String issuerCorpIndvSort; // (조회결과)발행인-개인법인구분
		private String issuerResidentBusinessNumber; // (조회결과)발행인-주민사업자번호
		private String issuerCorpName; // (조회결과)발행인-법인명
		private String issuerNameRepresentativeName; // (조회결과)발행인-성명(대표자명)
		private String issuerAddress; // (조회결과)발행인-주소
		private String issuerBankCode; // (조회결과)발행인-은행코드
		private String issuerCurrentAccountNumber; // (조회결과)발행인-당좌계좌번호
		private String beneCorpIndvSort; // (조회결과)수취인-개인법인구분
		private String beneResidentBusinessNumber; // (조회결과)수취인-주민사업자번호
		private String beneCorpName; // (조회결과)수취인-법인명
		private String beneNameRepresentativeName; // (조회결과)수취인-성명(대표자명)
		private String beneAddress; // (조회결과)수취인-주소
		private String beneBankCode; // (조회결과)수취인-은행코드
		private String beneDepositAccountNumber; // (조회결과)수취인-입금계좌번호
		private String issuanceProvisionConditionsNonTransferableSplitNumber; // (조회결과)발행부기요건-지시금지여부분할번호
		private String issuanceGuarantorCorpIndvSort; // (조회결과)발행보증인-개인법인구분
		private String issuanceGuarantorResidentBusinessNumber; // (조회결과)발행보증인-주민사업자번호
		private String issuanceGuarantorCorpName; // (조회결과)발행보증인-법인명
		private String issuanceGuarantorNameRepresentativeName; // (조회결과)발행보증인-성명(대표자명)
		private String issuanceGuarantorAddress; // (조회결과)발행보증인-주소
		private String issuanceGuarantorBankCode; // (조회결과)발행보증인-은행코드
		private String issuanceGuarantorDepositAccountNumber; // (조회결과)발행보증인-입금계좌번호
		private String guaranteeTargetSplitNumber; // (조회결과)보증대상분할번호
		private String guaranteeTargetEndorsementNumber; // (조회결과)보증대상배서번호
		private String guaranteeNumber; // (조회결과)보증번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsIssuanceGuaranteeSort$; // (조회결과)보증내역-01발행보증구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsBeforeAfterIssueSort$; // (조회결과)보증내역-02발행전/후구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeRequestDate$; // (조회결과)보증내역-03보증요청일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeProcessingDate$; // (조회결과)보증내역-04보증처리일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeProcessSort$; // (조회결과)보증내역-05보증처리구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteNumber$; // (조회결과)어음내역-06전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteType$; // (조회결과)어음내역-07전자어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteProcessStatus$; // (조회결과)어음내역-08전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssueDate$; // (조회결과)어음내역-전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssuePlace$; // (조회결과)어음내역-전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteAmount$; // (조회결과)어음내역-전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteMaturedDate$; // (조회결과)어음내역-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsPaymentBankAndBranchCode$; // (조회결과)어음내역-지급은행및지점코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpIndvSort$; // (조회결과)발행인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerResidentBusinessNumber$; // (조회결과)발행인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpName$; // (조회결과)발행인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerNameRepresentativeName$; // (조회결과)발행인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerAddress$; // (조회결과)발행인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerBankCode$; // (조회결과)발행인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCurrentAccountNumber$; // (조회결과)발행인-당좌계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneCorpIndvSort$; // (조회결과)수취인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneResidentBusinessNumber$; // (조회결과)수취인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneCorpName$; // (조회결과)수취인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneNameRepresentativeName$; // (조회결과)수취인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneAddress$; // (조회결과)수취인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneBankCode$; // (조회결과)수취인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beneDepositAccountNumber$; // (조회결과)수취인-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceProvisionConditionsNonTransferableSplitNumber$; // (조회결과)발행부기요건-지시금지여부분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorCorpIndvSort$; // (조회결과)발행보증인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorResidentBusinessNumber$; // (조회결과)발행보증인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorCorpName$; // (조회결과)발행보증인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorNameRepresentativeName$; // (조회결과)발행보증인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorAddress$; // (조회결과)발행보증인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorBankCode$; // (조회결과)발행보증인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuarantorDepositAccountNumber$; // (조회결과)발행보증인-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeTargetSplitNumber$; // (조회결과)보증대상분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeTargetEndorsementNumber$; // (조회결과)보증대상배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeNumber$; // (조회결과)보증번호

		@Override
		public void write(OutputStream out) throws IOException {
			guaranteeDetailsIssuanceGuaranteeSort$ = VOUtils.write(out, guaranteeDetailsIssuanceGuaranteeSort, 1); // (조회결과)보증내역-01발행보증구분
			guaranteeDetailsBeforeAfterIssueSort$ = VOUtils.write(out, guaranteeDetailsBeforeAfterIssueSort, 1); // (조회결과)보증내역-02발행전/후구분
			guaranteeDetailsGuaranteeRequestDate$ = VOUtils.write(out, guaranteeDetailsGuaranteeRequestDate, 8); // (조회결과)보증내역-03보증요청일자
			guaranteeDetailsGuaranteeProcessingDate$ = VOUtils.write(out, guaranteeDetailsGuaranteeProcessingDate, 8); // (조회결과)보증내역-04보증처리일자
			guaranteeDetailsGuaranteeProcessSort$ = VOUtils.write(out, guaranteeDetailsGuaranteeProcessSort, 1); // (조회결과)보증내역-05보증처리구분
			noteDetailsEnoteNumber$ = VOUtils.write(out, noteDetailsEnoteNumber, 20); // (조회결과)어음내역-06전자어음번호
			noteDetailsEnoteType$ = VOUtils.write(out, noteDetailsEnoteType, 1); // (조회결과)어음내역-07전자어음종류
			noteDetailsEnoteProcessStatus$ = VOUtils.write(out, noteDetailsEnoteProcessStatus, 2); // (조회결과)어음내역-08전자어음처리상태
			noteDetailsEnoteIssueDate$ = VOUtils.write(out, noteDetailsEnoteIssueDate, 8); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace$ = VOUtils.write(out, noteDetailsEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount$ = VOUtils.write(out, noteDetailsEnoteAmount, 15); // (조회결과)어음내역-전자어음금액
			noteDetailsEnoteMaturedDate$ = VOUtils.write(out, noteDetailsEnoteMaturedDate, 8); // (조회결과)어음내역-전자어음만기일자
			noteDetailsPaymentBankAndBranchCode$ = VOUtils.write(out, noteDetailsPaymentBankAndBranchCode, 7); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // (조회결과)발행인-주민사업자번호
			issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // (조회결과)발행인-법인명
			issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인-성명(대표자명)
			issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // (조회결과)발행인-주소
			issuerBankCode$ = VOUtils.write(out, issuerBankCode, 3); // (조회결과)발행인-은행코드
			issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // (조회결과)발행인-당좌계좌번호
			beneCorpIndvSort$ = VOUtils.write(out, beneCorpIndvSort, 1); // (조회결과)수취인-개인법인구분
			beneResidentBusinessNumber$ = VOUtils.write(out, beneResidentBusinessNumber, 13); // (조회결과)수취인-주민사업자번호
			beneCorpName$ = VOUtils.write(out, beneCorpName, 40, "EUC-KR"); // (조회결과)수취인-법인명
			beneNameRepresentativeName$ = VOUtils.write(out, beneNameRepresentativeName, 20, "EUC-KR"); // (조회결과)수취인-성명(대표자명)
			beneAddress$ = VOUtils.write(out, beneAddress, 60, "EUC-KR"); // (조회결과)수취인-주소
			beneBankCode$ = VOUtils.write(out, beneBankCode, 3); // (조회결과)수취인-은행코드
			beneDepositAccountNumber$ = VOUtils.write(out, beneDepositAccountNumber, 16); // (조회결과)수취인-입금계좌번호
			issuanceProvisionConditionsNonTransferableSplitNumber$ = VOUtils.write(out, issuanceProvisionConditionsNonTransferableSplitNumber, 1); // (조회결과)발행부기요건-지시금지여부분할번호
			issuanceGuarantorCorpIndvSort$ = VOUtils.write(out, issuanceGuarantorCorpIndvSort, 1); // (조회결과)발행보증인-개인법인구분
			issuanceGuarantorResidentBusinessNumber$ = VOUtils.write(out, issuanceGuarantorResidentBusinessNumber, 13); // (조회결과)발행보증인-주민사업자번호
			issuanceGuarantorCorpName$ = VOUtils.write(out, issuanceGuarantorCorpName, 40, "EUC-KR"); // (조회결과)발행보증인-법인명
			issuanceGuarantorNameRepresentativeName$ = VOUtils.write(out, issuanceGuarantorNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행보증인-성명(대표자명)
			issuanceGuarantorAddress$ = VOUtils.write(out, issuanceGuarantorAddress, 60, "EUC-KR"); // (조회결과)발행보증인-주소
			issuanceGuarantorBankCode$ = VOUtils.write(out, issuanceGuarantorBankCode, 3); // (조회결과)발행보증인-은행코드
			issuanceGuarantorDepositAccountNumber$ = VOUtils.write(out, issuanceGuarantorDepositAccountNumber, 16); // (조회결과)발행보증인-입금계좌번호
			guaranteeTargetSplitNumber$ = VOUtils.write(out, guaranteeTargetSplitNumber, 2); // (조회결과)보증대상분할번호
			guaranteeTargetEndorsementNumber$ = VOUtils.write(out, guaranteeTargetEndorsementNumber, 2); // (조회결과)보증대상배서번호
			guaranteeNumber$ = VOUtils.write(out, guaranteeNumber, 4); // (조회결과)보증번호
		}

		@Override
		public void read(InputStream in) throws IOException {
			guaranteeDetailsIssuanceGuaranteeSort = VOUtils.toString(guaranteeDetailsIssuanceGuaranteeSort$ = VOUtils.read(in, 1)); // (조회결과)보증내역-01발행보증구분
			guaranteeDetailsBeforeAfterIssueSort = VOUtils.toString(guaranteeDetailsBeforeAfterIssueSort$ = VOUtils.read(in, 1)); // (조회결과)보증내역-02발행전/후구분
			guaranteeDetailsGuaranteeRequestDate = VOUtils.toString(guaranteeDetailsGuaranteeRequestDate$ = VOUtils.read(in, 8)); // (조회결과)보증내역-03보증요청일자
			guaranteeDetailsGuaranteeProcessingDate = VOUtils.toString(guaranteeDetailsGuaranteeProcessingDate$ = VOUtils.read(in, 8)); // (조회결과)보증내역-04보증처리일자
			guaranteeDetailsGuaranteeProcessSort = VOUtils.toString(guaranteeDetailsGuaranteeProcessSort$ = VOUtils.read(in, 1)); // (조회결과)보증내역-05보증처리구분
			noteDetailsEnoteNumber = VOUtils.toString(noteDetailsEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음내역-06전자어음번호
			noteDetailsEnoteType = VOUtils.toString(noteDetailsEnoteType$ = VOUtils.read(in, 1)); // (조회결과)어음내역-07전자어음종류
			noteDetailsEnoteProcessStatus = VOUtils.toString(noteDetailsEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음내역-08전자어음처리상태
			noteDetailsEnoteIssueDate = VOUtils.toString(noteDetailsEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace = VOUtils.toString(noteDetailsEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount = VOUtils.toLong(noteDetailsEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음내역-전자어음금액
			noteDetailsEnoteMaturedDate = VOUtils.toString(noteDetailsEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음만기일자
			noteDetailsPaymentBankAndBranchCode = VOUtils.toString(noteDetailsPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인-주민사업자번호
			issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인-법인명
			issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인-성명(대표자명)
			issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인-주소
			issuerBankCode = VOUtils.toString(issuerBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행인-은행코드
			issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행인-당좌계좌번호
			beneCorpIndvSort = VOUtils.toString(beneCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)수취인-개인법인구분
			beneResidentBusinessNumber = VOUtils.toString(beneResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)수취인-주민사업자번호
			beneCorpName = VOUtils.toString(beneCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)수취인-법인명
			beneNameRepresentativeName = VOUtils.toString(beneNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)수취인-성명(대표자명)
			beneAddress = VOUtils.toString(beneAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)수취인-주소
			beneBankCode = VOUtils.toString(beneBankCode$ = VOUtils.read(in, 3)); // (조회결과)수취인-은행코드
			beneDepositAccountNumber = VOUtils.toString(beneDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)수취인-입금계좌번호
			issuanceProvisionConditionsNonTransferableSplitNumber = VOUtils.toString(issuanceProvisionConditionsNonTransferableSplitNumber$ = VOUtils.read(in, 1)); // (조회결과)발행부기요건-지시금지여부분할번호
			issuanceGuarantorCorpIndvSort = VOUtils.toString(issuanceGuarantorCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행보증인-개인법인구분
			issuanceGuarantorResidentBusinessNumber = VOUtils.toString(issuanceGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행보증인-주민사업자번호
			issuanceGuarantorCorpName = VOUtils.toString(issuanceGuarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행보증인-법인명
			issuanceGuarantorNameRepresentativeName = VOUtils.toString(issuanceGuarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행보증인-성명(대표자명)
			issuanceGuarantorAddress = VOUtils.toString(issuanceGuarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행보증인-주소
			issuanceGuarantorBankCode = VOUtils.toString(issuanceGuarantorBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행보증인-은행코드
			issuanceGuarantorDepositAccountNumber = VOUtils.toString(issuanceGuarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행보증인-입금계좌번호
			guaranteeTargetSplitNumber = VOUtils.toString(guaranteeTargetSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)보증대상분할번호
			guaranteeTargetEndorsementNumber = VOUtils.toString(guaranteeTargetEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)보증대상배서번호
			guaranteeNumber = VOUtils.toString(guaranteeNumber$ = VOUtils.read(in, 4)); // (조회결과)보증번호
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", guaranteeDetailsIssuanceGuaranteeSort=").append(guaranteeDetailsIssuanceGuaranteeSort).append(System.lineSeparator()); // (조회결과)보증내역-01발행보증구분
			sb.append(", guaranteeDetailsBeforeAfterIssueSort=").append(guaranteeDetailsBeforeAfterIssueSort).append(System.lineSeparator()); // (조회결과)보증내역-02발행전/후구분
			sb.append(", guaranteeDetailsGuaranteeRequestDate=").append(guaranteeDetailsGuaranteeRequestDate).append(System.lineSeparator()); // (조회결과)보증내역-03보증요청일자
			sb.append(", guaranteeDetailsGuaranteeProcessingDate=").append(guaranteeDetailsGuaranteeProcessingDate).append(System.lineSeparator()); // (조회결과)보증내역-04보증처리일자
			sb.append(", guaranteeDetailsGuaranteeProcessSort=").append(guaranteeDetailsGuaranteeProcessSort).append(System.lineSeparator()); // (조회결과)보증내역-05보증처리구분
			sb.append(", noteDetailsEnoteNumber=").append(noteDetailsEnoteNumber).append(System.lineSeparator()); // (조회결과)어음내역-06전자어음번호
			sb.append(", noteDetailsEnoteType=").append(noteDetailsEnoteType).append(System.lineSeparator()); // (조회결과)어음내역-07전자어음종류
			sb.append(", noteDetailsEnoteProcessStatus=").append(noteDetailsEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음내역-08전자어음처리상태
			sb.append(", noteDetailsEnoteIssueDate=").append(noteDetailsEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행일자
			sb.append(", noteDetailsEnoteIssuePlace=").append(noteDetailsEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행지
			sb.append(", noteDetailsEnoteAmount=").append(noteDetailsEnoteAmount).append(System.lineSeparator()); // (조회결과)어음내역-전자어음금액
			sb.append(", noteDetailsEnoteMaturedDate=").append(noteDetailsEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음만기일자
			sb.append(", noteDetailsPaymentBankAndBranchCode=").append(noteDetailsPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음내역-지급은행및지점코드
			sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인-개인법인구분
			sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인-주민사업자번호
			sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // (조회결과)발행인-법인명
			sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인-성명(대표자명)
			sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // (조회결과)발행인-주소
			sb.append(", issuerBankCode=").append(issuerBankCode).append(System.lineSeparator()); // (조회결과)발행인-은행코드
			sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행인-당좌계좌번호
			sb.append(", beneCorpIndvSort=").append(beneCorpIndvSort).append(System.lineSeparator()); // (조회결과)수취인-개인법인구분
			sb.append(", beneResidentBusinessNumber=").append(beneResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)수취인-주민사업자번호
			sb.append(", beneCorpName=").append(beneCorpName).append(System.lineSeparator()); // (조회결과)수취인-법인명
			sb.append(", beneNameRepresentativeName=").append(beneNameRepresentativeName).append(System.lineSeparator()); // (조회결과)수취인-성명(대표자명)
			sb.append(", beneAddress=").append(beneAddress).append(System.lineSeparator()); // (조회결과)수취인-주소
			sb.append(", beneBankCode=").append(beneBankCode).append(System.lineSeparator()); // (조회결과)수취인-은행코드
			sb.append(", beneDepositAccountNumber=").append(beneDepositAccountNumber).append(System.lineSeparator()); // (조회결과)수취인-입금계좌번호
			sb.append(", issuanceProvisionConditionsNonTransferableSplitNumber=").append(issuanceProvisionConditionsNonTransferableSplitNumber).append(System.lineSeparator()); // (조회결과)발행부기요건-지시금지여부분할번호
			sb.append(", issuanceGuarantorCorpIndvSort=").append(issuanceGuarantorCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행보증인-개인법인구분
			sb.append(", issuanceGuarantorResidentBusinessNumber=").append(issuanceGuarantorResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행보증인-주민사업자번호
			sb.append(", issuanceGuarantorCorpName=").append(issuanceGuarantorCorpName).append(System.lineSeparator()); // (조회결과)발행보증인-법인명
			sb.append(", issuanceGuarantorNameRepresentativeName=").append(issuanceGuarantorNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행보증인-성명(대표자명)
			sb.append(", issuanceGuarantorAddress=").append(issuanceGuarantorAddress).append(System.lineSeparator()); // (조회결과)발행보증인-주소
			sb.append(", issuanceGuarantorBankCode=").append(issuanceGuarantorBankCode).append(System.lineSeparator()); // (조회결과)발행보증인-은행코드
			sb.append(", issuanceGuarantorDepositAccountNumber=").append(issuanceGuarantorDepositAccountNumber).append(System.lineSeparator()); // (조회결과)발행보증인-입금계좌번호
			sb.append(", guaranteeTargetSplitNumber=").append(guaranteeTargetSplitNumber).append(System.lineSeparator()); // (조회결과)보증대상분할번호
			sb.append(", guaranteeTargetEndorsementNumber=").append(guaranteeTargetEndorsementNumber).append(System.lineSeparator()); // (조회결과)보증대상배서번호
			sb.append(", guaranteeNumber=").append(guaranteeNumber).append(System.lineSeparator()); // (조회결과)보증번호
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "420000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String sortCondition; // 정렬조건
	private String searchConditionSort; // 검색조건구분
	private String inquiryNoteGuaranteeStatusSort; // 조회전자어음보증상태구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String depositAccountNumber; // 입금계좌번호
	private String guaranteeRequestDateBasisQueryStartDate; // 보증요청일기준조회시작일
	private String guaranteeRequestDateBasisQueryEndDate; // 보증요청일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0210420000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sortCondition$; // 정렬조건
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String inquiryNoteGuaranteeStatusSort$; // 조회전자어음보증상태구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDateBasisQueryStartDate$; // 보증요청일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDateBasisQueryEndDate$; // 보증요청일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 18;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		sortCondition$ = VOUtils.write(out, sortCondition, 2); // 정렬조건
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		inquiryNoteGuaranteeStatusSort$ = VOUtils.write(out, inquiryNoteGuaranteeStatusSort, 1); // 조회전자어음보증상태구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		guaranteeRequestDateBasisQueryStartDate$ = VOUtils.write(out, guaranteeRequestDateBasisQueryStartDate, 8); // 보증요청일기준조회시작일
		guaranteeRequestDateBasisQueryEndDate$ = VOUtils.write(out, guaranteeRequestDateBasisQueryEndDate, 8); // 보증요청일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0210420000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		sortCondition = VOUtils.toString(sortCondition$ = VOUtils.read(in, 2)); // 정렬조건
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		inquiryNoteGuaranteeStatusSort = VOUtils.toString(inquiryNoteGuaranteeStatusSort$ = VOUtils.read(in, 1)); // 조회전자어음보증상태구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		guaranteeRequestDateBasisQueryStartDate = VOUtils.toString(guaranteeRequestDateBasisQueryStartDate$ = VOUtils.read(in, 8)); // 보증요청일기준조회시작일
		guaranteeRequestDateBasisQueryEndDate = VOUtils.toString(guaranteeRequestDateBasisQueryEndDate$ = VOUtils.read(in, 8)); // 보증요청일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0210420000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", sortCondition=").append(sortCondition).append(System.lineSeparator()); // 정렬조건
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", inquiryNoteGuaranteeStatusSort=").append(inquiryNoteGuaranteeStatusSort).append(System.lineSeparator()); // 조회전자어음보증상태구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", guaranteeRequestDateBasisQueryStartDate=").append(guaranteeRequestDateBasisQueryStartDate).append(System.lineSeparator()); // 보증요청일기준조회시작일
		sb.append(", guaranteeRequestDateBasisQueryEndDate=").append(guaranteeRequestDateBasisQueryEndDate).append(System.lineSeparator()); // 보증요청일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "420000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "sortCondition", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "inquiryNoteGuaranteeStatusSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDateBasisQueryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDateBasisQueryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsIssuanceGuaranteeSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsBeforeAfterIssueSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeProcessSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceProvisionConditionsNonTransferableSplitNumber", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeTargetSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "guaranteeTargetEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "guaranteeNumber", "fldLen", "4", "defltVal", "")
		);
	}

}
