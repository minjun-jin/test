package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 입금지시
 * <pre>{@code
 * KftCmsEB23R kftCmsEB23R  = new KftCmsEB23R(); // 입금지시
 * kftCmsEB23R.setRecordType(""); // Record 구분
 * kftCmsEB23R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB23R.setInstitutionCode(""); // 기관코드
 * kftCmsEB23R.setMainBankBranchCode(""); // 주거래은행점코드
 * kftCmsEB23R.setDepositAccountNumber(""); // 입금계좌번호
 * kftCmsEB23R.setCountOfTotalWithdrawals(0); // 총 출금건수
 * kftCmsEB23R.setAmountOfTotalWithdrawals(0L); // 총 출금액
 * kftCmsEB23R.setTotalFee(0L); // 총 수수료
 * kftCmsEB23R.setWithdrawalBankFee(0L); // 출금은행 수수료
 * kftCmsEB23R.setDepositBankFee(0L); // 입금은행 수수료
 * kftCmsEB23R.setCountOfTotalRequests(0); // 총 의뢰건수
 * kftCmsEB23R.setTransferDueDate(""); // 이체기일
 * kftCmsEB23R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB23R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String mainBankBranchCode; // 주거래은행점코드
	private String depositAccountNumber; // 입금계좌번호
	private int countOfTotalWithdrawals; // 총 출금건수
	private long amountOfTotalWithdrawals; // 총 출금액
	private long totalFee; // 총 수수료
	private long withdrawalBankFee; // 출금은행 수수료
	private long depositBankFee; // 입금은행 수수료
	private int countOfTotalRequests; // 총 의뢰건수
	private String transferDueDate; // 이체기일
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mainBankBranchCode$; // 주거래은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String countOfTotalWithdrawals$; // 총 출금건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String amountOfTotalWithdrawals$; // 총 출금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFee$; // 총 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalBankFee$; // 출금은행 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositBankFee$; // 입금은행 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String countOfTotalRequests$; // 총 의뢰건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transferDueDate$; // 이체기일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		mainBankBranchCode$ = VOUtils.write(out, mainBankBranchCode, 7); // 주거래은행점코드
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		countOfTotalWithdrawals$ = VOUtils.write(out, countOfTotalWithdrawals, 8); // 총 출금건수
		amountOfTotalWithdrawals$ = VOUtils.write(out, amountOfTotalWithdrawals, 13); // 총 출금액
		totalFee$ = VOUtils.write(out, totalFee, 11); // 총 수수료
		withdrawalBankFee$ = VOUtils.write(out, withdrawalBankFee, 11); // 출금은행 수수료
		depositBankFee$ = VOUtils.write(out, depositBankFee, 11); // 입금은행 수수료
		countOfTotalRequests$ = VOUtils.write(out, countOfTotalRequests, 8); // 총 의뢰건수
		transferDueDate$ = VOUtils.write(out, transferDueDate, 8); // 이체기일
		filler2$ = VOUtils.write(out, filler2, 38); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		mainBankBranchCode = VOUtils.toString(mainBankBranchCode$ = VOUtils.read(in, 7)); // 주거래은행점코드
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		countOfTotalWithdrawals = VOUtils.toInt(countOfTotalWithdrawals$ = VOUtils.read(in, 8)); // 총 출금건수
		amountOfTotalWithdrawals = VOUtils.toLong(amountOfTotalWithdrawals$ = VOUtils.read(in, 13)); // 총 출금액
		totalFee = VOUtils.toLong(totalFee$ = VOUtils.read(in, 11)); // 총 수수료
		withdrawalBankFee = VOUtils.toLong(withdrawalBankFee$ = VOUtils.read(in, 11)); // 출금은행 수수료
		depositBankFee = VOUtils.toLong(depositBankFee$ = VOUtils.read(in, 11)); // 입금은행 수수료
		countOfTotalRequests = VOUtils.toInt(countOfTotalRequests$ = VOUtils.read(in, 8)); // 총 의뢰건수
		transferDueDate = VOUtils.toString(transferDueDate$ = VOUtils.read(in, 8)); // 이체기일
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 38)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", mainBankBranchCode=").append(mainBankBranchCode).append(System.lineSeparator()); // 주거래은행점코드
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", countOfTotalWithdrawals=").append(countOfTotalWithdrawals).append(System.lineSeparator()); // 총 출금건수
		sb.append(", amountOfTotalWithdrawals=").append(amountOfTotalWithdrawals).append(System.lineSeparator()); // 총 출금액
		sb.append(", totalFee=").append(totalFee).append(System.lineSeparator()); // 총 수수료
		sb.append(", withdrawalBankFee=").append(withdrawalBankFee).append(System.lineSeparator()); // 출금은행 수수료
		sb.append(", depositBankFee=").append(depositBankFee).append(System.lineSeparator()); // 입금은행 수수료
		sb.append(", countOfTotalRequests=").append(countOfTotalRequests).append(System.lineSeparator()); // 총 의뢰건수
		sb.append(", transferDueDate=").append(transferDueDate).append(System.lineSeparator()); // 이체기일
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "mainBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "countOfTotalWithdrawals", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "amountOfTotalWithdrawals", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "totalFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "withdrawalBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "depositBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "countOfTotalRequests", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "transferDueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "38", "defltVal", "")
		);
	}

}
