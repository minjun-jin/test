package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시 결과 조회 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 210
 * messageTrackingNumber 전문추적번호 470000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * paymentPresentationDate 지급제시일자 
 * paymentPresentationNumber 지급제시번호 
 * settlementProcessSort 결제처리구분 
 * eNoteNumber (조회결과)어음내역-전자어음번호 
 * eNoteType (조회결과)어음내역-전자어음종류 
 * eNoteIssueDate (조회결과)어음내역-전자어음발행일자 
 * eNoteIssuePlace (조회결과)어음내역-전자어음발행지 
 * eNoteAmount (조회결과)어음내역-전자어음금액 
 * eNoteMaturedDate (조회결과)어음내역-전자어음만기일자 
 * paymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
 * payingBranchNoteExchangeCode (조회결과)어음내역-지급점포어음교환소코드 
 * issuerCorpIndvSort (조회결과)발행인-개인법인구분 
 * issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
 * issuerCorpName (조회결과)발행인-법인명 
 * issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
 * issuerAddress (조회결과)발행인-주소 
 * issuerCurrentAccountNumber (조회결과)발행인-당좌계좌번호 
 * finalHolderCorpIndvSort (조회결과)최종소지인개인법인구분 
 * finalHolderResidentBusinessNumber (조회결과)최종소지인주민사업자번호 
 * finalHolderCorpName (조회결과)최종소지인법인명 
 * finalHolderNameRepresentativeName (조회결과)최종소지인성명(대표자명) 
 * finalHolderAddress (조회결과)최종소지인주소 
 * finalHolderBankCode (조회결과)최종소지인은행코드 
 * finalHolderDepositAccountNumber (조회결과)최종소지인입금계좌번호 
 * finalRecipientSplitEnoteAmount (조회결과)최종소지인(분활된)전자어음금액 
 * finalHolderSplitNumber (조회결과)최종소지인분할번호 
 * finalHolderEndorsementNumber (조회결과)최종소지인배서번호 
 * eNoteMaturedSettlementDatetime (조회결과)전자어음만기결제일시 
 * defaultDate (조회결과)부도일 
 * eNoteDefaultReason (조회결과)부도사유-전자어음부도사유 
 * defaultReasonAccidentReportReason (조회결과)부도사유-사고신고서사유 
 * defaultReasonPaymentStopProvisionalDisposition (조회결과)부도사유-지급정지가처분 
 * defaultReasonSpecialDeposit (조회결과)부도사유-별단예금입금 
 * defaultReasonBankManagedCompany (조회결과)부도사유-은행관리기업여부 
 * defaultReasonRestructuringTargetCompany (조회결과)부도사유-구조조정대상기업여부 
 * defaultReasonDepositInsufficientCause (조회결과)부도사유-예금부족원인 
 * defaultDepositDateTime (조회결과)부도입금-입금일시 
 * defaultDepositBankBranchCode (조회결과)부도입금-입금은행및지점코드 
 * 
 * KftEnt0210470000 kftEnt0210470000 = new KftEnt0210470000(); // 지급제시 결과 조회 응답
 * kftEnt0210470000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210470000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210470000.setBnkCd("057"); // 은행코드
 * kftEnt0210470000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210470000.setTransactionCode("470000"); // 거래구분코드
 * kftEnt0210470000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210470000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210470000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210470000.setStatus("000"); // STATUS
 * kftEnt0210470000.setResponseCode1(""); // 응답코드1
 * kftEnt0210470000.setResponseCode2(""); // 응답코드2
 * kftEnt0210470000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210470000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210470000.setPaymentPresentationDate(""); // 지급제시일자
 * kftEnt0210470000.setPaymentPresentationNumber(""); // 지급제시번호
 * kftEnt0210470000.setSettlementProcessSort(""); // 결제처리구분
 * kftEnt0210470000.setENoteNumber(""); // (조회결과)어음내역-전자어음번호
 * kftEnt0210470000.setENoteType(""); // (조회결과)어음내역-전자어음종류
 * kftEnt0210470000.setENoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
 * kftEnt0210470000.setENoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
 * kftEnt0210470000.setENoteAmount(0L); // (조회결과)어음내역-전자어음금액
 * kftEnt0210470000.setENoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
 * kftEnt0210470000.setPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
 * kftEnt0210470000.setPayingBranchNoteExchangeCode(""); // (조회결과)어음내역-지급점포어음교환소코드
 * kftEnt0210470000.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
 * kftEnt0210470000.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
 * kftEnt0210470000.setIssuerCorpName(""); // (조회결과)발행인-법인명
 * kftEnt0210470000.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
 * kftEnt0210470000.setIssuerAddress(""); // (조회결과)발행인-주소
 * kftEnt0210470000.setIssuerCurrentAccountNumber(""); // (조회결과)발행인-당좌계좌번호
 * kftEnt0210470000.setFinalHolderCorpIndvSort(""); // (조회결과)최종소지인개인법인구분
 * kftEnt0210470000.setFinalHolderResidentBusinessNumber(""); // (조회결과)최종소지인주민사업자번호
 * kftEnt0210470000.setFinalHolderCorpName(""); // (조회결과)최종소지인법인명
 * kftEnt0210470000.setFinalHolderNameRepresentativeName(""); // (조회결과)최종소지인성명(대표자명)
 * kftEnt0210470000.setFinalHolderAddress(""); // (조회결과)최종소지인주소
 * kftEnt0210470000.setFinalHolderBankCode(""); // (조회결과)최종소지인은행코드
 * kftEnt0210470000.setFinalHolderDepositAccountNumber(""); // (조회결과)최종소지인입금계좌번호
 * kftEnt0210470000.setFinalRecipientSplitEnoteAmount(0L); // (조회결과)최종소지인(분활된)전자어음금액
 * kftEnt0210470000.setFinalHolderSplitNumber(""); // (조회결과)최종소지인분할번호
 * kftEnt0210470000.setFinalHolderEndorsementNumber(""); // (조회결과)최종소지인배서번호
 * kftEnt0210470000.setENoteMaturedSettlementDatetime(""); // (조회결과)전자어음만기결제일시
 * kftEnt0210470000.setDefaultDate(""); // (조회결과)부도일
 * kftEnt0210470000.setENoteDefaultReason(""); // (조회결과)부도사유-전자어음부도사유
 * kftEnt0210470000.setDefaultReasonAccidentReportReason(""); // (조회결과)부도사유-사고신고서사유
 * kftEnt0210470000.setDefaultReasonPaymentStopProvisionalDisposition(""); // (조회결과)부도사유-지급정지가처분
 * kftEnt0210470000.setDefaultReasonSpecialDeposit(""); // (조회결과)부도사유-별단예금입금
 * kftEnt0210470000.setDefaultReasonBankManagedCompany(""); // (조회결과)부도사유-은행관리기업여부
 * kftEnt0210470000.setDefaultReasonRestructuringTargetCompany(""); // (조회결과)부도사유-구조조정대상기업여부
 * kftEnt0210470000.setDefaultReasonDepositInsufficientCause(""); // (조회결과)부도사유-예금부족원인
 * kftEnt0210470000.setDefaultDepositDateTime(LocalDateTime.now()); // (조회결과)부도입금-입금일시
 * kftEnt0210470000.setDefaultDepositBankBranchCode(""); // (조회결과)부도입금-입금은행및지점코드
 * }</pre>
 */
@Data
public class KftEnt0210470000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "470000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String paymentPresentationDate; // 지급제시일자
	private String paymentPresentationNumber; // 지급제시번호
	private String settlementProcessSort; // 결제처리구분
	private String eNoteNumber; // (조회결과)어음내역-전자어음번호
	private String eNoteType; // (조회결과)어음내역-전자어음종류
	private String eNoteIssueDate; // (조회결과)어음내역-전자어음발행일자
	private String eNoteIssuePlace; // (조회결과)어음내역-전자어음발행지
	private long eNoteAmount; // (조회결과)어음내역-전자어음금액
	private String eNoteMaturedDate; // (조회결과)어음내역-전자어음만기일자
	private String paymentBankAndBranchCode; // (조회결과)어음내역-지급은행및지점코드
	private String payingBranchNoteExchangeCode; // (조회결과)어음내역-지급점포어음교환소코드
	private String issuerCorpIndvSort; // (조회결과)발행인-개인법인구분
	private String issuerResidentBusinessNumber; // (조회결과)발행인-주민사업자번호
	private String issuerCorpName; // (조회결과)발행인-법인명
	private String issuerNameRepresentativeName; // (조회결과)발행인-성명(대표자명)
	private String issuerAddress; // (조회결과)발행인-주소
	private String issuerCurrentAccountNumber; // (조회결과)발행인-당좌계좌번호
	private String finalHolderCorpIndvSort; // (조회결과)최종소지인개인법인구분
	private String finalHolderResidentBusinessNumber; // (조회결과)최종소지인주민사업자번호
	private String finalHolderCorpName; // (조회결과)최종소지인법인명
	private String finalHolderNameRepresentativeName; // (조회결과)최종소지인성명(대표자명)
	private String finalHolderAddress; // (조회결과)최종소지인주소
	private String finalHolderBankCode; // (조회결과)최종소지인은행코드
	private String finalHolderDepositAccountNumber; // (조회결과)최종소지인입금계좌번호
	private long finalRecipientSplitEnoteAmount; // (조회결과)최종소지인(분활된)전자어음금액
	private String finalHolderSplitNumber; // (조회결과)최종소지인분할번호
	private String finalHolderEndorsementNumber; // (조회결과)최종소지인배서번호
	private String eNoteMaturedSettlementDatetime; // (조회결과)전자어음만기결제일시
	private String defaultDate; // (조회결과)부도일
	private String eNoteDefaultReason; // (조회결과)부도사유-전자어음부도사유
	private String defaultReasonAccidentReportReason; // (조회결과)부도사유-사고신고서사유
	private String defaultReasonPaymentStopProvisionalDisposition; // (조회결과)부도사유-지급정지가처분
	private String defaultReasonSpecialDeposit; // (조회결과)부도사유-별단예금입금
	private String defaultReasonBankManagedCompany; // (조회결과)부도사유-은행관리기업여부
	private String defaultReasonRestructuringTargetCompany; // (조회결과)부도사유-구조조정대상기업여부
	private String defaultReasonDepositInsufficientCause; // (조회결과)부도사유-예금부족원인
	private LocalDateTime defaultDepositDateTime; // (조회결과)부도입금-입금일시
	private String defaultDepositBankBranchCode; // (조회결과)부도입금-입금은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationNumber$; // 지급제시번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String settlementProcessSort$; // 결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // (조회결과)어음내역-전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // (조회결과)어음내역-전자어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // (조회결과)어음내역-전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // (조회결과)어음내역-전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // (조회결과)어음내역-전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // (조회결과)어음내역-전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // (조회결과)어음내역-지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payingBranchNoteExchangeCode$; // (조회결과)어음내역-지급점포어음교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // (조회결과)발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // (조회결과)발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // (조회결과)발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // (조회결과)발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // (조회결과)발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // (조회결과)발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderCorpIndvSort$; // (조회결과)최종소지인개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderResidentBusinessNumber$; // (조회결과)최종소지인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderCorpName$; // (조회결과)최종소지인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderNameRepresentativeName$; // (조회결과)최종소지인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderAddress$; // (조회결과)최종소지인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderBankCode$; // (조회결과)최종소지인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderDepositAccountNumber$; // (조회결과)최종소지인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalRecipientSplitEnoteAmount$; // (조회결과)최종소지인(분활된)전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderSplitNumber$; // (조회결과)최종소지인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalHolderEndorsementNumber$; // (조회결과)최종소지인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedSettlementDatetime$; // (조회결과)전자어음만기결제일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // (조회결과)부도일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteDefaultReason$; // (조회결과)부도사유-전자어음부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonAccidentReportReason$; // (조회결과)부도사유-사고신고서사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonPaymentStopProvisionalDisposition$; // (조회결과)부도사유-지급정지가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonSpecialDeposit$; // (조회결과)부도사유-별단예금입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonBankManagedCompany$; // (조회결과)부도사유-은행관리기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonRestructuringTargetCompany$; // (조회결과)부도사유-구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonDepositInsufficientCause$; // (조회결과)부도사유-예금부족원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositDateTime$; // (조회결과)부도입금-입금일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositBankBranchCode$; // (조회결과)부도입금-입금은행및지점코드

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(settlementProcessSort$)) { // 결제처리구분
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // (조회결과)어음내역-전자어음번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerResidentBusinessNumber$)) { // (조회결과)발행인-주민사업자번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerCurrentAccountNumber$)) { // (조회결과)발행인-당좌계좌번호
			return 30;
		}
		if (VOUtils.isNotAlphanumericSpace(finalHolderResidentBusinessNumber$)) { // (조회결과)최종소지인주민사업자번호
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(finalHolderDepositAccountNumber$)) { // (조회결과)최종소지인입금계좌번호
			return 37;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		paymentPresentationNumber$ = VOUtils.write(out, paymentPresentationNumber, 16); // 지급제시번호
		settlementProcessSort$ = VOUtils.write(out, settlementProcessSort, 2); // 결제처리구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // (조회결과)어음내역-전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // (조회결과)어음내역-전자어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // (조회결과)어음내역-전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음내역-전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // (조회결과)어음내역-전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // (조회결과)어음내역-전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // (조회결과)어음내역-지급은행및지점코드
		payingBranchNoteExchangeCode$ = VOUtils.write(out, payingBranchNoteExchangeCode, 2); // (조회결과)어음내역-지급점포어음교환소코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // (조회결과)발행인-개인법인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // (조회결과)발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // (조회결과)발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // (조회결과)발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // (조회결과)발행인-당좌계좌번호
		finalHolderCorpIndvSort$ = VOUtils.write(out, finalHolderCorpIndvSort, 1); // (조회결과)최종소지인개인법인구분
		finalHolderResidentBusinessNumber$ = VOUtils.write(out, finalHolderResidentBusinessNumber, 13); // (조회결과)최종소지인주민사업자번호
		finalHolderCorpName$ = VOUtils.write(out, finalHolderCorpName, 40, "EUC-KR"); // (조회결과)최종소지인법인명
		finalHolderNameRepresentativeName$ = VOUtils.write(out, finalHolderNameRepresentativeName, 20, "EUC-KR"); // (조회결과)최종소지인성명(대표자명)
		finalHolderAddress$ = VOUtils.write(out, finalHolderAddress, 60, "EUC-KR"); // (조회결과)최종소지인주소
		finalHolderBankCode$ = VOUtils.write(out, finalHolderBankCode, 3); // (조회결과)최종소지인은행코드
		finalHolderDepositAccountNumber$ = VOUtils.write(out, finalHolderDepositAccountNumber, 16); // (조회결과)최종소지인입금계좌번호
		finalRecipientSplitEnoteAmount$ = VOUtils.write(out, finalRecipientSplitEnoteAmount, 15); // (조회결과)최종소지인(분활된)전자어음금액
		finalHolderSplitNumber$ = VOUtils.write(out, finalHolderSplitNumber, 2); // (조회결과)최종소지인분할번호
		finalHolderEndorsementNumber$ = VOUtils.write(out, finalHolderEndorsementNumber, 2); // (조회결과)최종소지인배서번호
		eNoteMaturedSettlementDatetime$ = VOUtils.write(out, eNoteMaturedSettlementDatetime, 14); // (조회결과)전자어음만기결제일시
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // (조회결과)부도일
		eNoteDefaultReason$ = VOUtils.write(out, eNoteDefaultReason, 2); // (조회결과)부도사유-전자어음부도사유
		defaultReasonAccidentReportReason$ = VOUtils.write(out, defaultReasonAccidentReportReason, 1); // (조회결과)부도사유-사고신고서사유
		defaultReasonPaymentStopProvisionalDisposition$ = VOUtils.write(out, defaultReasonPaymentStopProvisionalDisposition, 1); // (조회결과)부도사유-지급정지가처분
		defaultReasonSpecialDeposit$ = VOUtils.write(out, defaultReasonSpecialDeposit, 1); // (조회결과)부도사유-별단예금입금
		defaultReasonBankManagedCompany$ = VOUtils.write(out, defaultReasonBankManagedCompany, 1); // (조회결과)부도사유-은행관리기업여부
		defaultReasonRestructuringTargetCompany$ = VOUtils.write(out, defaultReasonRestructuringTargetCompany, 1); // (조회결과)부도사유-구조조정대상기업여부
		defaultReasonDepositInsufficientCause$ = VOUtils.write(out, defaultReasonDepositInsufficientCause, 1); // (조회결과)부도사유-예금부족원인
		defaultDepositDateTime$ = VOUtils.write(out, defaultDepositDateTime, 14, "yyyyMMddHHmmss"); // (조회결과)부도입금-입금일시
		defaultDepositBankBranchCode$ = VOUtils.write(out, defaultDepositBankBranchCode, 7); // (조회결과)부도입금-입금은행및지점코드
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		paymentPresentationNumber = VOUtils.toString(paymentPresentationNumber$ = VOUtils.read(in, 16)); // 지급제시번호
		settlementProcessSort = VOUtils.toString(settlementProcessSort$ = VOUtils.read(in, 2)); // 결제처리구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음내역-전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // (조회결과)어음내역-전자어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음내역-전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음내역-전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음내역-지급은행및지점코드
		payingBranchNoteExchangeCode = VOUtils.toString(payingBranchNoteExchangeCode$ = VOUtils.read(in, 2)); // (조회결과)어음내역-지급점포어음교환소코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인-개인법인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행인-당좌계좌번호
		finalHolderCorpIndvSort = VOUtils.toString(finalHolderCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)최종소지인개인법인구분
		finalHolderResidentBusinessNumber = VOUtils.toString(finalHolderResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)최종소지인주민사업자번호
		finalHolderCorpName = VOUtils.toString(finalHolderCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)최종소지인법인명
		finalHolderNameRepresentativeName = VOUtils.toString(finalHolderNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)최종소지인성명(대표자명)
		finalHolderAddress = VOUtils.toString(finalHolderAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)최종소지인주소
		finalHolderBankCode = VOUtils.toString(finalHolderBankCode$ = VOUtils.read(in, 3)); // (조회결과)최종소지인은행코드
		finalHolderDepositAccountNumber = VOUtils.toString(finalHolderDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)최종소지인입금계좌번호
		finalRecipientSplitEnoteAmount = VOUtils.toLong(finalRecipientSplitEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)최종소지인(분활된)전자어음금액
		finalHolderSplitNumber = VOUtils.toString(finalHolderSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)최종소지인분할번호
		finalHolderEndorsementNumber = VOUtils.toString(finalHolderEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)최종소지인배서번호
		eNoteMaturedSettlementDatetime = VOUtils.toString(eNoteMaturedSettlementDatetime$ = VOUtils.read(in, 14)); // (조회결과)전자어음만기결제일시
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // (조회결과)부도일
		eNoteDefaultReason = VOUtils.toString(eNoteDefaultReason$ = VOUtils.read(in, 2)); // (조회결과)부도사유-전자어음부도사유
		defaultReasonAccidentReportReason = VOUtils.toString(defaultReasonAccidentReportReason$ = VOUtils.read(in, 1)); // (조회결과)부도사유-사고신고서사유
		defaultReasonPaymentStopProvisionalDisposition = VOUtils.toString(defaultReasonPaymentStopProvisionalDisposition$ = VOUtils.read(in, 1)); // (조회결과)부도사유-지급정지가처분
		defaultReasonSpecialDeposit = VOUtils.toString(defaultReasonSpecialDeposit$ = VOUtils.read(in, 1)); // (조회결과)부도사유-별단예금입금
		defaultReasonBankManagedCompany = VOUtils.toString(defaultReasonBankManagedCompany$ = VOUtils.read(in, 1)); // (조회결과)부도사유-은행관리기업여부
		defaultReasonRestructuringTargetCompany = VOUtils.toString(defaultReasonRestructuringTargetCompany$ = VOUtils.read(in, 1)); // (조회결과)부도사유-구조조정대상기업여부
		defaultReasonDepositInsufficientCause = VOUtils.toString(defaultReasonDepositInsufficientCause$ = VOUtils.read(in, 1)); // (조회결과)부도사유-예금부족원인
		defaultDepositDateTime = VOUtils.toLocalDateTime(defaultDepositDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // (조회결과)부도입금-입금일시
		defaultDepositBankBranchCode = VOUtils.toString(defaultDepositBankBranchCode$ = VOUtils.read(in, 7)); // (조회결과)부도입금-입금은행및지점코드
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", paymentPresentationNumber=").append(paymentPresentationNumber).append(System.lineSeparator()); // 지급제시번호
		sb.append(", settlementProcessSort=").append(settlementProcessSort).append(System.lineSeparator()); // 결제처리구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // (조회결과)어음내역-전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // (조회결과)어음내역-전자어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // (조회결과)어음내역-전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음내역-지급은행및지점코드
		sb.append(", payingBranchNoteExchangeCode=").append(payingBranchNoteExchangeCode).append(System.lineSeparator()); // (조회결과)어음내역-지급점포어음교환소코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인-개인법인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // (조회결과)발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // (조회결과)발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행인-당좌계좌번호
		sb.append(", finalHolderCorpIndvSort=").append(finalHolderCorpIndvSort).append(System.lineSeparator()); // (조회결과)최종소지인개인법인구분
		sb.append(", finalHolderResidentBusinessNumber=").append(finalHolderResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)최종소지인주민사업자번호
		sb.append(", finalHolderCorpName=").append(finalHolderCorpName).append(System.lineSeparator()); // (조회결과)최종소지인법인명
		sb.append(", finalHolderNameRepresentativeName=").append(finalHolderNameRepresentativeName).append(System.lineSeparator()); // (조회결과)최종소지인성명(대표자명)
		sb.append(", finalHolderAddress=").append(finalHolderAddress).append(System.lineSeparator()); // (조회결과)최종소지인주소
		sb.append(", finalHolderBankCode=").append(finalHolderBankCode).append(System.lineSeparator()); // (조회결과)최종소지인은행코드
		sb.append(", finalHolderDepositAccountNumber=").append(finalHolderDepositAccountNumber).append(System.lineSeparator()); // (조회결과)최종소지인입금계좌번호
		sb.append(", finalRecipientSplitEnoteAmount=").append(finalRecipientSplitEnoteAmount).append(System.lineSeparator()); // (조회결과)최종소지인(분활된)전자어음금액
		sb.append(", finalHolderSplitNumber=").append(finalHolderSplitNumber).append(System.lineSeparator()); // (조회결과)최종소지인분할번호
		sb.append(", finalHolderEndorsementNumber=").append(finalHolderEndorsementNumber).append(System.lineSeparator()); // (조회결과)최종소지인배서번호
		sb.append(", eNoteMaturedSettlementDatetime=").append(eNoteMaturedSettlementDatetime).append(System.lineSeparator()); // (조회결과)전자어음만기결제일시
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // (조회결과)부도일
		sb.append(", eNoteDefaultReason=").append(eNoteDefaultReason).append(System.lineSeparator()); // (조회결과)부도사유-전자어음부도사유
		sb.append(", defaultReasonAccidentReportReason=").append(defaultReasonAccidentReportReason).append(System.lineSeparator()); // (조회결과)부도사유-사고신고서사유
		sb.append(", defaultReasonPaymentStopProvisionalDisposition=").append(defaultReasonPaymentStopProvisionalDisposition).append(System.lineSeparator()); // (조회결과)부도사유-지급정지가처분
		sb.append(", defaultReasonSpecialDeposit=").append(defaultReasonSpecialDeposit).append(System.lineSeparator()); // (조회결과)부도사유-별단예금입금
		sb.append(", defaultReasonBankManagedCompany=").append(defaultReasonBankManagedCompany).append(System.lineSeparator()); // (조회결과)부도사유-은행관리기업여부
		sb.append(", defaultReasonRestructuringTargetCompany=").append(defaultReasonRestructuringTargetCompany).append(System.lineSeparator()); // (조회결과)부도사유-구조조정대상기업여부
		sb.append(", defaultReasonDepositInsufficientCause=").append(defaultReasonDepositInsufficientCause).append(System.lineSeparator()); // (조회결과)부도사유-예금부족원인
		sb.append(", defaultDepositDateTime=").append(defaultDepositDateTime).append(System.lineSeparator()); // (조회결과)부도입금-입금일시
		sb.append(", defaultDepositBankBranchCode=").append(defaultDepositBankBranchCode).append(System.lineSeparator()); // (조회결과)부도입금-입금은행및지점코드
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "470000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentPresentationNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "settlementProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "payingBranchNoteExchangeCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "finalHolderCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "finalHolderResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "finalHolderCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "finalHolderNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "finalHolderAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "finalHolderBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "finalHolderDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "finalRecipientSplitEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "finalHolderSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "finalHolderEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "eNoteMaturedSettlementDatetime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultReasonAccidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonPaymentStopProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonSpecialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonBankManagedCompany", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonRestructuringTargetCompany", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonDepositInsufficientCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultDepositDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "defaultDepositBankBranchCode", "fldLen", "7", "defltVal", "")
		);
	}

}
