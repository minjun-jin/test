package com.jpmc.kcg.ent.biz;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0200221000;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0210221000;
import com.jpmc.kcg.ent.biz.vo.KftEnt0200221000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class RealtimeRecipientGuarantorInfoOutReqIntf extends FrwServiceBean<CqeEnt0200221000> {
    private final FrwTemplate frwTemplate;
    private final FrwContext frwContext;
    private final BizCom bizCom;
    private final EntCom entCom;
    private final ConversionService conversionService;

    @Override
    public boolean control(CqeEnt0200221000 in) {

//      [KR] 1.1 입력값 검증
//      [EN] 1.1 input validation
//      [KR] 1.2 개설은행상태 확인
//      [EN] 1.2 Beneficiary Bank status check
        entCom.validateOutboundInput(in);

        return super.control(in);
    }

    @Override
    public void process(CqeEnt0200221000 in) {

        /**
         * [KR] 2.1 거래고유번호, 전문추적번호 채번
         * [EN] TR_UNIQ_NO, ENT_TLG_TRCE_NO numbering
         */
        String traxIdNo = bizCom.getNumbering(BizDvsnCdEnum.ENT.getValue(), NumberingEnum.ENTKFT01.getName());
        String tlgmTraxIdNo = EntConst.ENTKFT01_TRACE_NUMBERING.concat(traxIdNo.substring(7));
        in.setTransactionIdNumber(traxIdNo);

        /**
         * [KR] 2.3 회원거래내역 table insert
         * [EN] 2.3 ENT_MBR_L table insert
         */
        EntMbrL entMbrL = conversionService.convert(in, EntMbrL.class);
        entCom.insertMemberLog(entMbrL, traxIdNo, tlgmTraxIdNo);

        log.debug("----------------- insert EntMbrL -----------------: {}", entMbrL);

        /**
         * [KR] 2.4 실시간 수취인/보증인정보조회 요청
         * - kftc 전문생성, 전송
         * [EN] 2.4. Real-time Recipient/Guarantor info inquiry Request
         * - ktfc message creation, send
         */
        KftEnt0200221000 sendVo = conversionService.convert(in, KftEnt0200221000.class);
        sendVo.setTransactionIdNumber(traxIdNo);                      // 거래고유번호
        sendVo.setMessageTrackingNumber(tlgmTraxIdNo);                // 전문추적번호

        log.debug("----------------- KftEnt0200221000 -----------------: {}", sendVo);

        // KCG -> KFTC 전송
        frwTemplate.send(FrwDestination.KFT_ENT, sendVo);
    }

    @Override
    public void handleError(CqeEnt0200221000 in, Throwable t) {
        // 응답 전문으로 변환
        CqeEnt0210221000 sendVo = conversionService.convert(in, CqeEnt0210221000.class);

        // 에러 응답 값 세팅 (공통화 메서드 호출)
        entCom.setOutboundRequestErrorVo(in, sendVo, t);

        // 로그 출력: 전송 전에 sendVo 내용 확인
        log.info("----------------- CqeEnt0210221000: {} -----------------", sendVo);

        // CQE 전송: 에러 응답
        frwTemplate.send(FrwDestination.CQE_ENT, sendVo);
    }
}
