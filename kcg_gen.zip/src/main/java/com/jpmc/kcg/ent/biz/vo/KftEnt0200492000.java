package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 소지인별 어음정보 조회 요청 C
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * sortCondition 정렬조건 
 * searchConditionSort 검색조건구분 
 * inquiryNoteStatus 조회전자어음상태구분 
 * residentBusinessNumber 주민사업자번호 
 * depositAccountNumber 입금계좌번호 
 * lastTransactionDateInquiryStartDate 최종거래일기준조회시작일 
 * lastTransactionDateInquiryEndDate 최종거래일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.noteInfoEnoteNumber (조회결과)어음정보-01전자어음번호 
 * queryResultArray.noteInfoEnoteType (조회결과)어음정보-02어음종류 
 * queryResultArray.noteInfoEnoteProcessStatus (조회결과)어음정보-03전자어음처리상태 
 * queryResultArray.noteInfoEnoteIssueDate (조회결과)어음정보-04전자어음발행일자 
 * queryResultArray.noteInfoEnoteIssuePlace (조회결과)어음정보-05전자어음발행지 
 * queryResultArray.noteInfoEnoteAmount (조회결과)어음정보-06전자어음금액 
 * queryResultArray.noteInfoDefaultReasonCode (조회결과)어음정보-07부도사유코드 
 * queryResultArray.noteInfoEnoteMaturedDate (조회결과)어음정보-08전자어음만기일자 
 * queryResultArray.beforeMaturityPaymentPresentationRequestDate (조회결과)어음정보-09만기전지급제시신청일자 
 * queryResultArray.beforeMaturityPaymentPresentationDate (조회결과)어음정보-10만기전지급제시일자 
 * queryResultArray.noteInfoEnoteDefaultDate (조회결과)어음정보-11전자어음부도일자 
 * queryResultArray.noteInfoEnoteFinalPaymentDate (조회결과)어음정보-12전자어음최종결제일자 
 * queryResultArray.noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
 * queryResultArray.noteInfoEndorsementCount (조회결과)어음정보-배서횟수 
 * queryResultArray.noteInfoInstructionProhibited (조회결과)어음정보-지시금지여부 
 * queryResultArray.issuerInfoCorpIndvSort (조회결과)발행인정보-개인법인구분 
 * queryResultArray.issuerInfoResidentBusinessNumber (조회결과)발행인정보-주민사업자번호 
 * queryResultArray.issuerInfoCorpName (조회결과)발행인정보-법인명 
 * queryResultArray.issuerInfoNameRepresentativeName (조회결과)발행인정보-성명(대표자명) 
 * queryResultArray.issuerInfoAddress (조회결과)발행인정보-주소 
 * queryResultArray.issuerInfoCurrentAccountNumber (조회결과)발행인정보-당좌계좌번호 
 * queryResultArray.issuanceGuaranteeYn (조회결과)발행보증여부 
 * queryResultArray.postmaturedEndorsementYn (조회결과)기한후배서여부 
 * queryResultArray.splitNumber (조회결과)분할번호 
 * queryResultArray.endorsementNumber (조회결과)배서번호 
 * queryResultArray.endorsementAmount (조회결과)배서금액 
 * queryResultArray.endorsementDate (조회결과)배서일자 
 * queryResultArray.issuanceGuaranteeInfoEndorserCorpIndvSort (조회결과)발행보증정보(피보증인)-개인법인구분 
 * queryResultArray.issuanceGuaranteeInfoEndorserResidentBusinessNumber (조회결과)발행보증정보(피보증인)-주민사업자번호 
 * queryResultArray.issuanceGuaranteeInfoEndorserCorpName (조회결과)발행보증정보(피보증인)-법인명 
 * queryResultArray.issuanceGuaranteeInfoEndorserNameRepresentativeName (조회결과)발행보증정보(피보증인)-성명(대표자명) 
 * queryResultArray.issuanceGuaranteeInfoEndorserAddress (조회결과)발행보증정보(피보증인)-주소 
 * queryResultArray.issuanceGuaranteeEndorserBankCode (조회결과)발행보증정보(피보증인)-은행코드 
 * queryResultArray.issuanceGuaranteeInfoAssuredCurrentAccountNumber (조회결과)발행보증정보(피보증인)-당좌계좌번호 
 * queryResultArray.issuanceGuaranteeInfoGuarantorIndvCorpSort (조회결과)발행보증정보(보증인)-개인법인구분 
 * queryResultArray.issuanceGuaranteeInfoGuarantorResidentBusinessNumber (조회결과)발행보증정보(보증인)-주민사업자번호 
 * queryResultArray.issuanceGuaranteeInfoGuarantorCorpName (조회결과)발행보증정보(보증인)-법인명 
 * queryResultArray.issuanceGuaranteeInfoGuarantorNameRepresentative (조회결과)발행보증정보(보증인)-성명(대표자명) 
 * queryResultArray.issuanceGuaranteeInfoGuarantorAddress (조회결과)발행보증정보(보증인)-주소 
 * queryResultArray.issuanceGuaranteeInfoGuarantorBankCode (조회결과)발행보증정보(보증인)-은행코드 
 * queryResultArray.issuanceGuaranteeInfoGuarantorDepositAccountNumber (조회결과)발행보증정보(보증인)-입금계좌번호 
 * queryResultArray.guaranteeTargetSplitNumber (조회결과)보증대상분할번호 
 * queryResultArray.guaranteeTargetEndorsementNumber (조회결과)보증대상배서번호 
 * queryResultArray.guaranteeNumber (조회결과)보증번호 
 * 
 * KftEnt0200492000 kftEnt0200492000 = new KftEnt0200492000(); // 소지인별 어음정보 조회 요청 C
 * kftEnt0200492000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200492000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200492000.setBnkCd("057"); // 은행코드
 * kftEnt0200492000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200492000.setTransactionCode("492000"); // 거래구분코드
 * kftEnt0200492000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200492000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200492000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200492000.setStatus("000"); // STATUS
 * kftEnt0200492000.setResponseCode1(""); // 응답코드1
 * kftEnt0200492000.setResponseCode2(""); // 응답코드2
 * kftEnt0200492000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200492000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200492000.setSortCondition(""); // 정렬조건
 * kftEnt0200492000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0200492000.setInquiryNoteStatus(""); // 조회전자어음상태구분
 * kftEnt0200492000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200492000.setDepositAccountNumber(""); // 입금계좌번호
 * kftEnt0200492000.setLastTransactionDateInquiryStartDate(""); // 최종거래일기준조회시작일
 * kftEnt0200492000.setLastTransactionDateInquiryEndDate(""); // 최종거래일기준조회종료일
 * kftEnt0200492000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0200492000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0200492000.setCurrentCount(0); // 현재건수
 * KftEnt0200492000.QueryResult queryResult = new KftEnt0200492000.QueryResult(); // 조회결과Array
 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-01전자어음번호
 * queryResult.setNoteInfoEnoteType(""); // (조회결과)어음정보-02어음종류
 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-03전자어음처리상태
 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-04전자어음발행일자
 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-05전자어음발행지
 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-06전자어음금액
 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-07부도사유코드
 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-08전자어음만기일자
 * queryResult.setBeforeMaturityPaymentPresentationRequestDate(""); // (조회결과)어음정보-09만기전지급제시신청일자
 * queryResult.setBeforeMaturityPaymentPresentationDate(""); // (조회결과)어음정보-10만기전지급제시일자
 * queryResult.setNoteInfoEnoteDefaultDate(""); // (조회결과)어음정보-11전자어음부도일자
 * queryResult.setNoteInfoEnoteFinalPaymentDate(""); // (조회결과)어음정보-12전자어음최종결제일자
 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
 * queryResult.setNoteInfoEndorsementCount(0); // (조회결과)어음정보-배서횟수
 * queryResult.setNoteInfoInstructionProhibited(""); // (조회결과)어음정보-지시금지여부
 * queryResult.setIssuerInfoCorpIndvSort(""); // (조회결과)발행인정보-개인법인구분
 * queryResult.setIssuerInfoResidentBusinessNumber(""); // (조회결과)발행인정보-주민사업자번호
 * queryResult.setIssuerInfoCorpName(""); // (조회결과)발행인정보-법인명
 * queryResult.setIssuerInfoNameRepresentativeName(""); // (조회결과)발행인정보-성명(대표자명)
 * queryResult.setIssuerInfoAddress(""); // (조회결과)발행인정보-주소
 * queryResult.setIssuerInfoCurrentAccountNumber(""); // (조회결과)발행인정보-당좌계좌번호
 * queryResult.setIssuanceGuaranteeYn(""); // (조회결과)발행보증여부
 * queryResult.setPostmaturedEndorsementYn(""); // (조회결과)기한후배서여부
 * queryResult.setSplitNumber(""); // (조회결과)분할번호
 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
 * queryResult.setEndorsementAmount(0L); // (조회결과)배서금액
 * queryResult.setEndorsementDate(""); // (조회결과)배서일자
 * queryResult.setIssuanceGuaranteeInfoEndorserCorpIndvSort(""); // (조회결과)발행보증정보(피보증인)-개인법인구분
 * queryResult.setIssuanceGuaranteeInfoEndorserResidentBusinessNumber(""); // (조회결과)발행보증정보(피보증인)-주민사업자번호
 * queryResult.setIssuanceGuaranteeInfoEndorserCorpName(""); // (조회결과)발행보증정보(피보증인)-법인명
 * queryResult.setIssuanceGuaranteeInfoEndorserNameRepresentativeName(""); // (조회결과)발행보증정보(피보증인)-성명(대표자명)
 * queryResult.setIssuanceGuaranteeInfoEndorserAddress(""); // (조회결과)발행보증정보(피보증인)-주소
 * queryResult.setIssuanceGuaranteeEndorserBankCode(""); // (조회결과)발행보증정보(피보증인)-은행코드
 * queryResult.setIssuanceGuaranteeInfoAssuredCurrentAccountNumber(""); // (조회결과)발행보증정보(피보증인)-당좌계좌번호
 * queryResult.setIssuanceGuaranteeInfoGuarantorIndvCorpSort(""); // (조회결과)발행보증정보(보증인)-개인법인구분
 * queryResult.setIssuanceGuaranteeInfoGuarantorResidentBusinessNumber(""); // (조회결과)발행보증정보(보증인)-주민사업자번호
 * queryResult.setIssuanceGuaranteeInfoGuarantorCorpName(""); // (조회결과)발행보증정보(보증인)-법인명
 * queryResult.setIssuanceGuaranteeInfoGuarantorNameRepresentative(""); // (조회결과)발행보증정보(보증인)-성명(대표자명)
 * queryResult.setIssuanceGuaranteeInfoGuarantorAddress(""); // (조회결과)발행보증정보(보증인)-주소
 * queryResult.setIssuanceGuaranteeInfoGuarantorBankCode(""); // (조회결과)발행보증정보(보증인)-은행코드
 * queryResult.setIssuanceGuaranteeInfoGuarantorDepositAccountNumber(""); // (조회결과)발행보증정보(보증인)-입금계좌번호
 * queryResult.setGuaranteeTargetSplitNumber(""); // (조회결과)보증대상분할번호
 * queryResult.setGuaranteeTargetEndorsementNumber(""); // (조회결과)보증대상배서번호
 * queryResult.setGuaranteeNumber(""); // (조회결과)보증번호
 * kftEnt0200492000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0200492000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * noteInfoEnoteNumber (조회결과)어음정보-01전자어음번호 
	 * noteInfoEnoteType (조회결과)어음정보-02어음종류 
	 * noteInfoEnoteProcessStatus (조회결과)어음정보-03전자어음처리상태 
	 * noteInfoEnoteIssueDate (조회결과)어음정보-04전자어음발행일자 
	 * noteInfoEnoteIssuePlace (조회결과)어음정보-05전자어음발행지 
	 * noteInfoEnoteAmount (조회결과)어음정보-06전자어음금액 
	 * noteInfoDefaultReasonCode (조회결과)어음정보-07부도사유코드 
	 * noteInfoEnoteMaturedDate (조회결과)어음정보-08전자어음만기일자 
	 * beforeMaturityPaymentPresentationRequestDate (조회결과)어음정보-09만기전지급제시신청일자 
	 * beforeMaturityPaymentPresentationDate (조회결과)어음정보-10만기전지급제시일자 
	 * noteInfoEnoteDefaultDate (조회결과)어음정보-11전자어음부도일자 
	 * noteInfoEnoteFinalPaymentDate (조회결과)어음정보-12전자어음최종결제일자 
	 * noteInfoPaymentBankAndBranchCode (조회결과)어음정보-지급은행및점포코드 
	 * noteInfoEndorsementCount (조회결과)어음정보-배서횟수 
	 * noteInfoInstructionProhibited (조회결과)어음정보-지시금지여부 
	 * issuerInfoCorpIndvSort (조회결과)발행인정보-개인법인구분 
	 * issuerInfoResidentBusinessNumber (조회결과)발행인정보-주민사업자번호 
	 * issuerInfoCorpName (조회결과)발행인정보-법인명 
	 * issuerInfoNameRepresentativeName (조회결과)발행인정보-성명(대표자명) 
	 * issuerInfoAddress (조회결과)발행인정보-주소 
	 * issuerInfoCurrentAccountNumber (조회결과)발행인정보-당좌계좌번호 
	 * issuanceGuaranteeYn (조회결과)발행보증여부 
	 * postmaturedEndorsementYn (조회결과)기한후배서여부 
	 * splitNumber (조회결과)분할번호 
	 * endorsementNumber (조회결과)배서번호 
	 * endorsementAmount (조회결과)배서금액 
	 * endorsementDate (조회결과)배서일자 
	 * issuanceGuaranteeInfoEndorserCorpIndvSort (조회결과)발행보증정보(피보증인)-개인법인구분 
	 * issuanceGuaranteeInfoEndorserResidentBusinessNumber (조회결과)발행보증정보(피보증인)-주민사업자번호 
	 * issuanceGuaranteeInfoEndorserCorpName (조회결과)발행보증정보(피보증인)-법인명 
	 * issuanceGuaranteeInfoEndorserNameRepresentativeName (조회결과)발행보증정보(피보증인)-성명(대표자명) 
	 * issuanceGuaranteeInfoEndorserAddress (조회결과)발행보증정보(피보증인)-주소 
	 * issuanceGuaranteeEndorserBankCode (조회결과)발행보증정보(피보증인)-은행코드 
	 * issuanceGuaranteeInfoAssuredCurrentAccountNumber (조회결과)발행보증정보(피보증인)-당좌계좌번호 
	 * issuanceGuaranteeInfoGuarantorIndvCorpSort (조회결과)발행보증정보(보증인)-개인법인구분 
	 * issuanceGuaranteeInfoGuarantorResidentBusinessNumber (조회결과)발행보증정보(보증인)-주민사업자번호 
	 * issuanceGuaranteeInfoGuarantorCorpName (조회결과)발행보증정보(보증인)-법인명 
	 * issuanceGuaranteeInfoGuarantorNameRepresentative (조회결과)발행보증정보(보증인)-성명(대표자명) 
	 * issuanceGuaranteeInfoGuarantorAddress (조회결과)발행보증정보(보증인)-주소 
	 * issuanceGuaranteeInfoGuarantorBankCode (조회결과)발행보증정보(보증인)-은행코드 
	 * issuanceGuaranteeInfoGuarantorDepositAccountNumber (조회결과)발행보증정보(보증인)-입금계좌번호 
	 * guaranteeTargetSplitNumber (조회결과)보증대상분할번호 
	 * guaranteeTargetEndorsementNumber (조회결과)보증대상배서번호 
	 * guaranteeNumber (조회결과)보증번호 
	 * 
	 * KftEnt0200492000.QueryResult queryResult = new KftEnt0200492000.QueryResult(); // 조회결과Array
	 * queryResult.setNoteInfoEnoteNumber(""); // (조회결과)어음정보-01전자어음번호
	 * queryResult.setNoteInfoEnoteType(""); // (조회결과)어음정보-02어음종류
	 * queryResult.setNoteInfoEnoteProcessStatus(""); // (조회결과)어음정보-03전자어음처리상태
	 * queryResult.setNoteInfoEnoteIssueDate(""); // (조회결과)어음정보-04전자어음발행일자
	 * queryResult.setNoteInfoEnoteIssuePlace(""); // (조회결과)어음정보-05전자어음발행지
	 * queryResult.setNoteInfoEnoteAmount(0L); // (조회결과)어음정보-06전자어음금액
	 * queryResult.setNoteInfoDefaultReasonCode(""); // (조회결과)어음정보-07부도사유코드
	 * queryResult.setNoteInfoEnoteMaturedDate(""); // (조회결과)어음정보-08전자어음만기일자
	 * queryResult.setBeforeMaturityPaymentPresentationRequestDate(""); // (조회결과)어음정보-09만기전지급제시신청일자
	 * queryResult.setBeforeMaturityPaymentPresentationDate(""); // (조회결과)어음정보-10만기전지급제시일자
	 * queryResult.setNoteInfoEnoteDefaultDate(""); // (조회결과)어음정보-11전자어음부도일자
	 * queryResult.setNoteInfoEnoteFinalPaymentDate(""); // (조회결과)어음정보-12전자어음최종결제일자
	 * queryResult.setNoteInfoPaymentBankAndBranchCode(""); // (조회결과)어음정보-지급은행및점포코드
	 * queryResult.setNoteInfoEndorsementCount(0); // (조회결과)어음정보-배서횟수
	 * queryResult.setNoteInfoInstructionProhibited(""); // (조회결과)어음정보-지시금지여부
	 * queryResult.setIssuerInfoCorpIndvSort(""); // (조회결과)발행인정보-개인법인구분
	 * queryResult.setIssuerInfoResidentBusinessNumber(""); // (조회결과)발행인정보-주민사업자번호
	 * queryResult.setIssuerInfoCorpName(""); // (조회결과)발행인정보-법인명
	 * queryResult.setIssuerInfoNameRepresentativeName(""); // (조회결과)발행인정보-성명(대표자명)
	 * queryResult.setIssuerInfoAddress(""); // (조회결과)발행인정보-주소
	 * queryResult.setIssuerInfoCurrentAccountNumber(""); // (조회결과)발행인정보-당좌계좌번호
	 * queryResult.setIssuanceGuaranteeYn(""); // (조회결과)발행보증여부
	 * queryResult.setPostmaturedEndorsementYn(""); // (조회결과)기한후배서여부
	 * queryResult.setSplitNumber(""); // (조회결과)분할번호
	 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
	 * queryResult.setEndorsementAmount(0L); // (조회결과)배서금액
	 * queryResult.setEndorsementDate(""); // (조회결과)배서일자
	 * queryResult.setIssuanceGuaranteeInfoEndorserCorpIndvSort(""); // (조회결과)발행보증정보(피보증인)-개인법인구분
	 * queryResult.setIssuanceGuaranteeInfoEndorserResidentBusinessNumber(""); // (조회결과)발행보증정보(피보증인)-주민사업자번호
	 * queryResult.setIssuanceGuaranteeInfoEndorserCorpName(""); // (조회결과)발행보증정보(피보증인)-법인명
	 * queryResult.setIssuanceGuaranteeInfoEndorserNameRepresentativeName(""); // (조회결과)발행보증정보(피보증인)-성명(대표자명)
	 * queryResult.setIssuanceGuaranteeInfoEndorserAddress(""); // (조회결과)발행보증정보(피보증인)-주소
	 * queryResult.setIssuanceGuaranteeEndorserBankCode(""); // (조회결과)발행보증정보(피보증인)-은행코드
	 * queryResult.setIssuanceGuaranteeInfoAssuredCurrentAccountNumber(""); // (조회결과)발행보증정보(피보증인)-당좌계좌번호
	 * queryResult.setIssuanceGuaranteeInfoGuarantorIndvCorpSort(""); // (조회결과)발행보증정보(보증인)-개인법인구분
	 * queryResult.setIssuanceGuaranteeInfoGuarantorResidentBusinessNumber(""); // (조회결과)발행보증정보(보증인)-주민사업자번호
	 * queryResult.setIssuanceGuaranteeInfoGuarantorCorpName(""); // (조회결과)발행보증정보(보증인)-법인명
	 * queryResult.setIssuanceGuaranteeInfoGuarantorNameRepresentative(""); // (조회결과)발행보증정보(보증인)-성명(대표자명)
	 * queryResult.setIssuanceGuaranteeInfoGuarantorAddress(""); // (조회결과)발행보증정보(보증인)-주소
	 * queryResult.setIssuanceGuaranteeInfoGuarantorBankCode(""); // (조회결과)발행보증정보(보증인)-은행코드
	 * queryResult.setIssuanceGuaranteeInfoGuarantorDepositAccountNumber(""); // (조회결과)발행보증정보(보증인)-입금계좌번호
	 * queryResult.setGuaranteeTargetSplitNumber(""); // (조회결과)보증대상분할번호
	 * queryResult.setGuaranteeTargetEndorsementNumber(""); // (조회결과)보증대상배서번호
	 * queryResult.setGuaranteeNumber(""); // (조회결과)보증번호
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String noteInfoEnoteNumber; // (조회결과)어음정보-01전자어음번호
		private String noteInfoEnoteType; // (조회결과)어음정보-02어음종류
		private String noteInfoEnoteProcessStatus; // (조회결과)어음정보-03전자어음처리상태
		private String noteInfoEnoteIssueDate; // (조회결과)어음정보-04전자어음발행일자
		private String noteInfoEnoteIssuePlace; // (조회결과)어음정보-05전자어음발행지
		private long noteInfoEnoteAmount; // (조회결과)어음정보-06전자어음금액
		private String noteInfoDefaultReasonCode; // (조회결과)어음정보-07부도사유코드
		private String noteInfoEnoteMaturedDate; // (조회결과)어음정보-08전자어음만기일자
		private String beforeMaturityPaymentPresentationRequestDate; // (조회결과)어음정보-09만기전지급제시신청일자
		private String beforeMaturityPaymentPresentationDate; // (조회결과)어음정보-10만기전지급제시일자
		private String noteInfoEnoteDefaultDate; // (조회결과)어음정보-11전자어음부도일자
		private String noteInfoEnoteFinalPaymentDate; // (조회결과)어음정보-12전자어음최종결제일자
		private String noteInfoPaymentBankAndBranchCode; // (조회결과)어음정보-지급은행및점포코드
		private int noteInfoEndorsementCount; // (조회결과)어음정보-배서횟수
		private String noteInfoInstructionProhibited; // (조회결과)어음정보-지시금지여부
		private String issuerInfoCorpIndvSort; // (조회결과)발행인정보-개인법인구분
		private String issuerInfoResidentBusinessNumber; // (조회결과)발행인정보-주민사업자번호
		private String issuerInfoCorpName; // (조회결과)발행인정보-법인명
		private String issuerInfoNameRepresentativeName; // (조회결과)발행인정보-성명(대표자명)
		private String issuerInfoAddress; // (조회결과)발행인정보-주소
		private String issuerInfoCurrentAccountNumber; // (조회결과)발행인정보-당좌계좌번호
		private String issuanceGuaranteeYn; // (조회결과)발행보증여부
		private String postmaturedEndorsementYn; // (조회결과)기한후배서여부
		private String splitNumber; // (조회결과)분할번호
		private String endorsementNumber; // (조회결과)배서번호
		private long endorsementAmount; // (조회결과)배서금액
		private String endorsementDate; // (조회결과)배서일자
		private String issuanceGuaranteeInfoEndorserCorpIndvSort; // (조회결과)발행보증정보(피보증인)-개인법인구분
		private String issuanceGuaranteeInfoEndorserResidentBusinessNumber; // (조회결과)발행보증정보(피보증인)-주민사업자번호
		private String issuanceGuaranteeInfoEndorserCorpName; // (조회결과)발행보증정보(피보증인)-법인명
		private String issuanceGuaranteeInfoEndorserNameRepresentativeName; // (조회결과)발행보증정보(피보증인)-성명(대표자명)
		private String issuanceGuaranteeInfoEndorserAddress; // (조회결과)발행보증정보(피보증인)-주소
		private String issuanceGuaranteeEndorserBankCode; // (조회결과)발행보증정보(피보증인)-은행코드
		private String issuanceGuaranteeInfoAssuredCurrentAccountNumber; // (조회결과)발행보증정보(피보증인)-당좌계좌번호
		private String issuanceGuaranteeInfoGuarantorIndvCorpSort; // (조회결과)발행보증정보(보증인)-개인법인구분
		private String issuanceGuaranteeInfoGuarantorResidentBusinessNumber; // (조회결과)발행보증정보(보증인)-주민사업자번호
		private String issuanceGuaranteeInfoGuarantorCorpName; // (조회결과)발행보증정보(보증인)-법인명
		private String issuanceGuaranteeInfoGuarantorNameRepresentative; // (조회결과)발행보증정보(보증인)-성명(대표자명)
		private String issuanceGuaranteeInfoGuarantorAddress; // (조회결과)발행보증정보(보증인)-주소
		private String issuanceGuaranteeInfoGuarantorBankCode; // (조회결과)발행보증정보(보증인)-은행코드
		private String issuanceGuaranteeInfoGuarantorDepositAccountNumber; // (조회결과)발행보증정보(보증인)-입금계좌번호
		private String guaranteeTargetSplitNumber; // (조회결과)보증대상분할번호
		private String guaranteeTargetEndorsementNumber; // (조회결과)보증대상배서번호
		private String guaranteeNumber; // (조회결과)보증번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteNumber$; // (조회결과)어음정보-01전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteType$; // (조회결과)어음정보-02어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteProcessStatus$; // (조회결과)어음정보-03전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssueDate$; // (조회결과)어음정보-04전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteIssuePlace$; // (조회결과)어음정보-05전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteAmount$; // (조회결과)어음정보-06전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoDefaultReasonCode$; // (조회결과)어음정보-07부도사유코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteMaturedDate$; // (조회결과)어음정보-08전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beforeMaturityPaymentPresentationRequestDate$; // (조회결과)어음정보-09만기전지급제시신청일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String beforeMaturityPaymentPresentationDate$; // (조회결과)어음정보-10만기전지급제시일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteDefaultDate$; // (조회결과)어음정보-11전자어음부도일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEnoteFinalPaymentDate$; // (조회결과)어음정보-12전자어음최종결제일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoPaymentBankAndBranchCode$; // (조회결과)어음정보-지급은행및점포코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoEndorsementCount$; // (조회결과)어음정보-배서횟수
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteInfoInstructionProhibited$; // (조회결과)어음정보-지시금지여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoCorpIndvSort$; // (조회결과)발행인정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoResidentBusinessNumber$; // (조회결과)발행인정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoCorpName$; // (조회결과)발행인정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoNameRepresentativeName$; // (조회결과)발행인정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoAddress$; // (조회결과)발행인정보-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerInfoCurrentAccountNumber$; // (조회결과)발행인정보-당좌계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeYn$; // (조회결과)발행보증여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String postmaturedEndorsementYn$; // (조회결과)기한후배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String splitNumber$; // (조회결과)분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementNumber$; // (조회결과)배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementAmount$; // (조회결과)배서금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementDate$; // (조회결과)배서일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoEndorserCorpIndvSort$; // (조회결과)발행보증정보(피보증인)-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoEndorserResidentBusinessNumber$; // (조회결과)발행보증정보(피보증인)-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoEndorserCorpName$; // (조회결과)발행보증정보(피보증인)-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoEndorserNameRepresentativeName$; // (조회결과)발행보증정보(피보증인)-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoEndorserAddress$; // (조회결과)발행보증정보(피보증인)-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeEndorserBankCode$; // (조회결과)발행보증정보(피보증인)-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoAssuredCurrentAccountNumber$; // (조회결과)발행보증정보(피보증인)-당좌계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorIndvCorpSort$; // (조회결과)발행보증정보(보증인)-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorResidentBusinessNumber$; // (조회결과)발행보증정보(보증인)-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorCorpName$; // (조회결과)발행보증정보(보증인)-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorNameRepresentative$; // (조회결과)발행보증정보(보증인)-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorAddress$; // (조회결과)발행보증정보(보증인)-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorBankCode$; // (조회결과)발행보증정보(보증인)-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuanceGuaranteeInfoGuarantorDepositAccountNumber$; // (조회결과)발행보증정보(보증인)-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeTargetSplitNumber$; // (조회결과)보증대상분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeTargetEndorsementNumber$; // (조회결과)보증대상배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeNumber$; // (조회결과)보증번호

		@Override
		public void write(OutputStream out) throws IOException {
			noteInfoEnoteNumber$ = VOUtils.write(out, noteInfoEnoteNumber, 20); // (조회결과)어음정보-01전자어음번호
			noteInfoEnoteType$ = VOUtils.write(out, noteInfoEnoteType, 1); // (조회결과)어음정보-02어음종류
			noteInfoEnoteProcessStatus$ = VOUtils.write(out, noteInfoEnoteProcessStatus, 2); // (조회결과)어음정보-03전자어음처리상태
			noteInfoEnoteIssueDate$ = VOUtils.write(out, noteInfoEnoteIssueDate, 8); // (조회결과)어음정보-04전자어음발행일자
			noteInfoEnoteIssuePlace$ = VOUtils.write(out, noteInfoEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음정보-05전자어음발행지
			noteInfoEnoteAmount$ = VOUtils.write(out, noteInfoEnoteAmount, 15); // (조회결과)어음정보-06전자어음금액
			noteInfoDefaultReasonCode$ = VOUtils.write(out, noteInfoDefaultReasonCode, 2); // (조회결과)어음정보-07부도사유코드
			noteInfoEnoteMaturedDate$ = VOUtils.write(out, noteInfoEnoteMaturedDate, 8); // (조회결과)어음정보-08전자어음만기일자
			beforeMaturityPaymentPresentationRequestDate$ = VOUtils.write(out, beforeMaturityPaymentPresentationRequestDate, 8); // (조회결과)어음정보-09만기전지급제시신청일자
			beforeMaturityPaymentPresentationDate$ = VOUtils.write(out, beforeMaturityPaymentPresentationDate, 8); // (조회결과)어음정보-10만기전지급제시일자
			noteInfoEnoteDefaultDate$ = VOUtils.write(out, noteInfoEnoteDefaultDate, 8); // (조회결과)어음정보-11전자어음부도일자
			noteInfoEnoteFinalPaymentDate$ = VOUtils.write(out, noteInfoEnoteFinalPaymentDate, 8); // (조회결과)어음정보-12전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode$ = VOUtils.write(out, noteInfoPaymentBankAndBranchCode, 7); // (조회결과)어음정보-지급은행및점포코드
			noteInfoEndorsementCount$ = VOUtils.write(out, noteInfoEndorsementCount, 2); // (조회결과)어음정보-배서횟수
			noteInfoInstructionProhibited$ = VOUtils.write(out, noteInfoInstructionProhibited, 1); // (조회결과)어음정보-지시금지여부
			issuerInfoCorpIndvSort$ = VOUtils.write(out, issuerInfoCorpIndvSort, 1); // (조회결과)발행인정보-개인법인구분
			issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // (조회결과)발행인정보-주민사업자번호
			issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // (조회결과)발행인정보-법인명
			issuerInfoNameRepresentativeName$ = VOUtils.write(out, issuerInfoNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인정보-성명(대표자명)
			issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // (조회결과)발행인정보-주소
			issuerInfoCurrentAccountNumber$ = VOUtils.write(out, issuerInfoCurrentAccountNumber, 16); // (조회결과)발행인정보-당좌계좌번호
			issuanceGuaranteeYn$ = VOUtils.write(out, issuanceGuaranteeYn, 1); // (조회결과)발행보증여부
			postmaturedEndorsementYn$ = VOUtils.write(out, postmaturedEndorsementYn, 1); // (조회결과)기한후배서여부
			splitNumber$ = VOUtils.write(out, splitNumber, 2); // (조회결과)분할번호
			endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // (조회결과)배서번호
			endorsementAmount$ = VOUtils.write(out, endorsementAmount, 15); // (조회결과)배서금액
			endorsementDate$ = VOUtils.write(out, endorsementDate, 8); // (조회결과)배서일자
			issuanceGuaranteeInfoEndorserCorpIndvSort$ = VOUtils.write(out, issuanceGuaranteeInfoEndorserCorpIndvSort, 1); // (조회결과)발행보증정보(피보증인)-개인법인구분
			issuanceGuaranteeInfoEndorserResidentBusinessNumber$ = VOUtils.write(out, issuanceGuaranteeInfoEndorserResidentBusinessNumber, 13); // (조회결과)발행보증정보(피보증인)-주민사업자번호
			issuanceGuaranteeInfoEndorserCorpName$ = VOUtils.write(out, issuanceGuaranteeInfoEndorserCorpName, 40, "EUC-KR"); // (조회결과)발행보증정보(피보증인)-법인명
			issuanceGuaranteeInfoEndorserNameRepresentativeName$ = VOUtils.write(out, issuanceGuaranteeInfoEndorserNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행보증정보(피보증인)-성명(대표자명)
			issuanceGuaranteeInfoEndorserAddress$ = VOUtils.write(out, issuanceGuaranteeInfoEndorserAddress, 60, "EUC-KR"); // (조회결과)발행보증정보(피보증인)-주소
			issuanceGuaranteeEndorserBankCode$ = VOUtils.write(out, issuanceGuaranteeEndorserBankCode, 3); // (조회결과)발행보증정보(피보증인)-은행코드
			issuanceGuaranteeInfoAssuredCurrentAccountNumber$ = VOUtils.write(out, issuanceGuaranteeInfoAssuredCurrentAccountNumber, 16); // (조회결과)발행보증정보(피보증인)-당좌계좌번호
			issuanceGuaranteeInfoGuarantorIndvCorpSort$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorIndvCorpSort, 1); // (조회결과)발행보증정보(보증인)-개인법인구분
			issuanceGuaranteeInfoGuarantorResidentBusinessNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorResidentBusinessNumber, 13); // (조회결과)발행보증정보(보증인)-주민사업자번호
			issuanceGuaranteeInfoGuarantorCorpName$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorCorpName, 40, "EUC-KR"); // (조회결과)발행보증정보(보증인)-법인명
			issuanceGuaranteeInfoGuarantorNameRepresentative$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorNameRepresentative, 20, "EUC-KR"); // (조회결과)발행보증정보(보증인)-성명(대표자명)
			issuanceGuaranteeInfoGuarantorAddress$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorAddress, 60, "EUC-KR"); // (조회결과)발행보증정보(보증인)-주소
			issuanceGuaranteeInfoGuarantorBankCode$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorBankCode, 3); // (조회결과)발행보증정보(보증인)-은행코드
			issuanceGuaranteeInfoGuarantorDepositAccountNumber$ = VOUtils.write(out, issuanceGuaranteeInfoGuarantorDepositAccountNumber, 16); // (조회결과)발행보증정보(보증인)-입금계좌번호
			guaranteeTargetSplitNumber$ = VOUtils.write(out, guaranteeTargetSplitNumber, 2); // (조회결과)보증대상분할번호
			guaranteeTargetEndorsementNumber$ = VOUtils.write(out, guaranteeTargetEndorsementNumber, 2); // (조회결과)보증대상배서번호
			guaranteeNumber$ = VOUtils.write(out, guaranteeNumber, 4); // (조회결과)보증번호
		}

		@Override
		public void read(InputStream in) throws IOException {
			noteInfoEnoteNumber = VOUtils.toString(noteInfoEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음정보-01전자어음번호
			noteInfoEnoteType = VOUtils.toString(noteInfoEnoteType$ = VOUtils.read(in, 1)); // (조회결과)어음정보-02어음종류
			noteInfoEnoteProcessStatus = VOUtils.toString(noteInfoEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음정보-03전자어음처리상태
			noteInfoEnoteIssueDate = VOUtils.toString(noteInfoEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-04전자어음발행일자
			noteInfoEnoteIssuePlace = VOUtils.toString(noteInfoEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음정보-05전자어음발행지
			noteInfoEnoteAmount = VOUtils.toLong(noteInfoEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음정보-06전자어음금액
			noteInfoDefaultReasonCode = VOUtils.toString(noteInfoDefaultReasonCode$ = VOUtils.read(in, 2)); // (조회결과)어음정보-07부도사유코드
			noteInfoEnoteMaturedDate = VOUtils.toString(noteInfoEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-08전자어음만기일자
			beforeMaturityPaymentPresentationRequestDate = VOUtils.toString(beforeMaturityPaymentPresentationRequestDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-09만기전지급제시신청일자
			beforeMaturityPaymentPresentationDate = VOUtils.toString(beforeMaturityPaymentPresentationDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-10만기전지급제시일자
			noteInfoEnoteDefaultDate = VOUtils.toString(noteInfoEnoteDefaultDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-11전자어음부도일자
			noteInfoEnoteFinalPaymentDate = VOUtils.toString(noteInfoEnoteFinalPaymentDate$ = VOUtils.read(in, 8)); // (조회결과)어음정보-12전자어음최종결제일자
			noteInfoPaymentBankAndBranchCode = VOUtils.toString(noteInfoPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음정보-지급은행및점포코드
			noteInfoEndorsementCount = VOUtils.toInt(noteInfoEndorsementCount$ = VOUtils.read(in, 2)); // (조회결과)어음정보-배서횟수
			noteInfoInstructionProhibited = VOUtils.toString(noteInfoInstructionProhibited$ = VOUtils.read(in, 1)); // (조회결과)어음정보-지시금지여부
			issuerInfoCorpIndvSort = VOUtils.toString(issuerInfoCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인정보-개인법인구분
			issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인정보-주민사업자번호
			issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인정보-법인명
			issuerInfoNameRepresentativeName = VOUtils.toString(issuerInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인정보-성명(대표자명)
			issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인정보-주소
			issuerInfoCurrentAccountNumber = VOUtils.toString(issuerInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행인정보-당좌계좌번호
			issuanceGuaranteeYn = VOUtils.toString(issuanceGuaranteeYn$ = VOUtils.read(in, 1)); // (조회결과)발행보증여부
			postmaturedEndorsementYn = VOUtils.toString(postmaturedEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)기한후배서여부
			splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // (조회결과)분할번호
			endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)배서번호
			endorsementAmount = VOUtils.toLong(endorsementAmount$ = VOUtils.read(in, 15)); // (조회결과)배서금액
			endorsementDate = VOUtils.toString(endorsementDate$ = VOUtils.read(in, 8)); // (조회결과)배서일자
			issuanceGuaranteeInfoEndorserCorpIndvSort = VOUtils.toString(issuanceGuaranteeInfoEndorserCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행보증정보(피보증인)-개인법인구분
			issuanceGuaranteeInfoEndorserResidentBusinessNumber = VOUtils.toString(issuanceGuaranteeInfoEndorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행보증정보(피보증인)-주민사업자번호
			issuanceGuaranteeInfoEndorserCorpName = VOUtils.toString(issuanceGuaranteeInfoEndorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행보증정보(피보증인)-법인명
			issuanceGuaranteeInfoEndorserNameRepresentativeName = VOUtils.toString(issuanceGuaranteeInfoEndorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행보증정보(피보증인)-성명(대표자명)
			issuanceGuaranteeInfoEndorserAddress = VOUtils.toString(issuanceGuaranteeInfoEndorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행보증정보(피보증인)-주소
			issuanceGuaranteeEndorserBankCode = VOUtils.toString(issuanceGuaranteeEndorserBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행보증정보(피보증인)-은행코드
			issuanceGuaranteeInfoAssuredCurrentAccountNumber = VOUtils.toString(issuanceGuaranteeInfoAssuredCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행보증정보(피보증인)-당좌계좌번호
			issuanceGuaranteeInfoGuarantorIndvCorpSort = VOUtils.toString(issuanceGuaranteeInfoGuarantorIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)발행보증정보(보증인)-개인법인구분
			issuanceGuaranteeInfoGuarantorResidentBusinessNumber = VOUtils.toString(issuanceGuaranteeInfoGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행보증정보(보증인)-주민사업자번호
			issuanceGuaranteeInfoGuarantorCorpName = VOUtils.toString(issuanceGuaranteeInfoGuarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행보증정보(보증인)-법인명
			issuanceGuaranteeInfoGuarantorNameRepresentative = VOUtils.toString(issuanceGuaranteeInfoGuarantorNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행보증정보(보증인)-성명(대표자명)
			issuanceGuaranteeInfoGuarantorAddress = VOUtils.toString(issuanceGuaranteeInfoGuarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행보증정보(보증인)-주소
			issuanceGuaranteeInfoGuarantorBankCode = VOUtils.toString(issuanceGuaranteeInfoGuarantorBankCode$ = VOUtils.read(in, 3)); // (조회결과)발행보증정보(보증인)-은행코드
			issuanceGuaranteeInfoGuarantorDepositAccountNumber = VOUtils.toString(issuanceGuaranteeInfoGuarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행보증정보(보증인)-입금계좌번호
			guaranteeTargetSplitNumber = VOUtils.toString(guaranteeTargetSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)보증대상분할번호
			guaranteeTargetEndorsementNumber = VOUtils.toString(guaranteeTargetEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)보증대상배서번호
			guaranteeNumber = VOUtils.toString(guaranteeNumber$ = VOUtils.read(in, 4)); // (조회결과)보증번호
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", noteInfoEnoteNumber=").append(noteInfoEnoteNumber).append(System.lineSeparator()); // (조회결과)어음정보-01전자어음번호
			sb.append(", noteInfoEnoteType=").append(noteInfoEnoteType).append(System.lineSeparator()); // (조회결과)어음정보-02어음종류
			sb.append(", noteInfoEnoteProcessStatus=").append(noteInfoEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음정보-03전자어음처리상태
			sb.append(", noteInfoEnoteIssueDate=").append(noteInfoEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음정보-04전자어음발행일자
			sb.append(", noteInfoEnoteIssuePlace=").append(noteInfoEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음정보-05전자어음발행지
			sb.append(", noteInfoEnoteAmount=").append(noteInfoEnoteAmount).append(System.lineSeparator()); // (조회결과)어음정보-06전자어음금액
			sb.append(", noteInfoDefaultReasonCode=").append(noteInfoDefaultReasonCode).append(System.lineSeparator()); // (조회결과)어음정보-07부도사유코드
			sb.append(", noteInfoEnoteMaturedDate=").append(noteInfoEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음정보-08전자어음만기일자
			sb.append(", beforeMaturityPaymentPresentationRequestDate=").append(beforeMaturityPaymentPresentationRequestDate).append(System.lineSeparator()); // (조회결과)어음정보-09만기전지급제시신청일자
			sb.append(", beforeMaturityPaymentPresentationDate=").append(beforeMaturityPaymentPresentationDate).append(System.lineSeparator()); // (조회결과)어음정보-10만기전지급제시일자
			sb.append(", noteInfoEnoteDefaultDate=").append(noteInfoEnoteDefaultDate).append(System.lineSeparator()); // (조회결과)어음정보-11전자어음부도일자
			sb.append(", noteInfoEnoteFinalPaymentDate=").append(noteInfoEnoteFinalPaymentDate).append(System.lineSeparator()); // (조회결과)어음정보-12전자어음최종결제일자
			sb.append(", noteInfoPaymentBankAndBranchCode=").append(noteInfoPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음정보-지급은행및점포코드
			sb.append(", noteInfoEndorsementCount=").append(noteInfoEndorsementCount).append(System.lineSeparator()); // (조회결과)어음정보-배서횟수
			sb.append(", noteInfoInstructionProhibited=").append(noteInfoInstructionProhibited).append(System.lineSeparator()); // (조회결과)어음정보-지시금지여부
			sb.append(", issuerInfoCorpIndvSort=").append(issuerInfoCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인정보-개인법인구분
			sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인정보-주민사업자번호
			sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // (조회결과)발행인정보-법인명
			sb.append(", issuerInfoNameRepresentativeName=").append(issuerInfoNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인정보-성명(대표자명)
			sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // (조회결과)발행인정보-주소
			sb.append(", issuerInfoCurrentAccountNumber=").append(issuerInfoCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행인정보-당좌계좌번호
			sb.append(", issuanceGuaranteeYn=").append(issuanceGuaranteeYn).append(System.lineSeparator()); // (조회결과)발행보증여부
			sb.append(", postmaturedEndorsementYn=").append(postmaturedEndorsementYn).append(System.lineSeparator()); // (조회결과)기한후배서여부
			sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // (조회결과)분할번호
			sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // (조회결과)배서번호
			sb.append(", endorsementAmount=").append(endorsementAmount).append(System.lineSeparator()); // (조회결과)배서금액
			sb.append(", endorsementDate=").append(endorsementDate).append(System.lineSeparator()); // (조회결과)배서일자
			sb.append(", issuanceGuaranteeInfoEndorserCorpIndvSort=").append(issuanceGuaranteeInfoEndorserCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-개인법인구분
			sb.append(", issuanceGuaranteeInfoEndorserResidentBusinessNumber=").append(issuanceGuaranteeInfoEndorserResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-주민사업자번호
			sb.append(", issuanceGuaranteeInfoEndorserCorpName=").append(issuanceGuaranteeInfoEndorserCorpName).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-법인명
			sb.append(", issuanceGuaranteeInfoEndorserNameRepresentativeName=").append(issuanceGuaranteeInfoEndorserNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-성명(대표자명)
			sb.append(", issuanceGuaranteeInfoEndorserAddress=").append(issuanceGuaranteeInfoEndorserAddress).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-주소
			sb.append(", issuanceGuaranteeEndorserBankCode=").append(issuanceGuaranteeEndorserBankCode).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-은행코드
			sb.append(", issuanceGuaranteeInfoAssuredCurrentAccountNumber=").append(issuanceGuaranteeInfoAssuredCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행보증정보(피보증인)-당좌계좌번호
			sb.append(", issuanceGuaranteeInfoGuarantorIndvCorpSort=").append(issuanceGuaranteeInfoGuarantorIndvCorpSort).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-개인법인구분
			sb.append(", issuanceGuaranteeInfoGuarantorResidentBusinessNumber=").append(issuanceGuaranteeInfoGuarantorResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-주민사업자번호
			sb.append(", issuanceGuaranteeInfoGuarantorCorpName=").append(issuanceGuaranteeInfoGuarantorCorpName).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-법인명
			sb.append(", issuanceGuaranteeInfoGuarantorNameRepresentative=").append(issuanceGuaranteeInfoGuarantorNameRepresentative).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-성명(대표자명)
			sb.append(", issuanceGuaranteeInfoGuarantorAddress=").append(issuanceGuaranteeInfoGuarantorAddress).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-주소
			sb.append(", issuanceGuaranteeInfoGuarantorBankCode=").append(issuanceGuaranteeInfoGuarantorBankCode).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-은행코드
			sb.append(", issuanceGuaranteeInfoGuarantorDepositAccountNumber=").append(issuanceGuaranteeInfoGuarantorDepositAccountNumber).append(System.lineSeparator()); // (조회결과)발행보증정보(보증인)-입금계좌번호
			sb.append(", guaranteeTargetSplitNumber=").append(guaranteeTargetSplitNumber).append(System.lineSeparator()); // (조회결과)보증대상분할번호
			sb.append(", guaranteeTargetEndorsementNumber=").append(guaranteeTargetEndorsementNumber).append(System.lineSeparator()); // (조회결과)보증대상배서번호
			sb.append(", guaranteeNumber=").append(guaranteeNumber).append(System.lineSeparator()); // (조회결과)보증번호
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "492000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String sortCondition; // 정렬조건
	private String searchConditionSort; // 검색조건구분
	private String inquiryNoteStatus; // 조회전자어음상태구분
	private String residentBusinessNumber; // 주민사업자번호
	private String depositAccountNumber; // 입금계좌번호
	private String lastTransactionDateInquiryStartDate; // 최종거래일기준조회시작일
	private String lastTransactionDateInquiryEndDate; // 최종거래일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0200492000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sortCondition$; // 정렬조건
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String inquiryNoteStatus$; // 조회전자어음상태구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String lastTransactionDateInquiryStartDate$; // 최종거래일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String lastTransactionDateInquiryEndDate$; // 최종거래일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 17;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		sortCondition$ = VOUtils.write(out, sortCondition, 2); // 정렬조건
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		inquiryNoteStatus$ = VOUtils.write(out, inquiryNoteStatus, 1); // 조회전자어음상태구분
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		lastTransactionDateInquiryStartDate$ = VOUtils.write(out, lastTransactionDateInquiryStartDate, 8); // 최종거래일기준조회시작일
		lastTransactionDateInquiryEndDate$ = VOUtils.write(out, lastTransactionDateInquiryEndDate, 8); // 최종거래일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0200492000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		sortCondition = VOUtils.toString(sortCondition$ = VOUtils.read(in, 2)); // 정렬조건
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		inquiryNoteStatus = VOUtils.toString(inquiryNoteStatus$ = VOUtils.read(in, 1)); // 조회전자어음상태구분
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		lastTransactionDateInquiryStartDate = VOUtils.toString(lastTransactionDateInquiryStartDate$ = VOUtils.read(in, 8)); // 최종거래일기준조회시작일
		lastTransactionDateInquiryEndDate = VOUtils.toString(lastTransactionDateInquiryEndDate$ = VOUtils.read(in, 8)); // 최종거래일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0200492000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", sortCondition=").append(sortCondition).append(System.lineSeparator()); // 정렬조건
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", inquiryNoteStatus=").append(inquiryNoteStatus).append(System.lineSeparator()); // 조회전자어음상태구분
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", lastTransactionDateInquiryStartDate=").append(lastTransactionDateInquiryStartDate).append(System.lineSeparator()); // 최종거래일기준조회시작일
		sb.append(", lastTransactionDateInquiryEndDate=").append(lastTransactionDateInquiryEndDate).append(System.lineSeparator()); // 최종거래일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "492000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "sortCondition", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "inquiryNoteStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "lastTransactionDateInquiryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "lastTransactionDateInquiryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteInfoDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "beforeMaturityPaymentPresentationRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "beforeMaturityPaymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteDefaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoEnoteFinalPaymentDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteInfoPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "noteInfoEndorsementCount", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteInfoInstructionProhibited", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "postmaturedEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "endorsementDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoEndorserCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoEndorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoEndorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoEndorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoEndorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeEndorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoAssuredCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuaranteeInfoGuarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeTargetSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "guaranteeTargetEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "guaranteeNumber", "fldLen", "4", "defltVal", "")
		);
	}

}
