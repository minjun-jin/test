package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 인출정지정보공유
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 
 * systemId 시스템-ID 
 * messageType 전문종별코드 
 * messageCode 거래구분코드 
 * sendReceiveFlag 송수신FLAG 
 * status STATUS 
 * responseCode 응답코드 
 * messageTransmissionDate 전문전송일 
 * messageSendTime 전문전송시간 
 * messageTrackingNumber 전문추적번호 
 * traxOccurredDate 거래발생일 
 * transactionIdNumber 거래고유번호 
 * handlingInstitutionRepCode 취급기관대표코드 
 * requestBranchCode 취급기관ㆍ점별코드 
 * beneficiaryBankCode 개설기관대표코드 
 * beneficiaryBranchCode 개설기관ㆍ점별코드 
 * withdrawSuspendedAccountNumber 인출정지계좌번호 
 * relatedTransactionProcessDate 연관거래처리일자 
 * relatedTransactionProcessTime 연관거래처리시간 
 * relatedTransactionSystemCode 연관거래시스템코드 
 * relatedTransactionId 연관거래거래고유번호 
 * relatedTransactionDebitCreditFlag 연관거래입출금구분 
 * counterAccountNumber 상대계좌번호 
 * relatedTransactionAmount 연관거래거래금액 
 * employeeName 담당자이름 
 * employeeContact 담당자전화번호 
 * referenceContent 참고내용 
 * filler FILLER 
 * reservedInformationField1 예비정보FIELD 
 * reservedInformationField2 예비정보FIELD 
 * 
 * KftHof0200950000 kftHof0200950000 = new KftHof0200950000(); // 인출정지정보공유
 * kftHof0200950000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0200950000.setSystemId("ELB"); // 시스템-ID
 * kftHof0200950000.setMessageType("0200"); // 전문종별코드
 * kftHof0200950000.setMessageCode("950000"); // 거래구분코드
 * kftHof0200950000.setSendReceiveFlag("1"); // 송수신FLAG
 * kftHof0200950000.setStatus("000"); // STATUS
 * kftHof0200950000.setResponseCode(""); // 응답코드
 * kftHof0200950000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0200950000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0200950000.setMessageTrackingNumber("00000000"); // 전문추적번호
 * kftHof0200950000.setTraxOccurredDate(LocalDate.now()); // 거래발생일
 * kftHof0200950000.setTransactionIdNumber(""); // 거래고유번호
 * kftHof0200950000.setHandlingInstitutionRepCode("000"); // 취급기관대표코드
 * kftHof0200950000.setRequestBranchCode("0000000"); // 취급기관ㆍ점별코드
 * kftHof0200950000.setBeneficiaryBankCode("000"); // 개설기관대표코드
 * kftHof0200950000.setBeneficiaryBranchCode("0000000"); // 개설기관ㆍ점별코드
 * kftHof0200950000.setWithdrawSuspendedAccountNumber(""); // 인출정지계좌번호
 * kftHof0200950000.setRelatedTransactionProcessDate("00000000"); // 연관거래처리일자
 * kftHof0200950000.setRelatedTransactionProcessTime("000000"); // 연관거래처리시간
 * kftHof0200950000.setRelatedTransactionSystemCode(""); // 연관거래시스템코드
 * kftHof0200950000.setRelatedTransactionId(""); // 연관거래거래고유번호
 * kftHof0200950000.setRelatedTransactionDebitCreditFlag(""); // 연관거래입출금구분
 * kftHof0200950000.setCounterAccountNumber(""); // 상대계좌번호
 * kftHof0200950000.setRelatedTransactionAmount(0L); // 연관거래거래금액
 * kftHof0200950000.setEmployeeName(""); // 담당자이름
 * kftHof0200950000.setEmployeeContact(""); // 담당자전화번호
 * kftHof0200950000.setReferenceContent(""); // 참고내용
 * kftHof0200950000.setFiller(""); // FILLER
 * kftHof0200950000.setReservedInformationField1(""); // 예비정보FIELD
 * kftHof0200950000.setReservedInformationField2(""); // 예비정보FIELD
 * }</pre>
 */
@Data
public class KftHof0200950000 implements KftHofComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "ELB"; // 시스템-ID
	private String messageType = "0200"; // 전문종별코드
	private String messageCode = "950000"; // 거래구분코드
	private String sendReceiveFlag = "1"; // 송수신FLAG
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "00000000"; // 전문추적번호
	private LocalDate traxOccurredDate; // 거래발생일
	private String transactionIdNumber; // 거래고유번호
	private String handlingInstitutionRepCode = "000"; // 취급기관대표코드
	private String requestBranchCode = "0000000"; // 취급기관ㆍ점별코드
	private String beneficiaryBankCode = "000"; // 개설기관대표코드
	private String beneficiaryBranchCode = "0000000"; // 개설기관ㆍ점별코드
	private String withdrawSuspendedAccountNumber; // 인출정지계좌번호
	private String relatedTransactionProcessDate = "00000000"; // 연관거래처리일자
	private String relatedTransactionProcessTime = "000000"; // 연관거래처리시간
	private String relatedTransactionSystemCode; // 연관거래시스템코드
	private String relatedTransactionId; // 연관거래거래고유번호
	private String relatedTransactionDebitCreditFlag; // 연관거래입출금구분
	private String counterAccountNumber; // 상대계좌번호
	private long relatedTransactionAmount; // 연관거래거래금액
	private String employeeName; // 담당자이름
	private String employeeContact; // 담당자전화번호
	private String referenceContent; // 참고내용
	private String filler; // FILLER
	private String reservedInformationField1; // 예비정보FIELD
	private String reservedInformationField2; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String traxOccurredDate$; // 거래발생일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingInstitutionRepCode$; // 취급기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawSuspendedAccountNumber$; // 인출정지계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionProcessDate$; // 연관거래처리일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionProcessTime$; // 연관거래처리시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionSystemCode$; // 연관거래시스템코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionId$; // 연관거래거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionDebitCreditFlag$; // 연관거래입출금구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String counterAccountNumber$; // 상대계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String relatedTransactionAmount$; // 연관거래거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String employeeName$; // 담당자이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String employeeContact$; // 담당자전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String referenceContent$; // 참고내용
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField1$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField2$; // 예비정보FIELD

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 4;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 7;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 8;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 9;
		}
		if (VOUtils.isWhitespace(traxOccurredDate$)) { // 거래발생일
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(withdrawSuspendedAccountNumber$)) { // 인출정지계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(relatedTransactionSystemCode$)) { // 연관거래시스템코드
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(relatedTransactionId$)) { // 연관거래거래고유번호
			return 20;
		}
		if (VOUtils.isNotAlphanumericSpace(counterAccountNumber$)) { // 상대계좌번호
			return 22;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 8); // 전문추적번호
		traxOccurredDate$ = VOUtils.write(out, traxOccurredDate, 8, "yyyyMMdd"); // 거래발생일
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		handlingInstitutionRepCode$ = VOUtils.write(out, handlingInstitutionRepCode, 3); // 취급기관대표코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관대표코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 7); // 개설기관ㆍ점별코드
		withdrawSuspendedAccountNumber$ = VOUtils.write(out, withdrawSuspendedAccountNumber, 16); // 인출정지계좌번호
		relatedTransactionProcessDate$ = VOUtils.write(out, relatedTransactionProcessDate, 8); // 연관거래처리일자
		relatedTransactionProcessTime$ = VOUtils.write(out, relatedTransactionProcessTime, 6); // 연관거래처리시간
		relatedTransactionSystemCode$ = VOUtils.write(out, relatedTransactionSystemCode, 2); // 연관거래시스템코드
		relatedTransactionId$ = VOUtils.write(out, relatedTransactionId, 20); // 연관거래거래고유번호
		relatedTransactionDebitCreditFlag$ = VOUtils.write(out, relatedTransactionDebitCreditFlag, 1); // 연관거래입출금구분
		counterAccountNumber$ = VOUtils.write(out, counterAccountNumber, 16); // 상대계좌번호
		relatedTransactionAmount$ = VOUtils.write(out, relatedTransactionAmount, 14); // 연관거래거래금액
		employeeName$ = VOUtils.write(out, employeeName, 20, "EUC-KR"); // 담당자이름
		employeeContact$ = VOUtils.write(out, employeeContact, 15); // 담당자전화번호
		referenceContent$ = VOUtils.write(out, referenceContent, 80, "EUC-KR"); // 참고내용
		filler$ = VOUtils.write(out, filler, 181); // FILLER
		reservedInformationField1$ = VOUtils.write(out, reservedInformationField1, 10); // 예비정보FIELD
		reservedInformationField2$ = VOUtils.write(out, reservedInformationField2, 28); // 예비정보FIELD
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 8)); // 전문추적번호
		traxOccurredDate = VOUtils.toLocalDate(traxOccurredDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 거래발생일
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		handlingInstitutionRepCode = VOUtils.toString(handlingInstitutionRepCode$ = VOUtils.read(in, 3)); // 취급기관대표코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관대표코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		withdrawSuspendedAccountNumber = VOUtils.toString(withdrawSuspendedAccountNumber$ = VOUtils.read(in, 16)); // 인출정지계좌번호
		relatedTransactionProcessDate = VOUtils.toString(relatedTransactionProcessDate$ = VOUtils.read(in, 8)); // 연관거래처리일자
		relatedTransactionProcessTime = VOUtils.toString(relatedTransactionProcessTime$ = VOUtils.read(in, 6)); // 연관거래처리시간
		relatedTransactionSystemCode = VOUtils.toString(relatedTransactionSystemCode$ = VOUtils.read(in, 2)); // 연관거래시스템코드
		relatedTransactionId = VOUtils.toString(relatedTransactionId$ = VOUtils.read(in, 20)); // 연관거래거래고유번호
		relatedTransactionDebitCreditFlag = VOUtils.toString(relatedTransactionDebitCreditFlag$ = VOUtils.read(in, 1)); // 연관거래입출금구분
		counterAccountNumber = VOUtils.toString(counterAccountNumber$ = VOUtils.read(in, 16)); // 상대계좌번호
		relatedTransactionAmount = VOUtils.toLong(relatedTransactionAmount$ = VOUtils.read(in, 14)); // 연관거래거래금액
		employeeName = VOUtils.toString(employeeName$ = VOUtils.read(in, 20, "EUC-KR")); // 담당자이름
		employeeContact = VOUtils.toString(employeeContact$ = VOUtils.read(in, 15)); // 담당자전화번호
		referenceContent = VOUtils.toString(referenceContent$ = VOUtils.read(in, 80, "EUC-KR")); // 참고내용
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 181)); // FILLER
		reservedInformationField1 = VOUtils.toString(reservedInformationField1$ = VOUtils.read(in, 10)); // 예비정보FIELD
		reservedInformationField2 = VOUtils.toString(reservedInformationField2$ = VOUtils.read(in, 28)); // 예비정보FIELD
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", traxOccurredDate=").append(traxOccurredDate).append(System.lineSeparator()); // 거래발생일
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", handlingInstitutionRepCode=").append(handlingInstitutionRepCode).append(System.lineSeparator()); // 취급기관대표코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관대표코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", withdrawSuspendedAccountNumber=").append(withdrawSuspendedAccountNumber).append(System.lineSeparator()); // 인출정지계좌번호
		sb.append(", relatedTransactionProcessDate=").append(relatedTransactionProcessDate).append(System.lineSeparator()); // 연관거래처리일자
		sb.append(", relatedTransactionProcessTime=").append(relatedTransactionProcessTime).append(System.lineSeparator()); // 연관거래처리시간
		sb.append(", relatedTransactionSystemCode=").append(relatedTransactionSystemCode).append(System.lineSeparator()); // 연관거래시스템코드
		sb.append(", relatedTransactionId=").append(relatedTransactionId).append(System.lineSeparator()); // 연관거래거래고유번호
		sb.append(", relatedTransactionDebitCreditFlag=").append(relatedTransactionDebitCreditFlag).append(System.lineSeparator()); // 연관거래입출금구분
		sb.append(", counterAccountNumber=").append(counterAccountNumber).append(System.lineSeparator()); // 상대계좌번호
		sb.append(", relatedTransactionAmount=").append(relatedTransactionAmount).append(System.lineSeparator()); // 연관거래거래금액
		sb.append(", employeeName=").append(employeeName).append(System.lineSeparator()); // 담당자이름
		sb.append(", employeeContact=").append(employeeContact).append(System.lineSeparator()); // 담당자전화번호
		sb.append(", referenceContent=").append(referenceContent).append(System.lineSeparator()); // 참고내용
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", reservedInformationField1=").append(reservedInformationField1).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", reservedInformationField2=").append(reservedInformationField2).append(System.lineSeparator()); // 예비정보FIELD
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "ELB"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "950000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "1"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "traxOccurredDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "handlingInstitutionRepCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "withdrawSuspendedAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "relatedTransactionProcessDate", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "relatedTransactionProcessTime", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "relatedTransactionSystemCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "relatedTransactionId", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "relatedTransactionDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "counterAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "relatedTransactionAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "employeeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "employeeContact", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "referenceContent", "fldLen", "80", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "181", "defltVal", ""),
			Map.of("fld", "reservedInformationField1", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "reservedInformationField2", "fldLen", "28", "defltVal", "")
		);
	}

}
