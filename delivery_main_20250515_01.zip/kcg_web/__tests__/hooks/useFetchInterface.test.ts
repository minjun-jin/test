import { renderHook, act } from "@testing-library/react"
import useFetchInterface from "@/hooks/useFetchInterface"

// define mock hooks
const mockSelector = jest.fn()
const mockDispatch = jest.fn()

jest.mock("@/hooks/useRecoil", () => () => ({
  selector: mockSelector,
  dispatch: mockDispatch,
}))
describe("useFetchInterface Hook", () => {
  const mockValidate = jest.fn().mockResolvedValue({ key: "value" })
  const mockSetGridData = jest.fn()
  const mockSetGridCount = jest.fn()
  const mockSetValue2 = jest.fn()

  beforeEach(() => {
    jest.clearAllMocks()
    mockSelector.mockRestore()
    mockDispatch.mockRestore()
    mockUseProxy.mockAsync.mockResolvedValue({
      data: {
        outList: ["data1", "data2"],
        outListLength: 2,
        field1: "value1",
        field2: "value2",
      },
    })
  })

  afterAll(() => {
    jest.restoreAllMocks()
  })

  it("should fetch interface data and set grid data and count", async () => {
    const { result } = renderHook(() =>
      useFetchInterface({
        interfaceCd: "testCd",
        interfaceId: "testId",
        validate: mockValidate,
        setGridData: mockSetGridData,
        setGridCount: mockSetGridCount,
      }),
    )

    await act(async () => {
      await result.current.fetchInterfaceDataSetGrid({ type: "click" })
    })

    expect(mockValidate).toHaveBeenCalled()
    expect(mockUseProxy.mockAsync).toHaveBeenCalledWith({
      interfaceCd: "testCd",
      interfaceId: "testId",
      key: "value",
    })
    expect(mockSetGridData).toHaveBeenCalledWith(["data1", "data2"])
    expect(mockSetGridCount).toHaveBeenCalledWith({ totalCnt: 2 })
  })

  it("should fetch interface data and set values to box", async () => {
    const { result } = renderHook(() =>
      useFetchInterface({
        interfaceCd: "testCd",
        interfaceId: "testId",
        validate: mockValidate,
        setValue2: mockSetValue2,
      }),
    )

    await act(async () => {
      await result.current.fetchInterfaceDataToBox({ type: "click" })
    })

    expect(mockValidate).toHaveBeenCalled()
    expect(mockUseProxy.mockAsync).toHaveBeenCalledWith({
      interfaceCd: "testCd",
      interfaceId: "testId",
      key: "value",
    })
    expect(mockSetValue2).toHaveBeenCalledWith("field1", "value1")
    expect(mockSetValue2).toHaveBeenCalledWith("field2", "value2")
  })

  it("should handle case when setGridData, setGridCount, and setValue2 are undefined", async () => {
    const { result } = renderHook(() =>
      useFetchInterface({
        interfaceCd: "testCd",
        interfaceId: "testId",
        validate: mockValidate,
      }),
    )

    await act(async () => {
      await result.current.fetchInterfaceDataSetGrid({ type: "click" })
    })

    await act(async () => {
      await result.current.fetchInterfaceDataToBox({ type: "click" })
    })

    expect(mockValidate).toHaveBeenCalled()
    expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
  })
})
