package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금음공동망 거래 정상분
 * <pre>{@code
 * KftHofEL0011R kftHofEL0011R  = new KftHofEL0011R(); // 전자금음공동망 거래 정상분
 * kftHofEL0011R.setFileName(""); // 업무구분
 * kftHofEL0011R.setDataType(""); // 데이타구분
 * kftHofEL0011R.setSerialNumber(""); // 일련번호
 * kftHofEL0011R.setTransactionIdNumber(""); // 거래고유번호
 * kftHofEL0011R.setTransactionCode(""); // 거래구분코드
 * kftHofEL0011R.setHandlingBankBranchCode(""); // 취급은행지점코드
 * kftHofEL0011R.setBeneficiaryBankBranchCode(""); // 개설은행지점코드
 * kftHofEL0011R.setAccountNumber(""); // 계좌번호
 * kftHofEL0011R.setAmount(""); // 금액
 * kftHofEL0011R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0011R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String transactionIdNumber; // 거래고유번호
	private String transactionCode; // 거래구분코드
	private String handlingBankBranchCode; // 취급은행지점코드
	private String beneficiaryBankBranchCode; // 개설은행지점코드
	private String accountNumber; // 계좌번호
	private String amount; // 금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingBankBranchCode$; // 취급은행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankBranchCode$; // 개설은행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountNumber$; // 계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String amount$; // 금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		handlingBankBranchCode$ = VOUtils.write(out, handlingBankBranchCode, 7); // 취급은행지점코드
		beneficiaryBankBranchCode$ = VOUtils.write(out, beneficiaryBankBranchCode, 7); // 개설은행지점코드
		accountNumber$ = VOUtils.write(out, accountNumber, 16); // 계좌번호
		amount$ = VOUtils.write(out, amount, 14); // 금액
		filler$ = VOUtils.write(out, filler, 12); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		handlingBankBranchCode = VOUtils.toString(handlingBankBranchCode$ = VOUtils.read(in, 7)); // 취급은행지점코드
		beneficiaryBankBranchCode = VOUtils.toString(beneficiaryBankBranchCode$ = VOUtils.read(in, 7)); // 개설은행지점코드
		accountNumber = VOUtils.toString(accountNumber$ = VOUtils.read(in, 16)); // 계좌번호
		amount = VOUtils.toString(amount$ = VOUtils.read(in, 14)); // 금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 12)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", handlingBankBranchCode=").append(handlingBankBranchCode).append(System.lineSeparator()); // 취급은행지점코드
		sb.append(", beneficiaryBankBranchCode=").append(beneficiaryBankBranchCode).append(System.lineSeparator()); // 개설은행지점코드
		sb.append(", accountNumber=").append(accountNumber).append(System.lineSeparator()); // 계좌번호
		sb.append(", amount=").append(amount).append(System.lineSeparator()); // 금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "handlingBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "beneficiaryBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "accountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "amount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "12", "defltVal", "")
		);
	}

}
