import { Component } from "@/hoc/TestUtil"
import UENTOPS210 from "@/pages/views/ent/UENTOPS-210"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

const component = Component(UENTOPS210)
// 테스트 파일 위쪽
let isDashboard = false
const mockAsync = jest.fn()

jest.mock("@/hooks/useParams", () => ({
  __esModule: true,
  default: () => ({
    params: {
      get isDashboard() {
        return isDashboard
      },
    },
  }),
}))

describe("[UENTOPS-210] 전자어음 내역 조회", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("20240101")
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)

    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("초기화 버튼 클릭 시 initScreen 호출", async () => {
    const { findByText } = render(component)

    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("조회 버튼 클릭 시 fetchInterfaceData 호출", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        outList: [],
        outListLength: 0,
      },
    })

    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("일자 검색 구분 - issue 선택 시 동작 확인", async () => {
    const { getAllByRole, findByText } = render(component)

    // 3. 이제 해당 항목이 DOM에 존재해야 함
    expect(await findByText(/SCRNITM#entMatDt/)).toBeInTheDocument()
  })

  it("일자 검색 구분 - issue 선택 시 동작 확인", async () => {
    const { getByTestId } = render(component)
  
    // 1) API 콜이 끝날 때까지 대기
    await waitFor(() => expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0))
  
    // 2) TestUtil이 붙여준 SelectBox wrapper 찾기
    const selectWrapper = getByTestId("SCRNITM#dateSrchDvsnCd")
  
    // 3) wrapper 내부의 onChange 테스트 버튼 클릭
    const changeBtn = within(selectWrapper).getByTestId("onChange")
    fireEvent.click(changeBtn)
  })
  
  it("EXCEL 버튼 클릭 시 downloadExcel 호출", async () => {
    const mockDownloadExcel = jest.fn()
    jest.mock("@/hooks/useDownloader", () => () => ({
      downloadExcel: mockDownloadExcel,
    }))

    const { findByText } = render(component)
    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)
  })

  it("더블클릭 시 UENTOPS-215로 이동", async () => {
    const mockOpenMenu = jest.fn()
    jest.mock("@/hooks/useMenu", () => () => ({
      openMenuByScrnId: mockOpenMenu,
    }))

    const { container } = render(component)
    const row = container.querySelector(".ag-row") // Grid 내부의 첫 row
    if (row) {
      fireEvent.doubleClick(row)
      expect(mockOpenMenu).toHaveBeenCalledWith(
        "UENTOPS-215",
        expect.anything(),
      )
    }
  })
})
