package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보 등록 변경 해지 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 전자어음시스템을 구분하기 위해'EBS'사용
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 210000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * processSort 처리구분 
 * corpIndvSort 법인개인구분 
 * residentBusinessNumber 주민사업자번호 
 * nameRepresentativeName 성명(대표자명) 
 * corpName 법인명 
 * address 주소 
 * phoneNumber 전화번호 
 * mobilePhoneNumber 핸드폰번호 
 * emailAddress 이메일주소 
 * paymentBranchClearingHouseCode 지급점포교환소코드 
 * paymentRegisterRequestBankCode 지급(등록의뢰)은행코드 
 * paymentRegisterRequestBankBranchCode 지급(등록의뢰)은행지점코드 
 * eNoteCurrentTransactionStartEndDate 전자어음당좌거래개시(해지)일자 
 * currentAccountNumber 당좌계좌번호 
 * companySize 기업규모 
 * industryCode 업종코드 
 * limitAmount 한도금액 
 * depositAccountNumber 입금계좌번호 
 * memberSort 회원구분 
 * afterChangeCurrentAccountNumber 변경후당좌계좌번호 
 * afterChangeDepositAccountNumber 변경후입금계좌번호 
 * 
 * KftEnt0200210000 kftEnt0200210000 = new KftEnt0200210000(); // 회원정보 등록 변경 해지 요청
 * kftEnt0200210000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200210000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200210000.setBnkCd("057"); // 은행코드
 * kftEnt0200210000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200210000.setTransactionCode("210000"); // 거래구분코드
 * kftEnt0200210000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200210000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200210000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200210000.setStatus("000"); // STATUS
 * kftEnt0200210000.setResponseCode1("   "); // 응답코드1
 * kftEnt0200210000.setResponseCode2(""); // 응답코드2
 * kftEnt0200210000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200210000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200210000.setProcessSort(""); // 처리구분
 * kftEnt0200210000.setCorpIndvSort(""); // 법인개인구분
 * kftEnt0200210000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200210000.setNameRepresentativeName(""); // 성명(대표자명)
 * kftEnt0200210000.setCorpName(""); // 법인명
 * kftEnt0200210000.setAddress(""); // 주소
 * kftEnt0200210000.setPhoneNumber(""); // 전화번호
 * kftEnt0200210000.setMobilePhoneNumber(""); // 핸드폰번호
 * kftEnt0200210000.setEmailAddress(""); // 이메일주소
 * kftEnt0200210000.setPaymentBranchClearingHouseCode(""); // 지급점포교환소코드
 * kftEnt0200210000.setPaymentRegisterRequestBankCode(""); // 지급(등록의뢰)은행코드
 * kftEnt0200210000.setPaymentRegisterRequestBankBranchCode(""); // 지급(등록의뢰)은행지점코드
 * kftEnt0200210000.setENoteCurrentTransactionStartEndDate(""); // 전자어음당좌거래개시(해지)일자
 * kftEnt0200210000.setCurrentAccountNumber(""); // 당좌계좌번호
 * kftEnt0200210000.setCompanySize(""); // 기업규모
 * kftEnt0200210000.setIndustryCode(""); // 업종코드
 * kftEnt0200210000.setLimitAmount(0L); // 한도금액
 * kftEnt0200210000.setDepositAccountNumber(""); // 입금계좌번호
 * kftEnt0200210000.setMemberSort(""); // 회원구분
 * kftEnt0200210000.setAfterChangeCurrentAccountNumber(""); // 변경후당좌계좌번호
 * kftEnt0200210000.setAfterChangeDepositAccountNumber(""); // 변경후입금계좌번호
 * }</pre>
 */
@Data
public class KftEnt0200210000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "210000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String processSort; // 처리구분
	private String corpIndvSort; // 법인개인구분
	private String residentBusinessNumber; // 주민사업자번호
	private String nameRepresentativeName; // 성명(대표자명)
	private String corpName; // 법인명
	private String address; // 주소
	private String phoneNumber; // 전화번호
	private String mobilePhoneNumber; // 핸드폰번호
	private String emailAddress; // 이메일주소
	private String paymentBranchClearingHouseCode; // 지급점포교환소코드
	private String paymentRegisterRequestBankCode; // 지급(등록의뢰)은행코드
	private String paymentRegisterRequestBankBranchCode; // 지급(등록의뢰)은행지점코드
	private String eNoteCurrentTransactionStartEndDate; // 전자어음당좌거래개시(해지)일자
	private String currentAccountNumber; // 당좌계좌번호
	private String companySize; // 기업규모
	private String industryCode; // 업종코드
	private long limitAmount; // 한도금액
	private String depositAccountNumber; // 입금계좌번호
	private String memberSort; // 회원구분
	private String afterChangeCurrentAccountNumber; // 변경후당좌계좌번호
	private String afterChangeDepositAccountNumber; // 변경후입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processSort$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpIndvSort$; // 법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nameRepresentativeName$; // 성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpName$; // 법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String address$; // 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mobilePhoneNumber$; // 핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String emailAddress$; // 이메일주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentRegisterRequestBankCode$; // 지급(등록의뢰)은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentRegisterRequestBankBranchCode$; // 지급(등록의뢰)은행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteCurrentTransactionStartEndDate$; // 전자어음당좌거래개시(해지)일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentAccountNumber$; // 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String companySize$; // 기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String industryCode$; // 업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String limitAmount$; // 한도금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String memberSort$; // 회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeCurrentAccountNumber$; // 변경후당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDepositAccountNumber$; // 변경후입금계좌번호

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(paymentRegisterRequestBankBranchCode$)) { // 지급(등록의뢰)은행지점코드
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(industryCode$)) { // 업종코드
			return 28;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 30;
		}
		if (VOUtils.isNotAlphanumericSpace(memberSort$)) { // 회원구분
			return 31;
		}
		if (VOUtils.isNotAlphanumericSpace(afterChangeCurrentAccountNumber$)) { // 변경후당좌계좌번호
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(afterChangeDepositAccountNumber$)) { // 변경후입금계좌번호
			return 33;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		processSort$ = VOUtils.write(out, processSort, 2); // 처리구분
		corpIndvSort$ = VOUtils.write(out, corpIndvSort, 1); // 법인개인구분
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		nameRepresentativeName$ = VOUtils.write(out, nameRepresentativeName, 20, "EUC-KR"); // 성명(대표자명)
		corpName$ = VOUtils.write(out, corpName, 40, "EUC-KR"); // 법인명
		address$ = VOUtils.write(out, address, 60, "EUC-KR"); // 주소
		phoneNumber$ = VOUtils.write(out, phoneNumber, 14); // 전화번호
		mobilePhoneNumber$ = VOUtils.write(out, mobilePhoneNumber, 14); // 핸드폰번호
		emailAddress$ = VOUtils.write(out, emailAddress, 40); // 이메일주소
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포교환소코드
		paymentRegisterRequestBankCode$ = VOUtils.write(out, paymentRegisterRequestBankCode, 3); // 지급(등록의뢰)은행코드
		paymentRegisterRequestBankBranchCode$ = VOUtils.write(out, paymentRegisterRequestBankBranchCode, 4); // 지급(등록의뢰)은행지점코드
		eNoteCurrentTransactionStartEndDate$ = VOUtils.write(out, eNoteCurrentTransactionStartEndDate, 8); // 전자어음당좌거래개시(해지)일자
		currentAccountNumber$ = VOUtils.write(out, currentAccountNumber, 16); // 당좌계좌번호
		companySize$ = VOUtils.write(out, companySize, 1); // 기업규모
		industryCode$ = VOUtils.write(out, industryCode, 2); // 업종코드
		limitAmount$ = VOUtils.write(out, limitAmount, 15); // 한도금액
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		memberSort$ = VOUtils.write(out, memberSort, 1); // 회원구분
		afterChangeCurrentAccountNumber$ = VOUtils.write(out, afterChangeCurrentAccountNumber, 16); // 변경후당좌계좌번호
		afterChangeDepositAccountNumber$ = VOUtils.write(out, afterChangeDepositAccountNumber, 16); // 변경후입금계좌번호
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		processSort = VOUtils.toString(processSort$ = VOUtils.read(in, 2)); // 처리구분
		corpIndvSort = VOUtils.toString(corpIndvSort$ = VOUtils.read(in, 1)); // 법인개인구분
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		nameRepresentativeName = VOUtils.toString(nameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 성명(대표자명)
		corpName = VOUtils.toString(corpName$ = VOUtils.read(in, 40, "EUC-KR")); // 법인명
		address = VOUtils.toString(address$ = VOUtils.read(in, 60, "EUC-KR")); // 주소
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 14)); // 전화번호
		mobilePhoneNumber = VOUtils.toString(mobilePhoneNumber$ = VOUtils.read(in, 14)); // 핸드폰번호
		emailAddress = VOUtils.toString(emailAddress$ = VOUtils.read(in, 40)); // 이메일주소
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포교환소코드
		paymentRegisterRequestBankCode = VOUtils.toString(paymentRegisterRequestBankCode$ = VOUtils.read(in, 3)); // 지급(등록의뢰)은행코드
		paymentRegisterRequestBankBranchCode = VOUtils.toString(paymentRegisterRequestBankBranchCode$ = VOUtils.read(in, 4)); // 지급(등록의뢰)은행지점코드
		eNoteCurrentTransactionStartEndDate = VOUtils.toString(eNoteCurrentTransactionStartEndDate$ = VOUtils.read(in, 8)); // 전자어음당좌거래개시(해지)일자
		currentAccountNumber = VOUtils.toString(currentAccountNumber$ = VOUtils.read(in, 16)); // 당좌계좌번호
		companySize = VOUtils.toString(companySize$ = VOUtils.read(in, 1)); // 기업규모
		industryCode = VOUtils.toString(industryCode$ = VOUtils.read(in, 2)); // 업종코드
		limitAmount = VOUtils.toLong(limitAmount$ = VOUtils.read(in, 15)); // 한도금액
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		memberSort = VOUtils.toString(memberSort$ = VOUtils.read(in, 1)); // 회원구분
		afterChangeCurrentAccountNumber = VOUtils.toString(afterChangeCurrentAccountNumber$ = VOUtils.read(in, 16)); // 변경후당좌계좌번호
		afterChangeDepositAccountNumber = VOUtils.toString(afterChangeDepositAccountNumber$ = VOUtils.read(in, 16)); // 변경후입금계좌번호
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", processSort=").append(processSort).append(System.lineSeparator()); // 처리구분
		sb.append(", corpIndvSort=").append(corpIndvSort).append(System.lineSeparator()); // 법인개인구분
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", nameRepresentativeName=").append(nameRepresentativeName).append(System.lineSeparator()); // 성명(대표자명)
		sb.append(", corpName=").append(corpName).append(System.lineSeparator()); // 법인명
		sb.append(", address=").append(address).append(System.lineSeparator()); // 주소
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호
		sb.append(", mobilePhoneNumber=").append(mobilePhoneNumber).append(System.lineSeparator()); // 핸드폰번호
		sb.append(", emailAddress=").append(emailAddress).append(System.lineSeparator()); // 이메일주소
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포교환소코드
		sb.append(", paymentRegisterRequestBankCode=").append(paymentRegisterRequestBankCode).append(System.lineSeparator()); // 지급(등록의뢰)은행코드
		sb.append(", paymentRegisterRequestBankBranchCode=").append(paymentRegisterRequestBankBranchCode).append(System.lineSeparator()); // 지급(등록의뢰)은행지점코드
		sb.append(", eNoteCurrentTransactionStartEndDate=").append(eNoteCurrentTransactionStartEndDate).append(System.lineSeparator()); // 전자어음당좌거래개시(해지)일자
		sb.append(", currentAccountNumber=").append(currentAccountNumber).append(System.lineSeparator()); // 당좌계좌번호
		sb.append(", companySize=").append(companySize).append(System.lineSeparator()); // 기업규모
		sb.append(", industryCode=").append(industryCode).append(System.lineSeparator()); // 업종코드
		sb.append(", limitAmount=").append(limitAmount).append(System.lineSeparator()); // 한도금액
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", memberSort=").append(memberSort).append(System.lineSeparator()); // 회원구분
		sb.append(", afterChangeCurrentAccountNumber=").append(afterChangeCurrentAccountNumber).append(System.lineSeparator()); // 변경후당좌계좌번호
		sb.append(", afterChangeDepositAccountNumber=").append(afterChangeDepositAccountNumber).append(System.lineSeparator()); // 변경후입금계좌번호
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "210000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "processSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "corpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "nameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "corpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "address", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "mobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "emailAddress", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "paymentRegisterRequestBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "paymentRegisterRequestBankBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "eNoteCurrentTransactionStartEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "currentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "companySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "industryCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "limitAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "memberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "afterChangeDepositAccountNumber", "fldLen", "16", "defltVal", "")
		);
	}

}
