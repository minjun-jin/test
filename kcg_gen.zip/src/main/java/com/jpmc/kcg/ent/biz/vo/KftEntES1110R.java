package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보
 * <pre>{@code
 * KftEntES1110R kftEntES1110R  = new KftEntES1110R(); // 회원정보
 * kftEntES1110R.setFileName(""); // 업무구분
 * kftEntES1110R.setDataType(""); // 데이터구분
 * kftEntES1110R.setSerialNumber(""); // 일련번호
 * kftEntES1110R.setProcessingCode(""); // 처리구분
 * kftEntES1110R.setCorpIndvSort(""); // 법인개인구분
 * kftEntES1110R.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEntES1110R.setNameRepresentativeName(""); // 성명(대표자명)
 * kftEntES1110R.setCorpName(""); // 법인명
 * kftEntES1110R.setAddress(""); // 주소
 * kftEntES1110R.setPhoneNumber(""); // 전화번호
 * kftEntES1110R.setMobilePhoneNumber(""); // 핸드폰 번호
 * kftEntES1110R.setEmailAddress(""); // 이메일 주소
 * kftEntES1110R.setPaymentBranchClearingHouseCode(""); // 지급점포교환소코드
 * kftEntES1110R.setPaymentRegisterRequestBankBranchCode(""); // 지급(등록의뢰) 은행 및 지점코드
 * kftEntES1110R.setENoteCurrentTransactionStartEndDate(""); // 전자어음 당좌거래 개시(해지) 일자
 * kftEntES1110R.setCurrentAccountNumber(""); // 당좌계좌번호
 * kftEntES1110R.setCompanySize(""); // 기업규모
 * kftEntES1110R.setIndustryCode(""); // 업종코드
 * kftEntES1110R.setLimitAmount(0L); // 한도금액
 * kftEntES1110R.setDepositAccountNumber(""); // 입금계좌번호
 * kftEntES1110R.setMemberSort(""); // 회원구분
 * kftEntES1110R.setAfterChangeCurrentAccountNumber(""); // 변경 후 당좌계좌번호
 * kftEntES1110R.setAfterChangeDepositAccountNumber(""); // 변경후 입금계좌번호
 * kftEntES1110R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1110R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String processingCode; // 처리구분
	private String corpIndvSort; // 법인개인구분
	private String residentBusinessNumber; // 주민사업자번호
	private String nameRepresentativeName; // 성명(대표자명)
	private String corpName; // 법인명
	private String address; // 주소
	private String phoneNumber; // 전화번호
	private String mobilePhoneNumber; // 핸드폰 번호
	private String emailAddress; // 이메일 주소
	private String paymentBranchClearingHouseCode; // 지급점포교환소코드
	private String paymentRegisterRequestBankBranchCode; // 지급(등록의뢰) 은행 및 지점코드
	private String eNoteCurrentTransactionStartEndDate; // 전자어음 당좌거래 개시(해지) 일자
	private String currentAccountNumber; // 당좌계좌번호
	private String companySize; // 기업규모
	private String industryCode; // 업종코드
	private long limitAmount; // 한도금액
	private String depositAccountNumber; // 입금계좌번호
	private String memberSort; // 회원구분
	private String afterChangeCurrentAccountNumber; // 변경 후 당좌계좌번호
	private String afterChangeDepositAccountNumber; // 변경후 입금계좌번호
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingCode$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpIndvSort$; // 법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nameRepresentativeName$; // 성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpName$; // 법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String address$; // 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mobilePhoneNumber$; // 핸드폰 번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String emailAddress$; // 이메일 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentRegisterRequestBankBranchCode$; // 지급(등록의뢰) 은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteCurrentTransactionStartEndDate$; // 전자어음 당좌거래 개시(해지) 일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentAccountNumber$; // 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String companySize$; // 기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String industryCode$; // 업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String limitAmount$; // 한도금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String memberSort$; // 회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeCurrentAccountNumber$; // 변경 후 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDepositAccountNumber$; // 변경후 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		processingCode$ = VOUtils.write(out, processingCode, 2); // 처리구분
		corpIndvSort$ = VOUtils.write(out, corpIndvSort, 1); // 법인개인구분
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		nameRepresentativeName$ = VOUtils.write(out, nameRepresentativeName, 20, "EUC-KR"); // 성명(대표자명)
		corpName$ = VOUtils.write(out, corpName, 40, "EUC-KR"); // 법인명
		address$ = VOUtils.write(out, address, 60, "EUC-KR"); // 주소
		phoneNumber$ = VOUtils.write(out, phoneNumber, 14); // 전화번호
		mobilePhoneNumber$ = VOUtils.write(out, mobilePhoneNumber, 14); // 핸드폰 번호
		emailAddress$ = VOUtils.write(out, emailAddress, 40); // 이메일 주소
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포교환소코드
		paymentRegisterRequestBankBranchCode$ = VOUtils.write(out, paymentRegisterRequestBankBranchCode, 7); // 지급(등록의뢰) 은행 및 지점코드
		eNoteCurrentTransactionStartEndDate$ = VOUtils.write(out, eNoteCurrentTransactionStartEndDate, 8); // 전자어음 당좌거래 개시(해지) 일자
		currentAccountNumber$ = VOUtils.write(out, currentAccountNumber, 16); // 당좌계좌번호
		companySize$ = VOUtils.write(out, companySize, 1); // 기업규모
		industryCode$ = VOUtils.write(out, industryCode, 2); // 업종코드
		limitAmount$ = VOUtils.write(out, limitAmount, 15); // 한도금액
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		memberSort$ = VOUtils.write(out, memberSort, 1); // 회원구분
		afterChangeCurrentAccountNumber$ = VOUtils.write(out, afterChangeCurrentAccountNumber, 16); // 변경 후 당좌계좌번호
		afterChangeDepositAccountNumber$ = VOUtils.write(out, afterChangeDepositAccountNumber, 16); // 변경후 입금계좌번호
		filler2$ = VOUtils.write(out, filler2, 31); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		processingCode = VOUtils.toString(processingCode$ = VOUtils.read(in, 2)); // 처리구분
		corpIndvSort = VOUtils.toString(corpIndvSort$ = VOUtils.read(in, 1)); // 법인개인구분
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		nameRepresentativeName = VOUtils.toString(nameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 성명(대표자명)
		corpName = VOUtils.toString(corpName$ = VOUtils.read(in, 40, "EUC-KR")); // 법인명
		address = VOUtils.toString(address$ = VOUtils.read(in, 60, "EUC-KR")); // 주소
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 14)); // 전화번호
		mobilePhoneNumber = VOUtils.toString(mobilePhoneNumber$ = VOUtils.read(in, 14)); // 핸드폰 번호
		emailAddress = VOUtils.toString(emailAddress$ = VOUtils.read(in, 40)); // 이메일 주소
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포교환소코드
		paymentRegisterRequestBankBranchCode = VOUtils.toString(paymentRegisterRequestBankBranchCode$ = VOUtils.read(in, 7)); // 지급(등록의뢰) 은행 및 지점코드
		eNoteCurrentTransactionStartEndDate = VOUtils.toString(eNoteCurrentTransactionStartEndDate$ = VOUtils.read(in, 8)); // 전자어음 당좌거래 개시(해지) 일자
		currentAccountNumber = VOUtils.toString(currentAccountNumber$ = VOUtils.read(in, 16)); // 당좌계좌번호
		companySize = VOUtils.toString(companySize$ = VOUtils.read(in, 1)); // 기업규모
		industryCode = VOUtils.toString(industryCode$ = VOUtils.read(in, 2)); // 업종코드
		limitAmount = VOUtils.toLong(limitAmount$ = VOUtils.read(in, 15)); // 한도금액
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		memberSort = VOUtils.toString(memberSort$ = VOUtils.read(in, 1)); // 회원구분
		afterChangeCurrentAccountNumber = VOUtils.toString(afterChangeCurrentAccountNumber$ = VOUtils.read(in, 16)); // 변경 후 당좌계좌번호
		afterChangeDepositAccountNumber = VOUtils.toString(afterChangeDepositAccountNumber$ = VOUtils.read(in, 16)); // 변경후 입금계좌번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 31)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", processingCode=").append(processingCode).append(System.lineSeparator()); // 처리구분
		sb.append(", corpIndvSort=").append(corpIndvSort).append(System.lineSeparator()); // 법인개인구분
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", nameRepresentativeName=").append(nameRepresentativeName).append(System.lineSeparator()); // 성명(대표자명)
		sb.append(", corpName=").append(corpName).append(System.lineSeparator()); // 법인명
		sb.append(", address=").append(address).append(System.lineSeparator()); // 주소
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호
		sb.append(", mobilePhoneNumber=").append(mobilePhoneNumber).append(System.lineSeparator()); // 핸드폰 번호
		sb.append(", emailAddress=").append(emailAddress).append(System.lineSeparator()); // 이메일 주소
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포교환소코드
		sb.append(", paymentRegisterRequestBankBranchCode=").append(paymentRegisterRequestBankBranchCode).append(System.lineSeparator()); // 지급(등록의뢰) 은행 및 지점코드
		sb.append(", eNoteCurrentTransactionStartEndDate=").append(eNoteCurrentTransactionStartEndDate).append(System.lineSeparator()); // 전자어음 당좌거래 개시(해지) 일자
		sb.append(", currentAccountNumber=").append(currentAccountNumber).append(System.lineSeparator()); // 당좌계좌번호
		sb.append(", companySize=").append(companySize).append(System.lineSeparator()); // 기업규모
		sb.append(", industryCode=").append(industryCode).append(System.lineSeparator()); // 업종코드
		sb.append(", limitAmount=").append(limitAmount).append(System.lineSeparator()); // 한도금액
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", memberSort=").append(memberSort).append(System.lineSeparator()); // 회원구분
		sb.append(", afterChangeCurrentAccountNumber=").append(afterChangeCurrentAccountNumber).append(System.lineSeparator()); // 변경 후 당좌계좌번호
		sb.append(", afterChangeDepositAccountNumber=").append(afterChangeDepositAccountNumber).append(System.lineSeparator()); // 변경후 입금계좌번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "processingCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "corpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "nameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "corpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "address", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "mobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "emailAddress", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "paymentRegisterRequestBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "eNoteCurrentTransactionStartEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "currentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "companySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "industryCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "limitAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "memberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "afterChangeDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "31", "defltVal", "")
		);
	}

}
