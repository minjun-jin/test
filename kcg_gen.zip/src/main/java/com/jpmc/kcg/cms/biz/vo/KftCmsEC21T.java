package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (당일)출금의뢰내역
 * <pre>{@code
 * KftCmsEC21T kftCmsEC21T  = new KftCmsEC21T(); // (당일)출금의뢰내역
 * kftCmsEC21T.setRecordType(""); // Record 구분
 * kftCmsEC21T.setSerialNumber(""); // 일련번호
 * kftCmsEC21T.setInstitutionCode(""); // 기관코드
 * kftCmsEC21T.setFileName(""); // File 이름
 * kftCmsEC21T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEC21T.setRequestedWithdrawalCount(0); // 출금의뢰건수
 * kftCmsEC21T.setRequestedWithdrawalAmount(0L); // 출금의뢰금액
 * kftCmsEC21T.setPartialWithdrawalCount(0); // 부분출금건수
 * kftCmsEC21T.setPartialWithdrawalAmount(0L); // 부분출금금액
 * kftCmsEC21T.setTotalFee(0L); // 총수수료
 * kftCmsEC21T.setWithdrawalBankFee(0L); // 출금은행수수료
 * kftCmsEC21T.setDepositBankFee(0L); // 입금은행수수료
 * kftCmsEC21T.setFiller3(""); // FILLER
 * kftCmsEC21T.setMacValue(""); // MAC 검증값
 * }</pre>
 */
@Data
public class KftCmsEC21T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int requestedWithdrawalCount; // 출금의뢰건수
	private long requestedWithdrawalAmount; // 출금의뢰금액
	private int partialWithdrawalCount; // 부분출금건수
	private long partialWithdrawalAmount; // 부분출금금액
	private long totalFee; // 총수수료
	private long withdrawalBankFee; // 출금은행수수료
	private long depositBankFee; // 입금은행수수료
	private String filler3; // FILLER
	private String macValue; // MAC 검증값
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalCount$; // 출금의뢰건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalAmount$; // 출금의뢰금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String partialWithdrawalCount$; // 부분출금건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String partialWithdrawalAmount$; // 부분출금금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFee$; // 총수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalBankFee$; // 출금은행수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositBankFee$; // 입금은행수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		requestedWithdrawalCount$ = VOUtils.write(out, requestedWithdrawalCount, 8); // 출금의뢰건수
		requestedWithdrawalAmount$ = VOUtils.write(out, requestedWithdrawalAmount, 13); // 출금의뢰금액
		partialWithdrawalCount$ = VOUtils.write(out, partialWithdrawalCount, 8); // 부분출금건수
		partialWithdrawalAmount$ = VOUtils.write(out, partialWithdrawalAmount, 13); // 부분출금금액
		totalFee$ = VOUtils.write(out, totalFee, 11); // 총수수료
		withdrawalBankFee$ = VOUtils.write(out, withdrawalBankFee, 11); // 출금은행수수료
		depositBankFee$ = VOUtils.write(out, depositBankFee, 11); // 입금은행수수료
		filler3$ = VOUtils.write(out, filler3, 30); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		requestedWithdrawalCount = VOUtils.toInt(requestedWithdrawalCount$ = VOUtils.read(in, 8)); // 출금의뢰건수
		requestedWithdrawalAmount = VOUtils.toLong(requestedWithdrawalAmount$ = VOUtils.read(in, 13)); // 출금의뢰금액
		partialWithdrawalCount = VOUtils.toInt(partialWithdrawalCount$ = VOUtils.read(in, 8)); // 부분출금건수
		partialWithdrawalAmount = VOUtils.toLong(partialWithdrawalAmount$ = VOUtils.read(in, 13)); // 부분출금금액
		totalFee = VOUtils.toLong(totalFee$ = VOUtils.read(in, 11)); // 총수수료
		withdrawalBankFee = VOUtils.toLong(withdrawalBankFee$ = VOUtils.read(in, 11)); // 출금은행수수료
		depositBankFee = VOUtils.toLong(depositBankFee$ = VOUtils.read(in, 11)); // 입금은행수수료
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 30)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", requestedWithdrawalCount=").append(requestedWithdrawalCount).append(System.lineSeparator()); // 출금의뢰건수
		sb.append(", requestedWithdrawalAmount=").append(requestedWithdrawalAmount).append(System.lineSeparator()); // 출금의뢰금액
		sb.append(", partialWithdrawalCount=").append(partialWithdrawalCount).append(System.lineSeparator()); // 부분출금건수
		sb.append(", partialWithdrawalAmount=").append(partialWithdrawalAmount).append(System.lineSeparator()); // 부분출금금액
		sb.append(", totalFee=").append(totalFee).append(System.lineSeparator()); // 총수수료
		sb.append(", withdrawalBankFee=").append(withdrawalBankFee).append(System.lineSeparator()); // 출금은행수수료
		sb.append(", depositBankFee=").append(depositBankFee).append(System.lineSeparator()); // 입금은행수수료
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "partialWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "partialWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "totalFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "withdrawalBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "depositBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
