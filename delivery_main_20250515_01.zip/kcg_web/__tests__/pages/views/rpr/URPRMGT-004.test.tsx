import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// URPRMGT004 컴포넌트를 불러옵니다.
import URPRMGT004 from "@/pages/views/rpr/URPRMGT-004"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(URPRMGT004)

describe("[URPRMGT-004] 자금반환관리", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("19900101")
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])
  })

  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("valueGetter Test", async () => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: null,
          rqstRtnDvsnCd: "01",
        },
      },
    })

    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: "01",
        },
      },
    })
  })

  it("rowClassRules Test", async () => {
    const { findByText } = render(component)

    const rowClassRulesTestBtn = await findByText(/rowClassRules Test/)
    fireEvent.click(rowClassRulesTestBtn, {
      target: { data: { data: { aprvStsCd: "01" } } },
    })
  })

  it("onRowClicked Test", async () => {
    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          rqstRtnDvsnCd: "01",
        },
      },
    })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })

  it("onRowDoubleClicked Test - aprvStsCd is 01", async () => {
    const { findByText } = render(component)

    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: "01" } },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 02", async () => {
    const { findByText } = render(component)

    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: "02" } },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is null", async () => {
    const { findByText } = render(component)

    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: null } },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
    })
  })

  it.each(["Y", "N", "05", "99", "51"])("onChange Test", async (flag) => {
    const { findAllByTestId, findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          kftcBizDvsnCd: "03",
          trStsCd: "12",
          rtnRsn: "05",
        },
      },
    })
    const onChangeTestBtns = await findAllByTestId("onChange")
    onChangeTestBtns.forEach((onChangeTestBtn) => {
      fireEvent.click(onChangeTestBtn, { target: { data: flag } })
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchData Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("createFundRetrun Test", async () => {
    mockUseForm.mockValidate.mockResolvedValueOnce({
      outinDvsnCd: "08 08",
    })
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {},
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
        },
      })
    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          kftcBizDvsnCd: "03",
          trStsCd: "12",
        },
      },
    })

    const regBtn = await findByText(/SCRNITM#reg/)
    fireEvent.click(regBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("validate Test", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(1).mockReturnValueOnce(0)
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(validateTestBtn, { target: { data: {} } })
  })
})
