package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 입금의뢰내역
 * <pre>{@code
 * KftCmsEB31R kftCmsEB31R  = new KftCmsEB31R(); // 입금의뢰내역
 * kftCmsEB31R.setRecordType(""); // Record 구분
 * kftCmsEB31R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB31R.setInstitutionCode(""); // 기관코드
 * kftCmsEB31R.setDepositBankBranchCode(""); // 입금은행점코드
 * kftCmsEB31R.setDepositAccountNumber(""); // 입금계좌번호
 * kftCmsEB31R.setDepositAmount(0L); // 입금액
 * kftCmsEB31R.setAccountHolderResidentBusinessNumber(""); // 예금주 생년월일 또는 사업자등록번호
 * kftCmsEB31R.setDepositResultDepositYn(""); // 입금결과 입금여부
 * kftCmsEB31R.setDepositResultFailedCode(""); // 입금결과 불능코드
 * kftCmsEB31R.setPassbookEntryDetails(""); // 통장기재내용
 * kftCmsEB31R.setFundType(""); // 자금종류
 * kftCmsEB31R.setInstitutionUseArea(""); // 이용기관사용영역
 * kftCmsEB31R.setCheckResidentBusinessNumberYn(""); // 생년월일(사업자등록번호) Check 여부
 * kftCmsEB31R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB31R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String depositBankBranchCode; // 입금은행점코드
	private String depositAccountNumber; // 입금계좌번호
	private long depositAmount; // 입금액
	private String accountHolderResidentBusinessNumber; // 예금주 생년월일 또는 사업자등록번호
	private String depositResultDepositYn; // 입금결과 입금여부
	private String depositResultFailedCode; // 입금결과 불능코드
	private String passbookEntryDetails; // 통장기재내용
	private String fundType; // 자금종류
	private String institutionUseArea; // 이용기관사용영역
	private String checkResidentBusinessNumberYn; // 생년월일(사업자등록번호) Check 여부
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositBankBranchCode$; // 입금은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAmount$; // 입금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderResidentBusinessNumber$; // 예금주 생년월일 또는 사업자등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositResultDepositYn$; // 입금결과 입금여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositResultFailedCode$; // 입금결과 불능코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String passbookEntryDetails$; // 통장기재내용
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionUseArea$; // 이용기관사용영역
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String checkResidentBusinessNumberYn$; // 생년월일(사업자등록번호) Check 여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		depositBankBranchCode$ = VOUtils.write(out, depositBankBranchCode, 7); // 입금은행점코드
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		depositAmount$ = VOUtils.write(out, depositAmount, 13); // 입금액
		accountHolderResidentBusinessNumber$ = VOUtils.write(out, accountHolderResidentBusinessNumber, 13); // 예금주 생년월일 또는 사업자등록번호
		depositResultDepositYn$ = VOUtils.write(out, depositResultDepositYn, 1); // 입금결과 입금여부
		depositResultFailedCode$ = VOUtils.write(out, depositResultFailedCode, 4); // 입금결과 불능코드
		passbookEntryDetails$ = VOUtils.write(out, passbookEntryDetails, 16, "EUC-KR"); // 통장기재내용
		fundType$ = VOUtils.write(out, fundType, 2); // 자금종류
		institutionUseArea$ = VOUtils.write(out, institutionUseArea, 25); // 이용기관사용영역
		checkResidentBusinessNumberYn$ = VOUtils.write(out, checkResidentBusinessNumberYn, 1); // 생년월일(사업자등록번호) Check 여부
		filler2$ = VOUtils.write(out, filler2, 33); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		depositBankBranchCode = VOUtils.toString(depositBankBranchCode$ = VOUtils.read(in, 7)); // 입금은행점코드
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		depositAmount = VOUtils.toLong(depositAmount$ = VOUtils.read(in, 13)); // 입금액
		accountHolderResidentBusinessNumber = VOUtils.toString(accountHolderResidentBusinessNumber$ = VOUtils.read(in, 13)); // 예금주 생년월일 또는 사업자등록번호
		depositResultDepositYn = VOUtils.toString(depositResultDepositYn$ = VOUtils.read(in, 1)); // 입금결과 입금여부
		depositResultFailedCode = VOUtils.toString(depositResultFailedCode$ = VOUtils.read(in, 4)); // 입금결과 불능코드
		passbookEntryDetails = VOUtils.toString(passbookEntryDetails$ = VOUtils.read(in, 16, "EUC-KR")); // 통장기재내용
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금종류
		institutionUseArea = VOUtils.toString(institutionUseArea$ = VOUtils.read(in, 25)); // 이용기관사용영역
		checkResidentBusinessNumberYn = VOUtils.toString(checkResidentBusinessNumberYn$ = VOUtils.read(in, 1)); // 생년월일(사업자등록번호) Check 여부
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 33)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", depositBankBranchCode=").append(depositBankBranchCode).append(System.lineSeparator()); // 입금은행점코드
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", depositAmount=").append(depositAmount).append(System.lineSeparator()); // 입금액
		sb.append(", accountHolderResidentBusinessNumber=").append(accountHolderResidentBusinessNumber).append(System.lineSeparator()); // 예금주 생년월일 또는 사업자등록번호
		sb.append(", depositResultDepositYn=").append(depositResultDepositYn).append(System.lineSeparator()); // 입금결과 입금여부
		sb.append(", depositResultFailedCode=").append(depositResultFailedCode).append(System.lineSeparator()); // 입금결과 불능코드
		sb.append(", passbookEntryDetails=").append(passbookEntryDetails).append(System.lineSeparator()); // 통장기재내용
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금종류
		sb.append(", institutionUseArea=").append(institutionUseArea).append(System.lineSeparator()); // 이용기관사용영역
		sb.append(", checkResidentBusinessNumberYn=").append(checkResidentBusinessNumberYn).append(System.lineSeparator()); // 생년월일(사업자등록번호) Check 여부
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "depositBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "depositAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accountHolderResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "depositResultDepositYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "depositResultFailedCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "passbookEntryDetails", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "institutionUseArea", "fldLen", "25", "defltVal", ""),
			Map.of("fld", "checkResidentBusinessNumberYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "33", "defltVal", "")
		);
	}

}
