package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 상환청구인별 상환청구정보 조회 응답 A
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0210
 * messageTrackingNumber 전문추적번호 510000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * userSort 이용자구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * currentCreditAccountNumber 당좌(입금)계좌번호 
 * repaymentClaimantSplitNumber 상환청구인분할번호 
 * noteDetailseNoteNumber 어음내역전자어음번호 
 * noteDetailseNoteType 어음내역어음종류 
 * noteDetailseNoteIssueDate 어음내역전자어음발행일자 
 * noteDetailseNoteIssuePlace 어음내역전자어음발행지 
 * noteDetailseNoteAmount 어음내역전자어음금액 
 * noteDetailseNoteMaturedDate 어음내역전자어음만기일자 
 * noteDetailspaymentBankAndBranchCode 어음내역지급은행및지점코드 
 * noteDetailsEndorsementCount 어음내역배서횟수 
 * recourseClaimdefaultReasonCode 상환청구인부도사유코드 
 * recourseClaimdefaultDate 상환청구인부도일자 
 * repaymentClaimantCorpIndvSortCode 상환청구인법인개인구분코드 
 * repaymentClaimantResidentBusinessNumber 상환청구인주민사업자번호 
 * repaymentClaimantCorpName 상환청구인법인명 
 * repaymentClaimantNameRepresentativeName 상환청구인성명(대표자명) 
 * repaymentClaimantAddress 상환청구인주소 
 * repaymentClaimantBankCode 상환청구인은행코드 
 * repaymentClaimantDepositAccountNumber 상환청구인입금계좌번호 
 * repaymentClaimantSplitNumber1 상환청구인분할번호 
 * repaymentClaimantEndorsementNumber 상환청구인배서번호 
 * totalRecourseClaimInfoCount 총상환청구정보건수 
 * issuerInfoIndvCorpSort 발행인정보-개인법인구분 
 * issuerInfoResidentBusinessNumber 발행인정보-주민사업자번호 
 * issuerInfoCorpName 발행인정보-법인명 
 * issuerInfoNameRepresentative 발행인정보-성명(대표자명) 
 * issuerInfoAddress 발행인정보-주소 
 * issuerInfoCurrentAccountNumber 발행인정보-당좌계좌번호 
 * issuerInfoRecourseClaimPresence 발행인정보-상환청구여부 
 * issuerInfoRecourseClaimDate 발행인정보-상환청구일 
 * issuanceGuarantorInfoIndvCorpSort 발행보증인정보-개인법인구분 
 * issuanceGuarantorInfoResidentBusinessNumber 발행보증인정보-주민사업자번호 
 * issuanceGuarantorInfoCorpName 발행보증인정보-법인명 
 * issuanceGuarantorInfoNameRepresentative 발행보증인정보-성명(대표자명) 
 * issuanceGuarantorInfoAddress 발행보증인정보-주소 
 * issuanceGuarantorInfoBankCode 발행보증인정보-은행코드 
 * issuanceGuarantorInfoDepositAccountNumber 발행보증인정보-입금계좌번호 
 * issuanceGuarantorInfoRecourseClaimPresence 발행보증인정보-상환청구여부 
 * issuanceGuarantorInfoRecourseClaimDate 발행보증인정보-상환청구일 
 * queryResultArray 조회결과Array 
 * queryResultArray.endorsementInfoIndvCorpSort (조회결과)배서정보-개인법인구분 
 * queryResultArray.endorsementInfoResidentBusinessNumber (조회결과)배서정보-주민사업자번호 
 * queryResultArray.endorsementInfoCorpName (조회결과)배서정보-법인명 
 * queryResultArray.endorsementInfoNameRepresentative (조회결과)배서정보-성명(대표자명) 
 * queryResultArray.endorsementInfoBankCode (조회결과)배서정보-은행코드 
 * queryResultArray.endorsementInfoDepositAccountNumber (조회결과)배서정보-입금계좌번호 
 * queryResultArray.endorsementInfoSplitNumber (조회결과)배서정보-분할번호 
 * queryResultArray.endorsementInfoEndorsementNumber (조회결과)배서정보-배서번호 
 * queryResultArray.endorsementInfoEndorsementDate (조회결과)배서정보-배서일자 
 * queryResultArray.endorsementInfoEndorsementAmount (조회결과)배서정보-배서금액 
 * queryResultArray.endorsementInfoNonCollateralEndorsement (조회결과)배서정보-무담보배서여부 
 * queryResultArray.endorsementInfoProhibitedEndorsement (조회결과)배서정보-배서금지배서여부 
 * queryResultArray.endorsementInfoGuaranteeEndorsement (조회결과)배서정보-배서보증여부 
 * queryResultArray.endorsementInfoDefaultNoteReturn (조회결과)배서정보-부도어음반환여부 
 * queryResultArray.endorsementInfoPostmaturedEndorsementPresence (조회결과)배서정보-시한후배서여부 
 * queryResultArray.endorsementInfoRecourseClaimPresence (조회결과)배서정보-상환청구여부 
 * queryResultArray.endorsementInfoRecourseClaimDate (조회결과)배서정보-상환청구일 
 * 
 * KftEnt0210510000 kftEnt0210510000 = new KftEnt0210510000(); // 상환청구인별 상환청구정보 조회 응답 A
 * kftEnt0210510000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210510000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210510000.setBnkCd("057"); // 은행코드
 * kftEnt0210510000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210510000.setTransactionCode("510000"); // 거래구분코드
 * kftEnt0210510000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210510000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210510000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210510000.setStatus("000"); // STATUS
 * kftEnt0210510000.setResponseCode1(""); // 응답코드1
 * kftEnt0210510000.setResponseCode2(""); // 응답코드2
 * kftEnt0210510000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210510000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210510000.setUserSort(""); // 이용자구분
 * kftEnt0210510000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210510000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0210510000.setCurrentCreditAccountNumber(""); // 당좌(입금)계좌번호
 * kftEnt0210510000.setRepaymentClaimantSplitNumber(""); // 상환청구인분할번호
 * kftEnt0210510000.setNoteDetailseNoteNumber(""); // 어음내역전자어음번호
 * kftEnt0210510000.setNoteDetailseNoteType(""); // 어음내역어음종류
 * kftEnt0210510000.setNoteDetailseNoteIssueDate(""); // 어음내역전자어음발행일자
 * kftEnt0210510000.setNoteDetailseNoteIssuePlace(""); // 어음내역전자어음발행지
 * kftEnt0210510000.setNoteDetailseNoteAmount(0L); // 어음내역전자어음금액
 * kftEnt0210510000.setNoteDetailseNoteMaturedDate(""); // 어음내역전자어음만기일자
 * kftEnt0210510000.setNoteDetailspaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * kftEnt0210510000.setNoteDetailsEndorsementCount(0); // 어음내역배서횟수
 * kftEnt0210510000.setRecourseClaimdefaultReasonCode(""); // 상환청구인부도사유코드
 * kftEnt0210510000.setRecourseClaimdefaultDate(""); // 상환청구인부도일자
 * kftEnt0210510000.setRepaymentClaimantCorpIndvSortCode(""); // 상환청구인법인개인구분코드
 * kftEnt0210510000.setRepaymentClaimantResidentBusinessNumber(""); // 상환청구인주민사업자번호
 * kftEnt0210510000.setRepaymentClaimantCorpName(""); // 상환청구인법인명
 * kftEnt0210510000.setRepaymentClaimantNameRepresentativeName(""); // 상환청구인성명(대표자명)
 * kftEnt0210510000.setRepaymentClaimantAddress(""); // 상환청구인주소
 * kftEnt0210510000.setRepaymentClaimantBankCode(""); // 상환청구인은행코드
 * kftEnt0210510000.setRepaymentClaimantDepositAccountNumber(""); // 상환청구인입금계좌번호
 * kftEnt0210510000.setRepaymentClaimantSplitNumber1(""); // 상환청구인분할번호
 * kftEnt0210510000.setRepaymentClaimantEndorsementNumber(""); // 상환청구인배서번호
 * kftEnt0210510000.setTotalRecourseClaimInfoCount(0); // 총상환청구정보건수
 * kftEnt0210510000.setIssuerInfoIndvCorpSort(""); // 발행인정보-개인법인구분
 * kftEnt0210510000.setIssuerInfoResidentBusinessNumber(""); // 발행인정보-주민사업자번호
 * kftEnt0210510000.setIssuerInfoCorpName(""); // 발행인정보-법인명
 * kftEnt0210510000.setIssuerInfoNameRepresentative(""); // 발행인정보-성명(대표자명)
 * kftEnt0210510000.setIssuerInfoAddress(""); // 발행인정보-주소
 * kftEnt0210510000.setIssuerInfoCurrentAccountNumber(""); // 발행인정보-당좌계좌번호
 * kftEnt0210510000.setIssuerInfoRecourseClaimPresence(""); // 발행인정보-상환청구여부
 * kftEnt0210510000.setIssuerInfoRecourseClaimDate(""); // 발행인정보-상환청구일
 * kftEnt0210510000.setIssuanceGuarantorInfoIndvCorpSort(""); // 발행보증인정보-개인법인구분
 * kftEnt0210510000.setIssuanceGuarantorInfoResidentBusinessNumber(""); // 발행보증인정보-주민사업자번호
 * kftEnt0210510000.setIssuanceGuarantorInfoCorpName(""); // 발행보증인정보-법인명
 * kftEnt0210510000.setIssuanceGuarantorInfoNameRepresentative(""); // 발행보증인정보-성명(대표자명)
 * kftEnt0210510000.setIssuanceGuarantorInfoAddress(""); // 발행보증인정보-주소
 * kftEnt0210510000.setIssuanceGuarantorInfoBankCode(""); // 발행보증인정보-은행코드
 * kftEnt0210510000.setIssuanceGuarantorInfoDepositAccountNumber(""); // 발행보증인정보-입금계좌번호
 * kftEnt0210510000.setIssuanceGuarantorInfoRecourseClaimPresence(""); // 발행보증인정보-상환청구여부
 * kftEnt0210510000.setIssuanceGuarantorInfoRecourseClaimDate(""); // 발행보증인정보-상환청구일
 * KftEnt0210510000.QueryResult queryResult = new KftEnt0210510000.QueryResult(); // 조회결과Array
 * queryResult.setEndorsementInfoIndvCorpSort(""); // (조회결과)배서정보-개인법인구분
 * queryResult.setEndorsementInfoResidentBusinessNumber(""); // (조회결과)배서정보-주민사업자번호
 * queryResult.setEndorsementInfoCorpName(""); // (조회결과)배서정보-법인명
 * queryResult.setEndorsementInfoNameRepresentative(""); // (조회결과)배서정보-성명(대표자명)
 * queryResult.setEndorsementInfoBankCode(""); // (조회결과)배서정보-은행코드
 * queryResult.setEndorsementInfoDepositAccountNumber(""); // (조회결과)배서정보-입금계좌번호
 * queryResult.setEndorsementInfoSplitNumber(""); // (조회결과)배서정보-분할번호
 * queryResult.setEndorsementInfoEndorsementNumber(""); // (조회결과)배서정보-배서번호
 * queryResult.setEndorsementInfoEndorsementDate(""); // (조회결과)배서정보-배서일자
 * queryResult.setEndorsementInfoEndorsementAmount(0L); // (조회결과)배서정보-배서금액
 * queryResult.setEndorsementInfoNonCollateralEndorsement(""); // (조회결과)배서정보-무담보배서여부
 * queryResult.setEndorsementInfoProhibitedEndorsement(""); // (조회결과)배서정보-배서금지배서여부
 * queryResult.setEndorsementInfoGuaranteeEndorsement(""); // (조회결과)배서정보-배서보증여부
 * queryResult.setEndorsementInfoDefaultNoteReturn(""); // (조회결과)배서정보-부도어음반환여부
 * queryResult.setEndorsementInfoPostmaturedEndorsementPresence(""); // (조회결과)배서정보-시한후배서여부
 * queryResult.setEndorsementInfoRecourseClaimPresence(""); // (조회결과)배서정보-상환청구여부
 * queryResult.setEndorsementInfoRecourseClaimDate(""); // (조회결과)배서정보-상환청구일
 * kftEnt0210510000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0210510000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * endorsementInfoIndvCorpSort (조회결과)배서정보-개인법인구분 
	 * endorsementInfoResidentBusinessNumber (조회결과)배서정보-주민사업자번호 
	 * endorsementInfoCorpName (조회결과)배서정보-법인명 
	 * endorsementInfoNameRepresentative (조회결과)배서정보-성명(대표자명) 
	 * endorsementInfoBankCode (조회결과)배서정보-은행코드 
	 * endorsementInfoDepositAccountNumber (조회결과)배서정보-입금계좌번호 
	 * endorsementInfoSplitNumber (조회결과)배서정보-분할번호 
	 * endorsementInfoEndorsementNumber (조회결과)배서정보-배서번호 
	 * endorsementInfoEndorsementDate (조회결과)배서정보-배서일자 
	 * endorsementInfoEndorsementAmount (조회결과)배서정보-배서금액 
	 * endorsementInfoNonCollateralEndorsement (조회결과)배서정보-무담보배서여부 
	 * endorsementInfoProhibitedEndorsement (조회결과)배서정보-배서금지배서여부 
	 * endorsementInfoGuaranteeEndorsement (조회결과)배서정보-배서보증여부 
	 * endorsementInfoDefaultNoteReturn (조회결과)배서정보-부도어음반환여부 
	 * endorsementInfoPostmaturedEndorsementPresence (조회결과)배서정보-시한후배서여부 
	 * endorsementInfoRecourseClaimPresence (조회결과)배서정보-상환청구여부 
	 * endorsementInfoRecourseClaimDate (조회결과)배서정보-상환청구일 
	 * 
	 * KftEnt0210510000.QueryResult queryResult = new KftEnt0210510000.QueryResult(); // 조회결과Array
	 * queryResult.setEndorsementInfoIndvCorpSort(""); // (조회결과)배서정보-개인법인구분
	 * queryResult.setEndorsementInfoResidentBusinessNumber(""); // (조회결과)배서정보-주민사업자번호
	 * queryResult.setEndorsementInfoCorpName(""); // (조회결과)배서정보-법인명
	 * queryResult.setEndorsementInfoNameRepresentative(""); // (조회결과)배서정보-성명(대표자명)
	 * queryResult.setEndorsementInfoBankCode(""); // (조회결과)배서정보-은행코드
	 * queryResult.setEndorsementInfoDepositAccountNumber(""); // (조회결과)배서정보-입금계좌번호
	 * queryResult.setEndorsementInfoSplitNumber(""); // (조회결과)배서정보-분할번호
	 * queryResult.setEndorsementInfoEndorsementNumber(""); // (조회결과)배서정보-배서번호
	 * queryResult.setEndorsementInfoEndorsementDate(""); // (조회결과)배서정보-배서일자
	 * queryResult.setEndorsementInfoEndorsementAmount(0L); // (조회결과)배서정보-배서금액
	 * queryResult.setEndorsementInfoNonCollateralEndorsement(""); // (조회결과)배서정보-무담보배서여부
	 * queryResult.setEndorsementInfoProhibitedEndorsement(""); // (조회결과)배서정보-배서금지배서여부
	 * queryResult.setEndorsementInfoGuaranteeEndorsement(""); // (조회결과)배서정보-배서보증여부
	 * queryResult.setEndorsementInfoDefaultNoteReturn(""); // (조회결과)배서정보-부도어음반환여부
	 * queryResult.setEndorsementInfoPostmaturedEndorsementPresence(""); // (조회결과)배서정보-시한후배서여부
	 * queryResult.setEndorsementInfoRecourseClaimPresence(""); // (조회결과)배서정보-상환청구여부
	 * queryResult.setEndorsementInfoRecourseClaimDate(""); // (조회결과)배서정보-상환청구일
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String endorsementInfoIndvCorpSort; // (조회결과)배서정보-개인법인구분
		private String endorsementInfoResidentBusinessNumber; // (조회결과)배서정보-주민사업자번호
		private String endorsementInfoCorpName; // (조회결과)배서정보-법인명
		private String endorsementInfoNameRepresentative; // (조회결과)배서정보-성명(대표자명)
		private String endorsementInfoBankCode; // (조회결과)배서정보-은행코드
		private String endorsementInfoDepositAccountNumber; // (조회결과)배서정보-입금계좌번호
		private String endorsementInfoSplitNumber; // (조회결과)배서정보-분할번호
		private String endorsementInfoEndorsementNumber; // (조회결과)배서정보-배서번호
		private String endorsementInfoEndorsementDate; // (조회결과)배서정보-배서일자
		private long endorsementInfoEndorsementAmount; // (조회결과)배서정보-배서금액
		private String endorsementInfoNonCollateralEndorsement; // (조회결과)배서정보-무담보배서여부
		private String endorsementInfoProhibitedEndorsement; // (조회결과)배서정보-배서금지배서여부
		private String endorsementInfoGuaranteeEndorsement; // (조회결과)배서정보-배서보증여부
		private String endorsementInfoDefaultNoteReturn; // (조회결과)배서정보-부도어음반환여부
		private String endorsementInfoPostmaturedEndorsementPresence; // (조회결과)배서정보-시한후배서여부
		private String endorsementInfoRecourseClaimPresence; // (조회결과)배서정보-상환청구여부
		private String endorsementInfoRecourseClaimDate; // (조회결과)배서정보-상환청구일
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoIndvCorpSort$; // (조회결과)배서정보-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoResidentBusinessNumber$; // (조회결과)배서정보-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoCorpName$; // (조회결과)배서정보-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoNameRepresentative$; // (조회결과)배서정보-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoBankCode$; // (조회결과)배서정보-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoDepositAccountNumber$; // (조회결과)배서정보-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoSplitNumber$; // (조회결과)배서정보-분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementNumber$; // (조회결과)배서정보-배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementDate$; // (조회결과)배서정보-배서일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoEndorsementAmount$; // (조회결과)배서정보-배서금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoNonCollateralEndorsement$; // (조회결과)배서정보-무담보배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoProhibitedEndorsement$; // (조회결과)배서정보-배서금지배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoGuaranteeEndorsement$; // (조회결과)배서정보-배서보증여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoDefaultNoteReturn$; // (조회결과)배서정보-부도어음반환여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoPostmaturedEndorsementPresence$; // (조회결과)배서정보-시한후배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoRecourseClaimPresence$; // (조회결과)배서정보-상환청구여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementInfoRecourseClaimDate$; // (조회결과)배서정보-상환청구일

		@Override
		public void write(OutputStream out) throws IOException {
			endorsementInfoIndvCorpSort$ = VOUtils.write(out, endorsementInfoIndvCorpSort, 1); // (조회결과)배서정보-개인법인구분
			endorsementInfoResidentBusinessNumber$ = VOUtils.write(out, endorsementInfoResidentBusinessNumber, 13); // (조회결과)배서정보-주민사업자번호
			endorsementInfoCorpName$ = VOUtils.write(out, endorsementInfoCorpName, 40, "EUC-KR"); // (조회결과)배서정보-법인명
			endorsementInfoNameRepresentative$ = VOUtils.write(out, endorsementInfoNameRepresentative, 20, "EUC-KR"); // (조회결과)배서정보-성명(대표자명)
			endorsementInfoBankCode$ = VOUtils.write(out, endorsementInfoBankCode, 3); // (조회결과)배서정보-은행코드
			endorsementInfoDepositAccountNumber$ = VOUtils.write(out, endorsementInfoDepositAccountNumber, 16); // (조회결과)배서정보-입금계좌번호
			endorsementInfoSplitNumber$ = VOUtils.write(out, endorsementInfoSplitNumber, 2); // (조회결과)배서정보-분할번호
			endorsementInfoEndorsementNumber$ = VOUtils.write(out, endorsementInfoEndorsementNumber, 2); // (조회결과)배서정보-배서번호
			endorsementInfoEndorsementDate$ = VOUtils.write(out, endorsementInfoEndorsementDate, 8); // (조회결과)배서정보-배서일자
			endorsementInfoEndorsementAmount$ = VOUtils.write(out, endorsementInfoEndorsementAmount, 15); // (조회결과)배서정보-배서금액
			endorsementInfoNonCollateralEndorsement$ = VOUtils.write(out, endorsementInfoNonCollateralEndorsement, 1); // (조회결과)배서정보-무담보배서여부
			endorsementInfoProhibitedEndorsement$ = VOUtils.write(out, endorsementInfoProhibitedEndorsement, 1); // (조회결과)배서정보-배서금지배서여부
			endorsementInfoGuaranteeEndorsement$ = VOUtils.write(out, endorsementInfoGuaranteeEndorsement, 1); // (조회결과)배서정보-배서보증여부
			endorsementInfoDefaultNoteReturn$ = VOUtils.write(out, endorsementInfoDefaultNoteReturn, 1); // (조회결과)배서정보-부도어음반환여부
			endorsementInfoPostmaturedEndorsementPresence$ = VOUtils.write(out, endorsementInfoPostmaturedEndorsementPresence, 1); // (조회결과)배서정보-시한후배서여부
			endorsementInfoRecourseClaimPresence$ = VOUtils.write(out, endorsementInfoRecourseClaimPresence, 1); // (조회결과)배서정보-상환청구여부
			endorsementInfoRecourseClaimDate$ = VOUtils.write(out, endorsementInfoRecourseClaimDate, 8); // (조회결과)배서정보-상환청구일
		}

		@Override
		public void read(InputStream in) throws IOException {
			endorsementInfoIndvCorpSort = VOUtils.toString(endorsementInfoIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)배서정보-개인법인구분
			endorsementInfoResidentBusinessNumber = VOUtils.toString(endorsementInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)배서정보-주민사업자번호
			endorsementInfoCorpName = VOUtils.toString(endorsementInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)배서정보-법인명
			endorsementInfoNameRepresentative = VOUtils.toString(endorsementInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)배서정보-성명(대표자명)
			endorsementInfoBankCode = VOUtils.toString(endorsementInfoBankCode$ = VOUtils.read(in, 3)); // (조회결과)배서정보-은행코드
			endorsementInfoDepositAccountNumber = VOUtils.toString(endorsementInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)배서정보-입금계좌번호
			endorsementInfoSplitNumber = VOUtils.toString(endorsementInfoSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)배서정보-분할번호
			endorsementInfoEndorsementNumber = VOUtils.toString(endorsementInfoEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)배서정보-배서번호
			endorsementInfoEndorsementDate = VOUtils.toString(endorsementInfoEndorsementDate$ = VOUtils.read(in, 8)); // (조회결과)배서정보-배서일자
			endorsementInfoEndorsementAmount = VOUtils.toLong(endorsementInfoEndorsementAmount$ = VOUtils.read(in, 15)); // (조회결과)배서정보-배서금액
			endorsementInfoNonCollateralEndorsement = VOUtils.toString(endorsementInfoNonCollateralEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-무담보배서여부
			endorsementInfoProhibitedEndorsement = VOUtils.toString(endorsementInfoProhibitedEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-배서금지배서여부
			endorsementInfoGuaranteeEndorsement = VOUtils.toString(endorsementInfoGuaranteeEndorsement$ = VOUtils.read(in, 1)); // (조회결과)배서정보-배서보증여부
			endorsementInfoDefaultNoteReturn = VOUtils.toString(endorsementInfoDefaultNoteReturn$ = VOUtils.read(in, 1)); // (조회결과)배서정보-부도어음반환여부
			endorsementInfoPostmaturedEndorsementPresence = VOUtils.toString(endorsementInfoPostmaturedEndorsementPresence$ = VOUtils.read(in, 1)); // (조회결과)배서정보-시한후배서여부
			endorsementInfoRecourseClaimPresence = VOUtils.toString(endorsementInfoRecourseClaimPresence$ = VOUtils.read(in, 1)); // (조회결과)배서정보-상환청구여부
			endorsementInfoRecourseClaimDate = VOUtils.toString(endorsementInfoRecourseClaimDate$ = VOUtils.read(in, 8)); // (조회결과)배서정보-상환청구일
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", endorsementInfoIndvCorpSort=").append(endorsementInfoIndvCorpSort).append(System.lineSeparator()); // (조회결과)배서정보-개인법인구분
			sb.append(", endorsementInfoResidentBusinessNumber=").append(endorsementInfoResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)배서정보-주민사업자번호
			sb.append(", endorsementInfoCorpName=").append(endorsementInfoCorpName).append(System.lineSeparator()); // (조회결과)배서정보-법인명
			sb.append(", endorsementInfoNameRepresentative=").append(endorsementInfoNameRepresentative).append(System.lineSeparator()); // (조회결과)배서정보-성명(대표자명)
			sb.append(", endorsementInfoBankCode=").append(endorsementInfoBankCode).append(System.lineSeparator()); // (조회결과)배서정보-은행코드
			sb.append(", endorsementInfoDepositAccountNumber=").append(endorsementInfoDepositAccountNumber).append(System.lineSeparator()); // (조회결과)배서정보-입금계좌번호
			sb.append(", endorsementInfoSplitNumber=").append(endorsementInfoSplitNumber).append(System.lineSeparator()); // (조회결과)배서정보-분할번호
			sb.append(", endorsementInfoEndorsementNumber=").append(endorsementInfoEndorsementNumber).append(System.lineSeparator()); // (조회결과)배서정보-배서번호
			sb.append(", endorsementInfoEndorsementDate=").append(endorsementInfoEndorsementDate).append(System.lineSeparator()); // (조회결과)배서정보-배서일자
			sb.append(", endorsementInfoEndorsementAmount=").append(endorsementInfoEndorsementAmount).append(System.lineSeparator()); // (조회결과)배서정보-배서금액
			sb.append(", endorsementInfoNonCollateralEndorsement=").append(endorsementInfoNonCollateralEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-무담보배서여부
			sb.append(", endorsementInfoProhibitedEndorsement=").append(endorsementInfoProhibitedEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-배서금지배서여부
			sb.append(", endorsementInfoGuaranteeEndorsement=").append(endorsementInfoGuaranteeEndorsement).append(System.lineSeparator()); // (조회결과)배서정보-배서보증여부
			sb.append(", endorsementInfoDefaultNoteReturn=").append(endorsementInfoDefaultNoteReturn).append(System.lineSeparator()); // (조회결과)배서정보-부도어음반환여부
			sb.append(", endorsementInfoPostmaturedEndorsementPresence=").append(endorsementInfoPostmaturedEndorsementPresence).append(System.lineSeparator()); // (조회결과)배서정보-시한후배서여부
			sb.append(", endorsementInfoRecourseClaimPresence=").append(endorsementInfoRecourseClaimPresence).append(System.lineSeparator()); // (조회결과)배서정보-상환청구여부
			sb.append(", endorsementInfoRecourseClaimDate=").append(endorsementInfoRecourseClaimDate).append(System.lineSeparator()); // (조회결과)배서정보-상환청구일
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "510000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String userSort; // 이용자구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String currentCreditAccountNumber; // 당좌(입금)계좌번호
	private String repaymentClaimantSplitNumber; // 상환청구인분할번호
	private String noteDetailseNoteNumber; // 어음내역전자어음번호
	private String noteDetailseNoteType; // 어음내역어음종류
	private String noteDetailseNoteIssueDate; // 어음내역전자어음발행일자
	private String noteDetailseNoteIssuePlace; // 어음내역전자어음발행지
	private long noteDetailseNoteAmount; // 어음내역전자어음금액
	private String noteDetailseNoteMaturedDate; // 어음내역전자어음만기일자
	private String noteDetailspaymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private int noteDetailsEndorsementCount; // 어음내역배서횟수
	private String recourseClaimdefaultReasonCode; // 상환청구인부도사유코드
	private String recourseClaimdefaultDate; // 상환청구인부도일자
	private String repaymentClaimantCorpIndvSortCode; // 상환청구인법인개인구분코드
	private String repaymentClaimantResidentBusinessNumber; // 상환청구인주민사업자번호
	private String repaymentClaimantCorpName; // 상환청구인법인명
	private String repaymentClaimantNameRepresentativeName; // 상환청구인성명(대표자명)
	private String repaymentClaimantAddress; // 상환청구인주소
	private String repaymentClaimantBankCode; // 상환청구인은행코드
	private String repaymentClaimantDepositAccountNumber; // 상환청구인입금계좌번호
	private String repaymentClaimantSplitNumber1; // 상환청구인분할번호
	private String repaymentClaimantEndorsementNumber; // 상환청구인배서번호
	private int totalRecourseClaimInfoCount; // 총상환청구정보건수
	private String issuerInfoIndvCorpSort; // 발행인정보-개인법인구분
	private String issuerInfoResidentBusinessNumber; // 발행인정보-주민사업자번호
	private String issuerInfoCorpName; // 발행인정보-법인명
	private String issuerInfoNameRepresentative; // 발행인정보-성명(대표자명)
	private String issuerInfoAddress; // 발행인정보-주소
	private String issuerInfoCurrentAccountNumber; // 발행인정보-당좌계좌번호
	private String issuerInfoRecourseClaimPresence; // 발행인정보-상환청구여부
	private String issuerInfoRecourseClaimDate; // 발행인정보-상환청구일
	private String issuanceGuarantorInfoIndvCorpSort; // 발행보증인정보-개인법인구분
	private String issuanceGuarantorInfoResidentBusinessNumber; // 발행보증인정보-주민사업자번호
	private String issuanceGuarantorInfoCorpName; // 발행보증인정보-법인명
	private String issuanceGuarantorInfoNameRepresentative; // 발행보증인정보-성명(대표자명)
	private String issuanceGuarantorInfoAddress; // 발행보증인정보-주소
	private String issuanceGuarantorInfoBankCode; // 발행보증인정보-은행코드
	private String issuanceGuarantorInfoDepositAccountNumber; // 발행보증인정보-입금계좌번호
	private String issuanceGuarantorInfoRecourseClaimPresence; // 발행보증인정보-상환청구여부
	private String issuanceGuarantorInfoRecourseClaimDate; // 발행보증인정보-상환청구일
	private List<KftEnt0210510000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String userSort$; // 이용자구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCreditAccountNumber$; // 당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantSplitNumber$; // 상환청구인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailseNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailspaymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailsEndorsementCount$; // 어음내역배서횟수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recourseClaimdefaultReasonCode$; // 상환청구인부도사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recourseClaimdefaultDate$; // 상환청구인부도일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpIndvSortCode$; // 상환청구인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantResidentBusinessNumber$; // 상환청구인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpName$; // 상환청구인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantNameRepresentativeName$; // 상환청구인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantAddress$; // 상환청구인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantBankCode$; // 상환청구인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantDepositAccountNumber$; // 상환청구인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantSplitNumber1$; // 상환청구인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantEndorsementNumber$; // 상환청구인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalRecourseClaimInfoCount$; // 총상환청구정보건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoIndvCorpSort$; // 발행인정보-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoResidentBusinessNumber$; // 발행인정보-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpName$; // 발행인정보-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoNameRepresentative$; // 발행인정보-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoAddress$; // 발행인정보-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCurrentAccountNumber$; // 발행인정보-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoRecourseClaimPresence$; // 발행인정보-상환청구여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoRecourseClaimDate$; // 발행인정보-상환청구일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoIndvCorpSort$; // 발행보증인정보-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoResidentBusinessNumber$; // 발행보증인정보-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoCorpName$; // 발행보증인정보-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoNameRepresentative$; // 발행보증인정보-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoAddress$; // 발행보증인정보-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoBankCode$; // 발행보증인정보-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoDepositAccountNumber$; // 발행보증인정보-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoRecourseClaimPresence$; // 발행보증인정보-상환청구여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceGuarantorInfoRecourseClaimDate$; // 발행보증인정보-상환청구일

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(userSort$)) { // 이용자구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(currentCreditAccountNumber$)) { // 당좌(입금)계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(noteDetailseNoteNumber$)) { // 어음내역전자어음번호
			return 18;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantResidentBusinessNumber$)) { // 상환청구인주민사업자번호
			return 29;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantDepositAccountNumber$)) { // 상환청구인입금계좌번호
			return 34;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoResidentBusinessNumber$)) { // 발행인정보-주민사업자번호
			return 39;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoCurrentAccountNumber$)) { // 발행인정보-당좌계좌번호
			return 43;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoRecourseClaimPresence$)) { // 발행인정보-상환청구여부
			return 44;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuarantorInfoResidentBusinessNumber$)) { // 발행보증인정보-주민사업자번호
			return 47;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuarantorInfoDepositAccountNumber$)) { // 발행보증인정보-입금계좌번호
			return 52;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceGuarantorInfoRecourseClaimPresence$)) { // 발행보증인정보-상환청구여부
			return 53;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		noteDetailsEndorsementCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		userSort$ = VOUtils.write(out, userSort, 1); // 이용자구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentCreditAccountNumber$ = VOUtils.write(out, currentCreditAccountNumber, 16); // 당좌(입금)계좌번호
		repaymentClaimantSplitNumber$ = VOUtils.write(out, repaymentClaimantSplitNumber, 2); // 상환청구인분할번호
		noteDetailseNoteNumber$ = VOUtils.write(out, noteDetailseNoteNumber, 20); // 어음내역전자어음번호
		noteDetailseNoteType$ = VOUtils.write(out, noteDetailseNoteType, 1); // 어음내역어음종류
		noteDetailseNoteIssueDate$ = VOUtils.write(out, noteDetailseNoteIssueDate, 8); // 어음내역전자어음발행일자
		noteDetailseNoteIssuePlace$ = VOUtils.write(out, noteDetailseNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		noteDetailseNoteAmount$ = VOUtils.write(out, noteDetailseNoteAmount, 15); // 어음내역전자어음금액
		noteDetailseNoteMaturedDate$ = VOUtils.write(out, noteDetailseNoteMaturedDate, 8); // 어음내역전자어음만기일자
		noteDetailspaymentBankAndBranchCode$ = VOUtils.write(out, noteDetailspaymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		noteDetailsEndorsementCount$ = VOUtils.write(out, noteDetailsEndorsementCount, 2); // 어음내역배서횟수
		recourseClaimdefaultReasonCode$ = VOUtils.write(out, recourseClaimdefaultReasonCode, 2); // 상환청구인부도사유코드
		recourseClaimdefaultDate$ = VOUtils.write(out, recourseClaimdefaultDate, 8); // 상환청구인부도일자
		repaymentClaimantCorpIndvSortCode$ = VOUtils.write(out, repaymentClaimantCorpIndvSortCode, 1); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber$ = VOUtils.write(out, repaymentClaimantResidentBusinessNumber, 13); // 상환청구인주민사업자번호
		repaymentClaimantCorpName$ = VOUtils.write(out, repaymentClaimantCorpName, 40, "EUC-KR"); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName$ = VOUtils.write(out, repaymentClaimantNameRepresentativeName, 20, "EUC-KR"); // 상환청구인성명(대표자명)
		repaymentClaimantAddress$ = VOUtils.write(out, repaymentClaimantAddress, 60, "EUC-KR"); // 상환청구인주소
		repaymentClaimantBankCode$ = VOUtils.write(out, repaymentClaimantBankCode, 3); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber$ = VOUtils.write(out, repaymentClaimantDepositAccountNumber, 16); // 상환청구인입금계좌번호
		repaymentClaimantSplitNumber1$ = VOUtils.write(out, repaymentClaimantSplitNumber1, 2); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber$ = VOUtils.write(out, repaymentClaimantEndorsementNumber, 2); // 상환청구인배서번호
		totalRecourseClaimInfoCount$ = VOUtils.write(out, totalRecourseClaimInfoCount, 2); // 총상환청구정보건수
		issuerInfoIndvCorpSort$ = VOUtils.write(out, issuerInfoIndvCorpSort, 1); // 발행인정보-개인법인구분
		issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // 발행인정보-주민사업자번호
		issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // 발행인정보-법인명
		issuerInfoNameRepresentative$ = VOUtils.write(out, issuerInfoNameRepresentative, 20, "EUC-KR"); // 발행인정보-성명(대표자명)
		issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // 발행인정보-주소
		issuerInfoCurrentAccountNumber$ = VOUtils.write(out, issuerInfoCurrentAccountNumber, 16); // 발행인정보-당좌계좌번호
		issuerInfoRecourseClaimPresence$ = VOUtils.write(out, issuerInfoRecourseClaimPresence, 1); // 발행인정보-상환청구여부
		issuerInfoRecourseClaimDate$ = VOUtils.write(out, issuerInfoRecourseClaimDate, 8); // 발행인정보-상환청구일
		issuanceGuarantorInfoIndvCorpSort$ = VOUtils.write(out, issuanceGuarantorInfoIndvCorpSort, 1); // 발행보증인정보-개인법인구분
		issuanceGuarantorInfoResidentBusinessNumber$ = VOUtils.write(out, issuanceGuarantorInfoResidentBusinessNumber, 13); // 발행보증인정보-주민사업자번호
		issuanceGuarantorInfoCorpName$ = VOUtils.write(out, issuanceGuarantorInfoCorpName, 40, "EUC-KR"); // 발행보증인정보-법인명
		issuanceGuarantorInfoNameRepresentative$ = VOUtils.write(out, issuanceGuarantorInfoNameRepresentative, 20, "EUC-KR"); // 발행보증인정보-성명(대표자명)
		issuanceGuarantorInfoAddress$ = VOUtils.write(out, issuanceGuarantorInfoAddress, 60, "EUC-KR"); // 발행보증인정보-주소
		issuanceGuarantorInfoBankCode$ = VOUtils.write(out, issuanceGuarantorInfoBankCode, 3); // 발행보증인정보-은행코드
		issuanceGuarantorInfoDepositAccountNumber$ = VOUtils.write(out, issuanceGuarantorInfoDepositAccountNumber, 16); // 발행보증인정보-입금계좌번호
		issuanceGuarantorInfoRecourseClaimPresence$ = VOUtils.write(out, issuanceGuarantorInfoRecourseClaimPresence, 1); // 발행보증인정보-상환청구여부
		issuanceGuarantorInfoRecourseClaimDate$ = VOUtils.write(out, issuanceGuarantorInfoRecourseClaimDate, 8); // 발행보증인정보-상환청구일
		VOUtils.write(out, queryResultArray, 20, KftEnt0210510000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		userSort = VOUtils.toString(userSort$ = VOUtils.read(in, 1)); // 이용자구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentCreditAccountNumber = VOUtils.toString(currentCreditAccountNumber$ = VOUtils.read(in, 16)); // 당좌(입금)계좌번호
		repaymentClaimantSplitNumber = VOUtils.toString(repaymentClaimantSplitNumber$ = VOUtils.read(in, 2)); // 상환청구인분할번호
		noteDetailseNoteNumber = VOUtils.toString(noteDetailseNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		noteDetailseNoteType = VOUtils.toString(noteDetailseNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		noteDetailseNoteIssueDate = VOUtils.toString(noteDetailseNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		noteDetailseNoteIssuePlace = VOUtils.toString(noteDetailseNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		noteDetailseNoteAmount = VOUtils.toLong(noteDetailseNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		noteDetailseNoteMaturedDate = VOUtils.toString(noteDetailseNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		noteDetailspaymentBankAndBranchCode = VOUtils.toString(noteDetailspaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		noteDetailsEndorsementCount = VOUtils.toInt(noteDetailsEndorsementCount$ = VOUtils.read(in, 2)); // 어음내역배서횟수
		recourseClaimdefaultReasonCode = VOUtils.toString(recourseClaimdefaultReasonCode$ = VOUtils.read(in, 2)); // 상환청구인부도사유코드
		recourseClaimdefaultDate = VOUtils.toString(recourseClaimdefaultDate$ = VOUtils.read(in, 8)); // 상환청구인부도일자
		repaymentClaimantCorpIndvSortCode = VOUtils.toString(repaymentClaimantCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber = VOUtils.toString(repaymentClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환청구인주민사업자번호
		repaymentClaimantCorpName = VOUtils.toString(repaymentClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName = VOUtils.toString(repaymentClaimantNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환청구인성명(대표자명)
		repaymentClaimantAddress = VOUtils.toString(repaymentClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환청구인주소
		repaymentClaimantBankCode = VOUtils.toString(repaymentClaimantBankCode$ = VOUtils.read(in, 3)); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber = VOUtils.toString(repaymentClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환청구인입금계좌번호
		repaymentClaimantSplitNumber1 = VOUtils.toString(repaymentClaimantSplitNumber1$ = VOUtils.read(in, 2)); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber = VOUtils.toString(repaymentClaimantEndorsementNumber$ = VOUtils.read(in, 2)); // 상환청구인배서번호
		totalRecourseClaimInfoCount = VOUtils.toInt(totalRecourseClaimInfoCount$ = VOUtils.read(in, 2)); // 총상환청구정보건수
		issuerInfoIndvCorpSort = VOUtils.toString(issuerInfoIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인정보-개인법인구분
		issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인정보-주민사업자번호
		issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인정보-법인명
		issuerInfoNameRepresentative = VOUtils.toString(issuerInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인정보-성명(대표자명)
		issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인정보-주소
		issuerInfoCurrentAccountNumber = VOUtils.toString(issuerInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인정보-당좌계좌번호
		issuerInfoRecourseClaimPresence = VOUtils.toString(issuerInfoRecourseClaimPresence$ = VOUtils.read(in, 1)); // 발행인정보-상환청구여부
		issuerInfoRecourseClaimDate = VOUtils.toString(issuerInfoRecourseClaimDate$ = VOUtils.read(in, 8)); // 발행인정보-상환청구일
		issuanceGuarantorInfoIndvCorpSort = VOUtils.toString(issuanceGuarantorInfoIndvCorpSort$ = VOUtils.read(in, 1)); // 발행보증인정보-개인법인구분
		issuanceGuarantorInfoResidentBusinessNumber = VOUtils.toString(issuanceGuarantorInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행보증인정보-주민사업자번호
		issuanceGuarantorInfoCorpName = VOUtils.toString(issuanceGuarantorInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행보증인정보-법인명
		issuanceGuarantorInfoNameRepresentative = VOUtils.toString(issuanceGuarantorInfoNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 발행보증인정보-성명(대표자명)
		issuanceGuarantorInfoAddress = VOUtils.toString(issuanceGuarantorInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행보증인정보-주소
		issuanceGuarantorInfoBankCode = VOUtils.toString(issuanceGuarantorInfoBankCode$ = VOUtils.read(in, 3)); // 발행보증인정보-은행코드
		issuanceGuarantorInfoDepositAccountNumber = VOUtils.toString(issuanceGuarantorInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // 발행보증인정보-입금계좌번호
		issuanceGuarantorInfoRecourseClaimPresence = VOUtils.toString(issuanceGuarantorInfoRecourseClaimPresence$ = VOUtils.read(in, 1)); // 발행보증인정보-상환청구여부
		issuanceGuarantorInfoRecourseClaimDate = VOUtils.toString(issuanceGuarantorInfoRecourseClaimDate$ = VOUtils.read(in, 8)); // 발행보증인정보-상환청구일
		queryResultArray = VOUtils.toVoList(in, noteDetailsEndorsementCount, KftEnt0210510000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		noteDetailsEndorsementCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", userSort=").append(userSort).append(System.lineSeparator()); // 이용자구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentCreditAccountNumber=").append(currentCreditAccountNumber).append(System.lineSeparator()); // 당좌(입금)계좌번호
		sb.append(", repaymentClaimantSplitNumber=").append(repaymentClaimantSplitNumber).append(System.lineSeparator()); // 상환청구인분할번호
		sb.append(", noteDetailseNoteNumber=").append(noteDetailseNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", noteDetailseNoteType=").append(noteDetailseNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", noteDetailseNoteIssueDate=").append(noteDetailseNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", noteDetailseNoteIssuePlace=").append(noteDetailseNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", noteDetailseNoteAmount=").append(noteDetailseNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", noteDetailseNoteMaturedDate=").append(noteDetailseNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", noteDetailspaymentBankAndBranchCode=").append(noteDetailspaymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", noteDetailsEndorsementCount=").append(noteDetailsEndorsementCount).append(System.lineSeparator()); // 어음내역배서횟수
		sb.append(", recourseClaimdefaultReasonCode=").append(recourseClaimdefaultReasonCode).append(System.lineSeparator()); // 상환청구인부도사유코드
		sb.append(", recourseClaimdefaultDate=").append(recourseClaimdefaultDate).append(System.lineSeparator()); // 상환청구인부도일자
		sb.append(", repaymentClaimantCorpIndvSortCode=").append(repaymentClaimantCorpIndvSortCode).append(System.lineSeparator()); // 상환청구인법인개인구분코드
		sb.append(", repaymentClaimantResidentBusinessNumber=").append(repaymentClaimantResidentBusinessNumber).append(System.lineSeparator()); // 상환청구인주민사업자번호
		sb.append(", repaymentClaimantCorpName=").append(repaymentClaimantCorpName).append(System.lineSeparator()); // 상환청구인법인명
		sb.append(", repaymentClaimantNameRepresentativeName=").append(repaymentClaimantNameRepresentativeName).append(System.lineSeparator()); // 상환청구인성명(대표자명)
		sb.append(", repaymentClaimantAddress=").append(repaymentClaimantAddress).append(System.lineSeparator()); // 상환청구인주소
		sb.append(", repaymentClaimantBankCode=").append(repaymentClaimantBankCode).append(System.lineSeparator()); // 상환청구인은행코드
		sb.append(", repaymentClaimantDepositAccountNumber=").append(repaymentClaimantDepositAccountNumber).append(System.lineSeparator()); // 상환청구인입금계좌번호
		sb.append(", repaymentClaimantSplitNumber1=").append(repaymentClaimantSplitNumber1).append(System.lineSeparator()); // 상환청구인분할번호
		sb.append(", repaymentClaimantEndorsementNumber=").append(repaymentClaimantEndorsementNumber).append(System.lineSeparator()); // 상환청구인배서번호
		sb.append(", totalRecourseClaimInfoCount=").append(totalRecourseClaimInfoCount).append(System.lineSeparator()); // 총상환청구정보건수
		sb.append(", issuerInfoIndvCorpSort=").append(issuerInfoIndvCorpSort).append(System.lineSeparator()); // 발행인정보-개인법인구분
		sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행인정보-주민사업자번호
		sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // 발행인정보-법인명
		sb.append(", issuerInfoNameRepresentative=").append(issuerInfoNameRepresentative).append(System.lineSeparator()); // 발행인정보-성명(대표자명)
		sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // 발행인정보-주소
		sb.append(", issuerInfoCurrentAccountNumber=").append(issuerInfoCurrentAccountNumber).append(System.lineSeparator()); // 발행인정보-당좌계좌번호
		sb.append(", issuerInfoRecourseClaimPresence=").append(issuerInfoRecourseClaimPresence).append(System.lineSeparator()); // 발행인정보-상환청구여부
		sb.append(", issuerInfoRecourseClaimDate=").append(issuerInfoRecourseClaimDate).append(System.lineSeparator()); // 발행인정보-상환청구일
		sb.append(", issuanceGuarantorInfoIndvCorpSort=").append(issuanceGuarantorInfoIndvCorpSort).append(System.lineSeparator()); // 발행보증인정보-개인법인구분
		sb.append(", issuanceGuarantorInfoResidentBusinessNumber=").append(issuanceGuarantorInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행보증인정보-주민사업자번호
		sb.append(", issuanceGuarantorInfoCorpName=").append(issuanceGuarantorInfoCorpName).append(System.lineSeparator()); // 발행보증인정보-법인명
		sb.append(", issuanceGuarantorInfoNameRepresentative=").append(issuanceGuarantorInfoNameRepresentative).append(System.lineSeparator()); // 발행보증인정보-성명(대표자명)
		sb.append(", issuanceGuarantorInfoAddress=").append(issuanceGuarantorInfoAddress).append(System.lineSeparator()); // 발행보증인정보-주소
		sb.append(", issuanceGuarantorInfoBankCode=").append(issuanceGuarantorInfoBankCode).append(System.lineSeparator()); // 발행보증인정보-은행코드
		sb.append(", issuanceGuarantorInfoDepositAccountNumber=").append(issuanceGuarantorInfoDepositAccountNumber).append(System.lineSeparator()); // 발행보증인정보-입금계좌번호
		sb.append(", issuanceGuarantorInfoRecourseClaimPresence=").append(issuanceGuarantorInfoRecourseClaimPresence).append(System.lineSeparator()); // 발행보증인정보-상환청구여부
		sb.append(", issuanceGuarantorInfoRecourseClaimDate=").append(issuanceGuarantorInfoRecourseClaimDate).append(System.lineSeparator()); // 발행보증인정보-상환청구일
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "510000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "userSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteDetailseNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailspaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "noteDetailsEndorsementCount", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recourseClaimdefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recourseClaimdefaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentClaimantNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantSplitNumber1", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimantEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "totalRecourseClaimInfoCount", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuerInfoRecourseClaimPresence", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoRecourseClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoRecourseClaimPresence", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceGuarantorInfoRecourseClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorsementInfoIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorsementInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorsementInfoNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorsementInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorsementInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorsementInfoSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "endorsementInfoEndorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "endorsementInfoNonCollateralEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoProhibitedEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoGuaranteeEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoDefaultNoteReturn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoPostmaturedEndorsementPresence", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoRecourseClaimPresence", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorsementInfoRecourseClaimDate", "fldLen", "8", "defltVal", "")
		);
	}

}
