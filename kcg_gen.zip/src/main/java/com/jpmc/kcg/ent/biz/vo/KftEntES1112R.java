package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시 결과보고 정정내역
 * <pre>{@code
 * KftEntES1112R kftEntES1112R  = new KftEntES1112R(); // 지급제시 결과보고 정정내역
 * kftEntES1112R.setFileName(""); // 업무구분
 * kftEntES1112R.setDataType(""); // 데이터구분
 * kftEntES1112R.setSerialNumber(""); // 일련번호
 * kftEntES1112R.setPaymentPresentationDate(""); // 지급제시일자
 * kftEntES1112R.setEnoteNumber(""); // 어음번호
 * kftEntES1112R.setEnoteType(""); // 어음종류
 * kftEntES1112R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1112R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1112R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1112R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1112R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES1112R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES1112R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES1112R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES1112R.setIssuerAddress(""); // 발행인-주소
 * kftEntES1112R.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEntES1112R.setRecipientCorpIndvSort(""); // 소지인-법인개인구분
 * kftEntES1112R.setRecipientResidentBusinessNumber(""); // 소지인-주민사업자번호
 * kftEntES1112R.setRecipientCorpName(""); // 소지인-법인명
 * kftEntES1112R.setRecipientNameRepresentativeName(""); // 소지인-성명(대표자명)
 * kftEntES1112R.setRecipientBankCode(""); // 소지인-입금은행코드
 * kftEntES1112R.setRecipientDepositAccountNumber(""); // 소지인-입금계좌번호
 * kftEntES1112R.setBeforeChangeSettlementProcessSort(""); // 변경전-결제처리구분
 * kftEntES1112R.setDefaultDate(""); // 변경전-부도일자
 * kftEntES1112R.setBeforeChangeEnoteDefaultReason(""); // 변경전-전자어음 부도사유
 * kftEntES1112R.setBeforeChangeAccidentReportReason(""); // 변경전-사고신고서 사유
 * kftEntES1112R.setBeforeChangePaymentSuspensionProvisionalDisposition(""); // 변경전-지급정지 가처분
 * kftEntES1112R.setBeforeChangeSpecialDeposit(""); // 변경전-별단예금 입금
 * kftEntES1112R.setBeforeChangeBankManagementCompanyYn(""); // 변경전-은행관리 기업여부
 * kftEntES1112R.setBeforeChangeRestructuringTargetCompanyYn(""); // 변경전-구조조정대상기업여부
 * kftEntES1112R.setBeforeChangeDepositShortageCause(""); // 변경전-예금부족 원인
 * kftEntES1112R.setBeforeChangeDefaultDepositDate(""); // 변경전-부도 입금일자
 * kftEntES1112R.setAfterChangeSettlementProcessSort(""); // 변경후-결제처리구분
 * kftEntES1112R.setAfterChangeDefaultDate(""); // 변경후-부도일자
 * kftEntES1112R.setAfterChangeEnoteDefaultReason(""); // 변경후-전자어음 부도사유
 * kftEntES1112R.setAfterChangeAccidentReportReason(""); // 변경후-사고신고서 사유
 * kftEntES1112R.setAfterChangePaymentSuspensionProvisionalDisposition(""); // 변경후-지급정지 가처분
 * kftEntES1112R.setAfterChangeSpecialDeposit(""); // 변경후-별단예금 입금
 * kftEntES1112R.setAfterChangeBankManagementCompanyYn(""); // 변경후-은행관리 기업여부
 * kftEntES1112R.setAfterChangeRestructuringTargetCompanyYn(""); // 변경후-구조조정대상기업여부
 * kftEntES1112R.setAfterChangeDepositShortageCause(""); // 변경후-예금부족 원인
 * kftEntES1112R.setAfterChangeDefaultDepositDate(""); // 변경후-부도 입금일자
 * kftEntES1112R.setCorrectionDateAndTime(""); // 정정일시
 * kftEntES1112R.setSplitNumber(""); // 분할번호
 * kftEntES1112R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1112R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String paymentPresentationDate; // 지급제시일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String recipientCorpIndvSort; // 소지인-법인개인구분
	private String recipientResidentBusinessNumber; // 소지인-주민사업자번호
	private String recipientCorpName; // 소지인-법인명
	private String recipientNameRepresentativeName; // 소지인-성명(대표자명)
	private String recipientBankCode; // 소지인-입금은행코드
	private String recipientDepositAccountNumber; // 소지인-입금계좌번호
	private String beforeChangeSettlementProcessSort; // 변경전-결제처리구분
	private String defaultDate; // 변경전-부도일자
	private String beforeChangeEnoteDefaultReason; // 변경전-전자어음 부도사유
	private String beforeChangeAccidentReportReason; // 변경전-사고신고서 사유
	private String beforeChangePaymentSuspensionProvisionalDisposition; // 변경전-지급정지 가처분
	private String beforeChangeSpecialDeposit; // 변경전-별단예금 입금
	private String beforeChangeBankManagementCompanyYn; // 변경전-은행관리 기업여부
	private String beforeChangeRestructuringTargetCompanyYn; // 변경전-구조조정대상기업여부
	private String beforeChangeDepositShortageCause; // 변경전-예금부족 원인
	private String beforeChangeDefaultDepositDate; // 변경전-부도 입금일자
	private String afterChangeSettlementProcessSort; // 변경후-결제처리구분
	private String afterChangeDefaultDate; // 변경후-부도일자
	private String afterChangeEnoteDefaultReason; // 변경후-전자어음 부도사유
	private String afterChangeAccidentReportReason; // 변경후-사고신고서 사유
	private String afterChangePaymentSuspensionProvisionalDisposition; // 변경후-지급정지 가처분
	private String afterChangeSpecialDeposit; // 변경후-별단예금 입금
	private String afterChangeBankManagementCompanyYn; // 변경후-은행관리 기업여부
	private String afterChangeRestructuringTargetCompanyYn; // 변경후-구조조정대상기업여부
	private String afterChangeDepositShortageCause; // 변경후-예금부족 원인
	private String afterChangeDefaultDepositDate; // 변경후-부도 입금일자
	private String correctionDateAndTime; // 정정일시
	private String splitNumber; // 분할번호
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpIndvSort$; // 소지인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientResidentBusinessNumber$; // 소지인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpName$; // 소지인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientNameRepresentativeName$; // 소지인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientBankCode$; // 소지인-입금은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientDepositAccountNumber$; // 소지인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeSettlementProcessSort$; // 변경전-결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 변경전-부도일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeEnoteDefaultReason$; // 변경전-전자어음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeAccidentReportReason$; // 변경전-사고신고서 사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangePaymentSuspensionProvisionalDisposition$; // 변경전-지급정지 가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeSpecialDeposit$; // 변경전-별단예금 입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeBankManagementCompanyYn$; // 변경전-은행관리 기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeRestructuringTargetCompanyYn$; // 변경전-구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeDepositShortageCause$; // 변경전-예금부족 원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeDefaultDepositDate$; // 변경전-부도 입금일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeSettlementProcessSort$; // 변경후-결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDefaultDate$; // 변경후-부도일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeEnoteDefaultReason$; // 변경후-전자어음 부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeAccidentReportReason$; // 변경후-사고신고서 사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangePaymentSuspensionProvisionalDisposition$; // 변경후-지급정지 가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeSpecialDeposit$; // 변경후-별단예금 입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeBankManagementCompanyYn$; // 변경후-은행관리 기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeRestructuringTargetCompanyYn$; // 변경후-구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDepositShortageCause$; // 변경후-예금부족 원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDefaultDepositDate$; // 변경후-부도 입금일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String correctionDateAndTime$; // 정정일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13, "EUC-KR"); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		recipientCorpIndvSort$ = VOUtils.write(out, recipientCorpIndvSort, 1); // 소지인-법인개인구분
		recipientResidentBusinessNumber$ = VOUtils.write(out, recipientResidentBusinessNumber, 13, "EUC-KR"); // 소지인-주민사업자번호
		recipientCorpName$ = VOUtils.write(out, recipientCorpName, 40, "EUC-KR"); // 소지인-법인명
		recipientNameRepresentativeName$ = VOUtils.write(out, recipientNameRepresentativeName, 20, "EUC-KR"); // 소지인-성명(대표자명)
		recipientBankCode$ = VOUtils.write(out, recipientBankCode, 3); // 소지인-입금은행코드
		recipientDepositAccountNumber$ = VOUtils.write(out, recipientDepositAccountNumber, 16); // 소지인-입금계좌번호
		beforeChangeSettlementProcessSort$ = VOUtils.write(out, beforeChangeSettlementProcessSort, 2); // 변경전-결제처리구분
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 변경전-부도일자
		beforeChangeEnoteDefaultReason$ = VOUtils.write(out, beforeChangeEnoteDefaultReason, 2); // 변경전-전자어음 부도사유
		beforeChangeAccidentReportReason$ = VOUtils.write(out, beforeChangeAccidentReportReason, 1); // 변경전-사고신고서 사유
		beforeChangePaymentSuspensionProvisionalDisposition$ = VOUtils.write(out, beforeChangePaymentSuspensionProvisionalDisposition, 1); // 변경전-지급정지 가처분
		beforeChangeSpecialDeposit$ = VOUtils.write(out, beforeChangeSpecialDeposit, 1); // 변경전-별단예금 입금
		beforeChangeBankManagementCompanyYn$ = VOUtils.write(out, beforeChangeBankManagementCompanyYn, 1); // 변경전-은행관리 기업여부
		beforeChangeRestructuringTargetCompanyYn$ = VOUtils.write(out, beforeChangeRestructuringTargetCompanyYn, 1); // 변경전-구조조정대상기업여부
		beforeChangeDepositShortageCause$ = VOUtils.write(out, beforeChangeDepositShortageCause, 1); // 변경전-예금부족 원인
		beforeChangeDefaultDepositDate$ = VOUtils.write(out, beforeChangeDefaultDepositDate, 8); // 변경전-부도 입금일자
		afterChangeSettlementProcessSort$ = VOUtils.write(out, afterChangeSettlementProcessSort, 2); // 변경후-결제처리구분
		afterChangeDefaultDate$ = VOUtils.write(out, afterChangeDefaultDate, 8); // 변경후-부도일자
		afterChangeEnoteDefaultReason$ = VOUtils.write(out, afterChangeEnoteDefaultReason, 2); // 변경후-전자어음 부도사유
		afterChangeAccidentReportReason$ = VOUtils.write(out, afterChangeAccidentReportReason, 1); // 변경후-사고신고서 사유
		afterChangePaymentSuspensionProvisionalDisposition$ = VOUtils.write(out, afterChangePaymentSuspensionProvisionalDisposition, 1); // 변경후-지급정지 가처분
		afterChangeSpecialDeposit$ = VOUtils.write(out, afterChangeSpecialDeposit, 1); // 변경후-별단예금 입금
		afterChangeBankManagementCompanyYn$ = VOUtils.write(out, afterChangeBankManagementCompanyYn, 1); // 변경후-은행관리 기업여부
		afterChangeRestructuringTargetCompanyYn$ = VOUtils.write(out, afterChangeRestructuringTargetCompanyYn, 1); // 변경후-구조조정대상기업여부
		afterChangeDepositShortageCause$ = VOUtils.write(out, afterChangeDepositShortageCause, 1); // 변경후-예금부족 원인
		afterChangeDefaultDepositDate$ = VOUtils.write(out, afterChangeDefaultDepositDate, 8); // 변경후-부도 입금일자
		correctionDateAndTime$ = VOUtils.write(out, correctionDateAndTime, 14); // 정정일시
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		filler2$ = VOUtils.write(out, filler2, 27); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13, "EUC-KR")); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		recipientCorpIndvSort = VOUtils.toString(recipientCorpIndvSort$ = VOUtils.read(in, 1)); // 소지인-법인개인구분
		recipientResidentBusinessNumber = VOUtils.toString(recipientResidentBusinessNumber$ = VOUtils.read(in, 13, "EUC-KR")); // 소지인-주민사업자번호
		recipientCorpName = VOUtils.toString(recipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 소지인-법인명
		recipientNameRepresentativeName = VOUtils.toString(recipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 소지인-성명(대표자명)
		recipientBankCode = VOUtils.toString(recipientBankCode$ = VOUtils.read(in, 3)); // 소지인-입금은행코드
		recipientDepositAccountNumber = VOUtils.toString(recipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 소지인-입금계좌번호
		beforeChangeSettlementProcessSort = VOUtils.toString(beforeChangeSettlementProcessSort$ = VOUtils.read(in, 2)); // 변경전-결제처리구분
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 변경전-부도일자
		beforeChangeEnoteDefaultReason = VOUtils.toString(beforeChangeEnoteDefaultReason$ = VOUtils.read(in, 2)); // 변경전-전자어음 부도사유
		beforeChangeAccidentReportReason = VOUtils.toString(beforeChangeAccidentReportReason$ = VOUtils.read(in, 1)); // 변경전-사고신고서 사유
		beforeChangePaymentSuspensionProvisionalDisposition = VOUtils.toString(beforeChangePaymentSuspensionProvisionalDisposition$ = VOUtils.read(in, 1)); // 변경전-지급정지 가처분
		beforeChangeSpecialDeposit = VOUtils.toString(beforeChangeSpecialDeposit$ = VOUtils.read(in, 1)); // 변경전-별단예금 입금
		beforeChangeBankManagementCompanyYn = VOUtils.toString(beforeChangeBankManagementCompanyYn$ = VOUtils.read(in, 1)); // 변경전-은행관리 기업여부
		beforeChangeRestructuringTargetCompanyYn = VOUtils.toString(beforeChangeRestructuringTargetCompanyYn$ = VOUtils.read(in, 1)); // 변경전-구조조정대상기업여부
		beforeChangeDepositShortageCause = VOUtils.toString(beforeChangeDepositShortageCause$ = VOUtils.read(in, 1)); // 변경전-예금부족 원인
		beforeChangeDefaultDepositDate = VOUtils.toString(beforeChangeDefaultDepositDate$ = VOUtils.read(in, 8)); // 변경전-부도 입금일자
		afterChangeSettlementProcessSort = VOUtils.toString(afterChangeSettlementProcessSort$ = VOUtils.read(in, 2)); // 변경후-결제처리구분
		afterChangeDefaultDate = VOUtils.toString(afterChangeDefaultDate$ = VOUtils.read(in, 8)); // 변경후-부도일자
		afterChangeEnoteDefaultReason = VOUtils.toString(afterChangeEnoteDefaultReason$ = VOUtils.read(in, 2)); // 변경후-전자어음 부도사유
		afterChangeAccidentReportReason = VOUtils.toString(afterChangeAccidentReportReason$ = VOUtils.read(in, 1)); // 변경후-사고신고서 사유
		afterChangePaymentSuspensionProvisionalDisposition = VOUtils.toString(afterChangePaymentSuspensionProvisionalDisposition$ = VOUtils.read(in, 1)); // 변경후-지급정지 가처분
		afterChangeSpecialDeposit = VOUtils.toString(afterChangeSpecialDeposit$ = VOUtils.read(in, 1)); // 변경후-별단예금 입금
		afterChangeBankManagementCompanyYn = VOUtils.toString(afterChangeBankManagementCompanyYn$ = VOUtils.read(in, 1)); // 변경후-은행관리 기업여부
		afterChangeRestructuringTargetCompanyYn = VOUtils.toString(afterChangeRestructuringTargetCompanyYn$ = VOUtils.read(in, 1)); // 변경후-구조조정대상기업여부
		afterChangeDepositShortageCause = VOUtils.toString(afterChangeDepositShortageCause$ = VOUtils.read(in, 1)); // 변경후-예금부족 원인
		afterChangeDefaultDepositDate = VOUtils.toString(afterChangeDefaultDepositDate$ = VOUtils.read(in, 8)); // 변경후-부도 입금일자
		correctionDateAndTime = VOUtils.toString(correctionDateAndTime$ = VOUtils.read(in, 14)); // 정정일시
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 27)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", recipientCorpIndvSort=").append(recipientCorpIndvSort).append(System.lineSeparator()); // 소지인-법인개인구분
		sb.append(", recipientResidentBusinessNumber=").append(recipientResidentBusinessNumber).append(System.lineSeparator()); // 소지인-주민사업자번호
		sb.append(", recipientCorpName=").append(recipientCorpName).append(System.lineSeparator()); // 소지인-법인명
		sb.append(", recipientNameRepresentativeName=").append(recipientNameRepresentativeName).append(System.lineSeparator()); // 소지인-성명(대표자명)
		sb.append(", recipientBankCode=").append(recipientBankCode).append(System.lineSeparator()); // 소지인-입금은행코드
		sb.append(", recipientDepositAccountNumber=").append(recipientDepositAccountNumber).append(System.lineSeparator()); // 소지인-입금계좌번호
		sb.append(", beforeChangeSettlementProcessSort=").append(beforeChangeSettlementProcessSort).append(System.lineSeparator()); // 변경전-결제처리구분
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 변경전-부도일자
		sb.append(", beforeChangeEnoteDefaultReason=").append(beforeChangeEnoteDefaultReason).append(System.lineSeparator()); // 변경전-전자어음 부도사유
		sb.append(", beforeChangeAccidentReportReason=").append(beforeChangeAccidentReportReason).append(System.lineSeparator()); // 변경전-사고신고서 사유
		sb.append(", beforeChangePaymentSuspensionProvisionalDisposition=").append(beforeChangePaymentSuspensionProvisionalDisposition).append(System.lineSeparator()); // 변경전-지급정지 가처분
		sb.append(", beforeChangeSpecialDeposit=").append(beforeChangeSpecialDeposit).append(System.lineSeparator()); // 변경전-별단예금 입금
		sb.append(", beforeChangeBankManagementCompanyYn=").append(beforeChangeBankManagementCompanyYn).append(System.lineSeparator()); // 변경전-은행관리 기업여부
		sb.append(", beforeChangeRestructuringTargetCompanyYn=").append(beforeChangeRestructuringTargetCompanyYn).append(System.lineSeparator()); // 변경전-구조조정대상기업여부
		sb.append(", beforeChangeDepositShortageCause=").append(beforeChangeDepositShortageCause).append(System.lineSeparator()); // 변경전-예금부족 원인
		sb.append(", beforeChangeDefaultDepositDate=").append(beforeChangeDefaultDepositDate).append(System.lineSeparator()); // 변경전-부도 입금일자
		sb.append(", afterChangeSettlementProcessSort=").append(afterChangeSettlementProcessSort).append(System.lineSeparator()); // 변경후-결제처리구분
		sb.append(", afterChangeDefaultDate=").append(afterChangeDefaultDate).append(System.lineSeparator()); // 변경후-부도일자
		sb.append(", afterChangeEnoteDefaultReason=").append(afterChangeEnoteDefaultReason).append(System.lineSeparator()); // 변경후-전자어음 부도사유
		sb.append(", afterChangeAccidentReportReason=").append(afterChangeAccidentReportReason).append(System.lineSeparator()); // 변경후-사고신고서 사유
		sb.append(", afterChangePaymentSuspensionProvisionalDisposition=").append(afterChangePaymentSuspensionProvisionalDisposition).append(System.lineSeparator()); // 변경후-지급정지 가처분
		sb.append(", afterChangeSpecialDeposit=").append(afterChangeSpecialDeposit).append(System.lineSeparator()); // 변경후-별단예금 입금
		sb.append(", afterChangeBankManagementCompanyYn=").append(afterChangeBankManagementCompanyYn).append(System.lineSeparator()); // 변경후-은행관리 기업여부
		sb.append(", afterChangeRestructuringTargetCompanyYn=").append(afterChangeRestructuringTargetCompanyYn).append(System.lineSeparator()); // 변경후-구조조정대상기업여부
		sb.append(", afterChangeDepositShortageCause=").append(afterChangeDepositShortageCause).append(System.lineSeparator()); // 변경후-예금부족 원인
		sb.append(", afterChangeDefaultDepositDate=").append(afterChangeDefaultDepositDate).append(System.lineSeparator()); // 변경후-부도 입금일자
		sb.append(", correctionDateAndTime=").append(correctionDateAndTime).append(System.lineSeparator()); // 정정일시
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recipientBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "recipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beforeChangeSettlementProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "beforeChangeEnoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "beforeChangeAccidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangePaymentSuspensionProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeSpecialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeBankManagementCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeRestructuringTargetCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeDepositShortageCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeDefaultDepositDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "afterChangeSettlementProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "afterChangeDefaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "afterChangeEnoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "afterChangeAccidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangePaymentSuspensionProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeSpecialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeBankManagementCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeRestructuringTargetCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeDepositShortageCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeDefaultDepositDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "correctionDateAndTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "27", "defltVal", "")
		);
	}

}
