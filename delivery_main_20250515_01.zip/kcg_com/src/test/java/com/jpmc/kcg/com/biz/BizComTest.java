package com.jpmc.kcg.com.biz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.dao.ComAcctNoMDao;
import com.jpmc.kcg.com.dao.ComAcctStsDao;
import com.jpmc.kcg.com.dao.ComBnkBrnchCdMDao;
import com.jpmc.kcg.com.dao.ComBnkCdMDao;
import com.jpmc.kcg.com.dao.ComBnkCdMMapper;
import com.jpmc.kcg.com.dao.ComBnkStsMDao;
import com.jpmc.kcg.com.dao.ComCdDMapper;
import com.jpmc.kcg.com.dao.ComChequeInfoMgmtMDao;
import com.jpmc.kcg.com.dao.ComChequeInfoMgmtMMapper;
import com.jpmc.kcg.com.dao.ComNbrgMDao;
import com.jpmc.kcg.com.dao.ComRespCdMDao;
import com.jpmc.kcg.com.dao.ComRespCdMMapper;
import com.jpmc.kcg.com.dao.ComRespCdMapMDao;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dao.ComTrHoldLMapper;
import com.jpmc.kcg.com.dto.CheckChequeStatusIn;
import com.jpmc.kcg.com.dto.ComAcctNoM;
import com.jpmc.kcg.com.dto.ComAcctStsOut;
import com.jpmc.kcg.com.dto.ComBnkBrnchCdM;
import com.jpmc.kcg.com.dto.ComBnkCdM;
import com.jpmc.kcg.com.dto.ComBnkStsM;
import com.jpmc.kcg.com.dto.ComBnkStsMIn;
import com.jpmc.kcg.com.dto.ComBnkStsMOut;
import com.jpmc.kcg.com.dto.ComCdD;
import com.jpmc.kcg.com.dto.ComChequeInfoMgmtM;
import com.jpmc.kcg.com.dto.ComNbrgM;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.dto.ComRespCdMapM;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.dto.ComTrHoldLIn;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;

@ExtendWith(MockitoExtension.class)
public class BizComTest {

	@Mock
	private ComBnkCdMDao comBnkCdMDao;
	@Mock
	private ComAcctNoMDao comAcctNoMDao;
	@Mock
	private ComAcctStsDao comAcctStsDao;
	@Mock
	private ComBnkBrnchCdMDao comBnkBrnchCdMDao;
	@Mock
	private ComBnkStsMDao comBnkStsMDao;
	@Mock
	private ComNbrgMDao comNbrgMDao;
	@Mock
	private ComRespCdMDao comRespCdMDao;
	@Mock
	private ComBnkCdM comBnkCdM;
	@Mock
	private ComAcctNoM comAcctNoM;
	@Mock
	private ComBnkBrnchCdM comBnkBrnchCdM;
	@Mock
	private ComBnkStsMIn comBnkStsMInDto;
	@Mock
	private ComBnkStsM comBnkStsM;
	@Mock
	private ComNbrgM comNbrgM;
	@Mock
	private ComRespCdM comRespCdM;
	@Mock
	private ComRespCdMMapper comRespCdMMapper;
	@Mock
	private ComTrHoldLMapper comTrHoldLMapper;
	@Mock
	private ComBnkCdMMapper comBnkCdMMapper;
	@Mock
	private ComCdDMapper comCdDMapper;
	@Mock
	private ComChequeInfoMgmtMMapper comChequeInfoMgmtMMapper;
	@Mock
	private ComChequeInfoMgmtMDao comChequeInfoMgmtMDao;
	@Mock
	private ComRespCdMapMDao comRespCdMapMDao;
	@Mock
	private ComTrHoldLDao comTrHoldLDao;
	@Mock
	private BizDate bizDate;

	@Mock
	FrwContext frwContext;

	@InjectMocks
	private BizCom bizCom;

	@Test
	@DisplayName("getBankCodeValidation - 기본 케이스")
	void getBankCodeValidation_BaseCase() {
		String validBnkCd = "057";
		String invalidBnkCd = "000";
		String nullBnkCd = null;

		// Mock DAO 결과
		ComBnkCdM validBnkCdM = new ComBnkCdM();
		validBnkCdM.setBnkCd(validBnkCd);
		when(comBnkCdMDao.selectComBnkCdList(any()))
				.thenReturn(Collections.singletonList(validBnkCdM))
				.thenReturn(Collections.emptyList());

		// 1. 유효한 은행코드
		boolean resultValid = bizCom.getBankCodeValidation(validBnkCd);
		assertTrue(resultValid, "유효한 은행코드는 true를 반환해야 함");

		// 2. 존재하지 않는 은행코드
		boolean resultInvalid = bizCom.getBankCodeValidation(invalidBnkCd);
		assertFalse(resultInvalid, "존재하지 않는 은행코드는 false를 반환해야 함");

		// 3. null 은행코드
		assertThrows(BusinessException.class, () -> bizCom.getBankCodeValidation(nullBnkCd),
				"null 은행코드는 BusinessException을 발생시켜야 함");
	}

	@Test
	@DisplayName("getBankCodeValidation - 모든 업무구분 코드 케이스")
	void getBankCodeValidation_AllBizDvsnCdEnums() {
		String validBnkCd = "057";

		// Mock DAO 결과
		ComBnkCdM combnkCdM = new ComBnkCdM();
		combnkCdM.setBnkCd(validBnkCd);
		when(comBnkCdMDao.selectComBnkCdList(any()))
				.thenReturn(Collections.singletonList(combnkCdM));

		// 1. HOF 코드
		List<BizDvsnCdEnum> hofBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.HOF);
		boolean resultHof = bizCom.getBankCodeValidation(validBnkCd, hofBizDvsnCd);
		assertTrue(resultHof, "HOF 코드가 포함된 경우 true를 반환해야 함");

		// 2. CMS 코드
		List<BizDvsnCdEnum> cmsBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.CMS);
		boolean resultCms = bizCom.getBankCodeValidation(validBnkCd, cmsBizDvsnCd);
		assertTrue(resultCms, "CMS 코드가 포함된 경우 true를 반환해야 함");

		// 3. HBK 코드
		List<BizDvsnCdEnum> hbkBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.HBK);
		boolean resultHbk = bizCom.getBankCodeValidation(validBnkCd, hbkBizDvsnCd);
		assertTrue(resultHbk, "HBK 코드가 포함된 경우 true를 반환해야 함");

		// 4. IFT 코드
		List<BizDvsnCdEnum> iftBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.IFT);
		boolean resultIft = bizCom.getBankCodeValidation(validBnkCd, iftBizDvsnCd);
		assertTrue(resultIft, "IFT 코드가 포함된 경우 true를 반환해야 함");

		// 5. RPR 코드
		List<BizDvsnCdEnum> rprBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.RPR);
		boolean resultRpr = bizCom.getBankCodeValidation(validBnkCd, rprBizDvsnCd);
		assertTrue(resultRpr, "RPR 코드가 포함된 경우 true를 반환해야 함");

		// 6. ENT 코드
		List<BizDvsnCdEnum> entBizDvsnCd = Collections.singletonList(BizDvsnCdEnum.ENT);
		boolean resultEnt = bizCom.getBankCodeValidation(validBnkCd, entBizDvsnCd);
		assertTrue(resultEnt, "ENT 코드가 포함된 경우 true를 반환해야 함");

		// 7. 모든 코드 포함
		List<BizDvsnCdEnum> allBizDvsnCd = Arrays.asList(BizDvsnCdEnum.values());
		boolean resultAll = bizCom.getBankCodeValidation(validBnkCd, allBizDvsnCd);
		assertTrue(resultAll, "모든 업무구분 코드가 포함된 경우 true를 반환해야 함");
	}

	@Test
	@DisplayName("getBankCodeValidation - DAO 결과가 빈 리스트일 때")
	void getBankCodeValidation_EmptyDaoResult() {
		String validBnkCd = "057";

		// Mock DAO에서 빈 리스트 반환
		when(comBnkCdMDao.selectComBnkCdList(any())).thenReturn(Collections.emptyList());

		// 업무구분 코드 포함
		List<BizDvsnCdEnum> bizDvsnCdList = Collections.singletonList(BizDvsnCdEnum.HOF);
		boolean result = bizCom.getBankCodeValidation(validBnkCd, bizDvsnCdList);
		assertFalse(result, "DAO 결과가 빈 리스트인 경우 false를 반환해야 함");
	}

	@Test
	@DisplayName("acctNo Null")
	void getAccountValidation_1() {

		// bizCom = new BizCom(comBnkCdMDao, comAcctNoMDao, comBnkBrnchCdMDao,
		// comBnkStsMDao, comNbrgMDao, comRespCdMDao);

		String acctNo = "";

		assertThrows(BusinessException.class,
				() -> bizCom.getAccountValidation(acctNo, "IFT", "KFT"));
	}

	@Test
	@DisplayName("getAccountValidation_validAccountNumber")
	void getAccountValidation_validAccountNumber() {

		String acctNo = "222222222";
		ComAcctStsOut comAcctStsOut = new ComAcctStsOut();
		comAcctStsOut.setAcctNo(acctNo);
		comAcctStsOut.setAcctNm("계좌이름");
		comAcctStsOut.setAcctStsCd("01");
		comAcctStsOut.setDdaCd("5");
		// List<ComAcctNoM> comAcctNoMList = new ArrayList<>();
		// comAcctNoMList.add(comAcctNoM);
		when(comAcctStsDao.selectAcctNoInfo_1(any())).thenReturn(comAcctStsOut);

		bizCom.getAccountValidation(acctNo, "IFT", "KFT");
		// assertThrows(BusinessException.class, () ->
		// bizCom.getAccountValidation(acctNo, "IFT","KFT"));
	}

	@Test
	@DisplayName("getAccountValidation Tests")
	void getAccountValidation() {
		String validAcctNo = "555666777888";
		String emptyAcctNo = "";
		String nullAcctNo = null;

		// 1. acctNo Null or Empty
		assertThrows(BusinessException.class,
				() -> bizCom.getAccountValidation(emptyAcctNo, "IFT", "KFT"));

		// 2. Valid Account Number
		ComAcctStsOut validAccount = createComAcctStsOut(validAcctNo, "정상계좌", "01", "5");
		when(comAcctStsDao.selectAcctNoInfo_1(any())).thenReturn(validAccount);
		bizCom.getAccountValidation(validAcctNo, "IFT", "KFT");

		// 3. Handle different account statuses
		List<String[]> accountStatusTests = Arrays.asList(new String[] { "휴면계좌", "02", "9" },
				new String[] { "해지계좌", "03", "9" }, new String[] { "제한계좌", "04", "9" },
				new String[] { "기타", "05", "9" });

		for (String[] status : accountStatusTests) {
			ComAcctStsOut accountStatus = createComAcctStsOut(validAcctNo, status[0], status[1],
					status[2]);
			when(comAcctStsDao.selectAcctNoInfo_1(any())).thenReturn(accountStatus);
			bizCom.getAccountValidation(validAcctNo, "IFT", "KFT");
		}

		// 4. Blank and Null scenarios
		List<ComAcctStsOut> accountVariants = Arrays.asList(
				createComAcctStsOut(emptyAcctNo, "정상계좌", "01", "5"),
				createComAcctStsOut(validAcctNo, "", "01", "5"),
				createComAcctStsOut(validAcctNo, "정상계좌", "01", ""),
				createComAcctStsOut(nullAcctNo, "정상계좌", "01", "5"));

		for (ComAcctStsOut variant : accountVariants) {
			when(comAcctStsDao.selectAcctNoInfo_1(any())).thenReturn(variant);
			bizCom.getAccountValidation(validAcctNo, "IFT", "KFT");
		}

		// 5. Virtual account name test
		ComAcctStsOut virtualAccount = createComAcctStsOut(validAcctNo, "정상계좌", "01", "");
		virtualAccount.setMthrAcctNo("33225567897");
		when(comAcctStsDao.selectAcctNoInfo_3(any())).thenReturn(virtualAccount);
		bizCom.getAccountValidation(validAcctNo, "IFT", "KFT");
	}

	// Helper method to create ComAcctStsOut objects
	private ComAcctStsOut createComAcctStsOut(String acctNo, String acctNm, String acctStsCd,
			String ddaCd) {
		ComAcctStsOut comAcctStsOut = new ComAcctStsOut();
		comAcctStsOut.setAcctNo(acctNo);
		comAcctStsOut.setAcctNm(acctNm);
		comAcctStsOut.setAcctStsCd(acctStsCd);
		comAcctStsOut.setDdaCd(ddaCd);
		return comAcctStsOut;
	}

	@Test
	@Order(7)
	@DisplayName("getBankBranchCodeValidation_validBnkBrnchCd")
	void getBankBranchCodeValidation_validBnkBrnchCd() {

		String bnkBrnchCd = "0030003";

		ComBnkBrnchCdM comBnkBrnchCdM = new ComBnkBrnchCdM();
		comBnkBrnchCdM.setBnkCd("003");
		comBnkBrnchCdM.setBrnchCd1("000");
		comBnkBrnchCdM.setBrnchCd2("3");

		List<ComBnkBrnchCdM> comBnkBrnchCdMList = new ArrayList<ComBnkBrnchCdM>();
		comBnkBrnchCdMList.add(comBnkBrnchCdM);

		when(comBnkBrnchCdMDao.selectListBnkBrnchCdM(any())).thenReturn(comBnkBrnchCdMList);

		bizCom.getBankBranchCodeValidation(bnkBrnchCd);
	}

	@Test
	@Order(7)
	@DisplayName("getBankBranchCodeValidation_validBnkBrnchCd")
	void getBankBranchCodeValidation_validBnkBrnchCd_2() {

		String bnkBrnchCd = "0030003";

		ComBnkBrnchCdM comBnkBrnchCdM = new ComBnkBrnchCdM();
		comBnkBrnchCdM.setBnkCd("003");
		comBnkBrnchCdM.setBrnchCd1("000");
		comBnkBrnchCdM.setBrnchCd2("3");

		List<ComBnkBrnchCdM> comBnkBrnchCdMList = new ArrayList<ComBnkBrnchCdM>();
		//comBnkBrnchCdMList.add(comBnkBrnchCdM);

		when(comBnkBrnchCdMDao.selectListBnkBrnchCdM(any())).thenReturn(comBnkBrnchCdMList);

		assertThrows(BusinessException.class, () -> bizCom.getBankBranchCodeValidation(bnkBrnchCd));
	}

	@Test
	@Order(7)
	@DisplayName("getBankBranchCodeValidation_validBnkBrnchCd")
	void getBankBranchCodeValidation_validBnkBrnchCd_3() {

		String bnkBrnchCd = "0030003";

		ComBnkBrnchCdM comBnkBrnchCdM = new ComBnkBrnchCdM();
		comBnkBrnchCdM.setBnkCd("003");
		comBnkBrnchCdM.setBrnchCd1("");
		comBnkBrnchCdM.setBrnchCd2("");

		List<ComBnkBrnchCdM> comBnkBrnchCdMList = new ArrayList<ComBnkBrnchCdM>();
		comBnkBrnchCdMList.add(comBnkBrnchCdM);

		when(comBnkBrnchCdMDao.selectListBnkBrnchCdM(any())).thenReturn(comBnkBrnchCdMList);

		assertThrows(BusinessException.class, () -> bizCom.getBankBranchCodeValidation(bnkBrnchCd));
	}

	@Test
	@Order(10)
	void getConnectivtyValidation_InValidCd_IFT_1() {

		String bnkCd = "";
		String bizDvsnCd = "IFT";
		assertThrows(BusinessException.class,
				() -> bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT"));
	}

	@Test
	@Order(10)
	void getConnectivtyValidation_InValidCd_IFT_2() {

		String bnkCd = "002";
		String bizDvsnCd = "";
		assertThrows(BusinessException.class,
				() -> bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT"));
	}

	@Test
	@Order(10)
	@DisplayName("getConnectivtyValidation_ValidBizDvsnCd_IFT")
	void getConnectivtyValidation_ValidBizDvsnCd_IFT() {

		String bnkCd = "057";
		String bizDvsnCd = "IFT";

		// 모의(mock) 데이터 설정
		ComBnkStsMOut comBnkStsMOut = new ComBnkStsMOut();
		comBnkStsMOut.setBnkCd(bnkCd);
		comBnkStsMOut.setBizDvsnCd(bizDvsnCd);
		comBnkStsMOut.setBnkStsCd("01");
		comBnkStsMOut.setKtfcNetStatus("000");
		comBnkStsMOut.setJpmcNetStatus("000");
		comBnkStsMOut.setBnkNetStatus("000");

		when(comBnkStsMDao.selectConnectivityStatus(any())).thenReturn(comBnkStsMOut);
		// 테스트 대상 메서드 호출
		bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT");
	}

	@Test
	@Order(10)
	void getConnectivtyValidation_ValidBizDvsnCd_IFT_1() {

		String bnkCd = "057";
		String bizDvsnCd = "IFT";

		// 모의(mock) 데이터 설정
		ComBnkStsMOut comBnkStsMOut = new ComBnkStsMOut();
		comBnkStsMOut.setBnkCd(bnkCd);
		comBnkStsMOut.setBizDvsnCd(bizDvsnCd);
		comBnkStsMOut.setBnkStsCd("01");
		comBnkStsMOut.setKtfcNetStatus("999");
		comBnkStsMOut.setJpmcNetStatus("000");
		comBnkStsMOut.setBnkNetStatus("000");

		when(comBnkStsMDao.selectConnectivityStatus(any())).thenReturn(comBnkStsMOut);
		// 테스트 대상 메서드 호출
		bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT");
	}

	@Test
	@Order(10)
	void getConnectivtyValidation_ValidBizDvsnCd_IFT_2() {

		String bnkCd = "057";
		String bizDvsnCd = "IFT";

		// 모의(mock) 데이터 설정
		ComBnkStsMOut comBnkStsMOut = new ComBnkStsMOut();
		comBnkStsMOut.setBnkCd(bnkCd);
		comBnkStsMOut.setBizDvsnCd(bizDvsnCd);
		comBnkStsMOut.setBnkStsCd("01");
		comBnkStsMOut.setKtfcNetStatus("000");
		comBnkStsMOut.setJpmcNetStatus("999");
		comBnkStsMOut.setBnkNetStatus("000");

		when(comBnkStsMDao.selectConnectivityStatus(any())).thenReturn(comBnkStsMOut);
		// 테스트 대상 메서드 호출
		bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT");
	}

	@Test
	@Order(10)
	void getConnectivtyValidation_ValidBizDvsnCd_IFT_3() {

		String bnkCd = "057";
		String bizDvsnCd = "IFT";

		// 모의(mock) 데이터 설정
		ComBnkStsMOut comBnkStsMOut = new ComBnkStsMOut();
		comBnkStsMOut.setBnkCd(bnkCd);
		comBnkStsMOut.setBizDvsnCd(bizDvsnCd);
		comBnkStsMOut.setBnkStsCd("01");
		comBnkStsMOut.setKtfcNetStatus("000");
		comBnkStsMOut.setJpmcNetStatus("000");
		comBnkStsMOut.setBnkNetStatus("999");

		when(comBnkStsMDao.selectConnectivityStatus(any())).thenReturn(comBnkStsMOut);
		// 테스트 대상 메서드 호출
		bizCom.getConnectivtyValidation(bnkCd, bizDvsnCd, "KFT");
	}

	@Test
	@Order(16)
	void getNumbering_validInput_bizDvsnCd_NullInput() {

		// Arrange
		String bizDvsnCd = "";
		String nbrgId = "";
		assertThrows(BusinessException.class, () -> bizCom.getNumbering(bizDvsnCd, nbrgId));
	}

	@Test
	@Order(16)
	void getNumbering_validInput_nbrgId_NullInput() {

		// Arrange
		String bizDvsnCd = "11";
		String nbrgId = "";

		assertThrows(BusinessException.class, () -> bizCom.getNumbering(bizDvsnCd, nbrgId));
	}

	@Test
	@Order(16)
	@DisplayName("getNumbering_validInput_ReturnsFormattedNumber")
	void getNumbering_validInput_ReturnsFormattedNumber() {

		// Arrange
		String bizDvsnCd = "IFT";
		String nbrgId = "IFTKFT01";

		// Mocking database behavior
		ComNbrgM comNbrgM = new ComNbrgM();
		comNbrgM.setNbrgNo("000001");

		when(comNbrgMDao.selectListComNbrgM(any())).thenReturn(comNbrgM);
		// Mocking database update behavior
		when(comNbrgMDao.updateComNbrgM(any())).thenReturn(1);
		// Act
		bizCom.getNumbering(bizDvsnCd, nbrgId);
	}

	@Test
	@Order(16)
	@DisplayName("getNumbering_validInput_ReturnsFormattedNumber")
	void getNumbering_validInput_ReturnsFormattedNumber_2() {

		// Arrange
		String bizDvsnCd = "IFT";
		String nbrgId = "IFTKFT01";

		// Mocking database behavior
		ComNbrgM comNbrgM = new ComNbrgM();
		comNbrgM.setNbrgNo("000001");

		when(comNbrgMDao.selectListComNbrgM(any())).thenReturn(null);
		// Mocking database update behavior
		//when(comNbrgMDao.updateComNbrgM(any())).thenReturn(1);
		// Act
		assertThrows(BusinessException.class, () -> bizCom.getNumbering(bizDvsnCd, nbrgId));
	}

	@Test
	@Order(16)
	void getNumbering_validInput_ReturnsFormattedNumber_3() {

		// Arrange
		String bizDvsnCd = "IFT";
		String nbrgId = "IFTKFT02";

		// Mocking database behavior
		ComNbrgM comNbrgM = new ComNbrgM();
		comNbrgM.setNbrgNo("000002");

		when(comNbrgMDao.selectListComNbrgM(any())).thenReturn(comNbrgM);
		// Mocking database update behavior
		//when(comNbrgMDao.updateComNbrgM(any())).thenReturn(1);
		// Act
		assertThrows(BusinessException.class, () -> bizCom.getNumbering(bizDvsnCd, nbrgId));
	}

	@Test
	@Order(16)
	void getNumbering_validInput_ReturnsFormattedNumber_4() {

		// Arrange
		String bizDvsnCd = "IFT";
		String nbrgId = "COMSEQ01";

		// Mocking database behavior
		ComNbrgM comNbrgM = new ComNbrgM();
		comNbrgM.setNbrgNo("000002");

		when(comNbrgMDao.selectListComNbrgM(any())).thenReturn(comNbrgM);

		when(comNbrgMDao.selectComTrHoldSeq(any())).thenReturn((long) 100);
		// Act
		//        assertThrows(BusinessException.class, () -> bizCom.getNumbering(bizDvsnCd, nbrgId));
		bizCom.getNumbering(bizDvsnCd, nbrgId);
	}

	@Test
	@Order(1)
	@DisplayName("getRespCode validMsgId")
	void getRespCode_validMsgId() {

		String hostCd = "KFT";
		String bizDvsnCd = "HBK";
		String respCd = "4289";
		ComRespCdM comRespCdM = new ComRespCdM();
		comRespCdM.setHostCd(hostCd);
		comRespCdM.setBizDvsnCd(bizDvsnCd);
		comRespCdM.setRespCd(respCd);
		comRespCdM.setMsgId("RPHBK04289");

		when(comRespCdMMapper.selectByPrimaryKey(hostCd, bizDvsnCd, respCd)).thenReturn(comRespCdM);
		//        when(comRespCdMDao.selectComRespCd(any())).thenReturn(comRespCdM);

		bizCom.getRespCode(hostCd, bizDvsnCd, respCd);
		//assertThrows(BusinessException.class, () -> bizCom.getRespCode(hostCd,bizDvsnCd,respCd));

	}

	//	@Test
	//	@Order(1)
	//	@DisplayName("getRespCode validMsgId")
	//	void getRespCode_validMsgId_2() {
	//
	//		String hostCd = "KFT";
	//		String bizDvsnCd = "HBK";
	//		String respCd = "4289";
	//		String msgId = "RPHBK04289";
	//		ComRespCdM comRespCdM = new ComRespCdM();
	//		comRespCdM.setHostCd(hostCd);
	//		comRespCdM.setBizDvsnCd(bizDvsnCd);
	//		comRespCdM.setRespCd(respCd);
	//		comRespCdM.setMsgId("RPHBK04289");
	//
	//		when(comRespCdMMapper.selectByPrimaryKey(hostCd, bizDvsnCd, respCd)).thenReturn(null);
	//		//when(comRespCdMDao.selectComRespCd(any())).thenReturn(comRespCdM);
	//
	//		//bizCom.getRespCode(hostCd,bizDvsnCd,respCd);
	//		assertThrows(BusinessException.class, () -> bizCom.getRespCode(hostCd, bizDvsnCd, respCd));
	//
	//	}

	@Test
	@Order(1)
	@DisplayName("getRespCode validMsgId")
	void getRespCode_validMsgId_3() {

		String hostCd = "";
		String bizDvsnCd = "HBK";
		String respCd = "4289";
		ComRespCdM comRespCdM = new ComRespCdM();
		comRespCdM.setHostCd(hostCd);
		comRespCdM.setBizDvsnCd(bizDvsnCd);
		comRespCdM.setRespCd(respCd);
		comRespCdM.setMsgId("RPHBK04289");

		//when(comRespCdMMapper.selectByPrimaryKey(hostCd, bizDvsnCd, respCd)).thenReturn(null);
		//when(comRespCdMDao.selectComRespCd(any())).thenReturn(comRespCdM);

		//bizCom.getRespCode(hostCd,bizDvsnCd,respCd);
		assertThrows(BusinessException.class, () -> bizCom.getRespCode(hostCd, bizDvsnCd, respCd));

	}

	@Test
	@Order(1)
	void updateBank_NullChk_1() {

		String bnkCd = "";
		String status = "01";
		int idx = 1;
		String extTime = "1030";
		String bizDvsnCd = "01";

		assertThrows(BusinessException.class,
				() -> bizCom.updateBank(bnkCd, status, idx, extTime, bizDvsnCd));
	}

	@Test
	@Order(1)
	void updateBank_1() {

		String bnkCd = "001;002;003";
		String status = "01";
		int idx = 1;
		String extTime = "1030";
		String bizDvsnCd = "01";

		assertThrows(BusinessException.class,
				() -> bizCom.updateBank(bnkCd, status, idx, extTime, bizDvsnCd));
	}

	@Test
	@Order(1)
	void updateBank_2() {

		String bnkCd = "000;";
		String status = "01";
		int idx = 1;
		String extTime = "1030";
		String bizDvsnCd = "01";

		//		when(comBnkStsMDao.updateAllBnkStat(any())).thenReturn(1);
		assertThrows(BusinessException.class,
				() -> bizCom.updateBank(bnkCd, status, idx, extTime, bizDvsnCd));
	}

	@Test
	@Order(1)
	void updateBank_3() {

		String bnkCd = "001;";
		String status = "01";
		int idx = 9;
		String extTime = "1030";
		String bizDvsnCd = "01";

		//when(comBnkStsMDao.updateAllBnkStat(any())).thenReturn(1);
		bizCom.updateBank(bnkCd, status, idx, extTime, bizDvsnCd);
		//assertThrows(BusinessException.class, () -> bizCom.updateBank(bnkCd,status,idx,extTime,bizDvsnCd));
	}

	@Test
	public void testGetNHAcctBnkCd() throws BusinessException {
		
		ComBnkCdM out = new ComBnkCdM();
		out.setKftcBnkCd("011");
		
		when(comBnkCdMMapper.selectByPrimaryKey("011")).thenReturn(out);
		
		out.setKftcBnkCd("012");
		when(comBnkCdMMapper.selectByPrimaryKey("012")).thenReturn(out);
//		bizCom.getNHAcctBnkCd("004", "12345669012345");
		
		// 11자리 계좌번호 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "12345678901"),
				"11자리 계좌는 농협은행 코드 011이어야 합니다.");

		// 12자리 계좌번호 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "123456789012"),
				"12자리 계좌는 농협은행 코드 011이어야 합니다.");

		// 10자리 계좌번호 - 마지막 8 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "1234567898"),
				"10자리 계좌의 마지막이 8이면 농협은행 코드 011이어야 합니다.");

		// 10자리 계좌번호 - 마지막 9 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "1234567899"),
				"10자리 계좌의 마지막이 9이면 지역농협 코드 012이어야 합니다.");

		// 13자리 계좌번호 - 마지막 1 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "1234567890121"),
				"13자리 계좌의 마지막이 1이면 농협은행 코드 011이어야 합니다.");

		// 13자리 계좌번호 - 마지막 2 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "1234567890122"),
				"13자리 계좌의 마지막이 1이면 농협은행 코드 011이어야 합니다.");

		// 13자리 계좌번호 - 마지막 3 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "1234567890123"),
				"13자리 계좌의 마지막이 3이면 지역농협 코드 012이어야 합니다.");
		// 13자리 계좌번호 - 마지막 4 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "1234567890124"),
				"13자리 계좌의 마지막이 3이면 지역농협 코드 012이어야 합니다.");
		// 13자리 계좌번호 - 마지막 5 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "1234567890125"),
				"13자리 계좌의 마지막이 3이면 지역농협 코드 012이어야 합니다.");
		// 13자리 계좌번호 - 마지막 8 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "1234567890128"),
				"13자리 계좌의 마지막이 3이면 지역농협 코드 012이어야 합니다.");
		// 13자리 계좌번호 - 마지막 9 - 농협은행
		assertEquals("012", bizCom.getNHAcctBnkCd("012", "1234567890129"),
				"13자리 계좌의 마지막이 3이면 지역농협 코드 012이어야 합니다.");

		// 14자리 계좌번호 - 앞자리 790 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "79012345678901"),
				"14자리 계좌의 앞자리 790이면 농협은행 코드 011이어야 합니다.");
		// 14자리 계좌번호 - 앞자리 791 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "79112345678901"),
				"14자리 계좌의 앞자리 790이면 농협은행 코드 011이어야 합니다."); 

		// 14자리 계좌번호 - 앞자리 792 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "79212345678901"),
				"14자리 계좌의 앞자리 792이면 지역농협 코드 012이어야 합니다.");

		// 14자리 계좌번호 - 중간 64 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "12345664012345"),
				"14자리 계좌의 중간이 64이면 농협은행 코드 011이어야 합니다.");
		// 14자리 계좌번호 - 중간 65 - 농협은행
		assertEquals("011", bizCom.getNHAcctBnkCd("011", "12345665012345"),
				"14자리 계좌의 중간이 64이면 농협은행 코드 011이어야 합니다.");

		// 14자리 계좌번호 - 중간 66 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "12345666012345"),
				"14자리 계좌의 중간이 66이면 지역농협 코드 012이어야 합니다.");
		// 14자리 계좌번호 - 중간 67 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "12345667012345"),
				"14자리 계좌의 중간이 66이면 지역농협 코드 012이어야 합니다.");
		// 14자리 계좌번호 - 중간 69 - 지역농협
		assertEquals("012", bizCom.getNHAcctBnkCd("011", "12345669012345"),
				"14자리 계좌의 중간이 66이면 지역농협 코드 012이어야 합니다.");

		//		assertThrows(BusinessException.class, () -> {
		//			bizCom.getNHAcctBnkCd("011", "1234566901234500");
		//		});

	}

	@Test
	void checkChequeStatus_Test() {
		// Test case for invalid inputs
		CheckChequeStatusIn inInvalid = new CheckChequeStatusIn();
		inInvalid.setChequeTp("");
		inInvalid.setChequeNo("");
		inInvalid.setChequeKindCd("");
		inInvalid.setIssueDt("");
		inInvalid.setChequeAmt(BigDecimal.ONE);
		assertThrows(BusinessException.class,
				() -> bizCom.checkChequeStatus(inInvalid, "IFT", "KFT"));

		// Test case for valid input with cheque status "00" and matching issue date and amount
		CheckChequeStatusIn inValid = new CheckChequeStatusIn();
		inValid.setChequeTp("00");
		inValid.setChequeNo("123456789");
		inValid.setChequeKindCd("11235");
		inValid.setIssueDt("240612");
		inValid.setChequeAmt(BigDecimal.ONE);
		inValid.setChequeBranchCd("0570006");
		ComChequeInfoMgmtM selectOutValid = new ComChequeInfoMgmtM();
		selectOutValid.setChequeStsCd("00");
		selectOutValid.setIssueDt("20240612");
		selectOutValid.setChequeAmt(BigDecimal.ONE);
		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(selectOutValid);

		String respCdValid = bizCom.checkChequeStatus(inValid, "KFT", "IFT");
		assertEquals("000", respCdValid);  // Successful processing

		// Test case for cheque status "00" with non-matching issue date
		CheckChequeStatusIn inInvalidIssueDate = new CheckChequeStatusIn();
		inInvalidIssueDate.setChequeTp("00");
		inInvalidIssueDate.setChequeNo("123456789");
		inInvalidIssueDate.setChequeKindCd("11235");
		inInvalidIssueDate.setIssueDt("240613");  // Invalid date format
		inInvalidIssueDate.setChequeAmt(BigDecimal.ONE);

		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(selectOutValid);
		String respCdInvalidDate = bizCom.checkChequeStatus(inInvalidIssueDate, "KFT", "IFT");
		assertEquals("506", respCdInvalidDate); // "미발행 수표"

		// Test case for cheque status "00" with non-matching branch code
		inInvalidIssueDate.setIssueDt("240612");  // Invalid date format
		inInvalidIssueDate.setChequeBranchCd("0570007");  // Adding branch code
		String respCdInvalidBranch = bizCom.checkChequeStatus(inInvalidIssueDate, "KFT", "IFT");
		assertEquals("506", respCdInvalidBranch); // "미발행 수표"

		// 수표금액 상이
		selectOutValid.setChequeAmt(BigDecimal.ZERO);
		inInvalidIssueDate.setChequeBranchCd("0570006");
		String respCdInvalidChequeAmt = bizCom.checkChequeStatus(inInvalidIssueDate, "KFT", "IFT");
		assertEquals("503", respCdInvalidChequeAmt); // "미발행 수표"

		// Test case for cheque status "09" (지급 수표)
		ComChequeInfoMgmtM selectOutChequeStatus09 = new ComChequeInfoMgmtM();
		selectOutChequeStatus09.setChequeStsCd("09");
		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(selectOutChequeStatus09);
		String respCd09 = bizCom.checkChequeStatus(inValid, "KFT", "IFT");
		assertEquals("505", respCd09); // "지급 수표"

		// Test case for cheque status "04" (부도 수표)
		ComChequeInfoMgmtM selectOutChequeStatus04 = new ComChequeInfoMgmtM();
		selectOutChequeStatus04.setChequeStsCd("04");
		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(selectOutChequeStatus04);
		String respCd04 = bizCom.checkChequeStatus(inValid, "KFT", "IFT");
		assertEquals("508", respCd04); // "부도 수표"

		// Test case for unknown cheque status
		ComChequeInfoMgmtM selectOutUnknownStatus = new ComChequeInfoMgmtM();
		selectOutUnknownStatus.setChequeStsCd("XX");
		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(selectOutUnknownStatus);
		String respCdUnknown = bizCom.checkChequeStatus(inValid, "KFT", "IFT");
		assertEquals("506", respCdUnknown); // "미발행 수표"

		// Test case for unknown cheque status
		when(comChequeInfoMgmtMDao.selectComChequeInfoMgmtM(any(ComChequeInfoMgmtM.class)))
				.thenReturn(null);
		String selectNull = bizCom.checkChequeStatus(inValid, "KFT", "IFT");
		assertEquals("506", selectNull); // "미발행 수표"
	}

	@Test
	void test_returns_mapped_response_code_when_mapping_exists() {
		String mapHostCd = "LVB";
		String bizDvsnCd = "IFT";
		String respCd = "100";
		ComRespCdMapM comRespCdMapM = new ComRespCdMapM();
		comRespCdMapM.setMapRespCd("200");
		when(comRespCdMapMDao.selectResponseCodeMapping(any(ComRespCdMapM.class)))
				.thenReturn(comRespCdMapM);

		String result = bizCom.getRespCdMap(mapHostCd, bizDvsnCd, respCd);

		assertEquals("200", result);
	}

	@Test
	void test_returns_representative_response_code_when_mapping_does_not_exist() {
		String mapHostCd = "LVB";
		String bizDvsnCd = "IFT";
		String respCd = "100";
		when(comRespCdMapMDao.selectResponseCodeMapping(any(ComRespCdMapM.class))).thenReturn(null);
		when(comRespCdMDao.selectRepRespCd(any(ComRespCdM.class))).thenReturn("300");

		String result = bizCom.getRespCdMap(mapHostCd, bizDvsnCd, respCd);

		assertEquals("300", result);
	}

	@Test
	void test_throws_business_exception_when_any_parameter_is_empty() {
		bizCom.getRespCdMap("", "IFT", "100");

		//		assertThrows(BusinessException.class, () -> {
		//			bizCom.getRespCdMap("LVB", "", "100");
		//		});
		//
		//		assertThrows(BusinessException.class, () -> {
		//			bizCom.getRespCdMap("LVB", "IFT", "");
		//		});
	}

	@Test
	void test_throws_business_exception_when_no_mapped_or_representative_response_code_found() {
		String mapHostCd = "LVB";
		String bizDvsnCd = "IFT";
		String respCd = "100";
		when(comRespCdMapMDao.selectResponseCodeMapping(any(ComRespCdMapM.class))).thenReturn(null);
		when(comRespCdMDao.selectRepRespCd(any(ComRespCdM.class))).thenReturn(null);

		//        assertThrows(BusinessException.class, () -> {
		bizCom.getRespCdMap(mapHostCd, bizDvsnCd, respCd);
		//        });
	}

	@Test
	public void testCreateHoldTransaction() {
		// Arrange
		ComTrHoldL holdIn = new ComTrHoldL();
		holdIn.setBizDvsnCd("IFT");
		holdIn.setOutinDvsnCd("002");
		holdIn.setTlgKndDvsnCd("0100"); // Change this value as necessary
		holdIn.setTlgTrDvsnCd("004");
		holdIn.setHostNo("123456");
		holdIn.setTrUnqNo("654321");
		holdIn.setRcvBnkCd("003");
		holdIn.setRcvAcctNo("789012");
		holdIn.setWhdrwlBnkCd("004");
		holdIn.setWhdrwlNm("Test Name");
		holdIn.setSndrRealNm("Real Sender");
		holdIn.setRqerInfo("Requester Info");
		holdIn.setTrAmt(new BigDecimal("1000"));
		holdIn.setHoldRsnCd("Reason Code");

		when(frwContext.getTlgCtt()).thenReturn("Transaction Content");
		//		when(frwContext.getOrgnTlgCtt()).thenReturn("Original Transaction Content");
		when(frwContext.getTractId()).thenReturn("12345");
		when(frwContext.getUsrId()).thenReturn("testUser");
		
		//		BizCom yourServiceSpy = spy(bizCom);
		//	    doReturn("000001").when(yourServiceSpy).getNumbering(holdIn.getBizDvsnCd(), NumberingEnum.COMSEQ01.toString());

		//		when(bizCom.getNumbering(holdIn.getBizDvsnCd(), NumberingEnum.COMSEQ01.toString()))
		//				.thenReturn("000001");

		// Act
		bizCom.createHoldTransaction(frwContext, holdIn);

		// Assert
	}

	@Test
	void testUpdateAllBnkStsStart_01() {

		String bizDvsnCd = BizDvsnCdEnum.IFT.getValue();

		bizCom.updateAllBnkStsStart(bizDvsnCd);

		// 2. 검증: comBnkStsMDao.updateAllBnkStat가 호출되었는지 검증
		verify(comBnkStsMDao, times(1)).updateAllBnkStat(any(ComBnkStsM.class));

		// 3. 검증: comBnkStsMDao.updateAllBnkStsStart가 호출되었는지 검증
		verify(comBnkStsMDao, times(1)).updateAllBnkStsStart(any(ComBnkStsM.class));
	}

	@Test
	void testUpdateMaxNumId_01() {

		// 테스트용 Enum 값 및 keyNo 설정
		String bizDvsnCd = BizDvsnCdEnum.IFT.getValue();
		String nbrgId = NumberingEnum.IFTKFT01.getName();
		String keyNo = "0001";

		// 반환될 Mock 객체 설정
		ComNbrgM nbrgIn = new ComNbrgM();
		nbrgIn.setBizDvsnCd(bizDvsnCd);
		nbrgIn.setNbrgId(nbrgId);
		nbrgIn.setNbrgNo("000001");  // NbrgNo 초기화

		// selectListComNbrgM에서 반환할 Mock 객체 설정
		ComNbrgM nbrgOut = new ComNbrgM();
		nbrgOut.setBizDvsnCd(bizDvsnCd);
		nbrgOut.setNbrgId(nbrgId);
		nbrgOut.setNbrgNo("000002");  // Mock 데이터로 반환할 NbrgNo 설정

		// 1. DAO에서 selectListComNbrgM 호출 시 Mock 객체를 반환하도록 설정
		doReturn(nbrgOut).when(comNbrgMDao).selectListComNbrgM(any(ComNbrgM.class));

		// 2. 테스트 대상 메서드 호출
		bizCom.updateMaxNumId(bizDvsnCd, NumberingEnum.IFTKFT01, keyNo);

		// 3. 검증: 반환된 NbrgNo 값을 검증하고 업데이트 되는지 확인
		// nbrgOut의 NbrgNo가 실제로 업데이트되었는지 확인
		int tableMaxNum = Integer.parseInt(nbrgOut.getNbrgNo()); // 변경된 nbrgOut의 nbrgNo를 사용
		int msgMaxNum = Integer.parseInt(keyNo) + 1; // keyNo를 정수로 파싱하여 사용
		int nextExpectedNo = tableMaxNum <= msgMaxNum ? msgMaxNum : tableMaxNum;

		// 기대되는 새로운 NbrgNo 값
		String expectedNbrgNo = String.format(NumberingEnum.IFTKFT01.getFormat(), nextExpectedNo);

		// 검증: NbrgNo 값이 예상한 값으로 업데이트 되었는지 확인
		assertEquals(expectedNbrgNo, nbrgOut.getNbrgNo());

		// 4. 검증: comNbrgMDao.updateComNbrgM이 호출되었는지 확인
		verify(comNbrgMDao, times(1)).updateComNbrgM(nbrgOut);
	}

	@Test
	public void testUpdateMaxNumId_02() {

		// 테스트용 Enum 값 및 keyNo 설정
		String nbrgId = NumberingEnum.IFTKFT01.getName();
		String keyNo = "0001";

		String bizDvsnCd = BizDvsnCdEnum.IFT.getValue();
		ComNbrgM nbrgIn = new ComNbrgM();
		nbrgIn.setBizDvsnCd(bizDvsnCd);
		nbrgIn.setNbrgId(nbrgId);

		// 1. Mock 설정: DAO에서 반환하는 값이 null인 경우
		when(comNbrgMDao.selectListComNbrgM(any(ComNbrgM.class))).thenReturn(null);

		// 2. 테스트 대상 메서드 호출
		bizCom.updateMaxNumId(bizDvsnCd, NumberingEnum.IFTKFT01, keyNo);
		// 3. 검증: comNbrgMDao.updateComNbrgM이 호출되지 않았는지 확인 (null이므로)
		verify(comNbrgMDao, never()).updateComNbrgM(any(ComNbrgM.class));

	}

	

	@Test
	void testGetAcctNoToKftcFormat() {

		String hostAcctNo = "000123456789";
		bizCom.getAcctNoToKftcFormat(hostAcctNo);

		hostAcctNo = "123456789";
		bizCom.getAcctNoToKftcFormat(hostAcctNo);

		hostAcctNo = "";
		bizCom.getAcctNoToKftcFormat(hostAcctNo);

		hostAcctNo = "111123456789";
		bizCom.getAcctNoToKftcFormat(hostAcctNo);
	}

	@Test
	void testGetHofOracleSeqNo() {
		
		when(comNbrgMDao.selectHofTrUnqNoSeq()).thenReturn(1L);
		String trUnqNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01);
		assertEquals("00000001", trUnqNo);
		
		when(comNbrgMDao.selectHofMsgNoSeq()).thenReturn(5L);
		String msgNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFLVB01);
		assertEquals("00000005", msgNo);
		
	}
	
	@Test
	public void testCreateHoldTransEaction2_KCGServiceHour() {
	    when(frwContext.getTlgCtt()).thenReturn("Transaction Content");
	    when(frwContext.getTractId()).thenReturn("12345");
	    when(frwContext.getUsrId()).thenReturn("testUser");
	    when(bizDate.getNextBizDay(anyString(), anyInt())).thenReturn("20250327");

	    // KCG_SERVICE_HOUR 테스트
	    ComTrHoldL holdIn = new ComTrHoldL();
	    holdIn.setBizDvsnCd("IFT");
	    holdIn.setOutinDvsnCd("002");
	    holdIn.setTlgKndDvsnCd("0100");
	    holdIn.setTlgTrDvsnCd("004");
	    holdIn.setHostNo("123456");
	    holdIn.setTrUnqNo("654321");
	    holdIn.setRcvBnkCd("003");
	    holdIn.setRcvAcctNo("789012");
	    holdIn.setWhdrwlBnkCd("004");
	    holdIn.setWhdrwlNm("Test Name");
	    holdIn.setSndrRealNm("Real Sender");
	    holdIn.setRqerInfo("Requester Info");
	    holdIn.setTrAmt(new BigDecimal("1000"));
	    holdIn.setHoldRsnCd(HoldRsnCdEnum.KCG_SERVICE_HOUR.getCode());
	    
	    // Mocking the service time
	    ComCdD comCdD = new ComCdD();
	    comCdD.setSubCdChar1("10:00");
	    when(comCdDMapper.selectByPrimaryKey(anyString(), anyString())).thenReturn(comCdD);

	    // Act
	    bizCom.createHoldTransaction(frwContext, holdIn);
	    String today = LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter());
	    // Assert
	    assertEquals(today, holdIn.getRelsStaDt());  // 익영업일
	    assertEquals("100000", holdIn.getRelsStaTm());    // 당발 영업일시
	}

	@Test
	public void testCreateHoldTransEaction2_Holiday() {
	    when(frwContext.getTlgCtt()).thenReturn("Transaction Content");
	    when(frwContext.getTractId()).thenReturn("12345");
	    when(frwContext.getUsrId()).thenReturn("testUser");
	    when(bizDate.getNextBizDay(anyString(), anyInt())).thenReturn("20250327");

	    // HOLIDAY 테스트
	    ComTrHoldL holdIn = new ComTrHoldL();
	    holdIn.setBizDvsnCd("IFT");
	    holdIn.setOutinDvsnCd("002");
	    holdIn.setTlgKndDvsnCd("0100");
	    holdIn.setTlgTrDvsnCd("004");
	    holdIn.setHostNo("123456");
	    holdIn.setTrUnqNo("654321");
	    holdIn.setRcvBnkCd("003");
	    holdIn.setRcvAcctNo("789012");
	    holdIn.setWhdrwlBnkCd("004");
	    holdIn.setWhdrwlNm("Test Name");
	    holdIn.setSndrRealNm("Real Sender");
	    holdIn.setRqerInfo("Requester Info");
	    holdIn.setTrAmt(new BigDecimal("1000"));
	    holdIn.setHoldRsnCd(HoldRsnCdEnum.HOLIDAY.getCode());
	    
	    // Mocking the service time
	    ComCdD comCdD = new ComCdD();
	    comCdD.setSubCdChar1("10:00");
	    when(comCdDMapper.selectByPrimaryKey(anyString(), anyString())).thenReturn(comCdD);

	    // Act
	    bizCom.createHoldTransaction(frwContext, holdIn);

	    // Assert
	    assertEquals("20250327", holdIn.getRelsStaDt());  // 익영업일
	    assertEquals("100000", holdIn.getRelsStaTm());    // 타발 영업일시
	}

	@Test
	public void testCreateHoldTransEaction2_AccountServiceHour() {
	    when(frwContext.getTlgCtt()).thenReturn("Transaction Content");
	    when(frwContext.getTractId()).thenReturn("12345");
	    when(frwContext.getUsrId()).thenReturn("testUser");
	    when(bizDate.getNextBizDay(anyString(), anyInt())).thenReturn("20250327");

	    // ACCOUNT_SERVICE_HOUR 테스트
	    ComTrHoldL holdIn = new ComTrHoldL();
	    holdIn.setBizDvsnCd("IFT");
	    holdIn.setOutinDvsnCd("002");
	    holdIn.setTlgKndDvsnCd("0100");
	    holdIn.setTlgTrDvsnCd("004");
	    holdIn.setHostNo("123456");
	    holdIn.setTrUnqNo("654321");
	    holdIn.setRcvBnkCd("003");
	    holdIn.setRcvAcctNo("789012");
	    holdIn.setWhdrwlBnkCd("004");
	    holdIn.setWhdrwlNm("Test Name");
	    holdIn.setSndrRealNm("Real Sender");
	    holdIn.setRqerInfo("Requester Info");
	    holdIn.setTrAmt(new BigDecimal("1000"));
	    holdIn.setHoldRsnCd(HoldRsnCdEnum.ACCOUNT_SERVICE_HOUR.getCode());
	    
	    // Mocking release target list
	    ComTrHoldL comTrHoldL = new ComTrHoldL();
	    comTrHoldL.setRcvAcctNo(holdIn.getWhdrwlAcctNo());
	    
	    // Mocking release target time
	    ComTrHoldL releaseTraget = new ComTrHoldL();
	    releaseTraget.setRelsStaTm("100000");
	    List<ComTrHoldL> releaseTragetList = Collections.singletonList(releaseTraget);
	    when(comTrHoldLDao.selectAcctStatmReleaseTarget(any())).thenReturn(releaseTragetList);

	    // Act
	    bizCom.createHoldTransaction(frwContext, holdIn);

	    String today = LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter());
	    // Assert
	    assertEquals(today, holdIn.getRelsStaDt());  // 익영업일
	    assertEquals("100000", holdIn.getRelsStaTm());    // 당발 영업일시
	}
	
    @Test
    void testValidBankCodeWithAllEnums() {
        // given
        String bnkCd = "001";
        List<BizDvsnCdEnum> enums = Arrays.asList(
                BizDvsnCdEnum.HOF, BizDvsnCdEnum.HBK,
                BizDvsnCdEnum.IFT, BizDvsnCdEnum.RPR,
                BizDvsnCdEnum.CMS, BizDvsnCdEnum.ENT
        );

        ComBnkCdM validBank = new ComBnkCdM();
        validBank.setBnkCd(bnkCd);

        when(comBnkCdMDao.selectComBnkCdList(any(ComBnkCdM.class)))
                .thenReturn(Collections.singletonList(validBank));

        // when
        boolean result = bizCom.getBankCodeValidation(bnkCd, enums);

        // then
        assertTrue(result);
    }

    @Test
    void testInvalidBankCodeWhenListIsEmpty() {
        String bnkCd = "002";
        List<BizDvsnCdEnum> enums = Collections.singletonList(BizDvsnCdEnum.HOF);

        when(comBnkCdMDao.selectComBnkCdList(any(ComBnkCdM.class)))
                .thenReturn(Collections.emptyList());

        boolean result = bizCom.getBankCodeValidation(bnkCd, enums);

        assertFalse(result);
    }

    @Test
    void testInvalidBankCodeWhenBnkCdIsBlank() {
        String bnkCd = "003";
        List<BizDvsnCdEnum> enums = Collections.singletonList(BizDvsnCdEnum.HBK);

        ComBnkCdM invalidBank = new ComBnkCdM();
        invalidBank.setBnkCd(""); // blank value

        when(comBnkCdMDao.selectComBnkCdList(any(ComBnkCdM.class)))
                .thenReturn(Collections.singletonList(invalidBank));

        boolean result = bizCom.getBankCodeValidation(bnkCd, enums);

        assertFalse(result);
    }

    @Test
    void testUnhandledEnumLogsWarning() {
        String bnkCd = "004";
        List<BizDvsnCdEnum> enums = Collections.singletonList(BizDvsnCdEnum.valueOf("SCM"));

        when(comBnkCdMDao.selectComBnkCdList(any(ComBnkCdM.class)))
                .thenReturn(Collections.emptyList());

        boolean result = bizCom.getBankCodeValidation(bnkCd, enums);

        assertFalse(result); // default branch
        // 로그 관련 검증은 로그 framework에 따라 별도 검증 가능
    }

    @Test
    void testEmptyEnumList() {
        String bnkCd = "005";
        List<BizDvsnCdEnum> enums = Collections.emptyList();

        ComBnkCdM bank = new ComBnkCdM();
        bank.setBnkCd("005");

        when(comBnkCdMDao.selectComBnkCdList(any(ComBnkCdM.class)))
                .thenReturn(Collections.singletonList(bank));

        boolean result = bizCom.getBankCodeValidation(bnkCd, enums);

        assertTrue(result);
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    @Test
    void testSetComHoldStatusDone_01() {

    	String hostNo = "";

    	BusinessException exception = assertThrows(BusinessException.class, () -> {
    		bizCom.setComHoldStatusDone(hostNo);
    	});
    }

    @Test
    void testSetComHoldStatusDone_02() {

    	String hostNo = "00000008";

    	ComTrHoldL result = new ComTrHoldL();
    	result.setTrDt("20240816");
    	result.setTrSeq(10L);
    	result.setHoldRsnCd("05");
    	result.setHoldStsCd("02");
    	when(comTrHoldLDao.selectHoldingTrByKeyValue(hostNo, null)).thenReturn(result);
    	when(comTrHoldLDao.updateHoldStatus(any(ComTrHoldL.class))).thenReturn(1);

    	bizCom.setComHoldStatusDone(hostNo);

    	// 4. 검증: comNbrgMDao.updateComNbrgM이 호출되었는지 확인
    	verify(comTrHoldLDao, times(1)).selectHoldingTrByKeyValue(hostNo, null);

    }

    @Test
    void testSetComHoldStatusDone_03() {

    	String hostNo = "00000008";

    	ComTrHoldL result = new ComTrHoldL();
    	result.setTrDt("20240816");
    	result.setTrSeq(10L);
    	result.setHoldRsnCd("05");
    	result.setHoldStsCd("02");
    	when(comTrHoldLDao.selectHoldingTrByKeyValue(hostNo, null)).thenReturn(null);

    	bizCom.setComHoldStatusDone(hostNo);

    	// 4. 검증: comNbrgMDao.updateComNbrgM이 호출되었는지 확인
    	verify(comTrHoldLDao, times(1)).selectHoldingTrByKeyValue(hostNo, null);
    	verify(comTrHoldLDao, never()).updateHoldStatus(result);

    }

    @Test
    void testSetComHoldStatusDone_04() {

    	 String keyValue = "12345678ABCDEFGHIJKLM"; // 21자리 값
    		String hostNo = "12345678";
    		String trUnqNo = "ABCDEFGHIJKLM";
    		
    		ComTrHoldL mockHoldingTr = new ComTrHoldL();
    		mockHoldingTr.setTrDt("20250326");
    		mockHoldingTr.setTrSeq(1L);
    		mockHoldingTr.setHoldRsnCd("01");
    		
    		when(comTrHoldLDao.selectHoldingTrByKeyValue(hostNo, null)).thenReturn(mockHoldingTr);
    		
    		bizCom.setComHoldStatusDone(keyValue);
    		
    		verify(comTrHoldLDao, times(1)).selectHoldingTrByKeyValue(hostNo, null);
    		verify(comTrHoldLDao, never()).updateHoldStatus(mockHoldingTr);

    }



    @Test
    void testSetComHoldStatusDoneTrDt_01() {

    	String hostNo = "";

    	BusinessException exception = assertThrows(BusinessException.class, () -> {
    		bizCom.setComHoldStatusDone(hostNo, "20250101");
    	});
    }

    @Test
    void testSetComHoldStatusDoneTrDt_02() {

    	String hostNo = "00000008";
    	String trDt = "20250101";
    	
    	ComTrHoldL result = new ComTrHoldL();
    	result.setTrDt("20250101");
    	result.setTrSeq(10L);
    	result.setHoldRsnCd("05");
    	result.setHoldStsCd("02");
    	when(comTrHoldLDao.selectHoldingTrByKeyValue(hostNo, trDt)).thenReturn(result);
    	when(comTrHoldLDao.updateHoldStatus(any(ComTrHoldL.class))).thenReturn(1);

    	bizCom.setComHoldStatusDone(hostNo, trDt);

    	// 4. 검증: comNbrgMDao.updateComNbrgM이 호출되었는지 확인
    	verify(comTrHoldLDao, times(1)).selectHoldingTrByKeyValue(hostNo, trDt);

    }

    @Test
    void testSetComHoldStatusDoneTrDt_03() {

    	String hostNo = "00000008";
    	String trDt = "20250101";
    	ComTrHoldL result = new ComTrHoldL();
    	result.setTrDt("20250101");
    	result.setTrSeq(10L);
    	result.setHoldRsnCd("05");
    	result.setHoldStsCd("02");
    	when(comTrHoldLDao.selectHoldingTrByKeyValue(hostNo, trDt)).thenReturn(null);

    	bizCom.setComHoldStatusDone(hostNo, trDt);

    	// 4. 검증: comNbrgMDao.updateComNbrgM이 호출되었는지 확인
    	verify(comTrHoldLDao, times(1)).selectHoldingTrByKeyValue(hostNo, trDt);
    	verify(comTrHoldLDao, never()).updateHoldStatus(result);

    }

    @Test
    void testSetComHoldStatusDone_ShouldNotUpdateHoldStatus_WhenHoldingTrDoesNotExist() {
    	ComTrHoldL input = new ComTrHoldL();
    	input.setTrDt("20250326");
    	input.setTrSeq(1L);
    	
    	when(comTrHoldLDao.selectHoldingTr(any(ComTrHoldL.class))).thenReturn(null);
    	
    	ComTrHoldLIn input2 = new ComTrHoldLIn();
    	input2.setTrDt("20250326");
    	input2.setSelTrUnqNo("1111");
    	
    	bizCom.setComHoldStatusDone(input2);
    	
    	verify(comTrHoldLDao, never()).updateHoldStatus(any());
    }

    @Test
    void testSetComHoldStatusDone_ShouldUpdateHoldStatus_WhenHoldingTrExists() {
    	ComTrHoldL input = new ComTrHoldL();
    	input.setTrDt("20250326");
    	input.setTrSeq(1L);
    	input.setHostNo("05700001");

    	ComTrHoldL mockHoldingTr = new ComTrHoldL();
    	mockHoldingTr.setTrDt("20250326");
    	mockHoldingTr.setTrSeq(1L);
    	mockHoldingTr.setHoldRsnCd("01");
    	mockHoldingTr.setHoldStsCd("01");

    	when(comTrHoldLDao.selectHoldingTr(any(ComTrHoldL.class))).thenReturn(mockHoldingTr);
    	when(comTrHoldLDao.updateHoldStatus(any(ComTrHoldL.class))).thenReturn(1);
    	
    	ComTrHoldLIn input2 = new ComTrHoldLIn();
    	input2.setTrDt("20250326");
    	input2.setSelTrUnqNo("1111");
    	
    	bizCom.setComHoldStatusDone(input2);
    	
    }

    // 1. 대기 거래 없음 (holdingTr == null)
    @Test
    void testSetComHoldStatusDone_noHoldingTransaction() {
    	ComTrHoldLIn input = new ComTrHoldLIn();
    	input.setTrDt("20250408");
    	input.setHostNo("H001");
    	input.setSelTrUnqNo("TR001");

    	Mockito.when(comTrHoldLDao.selectHoldingTr(Mockito.any())).thenReturn(null);

    	ComTrHoldL result = bizCom.setComHoldStatusDone(input);

    	Assertions.assertNull(result); // 대기 거래가 없으면 null 리턴
    }

    // 2. 동일한 대기사유코드 존재 (isUpdate == false)
    @Test
    void testSetComHoldStatusDone_sameHoldReasonCode() {
    	ComTrHoldLIn input = new ComTrHoldLIn();
    	input.setTrDt("20250408");
    	input.setHostNo("H001");
    	input.setSelTrUnqNo("TR001");
    	input.setHoldRsnCd("HR01");

    	ComTrHoldL existingHold = new ComTrHoldL();
    	existingHold.setTrDt("20250408");
    	existingHold.setTrSeq(3L);
    	existingHold.setHoldRsnCd("HR01");  // 동일한 코드

    	Mockito.when(comTrHoldLDao.selectHoldingTr(Mockito.any())).thenReturn(existingHold);

    	ComTrHoldL result = bizCom.setComHoldStatusDone(input);

    	Mockito.verify(comTrHoldLDao, Mockito.never()).updateHoldStatus(Mockito.any());
    	Assertions.assertEquals(existingHold, result);
    }

    // 3. 다른 대기사유코드 (isUpdate == true) → 상태 '02'로 업데이트
    @Test
    void testSetComHoldStatusDone_updateStatusToRelease() {
    	// Arrange
    	ComTrHoldLIn input = new ComTrHoldLIn();
    	input.setTrDt("20250408");
    	input.setHostNo("H001");
    	input.setSelTrUnqNo("TR001");
    	input.setHoldRsnCd("NEW_CODE"); // 다른 코드
    	input.setUpTrUnqNo("TR999");
    	input.setRespCd("999");

    	ComTrHoldL holdingTr = new ComTrHoldL();
    	holdingTr.setTrDt("20250408");
    	holdingTr.setTrSeq(3L);
    	holdingTr.setHoldRsnCd("OLD_CODE"); // 서로 다르게 설정하여 update 조건 만족

    	when(comTrHoldLDao.selectHoldingTr(any())).thenReturn(holdingTr);
    	when(comTrHoldLDao.updateHoldStatus(any())).thenReturn(1);
    	// Act
    	ComTrHoldL result = bizCom.setComHoldStatusDone(input);

    }
}