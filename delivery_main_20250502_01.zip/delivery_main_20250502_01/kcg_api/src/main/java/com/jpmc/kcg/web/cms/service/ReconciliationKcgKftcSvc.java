package com.jpmc.kcg.web.cms.service;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.jpmc.kcg.cms.biz.vo.KftCmsEB00R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB21R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB22R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB23R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB31R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB32R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB34R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB35R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEC21R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEC22R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEC23R;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.utils.constant.CCMN01;
import com.jpmc.kcg.web.cms.constants.CmsConstant;
import com.jpmc.kcg.web.cms.dao.CmsSndRcvFileLWebDao;
import com.jpmc.kcg.web.cms.dto.CmsSndRcvFileLWeb;
import com.jpmc.kcg.web.cms.service.dto.CountEB2030FeeDataOut;
import com.jpmc.kcg.web.cms.service.dto.ReconciliationKcgKftcIn;
import com.jpmc.kcg.web.cms.service.dto.ReconciliationKcgKftcOut;
import com.jpmc.kcg.web.com.constants.BCMN01;
import com.jpmc.kcg.web.utils.CpgObjectUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ReconciliationKcgKftcSvc {
	@Autowired
	private CmsSndRcvFileLWebDao cmsSndRcvFileLWebDao;
	
	@Autowired
	private BizDate bizDate;
	
	public ReconciliationKcgKftcOut getReconciliationKCGKFTC(ReconciliationKcgKftcIn in) {
		log.debug("ReconciliationKcgKftcSvc getReconciliationKcgKftc In Dto : {}", in);
       
		// Validate input parameters
	    CpgObjectUtils.isDtoValid(in, "trDt");
	    
        ReconciliationKcgKftcOut out = ReconciliationKcgKftcOut.builder().rsltCode(BCMN01.SUCCESS).build();
        
        // 날짜 세팅
	    String mmdd = DateUtils.formatDate(DateTimeFormatter.ofPattern(DateFormat.MMDD.getPattern()), in.getTrDt()); // trDt의 mmdd
	    String preBizDt = bizDate.getPrevWorkingDay(in.getTrDt(), 1); //전영업일
	    String preMmdd = StringUtils.substring(preBizDt, 4, 8); //전영업일의 mmdd
        CmsSndRcvFileLWeb selectIn = new CmsSndRcvFileLWeb();
        selectIn.setTrDt(in.getTrDt());
        selectIn.setMmdd(mmdd);
        selectIn.setPreBizDt(preBizDt);
        selectIn.setPreMmdd(preMmdd);
        
        //KFTC 데이터
        _getKftcData(out, selectIn);
        
        //KCG 데이터
        _getKcgData(out, selectIn, mmdd, preMmdd);
        
        //KCG (입금내역-수수료) 데이터
        _getKcgFeeData(out, selectIn);

		return out;
	}
	
	private void _getKcgData(ReconciliationKcgKftcOut out, CmsSndRcvFileLWeb selectIn, String mmdd, String preMmdd) {
        BigDecimal debitTrferWhdrwlAmtKcg;
        BigDecimal debitTrferWhdrwlAmtKcgA = BigDecimal.ZERO;
        BigDecimal debitTrferWhdrwlAmtKcgB = BigDecimal.ZERO;
//        long debitTrferWhdrwlAmtKcgC = 0;
        BigDecimal crditTrWhdrwlFeeKcg;
        BigDecimal crditTrWhdrwlFeeKcgA = BigDecimal.ZERO;
        BigDecimal crditTrWhdrwlFeeKcgB = BigDecimal.ZERO;
        BigDecimal dailyDebitTrWhdrwlAmtKcg;
        BigDecimal dailyDebitTrWhdrwlAmtKcgA = BigDecimal.ZERO;
        BigDecimal dailyDebitTrWhdrwlAmtKcgB = BigDecimal.ZERO;
//        long dailyDebitTrWhdrwlAmtKcgC = 0;
        BigDecimal debitTrferDepositAmtKcg = BigDecimal.ZERO;
        BigDecimal debitTrferWhdrwlFeeKcg = BigDecimal.ZERO;
        BigDecimal crditTrDepositAmtKcg = BigDecimal.ZERO;
        BigDecimal crditTrFailWhdrwlsAmtKcg = BigDecimal.ZERO;
        BigDecimal crditTrWhdrwlAmtKcg = BigDecimal.ZERO;
        BigDecimal crditTrFailDepositKcg = BigDecimal.ZERO;
        BigDecimal dailyDebitTrDepositAmtKcg = BigDecimal.ZERO;
        BigDecimal dailyDebitTrWhdrwlFeeKcg = BigDecimal.ZERO;
        
		List<CmsSndRcvFileLWeb> outList = cmsSndRcvFileLWebDao.selectEB2030List(selectIn);
		
        for (CmsSndRcvFileLWeb data : outList) {
        	
        	if (data.getFileNm().equals(CmsConstant.EB21 + preMmdd)) {
        		KftCmsEB21R voOutEB21 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB21R.class);
        		debitTrferWhdrwlAmtKcgA = debitTrferWhdrwlAmtKcgA.add(BigDecimal.valueOf(voOutEB21.getRequestedWithdrawalAmount()));
        	} else if (data.getFileNm().equals(CmsConstant.EB22 + preMmdd)) {
            	KftCmsEB22R voOutEB22 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB22R.class);
            	if (CpgObjectUtils.nullSafeEquals(voOutEB22.getWithdrawalResultWithdrawalYn(), CCMN01.N)) {
            		debitTrferWhdrwlAmtKcgB = debitTrferWhdrwlAmtKcgB.add(BigDecimal.valueOf(voOutEB22.getFailedWithdrawalAmount()));
            	}
//        	} else if (data.getFileNm().equals("EB22" + preMmdd)) {
//            	KftCmsEB22R voOutEB22 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB22R.class);
//            	if (CpgObjectUtils.nullSafeEquals(voOutEB22.getWithdrawalResultWithdrawalYn(), "N")) {
//            		if (!CpgObjectUtils.nullSafeEquals(voOutEB22.getWithdrawalType(), "0")) {
//            			debitTrferWhdrwlAmtKcgB = voOutEB22.getFailedWithdrawalAmount();
//            		} else {
//            			debitTrferWhdrwlAmtKcgC = voOutEB22.getFailedWithdrawalAmount();
//            		}
//            	}
        	} else if (data.getFileNm().equals(CmsConstant.EB23 + preMmdd)) {
        		KftCmsEB23R voOutEB23 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB23R.class);
        		debitTrferDepositAmtKcg = debitTrferDepositAmtKcg.add(BigDecimal.valueOf(voOutEB23.getAmountOfTotalWithdrawals()));
        		debitTrferWhdrwlFeeKcg = debitTrferWhdrwlFeeKcg.add(BigDecimal.valueOf(voOutEB23.getWithdrawalBankFee()));
        	} else if (data.getFileNm().equals(CmsConstant.EB31 + mmdd)) {
        		KftCmsEB31R voOutEB31 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB31R.class);
        		crditTrDepositAmtKcg = crditTrDepositAmtKcg.add(BigDecimal.valueOf(voOutEB31.getDepositAmount()));
        	} else if (data.getFileNm().equals(CmsConstant.EB32 + preMmdd)) {
        		KftCmsEB32R voOutEB32 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB32R.class);
        		if (CpgObjectUtils.nullSafeEquals(voOutEB32.getDepositResultDepositYn(), CCMN01.N)
        				&& !CpgObjectUtils.nullSafeEquals(voOutEB32.getDepositResultFailedCode(), CmsConstant.DPST_RSLT_FAIL_CD_000)) {
        			crditTrFailWhdrwlsAmtKcg = crditTrFailWhdrwlsAmtKcg.add(BigDecimal.valueOf(voOutEB32.getDepositAmount()));
        		}
        	} else if (data.getFileNm().equals(CmsConstant.EB34 + mmdd)) {
        		KftCmsEB34R voOutEB34 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB34R.class);
        		if (CpgObjectUtils.nullSafeEquals(voOutEB34.getWithdrawalResultWithdrawalYn(), CCMN01.Y)
        				&& CpgObjectUtils.nullSafeEquals(voOutEB34.getWithdrawalResultFailedCode(), CmsConstant.WHDRWL_RSLT_FAIL_CD_0000)) {
        			crditTrWhdrwlAmtKcg = crditTrWhdrwlAmtKcg.add(BigDecimal.valueOf(voOutEB34.getWithdrawalAmount()));
        		}
        	} else if (data.getFileNm().equals(CmsConstant.EB34 + preMmdd)) {
        		KftCmsEB34R voOutEB34 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB34R.class);
        		if (CpgObjectUtils.nullSafeEquals(voOutEB34.getWithdrawalResultWithdrawalYn(), CCMN01.Y)
        				&& CpgObjectUtils.nullSafeEquals(voOutEB34.getWithdrawalResultFailedCode(), CmsConstant.WHDRWL_RSLT_FAIL_CD_0000)) {
        			crditTrWhdrwlFeeKcgA = crditTrWhdrwlFeeKcgA.add(BigDecimal.valueOf(voOutEB34.getRequestedWithdrawalCount()));
        		}
        	} else if (data.getFileNm().equals(CmsConstant.EB35 + preMmdd)) {
            	KftCmsEB35R voOutEB35 = VOUtils.toVo(data.getTlgCtt(), KftCmsEB35R.class);
            	crditTrWhdrwlFeeKcgB = crditTrWhdrwlFeeKcgB.add(BigDecimal.valueOf(voOutEB35.getFailedDepositCount()));
            	crditTrFailDepositKcg = crditTrFailDepositKcg.add(BigDecimal.valueOf(voOutEB35.getFailedDepositAmount()));
        	} else if (data.getFileNm().equals(CmsConstant.EC21 + preMmdd)) {
            	KftCmsEC21R voOutEC21 = VOUtils.toVo(data.getTlgCtt(), KftCmsEC21R.class);
            	dailyDebitTrWhdrwlAmtKcgA = dailyDebitTrWhdrwlAmtKcgA.add(BigDecimal.valueOf(voOutEC21.getRequestedWithdrawalAmount()));
        	} else if (data.getFileNm().equals(CmsConstant.EC22 + preMmdd)) {
        		KftCmsEC22R voOutEC22 = VOUtils.toVo(data.getTlgCtt(), KftCmsEC22R.class);
        		if (CpgObjectUtils.nullSafeEquals(voOutEC22.getWithdrawalResultWithdrawalYn(), CCMN01.N)) {
        			dailyDebitTrWhdrwlAmtKcgB = dailyDebitTrWhdrwlAmtKcgB.add(BigDecimal.valueOf(voOutEC22.getRequestedWithdrawalAmount()));
        		}
//        	} else if (data.getFileNm().equals("EC22" + preMmdd)) {
//        		KftCmsEC22R voOutEC22 = VOUtils.toVo(data.getTlgCtt(), KftCmsEC22R.class);
//        		if (CpgObjectUtils.nullSafeEquals(voOutEC22.getWithdrawalResultWithdrawalYn(), "N")) {
//        			if (!CpgObjectUtils.nullSafeEquals(voOutEC22.getWithdrawalType(), "0")) {
//        				dailyDebitTrWhdrwlAmtKcgB = voOutEC22.getFailedWithdrawalAmount();
//        			} else {
//        				dailyDebitTrWhdrwlAmtKcgC = voOutEC22.getFailedWithdrawalAmount();
//        			}
//        		}
        	} else if (data.getFileNm().equals(CmsConstant.EC23 + preMmdd)) {
            	KftCmsEC23R voOutEC23 = VOUtils.toVo(data.getTlgCtt(), KftCmsEC23R.class);
            	dailyDebitTrDepositAmtKcg = dailyDebitTrDepositAmtKcg.add(BigDecimal.valueOf(voOutEC23.getAmountOfTotalWithdrawals()));
            	dailyDebitTrWhdrwlFeeKcg = dailyDebitTrWhdrwlFeeKcg.add(BigDecimal.valueOf(voOutEC23.getWithdrawalBankFee()));
        	}
        }
        
        out.setDebitTrferDepositAmtKcg(debitTrferDepositAmtKcg);
        out.setDebitTrferWhdrwlFeeKcg(debitTrferWhdrwlFeeKcg);
		out.setCrditTrDepositAmtKcg(crditTrDepositAmtKcg);
		out.setCrditTrFailWhdrwlsAmtKcg(crditTrFailWhdrwlsAmtKcg);
		out.setCrditTrWhdrwlAmtKcg(crditTrWhdrwlAmtKcg);
		out.setCrditTrFailDepositKcg(crditTrFailDepositKcg);
		out.setDailyDebitTrDepositAmtKcg(dailyDebitTrDepositAmtKcg);
		out.setDailyDebitTrWhdrwlFeeKcg(dailyDebitTrWhdrwlFeeKcg);
        
		//KCG 출금이체 출금내역 출금액 = a - b
    	debitTrferWhdrwlAmtKcg = debitTrferWhdrwlAmtKcgA.subtract(debitTrferWhdrwlAmtKcgB);
//    	debitTrferWhdrwlAmtKcg = debitTrferWhdrwlAmtKcgA - debitTrferWhdrwlAmtKcgB - debitTrferWhdrwlAmtKcgC;
    	out.setDebitTrferWhdrwlAmtKcg(debitTrferWhdrwlAmtKcg);
    	
    	//KCG 입금이체 출금내역 수수료 = (a - b) * 100
    	crditTrWhdrwlFeeKcg = crditTrWhdrwlFeeKcgA.subtract(crditTrWhdrwlFeeKcgB).multiply(new BigDecimal(100));
    	out.setCrditTrWhdrwlFeeKcg(crditTrWhdrwlFeeKcg);
    	
    	//KCG 당일출금이체 출금내역 출금액 = a - b
    	dailyDebitTrWhdrwlAmtKcg = dailyDebitTrWhdrwlAmtKcgA.subtract(dailyDebitTrWhdrwlAmtKcgB);
//    	dailyDebitTrWhdrwlAmtKcg = dailyDebitTrWhdrwlAmtKcgA - dailyDebitTrWhdrwlAmtKcgB - dailyDebitTrWhdrwlAmtKcgC;
    	out.setDailyDebitTrWhdrwlAmtKcg(dailyDebitTrWhdrwlAmtKcg);
		
	}

	private void _getKcgFeeData(ReconciliationKcgKftcOut out, CmsSndRcvFileLWeb selectIn) {
		BigDecimal debitTrferDepositFeeKcg;
		BigDecimal crditTrDepositFeeKcg;
		BigDecimal dailyDebitTrDepositFeeKcg;
        
        CountEB2030FeeDataOut feeData = cmsSndRcvFileLWebDao.countEB2030FeeData(selectIn);
        
        if (!CpgObjectUtils.isEmpty(feeData)) {
	        //KCG 출금이체 입금내역 수수료 = ((a * 20) + (a - b) * 120) + c * 60
        	debitTrferDepositFeeKcg = ((feeData.getDebitTrferDepositFeeKcgA().multiply(new BigDecimal(20)))
        			.add((feeData.getDebitTrferDepositFeeKcgA().subtract(feeData.getDebitTrferDepositFeeKcgB())).multiply(new BigDecimal(120)))
        			.add(feeData.getDebitTrferDepositFeeKcgC().multiply(new BigDecimal(60))));
	        out.setDebitTrferDepositFeeKcg(debitTrferDepositFeeKcg);
	        
	        //KCG 입금이체 입금내역 수수료 = (a - b) * 100
	        crditTrDepositFeeKcg= (feeData.getCrditTrDepositFeeKcgA().subtract(feeData.getCrditTrDepositFeeKcgB())).multiply(new BigDecimal(100));
	        out.setCrditTrDepositFeeKcg(crditTrDepositFeeKcg);
	        
	        //KCG 당일출금이체 입금내역 수수료 = ((a * 40) + (a - b) * 260) + c * 80
	        dailyDebitTrDepositFeeKcg = ((feeData.getDailyDebitTrDepositFeeKcgA().multiply(new BigDecimal(40)))
	        		.add((feeData.getDailyDebitTrDepositFeeKcgA().subtract(feeData.getDailyDebitTrDepositFeeKcgB())).multiply(new BigDecimal(260)))
	        		.add(feeData.getDailyDebitTrDepositFeeKcgC().multiply(new BigDecimal(80))));
	        out.setDailyDebitTrDepositFeeKcg(dailyDebitTrDepositFeeKcg);
        }
	}

	private void _getKftcData(ReconciliationKcgKftcOut out, CmsSndRcvFileLWeb selectIn) {
		List<CmsSndRcvFileLWeb> outList = cmsSndRcvFileLWebDao.selectEB00List(selectIn);
        
        if (CollectionUtils.isEmpty(outList)) {
            return;
        }
        
        for (CmsSndRcvFileLWeb data : outList) {
        	KftCmsEB00R voOut = VOUtils.toVo(data.getTlgCtt(), KftCmsEB00R.class);
        	String settlementOrderTypeCode = voOut.getSettlementOrderTypeCode();
        	
        	switch(settlementOrderTypeCode) {
	        	case CmsConstant.EB20 : {
	        		out.setDebitTrferDepositAmtKftc(BigDecimal.valueOf(voOut.getDepositDetailsAmount()));
	            	out.setDebitTrferDepositFeeKftc(BigDecimal.valueOf(voOut.getDepositDetailsFee()));
	            	out.setDebitTrferWhdrwlAmtKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsAmount()));
	            	out.setDebitTrferWhdrwlFeeKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsFee()));
	            	break;
	        	}
	        	case CmsConstant.EB30 : {
	        		out.setCrditTrDepositAmtKftc(BigDecimal.valueOf(voOut.getDepositDetailsAmount()));
	        		out.setCrditTrDepositFeeKftc(BigDecimal.valueOf(voOut.getDepositDetailsFee()));
	        		out.setCrditTrFailDepositKftc(BigDecimal.valueOf(voOut.getDepositDetailsFailed()));
	        		out.setCrditTrWhdrwlAmtKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsAmount()));
	        		out.setCrditTrWhdrwlFeeKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsFee()));
	        		out.setCrditTrFailWhdrwlsAmtKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsFailed()));
	        		break;
	        	}
	        	case CmsConstant.EB60 : {
	        		out.setDailyDebitTrDepositAmtKftc(BigDecimal.valueOf(voOut.getDepositDetailsAmount()));
	            	out.setDailyDebitTrDepositFeeKftc(BigDecimal.valueOf(voOut.getDepositDetailsFee()));
	            	out.setDailyDebitTrWhdrwlAmtKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsAmount()));
	            	out.setDailyDebitTrWhdrwlFeeKftc(BigDecimal.valueOf(voOut.getWithdrawalDetailsFee()));
	            	break;
	        	}
	        	default : {
	        		break;
	        	}
        	}
        }        
	}
}
