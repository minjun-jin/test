package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 시스템장애응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 전자어음시스템을 구분하기 위해'EBS'사용
 * bnkCd 은행코드 
 * messageType 전문종별코드 0810
 * transactionCode 거래구분코드 000004
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * bnkCd1 은행코드 
 * issueRecoveringBankCode 장애(회복)은행코드 
 * paymentPresentationExtensionTime 지급제시통보연장시각 
 * extensionReason 연장사유 
 * 
 * KftEnt0810000004 kftEnt0810000004 = new KftEnt0810000004(); // 시스템장애응답
 * kftEnt0810000004.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0810000004.setSystemId("EBS"); // 시스템-ID
 * kftEnt0810000004.setBnkCd("057"); // 은행코드
 * kftEnt0810000004.setMessageType("0810"); // 전문종별코드
 * kftEnt0810000004.setTransactionCode("000004"); // 거래구분코드
 * kftEnt0810000004.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0810000004.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0810000004.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0810000004.setStatus("000"); // STATUS
 * kftEnt0810000004.setResponseCode1(""); // 응답코드1
 * kftEnt0810000004.setResponseCode2(""); // 응답코드2
 * kftEnt0810000004.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0810000004.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0810000004.setBnkCd1(""); // 은행코드
 * kftEnt0810000004.setIssueRecoveringBankCode(""); // 장애(회복)은행코드
 * kftEnt0810000004.setPaymentPresentationExtensionTime(""); // 지급제시통보연장시각
 * kftEnt0810000004.setExtensionReason(""); // 연장사유
 * }</pre>
 */
@Data
public class KftEnt0810000004 implements KftEntMngHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0810"; // 전문종별코드
	private String transactionCode = "000004"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String bnkCd1; // 은행코드
	private String issueRecoveringBankCode; // 장애(회복)은행코드
	private String paymentPresentationExtensionTime; // 지급제시통보연장시각
	private String extensionReason; // 연장사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd1$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issueRecoveringBankCode$; // 장애(회복)은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationExtensionTime$; // 지급제시통보연장시각
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String extensionReason$; // 연장사유

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		bnkCd1$ = VOUtils.write(out, bnkCd1, 3); // 은행코드
		issueRecoveringBankCode$ = VOUtils.write(out, issueRecoveringBankCode, 3); // 장애(회복)은행코드
		paymentPresentationExtensionTime$ = VOUtils.write(out, paymentPresentationExtensionTime, 4); // 지급제시통보연장시각
		extensionReason$ = VOUtils.write(out, extensionReason, 2); // 연장사유
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		bnkCd1 = VOUtils.toString(bnkCd1$ = VOUtils.read(in, 3)); // 은행코드
		issueRecoveringBankCode = VOUtils.toString(issueRecoveringBankCode$ = VOUtils.read(in, 3)); // 장애(회복)은행코드
		paymentPresentationExtensionTime = VOUtils.toString(paymentPresentationExtensionTime$ = VOUtils.read(in, 4)); // 지급제시통보연장시각
		extensionReason = VOUtils.toString(extensionReason$ = VOUtils.read(in, 2)); // 연장사유
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", bnkCd1=").append(bnkCd1).append(System.lineSeparator()); // 은행코드
		sb.append(", issueRecoveringBankCode=").append(issueRecoveringBankCode).append(System.lineSeparator()); // 장애(회복)은행코드
		sb.append(", paymentPresentationExtensionTime=").append(paymentPresentationExtensionTime).append(System.lineSeparator()); // 지급제시통보연장시각
		sb.append(", extensionReason=").append(extensionReason).append(System.lineSeparator()); // 연장사유
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0810"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "000004"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "bnkCd1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issueRecoveringBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "paymentPresentationExtensionTime", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "extensionReason", "fldLen", "2", "defltVal", "")
		);
	}

}
