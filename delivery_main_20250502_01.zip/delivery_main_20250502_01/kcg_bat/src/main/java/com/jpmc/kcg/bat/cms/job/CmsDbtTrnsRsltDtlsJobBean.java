package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;
import static com.jpmc.kcg.cms.enums.CmsWhdrwlSts.NORMAL;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.bat.ChunkBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.bat.cms.biz.CmsSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dao.BatCmsSndRcvFileLDao;
import com.jpmc.kcg.bat.cms.dao.BatCmsWhdrwlTrnAplyMDao;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.cms.dto.BatCmsDbtTrnsRqstRsltVo;
import com.jpmc.kcg.bat.com.biz.ComFileTractLBean;
import com.jpmc.kcg.bat.utils.ExtFileProcessor;
import com.jpmc.kcg.cms.biz.vo.*;
import com.jpmc.kcg.cms.constants.CmsConst;
import com.jpmc.kcg.cms.dao.CmsCorpTotLMapper;
import com.jpmc.kcg.cms.dto.CmsCorpTotL;
import com.jpmc.kcg.cms.dto.CmsSndRcvFileL;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.cms.enums.CmsPrcsStsDvsnCdEnum;
import com.jpmc.kcg.cms.enums.CmsWhdrwlSts;
import com.jpmc.kcg.cms.enums.CmsWhdrwlType;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.Mac;
import com.jpmc.kcg.frw.SystemProperties;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.frw.bat.BatResourceHolder;

import lombok.extern.slf4j.Slf4j;

/**
 * EB22 (출금이체신청) 출금의뢰 결과내역
 * 출금 이체 처리 (출금불능 or 부분출금분만 send)
 */
@Component
@Slf4j
public class CmsDbtTrnsRsltDtlsJobBean extends ChunkBatJob<CmsSndRcvFileL, BatCmsDbtTrnsRqstRsltVo> {

    private final BatCmsSndRcvFileLDao batCmsSndRcvFileLDao;
    private final BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao;
    private final CmsCorpTotLMapper cmsCorpTotLMapper;
    private final ComFileTractLBean comFileTractLBean;
    private final CmsCom cmsCom;

    private final ExtFileProcessor fileProcessor;
    private final SystemProperties systemProperties;
    private final CmsSndRcvLogManager cmsSndRcvLogManager;

    public CmsDbtTrnsRsltDtlsJobBean(BatCmsSndRcvFileLDao batCmsSndRcvFileLDao
            , BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao, CmsCorpTotLMapper cmsCorpTotLMapper
            , ComFileTractLBean comFileTractLBean, CmsCom cmsCom, ExtFileProcessor fileProcessor
            , SystemProperties systemProperties, CmsSndRcvLogManager cmsSndRcvLogManager) {
        this.batCmsSndRcvFileLDao = batCmsSndRcvFileLDao;
        this.batCmsWhdrwlTrnAplyMDao = batCmsWhdrwlTrnAplyMDao;
        this.cmsCorpTotLMapper = cmsCorpTotLMapper;
        this.comFileTractLBean = comFileTractLBean;
        this.cmsCom = cmsCom;

        this.fileProcessor = fileProcessor;
        this.systemProperties = systemProperties;
        this.cmsSndRcvLogManager = cmsSndRcvLogManager;
    }

    @Override
    protected void beforeJob(BatContext batContext) {
        // 파라미터 초기화
        BatCmsContextVo cmsContextVo = new BatCmsContextVo();
        cmsContextVo.initializeContext(batContext, EB21, EB22);

        // 맥 설정
        String macKey1 = systemProperties.getMac().getKey1();
        String macKey2 = systemProperties.getMac().getKey2();
        Mac mac = new Mac(macKey1, macKey2);

        // BatContext에 CMS Context, 집계용 변수 저장
        batContext.setData(FILE_NO, EB22);
        batContext.setData(CMS_CONTEXT, cmsContextVo);
        batContext.setData(MAC, mac);
        batContext.setData(SEQ, 0);                         // EB22 생성 총 건수

        batContext.setData(NORMAL_COUNT, 0);                // 정상 건수
        batContext.setData(NORMAL_AMOUNT, BigDecimal.ZERO);     // 정상금액
        batContext.setData(ERROR_COUNT, 0);                 // 에러 총건수
        batContext.setData(ERROR_AMOUNT, BigDecimal.ZERO);      // 총 에러 금액

        batContext.setData(FULL_ERR_COUNT, 0);              // 전액출금 불능처리건수
        batContext.setData(FULL_ERR_AMOUNT, BigDecimal.ZERO);   // 전액출금 에러금액
        batContext.setData(PART_COUNT, 0);                  // 부분출금 건수
        batContext.setData(PART_AMOUNT, BigDecimal.ZERO);       // 부분출금금액
        batContext.setData(PART_ERR_COUNT, 0);              // 부분출금 에러건수
        batContext.setData(PART_ERR_AMOUNT, BigDecimal.ZERO);   // 부분출금 에러금액

        batContext.setData(PART_NORMAL_AMOUNT, BigDecimal.ZERO); // 부불출금액 (실출금액)
        batContext.setData(PART_INVALID_AMOUNT, BigDecimal.ZERO);// 부분출금시 출금불능금액

        batContext.setData(PROCESSING_FEE, 0L);             // 실제 수수료
        batContext.setData(BANK_FEE, 0L);                   // 수수료
        batContext.setData(ERROR_FEE, 0L);                  // 에러 수수료

        long targetEB21Count = cmsSndRcvLogManager.getCountReceivedFilesData(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        batContext.setData(TOT_RECORD_COUNT, targetEB21Count);  // EB21 의뢰 데이터 총 건수

        /*
         * EB21의 H, T 상태 업데이트
         */
        if (targetEB21Count > 0L) {
            cmsSndRcvLogManager.updateHeaderTrailerProcessStatus(cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        }
        
        /*
         * 중복 데이터 삭제
         */
        cmsSndRcvLogManager.deleteDuplicateList(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getTargetFileNm());
        super.beforeJob(batContext);
    }

    @Override
    protected long targetTotalCount(BatContext batContext) {
        log.debug(" ##### targetTotalCount start  ######");
        return (long)batContext.getData(TOT_RECORD_COUNT);
    }

    @Override
    protected Iterator<CmsSndRcvFileL> openReader(BatContext batContext) {
        log.debug(" ##### openReader start ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        /*
         * 파일 수신 데이터 조회
         */
        List<CmsSndRcvFileL> receivedFiles = cmsSndRcvLogManager.getReceivedFilesData(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        return receivedFiles.iterator();
    }

    @Override
    protected OutputStream openWriter(BatContext batContext) {
        log.debug(" ##### openWriter ######");
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        // EB21 header data 조회
        CmsSndRcvFileL header = cmsSndRcvLogManager.getReceivedFilesHeader(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());

        if(header == null) {
            // 파일 수신 데이터가 없습니다. {} 파일 수신 후 시도해주세요.
            throw new BusinessException("MCMNE06029", cmsContextVo.getSourceFileNm());
        }
        
        OutputStream outputStream = fileProcessor.openOutputStream(cmsContextVo.getTargetFileNm());

        // record가 null이어도 Header 작성
        processHeader(outputStream, cmsContextVo, batContext, header);
        return outputStream;
    }

    // Header 데이터 만들기
    private String processHeader(OutputStream outputStream, BatCmsContextVo cmsContextVo, BatContext batContext, CmsSndRcvFileL header) {
        KftCmsEB21H kftCmsEB21H = VOUtils.toVo(header.getTlgCtt(), KftCmsEB21H.class);
        String withdrawalDate = ObjectUtils.defaultIfNull(kftCmsEB21H.getWithdrawalDate(), ""); // yyMMdd

        // EB22 header 생성
        KftCmsEB22H kftCmsEB22H  = new KftCmsEB22H(); // 출금이체의뢰 불능내역
        kftCmsEB22H.setRecordType           ( CmsConst.HEADER_H              ); // Record 구분
        kftCmsEB22H.setSerialNumber         ( CmsConst.HEADER_SEQ            ); // 일련번호
        kftCmsEB22H.setInstitutionCode      ( CmsConst.COR_JPMC              ); // 기관코드
        kftCmsEB22H.setWithdrawalDate       ( withdrawalDate                 ); // EB21의 처리일자
        kftCmsEB22H.setMainBankBranchCode   ( ""                             ); // filler
        kftCmsEB22H.setFileName             ( cmsContextVo.getTargetFileNm() ); // File 이름

        //////////////////////////////////////////////////////////////////
        String message = VOUtils.toString(kftCmsEB22H);

        fileProcessor.append(outputStream, message);
        //////////////////////////////////////////////////////////////////

        /*
         * EB22 파일 데이터를 파일 송수신내역에 insert
         */
        cmsSndRcvLogManager.insertSndFileHeader(cmsContextVo.getTargetFileNm(), message, cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), batContext.getBatId());

        return message;
    }

    @Override
    protected BatCmsDbtTrnsRqstRsltVo process(CmsSndRcvFileL cmsSndRcvFileL) {
        BatContext batContext = (BatContext) FrwContextHolder.getContext();

        KftCmsEB21R kftCmsEB21R = VOUtils.toVo(cmsSndRcvFileL.getTlgCtt(), KftCmsEB21R.class);

        String respCd         = cmsCom.getResultResponseCode(cmsSndRcvFileL); // 0000 외에는 전부 불능코드로
        CmsWhdrwlSts respFlag = cmsCom.getResultResponseFlag(cmsSndRcvFileL, respCd);  // 전액출금, 출금불능인지 확인

        // 결과상태에 따라 원전문 및 불능코드 update
        updateResponseInfo(cmsSndRcvFileL, kftCmsEB21R, respFlag, respCd);

        BigDecimal failedWithdrawalAmount = BigDecimal.ZERO;
        BigDecimal requestedWithdrawalAmount = BigDecimal.valueOf(kftCmsEB21R.getRequestedWithdrawalAmount()); // 요청금애

        // 상태에 따른 집계 및 금액 누적
        switch (respFlag) {
            case NORMAL:
                // 정상출금 처리
                batContext.setData(NORMAL_COUNT, (int)batContext.getData(NORMAL_COUNT) + 1 );
                batContext.setData(NORMAL_AMOUNT, ((BigDecimal)batContext.getData(NORMAL_AMOUNT)).add(requestedWithdrawalAmount));

                log.debug("[INFO]    NORMAL COUNT        : [{}]", batContext.getData(NORMAL_COUNT));
                log.debug("[INFO]    NORMAL AMOUNT       : [{}]", batContext.getData(NORMAL_AMOUNT));
                break;
            case PARTIAL:
                // 부분출금 처리
                batContext.setData(SEQ, (int)batContext.getData(SEQ) + 1 ); // 총건수(sequence)
                batContext.setData(PART_COUNT, (int)batContext.getData(PART_COUNT) + 1 ); // 부분출금미처리 건수 증가

                /*
                 * 부분출금액 (실출금액)에 합계: 요청 금액에서 실출금액을 빼서 남은 부분출금 금액 계산
                 */
                BigDecimal partialProcessedAmt = cmsSndRcvFileL.getRealPrcsAmt(); // 실제 부분출금 처리된 금액
                batContext.setData(PART_AMOUNT, ((BigDecimal)batContext.getData(PART_AMOUNT)).add(partialProcessedAmt)); // 부분 출금액 

                /*
                 * 부분출금하고 남은 미출금 금액 (요청 금액에서 실출금액 뺀 금액) 합계
                 */
                failedWithdrawalAmount = requestedWithdrawalAmount.subtract(partialProcessedAmt); // 남은 부분출금 금액

                // 출금불능금액에 부분출금액에 남은 부분출금금액 추가
                batContext.setData(PART_INVALID_AMOUNT, ((BigDecimal)batContext.getData(PART_INVALID_AMOUNT)).add(failedWithdrawalAmount));

                log.debug("[INFO]    PARTIAL AMOUNT      : [{}]", batContext.getData(PART_AMOUNT));
                log.debug("[INFO]    PARTIAL REMAIN AMT  : [{}]", batContext.getData(PART_INVALID_AMOUNT));
                break;
            case FAILED:
                // 불능 처리
                batContext.setData(SEQ, (int)batContext.getData(SEQ) + 1 ); // 총건수(sequence)
                
                failedWithdrawalAmount = requestedWithdrawalAmount; // 전액출금인 경우, EB21의 금액, 아닌 경우 출금의뢰금액-실출금액

                /*
                 * 총 에러금액 합계
                 */
                batContext.setData(ERROR_COUNT, (int)batContext.getData(ERROR_COUNT) + 1 ); // 총불능건수
                batContext.setData(ERROR_AMOUNT, ((BigDecimal)batContext.getData(ERROR_AMOUNT)).add(requestedWithdrawalAmount));

                if (CmsWhdrwlType.PARTIAL_WITHDRAWAL_ALLOWED == CmsWhdrwlType.fromCode(kftCmsEB21R.getWithdrawalType())) {
                    // 부분출금인 경우
                    batContext.setData(PART_ERR_COUNT, (int)batContext.getData(PART_ERR_COUNT) + 1 ); // 부분출금 불능처리건수
                    batContext.setData(PART_ERR_AMOUNT, ((BigDecimal)batContext.getData(PART_ERR_AMOUNT)).add(requestedWithdrawalAmount));
                } else {
                    // 부분출금이 허용되지 않은 경우
                    batContext.setData(FULL_ERR_COUNT, (int)batContext.getData(FULL_ERR_COUNT) + 1 );  // 전액출금 불능처리건수
                    batContext.setData(FULL_ERR_AMOUNT, ((BigDecimal)batContext.getData(FULL_ERR_AMOUNT)).add(requestedWithdrawalAmount));
                }
                
                log.debug("[INFO]    PARTIAL ERROR COUNT : [{}]", batContext.getData(PART_ERR_COUNT));
                log.debug("[INFO]    PARTIAL ERROR AMOUNT: [{}]", batContext.getData(PART_ERR_AMOUNT));
                log.debug("[INFO]    FULL ERROR COUNT    : [{}]", batContext.getData(FULL_ERR_COUNT));
                log.debug("[INFO]    FULL ERROR AMOUNT   : [{}]", batContext.getData(FULL_ERR_AMOUNT));
                break;
            default:
                break;
        }

        if (respFlag == NORMAL) {
            return null;
        }

        // 수수료 -> 수수료 * (정상건수 + 부분출금건수)
        long fee = (long)batContext.getData(PROCESSING_FEE) * ((int)batContext.getData(NORMAL_COUNT) + (int)batContext.getData(PART_COUNT));

        batContext.setData(PROCESSING_FEE, fee);

        // Record message 만들기
        KftCmsEB22R kftCmsEB22R = createRecord(kftCmsEB21R, batContext, failedWithdrawalAmount, respCd, respFlag.getCode());

        // 파일 송수신내역에 저장할 EB22 dto 생성
        CmsSndRcvFileL eb22FileL = new CmsSndRcvFileL();
        eb22FileL.setRespCd     (respCd                                     );
        eb22FileL.setRtpyrId    (kftCmsEB22R.getPayerNumber()               );
        eb22FileL.setAcctNo     (kftCmsEB22R.getWithdrawalAccountNumber()   );
        eb22FileL.setReqAmt     (failedWithdrawalAmount                     );
        eb22FileL.setSeqNo      (kftCmsEB21R.getDataSerialNumber()          );

        // write에서 저장할 VO 생성
        BatCmsDbtTrnsRqstRsltVo batCmsDbtTrnsRqstRsltVo = new BatCmsDbtTrnsRqstRsltVo();
        batCmsDbtTrnsRqstRsltVo.setTargetRecordVo(kftCmsEB22R);
        batCmsDbtTrnsRqstRsltVo.setRespCd(respCd);
        batCmsDbtTrnsRqstRsltVo.setTargetFileL(eb22FileL);
        
        log.debug("[INFO]    ===================================================] ");
        log.debug("[INFO]    =                EB22 PROCESS RESULT              =] ");
        log.debug("[INFO]    ===================================================] ");
        log.debug("[INFO]    FILE SEQ            : [{}]", kftCmsEB21R.getDataSerialNumber());
        log.debug("[INFO]    RESPONSE CODE       : [{}]", respCd);
        log.debug("[INFO]    RESPONSE FLAG       : [{}]", respFlag);
        log.debug("[INFO]    REQUESTED AMOUNT    : [{}]", requestedWithdrawalAmount);
        log.debug("[INFO]    FAILED AMOUNT       : [{}]", failedWithdrawalAmount);
        log.debug("[INFO]    ===================================================] ");
        
        return batCmsDbtTrnsRqstRsltVo;
    }

    // CMS_SND_RCV_FILE_L update
    private void updateResponseInfo(CmsSndRcvFileL eB21FileL, KftCmsEB21R kftCmsEB21R, CmsWhdrwlSts respFlag, String respCd) {

        if (NORMAL == respFlag) {
            // 정상인 경우 상태코드 "33"으로 update
            eB21FileL.setPrcsStsDvsnCd(CmsPrcsStsDvsnCdEnum.COMPLETED.getCode());
        } else {
            // 전액출금이 아니라면 실패 코드 설정
            kftCmsEB21R.setWithdrawalResultWithdrawalYn(respFlag.getCode());
            kftCmsEB21R.setWithdrawalResultFailedCode(respCd);

            //////////////////////////////////////////////////////////////////
            // 원 전문 업데이트
            String tlgCtt = VOUtils.toString(kftCmsEB21R);
            eB21FileL.setTlgCtt(tlgCtt);
            /////////////////////////////////////////////////////////////////
        }

        log.debug("[EB22] [DATA_SEQ : {}], [RESP_FLAG : {}], [RESP_CD : {}]",
                kftCmsEB21R.getDataSerialNumber(), respFlag.getCode(), respCd);

        eB21FileL.setRespCd(respCd);
        batCmsSndRcvFileLDao.updateRespInfo(eB21FileL);
    }

    // Record 데이터 만들기
    private KftCmsEB22R createRecord(KftCmsEB21R kftCmsEB21R, BatContext batContext, BigDecimal failedAmount
            , String respCd, String respFlag)  {

        KftCmsEB22R kftCmsEB22R = new KftCmsEB22R(); // (은행접수)출금이체신청내역
        kftCmsEB22R.setRecordType                           ( DATA_R                                                 ); // Record 구분
        kftCmsEB22R.setDataSerialNumber                     ( kftCmsEB21R.getDataSerialNumber()                      ); // Data 일련번호
        kftCmsEB22R.setInstitutionCode                      ( kftCmsEB21R.getInstitutionCode()                       ); // 기관코드
        kftCmsEB22R.setWithdrawalBankBranchCode             ( kftCmsEB21R.getWithdrawalBankBranchCode()              );
        kftCmsEB22R.setWithdrawalAccountNumber              ( kftCmsEB21R.getWithdrawalAccountNumber()               );
        kftCmsEB22R.setFailedWithdrawalAmount               ( failedAmount.longValue()                               ); // 전액출금인 경우, Eb21R의 금액, 아닌 경우 출금의뢰금액-실출금액
        kftCmsEB22R.setAccountHolderResidentBusinessNumber  ( kftCmsEB21R.getAccountHolderResidentBusinessNumber()   );
        kftCmsEB22R.setWithdrawalResultWithdrawalYn         ( respFlag                                               ); // 출금여부(N:불능, P:부분출금)
        kftCmsEB22R.setWithdrawalResultFailedCode           ( respCd                                                 ); // 불능코드
        kftCmsEB22R.setPassbookEntryDetails                 ( kftCmsEB21R.getPassbookEntryDetails()                  );
        kftCmsEB22R.setFundType                             ( kftCmsEB21R.getFundType()                              ); // 자금종류
        kftCmsEB22R.setPayerNumber                          ( kftCmsEB21R.getPayerNumber()                           ); // 납부자번호
        kftCmsEB22R.setPhoneNumber                          ( kftCmsEB21R.getPhoneNumber()                           ); // 전화번호(핸드폰)
        kftCmsEB22R.setInstitutionUseArea                   ( kftCmsEB21R.getInstitutionUseArea()                    ); // 이용기관사용영역
        kftCmsEB22R.setInstitutionUseArea                   ( kftCmsEB21R.getInstitutionUseArea()                    ); // 이용기관사용영역
        kftCmsEB22R.setWithdrawalType                       ( kftCmsEB21R.getWithdrawalType()                        ); // 출금형태
        kftCmsEB22R.setFiller2                              ( kftCmsEB21R.getFiller2()                               ); // FILLER
        kftCmsEB22R.calculate                               ( (Mac)batContext.getData(MAC)                           );
        return kftCmsEB22R;
    }

    // 집계원장 UPDATE
    private void updateCmsCorpTotL(BatContext batContext, BatCmsContextVo cmsContextVo) {
        // 총건수와 금액을 BatContext에서 가져옴
        int normalCnt = (int)batContext.getData(NORMAL_COUNT);
        BigDecimal normalAmt = (BigDecimal)batContext.getData(NORMAL_AMOUNT);
        int partCnt = (int)batContext.getData(PART_COUNT);
        BigDecimal normalPartAmt = (BigDecimal)batContext.getData(PART_AMOUNT);
        int partErrCnt = (int)batContext.getData(PART_ERR_COUNT);
        BigDecimal partErrAmt = (BigDecimal)batContext.getData(PART_ERR_AMOUNT);
        int errCnt = (int)batContext.getData(ERROR_COUNT);
        BigDecimal errAmt = (BigDecimal)batContext.getData(ERROR_AMOUNT);

        int withdrawalCount = normalCnt + partCnt; // 정상건수 + 부분출금건수
        // 수수료 -> 수수료 * (정상건수 + 부분출금건수)
        long bnkFee = (long)batContext.getData(PROCESSING_FEE) * withdrawalCount;

        log.debug("[INFO]    ===================================================] ");
        log.debug("[INFO]    =               EB22 CMS_CORP_TOT_L DATA          =] ");
        log.debug("[INFO]    ===================================================] ");
        log.debug("[INFO]    NORMAL COUNT        : [{}]", normalCnt);
        log.debug("[INFO]    NORMAL AMOUNT       : [{}]", normalAmt);
        log.debug("[INFO]    PARTIAL COUNT       : [{}]", partCnt);
        log.debug("[INFO]    NORMAL PART AMOUNT  : [{}]", normalPartAmt);
        log.debug("[INFO]    PARTIAL ERROR COUNT : [{}]", partErrCnt);
        log.debug("[INFO]    PARTIAL ERROR AMOUNT: [{}]", partErrAmt);
        log.debug("[INFO]    ERROR COUNT         : [{}]", errCnt);
        log.debug("[INFO]    ERROR AMOUNT        : [{}]", errAmt);
        log.debug("[INFO]    BANK FEE            : [{}]", bnkFee);
        log.debug("[INFO]    ===================================================] ");
        
        log.debug("[EB22] CMS_CORP_TOT_L DATA [NORMAL_CNT: {}], [NORMAL_AMT: {}], [PART_CNT: {}], \n"
                        + "[NORMAL_PART_AMT: {}], [PART_ERR_CNT: {}], [PART_ERR_AMT: {}], [ERR_CNT: {}], [ERR_AMT: {}], [BANK_FEE: {}]"
                , normalCnt, normalAmt, partCnt, normalPartAmt, partErrCnt, partErrAmt, errCnt, errAmt ,bnkFee);

        // EB21의 이용집계 정보 조회해서 EB22의 총액, 총 건수는 EB21 총액, 총건수로 저장
        CmsCorpTotL cmsCorpTotLEB21 = cmsCorpTotLMapper.selectByPrimaryKey(cmsContextVo.getTrDt()
                , CmsConst.COR_JPMC, cmsContextVo.getSourceFileNm());

        BigDecimal totAmt = BigDecimal.ZERO;
        Long totCnt = 0L;
        if (cmsCorpTotLEB21 != null) {
            totAmt = cmsCorpTotLEB21.getTotAmt();
            totCnt = cmsCorpTotLEB21.getTotCnt();
        }

        CmsCorpTotL cmsCorpTotLEB22 = new CmsCorpTotL();
        cmsCorpTotLEB22.setTotAmt                 ( totAmt                          ); // 총금액
        cmsCorpTotLEB22.setTotCnt                 ( totCnt                          ); // 총건수
        cmsCorpTotLEB22.setRegDt                  ( cmsContextVo.getTrDt()          ); // 등록일자
        cmsCorpTotLEB22.setCorpCd                 ( CmsConst.COR_JPMC               ); // 기관코드
        cmsCorpTotLEB22.setFileNm                 ( cmsContextVo.getTargetFileNm()  ); // 파일명
        cmsCorpTotLEB22.setNmlPrcsCnt             ( (long) normalCnt                ); // 정상처리건수
        cmsCorpTotLEB22.setNmlPrcsAmt             ( normalAmt                       ); // 정상처리금액
        cmsCorpTotLEB22.setPartNotWhdrwlPrcsCnt   ( (long) partCnt                  ); // 부분미출금처리건수 (P 처리건수)
        cmsCorpTotLEB22.setPartNotWhdrwlAmt       ( normalPartAmt                   ); // 부분미출금금액 (P 처리 금액)
        cmsCorpTotLEB22.setPartWhdrwlIncpPrcsCnt  ( (long) partErrCnt               ); // 부분출금불능처리건수 (N인데 부분출금)
        cmsCorpTotLEB22.setPartWhdrwlIncpPrcsAmt  ( partErrAmt                      ); // 부분출금불능처리금액 (N인데 부분출금)
        cmsCorpTotLEB22.setErrCnt                 ( (long) errCnt                   ); // 전액출금불능처리건수
        cmsCorpTotLEB22.setErrAmt                 ( errAmt                          ); // 전액출금불능처리금액
        cmsCorpTotLEB22.setBnkFee                 ( bnkFee                          ); // 은행수수료

        // 결과 집계 저장
        cmsSndRcvLogManager.saveRsltCmsCorpTotL(cmsContextVo.getTrDt(), CmsConst.COR_JPMC, cmsContextVo.getTargetFileNm(), cmsCorpTotLEB22);
    }

    @Override
    protected void write(List<BatCmsDbtTrnsRqstRsltVo> items) {

        log.debug(" ##### write ######");
        BatContext batContext = (BatContext)FrwContextHolder.getContext();
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        OutputStream outputStream = BatResourceHolder.getWriter(cmsContextVo.getTargetFileNm());

        items.forEach(item -> {
            //////////////////////////////////////////////////////////////////
            /*
             * write 파일 데이터
             */
            String message = VOUtils.toString((KftCmsEB22R)item.getTargetRecordVo());

            fileProcessor.append(outputStream, message);
            /////////////////////////////////////////////////////////////////

            KftCmsEB22R kftCmsEB22R = (KftCmsEB22R)item.getTargetRecordVo();
            String corpCd = kftCmsEB22R.getInstitutionCode();
            /*
             * EB22 파일 데이터를 파일 송수신내역에 insert
             */
            ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////// corpCd 들어가야함
            cmsSndRcvLogManager.insertSndFileData(item.getTargetFileL(), cmsContextVo.getTargetFileNm(),
                    kftCmsEB22R.getDataSerialNumber(), message, cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), batContext.getBatId(), corpCd);

            // 출금이체 원장 불능 금액, 불능코드 update
            updateInvalidWithdrawal(kftCmsEB22R, item.getRespCd());
        });
    }

    // 불능코드, 불능금액 update
    private void updateInvalidWithdrawal(KftCmsEB22R kftCmsEB22R, String respCd) {

        CmsWhdrwlTrnAplyM trnAplyM = new CmsWhdrwlTrnAplyM();
        trnAplyM.setCorpCd(kftCmsEB22R.getInstitutionCode());
        trnAplyM.setAcctNo(kftCmsEB22R.getWithdrawalAccountNumber());
        trnAplyM.setRtpyrId(kftCmsEB22R.getPayerNumber());

        trnAplyM.setWhdrwlAmt(BigDecimal.valueOf(kftCmsEB22R.getFailedWithdrawalAmount()));
        trnAplyM.setWhdrwlRespCd(respCd);
        batCmsWhdrwlTrnAplyMDao.updateRealWhdrwlInfo(trnAplyM);
    }


    @Override
    protected void afterJob(BatContext batContext) {
        log.debug(" ##### afterJob ######");
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        /*
         * trailer 작성
         */
        OutputStream outputStream = BatResourceHolder.getWriter(cmsContextVo.getTargetFileNm());

        // 총건수, 불능건수/금액, 부분출금건수/미처리금액
        processTrailer(outputStream, batContext, cmsContextVo);

        /*
         * 작성한 파일을 전송하기 위해 close
         */
        fileProcessor.closeOutputStream(cmsContextVo.getTargetFileNm());
        
        /*
         * 결제원으로 파일 전송 처리
         */
        fileProcessor.sendFile(cmsContextVo.getTargetFileNm());
        
        // EC21 H, T 상태 update
        cmsSndRcvLogManager.updateHeaderTrailerCompletedProcessStatus(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        
        // 집계테이블 update
        updateCmsCorpTotL(batContext, cmsContextVo);

        //////////////////////////////////////////////////////////////////
        // file tracking 정보 저장
        comFileTractLBean.insertBySndBatJob(EB22);

        log.debug("[SUCCESS]  ===================================================] ");
        log.debug("[SUCCESS]  =                  EB22 SUMMARY                  =] ");
        log.debug("[SUCCESS]  ===================================================] ");
        log.debug("[SUCCESS]  FILE NAME          : [{}]", cmsContextVo.getTargetFileNm());
        log.debug("[SUCCESS]  TR DATE            : [{}]", cmsContextVo.getTrDt());
        log.debug("[SUCCESS]  TOTAL EC21 COUNT   : [{}]", batContext.getData(TOT_RECORD_COUNT));
        log.debug("[SUCCESS]  TOTAL EB22 COUNT   : [{}]", batContext.getData(SEQ));
        log.debug("[SUCCESS]  NORMAL COUNT       : [{}]", batContext.getData(NORMAL_COUNT));
        log.debug("[SUCCESS]  ===================================================] ");

        super.afterJob(batContext);

    }

    // Trailer 데이터 만들기
    private void processTrailer(OutputStream outputStream, BatContext batContext, BatCmsContextVo contextVo)  {

        KftCmsEB22T kftCmsEB22T = new KftCmsEB22T(); // (은행접수)출금이체신청내역
        kftCmsEB22T.setRecordType                    (CmsConst.TRAILER_T                                         ); // Record 구분
        kftCmsEB22T.setSerialNumber                  (CmsConst.TRALIER_SEQ                                       );
        kftCmsEB22T.setInstitutionCode               (CmsConst.COR_JPMC                                          ); // 기관코드
        kftCmsEB22T.setFileName                      (contextVo.getTargetFileNm()                                ); // File 이름
        kftCmsEB22T.setTotalDataRecordCount          ((int)batContext.getData(SEQ)                               ); // 총데이터 건수
        kftCmsEB22T.setWithdrawalFailedCount         ((int)batContext.getData(ERROR_COUNT)                       ); // 출금불능건수 (출금 총 에러건수) N 건수
        kftCmsEB22T.setWithdrawalFailedAmount        (((BigDecimal)batContext.getData(ERROR_AMOUNT)).longValue() ); // 출금불능금액 (출금 총 에러금액) N 금액
        kftCmsEB22T.setPartialWithdrawalFailedCount  ((int)batContext.getData(PART_COUNT)                        ); // 부분출금불능건수 - 부분출금건수 // P 건수
        kftCmsEB22T.setPartialWithdrawalFailedAmount (((BigDecimal)batContext.getData(PART_AMOUNT)).longValue()  ); // 부분출금불능금액 - 미처리된 부분출금금액 // P 금액(남은 금액)
        /*-----------------------------------------*/
        /* bank <-> kftc  수수료 = 0 (설계서 참조) */
        /*-----------------------------------------*/
        kftCmsEB22T.setTotalFee                      (0                                                          ); // 총수수료
        kftCmsEB22T.setWithdrawalBankFee             (0                                                          ); // 출금은행수수료
        kftCmsEB22T.setDepositBankFee                (0                                                          ); // 입금은행수수료
        kftCmsEB22T.setMacValue                      (batContext.getData(MAC).toString()                         );

        //////////////////////////////////////////////////////////////////
        String message = VOUtils.toString(kftCmsEB22T);

        fileProcessor.append(outputStream, message);
        /////////////////////////////////////////////////////////////////

        cmsSndRcvLogManager.insertSndFileTrailer(contextVo.getTargetFileNm(), message, contextVo.getSrDt(), contextVo.getTrDt(), batContext.getBatId());
    }
}