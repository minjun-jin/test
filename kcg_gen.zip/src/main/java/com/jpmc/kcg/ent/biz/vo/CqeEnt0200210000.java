package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보(등록,변경,해지) 요청
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * processSort 처리구분 
 * corpIndvSort 법인개인구분 
 * residentBusinessNumber 주민사업자번호 
 * nameRepresentativeName 성명(대표자명) 
 * corpName 법인명 
 * address 주소 
 * phoneNumber 전화번호 
 * mobilePhoneNumber 핸드폰번호 
 * emailAddress 이메일주소 
 * paymentBranchClearingHouseCode 지급점포교환소코드 
 * paymentRegisterRequestBankCode 지급(등록의뢰)은행코드 
 * paymentRegisterRequestBankBranchCode 지급(등록의뢰)은행지점코드 
 * eNoteCurrentTransactionStartEndDate 전자어음당좌거래개시(해지)일자 
 * currentAccountNumber 당좌계좌번호 
 * companySize 기업규모 
 * industryCode 업종코드 
 * limitAmount 한도금액 
 * depositAccountNumber 입금계좌번호 
 * memberSort 회원구분 
 * afterChangeCurrentAccountNumber 변경후당좌계좌번호 
 * afterChangeDepositAccountNumber 변경후입금계좌번호 
 * 
 * CqeEnt0200210000 cqeEnt0200210000 = new CqeEnt0200210000(); // 회원정보(등록,변경,해지) 요청
 * cqeEnt0200210000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200210000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200210000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200210000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200210000.setTransactionCode("210000"); // 거래구분코드
 * cqeEnt0200210000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200210000.setBnkCd("057"); // 은행코드
 * cqeEnt0200210000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200210000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200210000.setFiller(""); // FILLER
 * cqeEnt0200210000.setProcessSort(""); // 처리구분
 * cqeEnt0200210000.setCorpIndvSort(""); // 법인개인구분
 * cqeEnt0200210000.setResidentBusinessNumber(""); // 주민사업자번호
 * cqeEnt0200210000.setNameRepresentativeName(""); // 성명(대표자명)
 * cqeEnt0200210000.setCorpName(""); // 법인명
 * cqeEnt0200210000.setAddress(""); // 주소
 * cqeEnt0200210000.setPhoneNumber(""); // 전화번호
 * cqeEnt0200210000.setMobilePhoneNumber(""); // 핸드폰번호
 * cqeEnt0200210000.setEmailAddress(""); // 이메일주소
 * cqeEnt0200210000.setPaymentBranchClearingHouseCode(""); // 지급점포교환소코드
 * cqeEnt0200210000.setPaymentRegisterRequestBankCode(""); // 지급(등록의뢰)은행코드
 * cqeEnt0200210000.setPaymentRegisterRequestBankBranchCode(""); // 지급(등록의뢰)은행지점코드
 * cqeEnt0200210000.setENoteCurrentTransactionStartEndDate(""); // 전자어음당좌거래개시(해지)일자
 * cqeEnt0200210000.setCurrentAccountNumber(""); // 당좌계좌번호
 * cqeEnt0200210000.setCompanySize(""); // 기업규모
 * cqeEnt0200210000.setIndustryCode(""); // 업종코드
 * cqeEnt0200210000.setLimitAmount(0L); // 한도금액
 * cqeEnt0200210000.setDepositAccountNumber(""); // 입금계좌번호
 * cqeEnt0200210000.setMemberSort(""); // 회원구분
 * cqeEnt0200210000.setAfterChangeCurrentAccountNumber(""); // 변경후당좌계좌번호
 * cqeEnt0200210000.setAfterChangeDepositAccountNumber(""); // 변경후입금계좌번호
 * }</pre>
 */
@Data
public class CqeEnt0200210000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "210000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String processSort; // 처리구분
	private String corpIndvSort; // 법인개인구분
	private String residentBusinessNumber; // 주민사업자번호
	private String nameRepresentativeName; // 성명(대표자명)
	private String corpName; // 법인명
	private String address; // 주소
	private String phoneNumber; // 전화번호
	private String mobilePhoneNumber; // 핸드폰번호
	private String emailAddress; // 이메일주소
	private String paymentBranchClearingHouseCode; // 지급점포교환소코드
	private String paymentRegisterRequestBankCode; // 지급(등록의뢰)은행코드
	private String paymentRegisterRequestBankBranchCode; // 지급(등록의뢰)은행지점코드
	private String eNoteCurrentTransactionStartEndDate; // 전자어음당좌거래개시(해지)일자
	private String currentAccountNumber; // 당좌계좌번호
	private String companySize; // 기업규모
	private String industryCode; // 업종코드
	private long limitAmount; // 한도금액
	private String depositAccountNumber; // 입금계좌번호
	private String memberSort; // 회원구분
	private String afterChangeCurrentAccountNumber; // 변경후당좌계좌번호
	private String afterChangeDepositAccountNumber; // 변경후입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processSort$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpIndvSort$; // 법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nameRepresentativeName$; // 성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String corpName$; // 법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String address$; // 주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mobilePhoneNumber$; // 핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String emailAddress$; // 이메일주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentRegisterRequestBankCode$; // 지급(등록의뢰)은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentRegisterRequestBankBranchCode$; // 지급(등록의뢰)은행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteCurrentTransactionStartEndDate$; // 전자어음당좌거래개시(해지)일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentAccountNumber$; // 당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String companySize$; // 기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String industryCode$; // 업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String limitAmount$; // 한도금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String memberSort$; // 회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeCurrentAccountNumber$; // 변경후당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeDepositAccountNumber$; // 변경후입금계좌번호

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isWhitespace(processSort$)) { // 처리구분
			return 10;
		}
		if (VOUtils.isWhitespace(corpIndvSort$)) { // 법인개인구분
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(paymentRegisterRequestBankBranchCode$)) { // 지급(등록의뢰)은행지점코드
			return 21;
		}
		if (VOUtils.isNotAlphanumericSpace(industryCode$)) { // 업종코드
			return 25;
		}
		if (VOUtils.isNotNumeric(limitAmount$)) { // 한도금액
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(memberSort$)) { // 회원구분
			return 28;
		}
		if (VOUtils.isNotAlphanumericSpace(afterChangeCurrentAccountNumber$)) { // 변경후당좌계좌번호
			return 29;
		}
		if (VOUtils.isNotAlphanumericSpace(afterChangeDepositAccountNumber$)) { // 변경후입금계좌번호
			return 30;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		processSort$ = VOUtils.write(out, processSort, 2); // 처리구분
		corpIndvSort$ = VOUtils.write(out, corpIndvSort, 1); // 법인개인구분
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		nameRepresentativeName$ = VOUtils.write(out, nameRepresentativeName, 20, "EUC-KR"); // 성명(대표자명)
		corpName$ = VOUtils.write(out, corpName, 40, "EUC-KR"); // 법인명
		address$ = VOUtils.write(out, address, 60, "EUC-KR"); // 주소
		phoneNumber$ = VOUtils.write(out, phoneNumber, 14); // 전화번호
		mobilePhoneNumber$ = VOUtils.write(out, mobilePhoneNumber, 14); // 핸드폰번호
		emailAddress$ = VOUtils.write(out, emailAddress, 40); // 이메일주소
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포교환소코드
		paymentRegisterRequestBankCode$ = VOUtils.write(out, paymentRegisterRequestBankCode, 3); // 지급(등록의뢰)은행코드
		paymentRegisterRequestBankBranchCode$ = VOUtils.write(out, paymentRegisterRequestBankBranchCode, 4); // 지급(등록의뢰)은행지점코드
		eNoteCurrentTransactionStartEndDate$ = VOUtils.write(out, eNoteCurrentTransactionStartEndDate, 8); // 전자어음당좌거래개시(해지)일자
		currentAccountNumber$ = VOUtils.write(out, currentAccountNumber, 16); // 당좌계좌번호
		companySize$ = VOUtils.write(out, companySize, 1); // 기업규모
		industryCode$ = VOUtils.write(out, industryCode, 2); // 업종코드
		limitAmount$ = VOUtils.write(out, limitAmount, 15); // 한도금액
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		memberSort$ = VOUtils.write(out, memberSort, 1); // 회원구분
		afterChangeCurrentAccountNumber$ = VOUtils.write(out, afterChangeCurrentAccountNumber, 16); // 변경후당좌계좌번호
		afterChangeDepositAccountNumber$ = VOUtils.write(out, afterChangeDepositAccountNumber, 16); // 변경후입금계좌번호
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		processSort = VOUtils.toString(processSort$ = VOUtils.read(in, 2)); // 처리구분
		corpIndvSort = VOUtils.toString(corpIndvSort$ = VOUtils.read(in, 1)); // 법인개인구분
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		nameRepresentativeName = VOUtils.toString(nameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 성명(대표자명)
		corpName = VOUtils.toString(corpName$ = VOUtils.read(in, 40, "EUC-KR")); // 법인명
		address = VOUtils.toString(address$ = VOUtils.read(in, 60, "EUC-KR")); // 주소
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 14)); // 전화번호
		mobilePhoneNumber = VOUtils.toString(mobilePhoneNumber$ = VOUtils.read(in, 14)); // 핸드폰번호
		emailAddress = VOUtils.toString(emailAddress$ = VOUtils.read(in, 40)); // 이메일주소
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포교환소코드
		paymentRegisterRequestBankCode = VOUtils.toString(paymentRegisterRequestBankCode$ = VOUtils.read(in, 3)); // 지급(등록의뢰)은행코드
		paymentRegisterRequestBankBranchCode = VOUtils.toString(paymentRegisterRequestBankBranchCode$ = VOUtils.read(in, 4)); // 지급(등록의뢰)은행지점코드
		eNoteCurrentTransactionStartEndDate = VOUtils.toString(eNoteCurrentTransactionStartEndDate$ = VOUtils.read(in, 8)); // 전자어음당좌거래개시(해지)일자
		currentAccountNumber = VOUtils.toString(currentAccountNumber$ = VOUtils.read(in, 16)); // 당좌계좌번호
		companySize = VOUtils.toString(companySize$ = VOUtils.read(in, 1)); // 기업규모
		industryCode = VOUtils.toString(industryCode$ = VOUtils.read(in, 2)); // 업종코드
		limitAmount = VOUtils.toLong(limitAmount$ = VOUtils.read(in, 15)); // 한도금액
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		memberSort = VOUtils.toString(memberSort$ = VOUtils.read(in, 1)); // 회원구분
		afterChangeCurrentAccountNumber = VOUtils.toString(afterChangeCurrentAccountNumber$ = VOUtils.read(in, 16)); // 변경후당좌계좌번호
		afterChangeDepositAccountNumber = VOUtils.toString(afterChangeDepositAccountNumber$ = VOUtils.read(in, 16)); // 변경후입금계좌번호
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", processSort=").append(processSort).append(System.lineSeparator()); // 처리구분
		sb.append(", corpIndvSort=").append(corpIndvSort).append(System.lineSeparator()); // 법인개인구분
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", nameRepresentativeName=").append(nameRepresentativeName).append(System.lineSeparator()); // 성명(대표자명)
		sb.append(", corpName=").append(corpName).append(System.lineSeparator()); // 법인명
		sb.append(", address=").append(address).append(System.lineSeparator()); // 주소
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호
		sb.append(", mobilePhoneNumber=").append(mobilePhoneNumber).append(System.lineSeparator()); // 핸드폰번호
		sb.append(", emailAddress=").append(emailAddress).append(System.lineSeparator()); // 이메일주소
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포교환소코드
		sb.append(", paymentRegisterRequestBankCode=").append(paymentRegisterRequestBankCode).append(System.lineSeparator()); // 지급(등록의뢰)은행코드
		sb.append(", paymentRegisterRequestBankBranchCode=").append(paymentRegisterRequestBankBranchCode).append(System.lineSeparator()); // 지급(등록의뢰)은행지점코드
		sb.append(", eNoteCurrentTransactionStartEndDate=").append(eNoteCurrentTransactionStartEndDate).append(System.lineSeparator()); // 전자어음당좌거래개시(해지)일자
		sb.append(", currentAccountNumber=").append(currentAccountNumber).append(System.lineSeparator()); // 당좌계좌번호
		sb.append(", companySize=").append(companySize).append(System.lineSeparator()); // 기업규모
		sb.append(", industryCode=").append(industryCode).append(System.lineSeparator()); // 업종코드
		sb.append(", limitAmount=").append(limitAmount).append(System.lineSeparator()); // 한도금액
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", memberSort=").append(memberSort).append(System.lineSeparator()); // 회원구분
		sb.append(", afterChangeCurrentAccountNumber=").append(afterChangeCurrentAccountNumber).append(System.lineSeparator()); // 변경후당좌계좌번호
		sb.append(", afterChangeDepositAccountNumber=").append(afterChangeDepositAccountNumber).append(System.lineSeparator()); // 변경후입금계좌번호
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "210000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "processSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "corpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "nameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "corpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "address", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "mobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "emailAddress", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "paymentRegisterRequestBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "paymentRegisterRequestBankBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "eNoteCurrentTransactionStartEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "currentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "companySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "industryCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "limitAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "memberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "afterChangeCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "afterChangeDepositAccountNumber", "fldLen", "16", "defltVal", "")
		);
	}

}
