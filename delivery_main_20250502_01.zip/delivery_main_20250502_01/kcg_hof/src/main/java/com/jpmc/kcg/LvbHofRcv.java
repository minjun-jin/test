package com.jpmc.kcg;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Properties;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.HexDump;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.ThreadUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMsg2;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.spring.boot.MQConfigurationProperties;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.jpmc.kcg.frw.FrwExecutor;
import com.jpmc.kcg.frw.FrwServiceExecutor;
import com.jpmc.kcg.frw.SystemProperties;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.dao.FrwMsgLMapper;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.hof.biz.vo.LvbHofComHdr;
import com.jpmc.kcg.hof.biz.vo.LvbHofComHdrImpl;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;

@Generated
@Slf4j
@Component
@ConditionalOnProperty("ibm.mq.auto-configure")
public class LvbHofRcv implements DisposableBean, InitializingBean, Runnable {

	@Autowired
	private FrwExecutor frwExecutor;
	@Autowired
	private FrwMsgLMapper frwMsgLMapper;
	@Autowired
	private FrwServiceExecutor frwServiceExecutor;
	@Autowired
	private JmsTemplate jmsTemplate;
	@Autowired
	private SystemProperties systemProperties;
	private ExecutorService executorService;

//	@JmsListener(concurrency = "${system.lvb.hof.con}", destination = "queue:///${system.lvb.hof.rcv}?receiveCCSID=970&receiveConversion=2")
	public void receiveJms(Message message) {
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 승인처리 ///////////////////////////////////////////////////////////////
		try {
			String tlgCtt = ((TextMessage) message).getText();
			if (StringUtils.endsWith(StringUtils.left(tlgCtt, 38), "0200400000")) {
				StringBuilder sb = new StringBuilder(tlgCtt);
				sb.setCharAt(28, '1');
				String ackCtt = sb.toString();
				log.info(">{}]", ackCtt);
				LvbHofComHdr lvbHofComHdr = VOUtils.toVo(ackCtt, LvbHofComHdrImpl.class);
				log.debug("{}", lvbHofComHdr);
				FrwMsgL frwMsgL = new FrwMsgL();
				frwMsgL.setLogDttm(LocalDateTime.now());
				frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
				frwMsgL.setSvcGuid(String.valueOf(UUID.randomUUID()));
				frwMsgL.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(systemProperties.getInstnId()), 2), 2, '0'));
				frwMsgL.setAppNm("HOF");
				frwMsgL.setHostCd("LVB");
				frwMsgL.setBizDvsnCd(frwMsgL.getAppNm());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////// 원본구분코드저장 ///////////////////////////////////////////////
				frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 28, 32)); // 전문종별구분코드
				frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 32, 38)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				frwMsgL.setTlgSndRcvDttm(lvbHofComHdr.getSystemSendReceiveTime());
				frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
				frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
//				frwMsgL.setMsgTrckNo();
				frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
				frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
//				frwMsgL.setHndlMsgNo();
//				frwMsgL.setKftcMsgNo();
//				frwMsgL.setInitInstCd();
//				frwMsgL.setInitMsgNo();
				frwMsgL.setTractSortCd("00"); // 당발승인송신
				frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
					StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
					StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
					StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
					"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
					StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
					StringUtils.leftPad(StringUtils.defaultString(lvbHofComHdr.getMsgNo()), 13, '0'),
				"11")); // 당발요구수신
				frwMsgL.setOrgnTractId(frwMsgL.getTractId());
				frwMsgL.setFrstTractId(frwMsgL.getTractId());
				frwMsgL.setUsrId(StringUtils.join(frwMsgL.getAppNm(), "SYS"));
//				frwMsgL.setCrltnId();
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
				frwMsgL.setTlgCtt(ackCtt);
//				frwMsgL.setStckTrc();
//				frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
//				frwMsgL.setAprvStsCd();
//				frwMsgL.setMakeId();
//				frwMsgL.setMakeDttm();
//				frwMsgL.setChkId();
//				frwMsgL.setChkDttm();
				frwMsgL.setFrstChngGuid(frwMsgL.getSvcGuid());
				frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
				frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
				frwMsgL.setLastChngGuid(frwMsgL.getSvcGuid());
				frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
				frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////// 실제구분코드저장 ///////////////////////////////////////////////
				frwMsgL.setTlgKndDvsnCd(StringUtils.substring(ackCtt, 28, 32)); // 전문종별구분코드
				frwMsgL.setTlgBizDvsnCd(StringUtils.substring(ackCtt, 32, 38)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				log.debug("{}", frwMsgL);
				frwExecutor.requiresNew(() -> {
					frwMsgLMapper.insert(frwMsgL);
					String destinationName = systemProperties.getLvb().getHof().getAck();
					destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
						WMQConstants.WMQ_CCSID, "=970&",
						WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
					log.debug("{}", destinationName);
					jmsTemplate.setExplicitQosEnabled(false);
					jmsTemplate.send(destinationName, session -> {
						TextMessage textMessage = session.createTextMessage(ackCtt);
						log.debug("{}", textMessage);
						return textMessage;
					});
				});
			}
		} catch (JMSException e) {
			log.debug("{}", message);
			log.error(ExceptionUtils.getRootCauseMessage(e), e);
			return;
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwServiceExecutor.execute(message);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		int nThreads = NumberUtils.toInt(systemProperties.getLvb().getHof().getCon());
		executorService = Executors.newFixedThreadPool(nThreads);
		for (int i = 0; i < nThreads; i++) {
			executorService.submit(this);
		}
	}

	@Override
	public void destroy() throws Exception {
		executorService.shutdown();
		while (!executorService.awaitTermination(1L, TimeUnit.SECONDS)) {
		}
	}

	@Autowired(required = false)
	private MQConfigurationProperties mqConfigurationProperties;
	private MQQueueManager newMQQueueManager() throws MQException {
		Properties properties = new Properties();
		properties.setProperty(MQConstants.HOST_NAME_PROPERTY, StringUtils.substringBefore(mqConfigurationProperties.getConnName(), '('));
		properties.put(MQConstants.PORT_PROPERTY, NumberUtils.createInteger(StringUtils.substringBetween(mqConfigurationProperties.getConnName(), "(", ")")));
		properties.setProperty(MQConstants.CHANNEL_PROPERTY, mqConfigurationProperties.getChannel());
		properties.setProperty(MQConstants.USER_ID_PROPERTY, mqConfigurationProperties.getUser());
		properties.setProperty(MQConstants.PASSWORD_PROPERTY, mqConfigurationProperties.getPassword());
		if (StringUtils.isNotEmpty(mqConfigurationProperties.getSslCipherSuite())) {
			properties.setProperty(MQConstants.SSL_CIPHER_SUITE_PROPERTY, mqConfigurationProperties.getSslCipherSuite());
		}
		return new MQQueueManager(mqConfigurationProperties.getQueueManager(), properties);
	}

	@Override
	public void run() {
		log.info("start");
		while (!executorService.isShutdown()) {
			try {
				MQQueueManager mqQueueManager = newMQQueueManager();
				try {
					MQQueue mqGetQueue = mqQueueManager.accessQueue(systemProperties.getLvb().getHof().getRcv(), MQConstants.MQOO_INPUT_AS_Q_DEF + MQConstants.MQOO_FAIL_IF_QUIESCING);
					MQGetMessageOptions mqGetMessageOptions = new MQGetMessageOptions();
					mqGetMessageOptions.options = MQConstants.MQGMO_SYNCPOINT + MQConstants.MQGMO_WAIT + MQConstants.MQGMO_CONVERT;
					mqGetMessageOptions.waitInterval = NumberUtils.toInt(System.getProperty("system.lvb.hof.rcv.wait-interval", "1000"));
					try {
						MQQueue mqPutQueue = mqQueueManager.accessQueue(systemProperties.getKcg().getHof().getCmn(), MQConstants.MQOO_OUTPUT + MQConstants.MQOO_FAIL_IF_QUIESCING);
						MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();
						mqPutMessageOptions.options = MQConstants.MQPMO_SYNCPOINT;
					try {
						MQQueue mqAckQueue = mqQueueManager.accessQueue(systemProperties.getLvb().getHof().getAck(), MQConstants.MQOO_OUTPUT + MQConstants.MQOO_FAIL_IF_QUIESCING);
						MQPutMessageOptions mqAckMessageOptions = new MQPutMessageOptions();
						mqAckMessageOptions.options = MQConstants.MQPMO_SYNCPOINT;
						try {
							boolean hexDump = Boolean.getBoolean("system.lvb.hof.rcv.hex-dump");
							while (!executorService.isShutdown()) {
								MQMsg2 mqMsg2 = new MQMsg2();
								mqMsg2.setFormat(MQConstants.MQFMT_STRING);
								mqMsg2.setCharacterSet(970);
								try {
									mqGetQueue.getMsg2(mqMsg2, mqGetMessageOptions);
								} catch (MQException e) {
									if ((MQConstants.MQCC_FAILED == e.getCompCode()) &&
										(MQConstants.MQRC_NO_MSG_AVAILABLE == e.getReason())) {
										continue;
									}
									throw e;
								}
								byte[] byteArray = mqMsg2.getMessageData();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// RFH2헤더보정 ///////////////////////////////////
								if ('R' == byteArray[0] &&
									'F' == byteArray[1] &&
									'H' == byteArray[2]) {
									for (int i = 0; i < byteArray.length - 5; i++) {
										if ('<' == byteArray[i + 0] &&
											'/' == byteArray[i + 1] &&
											'u' == byteArray[i + 2] &&
											's' == byteArray[i + 3] &&
											'r' == byteArray[i + 4] &&
											'>' == byteArray[i + 5]) {
											byteArray = ArrayUtils.subarray(byteArray, i + 6, byteArray.length);
											break;
										}
									}
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// 전문덤프 ///////////////////////////////////////
								if (hexDump) {
									StringBuilder sb = new StringBuilder(System.lineSeparator());
									HexDump.dump(byteArray, sb);
									log.debug("{}", sb.toString());
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
								String tlgCtt = IOUtils.toString(byteArray, "EUC-KR");
								log.info("<{}]", tlgCtt);
								if (StringUtils.endsWith(StringUtils.left(tlgCtt, 38), "0200400000")) {
									byteArray[28] = '1';
									mqMsg2 = new MQMsg2();
									mqMsg2.setFormat(MQConstants.MQFMT_STRING);
									mqMsg2.setCharacterSet(970);
									mqMsg2.setMessageData(byteArray);
									mqMsg2.setPriority(9);
									mqAckQueue.putMsg2(mqMsg2, mqAckMessageOptions);
									byteArray[28] = '0';
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// 전각한글한자보정 ///////////////////////////////
								for (int i = 0; i < byteArray.length; i++) {
									if ((byte) 0xa1 <= byteArray[i] &&
										(byte) 0xaf >= byteArray[i]) { // 전각보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xa1 <= byteArray[i] &&
											(byte) 0x80 <= byteArray[i + 1] &&
											(byte) 0xaf >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
									if ((byte) 0xb0 <= byteArray[i] &&
										(byte) 0xc9 >= byteArray[i]) { // 한글보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xb0 <= byteArray[i] &&
											(byte) 0xa1 <= byteArray[i + 1] &&
											(byte) 0xc9 >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
									if ((byte) 0xca <= byteArray[i] &&
										(byte) 0xfd >= byteArray[i]) { // 한자보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xca <= byteArray[i] &&
											(byte) 0x80 <= byteArray[i + 1] &&
											(byte) 0xfd >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
								tlgCtt = IOUtils.toString(byteArray, "EUC-KR");
								if (StringUtils.endsWith(StringUtils.left(tlgCtt, 38), "0200400000")) {
									StringBuilder sb = new StringBuilder(tlgCtt);
									sb.setCharAt(28, '1');
									String ackCtt = sb.toString();
									log.info(">{}]", ackCtt);
									LvbHofComHdr lvbHofComHdr = VOUtils.toVo(ackCtt, LvbHofComHdrImpl.class);
									log.debug("{}", lvbHofComHdr);
									FrwMsgL frwMsgL = new FrwMsgL();
									frwMsgL.setLogDttm(LocalDateTime.now());
									frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
									frwMsgL.setSvcGuid(String.valueOf(UUID.randomUUID()));
									frwMsgL.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(systemProperties.getInstnId()), 2), 2, '0'));
									frwMsgL.setAppNm("HOF");
									frwMsgL.setHostCd("LVB");
									frwMsgL.setBizDvsnCd(frwMsgL.getAppNm());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////// 원본구분코드저장 ///////////////////////
									frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 28, 32)); // 전문종별구분코드
									frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 32, 38)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
									frwMsgL.setTlgSndRcvDttm(lvbHofComHdr.getSystemSendReceiveTime());
									frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
									frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
//									frwMsgL.setMsgTrckNo();
									frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
									frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
//									frwMsgL.setHndlMsgNo();
//									frwMsgL.setKftcMsgNo();
//									frwMsgL.setInitInstCd();
//									frwMsgL.setInitMsgNo();
									frwMsgL.setTractSortCd("00"); // 당발승인송신
									frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
										StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
										StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
										StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
										"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
										StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
										StringUtils.leftPad(StringUtils.defaultString(lvbHofComHdr.getMsgNo()), 13, '0'),
									"11")); // 당발요구수신
									frwMsgL.setOrgnTractId(frwMsgL.getTractId());
									frwMsgL.setFrstTractId(frwMsgL.getTractId());
									frwMsgL.setUsrId(StringUtils.join(frwMsgL.getAppNm(), "SYS"));
//									frwMsgL.setCrltnId();
									frwMsgL.setTlgLaytId(StringUtils.join(
										frwMsgL.getHostCd(),
										frwMsgL.getBizDvsnCd(),
										frwMsgL.getTlgKndDvsnCd(),
										frwMsgL.getTlgBizDvsnCd()
									));
									frwMsgL.setTlgCtt(ackCtt);
//									frwMsgL.setStckTrc();
//									frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
//									frwMsgL.setAprvStsCd();
//									frwMsgL.setMakeId();
//									frwMsgL.setMakeDttm();
//									frwMsgL.setChkId();
//									frwMsgL.setChkDttm();
									frwMsgL.setFrstChngGuid(frwMsgL.getSvcGuid());
									frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
									frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
									frwMsgL.setLastChngGuid(frwMsgL.getSvcGuid());
									frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
									frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 실제구분코드저장 ///////////////////////////
									frwMsgL.setTlgKndDvsnCd(StringUtils.substring(ackCtt, 28, 32)); // 전문종별구분코드
									frwMsgL.setTlgBizDvsnCd(StringUtils.substring(ackCtt, 32, 38)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
									log.debug("{}", frwMsgL);
									frwMsgLMapper.insert(frwMsgL);
								}
								log.info(">{}]", tlgCtt);
								mqMsg2 = new MQMsg2();
								mqMsg2.setFormat(MQConstants.MQFMT_STRING);
								mqMsg2.setCharacterSet(WMQConstants.CCSID_UTF8);
								mqMsg2.setMessageData(StringUtils.getBytes(tlgCtt, Charsets.toCharset("UTF-8")));
								mqMsg2.setPriority(4);
								mqPutQueue.putMsg2(mqMsg2, mqPutMessageOptions);
								mqQueueManager.commit();
							}
						} finally {
							mqAckQueue.close();
						}
						} finally {
							mqPutQueue.close();
						}
					} finally {
						mqGetQueue.close();
					}
				}
				finally {
					try {
						mqQueueManager.close();
					} finally {
						mqQueueManager.disconnect();
					}
				}
			} catch (Throwable t) {
				log.error(ExceptionUtils.getRootCauseMessage(t), t);
			}
			ThreadUtils.sleepQuietly(Duration.ofSeconds(1L));
		}
		log.info("stop");
	}

}
