package com.jpmc.kcg.web.aspect;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.junit.jupiter.MockitoExtension;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@ExtendWith(MockitoExtension.class)
class WebRequestFilterTest {
	
    private WebRequestFilter filter;

    private HttpServletRequest request;
    private HttpServletResponse response;
    private FilterChain chain;

    @BeforeEach
    void setUp() {
        filter = new WebRequestFilter();
        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
        chain = mock(FilterChain.class);
    }

    @Test
    void testDoFilter_api요청_RequestWrapper적용됨() throws Exception {
        // given
        when(request.getRequestURI()).thenReturn("/myapp/api/test");
        when(request.getContextPath()).thenReturn("/myapp");

        // when
        filter.doFilterInternal(request, response, chain);

        // then
        ArgumentCaptor<RequestWrapper> wrapperCaptor = ArgumentCaptor.forClass(RequestWrapper.class);
        verify(chain).doFilter(wrapperCaptor.capture(), eq(response));
    }

    @Test
    void testDoFilter_일반요청_RequestWrapper미적용() throws Exception {
        // given
        when(request.getRequestURI()).thenReturn("/myapp/other/test");
        when(request.getContextPath()).thenReturn("/myapp");

        // when
        filter.doFilterInternal(request, response, chain);

        // then
        verify(chain).doFilter(request, response); // 원본 그대로 전달
    }

    @Test
    void testDoFilter_예외발생_500응답() throws Exception {
        // given
        when(request.getRequestURI()).thenReturn("/api/test");
        when(request.getContextPath()).thenReturn("").thenThrow(new RuntimeException("TEST ERROR"));

        // when
        filter.doFilterInternal(request, response, chain);

    }

}
