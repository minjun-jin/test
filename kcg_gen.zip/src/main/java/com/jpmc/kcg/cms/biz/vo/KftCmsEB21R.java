package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.Mac;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 출금의뢰내역
 * <pre>{@code
 * KftCmsEB21R kftCmsEB21R  = new KftCmsEB21R(); // 출금의뢰내역
 * kftCmsEB21R.setRecordType(""); // Record 구분
 * kftCmsEB21R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB21R.setInstitutionCode(""); // 기관코드
 * kftCmsEB21R.setWithdrawalBankBranchCode(""); // 출금은행점코드
 * kftCmsEB21R.setWithdrawalAccountNumber(""); // 출금계좌번호
 * kftCmsEB21R.setRequestedWithdrawalAmount(0L); // 출금의뢰(불능)금액
 * kftCmsEB21R.setAccountHolderResidentBusinessNumber(""); // 예금주 생년월일 또는 사업자등록번호
 * kftCmsEB21R.setWithdrawalResultWithdrawalYn(""); // 출금결과 출금여부
 * kftCmsEB21R.setWithdrawalResultFailedCode(""); // 출금결과 불능코드
 * kftCmsEB21R.setPassbookEntryDetails(""); // 통장기재내용
 * kftCmsEB21R.setFundType(""); // 자금종류
 * kftCmsEB21R.setPayerNumber(""); // 납부자번호
 * kftCmsEB21R.setInstitutionUseArea(""); // 이용기관사용영역
 * kftCmsEB21R.setWithdrawalType(""); // 출금형태
 * kftCmsEB21R.setPhoneNumber(""); // 전화번호(휴대전화번호)
 * kftCmsEB21R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB21R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String withdrawalBankBranchCode; // 출금은행점코드
	private String withdrawalAccountNumber; // 출금계좌번호
	private long requestedWithdrawalAmount; // 출금의뢰(불능)금액
	private String accountHolderResidentBusinessNumber; // 예금주 생년월일 또는 사업자등록번호
	private String withdrawalResultWithdrawalYn; // 출금결과 출금여부
	private String withdrawalResultFailedCode; // 출금결과 불능코드
	private String passbookEntryDetails; // 통장기재내용
	private String fundType; // 자금종류
	private String payerNumber; // 납부자번호
	private String institutionUseArea; // 이용기관사용영역
	private String withdrawalType; // 출금형태
	private String phoneNumber; // 전화번호(휴대전화번호)
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalBankBranchCode$; // 출금은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalAmount$; // 출금의뢰(불능)금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderResidentBusinessNumber$; // 예금주 생년월일 또는 사업자등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalResultWithdrawalYn$; // 출금결과 출금여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalResultFailedCode$; // 출금결과 불능코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String passbookEntryDetails$; // 통장기재내용
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumber$; // 납부자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionUseArea$; // 이용기관사용영역
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalType$; // 출금형태
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호(휴대전화번호)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void calculate(Mac mac) {
		mac.calculate(withdrawalAccountNumber);
		mac.calculate(requestedWithdrawalAmount, 13);
	}

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		withdrawalBankBranchCode$ = VOUtils.write(out, withdrawalBankBranchCode, 7); // 출금은행점코드
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		requestedWithdrawalAmount$ = VOUtils.write(out, requestedWithdrawalAmount, 13); // 출금의뢰(불능)금액
		accountHolderResidentBusinessNumber$ = VOUtils.write(out, accountHolderResidentBusinessNumber, 13); // 예금주 생년월일 또는 사업자등록번호
		withdrawalResultWithdrawalYn$ = VOUtils.write(out, withdrawalResultWithdrawalYn, 1); // 출금결과 출금여부
		withdrawalResultFailedCode$ = VOUtils.write(out, withdrawalResultFailedCode, 4); // 출금결과 불능코드
		passbookEntryDetails$ = VOUtils.write(out, passbookEntryDetails, 16, "EUC-KR"); // 통장기재내용
		fundType$ = VOUtils.write(out, fundType, 2); // 자금종류
		payerNumber$ = VOUtils.write(out, payerNumber, 20); // 납부자번호
		institutionUseArea$ = VOUtils.write(out, institutionUseArea, 5); // 이용기관사용영역
		withdrawalType$ = VOUtils.write(out, withdrawalType, 1); // 출금형태
		phoneNumber$ = VOUtils.write(out, phoneNumber, 12); // 전화번호(휴대전화번호)
		filler2$ = VOUtils.write(out, filler2, 21); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		withdrawalBankBranchCode = VOUtils.toString(withdrawalBankBranchCode$ = VOUtils.read(in, 7)); // 출금은행점코드
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		requestedWithdrawalAmount = VOUtils.toLong(requestedWithdrawalAmount$ = VOUtils.read(in, 13)); // 출금의뢰(불능)금액
		accountHolderResidentBusinessNumber = VOUtils.toString(accountHolderResidentBusinessNumber$ = VOUtils.read(in, 13)); // 예금주 생년월일 또는 사업자등록번호
		withdrawalResultWithdrawalYn = VOUtils.toString(withdrawalResultWithdrawalYn$ = VOUtils.read(in, 1)); // 출금결과 출금여부
		withdrawalResultFailedCode = VOUtils.toString(withdrawalResultFailedCode$ = VOUtils.read(in, 4)); // 출금결과 불능코드
		passbookEntryDetails = VOUtils.toString(passbookEntryDetails$ = VOUtils.read(in, 16, "EUC-KR")); // 통장기재내용
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금종류
		payerNumber = VOUtils.toString(payerNumber$ = VOUtils.read(in, 20)); // 납부자번호
		institutionUseArea = VOUtils.toString(institutionUseArea$ = VOUtils.read(in, 5)); // 이용기관사용영역
		withdrawalType = VOUtils.toString(withdrawalType$ = VOUtils.read(in, 1)); // 출금형태
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 12)); // 전화번호(휴대전화번호)
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 21)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", withdrawalBankBranchCode=").append(withdrawalBankBranchCode).append(System.lineSeparator()); // 출금은행점코드
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", requestedWithdrawalAmount=").append(requestedWithdrawalAmount).append(System.lineSeparator()); // 출금의뢰(불능)금액
		sb.append(", accountHolderResidentBusinessNumber=").append(accountHolderResidentBusinessNumber).append(System.lineSeparator()); // 예금주 생년월일 또는 사업자등록번호
		sb.append(", withdrawalResultWithdrawalYn=").append(withdrawalResultWithdrawalYn).append(System.lineSeparator()); // 출금결과 출금여부
		sb.append(", withdrawalResultFailedCode=").append(withdrawalResultFailedCode).append(System.lineSeparator()); // 출금결과 불능코드
		sb.append(", passbookEntryDetails=").append(passbookEntryDetails).append(System.lineSeparator()); // 통장기재내용
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금종류
		sb.append(", payerNumber=").append(payerNumber).append(System.lineSeparator()); // 납부자번호
		sb.append(", institutionUseArea=").append(institutionUseArea).append(System.lineSeparator()); // 이용기관사용영역
		sb.append(", withdrawalType=").append(withdrawalType).append(System.lineSeparator()); // 출금형태
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호(휴대전화번호)
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "withdrawalBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accountHolderResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "withdrawalResultWithdrawalYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "withdrawalResultFailedCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "passbookEntryDetails", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "payerNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "institutionUseArea", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "withdrawalType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "21", "defltVal", "")
		);
	}

}
