package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 부도어음 반환 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * type 구분 
 * repaymentClaimDate 상환청구일자 
 * repaymentObligationFulfillmentRegistrationDate 상환의무이행등록일자 
 * repaymentObligationFulfillmentConfirmationDate 상환의무이행확인일자 
 * eNoteNumber 어음내역전자어음번호 
 * eNoteType 어음내역어음종류 
 * eNoteIssueDate 어음내역전자어음발행일자 
 * eNoteIssuePlace 어음내역전자어음발행지 
 * eNoteAmount 어음내역전자어음금액 
 * eNoteMaturedDate 어음내역전자어음만기일자 
 * paymentBankAndBranchCode 어음내역지급은행및지점코드 
 * payingBranchClearingHouseCode 어음내역지급점포교환소코드 
 * repaymentObligorCorpIndvSortCode 상환의무인법인개인구분코드 
 * repaymentObligorResidentBusinessNumber 상환의무인주민사업자번호 
 * repaymentObligorCorpName 상환의무인법인명 
 * repaymentObligorNameRepresentativeName 상환의무인성명(대표자명) 
 * repaymentObligorAddress 상환의무인주소 
 * repaymentObligorBankCode 상환의무인은행코드 
 * repaymentObligorCurrentAccountNumber 상환의무인당좌계좌번호 
 * repaymentClaimantCorpIndvSortCode 상환청구인법인개인구분코드 
 * repaymentClaimantResidentBusinessNumber 상환청구인주민사업자번호 
 * repaymentClaimantCorpName 상환청구인법인명 
 * repaymentClaimantNameRepresentativeName 상환청구인성명(대표자명) 
 * repaymentClaimantAddress 상환청구인주소 
 * repaymentClaimantBankCode 상환청구인은행코드 
 * repaymentClaimantDepositAccountNumber 상환청구인수취계좌번호 
 * depositRejectionDate 입금(거절)일자 
 * repaymentClaimAmount 상환청구금액 
 * repaymentClaimantSplitNumber 상환청구인분할번호 
 * repaymentClaimantEndorsementNumber 상환청구인배서번호 
 * repaymentClaimDesignationDate 상환청구인지정일자 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0210280000 kftEnt0210280000 = new KftEnt0210280000(); // 부도어음 반환 응답
 * kftEnt0210280000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210280000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210280000.setBnkCd("057"); // 은행코드
 * kftEnt0210280000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210280000.setTransactionCode("280000"); // 거래구분코드
 * kftEnt0210280000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210280000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210280000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210280000.setStatus("000"); // STATUS
 * kftEnt0210280000.setResponseCode1(""); // 응답코드1
 * kftEnt0210280000.setResponseCode2(""); // 응답코드2
 * kftEnt0210280000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210280000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210280000.setType(""); // 구분
 * kftEnt0210280000.setRepaymentClaimDate(""); // 상환청구일자
 * kftEnt0210280000.setRepaymentObligationFulfillmentRegistrationDate(""); // 상환의무이행등록일자
 * kftEnt0210280000.setRepaymentObligationFulfillmentConfirmationDate(""); // 상환의무이행확인일자
 * kftEnt0210280000.setENoteNumber(""); // 어음내역전자어음번호
 * kftEnt0210280000.setENoteType(""); // 어음내역어음종류
 * kftEnt0210280000.setENoteIssueDate(""); // 어음내역전자어음발행일자
 * kftEnt0210280000.setENoteIssuePlace(""); // 어음내역전자어음발행지
 * kftEnt0210280000.setENoteAmount(0L); // 어음내역전자어음금액
 * kftEnt0210280000.setENoteMaturedDate(""); // 어음내역전자어음만기일자
 * kftEnt0210280000.setPaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * kftEnt0210280000.setPayingBranchClearingHouseCode(""); // 어음내역지급점포교환소코드
 * kftEnt0210280000.setRepaymentObligorCorpIndvSortCode(""); // 상환의무인법인개인구분코드
 * kftEnt0210280000.setRepaymentObligorResidentBusinessNumber(""); // 상환의무인주민사업자번호
 * kftEnt0210280000.setRepaymentObligorCorpName(""); // 상환의무인법인명
 * kftEnt0210280000.setRepaymentObligorNameRepresentativeName(""); // 상환의무인성명(대표자명)
 * kftEnt0210280000.setRepaymentObligorAddress(""); // 상환의무인주소
 * kftEnt0210280000.setRepaymentObligorBankCode(""); // 상환의무인은행코드
 * kftEnt0210280000.setRepaymentObligorCurrentAccountNumber(""); // 상환의무인당좌계좌번호
 * kftEnt0210280000.setRepaymentClaimantCorpIndvSortCode(""); // 상환청구인법인개인구분코드
 * kftEnt0210280000.setRepaymentClaimantResidentBusinessNumber(""); // 상환청구인주민사업자번호
 * kftEnt0210280000.setRepaymentClaimantCorpName(""); // 상환청구인법인명
 * kftEnt0210280000.setRepaymentClaimantNameRepresentativeName(""); // 상환청구인성명(대표자명)
 * kftEnt0210280000.setRepaymentClaimantAddress(""); // 상환청구인주소
 * kftEnt0210280000.setRepaymentClaimantBankCode(""); // 상환청구인은행코드
 * kftEnt0210280000.setRepaymentClaimantDepositAccountNumber(""); // 상환청구인수취계좌번호
 * kftEnt0210280000.setDepositRejectionDate(""); // 입금(거절)일자
 * kftEnt0210280000.setRepaymentClaimAmount(0L); // 상환청구금액
 * kftEnt0210280000.setRepaymentClaimantSplitNumber(""); // 상환청구인분할번호
 * kftEnt0210280000.setRepaymentClaimantEndorsementNumber(""); // 상환청구인배서번호
 * kftEnt0210280000.setRepaymentClaimDesignationDate(""); // 상환청구인지정일자
 * kftEnt0210280000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0210280000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0210280000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "280000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String type; // 구분
	private String repaymentClaimDate; // 상환청구일자
	private String repaymentObligationFulfillmentRegistrationDate; // 상환의무이행등록일자
	private String repaymentObligationFulfillmentConfirmationDate; // 상환의무이행확인일자
	private String eNoteNumber; // 어음내역전자어음번호
	private String eNoteType; // 어음내역어음종류
	private String eNoteIssueDate; // 어음내역전자어음발행일자
	private String eNoteIssuePlace; // 어음내역전자어음발행지
	private long eNoteAmount; // 어음내역전자어음금액
	private String eNoteMaturedDate; // 어음내역전자어음만기일자
	private String paymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private String payingBranchClearingHouseCode; // 어음내역지급점포교환소코드
	private String repaymentObligorCorpIndvSortCode; // 상환의무인법인개인구분코드
	private String repaymentObligorResidentBusinessNumber; // 상환의무인주민사업자번호
	private String repaymentObligorCorpName; // 상환의무인법인명
	private String repaymentObligorNameRepresentativeName; // 상환의무인성명(대표자명)
	private String repaymentObligorAddress; // 상환의무인주소
	private String repaymentObligorBankCode; // 상환의무인은행코드
	private String repaymentObligorCurrentAccountNumber; // 상환의무인당좌계좌번호
	private String repaymentClaimantCorpIndvSortCode; // 상환청구인법인개인구분코드
	private String repaymentClaimantResidentBusinessNumber; // 상환청구인주민사업자번호
	private String repaymentClaimantCorpName; // 상환청구인법인명
	private String repaymentClaimantNameRepresentativeName; // 상환청구인성명(대표자명)
	private String repaymentClaimantAddress; // 상환청구인주소
	private String repaymentClaimantBankCode; // 상환청구인은행코드
	private String repaymentClaimantDepositAccountNumber; // 상환청구인수취계좌번호
	private String depositRejectionDate; // 입금(거절)일자
	private long repaymentClaimAmount; // 상환청구금액
	private String repaymentClaimantSplitNumber; // 상환청구인분할번호
	private String repaymentClaimantEndorsementNumber; // 상환청구인배서번호
	private String repaymentClaimDesignationDate; // 상환청구인지정일자
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String type$; // 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDate$; // 상환청구일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligationFulfillmentRegistrationDate$; // 상환의무이행등록일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligationFulfillmentConfirmationDate$; // 상환의무이행확인일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payingBranchClearingHouseCode$; // 어음내역지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpIndvSortCode$; // 상환의무인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorResidentBusinessNumber$; // 상환의무인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpName$; // 상환의무인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorNameRepresentativeName$; // 상환의무인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorAddress$; // 상환의무인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorBankCode$; // 상환의무인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCurrentAccountNumber$; // 상환의무인당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpIndvSortCode$; // 상환청구인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantResidentBusinessNumber$; // 상환청구인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpName$; // 상환청구인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantNameRepresentativeName$; // 상환청구인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantAddress$; // 상환청구인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantBankCode$; // 상환청구인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantDepositAccountNumber$; // 상환청구인수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositRejectionDate$; // 입금(거절)일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimAmount$; // 상환청구금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantSplitNumber$; // 상환청구인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantEndorsementNumber$; // 상환청구인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDesignationDate$; // 상환청구인지정일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음내역전자어음번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentObligorResidentBusinessNumber$)) { // 상환의무인주민사업자번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentObligorCurrentAccountNumber$)) { // 상환의무인당좌계좌번호
			return 31;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantResidentBusinessNumber$)) { // 상환청구인주민사업자번호
			return 33;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantDepositAccountNumber$)) { // 상환청구인수취계좌번호
			return 38;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		type$ = VOUtils.write(out, type, 1); // 구분
		repaymentClaimDate$ = VOUtils.write(out, repaymentClaimDate, 8); // 상환청구일자
		repaymentObligationFulfillmentRegistrationDate$ = VOUtils.write(out, repaymentObligationFulfillmentRegistrationDate, 8); // 상환의무이행등록일자
		repaymentObligationFulfillmentConfirmationDate$ = VOUtils.write(out, repaymentObligationFulfillmentConfirmationDate, 8); // 상환의무이행확인일자
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음내역전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음내역어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음내역전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음내역전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음내역전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		payingBranchClearingHouseCode$ = VOUtils.write(out, payingBranchClearingHouseCode, 2); // 어음내역지급점포교환소코드
		repaymentObligorCorpIndvSortCode$ = VOUtils.write(out, repaymentObligorCorpIndvSortCode, 1); // 상환의무인법인개인구분코드
		repaymentObligorResidentBusinessNumber$ = VOUtils.write(out, repaymentObligorResidentBusinessNumber, 13); // 상환의무인주민사업자번호
		repaymentObligorCorpName$ = VOUtils.write(out, repaymentObligorCorpName, 40, "EUC-KR"); // 상환의무인법인명
		repaymentObligorNameRepresentativeName$ = VOUtils.write(out, repaymentObligorNameRepresentativeName, 20, "EUC-KR"); // 상환의무인성명(대표자명)
		repaymentObligorAddress$ = VOUtils.write(out, repaymentObligorAddress, 60, "EUC-KR"); // 상환의무인주소
		repaymentObligorBankCode$ = VOUtils.write(out, repaymentObligorBankCode, 3); // 상환의무인은행코드
		repaymentObligorCurrentAccountNumber$ = VOUtils.write(out, repaymentObligorCurrentAccountNumber, 16); // 상환의무인당좌계좌번호
		repaymentClaimantCorpIndvSortCode$ = VOUtils.write(out, repaymentClaimantCorpIndvSortCode, 1); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber$ = VOUtils.write(out, repaymentClaimantResidentBusinessNumber, 13); // 상환청구인주민사업자번호
		repaymentClaimantCorpName$ = VOUtils.write(out, repaymentClaimantCorpName, 40, "EUC-KR"); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName$ = VOUtils.write(out, repaymentClaimantNameRepresentativeName, 20, "EUC-KR"); // 상환청구인성명(대표자명)
		repaymentClaimantAddress$ = VOUtils.write(out, repaymentClaimantAddress, 60, "EUC-KR"); // 상환청구인주소
		repaymentClaimantBankCode$ = VOUtils.write(out, repaymentClaimantBankCode, 3); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber$ = VOUtils.write(out, repaymentClaimantDepositAccountNumber, 16); // 상환청구인수취계좌번호
		depositRejectionDate$ = VOUtils.write(out, depositRejectionDate, 8); // 입금(거절)일자
		repaymentClaimAmount$ = VOUtils.write(out, repaymentClaimAmount, 15); // 상환청구금액
		repaymentClaimantSplitNumber$ = VOUtils.write(out, repaymentClaimantSplitNumber, 2); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber$ = VOUtils.write(out, repaymentClaimantEndorsementNumber, 2); // 상환청구인배서번호
		repaymentClaimDesignationDate$ = VOUtils.write(out, repaymentClaimDesignationDate, 8); // 상환청구인지정일자
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		type = VOUtils.toString(type$ = VOUtils.read(in, 1)); // 구분
		repaymentClaimDate = VOUtils.toString(repaymentClaimDate$ = VOUtils.read(in, 8)); // 상환청구일자
		repaymentObligationFulfillmentRegistrationDate = VOUtils.toString(repaymentObligationFulfillmentRegistrationDate$ = VOUtils.read(in, 8)); // 상환의무이행등록일자
		repaymentObligationFulfillmentConfirmationDate = VOUtils.toString(repaymentObligationFulfillmentConfirmationDate$ = VOUtils.read(in, 8)); // 상환의무이행확인일자
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		payingBranchClearingHouseCode = VOUtils.toString(payingBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 어음내역지급점포교환소코드
		repaymentObligorCorpIndvSortCode = VOUtils.toString(repaymentObligorCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상환의무인법인개인구분코드
		repaymentObligorResidentBusinessNumber = VOUtils.toString(repaymentObligorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환의무인주민사업자번호
		repaymentObligorCorpName = VOUtils.toString(repaymentObligorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환의무인법인명
		repaymentObligorNameRepresentativeName = VOUtils.toString(repaymentObligorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환의무인성명(대표자명)
		repaymentObligorAddress = VOUtils.toString(repaymentObligorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환의무인주소
		repaymentObligorBankCode = VOUtils.toString(repaymentObligorBankCode$ = VOUtils.read(in, 3)); // 상환의무인은행코드
		repaymentObligorCurrentAccountNumber = VOUtils.toString(repaymentObligorCurrentAccountNumber$ = VOUtils.read(in, 16)); // 상환의무인당좌계좌번호
		repaymentClaimantCorpIndvSortCode = VOUtils.toString(repaymentClaimantCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber = VOUtils.toString(repaymentClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환청구인주민사업자번호
		repaymentClaimantCorpName = VOUtils.toString(repaymentClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName = VOUtils.toString(repaymentClaimantNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환청구인성명(대표자명)
		repaymentClaimantAddress = VOUtils.toString(repaymentClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환청구인주소
		repaymentClaimantBankCode = VOUtils.toString(repaymentClaimantBankCode$ = VOUtils.read(in, 3)); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber = VOUtils.toString(repaymentClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환청구인수취계좌번호
		depositRejectionDate = VOUtils.toString(depositRejectionDate$ = VOUtils.read(in, 8)); // 입금(거절)일자
		repaymentClaimAmount = VOUtils.toLong(repaymentClaimAmount$ = VOUtils.read(in, 15)); // 상환청구금액
		repaymentClaimantSplitNumber = VOUtils.toString(repaymentClaimantSplitNumber$ = VOUtils.read(in, 2)); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber = VOUtils.toString(repaymentClaimantEndorsementNumber$ = VOUtils.read(in, 2)); // 상환청구인배서번호
		repaymentClaimDesignationDate = VOUtils.toString(repaymentClaimDesignationDate$ = VOUtils.read(in, 8)); // 상환청구인지정일자
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", type=").append(type).append(System.lineSeparator()); // 구분
		sb.append(", repaymentClaimDate=").append(repaymentClaimDate).append(System.lineSeparator()); // 상환청구일자
		sb.append(", repaymentObligationFulfillmentRegistrationDate=").append(repaymentObligationFulfillmentRegistrationDate).append(System.lineSeparator()); // 상환의무이행등록일자
		sb.append(", repaymentObligationFulfillmentConfirmationDate=").append(repaymentObligationFulfillmentConfirmationDate).append(System.lineSeparator()); // 상환의무이행확인일자
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", payingBranchClearingHouseCode=").append(payingBranchClearingHouseCode).append(System.lineSeparator()); // 어음내역지급점포교환소코드
		sb.append(", repaymentObligorCorpIndvSortCode=").append(repaymentObligorCorpIndvSortCode).append(System.lineSeparator()); // 상환의무인법인개인구분코드
		sb.append(", repaymentObligorResidentBusinessNumber=").append(repaymentObligorResidentBusinessNumber).append(System.lineSeparator()); // 상환의무인주민사업자번호
		sb.append(", repaymentObligorCorpName=").append(repaymentObligorCorpName).append(System.lineSeparator()); // 상환의무인법인명
		sb.append(", repaymentObligorNameRepresentativeName=").append(repaymentObligorNameRepresentativeName).append(System.lineSeparator()); // 상환의무인성명(대표자명)
		sb.append(", repaymentObligorAddress=").append(repaymentObligorAddress).append(System.lineSeparator()); // 상환의무인주소
		sb.append(", repaymentObligorBankCode=").append(repaymentObligorBankCode).append(System.lineSeparator()); // 상환의무인은행코드
		sb.append(", repaymentObligorCurrentAccountNumber=").append(repaymentObligorCurrentAccountNumber).append(System.lineSeparator()); // 상환의무인당좌계좌번호
		sb.append(", repaymentClaimantCorpIndvSortCode=").append(repaymentClaimantCorpIndvSortCode).append(System.lineSeparator()); // 상환청구인법인개인구분코드
		sb.append(", repaymentClaimantResidentBusinessNumber=").append(repaymentClaimantResidentBusinessNumber).append(System.lineSeparator()); // 상환청구인주민사업자번호
		sb.append(", repaymentClaimantCorpName=").append(repaymentClaimantCorpName).append(System.lineSeparator()); // 상환청구인법인명
		sb.append(", repaymentClaimantNameRepresentativeName=").append(repaymentClaimantNameRepresentativeName).append(System.lineSeparator()); // 상환청구인성명(대표자명)
		sb.append(", repaymentClaimantAddress=").append(repaymentClaimantAddress).append(System.lineSeparator()); // 상환청구인주소
		sb.append(", repaymentClaimantBankCode=").append(repaymentClaimantBankCode).append(System.lineSeparator()); // 상환청구인은행코드
		sb.append(", repaymentClaimantDepositAccountNumber=").append(repaymentClaimantDepositAccountNumber).append(System.lineSeparator()); // 상환청구인수취계좌번호
		sb.append(", depositRejectionDate=").append(depositRejectionDate).append(System.lineSeparator()); // 입금(거절)일자
		sb.append(", repaymentClaimAmount=").append(repaymentClaimAmount).append(System.lineSeparator()); // 상환청구금액
		sb.append(", repaymentClaimantSplitNumber=").append(repaymentClaimantSplitNumber).append(System.lineSeparator()); // 상환청구인분할번호
		sb.append(", repaymentClaimantEndorsementNumber=").append(repaymentClaimantEndorsementNumber).append(System.lineSeparator()); // 상환청구인배서번호
		sb.append(", repaymentClaimDesignationDate=").append(repaymentClaimDesignationDate).append(System.lineSeparator()); // 상환청구인지정일자
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "280000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "type", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationFulfillmentRegistrationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationFulfillmentConfirmationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "payingBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentObligorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentObligorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentObligorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentObligorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentObligorCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentClaimantNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "depositRejectionDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentClaimAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "repaymentClaimantSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimantEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimDesignationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
