package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.KftEnt0200210000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 회원정보 등록 변경 해지 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드
 * messageType 전문종별코드
 * messageCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 210000
 * sendReceiveFlag 송수신FLAG
 * transactionIdNumber 거래고유번호
 * status STATUS
 * responseCode1 응답코드1
 * responseCode2 응답코드2
 * messageSendTime 전문전송일시
 * kftcStatisticsCode 관리기관통계코드
 * processSort 처리구분
 * corpIndvSort 법인개인구분
 * residentBusinessNumber 주민사업자번호
 * nameRepresentativeName 성명(대표자명)
 * corpName 법인명
 * address 주소
 * phoneNumber 전화번호
 * mobilePhoneNumber 핸드폰번호
 * emailAddress 이메일주소
 * paymentBranchClearingHouseCode 지급점포교환소코드
 * paymentRegisterRequestBankCode 지급(등록의뢰)은행코드
 * paymentRegisterRequestBankBranchCode 지급(등록의뢰)은행지점코드
 * eNotecurrentTransactionStartEndDate 전자어음당좌거래개시(해지)일자
 * currentAccountNumber 당좌계좌번호
 * companySize 기업규모
 * industryCode 업종코드
 * limitAmount 한도금액
 * depositAccountNumber 입금계좌번호
 * memberSort 회원구분
 * afterChangeCurrentAccountNumber 변경후당좌계좌번호
 * afterChangeDepositAccountNumber 변경후입금계좌번호
 */
@Mapper(componentModel = "spring", imports = {LocalDateTime.class, BigDecimal.class, DateUtils.class, EntConst.class, ComConst.class})
public interface KftEnt0200210000EntMbrL extends Converter<KftEnt0200210000, EntMbrL> {
    @Override
    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())")
    @Mapping(target = "entTlgTrceNo", source = "messageTrackingNumber")
    @Mapping(target = "trUnqNo", source = "transactionIdNumber")
    @Mapping(target = "hostNo", ignore = true)
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.INBOUND_CD)")
    @Mapping(target = "othrPartyBnkCd", ignore = true)
    @Mapping(target = "sysDvsn", source = "systemId")
    @Mapping(target = "bnkCd", source = "bnkCd")
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType")
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode")
    @Mapping(target = "sndRcvDvsnCd", source = "sendReceiveFlag")
    @Mapping(target = "trSts", source = "status")
    @Mapping(target = "respCd1", source = "responseCode1")
    @Mapping(target = "respCd2", source = "responseCode2")
    @Mapping(target = "tlgTrDt", source = "messageSendTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "messageSendTime", dateFormat = "HHmmss")
    @Mapping(target = "kftcStattcCd", source = "kftcStatisticsCode")
    @Mapping(target = "trMemo", ignore = true)
    @Mapping(target = "srchCondSort", ignore = true)
    @Mapping(target = "condCtzBizNoEnc", ignore = true)
    @Mapping(target = "condBnkCd", ignore = true)
    @Mapping(target = "condDpstAcctNo", ignore = true)
    @Mapping(target = "ctzBizNoEnc", ignore = true)
    @Mapping(target = "currAcctNo", source = "currentAccountNumber")
    @Mapping(target = "dpstAcctNo", source = "depositAccountNumber")
    @Mapping(target = "ctzBizNo", source = "residentBusinessNumber")
    @Mapping(target = "entPrcsDvsnCd", source = "processSort")
    @Mapping(target = "corpIndvDvsnCd", source = "corpIndvSort")
    @Mapping(target = "repNm", source = "nameRepresentativeName")
    @Mapping(target = "corpNm", source = "corpName")
    @Mapping(target = "mbrAddr", source = "address")
    @Mapping(target = "mbrTelNo", source = "phoneNumber")
    @Mapping(target = "mbrMobileNo", source = "mobilePhoneNumber")
    @Mapping(target = "mbrEmail", source = "emailAddress")
    @Mapping(target = "pymntExCd", source = "paymentBranchClearingHouseCode")
    @Mapping(target = "pymntRqstRegBnkCd", source = "paymentRegisterRequestBankCode")
    @Mapping(target = "pymntBnkBrnchCd", source = "paymentRegisterRequestBankBranchCode")
    @Mapping(target = "entCurrOpnDt", source = "ENoteCurrentTransactionStartEndDate")
    @Mapping(target = "corpSizeCd", source = "companySize")
    @Mapping(target = "bizCd", source = "industryCode")

    @Mapping(target = "srchCondSort2", ignore = true)
    @Mapping(target = "condCtzBizNoEnc2", ignore = true)
    @Mapping(target = "condBnkCd2", ignore = true)
    @Mapping(target = "condDpstAcctNo2", ignore = true)
    @Mapping(target = "corpIndvDvsnCd2", ignore = true)
    @Mapping(target = "repNm2", ignore = true)
    @Mapping(target = "corpNm2", ignore = true)
    @Mapping(target = "mbrAddr2", ignore = true)
    @Mapping(target = "mbrTelNo2", ignore = true)
    @Mapping(target = "mbrMobileNo2", ignore = true)
    @Mapping(target = "mbrEmail2", ignore = true)
    @Mapping(target = "corpSizeCd2", ignore = true)
    @Mapping(target = "mbrDvsnCd2", ignore = true)
    @Mapping(target = "bizCd2", ignore = true)

    @Mapping(target = "lmtAmt", expression = "java(BigDecimal.valueOf(source.getLimitAmount()))")
    @Mapping(target = "mbrDvsnCd", source = "memberSort")
    @Mapping(target = "chgAfCurrAcctNo", source = "afterChangeCurrentAccountNumber")
    @Mapping(target = "chgAfDpstAcctNo", source = "afterChangeDepositAccountNumber")
    @Mapping(target = "frstChngGuid", ignore = true)
    @Mapping(target = "frstChngStaffId", ignore = true)
    @Mapping(target = "frstChngTmstmp", ignore = true)
    @Mapping(target = "lastChngGuid", ignore = true)
    @Mapping(target = "lastChngStaffId", ignore = true)
    @Mapping(target = "lastChngTmstmp", ignore = true)
    EntMbrL convert(KftEnt0200210000 source);

}
