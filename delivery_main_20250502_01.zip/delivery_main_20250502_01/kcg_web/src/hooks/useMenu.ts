import { BwgContext } from "@/components/BwgContext"
import { useContext, lazy } from "react"
import useModal from "@/hooks/useModal"
import useProxy from "@/hooks/useProxy"
import useRecoil from "@/hooks/useRecoil"
import { $storageUtils } from "@/utils/common.storage"
// import dynamic from "next/dynamic"
import { Menu, SelectMenu } from "../types"
import CONFIG from "@/config/siteConfig"
import { $i18nUtils } from "@/utils/common.i18n"

function useMenu() {
  const { actions } = useContext(BwgContext)
  const $proxyHooks = useProxy()
  const $recoilHooks = useRecoil()
  const $modalHooks = useModal()

  const roleList = $storageUtils.session("roleList")

  /**
   * 가이드 메뉴 가져오기
   * @returns
   */
  const getGuideMenu = () => {
    const menuId = 1000
    const list = [
      {
        upperMenuId: "0000000",
        menuId: "0900000", /// //////////////////////////////////////////////// ROOT
        menuNm: "Guide",
        scrnUseYn: "Y",
        level: 1,
      },
      {
        upperMenuId: "0900000",
        menuId: "0901000", /// //////////////////////////////////////////////// 샘플 페이지
        menuNm: "Sample",
        scrnUseYn: "Y",
        level: 2,
      },
      {
        upperMenuId: "0901000",
        menuId: "0901001", // 샘플 페이지 > 검색조건 + 그리드
        menuNm: "검색조건 + 그리드",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "USUIATEST01",
        menuLink: "pages/guide/sample/USUIATEST01",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901002", // 샘플 페이지 > 검색조건 + 그리드 + 상세
        menuNm: "검색조건 + 그리드 + 상세",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "USUIATEST02",
        menuLink: "pages/guide/sample/USUIATEST02",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901003", // 샘플 페이지 > 검색조건 + 탭
        menuNm: "검색조건 + 탭",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "USUIATEST03",
        menuLink: "pages/guide/sample/USUIATEST03",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901004", // 샘플 페이지 > 트리 + 상세 + 그리드
        scrnId: "USUIATEST04",
        menuNm: "트리 + 상세 + 그리드",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST04",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901005", // 샘플 페이지 > 팝업
        scrnId: "USUIATEST05",
        menuNm: "팝업",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST05",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901006", // 샘플 페이지 > 유효성 체크
        scrnId: "USUIATEST06",
        menuNm: "유효성 체크",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST06",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901007", // 샘플 페이지 > 이미지뷰어
        scrnId: "USUIATEST07",
        menuNm: "이미지뷰어",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST07",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901008", // 샘플 페이지 > 자료
        scrnId: "USUIATEST08",
        menuNm: "Data파싱",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST08",
      },
      {
        upperMenuId: "0901000",
        menuId: "0901009", // 샘플 페이지 > 리코일
        scrnId: "USUIATEST09",
        menuNm: "recoil",
        scrnUseYn: "Y",
        level: 3,
        menuLink: "pages/guide/sample/USUIATEST09",
      },
      {
        upperMenuId: "0900000",
        menuId: "0902000", /// //////////////////////////////////////////////// 샘플 페이지
        menuNm: "Component",
        scrnUseYn: "Y",
        level: 2,
      },
      {
        upperMenuId: "0902000",
        menuId: "0902001", // 샘플 페이지 > Component List
        menuNm: "Popup",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "PopupSample",
        menuLink: "pages/guide/component/PopupSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902002", // 샘플 페이지 > Component List
        menuNm: "Push",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "PushSample",
        menuLink: "pages/guide/component/PushSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902003", // 샘플 페이지 > Component List
        menuNm: "Input",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "InputSample",
        menuLink: "pages/guide/component/InputSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902004", // 샘플 페이지 > Component List
        menuNm: "Button",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "ButtonSample",
        menuLink: "pages/guide/component/ButtonSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902005", // 샘플 페이지 > Component List
        menuNm: "Select",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "SelectSample",
        menuLink: "pages/guide/component/SelectSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902006", // 샘플 페이지 > Component List
        menuNm: "Tab",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "TabSample",
        menuLink: "pages/guide/component/TabSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902007", // 샘플 페이지 > Component List
        menuNm: "Date",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "DateSample",
        menuLink: "pages/guide/component/DateSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902008", // 샘플 페이지 > Component List
        menuNm: "Tree",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "TreeSample",
        menuLink: "pages/guide/component/TreeSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902009", // 샘플 페이지 > Component List
        menuNm: "CheckBox",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "CheckBoxSample",
        menuLink: "pages/guide/component/CheckBoxSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902010", // 샘플 페이지 > Component List
        menuNm: "RadioBox",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "RadioBoxSample",
        menuLink: "pages/guide/component/RadioBoxSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902011", // 샘플 페이지 > Component List
        menuNm: "Switch",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "SwitchSample",
        menuLink: "pages/guide/component/SwitchSample",
      },
      {
        upperMenuId: "0902000",
        menuId: "0902012", // 샘플 페이지 > Component List
        menuNm: "MultiSelect",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "MultiSelectSample",
        menuLink: "pages/guide/component/MultiSelectSample",
      },
      {
        upperMenuId: "0900000",
        menuId: "0903000", /// //////////////////////////////////////////////// 그리드 샘플
        menuNm: "Grid",
        scrnUseYn: "Y",
        level: 2,
      },
      {
        upperMenuId: "0903000",
        menuId: "0903001", // 샘플 페이지 > Component List
        menuNm: "Normal",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "Normal",
        menuLink: "pages/guide/grid/NormalSample",
      },
      {
        upperMenuId: "0903000",
        menuId: "0903002", // 샘플 페이지 > Component List
        menuNm: "Paging",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "PagingSample",
        menuLink: "pages/guide/grid/PagingSample",
      },
      {
        upperMenuId: "0903000",
        menuId: "0903003", // 샘플 페이지 > Component List
        menuNm: "CellRender",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "CellRenderSample",
        menuLink: "pages/guide/grid/CellRenderSample",
      },
      {
        upperMenuId: "0903000",
        menuId: "0903004", // 샘플 페이지 > Component List
        menuNm: "import/export",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "ImportExportSample",
        menuLink: "pages/guide/grid/ImportExportSample",
      },
      {
        upperMenuId: "0903000",
        menuId: "0903005", // 샘플 페이지 > Component List
        menuNm: "Edit",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "EditSample",
        menuLink: "pages/guide/grid/EditSample",
      },
      {
        upperMenuId: "0900000",
        menuId: "0904000", /// //////////////////////////////////////////////// UI/UX 샘플
        menuNm: "UI/UX",
        scrnUseYn: "Y",
        level: 2,
      },
      {
        upperMenuId: "0904000",
        menuId: "0904001", // 샘플 페이지 > Component List
        menuNm: "배치결과조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample1",
        menuLink: "pages/guide/uiux/UIUXSample1",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904002", // 샘플 페이지 > Component List
        menuNm: "전문관리",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample2",
        menuLink: "pages/guide/uiux/UIUXSample2",
      },

      {
        upperMenuId: "0904000",
        menuId: "0904003", // 샘플 페이지 > Component List
        menuNm: "거래내역조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample3",
        menuLink: "pages/guide/uiux/UIUXSample3",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904004", // 샘플 페이지 > Component List
        menuNm: "KFTC송수신내역조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample4",
        menuLink: "pages/guide/uiux/UIUXSample4",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904005", // 샘플 페이지 > Component List
        menuNm: "수취인조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample5",
        menuLink: "pages/guide/uiux/UIUXSample5",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904006", // 샘플 페이지 > Component List
        menuNm: "회원정보 현황",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample6",
        menuLink: "pages/guide/uiux/UIUXSample6",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904007", // 샘플 페이지 > Component List
        menuNm: "출금이체 정보 조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample7",
        menuLink: "pages/guide/uiux/UIUXSample7",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904008", // 샘플 페이지 > Component List
        menuNm: "메뉴유지",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample8",
        menuLink: "pages/guide/uiux/UIUXSample8",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904009", // 샘플 페이지 > Component List
        menuNm: "배치작업유지",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample9",
        menuLink: "pages/guide/uiux/UIUXSample9",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904010", // 샘플 페이지 > Component List
        menuNm: "공통코드유지",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample10",
        menuLink: "pages/guide/uiux/UIUXSample10",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904011", // 샘플 페이지 > Component List
        menuNm: "배치결과조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample11",
        menuLink: "pages/guide/uiux/UIUXSample11",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904012", // 샘플 페이지 > Component List
        menuNm: "컴퍼넌트 유형별 정리",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample12",
        menuLink: "pages/guide/uiux/UIUXSample12",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904013", // 샘플 페이지 > Component List
        menuNm: "서비스선택팝업테스트",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample13",
        menuLink: "pages/guide/uiux/UIUXSample13",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904014", // 샘플 페이지 > Component List
        menuNm: "거래집계조회",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample14",
        menuLink: "pages/guide/uiux/UIUXSample14",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904015", // 샘플 페이지 > Component List
        menuNm: "대시보드 Type1",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample15",
        menuLink: "pages/guide/uiux/UIUXSample15",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904016", // 샘플 페이지 > Component List
        menuNm: "대시보드 2차오픈",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample16",
        menuLink: "pages/guide/uiux/UIUXSample16",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904018", // 샘플 페이지 > Component List
        menuNm: "대시보드 1차오픈",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample18",
        menuLink: "pages/guide/uiux/UIUXSample18",
      },
      {
        upperMenuId: "0904000",
        menuId: "0904017", // 샘플 페이지 > Component List
        menuNm: "탭스타일",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UIUXSample17",
        menuLink: "pages/guide/uiux/UIUXSample17",
      },
      {
        upperMenuId: "0900000",
        menuId: "0905000",
        menuNm: "Generator",
        scrnUseYn: "Y",
        level: 2,
      },
      {
        upperMenuId: "0905000",
        menuId: "0904019",
        menuNm: "Code 생성",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UCODEGEN",
        menuLink: "pages/guide/generator/UCODEGEN",
      },
      {
        upperMenuId: "0905000",
        menuId: "0904020",
        menuNm: "Cron Generator",
        scrnUseYn: "Y",
        level: 3,
        scrnId: "UCRONGEN",
        menuLink: "pages/guide/generator/UCRONGEN",
      },
    ]

    const isTechRole = roleList.some((roleObj: any) =>
      roleObj.roleNm.includes("TECH"),
    )
    // return process.env.NODE_ENV === "development" ? list : [] // ※ 로컬 환경(npm run dev)에서만 가이드메뉴 list 내보낸다 (package.json 참조)
    // return true ? list : []
    // return CONFIG.ENV.MODE === "L" ? list : []
    return isTechRole ? list : []
  }

  /**
   * 메뉴이동 (/main 내에서 메니 이동)
   * @param {object} selectedMenuInfo : 메뉴정보
   */
  const openBizComponent = (selectedMenuInfo: any = {}) =>
    new Promise((resolve, reject) => {
      const test = "components/LoadingShimmer"
      const menuList = {
        ...selectedMenuInfo,
        selected: true,
        // instance:
        //   selectedMenuInfo.path.indexOf("sample") > -1 ||
        //   selectedMenuInfo.path.indexOf("component") > -1
        //     ? dynamic(import(`@/pages/guide/${selectedMenuInfo.path}.tsx`))
        //     : dynamic(import(`@/pages/views/${selectedMenuInfo.scrnId}.tsx`)),
        // instance: `/src/${selectedMenuInfo.menuLink}.tsx`,
        // instance: dynamic(import(`/src/${selectedMenuInfo.menuLink}.tsx`)),
        // TODO: dynamic loading Shimmer 페이지 적용시 이벤트 처리 & 리렌더링 이슈
        // TODO: 아래와 같이 적용시 텍스트로 먹음
        instance: lazy(() => import(`/src/${selectedMenuInfo.menuLink}.tsx`)),
        // instance: dynamic(import(`/src/${selectedMenuInfo.menuLink}.tsx`), {
        //   // loading: () => "<p>Loading...</p>", //import("@/components/LoadingShimmer.tsx"),
        // }),
      }

      // $storageUtils.session('scrnId', selectedMenuInfo.scrnId)
      // $storageHooks.commit('addMyMenuList', menuList)
      // $recoilHooks.dispatch("setLoadingShimmer", true) // 로딩쉬머페이지 on
      actions.setLoadingShimmer(true)
      $recoilHooks.dispatch("addMyMenuList", menuList)

      // TODO 세션, recoil 에 화면식별자 설정
      $storageUtils.session("scrnId", selectedMenuInfo.scrnId)
      moveTabScrollLeft() // 메뉴위치조정
      resolve("")
    })

  /**
   * 메뉴가 존재하는지 체크
   * @param path
   * @returns
   */
  const doesPageExist = async (path: string) => {
    try {
      await import(`/src/${path}.tsx`)
      return true
    } catch (error) {
      return false
    }
  }

  /**
   * 화면오픈
   * 1. 1레벨 메뉴 선택
   * 2. 2레벨 메뉴 펼침
   * 3. 화면 오픈
   * @param {object} selectedMenuInfo : 메뉴정보
   */
  const openMenu = async (selectedMenuInfo: any) =>
    new Promise(async (resolve, reject) => {
      const { myMenuList } = $recoilHooks.selector("menu")

      const index = myMenuList.findIndex(
        (d: any) => d.scrnId === selectedMenuInfo.scrnId,
      )

      if (index === -1) {
        // 메뉴가 존재하는지 확인
        const isExsit = await doesPageExist(selectedMenuInfo.menuLink)
        if (!isExsit) {
          $modalHooks.alert({
            content: `The biz screen [${
              selectedMenuInfo.scrnId || selectedMenuInfo.targetScrnId
            }] does not exist.`,
          })
          reject()
          return
        }

        if (selectedMenuInfo) {
          // 토글처리
          openToggleSubMenuPanel(true)
          // 화면열림
          openBizComponent(selectedMenuInfo).then(() => {
            resolve("")
          })
        } else {
          // 메뉴가 존재하지 않음
          // $modalHooks.alert({ content: '메뉴가 존재하지 않습니다.' })
        }
      }
      // 기존 메뉴인 경우
      else {
        if (selectedMenuInfo?.params) {
          $recoilHooks.dispatch("openMyMenuList", selectedMenuInfo)
        } else {
          $recoilHooks.dispatch("selectMyMenuList", selectedMenuInfo)
        }
        resolve("")
      }
    })

  /**
   * 화면ID로 화면 이동하기
   * @param scrnId 화면ID
   * @param params 전달 파라미터
   */
  const openMenuByScrnId = (scrnId: string, params: any) => {
    // 모든메뉴와 출력메뉴를 가져옴
    const { allMenuList, printMenuList } = $recoilHooks.selector("menu")
    const flatAllMenuList: Menu[] = []
    flatModel(flatAllMenuList, allMenuList, "children")
    // 1. 전체메뉴에서 해당 메뉴가 있는지 확인
    const isExsit = flatAllMenuList.some((menu: Menu) => menu.scrnId === scrnId)
    if (!isExsit) {
      $modalHooks.alert({
        content: `The biz screen [${scrnId}] does not exist.`,
      })
      return
    }

    const flatPrintMenuList: Menu[] = []
    flatModel(flatPrintMenuList, printMenuList, "children")
    // 2. 출력메뉴에서 해당 메뉴가 있는지 확인
    const isHavingRole = flatPrintMenuList.some(
      (menu: Menu) => menu.scrnId === scrnId,
    )
    if (!isHavingRole) {
      $modalHooks.alert({ content: `No menu permission for [${scrnId}].` }) //
      return
    }

    const selectdMenuInfo = flatPrintMenuList.find(
      (menu: any) => menu.scrnId === scrnId,
    )
    const menuInfo = {
      ...selectdMenuInfo,
      targetScrnId: scrnId,
      params,
    }
    openMenu(menuInfo)
  }

  /**
   * 메뉴 패널 토글
   * @param {boolean} isShow : 오픈여부
   */
  const openToggleSubMenuPanel = (isShow: boolean) => {
    $recoilHooks.dispatch("isToggleSubMenuPanel", isShow)
  }

  /**
   * 즐겨찾기 목록 가져오기
   * @returns
   */
  const getFavoriteList = () =>
    new Promise((resolve, reject) => {
      const favoriteList = $recoilHooks.selector("favorite", "favoriteList")

      if (favoriteList?.length > 0) {
        resolve(favoriteList)
      } else {
        const param = {
          interfaceCd: "cmn",
          interfaceId: "getFvrtsMenuList",
          staffId: $storageUtils.session("staffId"),
        }
        $proxyHooks.async(param).then((response: any) => {
          const fvrtsList = response.data.fvrtsList || []

          resolve(fvrtsList)
        })
      }
    })

  /**
   * 즐겨찾기 목록 변경
   * @param isAdd : 추가여부
   * @param menuInfo : 메뉴정보
   * @returns
   */
  const modifyFavoriteMenu = (isAdd: boolean, menuInfo: any) =>
    new Promise((resolve, reject) => {
      const param = {
        interfaceCd: "cmn",
        interfaceId: isAdd ? "registerFvrtsMenu" : "removeFvrtsMenu",
        staffId: $storageUtils.session("staffId"),
        menuId: menuInfo.menuId,
      }
      const options = {
        disableLoading: true,
      }
      $proxyHooks.async(param, options).then((response: any) => {
        if (isAdd) {
          $recoilHooks.dispatch("addFavoriteList", menuInfo)
        } else {
          $recoilHooks.dispatch("deleteFavoriteList", menuInfo)
        }
        resolve("")
      })
    })

  /**
   * 선택된 메뉴를 스토어에 저장
   * @param selectedMenuArray : 선택된 메뉴 목록
   */
  const selectPrintMenuList = (selectedMenuArray: any) => {
    // const selectedMenu = $recoilHooks.selector("menu", "selectMenuList") || {}
    // 출력메뉴를 가져옴
    const menuList = $recoilHooks.selector("menu", "printMenuList")

    // flat 한 메뉴로 변환
    let flatList: Menu = []
    flatModel(flatList, menuList, "children")
    // const includesArr = []

    flatList = flatList.map((menu: Menu) => ({
      ...menu,
      children: null,
      selected: selectedMenuArray.includes(menu.menuId),
    }))

    // 계층형으로 변환
    setPrintMenuList(flatList)
    //
  }

  /**
   * 화면 전체 메뉴를 스토어에 저장
   * @param flatList : 플랫 배열
   */
  const setAllMenuList = (flatList: any) => {
    const hierarchicalList = treeModel(flatList, "0000000")

    $recoilHooks.dispatch("setAllMenuList", hierarchicalList)
  }

  /**
   * 화면 출력 메뉴를 스토어에 저장
   * @param flatList : 플랫 배열
   */
  const setPrintMenuList = (flatList: any) => {
    const hierarchicalList = treeModel(flatList, "0000000")

    $recoilHooks.dispatch("setPrintMenuList", hierarchicalList)
  }

  /**
   * 선택된 메뉴목록을 설정한다
   * @param selectMenu : 선택된 메뉴
   */
  const setSelectMenuList = (selectMenu: SelectMenu) => {
    // 선택한 메뉴를 저장해 둔다
    $recoilHooks.dispatch("setSelectMenuList", selectMenu)

    const selectedMenuArray = [
      selectMenu.level1,
      ...selectMenu.level2, // 2레벨은 배열
      selectMenu.level3,
    ]
    // 출력메뉴를 갱신한다.
    selectPrintMenuList(selectedMenuArray)
  }

  /**
   * 메뉴 선택시 메뉴출력을 동기화한다.
   * @param menu : 메뉴정보
   */
  const selectMyMenuList = (menu: Menu) => {
    // $recoilHooks.dispatch("setLoadingShimmer", false) // 로딩쉬머페이지 off
    actions.setLoadingShimmer(false)
    $recoilHooks.dispatch("selectMyMenuList", menu)
    // Recoil 동기화가 되지 않아 직접 구한다.
    // 메뉴출력 동기화
    selectPrintMenuByMyMenu(menu)
  }

  /**
   * 메뉴 선택시 메뉴출력을 동기화한다.
   * @param menu : 메뉴정보
   */
  const selectMyMenuListForOutSideClick = (menu: Menu) => {
    // $recoilHooks.dispatch("setLoadingShimmer", false) // 로딩쉬머페이지 off
    actions.setLoadingShimmer(false)
    // Recoil 동기화가 되지 않아 직접 구한다.
    // 메뉴출력 동기화
    selectPrintMenuByMyMenu(menu)
  }

  /**
   * 메뉴 삭제시 메뉴출력을 동기화한다.
   * @param menu : 메뉴정보
   */
  const deleteMyMenuList = (menu: Menu) => {
    $recoilHooks.dispatch("deleteMyMenuList", menu)
    // Recoil 동기화가 되지 않아 직접 구한다.
    const myMenuList = $recoilHooks.selector("menu", "myMenuList")
    // 인덱스를 구한다.
    const selectedIndex = myMenuList.findIndex(
      (item: any) => item.scrnId === menu.scrnId,
    )
    let newSelectedIndex = 0 // 새로 select될 메뉴 index
    if (myMenuList.length - 1 === selectedIndex) {
      // 마지막것인경우
      newSelectedIndex = myMenuList.length - 1
    } else {
      // 마지막이 아닌경우 현재 index 로 설정
      newSelectedIndex = selectedIndex
    }

    // 이 부분은 메뉴가 useRecoil의 deleteMyMenuList 함수와 동일하게 마지막 메뉴를 구함
    const menuList = myMenuList.filter(
      (item: any) => item.scrnId !== menu.scrnId,
    )
    // 메뉴의 마지막 인덱스를 선택된 메뉴로 변경한다.
    const newList = menuList.map((item: any, index: number) => ({
      ...item,
      selected: index === newSelectedIndex,
    }))
    const selectedMenu = newList.find((item: Menu) => item.selected)
    selectPrintMenuByMyMenu(selectedMenu)
  }

  /**
   * 메뉴 초기화 시 메뉴출력을 동기화한다.
   */
  const initMyMenuList = () => {
    $recoilHooks.dispatch("setMyMenuList", [])
    setSelectMenuList({
      level1: "",
      level2: [],
      level3: "",
    })
  }

  /**
   * 현재 메뉴 기준으로 출력메뉴를 지정한다.
   * @param menuInfo
   */
  const selectPrintMenuByMyMenu = (menuInfo: Menu) => {
    const menu = $recoilHooks.selector("menu")

    const { myMenuList, printMenuList } = menu

    if (menuInfo) {
      // 즐겨찾기 메뉴는 제외한다.
      const targetList = printMenuList.filter(
        (item: Menu) => item.menuId !== "favorite1",
      )
      const flatList: Menu[] = []

      flatModel(flatList, targetList, "children") // 재귀를 돌리기 위해 flat 하게 처리한다.
      let menuArr = [menuInfo.menuId] // 본인을 포함하여 상위 메뉴를 찾아 담는다.
      getUpperMenuId(menuArr, flatList, menuInfo.menuId) // 상위메뉴를 구한다.
      menuArr = menuArr.reverse() // 순서를 변경한다.

      // 출력메뉴를 갱신한다.
      selectPrintMenuList(menuArr)
      // 선택메뉴를 갱신한다
      setSelectMenuList({
        level1: menuArr[0],
        level2: [menuArr[1]],
        level3: menuArr[2],
      })

      $storageUtils.session("scrnId", menuInfo.scrnId)
    } else {
      // 출력메뉴를 갱신한다.
      selectPrintMenuList([])
      // 선택메뉴를 갱신한다
      setSelectMenuList({
        level1: "",
        level2: [],
        level3: "",
      })
    }
  }

  /**
   * 상위 메뉴를 가져온다.
   * @param menuArr : 빈배열(채울배열)
   * @param targetList : 타겟배열
   * @param menuKey : 메뉴키
   * @returns
   */
  const getUpperMenuId = (
    menuArr: string[],
    targetList: any,
    menuKey: string,
  ) => {
    const menuItem: Menu = targetList.find((d: Menu) => d.menuId === menuKey)
    if (menuItem.level !== 1) {
      menuArr.push(menuItem.upperMenuId)
      getUpperMenuId(menuArr, targetList, menuItem.upperMenuId)
    }
    return menuArr
  }

  /**
   * 메뉴의 경로를 가져온다.
   * @param menuArr : 빈배열(채울배열)
   * @param targetList : 타겟배열
   * @param menuKey : 메뉴키
   * @returns
   */
  const getPathName = (menuArr: string[], targetList: any, menuKey: string) => {
    const menuItem: Menu = targetList.find((d: Menu) => d.menuId === menuKey)
    if (menuItem && menuItem?.menuId !== "0000000" && menuItem?.level !== 0) {
      menuArr.push(menuItem?.menuNm)
      getPathName(menuArr, targetList, menuItem?.upperMenuId)
    }
    return menuArr
  }

  /**
   * 로그아웃
   * @param {string} path
   * @param {object} params
   */
  const logout = () =>
    new Promise((resolve, reject) => {
      // TODO: logout endpoint 적용시 풀기!!
      const param = {
        svcTp: "logout",
        interfaceCd: "cmn",
        interfaceId: "logout",
      }
      const options = {
        error: (response) => {
          // 전문통신 오류시 강제 로그 아웃
          $storageUtils.getSession()?.clear()
          $recoilHooks.reset()
          // 로딩창 닫기
          resolve("")
        },
      }
      $proxyHooks.async(param, options).then((response: any) => {
        // 로그인 후 세션 설정
        $storageUtils.getSession()?.clear()
        $recoilHooks.reset()
        // 로딩창 닫기
        resolve("")
      })
    })

  /**
   * 트리 구조 변환 메서드 (Flat한 목록을 트리형태로 변환)
   * @param flatList : 플랫 배열
   * @param rootId : 최상위 ID
   * @returns : 계층구조 반환
   */
  const treeModel = (arrayList: Menu[], rootId: string) => {
    const buildTree = (parentId: string): Menu[] => {
      const children: Menu[] = []
      for (let i = 0; i < arrayList.length; ) {
        const item = arrayList[i]
        if (item.upperMenuId === parentId) {
          children.push(item)
          arrayList.splice(i, 1)
        } else {
          i++
        }
      }
      for (const child of children) {
        child.children = buildTree(child.menuId)
      }
      return children
    }

    let rootNodes: Menu[] = buildTree(rootId)
    // Main(0000000) 화면 제거
    rootNodes = rootNodes.filter((item: Menu) => item.menuId !== "0000000")
    return rootNodes
  }

  /**
   * 트리를 Flat하게 변경
   * @param fillList : 빈배열(채울배열)
   * @param hierarchicalList : 계층 배열
   * @param childKey : 자식요소 키
   */
  const flatModel = (
    fillList: Menu[],
    hierarchicalList: Menu[],
    childKey: string,
  ) => {
    hierarchicalList.forEach((menu: Menu) => {
      fillList.push(menu)
      if (menu[childKey] instanceof Array) {
        flatModel(fillList, menu[childKey], childKey)
      }
    })
  }

  /**
   * 메뉴탭 위치 조정 (메뉴탭 스크롤 이동)
   */
  const moveTabScrollLeft = () => {
    setTimeout(() => {
      // const box = $('.main-tab');
      //   const boxWidth = box.width();
      //   const tab = $('.tab_' + vm.selectedTabId);
      //   const tabWidth = tab.width();
      //   const tabLeft = tab.position().left;
      //   const tabRight = tab.position().left + tabWidth;
      //   const tabIndex = vm.tabList.findIndex(d => d.id === vm.selectedTabId);

      //   if (tabRight > boxWidth) { // 보여질 탭이 오른쪽에 가려져 있을때
      //     box.animate({
      //       scrollLeft: tabRight - boxWidth + box.scrollLeft()
      //     }, 500)
      //   } else if (tabLeft < 0) { // 보여질 탭이 왼쪽에 가려져 있을때
      //     box.animate({
      //       scrollLeft: tabIndex * tabWidth
      //     }, 500)
      //   }
      const mainTab = document.querySelector(".main-tab") as HTMLElement
      const boxWidth = mainTab.getBoundingClientRect().width
      const tab = document.querySelector(".main-tab > li.active") as HTMLElement
      const tabWidth = tab.getBoundingClientRect().width // getBoundingClientRect()
      const tabLeft = tab.getBoundingClientRect().left
      const tabRight = tab.getBoundingClientRect().left + tabWidth
      // console.log(
      //   `moveTabScrollLeft boxWidth[${boxWidth}] tabRight[${tabRight}] boxWidth[${boxWidth}] tabLeft[${tabLeft}]`,
      // )
      if (tabRight > boxWidth) {
        // 보여질 탭이 오른쪽에 가려져 있을때
        mainTab.scrollLeft = tabRight - boxWidth + mainTab.scrollLeft
      } else if (tabLeft < 0) {
        // 보여질 탭이 왼쪽에 가려져 있을때
        mainTab.scrollLeft = tabLeft
      }
    })
  }

  return {
    openMenu,
    getFavoriteList,
    modifyFavoriteMenu,
    openMenuByScrnId,
    getGuideMenu,
    logout,
    getPathName,
    getUpperMenuId,
    openToggleSubMenuPanel,
    treeModel,
    flatModel,
    setAllMenuList,
    setPrintMenuList,
    setSelectMenuList,
    selectMyMenuList,
    selectMyMenuListForOutSideClick,
    deleteMyMenuList,
    initMyMenuList,
    moveTabScrollLeft,
  }
}

export default useMenu
