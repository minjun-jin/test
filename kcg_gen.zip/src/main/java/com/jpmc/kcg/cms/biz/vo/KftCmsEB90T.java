package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90T kftCmsEB90T  = new KftCmsEB90T(); // 이용기관정보통지
 * kftCmsEB90T.setRecordType(""); // Record 구분
 * kftCmsEB90T.setSerialNumber(""); // 일련번호
 * kftCmsEB90T.setInstitutionCode(""); // 기관코드
 * kftCmsEB90T.setFileName(""); // File 이름
 * kftCmsEB90T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEB90T.setFiller7(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private String filler7; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler7$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		filler7$ = VOUtils.write(out, filler7, 215); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		filler7 = VOUtils.toString(filler7$ = VOUtils.read(in, 215)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", filler7=").append(filler7).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler7", "fldLen", "215", "defltVal", "")
		);
	}

}
