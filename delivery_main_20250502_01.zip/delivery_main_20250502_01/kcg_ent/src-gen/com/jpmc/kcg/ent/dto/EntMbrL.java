package com.jpmc.kcg.ent.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;
import lombok.Generated;

@Data
@Generated
public class EntMbrL {
    private String trDt;

    private String entTlgTrceNo;

    private String trUnqNo;

    private String hostNo;

    private String entOutinDvsnCd;

    private String othrPartyBnkCd;

    private String sysDvsn;

    private String bnkCd;

    private String entTlgKndDvsnCd;

    private String entTlgTrDvsnCd;

    private String sndRcvDvsnCd;

    private String trSts;

    private String respCd1;

    private String respCd2;

    private String tlgTrDt;

    private String tlgSndTm;

    private String kftcStattcCd;

    private String trMemo;

    private String srchCondSort;

    private String condCtzBizNoEnc;

    private String condBnkCd;

    private String condDpstAcctNo;

    private String srchCondSort2;

    private String condCtzBizNoEnc2;

    private String condBnkCd2;

    private String condDpstAcctNo2;

    private String ctzBizNoEnc;

    private String currAcctNo;

    private String dpstAcctNo;

    private String ctzBizNo;

    private String entPrcsDvsnCd;

    private String corpIndvDvsnCd;

    private String repNm;

    private String corpNm;

    private String mbrAddr;

    private String mbrTelNo;

    private String mbrMobileNo;

    private String mbrEmail;

    private String pymntExCd;

    private String pymntRqstRegBnkCd;

    private String pymntBnkBrnchCd;

    private String entCurrOpnDt;

    private String corpSizeCd;

    private String bizCd;

    private BigDecimal lmtAmt;

    private String mbrDvsnCd;

    private String corpIndvDvsnCd2;

    private String repNm2;

    private String corpNm2;

    private String mbrAddr2;

    private String mbrTelNo2;

    private String mbrMobileNo2;

    private String mbrEmail2;

    private String corpSizeCd2;

    private String bizCd2;

    private String mbrDvsnCd2;

    private String chgAfCurrAcctNo;

    private String chgAfDpstAcctNo;

    private String frstChngGuid;

    private String frstChngStaffId;

    private LocalDateTime frstChngTmstmp;

    private String lastChngGuid;

    private String lastChngStaffId;

    private LocalDateTime lastChngTmstmp;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
        sb.append(", trDt=").append(trDt).append(System.lineSeparator());
        sb.append(", entTlgTrceNo=").append(entTlgTrceNo).append(System.lineSeparator());
        sb.append(", trUnqNo=").append(trUnqNo).append(System.lineSeparator());
        sb.append(", hostNo=").append(hostNo).append(System.lineSeparator());
        sb.append(", entOutinDvsnCd=").append(entOutinDvsnCd).append(System.lineSeparator());
        sb.append(", othrPartyBnkCd=").append(othrPartyBnkCd).append(System.lineSeparator());
        sb.append(", sysDvsn=").append(sysDvsn).append(System.lineSeparator());
        sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator());
        sb.append(", entTlgKndDvsnCd=").append(entTlgKndDvsnCd).append(System.lineSeparator());
        sb.append(", entTlgTrDvsnCd=").append(entTlgTrDvsnCd).append(System.lineSeparator());
        sb.append(", sndRcvDvsnCd=").append(sndRcvDvsnCd).append(System.lineSeparator());
        sb.append(", trSts=").append(trSts).append(System.lineSeparator());
        sb.append(", respCd1=").append(respCd1).append(System.lineSeparator());
        sb.append(", respCd2=").append(respCd2).append(System.lineSeparator());
        sb.append(", tlgTrDt=").append(tlgTrDt).append(System.lineSeparator());
        sb.append(", tlgSndTm=").append(tlgSndTm).append(System.lineSeparator());
        sb.append(", kftcStattcCd=").append(kftcStattcCd).append(System.lineSeparator());
        sb.append(", trMemo=").append(trMemo).append(System.lineSeparator());
        sb.append(", srchCondSort=").append(srchCondSort).append(System.lineSeparator());
        sb.append(", condCtzBizNoEnc=").append(condCtzBizNoEnc).append(System.lineSeparator());
        sb.append(", condBnkCd=").append(condBnkCd).append(System.lineSeparator());
        sb.append(", condDpstAcctNo=").append(condDpstAcctNo).append(System.lineSeparator());
        sb.append(", srchCondSort2=").append(srchCondSort2).append(System.lineSeparator());
        sb.append(", condCtzBizNoEnc2=").append(condCtzBizNoEnc2).append(System.lineSeparator());
        sb.append(", condBnkCd2=").append(condBnkCd2).append(System.lineSeparator());
        sb.append(", condDpstAcctNo2=").append(condDpstAcctNo2).append(System.lineSeparator());
        sb.append(", ctzBizNoEnc=").append(ctzBizNoEnc).append(System.lineSeparator());
        sb.append(", currAcctNo=").append(currAcctNo).append(System.lineSeparator());
        sb.append(", dpstAcctNo=").append(dpstAcctNo).append(System.lineSeparator());
        sb.append(", ctzBizNo=").append(ctzBizNo).append(System.lineSeparator());
        sb.append(", entPrcsDvsnCd=").append(entPrcsDvsnCd).append(System.lineSeparator());
        sb.append(", corpIndvDvsnCd=").append(corpIndvDvsnCd).append(System.lineSeparator());
        sb.append(", repNm=").append(repNm).append(System.lineSeparator());
        sb.append(", corpNm=").append(corpNm).append(System.lineSeparator());
        sb.append(", mbrAddr=").append(mbrAddr).append(System.lineSeparator());
        sb.append(", mbrTelNo=").append(mbrTelNo).append(System.lineSeparator());
        sb.append(", mbrMobileNo=").append(mbrMobileNo).append(System.lineSeparator());
        sb.append(", mbrEmail=").append(mbrEmail).append(System.lineSeparator());
        sb.append(", pymntExCd=").append(pymntExCd).append(System.lineSeparator());
        sb.append(", pymntRqstRegBnkCd=").append(pymntRqstRegBnkCd).append(System.lineSeparator());
        sb.append(", pymntBnkBrnchCd=").append(pymntBnkBrnchCd).append(System.lineSeparator());
        sb.append(", entCurrOpnDt=").append(entCurrOpnDt).append(System.lineSeparator());
        sb.append(", corpSizeCd=").append(corpSizeCd).append(System.lineSeparator());
        sb.append(", bizCd=").append(bizCd).append(System.lineSeparator());
        sb.append(", lmtAmt=").append(lmtAmt).append(System.lineSeparator());
        sb.append(", mbrDvsnCd=").append(mbrDvsnCd).append(System.lineSeparator());
        sb.append(", corpIndvDvsnCd2=").append(corpIndvDvsnCd2).append(System.lineSeparator());
        sb.append(", repNm2=").append(repNm2).append(System.lineSeparator());
        sb.append(", corpNm2=").append(corpNm2).append(System.lineSeparator());
        sb.append(", mbrAddr2=").append(mbrAddr2).append(System.lineSeparator());
        sb.append(", mbrTelNo2=").append(mbrTelNo2).append(System.lineSeparator());
        sb.append(", mbrMobileNo2=").append(mbrMobileNo2).append(System.lineSeparator());
        sb.append(", mbrEmail2=").append(mbrEmail2).append(System.lineSeparator());
        sb.append(", corpSizeCd2=").append(corpSizeCd2).append(System.lineSeparator());
        sb.append(", bizCd2=").append(bizCd2).append(System.lineSeparator());
        sb.append(", mbrDvsnCd2=").append(mbrDvsnCd2).append(System.lineSeparator());
        sb.append(", chgAfCurrAcctNo=").append(chgAfCurrAcctNo).append(System.lineSeparator());
        sb.append(", chgAfDpstAcctNo=").append(chgAfDpstAcctNo).append(System.lineSeparator());
        sb.append(", frstChngGuid=").append(frstChngGuid).append(System.lineSeparator());
        sb.append(", frstChngStaffId=").append(frstChngStaffId).append(System.lineSeparator());
        sb.append(", frstChngTmstmp=").append(frstChngTmstmp).append(System.lineSeparator());
        sb.append(", lastChngGuid=").append(lastChngGuid).append(System.lineSeparator());
        sb.append(", lastChngStaffId=").append(lastChngStaffId).append(System.lineSeparator());
        sb.append(", lastChngTmstmp=").append(lastChngTmstmp).append(System.lineSeparator());
        sb.append("]");
        return sb.toString();
    }
}