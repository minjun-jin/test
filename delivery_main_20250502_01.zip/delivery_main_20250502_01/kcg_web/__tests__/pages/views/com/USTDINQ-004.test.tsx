import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// USTDINQ004 컴포넌트를 불러옵니다.
import USTDINQ004 from "@/pages/views/com/USTDINQ-004"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(USTDINQ004)

describe("[USTDINQ-004] 대기거래관리", () => {
  beforeEach(() => {
    mockUseForm.mockGetValues.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
      },
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        holdTransactionList: [],
        totCnt: 0,
        sumOut: {},
      },
    })
  })

  it("onRowClicked Test", async () => {
    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, { target: { data: {} } })

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
  })

  it("valueFormatter Test - holdTm is empty", async () => {
    const { findByText } = render(component)

    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {
          trDt: "20241111",
          holdTm: "",
          trAmt: "1000",
        },
      },
    })
  })

  it("valueFormatter Test - holdTm is not empty", async () => {
    const { findByText } = render(component)

    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: {
          trDt: "20241111",
          holdTm: "235959",
          trAmt: undefined,
        },
      },
    })
  })

  it("rowClassRules Test", async () => {
    const { findByText } = render(component)
    const rowClassRulesTestBtn = await findByText(/rowClassRules Test/)
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: {
          data: {
            makeId: "Test",
            chkId: "test",
          },
        },
      },
    })
  })

  it.each([
    {
      value: { makeId: "somemakeid", chkId: undefined },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalledWith(
          "UOPSAPR-001",
          {
            aprvTpCd: "13",
            aprvKeyVal: undefined,
            strtDt: undefined,
          },
        )
      },
    },
    {
      value: {
        makeId: undefined,
        chkId: undefined,
        bizDvsnCd: "IFT",
        holdStsCd: "02",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalledWith(
          "UIFTINQ-006",
          {
            trDt: undefined,
            hostNo: undefined,
            kftcTlgNo: undefined,
          },
        )
      },
    },
    {
      value: {
        makeId: undefined,
        chkId: undefined,
        bizDvsnCd: "HOF",
        holdStsCd: "02",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalledWith(
          "UHOFINQ-012",
          {
            trDt: undefined,
            hostNo: undefined,
            kftcTlgNo: undefined,
          },
        )
      },
    },
    {
      value: {
        makeId: undefined,
        chkId: undefined,
        bizDvsnCd: "HOF",
        holdStsCd: "03",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
      },
    },
    {
      value: {
        makeId: undefined,
        chkId: undefined,
        bizDvsnCd: "CMS",
        holdStsCd: "02",
      },
      expect: () => {
        expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
      },
    },
  ])("onRowDoubleClicked Test", async (param) => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: param.value,
      },
    })
    await waitFor(() => {
      param.expect()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchData Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        holdTransactionList: [],
        totCnt: 0,
        sumOut: {},
      },
    })
    const { findByText } = render(component)

    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        holdTransactionList: undefined,
        totCnt: 0,
        sumOut: {},
      },
    })

    render(component)

    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("excelClick Test", async () => {
    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        holdTransactionList: [
          {
            trDt: "",
            holdTm: null,
            outinDvsnCd: "",
            bizDvsnCd: "",
            tlgKndDvsnCd: "",
            tlgTrDvsnCd: "",
            rcvBnkCd: "",
            rcvAcctNo: "",
            trAmt: undefined,
            whdrwlBnkCd: "",
            whdrwlAcctNo: "",
            whdrwlNm: "",
            holdStsCd: "",
            holdRsnCd: "",
            hostNo: "",
          },
          {
            trDt: "",
            outinDvsnCd: "",
            bizDvsnCd: "",
            tlgKndDvsnCd: "",
            tlgTrDvsnCd: "",
            relsStaTm: "000000",
            holdTm: "235959",
            rcvBnkCd: "",
            rcvAcctNo: "",
            trAmt: "4,000",
            whdrwlBnkCd: "",
            whdrwlAcctNo: "",
            whdrwlNm: "",
            holdStsCd: "",
            holdRsnCd: "",
            hostNo: "",
          },
        ],
        sumOut: {},
      },
    })
    const { findByText } = render(component)

    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("executeClick Test - confrim", async () => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.KCG_TECH_SUPPORT,
      },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        holdTransactionList: [],
        totCnt: 0,
        sumOut: {},
      },
    })
    mockDateUtils.mockToday.mockReturnValue("20240101")

    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "holdStsCd":
          return "01"
        case "holdRsnCd":
          return "05"
        default:
          return "20240101"
      }
    })

    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          holdStsCd: "01",
          holdRsnCd: "05",
          trDt: "20240101",
        },
      },
    })

    const actBtn = await findByText(/SCRNITM#act/)
    fireEvent.click(actBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
    })
  })

  it("executeClick Test - not confirm", async () => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.KCG_TECH_SUPPORT,
      },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    mockDateUtils.mockToday.mockReturnValue("20240101")

    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "holdStsCd":
          return "01"
        case "holdRsnCd":
          return "05"
        default:
          return "20240101"
      }
    })

    const { findByText } = render(component)

    const onRowClickedTestBtn = await findByText(/onRowClicked Test/)
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          holdStsCd: "01",
          holdRsnCd: "05",
          trDt: "20240101",
        },
      },
    })

    const actBtn = await findByText(/SCRNITM#act/)
    fireEvent.click(actBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("validate Test", async () => {
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(validateTestBtn, { target: { data: "test" } })
  })
})
