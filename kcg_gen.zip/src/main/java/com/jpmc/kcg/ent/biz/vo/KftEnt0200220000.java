package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보 조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 전자어음시스템을 구분하기 위해'EBS'사용
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 220000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * conditionSearchConditionSort 조건-검색조건구분 
 * conditionResidentBusinessNumber 조건-주민(사업자)번호 
 * conditionBankCode 조건-은행코드 
 * conditionDepositAccountNumber 조건-입금계좌번호 
 * resultCorpIndvSort 결과-법인개인구분 
 * resultResidentBusinessNumber 결과-주민(사업자)번호 
 * resultNameRepresentativeName 결과-성명(대표자명) 
 * resultCorpName 결과-법인명 
 * resultAddress 결과-주소 
 * resultPhoneNumber 결과-전화번호 
 * resultMobilePhoneNumber 결과-핸드폰번호 
 * resultEmail 결과-이메일 
 * resultMemberSort 결과-회원구분 
 * resultCompanySize 결과-기업규모 
 * resultIndustryCode 결과-업종코드 
 * 
 * KftEnt0200220000 kftEnt0200220000 = new KftEnt0200220000(); // 회원정보 조회 요청
 * kftEnt0200220000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200220000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200220000.setBnkCd("057"); // 은행코드
 * kftEnt0200220000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200220000.setTransactionCode("220000"); // 거래구분코드
 * kftEnt0200220000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200220000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200220000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200220000.setStatus("000"); // STATUS
 * kftEnt0200220000.setResponseCode1(""); // 응답코드1
 * kftEnt0200220000.setResponseCode2(""); // 응답코드2
 * kftEnt0200220000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200220000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200220000.setConditionSearchConditionSort(""); // 조건-검색조건구분
 * kftEnt0200220000.setConditionResidentBusinessNumber(""); // 조건-주민(사업자)번호
 * kftEnt0200220000.setConditionBankCode(""); // 조건-은행코드
 * kftEnt0200220000.setConditionDepositAccountNumber(""); // 조건-입금계좌번호
 * kftEnt0200220000.setResultCorpIndvSort(""); // 결과-법인개인구분
 * kftEnt0200220000.setResultResidentBusinessNumber(""); // 결과-주민(사업자)번호
 * kftEnt0200220000.setResultNameRepresentativeName(""); // 결과-성명(대표자명)
 * kftEnt0200220000.setResultCorpName(""); // 결과-법인명
 * kftEnt0200220000.setResultAddress(""); // 결과-주소
 * kftEnt0200220000.setResultPhoneNumber(""); // 결과-전화번호
 * kftEnt0200220000.setResultMobilePhoneNumber(""); // 결과-핸드폰번호
 * kftEnt0200220000.setResultEmail(""); // 결과-이메일
 * kftEnt0200220000.setResultMemberSort(""); // 결과-회원구분
 * kftEnt0200220000.setResultCompanySize(""); // 결과-기업규모
 * kftEnt0200220000.setResultIndustryCode(""); // 결과-업종코드
 * }</pre>
 */
@Data
public class KftEnt0200220000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "220000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String conditionSearchConditionSort; // 조건-검색조건구분
	private String conditionResidentBusinessNumber; // 조건-주민(사업자)번호
	private String conditionBankCode; // 조건-은행코드
	private String conditionDepositAccountNumber; // 조건-입금계좌번호
	private String resultCorpIndvSort; // 결과-법인개인구분
	private String resultResidentBusinessNumber; // 결과-주민(사업자)번호
	private String resultNameRepresentativeName; // 결과-성명(대표자명)
	private String resultCorpName; // 결과-법인명
	private String resultAddress; // 결과-주소
	private String resultPhoneNumber; // 결과-전화번호
	private String resultMobilePhoneNumber; // 결과-핸드폰번호
	private String resultEmail; // 결과-이메일
	private String resultMemberSort; // 결과-회원구분
	private String resultCompanySize; // 결과-기업규모
	private String resultIndustryCode; // 결과-업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionSearchConditionSort$; // 조건-검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionResidentBusinessNumber$; // 조건-주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBankCode$; // 조건-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionDepositAccountNumber$; // 조건-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCorpIndvSort$; // 결과-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultResidentBusinessNumber$; // 결과-주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultNameRepresentativeName$; // 결과-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCorpName$; // 결과-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultAddress$; // 결과-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultPhoneNumber$; // 결과-전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultMobilePhoneNumber$; // 결과-핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultEmail$; // 결과-이메일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultMemberSort$; // 결과-회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCompanySize$; // 결과-기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultIndustryCode$; // 결과-업종코드

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(conditionDepositAccountNumber$)) { // 조건-입금계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(resultResidentBusinessNumber$)) { // 결과-주민(사업자)번호
			return 18;
		}
		if (VOUtils.isNotAlphanumericSpace(resultPhoneNumber$)) { // 결과-전화번호
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(resultMobilePhoneNumber$)) { // 결과-핸드폰번호
			return 23;
		}
		if (VOUtils.isNotAlphanumericSpace(resultEmail$)) { // 결과-이메일
			return 24;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		conditionSearchConditionSort$ = VOUtils.write(out, conditionSearchConditionSort, 1); // 조건-검색조건구분
		conditionResidentBusinessNumber$ = VOUtils.write(out, conditionResidentBusinessNumber, 13); // 조건-주민(사업자)번호
		conditionBankCode$ = VOUtils.write(out, conditionBankCode, 3); // 조건-은행코드
		conditionDepositAccountNumber$ = VOUtils.write(out, conditionDepositAccountNumber, 16); // 조건-입금계좌번호
		resultCorpIndvSort$ = VOUtils.write(out, resultCorpIndvSort, 1); // 결과-법인개인구분
		resultResidentBusinessNumber$ = VOUtils.write(out, resultResidentBusinessNumber, 13); // 결과-주민(사업자)번호
		resultNameRepresentativeName$ = VOUtils.write(out, resultNameRepresentativeName, 20, "EUC-KR"); // 결과-성명(대표자명)
		resultCorpName$ = VOUtils.write(out, resultCorpName, 40, "EUC-KR"); // 결과-법인명
		resultAddress$ = VOUtils.write(out, resultAddress, 60, "EUC-KR"); // 결과-주소
		resultPhoneNumber$ = VOUtils.write(out, resultPhoneNumber, 14); // 결과-전화번호
		resultMobilePhoneNumber$ = VOUtils.write(out, resultMobilePhoneNumber, 14); // 결과-핸드폰번호
		resultEmail$ = VOUtils.write(out, resultEmail, 40); // 결과-이메일
		resultMemberSort$ = VOUtils.write(out, resultMemberSort, 1); // 결과-회원구분
		resultCompanySize$ = VOUtils.write(out, resultCompanySize, 1); // 결과-기업규모
		resultIndustryCode$ = VOUtils.write(out, resultIndustryCode, 2); // 결과-업종코드
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		conditionSearchConditionSort = VOUtils.toString(conditionSearchConditionSort$ = VOUtils.read(in, 1)); // 조건-검색조건구분
		conditionResidentBusinessNumber = VOUtils.toString(conditionResidentBusinessNumber$ = VOUtils.read(in, 13)); // 조건-주민(사업자)번호
		conditionBankCode = VOUtils.toString(conditionBankCode$ = VOUtils.read(in, 3)); // 조건-은행코드
		conditionDepositAccountNumber = VOUtils.toString(conditionDepositAccountNumber$ = VOUtils.read(in, 16)); // 조건-입금계좌번호
		resultCorpIndvSort = VOUtils.toString(resultCorpIndvSort$ = VOUtils.read(in, 1)); // 결과-법인개인구분
		resultResidentBusinessNumber = VOUtils.toString(resultResidentBusinessNumber$ = VOUtils.read(in, 13)); // 결과-주민(사업자)번호
		resultNameRepresentativeName = VOUtils.toString(resultNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 결과-성명(대표자명)
		resultCorpName = VOUtils.toString(resultCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 결과-법인명
		resultAddress = VOUtils.toString(resultAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 결과-주소
		resultPhoneNumber = VOUtils.toString(resultPhoneNumber$ = VOUtils.read(in, 14)); // 결과-전화번호
		resultMobilePhoneNumber = VOUtils.toString(resultMobilePhoneNumber$ = VOUtils.read(in, 14)); // 결과-핸드폰번호
		resultEmail = VOUtils.toString(resultEmail$ = VOUtils.read(in, 40)); // 결과-이메일
		resultMemberSort = VOUtils.toString(resultMemberSort$ = VOUtils.read(in, 1)); // 결과-회원구분
		resultCompanySize = VOUtils.toString(resultCompanySize$ = VOUtils.read(in, 1)); // 결과-기업규모
		resultIndustryCode = VOUtils.toString(resultIndustryCode$ = VOUtils.read(in, 2)); // 결과-업종코드
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", conditionSearchConditionSort=").append(conditionSearchConditionSort).append(System.lineSeparator()); // 조건-검색조건구분
		sb.append(", conditionResidentBusinessNumber=").append(conditionResidentBusinessNumber).append(System.lineSeparator()); // 조건-주민(사업자)번호
		sb.append(", conditionBankCode=").append(conditionBankCode).append(System.lineSeparator()); // 조건-은행코드
		sb.append(", conditionDepositAccountNumber=").append(conditionDepositAccountNumber).append(System.lineSeparator()); // 조건-입금계좌번호
		sb.append(", resultCorpIndvSort=").append(resultCorpIndvSort).append(System.lineSeparator()); // 결과-법인개인구분
		sb.append(", resultResidentBusinessNumber=").append(resultResidentBusinessNumber).append(System.lineSeparator()); // 결과-주민(사업자)번호
		sb.append(", resultNameRepresentativeName=").append(resultNameRepresentativeName).append(System.lineSeparator()); // 결과-성명(대표자명)
		sb.append(", resultCorpName=").append(resultCorpName).append(System.lineSeparator()); // 결과-법인명
		sb.append(", resultAddress=").append(resultAddress).append(System.lineSeparator()); // 결과-주소
		sb.append(", resultPhoneNumber=").append(resultPhoneNumber).append(System.lineSeparator()); // 결과-전화번호
		sb.append(", resultMobilePhoneNumber=").append(resultMobilePhoneNumber).append(System.lineSeparator()); // 결과-핸드폰번호
		sb.append(", resultEmail=").append(resultEmail).append(System.lineSeparator()); // 결과-이메일
		sb.append(", resultMemberSort=").append(resultMemberSort).append(System.lineSeparator()); // 결과-회원구분
		sb.append(", resultCompanySize=").append(resultCompanySize).append(System.lineSeparator()); // 결과-기업규모
		sb.append(", resultIndustryCode=").append(resultIndustryCode).append(System.lineSeparator()); // 결과-업종코드
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "220000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "conditionSearchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "conditionResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "conditionBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "conditionDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "resultCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "resultNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "resultCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "resultPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultMobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultEmail", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultMemberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultCompanySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultIndustryCode", "fldLen", "2", "defltVal", "")
		);
	}

}
