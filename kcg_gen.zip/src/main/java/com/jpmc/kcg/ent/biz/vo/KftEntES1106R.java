package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 부도어음 반환내역
 * <pre>{@code
 * KftEntES1106R kftEntES1106R  = new KftEntES1106R(); // 부도어음 반환내역
 * kftEntES1106R.setFileName(""); // 업무구분
 * kftEntES1106R.setDataType(""); // 데이터구분
 * kftEntES1106R.setSerialNumber(""); // 일련번호
 * kftEntES1106R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1106R.setBankCode(""); // 은행코드
 * kftEntES1106R.setType(""); // 구분
 * kftEntES1106R.setRepaymentClaimDate(""); // 상환청구일자
 * kftEntES1106R.setRepaymentObligationFulfillmentRegistrationDate(""); // 상환의무이행 등록일자
 * kftEntES1106R.setRepaymentObligationFulfillmentConfirmationDate(""); // 상환의무이행 확인일자
 * kftEntES1106R.setEnoteNumber(""); // 어음번호
 * kftEntES1106R.setEnoteType(""); // 어음종류
 * kftEntES1106R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1106R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1106R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1106R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1106R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1106R.setPaymentBranchClearingHouseCode(""); // 지급점포 교환소 코드
 * kftEntES1106R.setRepaymentObligorCorpIndvSort(""); // 상환의무인-법인개인구분
 * kftEntES1106R.setRepaymentObligorResidentBusinessNumber(""); // 상환의무인-주민사업자번호
 * kftEntES1106R.setRepaymentObligorCorpName(""); // 상환의무인-법인명
 * kftEntES1106R.setRepaymentObligorNameRepresentativeName(""); // 상환의무인-성명(대표자명)
 * kftEntES1106R.setRepaymentObligorAddress(""); // 상환의무인-주소
 * kftEntES1106R.setRepaymentObligorBankCode(""); // 상환의무인-은행코드
 * kftEntES1106R.setRepaymentObligorCurrentCreditAccountNumber(""); // 상환의무인-당좌(입금)계좌번호
 * kftEntES1106R.setRepaymentClaimantCorpIndvSort(""); // 상환청구인-법인개인구분
 * kftEntES1106R.setRepaymentClaimantResidentBusinessNumber(""); // 상환청구인-주민사업자번호
 * kftEntES1106R.setRepaymentClaimantCorpName(""); // 상환청구인-법인명
 * kftEntES1106R.setRepaymentClaimantNameRepresentativeName(""); // 상환청구인-성명(대표자명)
 * kftEntES1106R.setRepaymentClaimantAddress(""); // 상환청구인-주소
 * kftEntES1106R.setRepaymentClaimantBankCode(""); // 상환청구인-수취은행코드
 * kftEntES1106R.setRepaymentClaimantDepositAccountNumber(""); // 상환청구인-입금계좌번호
 * kftEntES1106R.setDepositRejectionDate(""); // 입금(거절)일자
 * kftEntES1106R.setRepaymentClaimAmount(0L); // 상환청구금액
 * kftEntES1106R.setSplitNumber(""); // 분할번호
 * kftEntES1106R.setEndorsementNumber(""); // 배서번호
 * kftEntES1106R.setRepaymentClaimDesignationDate(""); // 상환청구인 지정일자
 * kftEntES1106R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1106R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String type; // 구분
	private String repaymentClaimDate; // 상환청구일자
	private String repaymentObligationFulfillmentRegistrationDate; // 상환의무이행 등록일자
	private String repaymentObligationFulfillmentConfirmationDate; // 상환의무이행 확인일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String paymentBranchClearingHouseCode; // 지급점포 교환소 코드
	private String repaymentObligorCorpIndvSort; // 상환의무인-법인개인구분
	private String repaymentObligorResidentBusinessNumber; // 상환의무인-주민사업자번호
	private String repaymentObligorCorpName; // 상환의무인-법인명
	private String repaymentObligorNameRepresentativeName; // 상환의무인-성명(대표자명)
	private String repaymentObligorAddress; // 상환의무인-주소
	private String repaymentObligorBankCode; // 상환의무인-은행코드
	private String repaymentObligorCurrentCreditAccountNumber; // 상환의무인-당좌(입금)계좌번호
	private String repaymentClaimantCorpIndvSort; // 상환청구인-법인개인구분
	private String repaymentClaimantResidentBusinessNumber; // 상환청구인-주민사업자번호
	private String repaymentClaimantCorpName; // 상환청구인-법인명
	private String repaymentClaimantNameRepresentativeName; // 상환청구인-성명(대표자명)
	private String repaymentClaimantAddress; // 상환청구인-주소
	private String repaymentClaimantBankCode; // 상환청구인-수취은행코드
	private String repaymentClaimantDepositAccountNumber; // 상환청구인-입금계좌번호
	private String depositRejectionDate; // 입금(거절)일자
	private long repaymentClaimAmount; // 상환청구금액
	private String splitNumber; // 분할번호
	private String endorsementNumber; // 배서번호
	private String repaymentClaimDesignationDate; // 상환청구인 지정일자
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String type$; // 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDate$; // 상환청구일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligationFulfillmentRegistrationDate$; // 상환의무이행 등록일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligationFulfillmentConfirmationDate$; // 상환의무이행 확인일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포 교환소 코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpIndvSort$; // 상환의무인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorResidentBusinessNumber$; // 상환의무인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpName$; // 상환의무인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorNameRepresentativeName$; // 상환의무인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorAddress$; // 상환의무인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorBankCode$; // 상환의무인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCurrentCreditAccountNumber$; // 상환의무인-당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpIndvSort$; // 상환청구인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantResidentBusinessNumber$; // 상환청구인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpName$; // 상환청구인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantNameRepresentativeName$; // 상환청구인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantAddress$; // 상환청구인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantBankCode$; // 상환청구인-수취은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantDepositAccountNumber$; // 상환청구인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositRejectionDate$; // 입금(거절)일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimAmount$; // 상환청구금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementNumber$; // 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDesignationDate$; // 상환청구인 지정일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		type$ = VOUtils.write(out, type, 1); // 구분
		repaymentClaimDate$ = VOUtils.write(out, repaymentClaimDate, 8); // 상환청구일자
		repaymentObligationFulfillmentRegistrationDate$ = VOUtils.write(out, repaymentObligationFulfillmentRegistrationDate, 8); // 상환의무이행 등록일자
		repaymentObligationFulfillmentConfirmationDate$ = VOUtils.write(out, repaymentObligationFulfillmentConfirmationDate, 8); // 상환의무이행 확인일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포 교환소 코드
		repaymentObligorCorpIndvSort$ = VOUtils.write(out, repaymentObligorCorpIndvSort, 1); // 상환의무인-법인개인구분
		repaymentObligorResidentBusinessNumber$ = VOUtils.write(out, repaymentObligorResidentBusinessNumber, 13); // 상환의무인-주민사업자번호
		repaymentObligorCorpName$ = VOUtils.write(out, repaymentObligorCorpName, 40, "EUC-KR"); // 상환의무인-법인명
		repaymentObligorNameRepresentativeName$ = VOUtils.write(out, repaymentObligorNameRepresentativeName, 20, "EUC-KR"); // 상환의무인-성명(대표자명)
		repaymentObligorAddress$ = VOUtils.write(out, repaymentObligorAddress, 60, "EUC-KR"); // 상환의무인-주소
		repaymentObligorBankCode$ = VOUtils.write(out, repaymentObligorBankCode, 3); // 상환의무인-은행코드
		repaymentObligorCurrentCreditAccountNumber$ = VOUtils.write(out, repaymentObligorCurrentCreditAccountNumber, 16); // 상환의무인-당좌(입금)계좌번호
		repaymentClaimantCorpIndvSort$ = VOUtils.write(out, repaymentClaimantCorpIndvSort, 1); // 상환청구인-법인개인구분
		repaymentClaimantResidentBusinessNumber$ = VOUtils.write(out, repaymentClaimantResidentBusinessNumber, 13); // 상환청구인-주민사업자번호
		repaymentClaimantCorpName$ = VOUtils.write(out, repaymentClaimantCorpName, 40, "EUC-KR"); // 상환청구인-법인명
		repaymentClaimantNameRepresentativeName$ = VOUtils.write(out, repaymentClaimantNameRepresentativeName, 20, "EUC-KR"); // 상환청구인-성명(대표자명)
		repaymentClaimantAddress$ = VOUtils.write(out, repaymentClaimantAddress, 60, "EUC-KR"); // 상환청구인-주소
		repaymentClaimantBankCode$ = VOUtils.write(out, repaymentClaimantBankCode, 3); // 상환청구인-수취은행코드
		repaymentClaimantDepositAccountNumber$ = VOUtils.write(out, repaymentClaimantDepositAccountNumber, 16); // 상환청구인-입금계좌번호
		depositRejectionDate$ = VOUtils.write(out, depositRejectionDate, 8); // 입금(거절)일자
		repaymentClaimAmount$ = VOUtils.write(out, repaymentClaimAmount, 15); // 상환청구금액
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // 배서번호
		repaymentClaimDesignationDate$ = VOUtils.write(out, repaymentClaimDesignationDate, 8); // 상환청구인 지정일자
		filler2$ = VOUtils.write(out, filler2, 44); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		type = VOUtils.toString(type$ = VOUtils.read(in, 1)); // 구분
		repaymentClaimDate = VOUtils.toString(repaymentClaimDate$ = VOUtils.read(in, 8)); // 상환청구일자
		repaymentObligationFulfillmentRegistrationDate = VOUtils.toString(repaymentObligationFulfillmentRegistrationDate$ = VOUtils.read(in, 8)); // 상환의무이행 등록일자
		repaymentObligationFulfillmentConfirmationDate = VOUtils.toString(repaymentObligationFulfillmentConfirmationDate$ = VOUtils.read(in, 8)); // 상환의무이행 확인일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포 교환소 코드
		repaymentObligorCorpIndvSort = VOUtils.toString(repaymentObligorCorpIndvSort$ = VOUtils.read(in, 1)); // 상환의무인-법인개인구분
		repaymentObligorResidentBusinessNumber = VOUtils.toString(repaymentObligorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환의무인-주민사업자번호
		repaymentObligorCorpName = VOUtils.toString(repaymentObligorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환의무인-법인명
		repaymentObligorNameRepresentativeName = VOUtils.toString(repaymentObligorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환의무인-성명(대표자명)
		repaymentObligorAddress = VOUtils.toString(repaymentObligorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환의무인-주소
		repaymentObligorBankCode = VOUtils.toString(repaymentObligorBankCode$ = VOUtils.read(in, 3)); // 상환의무인-은행코드
		repaymentObligorCurrentCreditAccountNumber = VOUtils.toString(repaymentObligorCurrentCreditAccountNumber$ = VOUtils.read(in, 16)); // 상환의무인-당좌(입금)계좌번호
		repaymentClaimantCorpIndvSort = VOUtils.toString(repaymentClaimantCorpIndvSort$ = VOUtils.read(in, 1)); // 상환청구인-법인개인구분
		repaymentClaimantResidentBusinessNumber = VOUtils.toString(repaymentClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환청구인-주민사업자번호
		repaymentClaimantCorpName = VOUtils.toString(repaymentClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환청구인-법인명
		repaymentClaimantNameRepresentativeName = VOUtils.toString(repaymentClaimantNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환청구인-성명(대표자명)
		repaymentClaimantAddress = VOUtils.toString(repaymentClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환청구인-주소
		repaymentClaimantBankCode = VOUtils.toString(repaymentClaimantBankCode$ = VOUtils.read(in, 3)); // 상환청구인-수취은행코드
		repaymentClaimantDepositAccountNumber = VOUtils.toString(repaymentClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환청구인-입금계좌번호
		depositRejectionDate = VOUtils.toString(depositRejectionDate$ = VOUtils.read(in, 8)); // 입금(거절)일자
		repaymentClaimAmount = VOUtils.toLong(repaymentClaimAmount$ = VOUtils.read(in, 15)); // 상환청구금액
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // 배서번호
		repaymentClaimDesignationDate = VOUtils.toString(repaymentClaimDesignationDate$ = VOUtils.read(in, 8)); // 상환청구인 지정일자
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 44)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", type=").append(type).append(System.lineSeparator()); // 구분
		sb.append(", repaymentClaimDate=").append(repaymentClaimDate).append(System.lineSeparator()); // 상환청구일자
		sb.append(", repaymentObligationFulfillmentRegistrationDate=").append(repaymentObligationFulfillmentRegistrationDate).append(System.lineSeparator()); // 상환의무이행 등록일자
		sb.append(", repaymentObligationFulfillmentConfirmationDate=").append(repaymentObligationFulfillmentConfirmationDate).append(System.lineSeparator()); // 상환의무이행 확인일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포 교환소 코드
		sb.append(", repaymentObligorCorpIndvSort=").append(repaymentObligorCorpIndvSort).append(System.lineSeparator()); // 상환의무인-법인개인구분
		sb.append(", repaymentObligorResidentBusinessNumber=").append(repaymentObligorResidentBusinessNumber).append(System.lineSeparator()); // 상환의무인-주민사업자번호
		sb.append(", repaymentObligorCorpName=").append(repaymentObligorCorpName).append(System.lineSeparator()); // 상환의무인-법인명
		sb.append(", repaymentObligorNameRepresentativeName=").append(repaymentObligorNameRepresentativeName).append(System.lineSeparator()); // 상환의무인-성명(대표자명)
		sb.append(", repaymentObligorAddress=").append(repaymentObligorAddress).append(System.lineSeparator()); // 상환의무인-주소
		sb.append(", repaymentObligorBankCode=").append(repaymentObligorBankCode).append(System.lineSeparator()); // 상환의무인-은행코드
		sb.append(", repaymentObligorCurrentCreditAccountNumber=").append(repaymentObligorCurrentCreditAccountNumber).append(System.lineSeparator()); // 상환의무인-당좌(입금)계좌번호
		sb.append(", repaymentClaimantCorpIndvSort=").append(repaymentClaimantCorpIndvSort).append(System.lineSeparator()); // 상환청구인-법인개인구분
		sb.append(", repaymentClaimantResidentBusinessNumber=").append(repaymentClaimantResidentBusinessNumber).append(System.lineSeparator()); // 상환청구인-주민사업자번호
		sb.append(", repaymentClaimantCorpName=").append(repaymentClaimantCorpName).append(System.lineSeparator()); // 상환청구인-법인명
		sb.append(", repaymentClaimantNameRepresentativeName=").append(repaymentClaimantNameRepresentativeName).append(System.lineSeparator()); // 상환청구인-성명(대표자명)
		sb.append(", repaymentClaimantAddress=").append(repaymentClaimantAddress).append(System.lineSeparator()); // 상환청구인-주소
		sb.append(", repaymentClaimantBankCode=").append(repaymentClaimantBankCode).append(System.lineSeparator()); // 상환청구인-수취은행코드
		sb.append(", repaymentClaimantDepositAccountNumber=").append(repaymentClaimantDepositAccountNumber).append(System.lineSeparator()); // 상환청구인-입금계좌번호
		sb.append(", depositRejectionDate=").append(depositRejectionDate).append(System.lineSeparator()); // 입금(거절)일자
		sb.append(", repaymentClaimAmount=").append(repaymentClaimAmount).append(System.lineSeparator()); // 상환청구금액
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // 배서번호
		sb.append(", repaymentClaimDesignationDate=").append(repaymentClaimDesignationDate).append(System.lineSeparator()); // 상환청구인 지정일자
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "type", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationFulfillmentRegistrationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligationFulfillmentConfirmationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentObligorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentObligorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentObligorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentObligorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentObligorCurrentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentClaimantNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "depositRejectionDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentClaimAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentClaimDesignationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "44", "defltVal", "")
		);
	}

}
