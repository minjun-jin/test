package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 배서•배서보증인별 보증내역 조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 421000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * sortCondition 정렬조건 
 * searchConditionSort 검색조건구분 
 * userSort 이용자구분 
 * inquiryNoteGuaranteeStatusSort 조회전자어음보증상태구분 
 * eNoteNumber 전자어음번호 
 * splitNumber 분할번호 
 * residentBusinessNumber 주민사업자번호 
 * depositAccountNumber 입금계좌번호 
 * guaranteeRequestDateBasisQueryStartDate 보증요청일기준조회시작일 
 * guaranteeRequestDateBasisQueryEndDate 보증요청일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.guaranteeDetailsGuaranteeRequestDate (조회결과)보증내역-01보증요청일자 
 * queryResultArray.guaranteeDetailsGuaranteeProcessingDate (조회결과)보증내역-02보증처리일자 
 * queryResultArray.guaranteeDetailsGuaranteeProcessSort (조회결과)보증내역-03보증처리구분 
 * queryResultArray.noteDetailsEnoteNumber (조회결과)어음내역-04전자어음번호 
 * queryResultArray.noteDetailsEnoteType (조회결과)어음내역-05전자어음종류 
 * queryResultArray.noteDetailsEnoteProcessStatus (조회결과)어음내역-06전자어음처리상태 
 * queryResultArray.noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
 * queryResultArray.noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
 * queryResultArray.noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
 * queryResultArray.noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
 * queryResultArray.noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
 * queryResultArray.issuerCorpIndvSort (조회결과)발행인-개인법인구분 
 * queryResultArray.issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
 * queryResultArray.issuerCorpName (조회결과)발행인-법인명 
 * queryResultArray.issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
 * queryResultArray.issuerAddress (조회결과)발행인-주소 
 * queryResultArray.endorserCorpIndvSort (조회결과)배서인개인법인구분 
 * queryResultArray.endorserResidentBusinessNumber (조회결과)배서인주민사업자번호 
 * queryResultArray.endorserCorpName (조회결과)배서인법인명 
 * queryResultArray.endorserNameRepresentativeName (조회결과)배서인성명(대표자명) 
 * queryResultArray.endorserAddress (조회결과)배서인주소 
 * queryResultArray.endorserBankCode (조회결과)배서인은행코드 
 * queryResultArray.endorserDepositAccountNumber (조회결과)배서인입금계좌번호 
 * queryResultArray.endorseeCorpIndvSort (조회결과)피배서인개인법인구분 
 * queryResultArray.endorseeResidentBusinessNumber (조회결과)피배서인주민사업자번호 
 * queryResultArray.endorseeCorpName (조회결과)피배서인법인명 
 * queryResultArray.endorseeNameRepresentativeName (조회결과)피배서인성명(대표자명) 
 * queryResultArray.endorseeAddress (조회결과)피배서인주소 
 * queryResultArray.endorseeBankCode (조회결과)피배서인은행코드 
 * queryResultArray.endorseeDepositAccountNumber (조회결과)피배서인입금계좌번호 
 * queryResultArray.additionalConditionsUnsecuredEndorsementYn (조회결과)부가요건-무담보배서여부 
 * queryResultArray.additionalConditionsEndorsementProhibitionEndorsementYn (조회결과)부가요건-배서금지배서여부 
 * queryResultArray.additionalConditionsSplitNumber (조회결과)부가요건-분할번호 
 * queryResultArray.additionalConditionsEndorsementNumber (조회결과)부가요건-배서번호 
 * queryResultArray.additionalConditionsEndorsementAmount (조회결과)부가요건-배서금액 
 * queryResultArray.guarantorGuaranteeSort (조회결과)보증인-보증구분 
 * queryResultArray.guarantorCorpIndvSort (조회결과)보증인-개인법인구분 
 * queryResultArray.guarantorResidentBusinessNumber (조회결과)보증인-주민사업자번호 
 * queryResultArray.guarantorCorpName (조회결과)보증인-법인명 
 * queryResultArray.guarantorNameRepresentativeName (조회결과)보증인-성명(대표자명) 
 * queryResultArray.guarantorAddress (조회결과)보증인-주소 
 * queryResultArray.guarantorBankCode (조회결과)보증인-은행코드 
 * queryResultArray.guarantorDepositAccountNumber (조회결과)보증인-입금계좌번호 
 * queryResultArray.guarantorGuaranteeNumber (조회결과)보증인-보증번호 
 * 
 * KftEnt0200421000 kftEnt0200421000 = new KftEnt0200421000(); // 배서•배서보증인별 보증내역 조회 요청
 * kftEnt0200421000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200421000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200421000.setBnkCd("057"); // 은행코드
 * kftEnt0200421000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200421000.setTransactionCode("421000"); // 거래구분코드
 * kftEnt0200421000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200421000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200421000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200421000.setStatus("000"); // STATUS
 * kftEnt0200421000.setResponseCode1(""); // 응답코드1
 * kftEnt0200421000.setResponseCode2(""); // 응답코드2
 * kftEnt0200421000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200421000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200421000.setSortCondition(""); // 정렬조건
 * kftEnt0200421000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0200421000.setUserSort(""); // 이용자구분
 * kftEnt0200421000.setInquiryNoteGuaranteeStatusSort(""); // 조회전자어음보증상태구분
 * kftEnt0200421000.setENoteNumber(""); // 전자어음번호
 * kftEnt0200421000.setSplitNumber(""); // 분할번호
 * kftEnt0200421000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200421000.setDepositAccountNumber(""); // 입금계좌번호
 * kftEnt0200421000.setGuaranteeRequestDateBasisQueryStartDate(""); // 보증요청일기준조회시작일
 * kftEnt0200421000.setGuaranteeRequestDateBasisQueryEndDate(""); // 보증요청일기준조회종료일
 * kftEnt0200421000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0200421000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0200421000.setCurrentCount(0); // 현재건수
 * KftEnt0200421000.QueryResult queryResult = new KftEnt0200421000.QueryResult(); // 조회결과Array
 * queryResult.setGuaranteeDetailsGuaranteeRequestDate(""); // (조회결과)보증내역-01보증요청일자
 * queryResult.setGuaranteeDetailsGuaranteeProcessingDate(""); // (조회결과)보증내역-02보증처리일자
 * queryResult.setGuaranteeDetailsGuaranteeProcessSort(""); // (조회결과)보증내역-03보증처리구분
 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-04전자어음번호
 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-05전자어음종류
 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-06전자어음처리상태
 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
 * queryResult.setEndorserCorpIndvSort(""); // (조회결과)배서인개인법인구분
 * queryResult.setEndorserResidentBusinessNumber(""); // (조회결과)배서인주민사업자번호
 * queryResult.setEndorserCorpName(""); // (조회결과)배서인법인명
 * queryResult.setEndorserNameRepresentativeName(""); // (조회결과)배서인성명(대표자명)
 * queryResult.setEndorserAddress(""); // (조회결과)배서인주소
 * queryResult.setEndorserBankCode(""); // (조회결과)배서인은행코드
 * queryResult.setEndorserDepositAccountNumber(""); // (조회결과)배서인입금계좌번호
 * queryResult.setEndorseeCorpIndvSort(""); // (조회결과)피배서인개인법인구분
 * queryResult.setEndorseeResidentBusinessNumber(""); // (조회결과)피배서인주민사업자번호
 * queryResult.setEndorseeCorpName(""); // (조회결과)피배서인법인명
 * queryResult.setEndorseeNameRepresentativeName(""); // (조회결과)피배서인성명(대표자명)
 * queryResult.setEndorseeAddress(""); // (조회결과)피배서인주소
 * queryResult.setEndorseeBankCode(""); // (조회결과)피배서인은행코드
 * queryResult.setEndorseeDepositAccountNumber(""); // (조회결과)피배서인입금계좌번호
 * queryResult.setAdditionalConditionsUnsecuredEndorsementYn(""); // (조회결과)부가요건-무담보배서여부
 * queryResult.setAdditionalConditionsEndorsementProhibitionEndorsementYn(""); // (조회결과)부가요건-배서금지배서여부
 * queryResult.setAdditionalConditionsSplitNumber(""); // (조회결과)부가요건-분할번호
 * queryResult.setAdditionalConditionsEndorsementNumber(""); // (조회결과)부가요건-배서번호
 * queryResult.setAdditionalConditionsEndorsementAmount(0L); // (조회결과)부가요건-배서금액
 * queryResult.setGuarantorGuaranteeSort(""); // (조회결과)보증인-보증구분
 * queryResult.setGuarantorCorpIndvSort(""); // (조회결과)보증인-개인법인구분
 * queryResult.setGuarantorResidentBusinessNumber(""); // (조회결과)보증인-주민사업자번호
 * queryResult.setGuarantorCorpName(""); // (조회결과)보증인-법인명
 * queryResult.setGuarantorNameRepresentativeName(""); // (조회결과)보증인-성명(대표자명)
 * queryResult.setGuarantorAddress(""); // (조회결과)보증인-주소
 * queryResult.setGuarantorBankCode(""); // (조회결과)보증인-은행코드
 * queryResult.setGuarantorDepositAccountNumber(""); // (조회결과)보증인-입금계좌번호
 * queryResult.setGuarantorGuaranteeNumber(""); // (조회결과)보증인-보증번호
 * kftEnt0200421000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0200421000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * guaranteeDetailsGuaranteeRequestDate (조회결과)보증내역-01보증요청일자 
	 * guaranteeDetailsGuaranteeProcessingDate (조회결과)보증내역-02보증처리일자 
	 * guaranteeDetailsGuaranteeProcessSort (조회결과)보증내역-03보증처리구분 
	 * noteDetailsEnoteNumber (조회결과)어음내역-04전자어음번호 
	 * noteDetailsEnoteType (조회결과)어음내역-05전자어음종류 
	 * noteDetailsEnoteProcessStatus (조회결과)어음내역-06전자어음처리상태 
	 * noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
	 * noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
	 * noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
	 * noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
	 * noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
	 * issuerCorpIndvSort (조회결과)발행인-개인법인구분 
	 * issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
	 * issuerCorpName (조회결과)발행인-법인명 
	 * issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
	 * issuerAddress (조회결과)발행인-주소 
	 * endorserCorpIndvSort (조회결과)배서인개인법인구분 
	 * endorserResidentBusinessNumber (조회결과)배서인주민사업자번호 
	 * endorserCorpName (조회결과)배서인법인명 
	 * endorserNameRepresentativeName (조회결과)배서인성명(대표자명) 
	 * endorserAddress (조회결과)배서인주소 
	 * endorserBankCode (조회결과)배서인은행코드 
	 * endorserDepositAccountNumber (조회결과)배서인입금계좌번호 
	 * endorseeCorpIndvSort (조회결과)피배서인개인법인구분 
	 * endorseeResidentBusinessNumber (조회결과)피배서인주민사업자번호 
	 * endorseeCorpName (조회결과)피배서인법인명 
	 * endorseeNameRepresentativeName (조회결과)피배서인성명(대표자명) 
	 * endorseeAddress (조회결과)피배서인주소 
	 * endorseeBankCode (조회결과)피배서인은행코드 
	 * endorseeDepositAccountNumber (조회결과)피배서인입금계좌번호 
	 * additionalConditionsUnsecuredEndorsementYn (조회결과)부가요건-무담보배서여부 
	 * additionalConditionsEndorsementProhibitionEndorsementYn (조회결과)부가요건-배서금지배서여부 
	 * additionalConditionsSplitNumber (조회결과)부가요건-분할번호 
	 * additionalConditionsEndorsementNumber (조회결과)부가요건-배서번호 
	 * additionalConditionsEndorsementAmount (조회결과)부가요건-배서금액 
	 * guarantorGuaranteeSort (조회결과)보증인-보증구분 
	 * guarantorCorpIndvSort (조회결과)보증인-개인법인구분 
	 * guarantorResidentBusinessNumber (조회결과)보증인-주민사업자번호 
	 * guarantorCorpName (조회결과)보증인-법인명 
	 * guarantorNameRepresentativeName (조회결과)보증인-성명(대표자명) 
	 * guarantorAddress (조회결과)보증인-주소 
	 * guarantorBankCode (조회결과)보증인-은행코드 
	 * guarantorDepositAccountNumber (조회결과)보증인-입금계좌번호 
	 * guarantorGuaranteeNumber (조회결과)보증인-보증번호 
	 * 
	 * KftEnt0200421000.QueryResult queryResult = new KftEnt0200421000.QueryResult(); // 조회결과Array
	 * queryResult.setGuaranteeDetailsGuaranteeRequestDate(""); // (조회결과)보증내역-01보증요청일자
	 * queryResult.setGuaranteeDetailsGuaranteeProcessingDate(""); // (조회결과)보증내역-02보증처리일자
	 * queryResult.setGuaranteeDetailsGuaranteeProcessSort(""); // (조회결과)보증내역-03보증처리구분
	 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-04전자어음번호
	 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-05전자어음종류
	 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-06전자어음처리상태
	 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
	 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
	 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
	 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
	 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
	 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
	 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
	 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
	 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
	 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
	 * queryResult.setEndorserCorpIndvSort(""); // (조회결과)배서인개인법인구분
	 * queryResult.setEndorserResidentBusinessNumber(""); // (조회결과)배서인주민사업자번호
	 * queryResult.setEndorserCorpName(""); // (조회결과)배서인법인명
	 * queryResult.setEndorserNameRepresentativeName(""); // (조회결과)배서인성명(대표자명)
	 * queryResult.setEndorserAddress(""); // (조회결과)배서인주소
	 * queryResult.setEndorserBankCode(""); // (조회결과)배서인은행코드
	 * queryResult.setEndorserDepositAccountNumber(""); // (조회결과)배서인입금계좌번호
	 * queryResult.setEndorseeCorpIndvSort(""); // (조회결과)피배서인개인법인구분
	 * queryResult.setEndorseeResidentBusinessNumber(""); // (조회결과)피배서인주민사업자번호
	 * queryResult.setEndorseeCorpName(""); // (조회결과)피배서인법인명
	 * queryResult.setEndorseeNameRepresentativeName(""); // (조회결과)피배서인성명(대표자명)
	 * queryResult.setEndorseeAddress(""); // (조회결과)피배서인주소
	 * queryResult.setEndorseeBankCode(""); // (조회결과)피배서인은행코드
	 * queryResult.setEndorseeDepositAccountNumber(""); // (조회결과)피배서인입금계좌번호
	 * queryResult.setAdditionalConditionsUnsecuredEndorsementYn(""); // (조회결과)부가요건-무담보배서여부
	 * queryResult.setAdditionalConditionsEndorsementProhibitionEndorsementYn(""); // (조회결과)부가요건-배서금지배서여부
	 * queryResult.setAdditionalConditionsSplitNumber(""); // (조회결과)부가요건-분할번호
	 * queryResult.setAdditionalConditionsEndorsementNumber(""); // (조회결과)부가요건-배서번호
	 * queryResult.setAdditionalConditionsEndorsementAmount(0L); // (조회결과)부가요건-배서금액
	 * queryResult.setGuarantorGuaranteeSort(""); // (조회결과)보증인-보증구분
	 * queryResult.setGuarantorCorpIndvSort(""); // (조회결과)보증인-개인법인구분
	 * queryResult.setGuarantorResidentBusinessNumber(""); // (조회결과)보증인-주민사업자번호
	 * queryResult.setGuarantorCorpName(""); // (조회결과)보증인-법인명
	 * queryResult.setGuarantorNameRepresentativeName(""); // (조회결과)보증인-성명(대표자명)
	 * queryResult.setGuarantorAddress(""); // (조회결과)보증인-주소
	 * queryResult.setGuarantorBankCode(""); // (조회결과)보증인-은행코드
	 * queryResult.setGuarantorDepositAccountNumber(""); // (조회결과)보증인-입금계좌번호
	 * queryResult.setGuarantorGuaranteeNumber(""); // (조회결과)보증인-보증번호
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String guaranteeDetailsGuaranteeRequestDate; // (조회결과)보증내역-01보증요청일자
		private String guaranteeDetailsGuaranteeProcessingDate; // (조회결과)보증내역-02보증처리일자
		private String guaranteeDetailsGuaranteeProcessSort; // (조회결과)보증내역-03보증처리구분
		private String noteDetailsEnoteNumber; // (조회결과)어음내역-04전자어음번호
		private String noteDetailsEnoteType; // (조회결과)어음내역-05전자어음종류
		private String noteDetailsEnoteProcessStatus; // (조회결과)어음내역-06전자어음처리상태
		private String noteDetailsEnoteIssueDate; // (조회결과)어음내역-전자어음발행일자
		private String noteDetailsEnoteIssuePlace; // (조회결과)어음내역-전자어음발행지
		private long noteDetailsEnoteAmount; // (조회결과)어음내역-전자어음금액
		private String noteDetailsEnoteMaturedDate; // (조회결과)어음내역-전자어음만기일자
		private String noteDetailsPaymentBankAndBranchCode; // (조회결과)어음내역-지급은행및지점코드
		private String issuerCorpIndvSort; // (조회결과)발행인-개인법인구분
		private String issuerResidentBusinessNumber; // (조회결과)발행인-주민사업자번호
		private String issuerCorpName; // (조회결과)발행인-법인명
		private String issuerNameRepresentativeName; // (조회결과)발행인-성명(대표자명)
		private String issuerAddress; // (조회결과)발행인-주소
		private String endorserCorpIndvSort; // (조회결과)배서인개인법인구분
		private String endorserResidentBusinessNumber; // (조회결과)배서인주민사업자번호
		private String endorserCorpName; // (조회결과)배서인법인명
		private String endorserNameRepresentativeName; // (조회결과)배서인성명(대표자명)
		private String endorserAddress; // (조회결과)배서인주소
		private String endorserBankCode; // (조회결과)배서인은행코드
		private String endorserDepositAccountNumber; // (조회결과)배서인입금계좌번호
		private String endorseeCorpIndvSort; // (조회결과)피배서인개인법인구분
		private String endorseeResidentBusinessNumber; // (조회결과)피배서인주민사업자번호
		private String endorseeCorpName; // (조회결과)피배서인법인명
		private String endorseeNameRepresentativeName; // (조회결과)피배서인성명(대표자명)
		private String endorseeAddress; // (조회결과)피배서인주소
		private String endorseeBankCode; // (조회결과)피배서인은행코드
		private String endorseeDepositAccountNumber; // (조회결과)피배서인입금계좌번호
		private String additionalConditionsUnsecuredEndorsementYn; // (조회결과)부가요건-무담보배서여부
		private String additionalConditionsEndorsementProhibitionEndorsementYn; // (조회결과)부가요건-배서금지배서여부
		private String additionalConditionsSplitNumber; // (조회결과)부가요건-분할번호
		private String additionalConditionsEndorsementNumber; // (조회결과)부가요건-배서번호
		private long additionalConditionsEndorsementAmount; // (조회결과)부가요건-배서금액
		private String guarantorGuaranteeSort; // (조회결과)보증인-보증구분
		private String guarantorCorpIndvSort; // (조회결과)보증인-개인법인구분
		private String guarantorResidentBusinessNumber; // (조회결과)보증인-주민사업자번호
		private String guarantorCorpName; // (조회결과)보증인-법인명
		private String guarantorNameRepresentativeName; // (조회결과)보증인-성명(대표자명)
		private String guarantorAddress; // (조회결과)보증인-주소
		private String guarantorBankCode; // (조회결과)보증인-은행코드
		private String guarantorDepositAccountNumber; // (조회결과)보증인-입금계좌번호
		private String guarantorGuaranteeNumber; // (조회결과)보증인-보증번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeRequestDate$; // (조회결과)보증내역-01보증요청일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeProcessingDate$; // (조회결과)보증내역-02보증처리일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guaranteeDetailsGuaranteeProcessSort$; // (조회결과)보증내역-03보증처리구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteNumber$; // (조회결과)어음내역-04전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteType$; // (조회결과)어음내역-05전자어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteProcessStatus$; // (조회결과)어음내역-06전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssueDate$; // (조회결과)어음내역-전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssuePlace$; // (조회결과)어음내역-전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteAmount$; // (조회결과)어음내역-전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteMaturedDate$; // (조회결과)어음내역-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsPaymentBankAndBranchCode$; // (조회결과)어음내역-지급은행및지점코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpIndvSort$; // (조회결과)발행인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerResidentBusinessNumber$; // (조회결과)발행인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpName$; // (조회결과)발행인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerNameRepresentativeName$; // (조회결과)발행인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerAddress$; // (조회결과)발행인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserCorpIndvSort$; // (조회결과)배서인개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserResidentBusinessNumber$; // (조회결과)배서인주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserCorpName$; // (조회결과)배서인법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserNameRepresentativeName$; // (조회결과)배서인성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserAddress$; // (조회결과)배서인주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserBankCode$; // (조회결과)배서인은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorserDepositAccountNumber$; // (조회결과)배서인입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeCorpIndvSort$; // (조회결과)피배서인개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeResidentBusinessNumber$; // (조회결과)피배서인주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeCorpName$; // (조회결과)피배서인법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeNameRepresentativeName$; // (조회결과)피배서인성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeAddress$; // (조회결과)피배서인주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeBankCode$; // (조회결과)피배서인은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorseeDepositAccountNumber$; // (조회결과)피배서인입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String additionalConditionsUnsecuredEndorsementYn$; // (조회결과)부가요건-무담보배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String additionalConditionsEndorsementProhibitionEndorsementYn$; // (조회결과)부가요건-배서금지배서여부
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String additionalConditionsSplitNumber$; // (조회결과)부가요건-분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String additionalConditionsEndorsementNumber$; // (조회결과)부가요건-배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String additionalConditionsEndorsementAmount$; // (조회결과)부가요건-배서금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorGuaranteeSort$; // (조회결과)보증인-보증구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorCorpIndvSort$; // (조회결과)보증인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorResidentBusinessNumber$; // (조회결과)보증인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorCorpName$; // (조회결과)보증인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorNameRepresentativeName$; // (조회결과)보증인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorAddress$; // (조회결과)보증인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorBankCode$; // (조회결과)보증인-은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorDepositAccountNumber$; // (조회결과)보증인-입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String guarantorGuaranteeNumber$; // (조회결과)보증인-보증번호

		@Override
		public void write(OutputStream out) throws IOException {
			guaranteeDetailsGuaranteeRequestDate$ = VOUtils.write(out, guaranteeDetailsGuaranteeRequestDate, 8); // (조회결과)보증내역-01보증요청일자
			guaranteeDetailsGuaranteeProcessingDate$ = VOUtils.write(out, guaranteeDetailsGuaranteeProcessingDate, 8); // (조회결과)보증내역-02보증처리일자
			guaranteeDetailsGuaranteeProcessSort$ = VOUtils.write(out, guaranteeDetailsGuaranteeProcessSort, 1); // (조회결과)보증내역-03보증처리구분
			noteDetailsEnoteNumber$ = VOUtils.write(out, noteDetailsEnoteNumber, 20); // (조회결과)어음내역-04전자어음번호
			noteDetailsEnoteType$ = VOUtils.write(out, noteDetailsEnoteType, 1); // (조회결과)어음내역-05전자어음종류
			noteDetailsEnoteProcessStatus$ = VOUtils.write(out, noteDetailsEnoteProcessStatus, 2); // (조회결과)어음내역-06전자어음처리상태
			noteDetailsEnoteIssueDate$ = VOUtils.write(out, noteDetailsEnoteIssueDate, 8); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace$ = VOUtils.write(out, noteDetailsEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount$ = VOUtils.write(out, noteDetailsEnoteAmount, 15); // (조회결과)어음내역-전자어음금액
			noteDetailsEnoteMaturedDate$ = VOUtils.write(out, noteDetailsEnoteMaturedDate, 8); // (조회결과)어음내역-전자어음만기일자
			noteDetailsPaymentBankAndBranchCode$ = VOUtils.write(out, noteDetailsPaymentBankAndBranchCode, 7); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // (조회결과)발행인-주민사업자번호
			issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // (조회결과)발행인-법인명
			issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인-성명(대표자명)
			issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // (조회결과)발행인-주소
			endorserCorpIndvSort$ = VOUtils.write(out, endorserCorpIndvSort, 1); // (조회결과)배서인개인법인구분
			endorserResidentBusinessNumber$ = VOUtils.write(out, endorserResidentBusinessNumber, 13); // (조회결과)배서인주민사업자번호
			endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // (조회결과)배서인법인명
			endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // (조회결과)배서인성명(대표자명)
			endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // (조회결과)배서인주소
			endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // (조회결과)배서인은행코드
			endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // (조회결과)배서인입금계좌번호
			endorseeCorpIndvSort$ = VOUtils.write(out, endorseeCorpIndvSort, 1); // (조회결과)피배서인개인법인구분
			endorseeResidentBusinessNumber$ = VOUtils.write(out, endorseeResidentBusinessNumber, 13); // (조회결과)피배서인주민사업자번호
			endorseeCorpName$ = VOUtils.write(out, endorseeCorpName, 40, "EUC-KR"); // (조회결과)피배서인법인명
			endorseeNameRepresentativeName$ = VOUtils.write(out, endorseeNameRepresentativeName, 20, "EUC-KR"); // (조회결과)피배서인성명(대표자명)
			endorseeAddress$ = VOUtils.write(out, endorseeAddress, 60, "EUC-KR"); // (조회결과)피배서인주소
			endorseeBankCode$ = VOUtils.write(out, endorseeBankCode, 3); // (조회결과)피배서인은행코드
			endorseeDepositAccountNumber$ = VOUtils.write(out, endorseeDepositAccountNumber, 16); // (조회결과)피배서인입금계좌번호
			additionalConditionsUnsecuredEndorsementYn$ = VOUtils.write(out, additionalConditionsUnsecuredEndorsementYn, 1); // (조회결과)부가요건-무담보배서여부
			additionalConditionsEndorsementProhibitionEndorsementYn$ = VOUtils.write(out, additionalConditionsEndorsementProhibitionEndorsementYn, 1); // (조회결과)부가요건-배서금지배서여부
			additionalConditionsSplitNumber$ = VOUtils.write(out, additionalConditionsSplitNumber, 2); // (조회결과)부가요건-분할번호
			additionalConditionsEndorsementNumber$ = VOUtils.write(out, additionalConditionsEndorsementNumber, 2); // (조회결과)부가요건-배서번호
			additionalConditionsEndorsementAmount$ = VOUtils.write(out, additionalConditionsEndorsementAmount, 15); // (조회결과)부가요건-배서금액
			guarantorGuaranteeSort$ = VOUtils.write(out, guarantorGuaranteeSort, 1); // (조회결과)보증인-보증구분
			guarantorCorpIndvSort$ = VOUtils.write(out, guarantorCorpIndvSort, 1); // (조회결과)보증인-개인법인구분
			guarantorResidentBusinessNumber$ = VOUtils.write(out, guarantorResidentBusinessNumber, 13); // (조회결과)보증인-주민사업자번호
			guarantorCorpName$ = VOUtils.write(out, guarantorCorpName, 40, "EUC-KR"); // (조회결과)보증인-법인명
			guarantorNameRepresentativeName$ = VOUtils.write(out, guarantorNameRepresentativeName, 20, "EUC-KR"); // (조회결과)보증인-성명(대표자명)
			guarantorAddress$ = VOUtils.write(out, guarantorAddress, 60, "EUC-KR"); // (조회결과)보증인-주소
			guarantorBankCode$ = VOUtils.write(out, guarantorBankCode, 3); // (조회결과)보증인-은행코드
			guarantorDepositAccountNumber$ = VOUtils.write(out, guarantorDepositAccountNumber, 16); // (조회결과)보증인-입금계좌번호
			guarantorGuaranteeNumber$ = VOUtils.write(out, guarantorGuaranteeNumber, 4); // (조회결과)보증인-보증번호
		}

		@Override
		public void read(InputStream in) throws IOException {
			guaranteeDetailsGuaranteeRequestDate = VOUtils.toString(guaranteeDetailsGuaranteeRequestDate$ = VOUtils.read(in, 8)); // (조회결과)보증내역-01보증요청일자
			guaranteeDetailsGuaranteeProcessingDate = VOUtils.toString(guaranteeDetailsGuaranteeProcessingDate$ = VOUtils.read(in, 8)); // (조회결과)보증내역-02보증처리일자
			guaranteeDetailsGuaranteeProcessSort = VOUtils.toString(guaranteeDetailsGuaranteeProcessSort$ = VOUtils.read(in, 1)); // (조회결과)보증내역-03보증처리구분
			noteDetailsEnoteNumber = VOUtils.toString(noteDetailsEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음내역-04전자어음번호
			noteDetailsEnoteType = VOUtils.toString(noteDetailsEnoteType$ = VOUtils.read(in, 1)); // (조회결과)어음내역-05전자어음종류
			noteDetailsEnoteProcessStatus = VOUtils.toString(noteDetailsEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음내역-06전자어음처리상태
			noteDetailsEnoteIssueDate = VOUtils.toString(noteDetailsEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace = VOUtils.toString(noteDetailsEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount = VOUtils.toLong(noteDetailsEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음내역-전자어음금액
			noteDetailsEnoteMaturedDate = VOUtils.toString(noteDetailsEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음만기일자
			noteDetailsPaymentBankAndBranchCode = VOUtils.toString(noteDetailsPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인-주민사업자번호
			issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인-법인명
			issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인-성명(대표자명)
			issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인-주소
			endorserCorpIndvSort = VOUtils.toString(endorserCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)배서인개인법인구분
			endorserResidentBusinessNumber = VOUtils.toString(endorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)배서인주민사업자번호
			endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)배서인법인명
			endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)배서인성명(대표자명)
			endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)배서인주소
			endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // (조회결과)배서인은행코드
			endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)배서인입금계좌번호
			endorseeCorpIndvSort = VOUtils.toString(endorseeCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)피배서인개인법인구분
			endorseeResidentBusinessNumber = VOUtils.toString(endorseeResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)피배서인주민사업자번호
			endorseeCorpName = VOUtils.toString(endorseeCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)피배서인법인명
			endorseeNameRepresentativeName = VOUtils.toString(endorseeNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)피배서인성명(대표자명)
			endorseeAddress = VOUtils.toString(endorseeAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)피배서인주소
			endorseeBankCode = VOUtils.toString(endorseeBankCode$ = VOUtils.read(in, 3)); // (조회결과)피배서인은행코드
			endorseeDepositAccountNumber = VOUtils.toString(endorseeDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)피배서인입금계좌번호
			additionalConditionsUnsecuredEndorsementYn = VOUtils.toString(additionalConditionsUnsecuredEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)부가요건-무담보배서여부
			additionalConditionsEndorsementProhibitionEndorsementYn = VOUtils.toString(additionalConditionsEndorsementProhibitionEndorsementYn$ = VOUtils.read(in, 1)); // (조회결과)부가요건-배서금지배서여부
			additionalConditionsSplitNumber = VOUtils.toString(additionalConditionsSplitNumber$ = VOUtils.read(in, 2)); // (조회결과)부가요건-분할번호
			additionalConditionsEndorsementNumber = VOUtils.toString(additionalConditionsEndorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)부가요건-배서번호
			additionalConditionsEndorsementAmount = VOUtils.toLong(additionalConditionsEndorsementAmount$ = VOUtils.read(in, 15)); // (조회결과)부가요건-배서금액
			guarantorGuaranteeSort = VOUtils.toString(guarantorGuaranteeSort$ = VOUtils.read(in, 1)); // (조회결과)보증인-보증구분
			guarantorCorpIndvSort = VOUtils.toString(guarantorCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)보증인-개인법인구분
			guarantorResidentBusinessNumber = VOUtils.toString(guarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)보증인-주민사업자번호
			guarantorCorpName = VOUtils.toString(guarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)보증인-법인명
			guarantorNameRepresentativeName = VOUtils.toString(guarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)보증인-성명(대표자명)
			guarantorAddress = VOUtils.toString(guarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)보증인-주소
			guarantorBankCode = VOUtils.toString(guarantorBankCode$ = VOUtils.read(in, 3)); // (조회결과)보증인-은행코드
			guarantorDepositAccountNumber = VOUtils.toString(guarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)보증인-입금계좌번호
			guarantorGuaranteeNumber = VOUtils.toString(guarantorGuaranteeNumber$ = VOUtils.read(in, 4)); // (조회결과)보증인-보증번호
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", guaranteeDetailsGuaranteeRequestDate=").append(guaranteeDetailsGuaranteeRequestDate).append(System.lineSeparator()); // (조회결과)보증내역-01보증요청일자
			sb.append(", guaranteeDetailsGuaranteeProcessingDate=").append(guaranteeDetailsGuaranteeProcessingDate).append(System.lineSeparator()); // (조회결과)보증내역-02보증처리일자
			sb.append(", guaranteeDetailsGuaranteeProcessSort=").append(guaranteeDetailsGuaranteeProcessSort).append(System.lineSeparator()); // (조회결과)보증내역-03보증처리구분
			sb.append(", noteDetailsEnoteNumber=").append(noteDetailsEnoteNumber).append(System.lineSeparator()); // (조회결과)어음내역-04전자어음번호
			sb.append(", noteDetailsEnoteType=").append(noteDetailsEnoteType).append(System.lineSeparator()); // (조회결과)어음내역-05전자어음종류
			sb.append(", noteDetailsEnoteProcessStatus=").append(noteDetailsEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음내역-06전자어음처리상태
			sb.append(", noteDetailsEnoteIssueDate=").append(noteDetailsEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행일자
			sb.append(", noteDetailsEnoteIssuePlace=").append(noteDetailsEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행지
			sb.append(", noteDetailsEnoteAmount=").append(noteDetailsEnoteAmount).append(System.lineSeparator()); // (조회결과)어음내역-전자어음금액
			sb.append(", noteDetailsEnoteMaturedDate=").append(noteDetailsEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음만기일자
			sb.append(", noteDetailsPaymentBankAndBranchCode=").append(noteDetailsPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음내역-지급은행및지점코드
			sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인-개인법인구분
			sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인-주민사업자번호
			sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // (조회결과)발행인-법인명
			sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인-성명(대표자명)
			sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // (조회결과)발행인-주소
			sb.append(", endorserCorpIndvSort=").append(endorserCorpIndvSort).append(System.lineSeparator()); // (조회결과)배서인개인법인구분
			sb.append(", endorserResidentBusinessNumber=").append(endorserResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)배서인주민사업자번호
			sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // (조회결과)배서인법인명
			sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // (조회결과)배서인성명(대표자명)
			sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // (조회결과)배서인주소
			sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // (조회결과)배서인은행코드
			sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // (조회결과)배서인입금계좌번호
			sb.append(", endorseeCorpIndvSort=").append(endorseeCorpIndvSort).append(System.lineSeparator()); // (조회결과)피배서인개인법인구분
			sb.append(", endorseeResidentBusinessNumber=").append(endorseeResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)피배서인주민사업자번호
			sb.append(", endorseeCorpName=").append(endorseeCorpName).append(System.lineSeparator()); // (조회결과)피배서인법인명
			sb.append(", endorseeNameRepresentativeName=").append(endorseeNameRepresentativeName).append(System.lineSeparator()); // (조회결과)피배서인성명(대표자명)
			sb.append(", endorseeAddress=").append(endorseeAddress).append(System.lineSeparator()); // (조회결과)피배서인주소
			sb.append(", endorseeBankCode=").append(endorseeBankCode).append(System.lineSeparator()); // (조회결과)피배서인은행코드
			sb.append(", endorseeDepositAccountNumber=").append(endorseeDepositAccountNumber).append(System.lineSeparator()); // (조회결과)피배서인입금계좌번호
			sb.append(", additionalConditionsUnsecuredEndorsementYn=").append(additionalConditionsUnsecuredEndorsementYn).append(System.lineSeparator()); // (조회결과)부가요건-무담보배서여부
			sb.append(", additionalConditionsEndorsementProhibitionEndorsementYn=").append(additionalConditionsEndorsementProhibitionEndorsementYn).append(System.lineSeparator()); // (조회결과)부가요건-배서금지배서여부
			sb.append(", additionalConditionsSplitNumber=").append(additionalConditionsSplitNumber).append(System.lineSeparator()); // (조회결과)부가요건-분할번호
			sb.append(", additionalConditionsEndorsementNumber=").append(additionalConditionsEndorsementNumber).append(System.lineSeparator()); // (조회결과)부가요건-배서번호
			sb.append(", additionalConditionsEndorsementAmount=").append(additionalConditionsEndorsementAmount).append(System.lineSeparator()); // (조회결과)부가요건-배서금액
			sb.append(", guarantorGuaranteeSort=").append(guarantorGuaranteeSort).append(System.lineSeparator()); // (조회결과)보증인-보증구분
			sb.append(", guarantorCorpIndvSort=").append(guarantorCorpIndvSort).append(System.lineSeparator()); // (조회결과)보증인-개인법인구분
			sb.append(", guarantorResidentBusinessNumber=").append(guarantorResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)보증인-주민사업자번호
			sb.append(", guarantorCorpName=").append(guarantorCorpName).append(System.lineSeparator()); // (조회결과)보증인-법인명
			sb.append(", guarantorNameRepresentativeName=").append(guarantorNameRepresentativeName).append(System.lineSeparator()); // (조회결과)보증인-성명(대표자명)
			sb.append(", guarantorAddress=").append(guarantorAddress).append(System.lineSeparator()); // (조회결과)보증인-주소
			sb.append(", guarantorBankCode=").append(guarantorBankCode).append(System.lineSeparator()); // (조회결과)보증인-은행코드
			sb.append(", guarantorDepositAccountNumber=").append(guarantorDepositAccountNumber).append(System.lineSeparator()); // (조회결과)보증인-입금계좌번호
			sb.append(", guarantorGuaranteeNumber=").append(guarantorGuaranteeNumber).append(System.lineSeparator()); // (조회결과)보증인-보증번호
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "421000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String sortCondition; // 정렬조건
	private String searchConditionSort; // 검색조건구분
	private String userSort; // 이용자구분
	private String inquiryNoteGuaranteeStatusSort; // 조회전자어음보증상태구분
	private String eNoteNumber; // 전자어음번호
	private String splitNumber; // 분할번호
	private String residentBusinessNumber; // 주민사업자번호
	private String depositAccountNumber; // 입금계좌번호
	private String guaranteeRequestDateBasisQueryStartDate; // 보증요청일기준조회시작일
	private String guaranteeRequestDateBasisQueryEndDate; // 보증요청일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0200421000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sortCondition$; // 정렬조건
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String userSort$; // 이용자구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String inquiryNoteGuaranteeStatusSort$; // 조회전자어음보증상태구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDateBasisQueryStartDate$; // 보증요청일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDateBasisQueryEndDate$; // 보증요청일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(userSort$)) { // 이용자구분
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(depositAccountNumber$)) { // 입금계좌번호
			return 20;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		sortCondition$ = VOUtils.write(out, sortCondition, 2); // 정렬조건
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		userSort$ = VOUtils.write(out, userSort, 1); // 이용자구분
		inquiryNoteGuaranteeStatusSort$ = VOUtils.write(out, inquiryNoteGuaranteeStatusSort, 1); // 조회전자어음보증상태구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		guaranteeRequestDateBasisQueryStartDate$ = VOUtils.write(out, guaranteeRequestDateBasisQueryStartDate, 8); // 보증요청일기준조회시작일
		guaranteeRequestDateBasisQueryEndDate$ = VOUtils.write(out, guaranteeRequestDateBasisQueryEndDate, 8); // 보증요청일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0200421000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		sortCondition = VOUtils.toString(sortCondition$ = VOUtils.read(in, 2)); // 정렬조건
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		userSort = VOUtils.toString(userSort$ = VOUtils.read(in, 1)); // 이용자구분
		inquiryNoteGuaranteeStatusSort = VOUtils.toString(inquiryNoteGuaranteeStatusSort$ = VOUtils.read(in, 1)); // 조회전자어음보증상태구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		guaranteeRequestDateBasisQueryStartDate = VOUtils.toString(guaranteeRequestDateBasisQueryStartDate$ = VOUtils.read(in, 8)); // 보증요청일기준조회시작일
		guaranteeRequestDateBasisQueryEndDate = VOUtils.toString(guaranteeRequestDateBasisQueryEndDate$ = VOUtils.read(in, 8)); // 보증요청일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0200421000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", sortCondition=").append(sortCondition).append(System.lineSeparator()); // 정렬조건
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", userSort=").append(userSort).append(System.lineSeparator()); // 이용자구분
		sb.append(", inquiryNoteGuaranteeStatusSort=").append(inquiryNoteGuaranteeStatusSort).append(System.lineSeparator()); // 조회전자어음보증상태구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", guaranteeRequestDateBasisQueryStartDate=").append(guaranteeRequestDateBasisQueryStartDate).append(System.lineSeparator()); // 보증요청일기준조회시작일
		sb.append(", guaranteeRequestDateBasisQueryEndDate=").append(guaranteeRequestDateBasisQueryEndDate).append(System.lineSeparator()); // 보증요청일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "421000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "sortCondition", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "userSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "inquiryNoteGuaranteeStatusSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDateBasisQueryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDateBasisQueryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeDetailsGuaranteeProcessSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorseeCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorseeResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorseeCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorseeNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorseeAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorseeBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorseeDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "additionalConditionsUnsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "additionalConditionsEndorsementProhibitionEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "additionalConditionsSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "additionalConditionsEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "additionalConditionsEndorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "guarantorGuaranteeSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "guarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "guarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "guarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "guarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "guarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guarantorGuaranteeNumber", "fldLen", "4", "defltVal", "")
		);
	}

}
