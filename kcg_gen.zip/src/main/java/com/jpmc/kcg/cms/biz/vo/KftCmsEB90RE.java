package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90RE kftCmsEB90RE  = new KftCmsEB90RE(); // 이용기관정보통지
 * kftCmsEB90RE.setRecordType(""); // Record 구분
 * kftCmsEB90RE.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB90RE.setDataRecordType(""); // Data Record 구분코드
 * kftCmsEB90RE.setInstitutionCode(""); // 기관코드
 * kftCmsEB90RE.setChangeSeqBitMap(""); // 변경항번BitMap
 * kftCmsEB90RE.setPayerNumberSystemDesc4(""); // 납부자번호 체계 설명 4
 * kftCmsEB90RE.setPayerNumberSystemDesc5(""); // 납부자번호 체계 설명 5
 * kftCmsEB90RE.setFundType(""); // 자금종류
 * kftCmsEB90RE.setFiller6(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90RE implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String dataRecordType; // Data Record 구분코드
	private String institutionCode; // 기관코드
	private String changeSeqBitMap; // 변경항번BitMap
	private String payerNumberSystemDesc4; // 납부자번호 체계 설명 4
	private String payerNumberSystemDesc5; // 납부자번호 체계 설명 5
	private String fundType; // 자금종류
	private String filler6; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataRecordType$; // Data Record 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeSeqBitMap$; // 변경항번BitMap
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystemDesc4$; // 납부자번호 체계 설명 4
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystemDesc5$; // 납부자번호 체계 설명 5
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler6$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		dataRecordType$ = VOUtils.write(out, dataRecordType, 1); // Data Record 구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		changeSeqBitMap$ = VOUtils.write(out, changeSeqBitMap, 15); // 변경항번BitMap
		payerNumberSystemDesc4$ = VOUtils.write(out, payerNumberSystemDesc4, 70, "EUC-KR"); // 납부자번호 체계 설명 4
		payerNumberSystemDesc5$ = VOUtils.write(out, payerNumberSystemDesc5, 70, "EUC-KR"); // 납부자번호 체계 설명 5
		fundType$ = VOUtils.write(out, fundType, 30, "EUC-KR"); // 자금종류
		filler6$ = VOUtils.write(out, filler6, 45); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		dataRecordType = VOUtils.toString(dataRecordType$ = VOUtils.read(in, 1)); // Data Record 구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		changeSeqBitMap = VOUtils.toString(changeSeqBitMap$ = VOUtils.read(in, 15)); // 변경항번BitMap
		payerNumberSystemDesc4 = VOUtils.toString(payerNumberSystemDesc4$ = VOUtils.read(in, 70, "EUC-KR")); // 납부자번호 체계 설명 4
		payerNumberSystemDesc5 = VOUtils.toString(payerNumberSystemDesc5$ = VOUtils.read(in, 70, "EUC-KR")); // 납부자번호 체계 설명 5
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 30, "EUC-KR")); // 자금종류
		filler6 = VOUtils.toString(filler6$ = VOUtils.read(in, 45)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", dataRecordType=").append(dataRecordType).append(System.lineSeparator()); // Data Record 구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", changeSeqBitMap=").append(changeSeqBitMap).append(System.lineSeparator()); // 변경항번BitMap
		sb.append(", payerNumberSystemDesc4=").append(payerNumberSystemDesc4).append(System.lineSeparator()); // 납부자번호 체계 설명 4
		sb.append(", payerNumberSystemDesc5=").append(payerNumberSystemDesc5).append(System.lineSeparator()); // 납부자번호 체계 설명 5
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금종류
		sb.append(", filler6=").append(filler6).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "dataRecordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "changeSeqBitMap", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "payerNumberSystemDesc4", "fldLen", "70", "defltVal", ""),
			Map.of("fld", "payerNumberSystemDesc5", "fldLen", "70", "defltVal", ""),
			Map.of("fld", "fundType", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "filler6", "fldLen", "45", "defltVal", "")
		);
	}

}
