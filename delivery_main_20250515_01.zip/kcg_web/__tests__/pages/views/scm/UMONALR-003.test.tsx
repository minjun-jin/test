import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// UMONALR003 컴포넌트를 불러옵니다.
import UMONALR003 from "@/pages/views/scm/UMONALR-003"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(UMONALR003)

describe("[UMONALR-003] Push 메시지 포맷(HTML) 관리", () => {
  beforeAll(() => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      { roleCd: CONFIG.ROLE_CD.ALL },
    ])
  })

  it("main grid valueFormatter Test", async () => {
    const { findAllByText } = render(component)
    const valueFormatterTestBtn = (
      await findAllByText(/valueFormatter Test/)
    )[0]

    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("main grid onRowClicked Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        paramSubOutList: [],
        rcvdSubOutList: [],
      },
    })
    const { findAllByText } = render(component)
    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]

    fireEvent.click(onRowClickedTestBtn, { target: { data: {} } })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("main grid onRowDoubleClicked Test - aprvStsCd is 01", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        paramSubOutList: [],
        rcvdSubOutList: [],
      },
    })
    const { findAllByText } = render(component)
    const onRowDoubleClickedTestBtn = (
      await findAllByText(/onRowDoubleClicked Test/)
    )[0]

    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "01",
        },
      },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("main grid onRowDoubleClicked Test - aprvStsCd is 02", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        paramSubOutList: [],
        rcvdSubOutList: [],
      },
    })
    const { findAllByText } = render(component)
    const onRowDoubleClickedTestBtn = (
      await findAllByText(/onRowDoubleClicked Test/)
    )[0]

    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "02",
        },
      },
    })

    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
    })
  })

  it("main grid rowClassRules Test", async () => {
    const { findAllByText } = render(component)
    const rowClassRulesTestBtn = (await findAllByText(/rowClassRules Test/))[0]
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: { data: { aprvStsCd: "02" } },
      },
    })
  })

  it("rcvdUser grid rowClassRules Test", async () => {
    const { findAllByText } = render(component)
    const rowClassRulesTestBtn = (await findAllByText(/rowClassRules Test/))[2]
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: { data: { aprvStsCd: "02" } },
      },
    })
  })

  it("addRcvdUserGroup Test - pshMsgTmpltId is undefined", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(undefined)
    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[1]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).not.toHaveBeenCalled()
    })
  })

  it("addRcvdUserGroup Test - grpId is undefined", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseModal.mockOpenPopup.mockResolvedValueOnce({
      grpId: undefined,
    })
    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[1]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
      expect(mockGrid.mockGetAllRows).not.toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockGrid.mockAddRow).not.toHaveBeenCalled()
    })
  })

  it("addRcvdUserGroup Test - isDuplicated is true", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseModal.mockOpenPopup.mockResolvedValueOnce({
      grpId: "test",
    })
    mockGrid.mockGetAllRows.mockReturnValueOnce([{ grpId: "test" }])
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        paramSubOutList: [],
        rcvdSubOutList: [],
      },
    })
    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[1]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
      expect(mockGrid.mockAddRow).not.toHaveBeenCalled()
    })
  })

  it("addRcvdUserGroup Test - targetIndex != -1", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseModal.mockOpenPopup.mockResolvedValueOnce({
      grpId: "test",
    })
    mockGrid.mockGetAllRows
      .mockReturnValueOnce([{ grpId: "no test" }])
      .mockReturnValueOnce([
        {
          grpId: "test",
        },
      ])

    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[1]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockGrid.mockAddRow).toHaveBeenCalled()
      expect(mockGrid.mockSetSelectedRowByIndex).toHaveBeenCalled()
    })
  })

  it("addRcvdUserGroup Test - targetIndex == -1", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseModal.mockOpenPopup.mockResolvedValueOnce({
      grpId: "test",
    })
    mockGrid.mockGetAllRows
      .mockReturnValueOnce([{ grpId: "no test" }])
      .mockReturnValueOnce([
        {
          grpId: "not test",
        },
      ])

    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[1]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockGrid.mockAddRow).toHaveBeenCalled()
      expect(mockGrid.mockSetSelectedRowByIndex).not.toHaveBeenCalled()
    })
  })

  it("delRcvdUsrGroup Test - selectRowList.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findAllByText } = render(component)
    const delRowBtn = (await findAllByText(/SCRNITM#delRow/))[1]
    fireEvent.click(delRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(1)
      expect(mockGrid.mockDelRow).not.toHaveBeenCalled()
    })
  })

  it("delRcvdUsrGroup Test - selectRowList.length > 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        crudType: "C",
        pshMsgTmpltId: "Test",
        grpId: "Test",
      },
      {
        crudType: "A",
        pshMsgTmpltId: "Test",
        grpId: "Test",
      },
    ])
    mockGrid.mockDelRow.mockImplementationOnce((obj, fn1, fn2) => {
      fn1()
      fn2()
    })
    const { findAllByText } = render(component)
    const delRowBtn = (await findAllByText(/SCRNITM#delRow/))[1]
    fireEvent.click(delRowBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(2)
      expect(mockGrid.mockDelRow).toHaveBeenCalled()
    })
  })

  it("saveRcvdUserGroup Test - rcvdGroupList.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])

    const { findAllByText } = render(component)
    const saveBtn = (await findAllByText(/SCRNITM#save/))[1]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).not.toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("saveRcvdUserGroup Test - rcvdList.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      { pshMsgTmpltId: "test" },
    ])

    const { findAllByText } = render(component)
    const saveBtn = (await findAllByText(/SCRNITM#save/))[1]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("saveRcvdUserGroup Test - confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      { pshMsgTmpltId: "test", crudType: "C" },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        paramSubOutList: [],
        rcvdSubOutList: [],
      },
    })

    const { findAllByText } = render(component)
    const saveBtn = (await findAllByText(/SCRNITM#save/))[1]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("saveRcvdUserGroup Test - not confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      { pshMsgTmpltId: "test", crudType: "C" },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findAllByText } = render(component)
    const saveBtn = (await findAllByText(/SCRNITM#save/))[1]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("addPshPrm Test", async () => {
    const { findAllByText } = render(component)
    const addRowBtn = (await findAllByText(/SCRNITM#addRow/))[0]
    fireEvent.click(addRowBtn)

    await waitFor(() => {
      expect(mockGrid.mockAddRow).toHaveBeenCalled()
    })
  })

  it("delPshPrm Test - selectRowList.length is 0 ", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findAllByText } = render(component)
    const delRowBtn = (await findAllByText(/SCRNITM#delRow/))[0]
    fireEvent.click(delRowBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(1)
      expect(mockGrid.mockDelRow).not.toHaveBeenCalled()
    })
  })

  it("delPshPrm Test - selectRowList.length > 0 ", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        crudType: "C",
        pshMsgTmpltId: "test",
        afParmNm: "test",
      },
      {
        crudType: "A",
        pshMsgTmpltId: "test",
        afParmNm: "test",
      },
    ])

    mockGrid.mockDelRow.mockImplementationOnce((obj, fn1, fn2) => {
      fn1()
      fn2()
    })
    const { findAllByText } = render(component)
    const delRowBtn = (await findAllByText(/SCRNITM#delRow/))[0]
    fireEvent.click(delRowBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetSelectedRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(2)
      expect(mockGrid.mockDelRow).toHaveBeenCalled()
    })
  })

  it("pshPrm grid editable Test", async () => {
    const { findAllByText } = render(component)
    const editableTestBtn = (await findAllByText(/editable Test/))[1]
    fireEvent.click(editableTestBtn, {
      target: {
        data: {
          data: {
            crudType: "C",
          },
        },
      },
    })
  })

  it("pshPrm grid rowClassRules Test", async () => {
    const { findAllByText } = render(component)
    const rowClassRulesTestBtn = (await findAllByText(/rowClassRules Test/))[1]
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: {
          data: {
            aprvStsCd: "02",
          },
        },
      },
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchClick Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        tmpltSubOutList: [],
        totLen: 0,
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("addNewData Test", async () => {
    const { findByText } = render(component)
    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)
  })

  it("registerPush - paramList is false", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([{}])
    const { findByText, findAllByText } = render(component)

    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)

    const saveBtn = (await findAllByText(/SCRNITM#save/))[0]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).not.toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("registerPush - confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([{ afParmNm: "test" }])
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        tmpltSubOutList: [],
        totLen: 0,
      },
    })
    const { findByText, findAllByText } = render(component)

    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)

    const saveBtn = (await findAllByText(/SCRNITM#save/))[0]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("registerPush - not confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([{ afParmNm: "test" }])
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText, findAllByText } = render(component)

    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)

    const saveBtn = (await findAllByText(/SCRNITM#save/))[0]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("modifyPush - confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([{ afParmNm: "test" }])
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        tmpltSubOutList: [],
        totLen: 0,
      },
    })
    const { findByText, findAllByText } = render(component)

    const saveBtn = (await findAllByText(/SCRNITM#save/))[0]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("modifyPush - not confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([{ afParmNm: "test" }])
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText, findAllByText } = render(component)

    const saveBtn = (await findAllByText(/SCRNITM#save/))[0]
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("removeFormat Test - confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        tmpltSubOutList: [],
        totLen: 0,
      },
    })
    const { findByText } = render(component)
    const deleteBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(deleteBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("removeFormat Test - not confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)
    const { findByText } = render(component)
    const deleteBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(deleteBtn)
    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("openPopup Test - pshMsgTmpltId is undefined", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(undefined)
    const { findByText } = render(component)
    const previewBtn = await findByText(/SCRNITM#preview/)
    fireEvent.click(previewBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("openPopup Test - pshMsgTmpltId is not undefined", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseModal.mockOpenPopup.mockResolvedValueOnce(true)
    const { findByText } = render(component)
    const previewBtn = await findByText(/SCRNITM#preview/)
    fireEvent.click(previewBtn)

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
    })
  })
})
