package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시결과보고 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID EBS
 * bnkCd 은행코드 
 * messageType 전문종별코드 0210
 * transactionCode 거래구분코드 271000
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * eNoteNumber 전자어음번호 
 * eNoteType 어음종류 
 * eNoteIssueDate 전자어음발행일자 
 * eNoteIssuePlace 전자어음발행지 
 * eNoteAmount 전자어음금액 1,2,3
 * eNoteMaturedDate 전자어음만기일자 
 * paymentBankAndBranchCode 지급은행및지점코드 
 * splitNumber 분할번호 
 * endorsementNumber 배서번호 
 * issuerIndvCorpSort 발행인-개인법인구분 
 * issuerBusinessResidentRegistrationNumber 발행인-사업자(주민)등록번호 
 * issuerCorpName 발행인-법인명 1,2,3
 * issuerNameRepresentativeName 발행인-성명(대표자명) 
 * issuerAddress 발행인-주소 
 * issuerCurrentAccountNumber 발행인-당좌계좌번호 
 * recipientCorpIndvSort 소지인법인개인구분 
 * recipientBusinessResidentRegistrationNumber 소지인사업자(주민)등록번호 
 * recipientCorpName 소지인법인명 
 * recipientNameRepresentative 소지인성명(대표자명) Y,N,P
 * recipientAddress 소지인주소 
 * recipientBankCode 소지인은행코드 
 * beforeMaturityPaymentPresentationDate 만기전지급제시희망일자 
 * applyReason 신청사유 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0210271000 kftEnt0210271000 = new KftEnt0210271000(); // 지급제시결과보고 응답
 * kftEnt0210271000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210271000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210271000.setBnkCd("057"); // 은행코드
 * kftEnt0210271000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210271000.setTransactionCode("271000"); // 거래구분코드
 * kftEnt0210271000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210271000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210271000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210271000.setStatus("000"); // STATUS
 * kftEnt0210271000.setResponseCode1(""); // 응답코드1
 * kftEnt0210271000.setResponseCode2(""); // 응답코드2
 * kftEnt0210271000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210271000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210271000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210271000.setENoteType(""); // 어음종류
 * kftEnt0210271000.setENoteIssueDate(""); // 전자어음발행일자
 * kftEnt0210271000.setENoteIssuePlace(""); // 전자어음발행지
 * kftEnt0210271000.setENoteAmount(0L); // 전자어음금액
 * kftEnt0210271000.setENoteMaturedDate(""); // 전자어음만기일자
 * kftEnt0210271000.setPaymentBankAndBranchCode(""); // 지급은행및지점코드
 * kftEnt0210271000.setSplitNumber(""); // 분할번호
 * kftEnt0210271000.setEndorsementNumber(""); // 배서번호
 * kftEnt0210271000.setIssuerIndvCorpSort(""); // 발행인-개인법인구분
 * kftEnt0210271000.setIssuerBusinessResidentRegistrationNumber(""); // 발행인-사업자(주민)등록번호
 * kftEnt0210271000.setIssuerCorpName(""); // 발행인-법인명
 * kftEnt0210271000.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEnt0210271000.setIssuerAddress(""); // 발행인-주소
 * kftEnt0210271000.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEnt0210271000.setRecipientCorpIndvSort(""); // 소지인법인개인구분
 * kftEnt0210271000.setRecipientBusinessResidentRegistrationNumber(""); // 소지인사업자(주민)등록번호
 * kftEnt0210271000.setRecipientCorpName(""); // 소지인법인명
 * kftEnt0210271000.setRecipientNameRepresentative(""); // 소지인성명(대표자명)
 * kftEnt0210271000.setRecipientAddress(""); // 소지인주소
 * kftEnt0210271000.setRecipientBankCode(""); // 소지인은행코드
 * kftEnt0210271000.setBeforeMaturityPaymentPresentationDate(""); // 만기전지급제시희망일자
 * kftEnt0210271000.setApplyReason(""); // 신청사유
 * kftEnt0210271000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0210271000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0210271000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "271000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String eNoteNumber; // 전자어음번호
	private String eNoteType; // 어음종류
	private String eNoteIssueDate; // 전자어음발행일자
	private String eNoteIssuePlace; // 전자어음발행지
	private long eNoteAmount; // 전자어음금액
	private String eNoteMaturedDate; // 전자어음만기일자
	private String paymentBankAndBranchCode; // 지급은행및지점코드
	private String splitNumber; // 분할번호
	private String endorsementNumber; // 배서번호
	private String issuerIndvCorpSort; // 발행인-개인법인구분
	private String issuerBusinessResidentRegistrationNumber; // 발행인-사업자(주민)등록번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String recipientCorpIndvSort; // 소지인법인개인구분
	private String recipientBusinessResidentRegistrationNumber; // 소지인사업자(주민)등록번호
	private String recipientCorpName; // 소지인법인명
	private String recipientNameRepresentative; // 소지인성명(대표자명)
	private String recipientAddress; // 소지인주소
	private String recipientBankCode; // 소지인은행코드
	private String beforeMaturityPaymentPresentationDate; // 만기전지급제시희망일자
	private String applyReason; // 신청사유
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementNumber$; // 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerIndvCorpSort$; // 발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBusinessResidentRegistrationNumber$; // 발행인-사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpIndvSort$; // 소지인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientBusinessResidentRegistrationNumber$; // 소지인사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpName$; // 소지인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientNameRepresentative$; // 소지인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientAddress$; // 소지인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientBankCode$; // 소지인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeMaturityPaymentPresentationDate$; // 만기전지급제시희망일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String applyReason$; // 신청사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteMaturedDate$)) { // 전자어음만기일자
			return 18;
		}
		if (VOUtils.isNotAlphanumericSpace(paymentBankAndBranchCode$)) { // 지급은행및지점코드
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerCurrentAccountNumber$)) { // 발행인-당좌계좌번호
			return 27;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 지급은행및지점코드
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // 배서번호
		issuerIndvCorpSort$ = VOUtils.write(out, issuerIndvCorpSort, 1); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber$ = VOUtils.write(out, issuerBusinessResidentRegistrationNumber, 13); // 발행인-사업자(주민)등록번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		recipientCorpIndvSort$ = VOUtils.write(out, recipientCorpIndvSort, 1); // 소지인법인개인구분
		recipientBusinessResidentRegistrationNumber$ = VOUtils.write(out, recipientBusinessResidentRegistrationNumber, 13); // 소지인사업자(주민)등록번호
		recipientCorpName$ = VOUtils.write(out, recipientCorpName, 40, "EUC-KR"); // 소지인법인명
		recipientNameRepresentative$ = VOUtils.write(out, recipientNameRepresentative, 20, "EUC-KR"); // 소지인성명(대표자명)
		recipientAddress$ = VOUtils.write(out, recipientAddress, 60, "EUC-KR"); // 소지인주소
		recipientBankCode$ = VOUtils.write(out, recipientBankCode, 3); // 소지인은행코드
		beforeMaturityPaymentPresentationDate$ = VOUtils.write(out, beforeMaturityPaymentPresentationDate, 8); // 만기전지급제시희망일자
		applyReason$ = VOUtils.write(out, applyReason, 1); // 신청사유
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 지급은행및지점코드
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // 배서번호
		issuerIndvCorpSort = VOUtils.toString(issuerIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber = VOUtils.toString(issuerBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 발행인-사업자(주민)등록번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		recipientCorpIndvSort = VOUtils.toString(recipientCorpIndvSort$ = VOUtils.read(in, 1)); // 소지인법인개인구분
		recipientBusinessResidentRegistrationNumber = VOUtils.toString(recipientBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 소지인사업자(주민)등록번호
		recipientCorpName = VOUtils.toString(recipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 소지인법인명
		recipientNameRepresentative = VOUtils.toString(recipientNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 소지인성명(대표자명)
		recipientAddress = VOUtils.toString(recipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 소지인주소
		recipientBankCode = VOUtils.toString(recipientBankCode$ = VOUtils.read(in, 3)); // 소지인은행코드
		beforeMaturityPaymentPresentationDate = VOUtils.toString(beforeMaturityPaymentPresentationDate$ = VOUtils.read(in, 8)); // 만기전지급제시희망일자
		applyReason = VOUtils.toString(applyReason$ = VOUtils.read(in, 1)); // 신청사유
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 지급은행및지점코드
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // 배서번호
		sb.append(", issuerIndvCorpSort=").append(issuerIndvCorpSort).append(System.lineSeparator()); // 발행인-개인법인구분
		sb.append(", issuerBusinessResidentRegistrationNumber=").append(issuerBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 발행인-사업자(주민)등록번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", recipientCorpIndvSort=").append(recipientCorpIndvSort).append(System.lineSeparator()); // 소지인법인개인구분
		sb.append(", recipientBusinessResidentRegistrationNumber=").append(recipientBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 소지인사업자(주민)등록번호
		sb.append(", recipientCorpName=").append(recipientCorpName).append(System.lineSeparator()); // 소지인법인명
		sb.append(", recipientNameRepresentative=").append(recipientNameRepresentative).append(System.lineSeparator()); // 소지인성명(대표자명)
		sb.append(", recipientAddress=").append(recipientAddress).append(System.lineSeparator()); // 소지인주소
		sb.append(", recipientBankCode=").append(recipientBankCode).append(System.lineSeparator()); // 소지인은행코드
		sb.append(", beforeMaturityPaymentPresentationDate=").append(beforeMaturityPaymentPresentationDate).append(System.lineSeparator()); // 만기전지급제시희망일자
		sb.append(", applyReason=").append(applyReason).append(System.lineSeparator()); // 신청사유
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "271000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recipientBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recipientNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "recipientBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beforeMaturityPaymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "applyReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
