package com.jpmc.kcg.web.hof.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletResponse;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.dao.ComBnkCdMDao;
import com.jpmc.kcg.com.dao.ComMltlnMMapper;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.dto.PageableRequestList;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.hof.dto.HbkTrL;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HbkTrLWebDao;
import com.jpmc.kcg.web.hof.dto.SelectHbkTrDetailSumDaoOut;
import com.jpmc.kcg.web.hof.dto.SelectListHbkTrDaoIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHbkTransactionIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHbkTransactionOut;
import com.jpmc.kcg.web.utils.JwtUtils;

import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;


@ExtendWith(MockitoExtension.class)
@Slf4j
class HbkTransactionListSvcTest { 

    @InjectMocks
    private HbkTransactionListSvc hbkTransactionService; // 테스트 대상 클래스

    @Mock
    private HbkTrLWebDao hbkTrLWebDao; // 의존성 DAO 클래스

    @Mock
    private JwtUtils jwtUtils;
    
	@Mock
	private ComBnkCdMDao comBnkCdMDao;
    
	@Mock
	private BizCom bizCom;
	
    @Mock
    private ComMltlnMMapper comMltlnMMapper;

    @Mock
    private ComPshMsgBean comPshMsgBean;

	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}

    @Test
    public void testGetListHbkTransaction_Success() {
        // Given
        GetListHbkTransactionIn input = new GetListHbkTransactionIn();
        input.setTrStrDt("2023-01-01");
        input.setTrEndDt("2023-12-31");
        input.setStartTlgPrcsTm("235959");
        input.setEndTlgPrcsTm("235959");
        input.setOpnBnkCd("001");
        input.setFundTpCd("01");
        input.setRcvAcctNo("1133333444");
        input.setWhdrwlAcctNbr("1133333444");
        input.setTrUnqNo("123456789");
        input.setRespCd("000");
        input.setHostNo("987654321");
        input.setHbkTlgTrceNo("HBK123");
        input.setRqerNm("test");
        input.setRcpntNm("setRcpntNm");
        input.setTotTrAmt(new BigDecimal("1000000"));
        input.setOutinDvsnCd("01");
        input.setSuspTractYn("Y");
        input.setTrStsCd("02");
        input.setHbkRespCd("0001");
        input.setHbkInitInstRespCd("000");
        
        SelectListHbkTrDaoIn daoIn = new SelectListHbkTrDaoIn();
        daoIn.setTrStrDt(input.getTrStrDt());
        daoIn.setTrEndDt(input.getTrEndDt());
        
        List<HbkTrL> listInfoOut = new ArrayList<HbkTrL>();
        
        HbkTrL listInfo = new HbkTrL();
        listInfo.setTrDt("20230901");
        listInfo.setOutinDvsnCd("01");
        listInfo.setHbkTlgKndDvsnCd("A1");
        listInfo.setHbkTlgTrDvsnCd("B2");
        listInfo.setTrUnqNo("123456789");
        listInfo.setHostNo("987654321");
        listInfo.setSndRcvDvsnCd("S");
        listInfo.setTrSts("COMPLETED");
        listInfo.setMsgSndDt("20230901");
        listInfo.setMsgSndTm("100000");
        listInfo.setHbkTlgTrceNo("c");
        listInfo.setTrcId("TRC001");
        listInfo.setFrstTrcId("TRC001");
        listInfo.setTrStsCd("ST001");
        listInfo.setHostCd("HOST01");
        listInfo.setTrmnlDvsnCd("T01");
        listInfo.setRespCd("00");
        listInfo.setHbkRespCd("01");
        listInfo.setRqstTm("101010");
        listInfo.setRespTm("101500");
        listInfo.setHndlBnkCd("002");
        listInfo.setHndlBrnchCd("B001");
        listInfo.setOpnBnkCd("003");
        listInfo.setOpnBnkBrnchCd("B002");
        listInfo.setWhdrwlAcctNo("1234567890");
        listInfo.setRcvAcctNo("0987654321");
        listInfo.setNoteExCd("NE01");
        listInfo.setTotTrAmt(new BigDecimal("1000000"));
        listInfo.setSndrRealNm("홍길동");
        listInfo.setRcpntNm("이순신");
        listInfo.setRcpntNm2("강감찬");
        listInfo.setRqerNm("김유신");
        listInfo.setRqerNm2("최무선");
        listInfo.setMediaTpCd("MT01");
        listInfo.setFundTpCd("FT01");
        listInfo.setSuspTrInfo("ST01");
        listInfo.setRqerInfo("RQ01");
        listInfo.setHbkRcvInqryUnqNo("HR001");
        listInfo.setHbkRespCd("00");
        listInfo.setHbkInitInstRespCd("IR01");
        listInfo.setHbkHndlInstPostCd("HP01");
        listInfo.setHbkInitInstPostCd("IP01");
        listInfo.setHbkTrSeqNo("SEQ001");
        listInfo.setHbkHoldNo("HLD001");
        listInfo.setHbkAcntgNo("AC001");
        listInfo.setHbkRqstTm("110000");
        listInfo.setHbkPymntTm("111500");
        listInfo.setHbkPymntTp("PT01");
        listInfo.setHbkPymntFailRsn("FAIL01");
        listInfo.setHbkHoldTm("120000");
        listInfo.setHbkHoldCnclTm("121500");
        listInfo.setHbkRoutYn("Y");
        listInfo.setOrgnTrSeqNo("ORG001");
        listInfo.setOrgnTrDt("20230831");
        listInfo.setOrgnTrUnqNo("ORG123");
        listInfo.setMakeId("USER01");
        listInfo.setMakeDttm("20230901101010");
        listInfo.setChkId("CHK001");
        listInfo.setChkDttm("20230901103030");
        
        listInfoOut.add(listInfo);
        
        ComRespCdM out = new ComRespCdM();
        out.setRespCdNm("test");

        // When: 목 객체로 DAO 메서드의 동작을 설정
        when(hbkTrLWebDao.selectListHbkTrCnt(any(SelectListHbkTrDaoIn.class))).thenReturn(10);
        when(hbkTrLWebDao.selectListHbkTr(any(PageableRequestList.class))).thenReturn(listInfoOut);
        when(bizCom.getRespCode(any(), any(), any())).thenReturn(out);

        // 메서드 실행
        GetListHbkTransactionOut result = hbkTransactionService.getListHbkTransaction(input);

        // Then: 결과 값 검증
        assertNotNull(result);
        assertEquals(10, result.getTotCnt());

        // DAO 메서드가 호출되었는지 확인
        verify(hbkTrLWebDao, times(1)).selectListHbkTrCnt(any(SelectListHbkTrDaoIn.class));
    }

    @Test
    public void testGetListHbkTransaction_MissingTrStrDt() {
        // Given
        GetListHbkTransactionIn input = new GetListHbkTransactionIn(); // 거래 시작일을 설정하지 않음

        // When
        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	 hbkTransactionService.getListHbkTransaction(input);
        });

        // Then: BusinessException 예외가 발생해야 함
        assertTrue("MCMNE01002".contains(exception.getErrorCode()));
    }
    
    
    @Test
    public void testGetListHbkTransaction_sendReversalTrAlarm() {
    	// Given
    	GetListHbkTransactionIn input = new GetListHbkTransactionIn(); // 거래 시작일을 설정하지 않음
    	
    	hbkTransactionService.sendReversalTrAlarm(input);
    }
    
    
    @Test
    public void testGetListHbkTransaction_downloadHbkTransactionExcelList() {
    	// Given
        GetListHbkTransactionIn input = new GetListHbkTransactionIn();
        input.setTrStrDt("2023-01-01");
        input.setTrEndDt("2023-12-31");
        input.setStartTlgPrcsTm("235959");
        input.setEndTlgPrcsTm("235959");
        input.setOpnBnkCd("001");
        input.setFundTpCd("01");
        input.setRcvAcctNo("1133333444");
        input.setWhdrwlAcctNbr("1133333444");
        input.setTrUnqNo("123456789");
        input.setRespCd("000");
        input.setHostNo("987654321");
        input.setHbkTlgTrceNo("HBK123");
        input.setRqerNm("test");
        input.setRcpntNm("setRcpntNm");
        input.setTotTrAmt(new BigDecimal("1000000"));
        input.setOutinDvsnCd("01");
        input.setSuspTractYn("Y");
        input.setTrStsCd("02");
        input.setHbkRespCd("0001");
        input.setHbkInitInstRespCd("000");
        
        SelectListHbkTrDaoIn daoIn = new SelectListHbkTrDaoIn();
        daoIn.setTrStrDt(input.getTrStrDt());
        daoIn.setTrEndDt(input.getTrEndDt());
        
        List<HbkTrL> listInfoOut = new ArrayList<HbkTrL>();
        
        HbkTrL listInfo = new HbkTrL();
        listInfo.setTrDt("20230901");
        listInfo.setOutinDvsnCd("01");
        listInfo.setHbkTlgKndDvsnCd("A1");
        listInfo.setHbkTlgTrDvsnCd("B2");
        listInfo.setTrUnqNo("123456789");
        listInfo.setHostNo("987654321");
        listInfo.setSndRcvDvsnCd("S");
        listInfo.setTrSts("COMPLETED");
        listInfo.setMsgSndDt("20230901");
        listInfo.setMsgSndTm("100000");
        listInfo.setHbkTlgTrceNo("c");
        listInfo.setTrcId("TRC001");
        listInfo.setFrstTrcId("TRC001");
        listInfo.setTrStsCd("ST001");
        listInfo.setHostCd("HOST01");
        listInfo.setTrmnlDvsnCd("T01");
        listInfo.setRespCd("00");
        listInfo.setHbkRespCd("01");
        listInfo.setRqstTm("101010");
        listInfo.setRespTm("101500");
        listInfo.setHndlBnkCd("002");
        listInfo.setHndlBrnchCd("B001");
        listInfo.setOpnBnkCd("003");
        listInfo.setOpnBnkBrnchCd("B002");
        listInfo.setWhdrwlAcctNo("1234567890");
        listInfo.setRcvAcctNo("0987654321");
        listInfo.setNoteExCd("NE01");
        listInfo.setTotTrAmt(new BigDecimal("1000000"));
        listInfo.setSndrRealNm("홍길동");
        listInfo.setRcpntNm("이순신");
        listInfo.setRcpntNm2("강감찬");
        listInfo.setRqerNm("김유신");
        listInfo.setRqerNm2("최무선");
        listInfo.setMediaTpCd("MT01");
        listInfo.setFundTpCd("FT01");
        listInfo.setSuspTrInfo("ST01");
        listInfo.setRqerInfo("RQ01");
        listInfo.setHbkRcvInqryUnqNo("HR001");
        listInfo.setHbkRespCd("00");
        listInfo.setHbkInitInstRespCd("IR01");
        listInfo.setHbkHndlInstPostCd("HP01");
        listInfo.setHbkInitInstPostCd("IP01");
        listInfo.setHbkTrSeqNo("SEQ001");
        listInfo.setHbkHoldNo("HLD001");
        listInfo.setHbkAcntgNo("AC001");
        listInfo.setHbkRqstTm("110000");
        listInfo.setHbkPymntTm("111500");
        listInfo.setHbkPymntTp("PT01");
        listInfo.setHbkPymntFailRsn("FAIL01");
        listInfo.setHbkHoldTm("120000");
        listInfo.setHbkHoldCnclTm("121500");
        listInfo.setHbkRoutYn("Y");
        listInfo.setOrgnTrSeqNo("ORG001");
        listInfo.setOrgnTrDt("20230831");
        listInfo.setOrgnTrUnqNo("ORG123");
        listInfo.setMakeId("USER01");
        listInfo.setMakeDttm("20230901101010");
        listInfo.setChkId("CHK001");
        listInfo.setChkDttm("20230901103030");
        
        listInfoOut.add(listInfo);
        
        SelectHbkTrDetailSumDaoOut sumOut = new SelectHbkTrDetailSumDaoOut();
        sumOut.setInDepositErrorAmt(new BigDecimal("1000000"));
        sumOut.setInDepositErrorCnt(10);
        sumOut.setInDepositNormalAmt(new BigDecimal("1000000"));
        sumOut.setInDepositNormalCnt(10);
        sumOut.setInDepositProcessAmt(new BigDecimal("1000000"));
        sumOut.setInDepositProcessCnt(10);
        sumOut.setInDepositTotAmt(new BigDecimal("1000000"));
        sumOut.setInDepositTotCnt(10);
        sumOut.setOutDepositErrorAmt(new BigDecimal("1000000"));
        sumOut.setOutDepositErrorCnt(10);
        sumOut.setOutDepositNormalAmt(new BigDecimal("1000000"));
        sumOut.setOutDepositNormalCnt(10);
        sumOut.setOutDepositProcessAmt(new BigDecimal("1000000"));
        sumOut.setOutDepositProcessCnt(10);
        sumOut.setOutDepositTotAmt(new BigDecimal("1000000"));
        sumOut.setOutDepositTotCnt(10);
        
        sumOut.setInReversalErrorAmt(new BigDecimal("1000000"));
        sumOut.setInReversalErrorCnt(10);
        sumOut.setInReversalNormalAmt(new BigDecimal("1000000"));
        sumOut.setInReversalNormalCnt(10);
        sumOut.setInReversalProcessAmt(new BigDecimal("1000000"));
        sumOut.setInReversalProcessCnt(10);
        sumOut.setInReversalTotAmt(new BigDecimal("1000000"));
        sumOut.setInReversalTotCnt(10);
        sumOut.setOutReversalErrorAmt(new BigDecimal("1000000"));
        sumOut.setOutReversalErrorCnt(10);
        sumOut.setOutReversalNormalAmt(new BigDecimal("1000000"));
        sumOut.setOutReversalNormalCnt(10);
        sumOut.setOutReversalProcessAmt(new BigDecimal("1000000"));
        sumOut.setOutReversalProcessCnt(10);
        sumOut.setOutReversalTotAmt(new BigDecimal("1000000"));
        sumOut.setOutReversalTotCnt(10);

        ComRespCdM out = new ComRespCdM();
        out.setRespCdNm("test");

        // When: 목 객체로 DAO 메서드의 동작을 설정
        when(hbkTrLWebDao.selectListHbkTrCnt(any(SelectListHbkTrDaoIn.class))).thenReturn(1);
        when(hbkTrLWebDao.selectListHbkTr(any(PageableRequestList.class))).thenReturn(listInfoOut);
        when( hbkTrLWebDao.selectHbkTransactionDetailSum(any())).thenReturn(sumOut);
        when(bizCom.getRespCode(any(), any(), any())).thenReturn(out);

        MockHttpServletResponse response = new MockHttpServletResponse();
        
        // 메서드 실행
    	hbkTransactionService.downloadHbkTransactionExcelList(input, response);
    }
    

  
}
