package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 입금지시(당일)
 * <pre>{@code
 * msgType 전문유형 전문유형
 * systemSendReceiveTime 시스템송수신시간 시스템송수신시간
 * msgNo 메시지번호(Key) 메시지번호(Key)
 * messageType 전문구분코드 해당전문의 거래별 MESSAGE 구분코드
 * institutionCode 이용기관코드 이용기관코드
 * fileName 파일명 파일명
 * fileSerialNumber 파일일련번호 파일일련번호
 * processDate 처리일자 처리일자
 * accountNumber 계좌번호 계좌번호
 * requestedAmount 의뢰금액 의뢰금액
 * processedAmount 처리금액 실처리금액
 * responseCode 응답코드 처리결과
 * feeAmount 수수료 수수료
 * requestedCount 의뢰건수 총의뢰건수
 * processedCount 처리건수 총실처리건수
 * fundType 자금종류 자금종류
 * passbookEntryDetails 통장기재내용 통장기재내용
 * withdrawalType 출금형태 "0": 부분출금가능(300원 이상 부분출금, 300월 미만 센터불능처리) / "1": ONLY 전액출금 / 그 외  "2, 3, 4, 5, 6" 등
 * filler1 FILLER FILLER
 * 
 * LvbCmsEC23 lvbCmsEC23 = new LvbCmsEC23(); // 입금지시(당일)
 * lvbCmsEC23.setMsgType("KCGLVB"); // 전문유형
 * lvbCmsEC23.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * lvbCmsEC23.setMsgNo("00000000"); // 메시지번호(Key)
 * lvbCmsEC23.setMessageType("EC23"); // 전문구분코드
 * lvbCmsEC23.setInstitutionCode(""); // 이용기관코드
 * lvbCmsEC23.setFileName(""); // 파일명
 * lvbCmsEC23.setFileSerialNumber(""); // 파일일련번호
 * lvbCmsEC23.setProcessDate(""); // 처리일자
 * lvbCmsEC23.setAccountNumber("0000000000000000"); // 계좌번호
 * lvbCmsEC23.setRequestedAmount(0L); // 의뢰금액
 * lvbCmsEC23.setProcessedAmount(0L); // 처리금액
 * lvbCmsEC23.setResponseCode("0000"); // 응답코드
 * lvbCmsEC23.setFeeAmount(0L); // 수수료
 * lvbCmsEC23.setRequestedCount(1); // 의뢰건수
 * lvbCmsEC23.setProcessedCount(0); // 처리건수
 * lvbCmsEC23.setFundType(""); // 자금종류
 * lvbCmsEC23.setPassbookEntryDetails(""); // 통장기재내용
 * lvbCmsEC23.setWithdrawalType(""); // 출금형태
 * lvbCmsEC23.setFiller1(""); // FILLER
 * }</pre>
 */
@Data
public class LvbCmsEC23 implements LvbCmsComHdr, Vo {

	private String msgType = "KCGLVB"; // 전문유형
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "EC23"; // 전문구분코드
	private String institutionCode; // 이용기관코드
	private String fileName; // 파일명
	private String fileSerialNumber; // 파일일련번호
	private String processDate; // 처리일자
	private String accountNumber = "0000000000000000"; // 계좌번호
	private long requestedAmount; // 의뢰금액
	private long processedAmount; // 처리금액
	private String responseCode = "0000"; // 응답코드
	private long feeAmount; // 수수료
	private int requestedCount; // 의뢰건수
	private int processedCount; // 처리건수
	private String fundType; // 자금종류
	private String passbookEntryDetails; // 통장기재내용
	private String withdrawalType; // 출금형태
	private String filler1; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 전문유형
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 이용기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 파일명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileSerialNumber$; // 파일일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processDate$; // 처리일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountNumber$; // 계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedAmount$; // 의뢰금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processedAmount$; // 처리금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String feeAmount$; // 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedCount$; // 의뢰건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processedCount$; // 처리건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String passbookEntryDetails$; // 통장기재내용
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalType$; // 출금형태
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(institutionCode$)) { // 이용기관코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(fileName$)) { // 파일명
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(processDate$)) { // 처리일자
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(fundType$)) { // 자금종류
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(withdrawalType$)) { // 출금형태
			return 17;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 전문유형
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 이용기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // 파일명
		fileSerialNumber$ = VOUtils.write(out, fileSerialNumber, 8); // 파일일련번호
		processDate$ = VOUtils.write(out, processDate, 6); // 처리일자
		accountNumber$ = VOUtils.write(out, accountNumber, 16); // 계좌번호
		requestedAmount$ = VOUtils.write(out, requestedAmount, 13); // 의뢰금액
		processedAmount$ = VOUtils.write(out, processedAmount, 13); // 처리금액
		responseCode$ = VOUtils.write(out, responseCode, 4); // 응답코드
		feeAmount$ = VOUtils.write(out, feeAmount, 11); // 수수료
		requestedCount$ = VOUtils.write(out, requestedCount, 8); // 의뢰건수
		processedCount$ = VOUtils.write(out, processedCount, 8); // 처리건수
		fundType$ = VOUtils.write(out, fundType, 2); // 자금종류
		passbookEntryDetails$ = VOUtils.write(out, passbookEntryDetails, 16, "EUC-KR"); // 통장기재내용
		withdrawalType$ = VOUtils.write(out, withdrawalType, 1); // 출금형태
		filler1$ = VOUtils.write(out, filler1, 44); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 전문유형
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 이용기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // 파일명
		fileSerialNumber = VOUtils.toString(fileSerialNumber$ = VOUtils.read(in, 8)); // 파일일련번호
		processDate = VOUtils.toString(processDate$ = VOUtils.read(in, 6)); // 처리일자
		accountNumber = VOUtils.toString(accountNumber$ = VOUtils.read(in, 16)); // 계좌번호
		requestedAmount = VOUtils.toLong(requestedAmount$ = VOUtils.read(in, 13)); // 의뢰금액
		processedAmount = VOUtils.toLong(processedAmount$ = VOUtils.read(in, 13)); // 처리금액
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 4)); // 응답코드
		feeAmount = VOUtils.toLong(feeAmount$ = VOUtils.read(in, 11)); // 수수료
		requestedCount = VOUtils.toInt(requestedCount$ = VOUtils.read(in, 8)); // 의뢰건수
		processedCount = VOUtils.toInt(processedCount$ = VOUtils.read(in, 8)); // 처리건수
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금종류
		passbookEntryDetails = VOUtils.toString(passbookEntryDetails$ = VOUtils.read(in, 16, "EUC-KR")); // 통장기재내용
		withdrawalType = VOUtils.toString(withdrawalType$ = VOUtils.read(in, 1)); // 출금형태
		filler1 = VOUtils.toString(filler1$ = VOUtils.read(in, 44)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 전문유형
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 이용기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 파일명
		sb.append(", fileSerialNumber=").append(fileSerialNumber).append(System.lineSeparator()); // 파일일련번호
		sb.append(", processDate=").append(processDate).append(System.lineSeparator()); // 처리일자
		sb.append(", accountNumber=").append(accountNumber).append(System.lineSeparator()); // 계좌번호
		sb.append(", requestedAmount=").append(requestedAmount).append(System.lineSeparator()); // 의뢰금액
		sb.append(", processedAmount=").append(processedAmount).append(System.lineSeparator()); // 처리금액
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", feeAmount=").append(feeAmount).append(System.lineSeparator()); // 수수료
		sb.append(", requestedCount=").append(requestedCount).append(System.lineSeparator()); // 의뢰건수
		sb.append(", processedCount=").append(processedCount).append(System.lineSeparator()); // 처리건수
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금종류
		sb.append(", passbookEntryDetails=").append(passbookEntryDetails).append(System.lineSeparator()); // 통장기재내용
		sb.append(", withdrawalType=").append(withdrawalType).append(System.lineSeparator()); // 출금형태
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "KCGLVB"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "EC23"),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "fileSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "processDate", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "accountNumber", "fldLen", "16", "defltVal", "0000000000000000"),
			Map.of("fld", "requestedAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "processedAmount", "fldLen", "13", "defltVal", "0"),
			Map.of("fld", "responseCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "feeAmount", "fldLen", "11", "defltVal", "0"),
			Map.of("fld", "requestedCount", "fldLen", "8", "defltVal", "1"),
			Map.of("fld", "processedCount", "fldLen", "8", "defltVal", "0"),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "passbookEntryDetails", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "withdrawalType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler1", "fldLen", "44", "defltVal", "")
		);
	}

}
