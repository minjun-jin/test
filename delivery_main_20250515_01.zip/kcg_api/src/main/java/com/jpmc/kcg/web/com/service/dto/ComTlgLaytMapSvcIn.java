package com.jpmc.kcg.web.com.service.dto;

import java.util.List;

import com.jpmc.kcg.com.dto.ComTlgLaytMapD;

import com.jpmc.kcg.web.com.dto.CmnTlgLaytMapD;
import lombok.Data;

@Data
public class ComTlgLaytMapSvcIn {
    private String tlgLaytId;   // 전문레이아웃ID

    private String tlgLaytMapId;
    private String trgtTlgLaytId;
    private String sorcTlgLaytId;

    private List<ComTlgLaytMapD> tlgLaytMapDList;
    private List<CmnTlgLaytMapD> cmnTlgLaytMapDList;
}
