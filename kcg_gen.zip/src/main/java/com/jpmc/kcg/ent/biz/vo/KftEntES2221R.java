package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 사고신고 등록 처리내역
 * <pre>{@code
 * KftEntES2221R kftEntES2221R  = new KftEntES2221R(); // 사고신고 등록 처리내역
 * kftEntES2221R.setFileName(""); // 업무구분
 * kftEntES2221R.setDataType(""); // 데이터구분
 * kftEntES2221R.setSerialNumber(""); // 일련번호
 * kftEntES2221R.setBankCode(""); // 은행코드
 * kftEntES2221R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES2221R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES2221R.setAccidentReportEnoteNumber(""); // 사고신고-전자어음번호
 * kftEntES2221R.setAccidentReportSplitNumber(""); // 사고신고-분할번호
 * kftEntES2221R.setAccidentReportStatus(""); // 사고신고여부
 * kftEntES2221R.setProcessingResult(""); // 처리결과
 * kftEntES2221R.setAccidentReportReceptionCancellationDeletionDateTime(""); // 사고신고 (접수/취소/삭제) 일시
 * kftEntES2221R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES2221R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String bankCode; // 은행코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String accidentReportEnoteNumber; // 사고신고-전자어음번호
	private String accidentReportSplitNumber; // 사고신고-분할번호
	private String accidentReportStatus; // 사고신고여부
	private String processingResult; // 처리결과
	private String accidentReportReceptionCancellationDeletionDateTime; // 사고신고 (접수/취소/삭제) 일시
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportEnoteNumber$; // 사고신고-전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportSplitNumber$; // 사고신고-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportStatus$; // 사고신고여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingResult$; // 처리결과
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportReceptionCancellationDeletionDateTime$; // 사고신고 (접수/취소/삭제) 일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		accidentReportEnoteNumber$ = VOUtils.write(out, accidentReportEnoteNumber, 20); // 사고신고-전자어음번호
		accidentReportSplitNumber$ = VOUtils.write(out, accidentReportSplitNumber, 2); // 사고신고-분할번호
		accidentReportStatus$ = VOUtils.write(out, accidentReportStatus, 1); // 사고신고여부
		processingResult$ = VOUtils.write(out, processingResult, 3); // 처리결과
		accidentReportReceptionCancellationDeletionDateTime$ = VOUtils.write(out, accidentReportReceptionCancellationDeletionDateTime, 14); // 사고신고 (접수/취소/삭제) 일시
		filler2$ = VOUtils.write(out, filler2, 8); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		accidentReportEnoteNumber = VOUtils.toString(accidentReportEnoteNumber$ = VOUtils.read(in, 20)); // 사고신고-전자어음번호
		accidentReportSplitNumber = VOUtils.toString(accidentReportSplitNumber$ = VOUtils.read(in, 2)); // 사고신고-분할번호
		accidentReportStatus = VOUtils.toString(accidentReportStatus$ = VOUtils.read(in, 1)); // 사고신고여부
		processingResult = VOUtils.toString(processingResult$ = VOUtils.read(in, 3)); // 처리결과
		accidentReportReceptionCancellationDeletionDateTime = VOUtils.toString(accidentReportReceptionCancellationDeletionDateTime$ = VOUtils.read(in, 14)); // 사고신고 (접수/취소/삭제) 일시
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 8)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", accidentReportEnoteNumber=").append(accidentReportEnoteNumber).append(System.lineSeparator()); // 사고신고-전자어음번호
		sb.append(", accidentReportSplitNumber=").append(accidentReportSplitNumber).append(System.lineSeparator()); // 사고신고-분할번호
		sb.append(", accidentReportStatus=").append(accidentReportStatus).append(System.lineSeparator()); // 사고신고여부
		sb.append(", processingResult=").append(processingResult).append(System.lineSeparator()); // 처리결과
		sb.append(", accidentReportReceptionCancellationDeletionDateTime=").append(accidentReportReceptionCancellationDeletionDateTime).append(System.lineSeparator()); // 사고신고 (접수/취소/삭제) 일시
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accidentReportEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "accidentReportSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "processingResult", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "accidentReportReceptionCancellationDeletionDateTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "8", "defltVal", "")
		);
	}

}
