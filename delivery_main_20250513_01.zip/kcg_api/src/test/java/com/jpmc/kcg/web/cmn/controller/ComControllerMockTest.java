package com.jpmc.kcg.web.cmn.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.quartz.SchedulerException;
import org.springframework.mock.web.MockHttpServletResponse;

import com.jpmc.kcg.com.dto.ComTlgLaytMapM;
import com.jpmc.kcg.web.com.controller.ComController;
import com.jpmc.kcg.web.com.dto.CodeIn;
import com.jpmc.kcg.web.com.dto.ComLogFile;
import com.jpmc.kcg.web.com.service.AccountInformationSvc;
import com.jpmc.kcg.web.com.service.BankBranchCodeSvc;
import com.jpmc.kcg.web.com.service.BankCodeSvc;
import com.jpmc.kcg.web.com.service.BizDashboardSvc;
//import com.jpmc.kcg.web.com.service.CmnBnkStsMSvc;
import com.jpmc.kcg.web.com.service.CmnBtchWrkSvc;
import com.jpmc.kcg.web.com.service.CmnCodeSvc;
import com.jpmc.kcg.web.com.service.CmnFileSvc;
import com.jpmc.kcg.web.com.service.CmnFvrtsSvc;
import com.jpmc.kcg.web.com.service.CmnLoginSvc;
import com.jpmc.kcg.web.com.service.CmnMenuSvc;
import com.jpmc.kcg.web.com.service.CmnMltlnSvc;
import com.jpmc.kcg.web.com.service.CmnMsgSvc;
import com.jpmc.kcg.web.com.service.CmnRoleSvc;
import com.jpmc.kcg.web.com.service.CmnTgmSvc;
import com.jpmc.kcg.web.com.service.CmnUserSvc;
import com.jpmc.kcg.web.com.service.CmnWebSvcSvc;
import com.jpmc.kcg.web.com.service.ComBatDlySchdSvc;
import com.jpmc.kcg.web.com.service.ComFileTractLSvc;
import com.jpmc.kcg.web.com.service.ComHoldTransactionManagementSvc;
import com.jpmc.kcg.web.com.service.ComLogFileSvc;
import com.jpmc.kcg.web.com.service.ComPshMsgHistSvc;
import com.jpmc.kcg.web.com.service.ComPshMsgSvc;
import com.jpmc.kcg.web.com.service.ComRcvdUserGroupMSvc;
import com.jpmc.kcg.web.com.service.ComSndRcvFileInqrySvc;
import com.jpmc.kcg.web.com.service.ComTlgLaytMapSvc;
import com.jpmc.kcg.web.com.service.ComUserActHistSvc;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.HolidayInformationSvc;
import com.jpmc.kcg.web.com.service.IntegratedSummarySvc;
import com.jpmc.kcg.web.com.service.NetworkManagementSvc;
import com.jpmc.kcg.web.com.service.NetworkStateManagementSvc;
import com.jpmc.kcg.web.com.service.ResponseCodeMappingSvc;
import com.jpmc.kcg.web.com.service.ResponseCodeSvc;
import com.jpmc.kcg.web.com.service.SendReceiveFileInformationSvc;
import com.jpmc.kcg.web.com.service.dto.BizDashboardSvcIn;
import com.jpmc.kcg.web.com.service.dto.BizDashboardSvcOut;
//import com.jpmc.kcg.web.com.service.dto.CmnBnkStsMInDto;
//import com.jpmc.kcg.web.com.service.dto.CmnBnkStsMOutDto;
import com.jpmc.kcg.web.com.service.dto.CmnBtchWrkSvcRedoBtchIn;
import com.jpmc.kcg.web.com.service.dto.CmnBtchWrkSvcWrkIn;
import com.jpmc.kcg.web.com.service.dto.CmnBtchWrkSvcWrkOut;
import com.jpmc.kcg.web.com.service.dto.CmnBtchWrkSvcWrkRsltIn;
import com.jpmc.kcg.web.com.service.dto.CmnBtchWrkSvcWrkRsltOut;
import com.jpmc.kcg.web.com.service.dto.CmnCodeSvcCodeInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnCodeSvcCodeInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnFileSvcFileInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnFileSvcFileInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnFvrtsSvcFvrtsInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnFvrtsSvcFvrtsInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnLoginSvcLoginInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnLoginSvcLoginInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnLoginSvcLogoutOut;
import com.jpmc.kcg.web.com.service.dto.CmnMenuSvcLnbMenuInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnMenuSvcLnbMenuInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnMenuSvcMenuInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnMenuSvcMenuInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnMltlnSvcMltlnInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnMltlnSvcMltlnInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnMsgSvcMsgInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnMsgSvcMsgInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnRoleSvcRoleInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnRoleSvcRoleInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnRoleSvcRoleMenuInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnRoleSvcRoleMenuInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnTgmSvcTgmInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnTgmSvcTgmInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnUserSvcUserInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnUserSvcUserInfoOut;
import com.jpmc.kcg.web.com.service.dto.CmnWebSvcSvcInfoIn;
import com.jpmc.kcg.web.com.service.dto.CmnWebSvcSvcInfoOut;
import com.jpmc.kcg.web.com.service.dto.CodeLabelListOut;
import com.jpmc.kcg.web.com.service.dto.ComAcctInfoIn;
import com.jpmc.kcg.web.com.service.dto.ComAcctListOut;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import com.jpmc.kcg.web.com.service.dto.ComAprvHListOut;
import com.jpmc.kcg.web.com.service.dto.ComBatDlySchdSvcIn;
import com.jpmc.kcg.web.com.service.dto.ComBatDlySchdSvcOut;
import com.jpmc.kcg.web.com.service.dto.ComBnkBrnchCdIn;
import com.jpmc.kcg.web.com.service.dto.ComBnkBrnchCdListOut;
import com.jpmc.kcg.web.com.service.dto.ComBnkCdIn;
import com.jpmc.kcg.web.com.service.dto.ComBnkCdListOut;
import com.jpmc.kcg.web.com.service.dto.ComDateMInDto;
import com.jpmc.kcg.web.com.service.dto.ComDateMOutDto;
import com.jpmc.kcg.web.com.service.dto.ComFileNoListIn;
import com.jpmc.kcg.web.com.service.dto.ComFileTractLSvcIn;
import com.jpmc.kcg.web.com.service.dto.ComIntegratedSummaryIn;
import com.jpmc.kcg.web.com.service.dto.ComPshMsgHistSvcInfoIn;
import com.jpmc.kcg.web.com.service.dto.ComPshMsgHistSvcInfoOut;
import com.jpmc.kcg.web.com.service.dto.ComPshMsgSvcInfoIn;
import com.jpmc.kcg.web.com.service.dto.ComPshMsgSvcInfoOut;
import com.jpmc.kcg.web.com.service.dto.ComRcvdUserGroupMSvcIn;
import com.jpmc.kcg.web.com.service.dto.ComRespCdIn;
import com.jpmc.kcg.web.com.service.dto.ComRespCdListOut;
import com.jpmc.kcg.web.com.service.dto.ComRespCdMapIn;
import com.jpmc.kcg.web.com.service.dto.ComRespCdMapListOut;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapSvcIn;
import com.jpmc.kcg.web.com.service.dto.ComTlgLaytMapSvcOut;
import com.jpmc.kcg.web.com.service.dto.HoldTransactionManagementSvcIn;
import com.jpmc.kcg.web.com.service.dto.IntegratedSummaryHeaderIn;
import com.jpmc.kcg.web.com.service.dto.IntegratedSummaryHeaderOut;
import com.jpmc.kcg.web.com.service.dto.IntegratedSummaryIn;
import com.jpmc.kcg.web.com.service.dto.IntegratedSummaryOut;
import com.jpmc.kcg.web.com.service.dto.NetworkManagementSvcIn;
import com.jpmc.kcg.web.com.service.dto.NetworkManagementSvcOut;
import com.jpmc.kcg.web.com.service.dto.NetworkStateManagementSvcIn;
import com.jpmc.kcg.web.com.service.dto.NetworkStateManagementSvcOut;
import com.jpmc.kcg.web.com.service.dto.SendReceiveFileInformationIn;
import com.jpmc.kcg.web.com.service.dto.SendReceiveFileInformationOut;
import com.jpmc.kcg.web.com.service.dto.SndRcvFileDtlListIn;
import com.jpmc.kcg.web.com.service.dto.SndRcvFileListIn;
import com.jpmc.kcg.web.com.service.dto.StaffActInfoSvcActInfoIn;
import com.jpmc.kcg.web.com.service.dto.StaffActInfoSvcActInfoOut;
import com.jpmc.kcg.web.ida.CustomMonetaUser;
import com.jpmc.kcg.web.msg.SymphonyTestSvc;
import com.jpmc.kcg.web.msg.SymphonyTestSvcDto;
import com.jpmorgan.stk.validation.exceptions.InvalidRegularExpression;
import com.jpmorgan.stk.validation.exceptions.SafePathCheckException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * {@link com.jpmc.kcg.web.com.controller.ComController}
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
public class ComControllerMockTest {
	@InjectMocks ComController comController;
	@Mock CmnMenuSvc cmnMenuSvc;
	@Mock CmnWebSvcSvc cmnArtfcSvc;
	@Mock CmnCodeSvc cmnCodeSvc;
	@Mock CmnMltlnSvc cmnMltlnSvc;
	@Mock CmnMsgSvc cmnMsgSvc;
	@Mock CmnLoginSvc cmnLoginSvc;
	@Mock CmnTgmSvc cmnTgmSvc;
	@Mock CmnFileSvc cmnFileSvc;
	@Mock CmnBtchWrkSvc cmnBtchWrkSvc;
    @Mock ComBatDlySchdSvc comBatDlySchdSvc;
//	@Mock CmnBnkStsMSvc cmnBnkStsMSvc;
	@Mock CmnRoleSvc cmnRoleSvc;
	@Mock CmnUserSvc cmnUserSvc;
	@Mock CmnFvrtsSvc cmnFvrtsSvc;
	@Mock HolidayInformationSvc holidayInformationSvc;
	@Mock BankCodeSvc bankCodeSvc;
	@Mock BankBranchCodeSvc bankBranchCodeSvc;
	@Mock NetworkManagementSvc networkManagementSvc;
	@Mock NetworkStateManagementSvc networkStateManagementSvc;
	@Mock SendReceiveFileInformationSvc sendReceiveFileInformationSvc;
	@Mock ResponseCodeSvc responseCodeSvc;
	@Mock ResponseCodeMappingSvc responseCodeMappingSvc;
	@Mock AccountInformationSvc accountInformationSvc;
	@Mock CommonApprovalSvc commonApprovalSvc;
	@Mock ComUserActHistSvc comStaffActInfoSvc;
	@Mock ComPshMsgSvc comPshMsgSvc;
	@Mock ComTlgLaytMapSvc comTlgLaytMapSvc;
	@Mock IntegratedSummarySvc integratedSummarySvc;
	@Mock ComPshMsgHistSvc comPshMsgHistSvc;
    @Mock HttpServletResponse response;
    @Mock HttpServletRequest request;
    @Mock private BizDashboardSvc bizDashboardSvc;
    @Mock SymphonyTestSvc symphonyTestSvc;
    @Mock ComSndRcvFileInqrySvc comSndRcvFileInqrySvc;
    @Mock ComFileTractLSvc comFileTractLSvc;
    @Mock ComHoldTransactionManagementSvc holdTransactionManagementSvc;
    @Mock ComRcvdUserGroupMSvc comRcvdUserGroupMSvc;
    @Mock ComLogFileSvc comLogFileSvc;

    
    @Test
	void login() {
    	CmnLoginSvcLoginInfoIn in = new CmnLoginSvcLoginInfoIn();
    	
		CmnLoginSvcLoginInfoOut cmnLoginSvcLoginInfoOut = comController.login(in, request, response);		
	}

	@Test
	void logout() {
		CmnLoginSvcLogoutOut CmnLoginSvcLogoutOut = comController.logout(request, response);	
	}

	@Test
	void getLnbMenuList() {
		CmnMenuSvcLnbMenuInfoIn in = new CmnMenuSvcLnbMenuInfoIn();
		
		CmnMenuSvcLnbMenuInfoOut CmnMenuSvcLnbMenuInfoOut = comController.getLnbMenuList(in);
	}

	@Test
	void getMenuList() {
		CmnMenuSvcMenuInfoIn in = new CmnMenuSvcMenuInfoIn();
		
		CmnMenuSvcMenuInfoOut CmnMenuSvcMenuInfoOut = comController.getMenuList(in);
	}

	@Test
	void registerMenuM() {
		CmnMenuSvcMenuInfoIn in = new CmnMenuSvcMenuInfoIn();
		
		CmnMenuSvcMenuInfoOut CmnMenuSvcMenuInfoOut = comController.registerMenuM(in);
	}

	@Test
	void modifyMenuM() {
		CmnMenuSvcMenuInfoIn in = new CmnMenuSvcMenuInfoIn();
		
		CmnMenuSvcMenuInfoOut CmnMenuSvcMenuInfoOut = comController.modifyMenuM(in);
	}

	@Test
	void modifyMenuOrder() {
		CmnMenuSvcMenuInfoIn in = new CmnMenuSvcMenuInfoIn();
		
		CmnMenuSvcMenuInfoOut CmnMenuSvcMenuInfoOut = comController.modifyMenuOrder(in);
	}

	@Test
	void removeMenuM() {
		CmnMenuSvcMenuInfoIn in = new CmnMenuSvcMenuInfoIn();
		
		CmnMenuSvcMenuInfoOut CmnMenuSvcMenuInfoOut = comController.removeMenuM(in);
	}

	@Test
	void getRoleList() {
		CmnRoleSvcRoleInfoIn in = new CmnRoleSvcRoleInfoIn();
		
		CmnRoleSvcRoleInfoOut CmnRoleSvcRoleInfoOut = comController.getRoleList(in);
	}

	@Test
	void registerRole() {
		CmnRoleSvcRoleInfoIn in = new CmnRoleSvcRoleInfoIn();
		
		CmnRoleSvcRoleInfoOut CmnRoleSvcRoleInfoOut = comController.registerRole(in);
	}

	@Test
	void modifyRole() {
		CmnRoleSvcRoleInfoIn in = new CmnRoleSvcRoleInfoIn();
		
		CmnRoleSvcRoleInfoOut CmnRoleSvcRoleInfoOut = comController.modifyRole(in);
	}

	@Test
	void removeRole() {
		CmnRoleSvcRoleInfoIn in = new CmnRoleSvcRoleInfoIn();
		
		CmnRoleSvcRoleInfoOut CmnRoleSvcRoleInfoOut = comController.removeRole(in);
	}

	@Test
	void getRoleMenuList() {
		CmnRoleSvcRoleMenuInfoIn in = new CmnRoleSvcRoleMenuInfoIn();
		
		CmnRoleSvcRoleMenuInfoOut CmnRoleSvcRoleMenuInfoOut = comController.getRoleMenuList(in);
	}

	@Test
	void saveRoleMenu() {
		CmnRoleSvcRoleMenuInfoIn in = new CmnRoleSvcRoleMenuInfoIn();
		
		CmnRoleSvcRoleMenuInfoOut CmnRoleSvcRoleMenuInfoOut = comController.saveRoleMenu(in);
	}

	@Test
	void getUserList() {
		CmnUserSvcUserInfoIn in = new CmnUserSvcUserInfoIn();
		
		CmnUserSvcUserInfoOut CmnUserSvcUserInfoOut = comController.getUserList(in);
	}

	@Test
	void registerUser() {
		CmnUserSvcUserInfoIn in = new CmnUserSvcUserInfoIn();
		
		CmnUserSvcUserInfoOut CmnUserSvcUserInfoOut = comController.registerUser(in);
	}

	@Test
	void modifyUser() {
		CmnUserSvcUserInfoIn in = new CmnUserSvcUserInfoIn();
		
		CmnUserSvcUserInfoOut CmnUserSvcUserInfoOut = comController.modifyUser(in);
	}

	@Test
	void getFvrtsMenuList() {
		CmnFvrtsSvcFvrtsInfoIn in = new CmnFvrtsSvcFvrtsInfoIn();
		
		CmnFvrtsSvcFvrtsInfoOut CmnFvrtsSvcFvrtsInfoOut = comController.getFvrtsMenuList(in);
	}

	@Test
	void removeFvrtsMenu() {
		CmnFvrtsSvcFvrtsInfoIn in = new CmnFvrtsSvcFvrtsInfoIn();
		
		CmnFvrtsSvcFvrtsInfoOut CmnFvrtsSvcFvrtsInfoOut = comController.removeFvrtsMenu(in);
	}

	@Test
	void registerFvrtsMenu() {
		CmnFvrtsSvcFvrtsInfoIn in = new CmnFvrtsSvcFvrtsInfoIn();
		
		CmnFvrtsSvcFvrtsInfoOut CmnFvrtsSvcFvrtsInfoOut = comController.registerFvrtsMenu(in);
	}

	@Test
	void saveFvrtsMenu() {
		CmnFvrtsSvcFvrtsInfoIn in = new CmnFvrtsSvcFvrtsInfoIn();
		
		CmnFvrtsSvcFvrtsInfoOut CmnFvrtsSvcFvrtsInfoOut = comController.saveFvrtsMenu(in);
	}

	@Test
	void getSvcList() {
		CmnWebSvcSvcInfoIn in = new CmnWebSvcSvcInfoIn();
		
		CmnWebSvcSvcInfoOut CmnWebSvcSvcInfoOut = comController.getSvcList(in);
	}

	@Test
	void registerSvc() {
		CmnWebSvcSvcInfoIn in = new CmnWebSvcSvcInfoIn();
		
		CmnWebSvcSvcInfoOut CmnWebSvcSvcInfoOut = comController.registerSvc(in);
	}

	@Test
	void modifySvc() {
		CmnWebSvcSvcInfoIn in = new CmnWebSvcSvcInfoIn();
		
		CmnWebSvcSvcInfoOut CmnWebSvcSvcInfoOut = comController.modifySvc(in);
	}

	@Test
	void getCmnCdMList() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.getCmnCdMList(in);
	}

	@Test
	void getCmnCdDtlList() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.getCmnCdDtlList(in);
	}

	@Test
	void getCmnCdDListBySort() {
		CodeIn in = new CodeIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.getCmnCdDListBySort(in);
		
	}

	@Test
	void registerCdM() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.registerCdM(in);
	}

	@Test
	void modifyCdM() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.modifyCdM(in);
	}

	@Test
	void getCmnCdDList() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.getCmnCdDList(in);
	}

	@Test
	void saveCdD() {
		CmnCodeSvcCodeInfoIn in = new CmnCodeSvcCodeInfoIn();
		
		CmnCodeSvcCodeInfoOut CmnCodeSvcCodeInfoOut = comController.saveCdD(in);
	}

	@Test
	void getI18n() {
		CmnMltlnSvcMltlnInfoIn in = new CmnMltlnSvcMltlnInfoIn();
		
		CmnMltlnSvcMltlnInfoOut CmnMltlnSvcMltlnInfoOut = comController.getI18n(in);
	}

	@Test
	void getMltlnList() {
		CmnMltlnSvcMltlnInfoIn in = new CmnMltlnSvcMltlnInfoIn();
		
		CmnMltlnSvcMltlnInfoOut CmnMltlnSvcMltlnInfoOut = comController.getMltlnList(in);
	}

	@Test
	void registerMltln() {
		CmnMltlnSvcMltlnInfoIn in = new CmnMltlnSvcMltlnInfoIn();
		
		CmnMltlnSvcMltlnInfoOut CmnMltlnSvcMltlnInfoOut = comController.registerMltln(in);
	}

	@Test
	void modifyMltln() {
		CmnMltlnSvcMltlnInfoIn in = new CmnMltlnSvcMltlnInfoIn();
		
		CmnMltlnSvcMltlnInfoOut CmnMltlnSvcMltlnInfoOut = comController.modifyMltln(in);
	}

	@Test
	void getMsgList() {
		CmnMsgSvcMsgInfoIn in = new CmnMsgSvcMsgInfoIn();
		
		CmnMsgSvcMsgInfoOut CmnMsgSvcMsgInfoOut = comController.getMsgList(in);
	}

	@Test
	void registerMsg() {
		CmnMsgSvcMsgInfoIn in = new CmnMsgSvcMsgInfoIn();
		
		CmnMsgSvcMsgInfoOut CmnMsgSvcMsgInfoOut = comController.registerMsg(in);
	}

	@Test
	void modifyMsg() {
		CmnMsgSvcMsgInfoIn in = new CmnMsgSvcMsgInfoIn();
		
		CmnMsgSvcMsgInfoOut CmnMsgSvcMsgInfoOut = comController.modifyMsg(in);
	}

	@Test
	void getTgmList() {
		CmnTgmSvcTgmInfoIn in = new CmnTgmSvcTgmInfoIn();
		
		CmnTgmSvcTgmInfoOut CmnTgmSvcTgmInfoOut = comController.getTgmList(in);
	}

	@Test
	void getTgmDtlList() {
		CmnTgmSvcTgmInfoIn in = new CmnTgmSvcTgmInfoIn();
		
		CmnTgmSvcTgmInfoOut CmnTgmSvcTgmInfoOut = comController.getTgmDtlList(in);
	}

	@Test
	void saveTgm() {
		CmnTgmSvcTgmInfoIn in = new CmnTgmSvcTgmInfoIn();
		
		CmnTgmSvcTgmInfoOut CmnTgmSvcTgmInfoOut = comController.saveTgm(in);
	}

	// 전문 DTO 생성 및 다운로드
	@Test
	void downloadTgm() {
		CmnTgmSvcTgmInfoIn in = new CmnTgmSvcTgmInfoIn();
		comController.downloadTgm(in, response);
	}

	@Test
	void getFileList() {
		CmnFileSvcFileInfoIn in = new CmnFileSvcFileInfoIn();
		
		CmnFileSvcFileInfoOut CmnFileSvcFileInfoOut = comController.getFileList(in);
	}

	@Test
	void getFileDtlList() {
		CmnFileSvcFileInfoIn in = new CmnFileSvcFileInfoIn();
		
		CmnFileSvcFileInfoOut CmnFileSvcFileInfoOut = comController.getFileDtlList(in);
	}

	@Test
	void saveFile() {
		CmnFileSvcFileInfoIn in = new CmnFileSvcFileInfoIn();
		
		CmnFileSvcFileInfoOut CmnFileSvcFileInfoOut = comController.saveFile(in);
	}

	@Test
	void getBtchWrkList() {
		CmnBtchWrkSvcWrkIn in = new CmnBtchWrkSvcWrkIn();
		
		CmnBtchWrkSvcWrkOut CmnBtchWrkSvcWrkOut = comController.getBtchWrkList(in);
	}

	@Test
	void getPrevBtchWrkList() {
		CmnBtchWrkSvcWrkIn in = new CmnBtchWrkSvcWrkIn();
		
		CmnBtchWrkSvcWrkOut CmnBtchWrkSvcWrkOut = comController.getPrevBtchWrkList(in);
	}

	@Test
	void getAfBtchWrkList() {
		CmnBtchWrkSvcWrkIn in = new CmnBtchWrkSvcWrkIn();
		
		CmnBtchWrkSvcWrkOut CmnBtchWrkSvcWrkOut = comController.getAfBtchWrkList(in);
	}

	@Test
	void getBtchWrkExecRsltList() {
		CmnBtchWrkSvcWrkRsltIn in = new CmnBtchWrkSvcWrkRsltIn();
		
		CmnBtchWrkSvcWrkRsltOut CmnBtchWrkSvcWrkRsltOut = comController.getBtchWrkExecRsltList(in);
	}

	@Test
	void registerBtchWrk() {
		CmnBtchWrkSvcWrkIn in = new CmnBtchWrkSvcWrkIn();
		
		CmnBtchWrkSvcWrkOut CmnBtchWrkSvcWrkOut = comController.registerBtchWrk(in);
	}

	@Test
	void modifyBtchWrk() {
		CmnBtchWrkSvcWrkIn in = new CmnBtchWrkSvcWrkIn();
		
		CmnBtchWrkSvcWrkOut CmnBtchWrkSvcWrkOut = comController.modifyBtchWrk(in);
	}

	@Test
	public void redoBtch() throws SchedulerException {
		CmnBtchWrkSvcRedoBtchIn in = new CmnBtchWrkSvcRedoBtchIn();
		comController.redoBtch(in);
	}

    @Test
    void getBatDlySchdList() {
		ComBatDlySchdSvcIn in = new ComBatDlySchdSvcIn();
        
		ComBatDlySchdSvcOut ComBatDlySchdSvcOut = comController.getBatDlySchdList(in);
    }

    @Test
    void modifyBatDlySchd() {
		ComBatDlySchdSvcIn in = new ComBatDlySchdSvcIn();
        
		ComBatDlySchdSvcOut ComBatDlySchdSvcOut = comController.modifyBatDlySchd(in);
    }

//	@Test
//	void selectListCmnBnkStsM() {
//		CmnBnkStsMInDto dto = new CmnBnkStsMInDto();
//		CmnBnkStsMOutDto CmnBnkStsMOutDto = comController.selectListCmnBnkStsM(dto);
//	}
//
//	@Test
//	void insertCmnBnkStsM() {
//		CmnBnkStsMInDto dto = new CmnBnkStsMInDto();
//		comController.insertCmnBnkStsM(dto);
//	}
//
//	@Test
//	void updateCmnBnkStsM() {
//		CmnBnkStsMInDto dto = new CmnBnkStsMInDto();
//		comController.updateCmnBnkStsM(dto);
//	}
//
//	@Test
//	void mergeCmnBnkStsM() {
//		CmnBnkStsMInDto dto = new CmnBnkStsMInDto();
//		comController.mergeCmnBnkStsM(dto);
//	}

	// 통신망관리 목록 조회
	@Test
	void getListNetwork() {
		NetworkManagementSvcIn in = new NetworkManagementSvcIn();
		
		NetworkManagementSvcOut NetworkManagementSvcOut = comController.getListNetwork(in);
	}

	//망상태관리 목록 조회
	@Test
	void sendAllBnkNetworkMessage() {
		NetworkManagementSvcIn in = new NetworkManagementSvcIn();
		
		NetworkManagementSvcOut NetworkManagementSvcOut = comController.sendAllBnkNetworkMessage(in);
	}

	@Test
	void getListNetworkState() {
		NetworkStateManagementSvcIn in = new NetworkStateManagementSvcIn();
		NetworkStateManagementSvcOut NetworkStateManagementSvcOut =  comController.getListNetworkState(in);
	}

	// 휴일정보 목록조회
	@Test
	void getListHolidayInformation() {
		ComDateMInDto in = new ComDateMInDto();
		
		ComDateMOutDto ComDateMOutDto = comController.getListHolidayInformation(in);
	}

	// 휴일정보 수정
	@Test
	void changeHolidayInformation() {
		ComDateMInDto in = new ComDateMInDto();
		comController.changeHolidayInformation(in);
	}

	// 은행코드 목록조회
	@Test
	void getListBankCode() {
		ComBnkCdIn in = new ComBnkCdIn();
		
		ComBnkCdListOut ComBnkCdListOut = comController.getListBankCode(in);
	}


	// 은행코드 수정
	@Test
	void changeBankCode() {
		ComBnkCdIn in = new ComBnkCdIn();
		comController.changeBankCode(in);
	}

    // 은행코드 코드성 목록 조회
    @Test
    void getListBankCodeLabel() {
		ComBnkCdIn in = new ComBnkCdIn();
        
		CodeLabelListOut CodeLabelListOut = comController.getListBankCodeLabel(in);
    }

    // 은행지점코드 목록조회
    @Test
    void getListBankBranchCode() {
		ComBnkBrnchCdIn in = new ComBnkBrnchCdIn();
        
		ComBnkBrnchCdListOut ComBnkBrnchCdListOut = comController.getListBankBranchCode(in);
    }

    // 은행지점코드 코드성 목록 조회
    @Test
    void getListBankBranchCodeLabel() {
		ComBnkBrnchCdIn in = new ComBnkBrnchCdIn();
        
		CodeLabelListOut CodeLabelListOut = comController.getListBankBranchCodeLabel(in);
    }

	@Test
	void getListSendReceiveFileInformation() {
		SendReceiveFileInformationIn in = new SendReceiveFileInformationIn();
		
		SendReceiveFileInformationOut SendReceiveFileInformationOut = comController.getListSendReceiveFileInformation(in);
	}

	// 응답코드 목록조회
	@Test
	void getListResponseCode() {
		ComRespCdIn in = new ComRespCdIn();
		
		ComRespCdListOut ComRespCdListOut = comController.getListResponseCode(in);
	}

	// 응답코드 등록
	@Test
	void createResponseCode() {
		ComRespCdIn in = new ComRespCdIn();
		comController.createResponseCode(in);
	}

	// 응답코드 수정
	@Test
	void changeResponseCode() {
		ComRespCdIn in = new ComRespCdIn();
		comController.changeResponseCode(in);
	}

	// 응답코드 삭제
	@Test
	void removeResponseCode() {
		ComRespCdIn in = new ComRespCdIn();
		comController.removeResponseCode(in);
	}

	// 응답코드맵핑 목록조회
	@Test
	void getListResponseCodeMapping() {
		ComRespCdMapIn in = new ComRespCdMapIn();
		
		ComRespCdMapListOut ComRespCdMapListOut = comController.getListResponseCodeMapping(in);
	}

	// 응답코드맵핑 등록
	@Test
	void createResponseCodeMappingClick() {
		ComRespCdMapIn in = new ComRespCdMapIn();
		comController.createResponseCodeMappingClick(in);
	}

	// 응답코드맵핑 수정
	@Test
	void changeResponseCodeMapping() {
		ComRespCdMapIn in = new ComRespCdMapIn();
		comController.changeResponseCodeMapping(in);
	}

	// 응답코드맵핑 삭제
	@Test
	void removeResponseCodeMapping() {
		ComRespCdMapIn in = new ComRespCdMapIn();
		comController.removeResponseCodeMapping(in);
	}

	// 계좌정보 목록조회
	@Test
	void getListAccountInformation() {
		ComAcctInfoIn in = new ComAcctInfoIn();
		
		ComAcctListOut ComAcctListOut = comController.getListAccountInformation(in);
	}

	// 계좌정보 등록
	@Test
	void createAccountInformation() {
		ComAcctInfoIn in = new ComAcctInfoIn();
		comController.createAccountInformation(in);
	}

	// 계좌정보 수정
	@Test
	void changeAccountInformation() {
		ComAcctInfoIn in = new ComAcctInfoIn();
		
		comController.changeAccountInformation(in);
	}

	// 공통승인 목록조회
	@Test
	void getListCommonApproval() {
		ComAprvHIn in = new ComAprvHIn();
		
		ComAprvHListOut ComAprvHListOut = comController.getListCommonApproval(in);
	}

    // 공통승인 승인
	@Test
	void executeCommonApproval() {
		ComAprvHIn in = new ComAprvHIn();
		
		comController.executeCommonApproval(in);
	}

	// 공통승인 반려
	@Test
	void rejectCommonApproval() {
		ComAprvHIn in = new ComAprvHIn();
		
		comController.rejectCommonApproval(in);
	}

	// 사용자 활동정보 목록 조회
	@Test
	void getStaffActInfoList() {
		StaffActInfoSvcActInfoIn in = new StaffActInfoSvcActInfoIn();
		
		StaffActInfoSvcActInfoOut StaffActInfoSvcActInfoOut = comController.getStaffActInfoList(in);
	}

	// Push Message Format 목록 조회
	@Test
	void getPushMsgFmtList() {
		ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
		
		ComPshMsgSvcInfoOut ComPshMsgSvcInfoOut = comController.getPushMsgFmtList(in);
	}

	// Push Message Format 상세 조회
	@Test
	void getPushMsgDtlList() {
		ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
		
		ComPshMsgSvcInfoOut ComPshMsgSvcInfoOut = comController.getPushMsgDtlList(in);
	}

	// Push Message Format 등록
	@Test
	void registerPushMsgFmt() {
		ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
		
		ComPshMsgSvcInfoOut ComPshMsgSvcInfoOut = comController.registerPushMsgFmt(in);
	}

	// Push Message Format 수정
	@Test
	void modifyPushMsgFmt() {
		ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
		
		ComPshMsgSvcInfoOut ComPshMsgSvcInfoOut = comController.modifyPushMsgFmt(in);
	}

	// Push Message Format 삭제
	@Test
	void removePushMsgFmt() {
		ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
		
		ComPshMsgSvcInfoOut ComPshMsgSvcInfoOut = comController.removePushMsgFmt(in);
	}

    // 전문 매핑 목록 조회
	@Test
	void getTlgMapMList() {
		ComTlgLaytMapM in = new ComTlgLaytMapM();
		
		ComTlgLaytMapSvcOut ComTlgLaytMapSvcOut = comController.getTlgMapMList(in);
	}

    // 전문 매핑 정보 상세 조회
	@Test
	void getTlgMapInfo() {
		ComTlgLaytMapSvcIn in = new ComTlgLaytMapSvcIn();
		
		ComTlgLaytMapSvcOut ComTlgLaytMapSvcOut = comController.getTlgMapInfo(in);
	}

    // 전문 매핑 정보 저장
	@Test
	void saveTlgMap() {
		ComTlgLaytMapSvcIn in = new ComTlgLaytMapSvcIn();
		
		ComTlgLaytMapSvcOut ComTlgLaytMapSvcOut = comController.saveTlgMap(in);
	}

    // 전문 매핑 정보 수정
	@Test
	void updateTlgMap() {
		ComTlgLaytMapSvcIn in = new ComTlgLaytMapSvcIn();
		
		ComTlgLaytMapSvcOut ComTlgLaytMapSvcOut = comController.updateTlgMap(in);
	}

	@Test
	void getIntegratedSummary() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		
		IntegratedSummaryOut IntegratedSummaryOut = comController.getIntegratedSummary(in);
	}


	// Push Message Format 상세 조회
	@Test
	void getPushMsgHistList() {
		ComPshMsgHistSvcInfoIn in = new ComPshMsgHistSvcInfoIn();
		
		ComPshMsgHistSvcInfoOut ComPshMsgHistSvcInfoOut = comController.getPushMsgHistList(in);
	}
	
    @Test
    void auth() {
        CustomMonetaUser monetaUser = mock(CustomMonetaUser.class);
        when(cmnLoginSvc.auth(monetaUser)).thenReturn(new CmnLoginSvcLoginInfoOut());

        CmnLoginSvcLoginInfoOut result = comController.auth(monetaUser);

        assertNotNull(result);
        verify(cmnLoginSvc).auth(monetaUser);
    }

    @Test
    void oauthLogin() {
        MockHttpServletResponse response = new MockHttpServletResponse();
        when(cmnLoginSvc.oauthLogin()).thenReturn(new CmnLoginSvcLoginInfoOut());

        CmnLoginSvcLoginInfoOut result = comController.oauthLogin(response);

        assertNotNull(result);
        verify(cmnLoginSvc).oauthLogin();
    }

    @Test
    void deleteMltln() {
        CmnMltlnSvcMltlnInfoIn in = new CmnMltlnSvcMltlnInfoIn();

        doNothing().when(cmnMltlnSvc).deleteMltln(in);

        comController.deleteMltln(in);

        verify(cmnMltlnSvc).deleteMltln(in);
    }

    @Test
    void getSpecificBtchWrkExecRsltList() {
        CmnBtchWrkSvcWrkRsltIn in = new CmnBtchWrkSvcWrkRsltIn();
        when(cmnBtchWrkSvc.getSpecificBtchWrkExecRsltList(in)).thenReturn(new CmnBtchWrkSvcWrkRsltOut());

        CmnBtchWrkSvcWrkRsltOut result = comController.getSpecificBtchWrkExecRsltList(in);

        assertNotNull(result);
        verify(cmnBtchWrkSvc).getSpecificBtchWrkExecRsltList(in);
    }

    @Test
    void forcedBtch() throws SchedulerException {
        CmnBtchWrkSvcRedoBtchIn in = new CmnBtchWrkSvcRedoBtchIn();

        doNothing().when(cmnBtchWrkSvc).forcedBtch(in);

        comController.forcedBtch(in);

        verify(cmnBtchWrkSvc).forcedBtch(in);
    }

    @Test
    void createHolidayInformation() {
        ComDateMInDto in = new ComDateMInDto();

        doNothing().when(holidayInformationSvc).registerComDateM(in);

        comController.createHolidayInformation(in);

        verify(holidayInformationSvc).registerComDateM(in);
    }

    @Test
    void createBankCode() {
        ComBnkCdIn in = new ComBnkCdIn();

        doNothing().when(bankCodeSvc).createBnkCd(in);

        comController.createBankCode(in);

        verify(bankCodeSvc).createBnkCd(in);
    }

    @Test
    void getIntegratedSummaryHeader() {
        IntegratedSummaryHeaderIn in = new IntegratedSummaryHeaderIn();
        when(integratedSummarySvc.getIntegratedSummaryHeader(in)).thenReturn(new IntegratedSummaryHeaderOut());

        IntegratedSummaryHeaderOut result = comController.getIntegratedSummaryHeader(in);

        assertNotNull(result);
        verify(integratedSummarySvc).getIntegratedSummaryHeader(in);
    }

    @Test
    void getBizDashboard() {
        when(bizDashboardSvc.getBizDashboard(any())).thenReturn(new BizDashboardSvcOut());

        BizDashboardSvcIn in = new BizDashboardSvcIn();
        BizDashboardSvcOut result = comController.getBizDashboard(new BizDashboardSvcIn());

        assertNotNull(result);
        verify(bizDashboardSvc).getBizDashboard(in);
    }

    @Test
    void sendMessageControllerTest() {
        SymphonyTestSvcDto in = new SymphonyTestSvcDto();

        comController.sendMessageTest(in);

        verify(symphonyTestSvc).sendMessage(in);
    }
    
    @Test
    void getFileNoListControllerTest() {
    	ComFileNoListIn in = new ComFileNoListIn();
    	
    	comController.getFileNoList(in);
    	
    	verify(comSndRcvFileInqrySvc).getFileNoList(in);
    }
    
    @Test
    void getCmsSndRcvFileListControllerTest() {
    	SndRcvFileListIn in = new SndRcvFileListIn();
    	
    	comController.getCmsSndRcvFileList(in);
    	
    	verify(comSndRcvFileInqrySvc).getSndRcvFileList(in);
    }
    
    @Test
    void getCmsSndRcvFileDetailListControllerTest() {
    	SndRcvFileDtlListIn in = new SndRcvFileDtlListIn();
    	
    	comController.getCmsSndRcvFileDetailList(in);
    	
    	verify(comSndRcvFileInqrySvc).getSndRcvFileDetailList(in);
    }
    
    @Test
    void getSndRcvFileStsListControllerTest() {
    	ComFileTractLSvcIn in = new ComFileTractLSvcIn();
    	
    	comController.getSndRcvFileStsList(in);
    	
    	verify(comFileTractLSvc).getSndRcvFileStsList(in);
    }
    
    @Test
    void reSndRcvFileRqstControllerTest() {
    	ComFileTractLSvcIn in = new ComFileTractLSvcIn();
    	
    	comController.reSndRcvFileRqst(in);
    	
    	verify(comFileTractLSvc).reSndRcvFileRqst(in);
    }
    
    @Test
    void getListSendReceiveFileInformationControllerTest() {
    	ComFileNoListIn in = new ComFileNoListIn();
    	
    	comController.getListSendReceiveFileInformation(in);
    	
    	verify(sendReceiveFileInformationSvc).getAllFileNoList(in);
    }
    
    @Test
    void getComIntegratedSummaryReportControllerTest() {
    	ComIntegratedSummaryIn in = new ComIntegratedSummaryIn();
    	
    	comController.getComIntegratedSummaryReport(in, response);
    	
    	verify(integratedSummarySvc).getComIntegratedSummaryReport(in, response);
    }
    
    @Test
    void getComIntegratedSummaryControllerTest() {
    	ComIntegratedSummaryIn in = new ComIntegratedSummaryIn();
    	
    	comController.getComIntegratedSummary(in);
    	
    	verify(integratedSummarySvc).getComIntegratedSummary(in);
    }
    
    @Test
    void getListHoldTransactionControllerTest() {
    	HoldTransactionManagementSvcIn in = new HoldTransactionManagementSvcIn();
    	
    	comController.getListHoldTransaction(in);
    	
    	verify(holdTransactionManagementSvc).getListHoldTransaction(in);
    }
    
    @Test
    void sendHoldTransactionInquiryControllerTest() {
    	HoldTransactionManagementSvcIn in = new HoldTransactionManagementSvcIn();
    	
    	comController.sendHoldTransactionInquiry(in);
    	
    	verify(holdTransactionManagementSvc).sendHoldTransactionInquiry(in);
    }
    
    @Test
    void getRcvdUserGroupListControllerTest() {
    	
    	comController.getRcvdUserGroupList();
    	
    	verify(comRcvdUserGroupMSvc).getRcvdUsrGrpList();
    }
    
    @Test
    void insertRcvdUserControllerTest() {
    	ComRcvdUserGroupMSvcIn in = new ComRcvdUserGroupMSvcIn();
    	
    	comController.insertRcvdUser(in);
    	
    	verify(comRcvdUserGroupMSvc).insertRcvdUsrGrp(in);
    }
    
    @Test
    void updateRcvdUserControllerTest() {
    	ComRcvdUserGroupMSvcIn in = new ComRcvdUserGroupMSvcIn();
    	
    	comController.updateRcvdUser(in);
    	
    	verify(comRcvdUserGroupMSvc).updateRcvdUsrGrp(in);
    }
    
    @Test
    void modifyRcvdUsrGrpControllerTest() {
    	ComPshMsgSvcInfoIn in = new ComPshMsgSvcInfoIn();
    	
    	comController.modifyRcvdUsrGrp(in);
    	
    	verify(comPshMsgSvc).modifyRcvdUsrGrp(in);
    }
    
    @Test
    void getLogFileListControllerTest() {
    	ComLogFile in = new ComLogFile();
    	
    	comController.getLogFileList(in);
    	
    	verify(comLogFileSvc).getLogFileList(in);
    }
    
    @Test
    void logFileDownControllerTest() {
    	ComLogFile in = new ComLogFile();
    	
    	try {
			comController.logFileDown(response, in);
			
			verify(comLogFileSvc).logFileDown(in, response);
			
		} catch (SafePathCheckException e) {
			e.printStackTrace();
		} catch (InvalidRegularExpression e) {
			e.printStackTrace();
		}
    	
    }
}
