package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.jpmc.kcg.bat.ChunkBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.bat.cms.biz.CmsSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.cms.dto.BatCmsDbtTrnsRqstRsltVo;
import com.jpmc.kcg.cms.biz.CmsAccountValidator;
import com.jpmc.kcg.cms.biz.Money;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB23R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB23T;
import com.jpmc.kcg.cms.biz.vo.LvbCmsEB23;
import com.jpmc.kcg.cms.constants.CmsConst;
import com.jpmc.kcg.cms.dto.AccountOut;
import com.jpmc.kcg.cms.dto.CmsSndRcvFileL;
import com.jpmc.kcg.cms.enums.CmsBatchRespCdEnum;
import com.jpmc.kcg.cms.enums.CmsPrcsStsDvsnCdEnum;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComAcctAlarmMDao;
import com.jpmc.kcg.com.dto.ComAcctAlarmM;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.frw.bat.BatContextImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * EB23 (출금의뢰내역)입금 지시
 * (Debit Transfer Request) Deposit Instruction
 * 처리기준: 전영업일 출금한 금액에 대한 이용기관 모계좌 입금일
 */
@Component
@Slf4j
public class CmsDbtTrnsDpstInstrJobBean extends ChunkBatJob<CmsSndRcvFileL, BatCmsDbtTrnsRqstRsltVo> {

    private static final String FILE_NAME = "EB23";
	private static final String MAIL_CONTENTS_LIST = "MAIL_CONTENTS_LIST";
	private final CmsAccountValidator cmsAccountValidator;
	private final CmsSndRcvLogManager cmsSndRcvLogManager;
    private final ComAcctAlarmMDao comAcctAlarmMDao;
	private final FrwTemplate frwTemplate;
	private final ComPshMsgBean comPshMsgBean;
    private final CmsCom cmsCom;
	
	public CmsDbtTrnsDpstInstrJobBean(CmsAccountValidator cmsAccountValidator
			, CmsSndRcvLogManager cmsSndRcvLogManager, ComAcctAlarmMDao comAcctAlarmMDao
            , FrwTemplate frwTemplate, ComPshMsgBean comPshMsgBean, CmsCom cmsCom) {
		this.cmsAccountValidator = cmsAccountValidator;
		this.cmsSndRcvLogManager = cmsSndRcvLogManager;
        this.comAcctAlarmMDao = comAcctAlarmMDao;
        this.comPshMsgBean = comPshMsgBean;
		this.frwTemplate = frwTemplate;
        this.cmsCom = cmsCom;
	}

	@Override
	protected void beforeJob(BatContext batContext) {
		log.debug("### beforeJob #####");

		BatCmsContextVo cmsContextVo = new BatCmsContextVo();
		
		cmsContextVo.initializeContext(batContext, FILE_NAME);
		List<Map<String, String>> mailContentsList = new ArrayList<>();
		
		batContext.setData(CMS_CONTEXT, cmsContextVo);
	    batContext.setData(TOT_AMOUNT, BigDecimal.ZERO);
	    batContext.setData(TOT_RECORD_COUNT, 0);
	    batContext.setData(ERROR_COUNT, 0);
	    batContext.setData(WITHDRAWAL_COUNT, 0);
		batContext.setData(MAIL_CONTENTS_LIST, mailContentsList);

        // file tracking 정보 저장
        batContext.setFileTractId(cmsCom.getFileTractId(cmsContextVo.getSrDt(), EB23));

        // commit interval 설정
        BatContextImpl context = (BatContextImpl)FrwContextHolder.getContext();
        context.setCommitInterval(cmsContextVo.getCommitInterval());
	}

	@Override
	protected long targetTotalCount(BatContext batContext) {
		
		BatCmsContextVo cmsContextVo = (BatCmsContextVo)batContext.getData(CMS_CONTEXT);
		int totalRecCount = cmsSndRcvLogManager.getCountReceivedFilesData(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
		batContext.setData(TOT_RECORD_COUNT, totalRecCount);
		return totalRecCount;
	}
	
	// 처리 대상 조회
	@Override
	protected Iterator<CmsSndRcvFileL> openReader(BatContext batContext) {
		log.debug(" ##### openReader start  {} ######");
	    BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
		
		// EB23 파일 데이터 조회(CMS_SND_RVC_FILE_L)
		List<CmsSndRcvFileL> dataList = cmsSndRcvLogManager.getReceivedFilesData(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
		log.debug(" ##### [EB23] NO DATA SIZE  {} ######", dataList.size());
	    
	    return dataList.iterator();
	}
	

	@Override
	protected BatCmsDbtTrnsRqstRsltVo process(CmsSndRcvFileL in) {
		log.debug(" ##### process start ######");
		
		BatCmsDbtTrnsRqstRsltVo resultVo = new BatCmsDbtTrnsRqstRsltVo();

		KftCmsEB23R kftCmsEB23R = VOUtils.toVo(in.getTlgCtt(), KftCmsEB23R.class);

		// 출금 데이터 검증
        String respCd = _validateWithdrawalInfo(kftCmsEB23R);
		
		resultVo.setRespCd(respCd);
		resultVo.setTargetRecordVo(kftCmsEB23R);
		resultVo.setWithdrawalAmt(BigDecimal.valueOf(kftCmsEB23R.getAmountOfTotalWithdrawals()));
		resultVo.setTargetFileL(in);
		return resultVo;
	}

	@Override
	protected void write(List<BatCmsDbtTrnsRqstRsltVo> items) {
		log.debug(" ##### write start ######");

		BatContext batContext = (BatContext) FrwContextHolder.getContext();
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
		List<Map<String, String>> mailContentsList = (List<Map<String, String>>) batContext.getData(MAIL_CONTENTS_LIST);

		BigDecimal totalAmount = (BigDecimal) batContext.getData(TOT_AMOUNT);
	    int errCnt = (int) batContext.getData(ERROR_COUNT);
	    int totalWhdrwlCnt = (int) batContext.getData(WITHDRAWAL_COUNT);
	    
	    for (BatCmsDbtTrnsRqstRsltVo resultVo : items) {
	    
	    	KftCmsEB23R kftCmsEB23R = (KftCmsEB23R) resultVo.getTargetRecordVo();

	        String respCd = resultVo.getRespCd();
	        String sourceFileNm = resultVo.getTargetFileL().getFileNm();
	        
			batContext.setData(TOT_AMOUNT, totalAmount.add(resultVo.getWithdrawalAmt()));
			batContext.setData(WITHDRAWAL_COUNT, totalWhdrwlCnt + kftCmsEB23R.getCountOfTotalWithdrawals()); //총 출금건수

//			// 출금액 - 총수수료 != 입금은행수수료 검증
//			if (!isValidWithdrawalAmount(kftCmsEB23R)) {
//				sendAmountMismatchAlarm(kftCmsEB23R);
//				
//				// TODO 응답코드 수정이 필요해보임
//			} else {
//			}
            // 출금이체 호출
            _sendWithdrawal(kftCmsEB23R, sourceFileNm, respCd, cmsContextVo, mailContentsList);

            // 결과코드, 처리상태코드(11: 전송완료) update()
            cmsSndRcvLogManager.updateStatus(resultVo.getTargetFileL(), respCd, CmsPrcsStsDvsnCdEnum.LVB_SND.getCode());
			
			if(!CmsBatchRespCdEnum.NORMAL.getCode().equals(respCd)) {
				batContext.setData(ERROR_COUNT, errCnt++);
				
				log.debug("[EB23] VALIDATE ERROR DATA [[FILE_NM= {}] [SEQ_NO={}] [RESP_CD = {}]", 
	                      sourceFileNm, kftCmsEB23R.getDataSerialNumber(), respCd);					
			}
			
	    }
		
	    // BatContext에 메일링 변수 저장
		batContext.setData(MAIL_CONTENTS_LIST, mailContentsList);
	}

//	/**
//	 * 출금액과 수수료 검증 로직
//	 */
//	private boolean isValidWithdrawalAmount(KftCmsEB23R kftCmsEB23R) {
//        // TODO (총 출금액 - 입금은행 수수료) != 출금 총액 인 경우에 host로 전송 안함
//		
//		Money calculatedAmount = Money.minusAmount(
//				kftCmsEB23R.getAmountOfTotalWithdrawals(),
//				kftCmsEB23R.getDepositBankFee()
//		);
//		return calculatedAmount.equals(new Money(kftCmsEB23R.getAmountOfTotalWithdrawals()));
//	}
//
//	/**
//	 * 출금 금액 불일치 알람 발송
//	 */
//	private void sendAmountMismatchAlarm(KftCmsEB23R kftCmsEB23R) {
//		String mailContent = String.format(
//				"\"40\", [F A I L] EB23 Amount Calculation Error! AccNo [%s] Total Amt [KRW %s] Fee [KRW %s] Calculated Amt [KRW %s]",
//				kftCmsEB23R.getDepositAccountNumber(),
//				new Money(kftCmsEB23R.getAmountOfTotalWithdrawals()).format(),
//				new Money(kftCmsEB23R.getTotalFee()).format(),
//				Money.minusAmount(kftCmsEB23R.getAmountOfTotalWithdrawals(), kftCmsEB23R.getTotalFee()).format()
//		);
//
//		Map<String, Object> alarmContent = new HashMap<>();
//		alarmContent.put("errTlgId", "[KCG] EB23 Amount Calculation Error");
//		alarmContent.put("errCtt", mailContent);
//
//		comPshMsgBean.sendAlarm(14, alarmContent, null, true);
//	}
	
	private void _sendWithdrawal(KftCmsEB23R kftCmsEB23R, String sourceFileNm, String respCd, BatCmsContextVo cmsContextVo, List<Map<String, String>> mailContentsList) {

        /**************************************************************************
        EB23 파일의 수수료가 기존 00000000000 로 처리되게 되어있어서
        고객의 수수료를 JP가 부담하고 있었음
        하여 의뢰금액-수수료 로 계산하여 수수료를 제외한 금액을 LVB로 전송하기로함.
        **************************************************************************/
		// 총 출금액 - 출금은행 수수료
		Money realWithdrawalAmount = Money.minusAmount(kftCmsEB23R.getAmountOfTotalWithdrawals(), kftCmsEB23R.getWithdrawalBankFee());

		LvbCmsEB23 lvbCmsEB23 = new LvbCmsEB23();
		String msgNo = cmsCom.getCmsNumbering();
		lvbCmsEB23.setMsgNo                 ( msgNo                                 );
		lvbCmsEB23.setSystemSendReceiveTime ( LocalDateTime.now()                   ); // 시스템송수신시간
		lvbCmsEB23.setMessageType           ( EB23                                  ); // EB23
		lvbCmsEB23.setInstitutionCode       ( kftCmsEB23R.getInstitutionCode()      ); // 기관코드
		lvbCmsEB23.setFileName              ( sourceFileNm                          );
		lvbCmsEB23.setFileSerialNumber      ( kftCmsEB23R.getDataSerialNumber()     );
		lvbCmsEB23.setResponseCode          ( respCd                                ); // 응답코드 (default: 0000)
//        lvbCmsEB23.setProcessDate           ( cmsContextVo.getPrcsDt()              ); // LVB 처리일자 -> LVB에서 validation 로직 존재하여, as-is와 동일하게 거래일자로 처리 2025-02-25
		lvbCmsEB23.setProcessDate           ( StringUtils.substring(kftCmsEB23R.getTransferDueDate(), 2, 8)); // LVB 처리일자 -> 이체기일로 전달하도록 적용: 2025-04-18
		lvbCmsEB23.setAccountNumber         ( kftCmsEB23R.getDepositAccountNumber() ); // 출금계좌번호
		lvbCmsEB23.setRequestedAmount       ( realWithdrawalAmount.getLongAmount()  ); // 의뢰금액
		lvbCmsEB23.setProcessedAmount       ( 0L                                    ); // 처리금액
		lvbCmsEB23.setFeeAmount             ( 0L                                    ); // 수수료
		lvbCmsEB23.setRequestedCount        ( kftCmsEB23R.getCountOfTotalWithdrawals() ); // 의뢰건수
		lvbCmsEB23.setProcessedCount        ( 0                                    ); // 처리건수

		frwTemplate.send(FrwDestination.LVB_CMS, lvbCmsEB23);

		/**	전송 후 성공 알림 호출
		f_sendTivoli("41", "[I N F O] CMS EB23 LVB Sent! [Metlife Insurance] AccNo [%s] Total Amt [KRW %s] Fee [KRW %s] Final Credit Amt [KRW %s]"
                , msg_account, msg_tamount, msg_fee, msg_ramount);
         */

        /*
        계좌 알람전송의 계좌와 일치시 메일 발송
         */
		ComAcctAlarmM comAcctAlarmM = new ComAcctAlarmM();
		comAcctAlarmM.setAcctNo(kftCmsEB23R.getDepositAccountNumber());
		comAcctAlarmM.setPshMsgTmpltId(12);
		comAcctAlarmM.setAlarmTrDvsnCd(ComConst.CHAR_01);
        ComAcctAlarmM alarmAccount = comAcctAlarmMDao.selectDrctAlarmTrgt(comAcctAlarmM);
        
        log.debug("EB23 ALARM ACCOUNT : {}", comAcctAlarmM);
        
        if (alarmAccount != null) { // 01: 정상알림
            log.debug("EB23 METLIFE ALARM START ");

            // 포맷 정의
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            
            Map<String, String> mailContents = new HashMap<>();
            mailContents.put("dateTime" 		  ,LocalDateTime.now().format(formatter)                        ); 
            mailContents.put("accountNumber" 	  ,kftCmsEB23R.getDepositAccountNumber()						);
            mailContents.put("totalAmount" 	  	  ,new Money(kftCmsEB23R.getAmountOfTotalWithdrawals()).format());
            mailContents.put("fee" 			  	  ,new Money(kftCmsEB23R.getWithdrawalBankFee()).format()	    );
            mailContents.put("finalCreditAmount"  ,realWithdrawalAmount.format()                                );
            mailContentsList.add(mailContents);
        } 
	}
	
	/**
	 * 1. 의뢰금액 검증
	 * 2. 계좌 검증
	 * @param kftCmsEB23R
	 * @return
	 */
	private String _validateWithdrawalInfo(KftCmsEB23R kftCmsEB23R) {
		
    	// 의뢰금액 <= 0 인 경우 0061 금액 정보 에러
        String respCd = cmsCom.validateAmt(BigDecimal.valueOf(kftCmsEB23R.getAmountOfTotalWithdrawals()));

    	if(!CmsBatchRespCdEnum.isNormal(respCd)) {
            // 계좌 검증 실패 시 에러
            AccountOut accountInfo = cmsAccountValidator.validateAccountWithdrawalAccountError(kftCmsEB23R.getDepositAccountNumber());
            return accountInfo.getRespCd();
    	}
		return respCd;
	}

	/**
	 * 4. trailer 데이터 검증 
	 * 5. 집계 데이터 update 
	 * */
	@Override
	protected void afterJob(BatContext batContext) {
		log.debug(" ##### afterJob start ######");

		BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
		List<Map<String, String>> mailContentsList = (List<Map<String, String>>) batContext.getData(MAIL_CONTENTS_LIST);
		BigDecimal totalAmount = (BigDecimal) batContext.getData(TOT_AMOUNT);
		int totalCount = (int) batContext.getData(TOT_RECORD_COUNT);
		int totalErrCnt = (int) batContext.getData(ERROR_COUNT);
		int totalWhdrwlCnt = (int) batContext.getData(WITHDRAWAL_COUNT);

		// JPMC 이용 집계 업데이트
//		_updateCmsCorpTotL(cmsContextVo.getSourceFileNm(), cmsContextVo.getTrDt(), CmsConst.COR_JPMC, totalAmount, totalWhdrwlCnt);
		cmsSndRcvLogManager.saveRqstCmsCorpTotL(cmsContextVo.getTrDt(), CmsConst.COR_JPMC, cmsContextVo.getSourceFileNm(), totalAmount, totalWhdrwlCnt);

		// TRAILER 부 조회
		CmsSndRcvFileL trailer = cmsSndRcvLogManager.getReceivedFilesTrailer(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());

		if(trailer != null) {

			// trailer 금액 및 count 검증
			String trailerRespCd = validateTrailerData(trailer, totalAmount, totalCount, totalWhdrwlCnt);

			// KFTC 이용 집계 업데이트 - 정상적인 응답이 아닌 경우
			if (!CmsBatchRespCdEnum.isNormal(trailerRespCd)) {

				cmsSndRcvLogManager.updateRcvFileLog(trailer, trailerRespCd);

				cmsSndRcvLogManager.saveRqstCmsCorpTotL(cmsContextVo.getTrDt(), CmsConst.COR_KFTC, cmsContextVo.getSourceFileNm(), totalAmount, totalWhdrwlCnt);

                log.debug("[INFO]    ===================================================] ");
                log.debug("[INFO]    =                 EB23 COR_KFTC UPDATE            =] ");
                log.debug("[INFO]    ===================================================] ");
                log.debug("[INFO]    FILE NAME         : [{}]", cmsContextVo.getSourceFileNm());
                log.debug("[INFO]    SR DATE           : [{}]", cmsContextVo.getSrDt());
                log.debug("[INFO]    TR DATE           : [{}]", cmsContextVo.getTrDt());
                log.debug("[INFO]    TOTAL AMOUNT      : [{}]", totalAmount);
                log.debug("[INFO]    NORMAL COUNT      : [{}]", totalCount);
                log.debug("[INFO]    ERROR COUNT       : [{}]", totalErrCnt);
                log.debug("[INFO]    TOTAL WITHDRAWAL  : [{}]", totalWhdrwlCnt);
                log.debug("[INFO]    ===================================================] ");
			}

			// header/trailer 처리상태 11로 변경 (전송완료)
			cmsSndRcvLogManager.updateHeaderTrailerLvbSndProcessStatus(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
		}

		/*
		 계좌 알람전송의 계좌 거래건이 있을 때 메일 전송
		 */
        if (!CollectionUtils.isEmpty(mailContentsList)) {
            Map<String, Object> paramValList = new HashMap<>();
            paramValList.put("items", mailContentsList);
            comPshMsgBean.sendAlarm(12, paramValList, null, true);
        }

		log.debug("[EB23] SUCCESS [FILE_NM = {}] [TOT_AMT = {}] [TOT_CNT = {}] [ERR_CNT = {}] [TOT_WITHDRAWA_CNT = {}]",
				cmsContextVo.getSourceFileNm(), totalAmount, totalCount, totalErrCnt, totalWhdrwlCnt);
	}
	
	private String validateTrailerData(CmsSndRcvFileL trailer, BigDecimal totAmt, int recordCnt, int totalWhdrwlCnt) {

		KftCmsEB23T kftCmsEB23T = VOUtils.toVo(trailer.getTlgCtt(), KftCmsEB23T.class);

        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  =                  EB23 TRAILER                  =] ");
        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  TOTAL RECORD COUNT          : [{}]", kftCmsEB23T.getTotalDataRecordCount());
        log.debug("[I N F O]  PROCESSED RECORD COUNT      : [{}]", recordCnt);
        log.debug("[I N F O]  TOTAL WITHDRAWAL COUNT      : [{}]", kftCmsEB23T.getTotalCountOfWithdrawals());
        log.debug("[I N F O]  PROCESSED WITHDRAWAL COUNT  : [{}]", totalWhdrwlCnt);
        log.debug("[I N F O]  REQUESTED WITHDRAWAL AMOUNT : [{}]", kftCmsEB23T.getTotalAmountOfWithdrawals());
        log.debug("[I N F O]  PROCESSED WITHDRAWAL AMOUNT : [{}]", totAmt);
        log.debug("[I N F O]  ===================================================] ");
		
		if(kftCmsEB23T.getTotalDataRecordCount() != recordCnt) {
			log.info("[F A I L] EB23 FILE 신규건수가 일치하지 않음 [TOTAL_DATA_RECORD_CNT={}] [PROC_RECORD_COUNT = {}] ", 
					kftCmsEB23T.getTotalDataRecordCount() , recordCnt);
			// 9998 기타오류
			return CmsBatchRespCdEnum.ETC_ERROR.getCode();
		}

        if(kftCmsEB23T.getTotalCountOfWithdrawals() != totalWhdrwlCnt) {;
            log.info("[F A I L] EB23 총 출금의뢰 건수가 일치하지 않음 [TOTAL_WITHDRAWAL_RECORD_CNT={}] [PROC_WITHDRAWAL_COUNT = {}] ",
                    kftCmsEB23T.getTotalCountOfWithdrawals() , recordCnt);
            // 9998 기타오류
            return CmsBatchRespCdEnum.ETC_ERROR.getCode();
        }
		
		if(BigDecimal.valueOf(kftCmsEB23T.getTotalAmountOfWithdrawals()).compareTo(totAmt) != 0) {
			log.info("[F A I L] EB23 총 금액이 일치하지 않음 [REQUEST_TOT_AMT = {}] [PROC_WITHDRAWAL_AMOUNT = {}]", 
					kftCmsEB23T.getTotalAmountOfWithdrawals(), totAmt);
			// 9998 기타오류
			return CmsBatchRespCdEnum.ETC_ERROR.getCode();
		}
		
		return CmsBatchRespCdEnum.NORMAL.getCode();
	}
	

	@Override
	protected OutputStream openWriter(BatContext batContext) {
		return null;
	}

}