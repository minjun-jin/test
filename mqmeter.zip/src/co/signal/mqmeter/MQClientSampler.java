package co.signal.mqmeter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.jmeter.config.Arguments;
import org.apache.jmeter.protocol.java.sampler.AbstractJavaSamplerClient;
import org.apache.jmeter.protocol.java.sampler.JavaSamplerContext;
import org.apache.jmeter.samplers.SampleResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.msg.client.jakarta.jms.JmsConnectionFactory;
import com.ibm.msg.client.jakarta.jms.JmsConstants;
import com.ibm.msg.client.jakarta.jms.JmsFactoryFactory;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;

import jakarta.jms.JMSConsumer;
import jakarta.jms.JMSContext;
import jakarta.jms.JMSProducer;
import jakarta.jms.Message;
import jakarta.jms.Queue;
import jakarta.jms.TextMessage;

public class MQClientSampler extends AbstractJavaSamplerClient {

	private static final Logger log = LoggerFactory.getLogger(MQClientSampler.class);

	private JMSContext jmsContext;
	private Queue sQueue;
	private Queue rQueue;
	private long timeout;

	@Override
	public Arguments getDefaultParameters() {
		Arguments arguments = new Arguments();
		arguments.addArgument(WMQConstants.WMQ_SHARE_CONV_ALLOWED, String.valueOf(WMQConstants.WMQ_SHARE_CONV_ALLOWED_NO));
		arguments.addArgument(WMQConstants.WMQ_HOST_NAME, "43.200.13.107");
		arguments.addArgument(WMQConstants.WMQ_PORT, "1414");
		arguments.addArgument(WMQConstants.WMQ_QUEUE_MANAGER, "QM1");
		arguments.addArgument(WMQConstants.WMQ_CHANNEL, "DEV.APP.SVRCONN");
		arguments.addArgument(WMQConstants.USERID, "app");
		arguments.addArgument(WMQConstants.PASSWORD, "passw0rd");
//		arguments.addArgument("XMSC_QUEUE_PRODUCER", "queue:///TSSIAKCG.KCG.IFT.CMN?putAsyncAllowed=1");
		arguments.addArgument("XMSC_QUEUE_PRODUCER", "queue:///TSSIAKCG.KCG.IFT.CMN");
		arguments.addArgument("XMSC_QUEUE_CONSUMER", "queue:///TSSIAKCG.KCG.FRW.CMN");
		arguments.addArgument("XMSC_QUEUE_CONSUMER_TIMEOUT", "10000");
		String message = StringUtils.replace("LVBKCG20240822140712000040050200000200   05700320240822000000000000080001011000     00000000001000ＫＦＴＣＪＰ　　　　ＪＰＫＦＴＣ　　　　ＪＰＫＦＴＴＥ　　　00000000100000000000000020240820000000000000000000000000000000000000000000000000000000000000", "20240822", LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		arguments.addArgument("XMSC_MESSAGE", message);
//		arguments.addArgument(WMQConstants.WMQ_SSL_CIPHER_SUITE, "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384");
		return arguments;
	}

	@Override
	public void setupTest(JavaSamplerContext context) {
		try {
			JmsFactoryFactory jmsFactoryFactory = JmsFactoryFactory.getInstance(WMQConstants.JAKARTA_WMQ_PROVIDER);
			JmsConnectionFactory jmsConnectionFactory = jmsFactoryFactory.createConnectionFactory();
			jmsConnectionFactory.setIntProperty(WMQConstants.WMQ_SHARE_CONV_ALLOWED, NumberUtils.toInt(context.getParameter(WMQConstants.WMQ_SHARE_CONV_ALLOWED)));
			jmsConnectionFactory.setStringProperty(WMQConstants.WMQ_APPLICATIONNAME, "jmeter");
			jmsConnectionFactory.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
			jmsConnectionFactory.setStringProperty(WMQConstants.WMQ_HOST_NAME, context.getParameter(WMQConstants.WMQ_HOST_NAME));
			jmsConnectionFactory.setIntProperty(WMQConstants.WMQ_PORT, NumberUtils.toInt(context.getParameter(WMQConstants.WMQ_PORT)));
			jmsConnectionFactory.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, context.getParameter(WMQConstants.WMQ_QUEUE_MANAGER));
			jmsConnectionFactory.setStringProperty(WMQConstants.WMQ_CHANNEL, context.getParameter(WMQConstants.WMQ_CHANNEL));
			jmsConnectionFactory.setStringProperty(WMQConstants.USERID, context.getParameter(WMQConstants.USERID));
			jmsConnectionFactory.setStringProperty(WMQConstants.PASSWORD, context.getParameter(WMQConstants.PASSWORD));
			if (StringUtils.isNotEmpty(System.getProperty("javax.net.ssl.keyStore"))) {
				jmsConnectionFactory.setStringProperty(WMQConstants.WMQ_SSL_CIPHER_SUITE, System.getProperty("javax.net.ssl.cipher.suite", "TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384"));
			}
			jmsContext = jmsConnectionFactory.createContext();
			String sDest = context.getParameter("XMSC_QUEUE_PRODUCER");
			sQueue = jmsContext.createQueue(sDest);
			String rDest = context.getParameter("XMSC_QUEUE_CONSUMER");
			if (StringUtils.isNotEmpty(rDest)) {
				rQueue = jmsContext.createQueue(rDest);
			}
			timeout = NumberUtils.toLong(context.getParameter("XMSC_QUEUE_CONSUMER_TIMEOUT"));
		} catch (Throwable t) {
			// TODO Auto-generated catch block
			if (log.isErrorEnabled()) {
				log.error("setupTest", t);
			}
		}
	}

	@Override
	public void teardownTest(JavaSamplerContext context) {
		try {
			if (null != jmsContext) {
				jmsContext.close();
			}
		} catch (Throwable t) {
			// TODO Auto-generated catch block
			if (log.isErrorEnabled()) {
				log.error("teardownTest", t);
			}
		}
	}

	@Override
	public SampleResult runTest(JavaSamplerContext context) {
		SampleResult sampleResult = new SampleResult();
		sampleResult.setDataEncoding("EUC-KR");
		sampleResult.setDataType(SampleResult.TEXT);
		String data = context.getParameter("XMSC_MESSAGE");
		sampleResult.setSamplerData(data);
		sampleResult.sampleStart();
		try {
			Message message = jmsContext.createTextMessage(data);
			String jmsCorrelationID = String.valueOf(UUID.randomUUID());
			message.setJMSCorrelationID(jmsCorrelationID);
			message.setStringProperty("USRX_USR_ID", "JMETER");
			JMSProducer jmsProducer = jmsContext.createProducer();
			jmsProducer.send(sQueue, message);
//////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			if (null == rQueue || 0L > timeout) {
				sampleResult.sampleEnd();
				sampleResult.setResponseOK();
				sampleResult.setResponseCode("000");
				sampleResult.setResponseData("", "EUC-KR");
				return sampleResult;
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			try (JMSConsumer jmsConsumer = jmsContext.createConsumer(rQueue, StringUtils.join(JmsConstants.JMS_CORRELATIONID, " = '", jmsCorrelationID, "'"))) {
				if (0L < timeout) {
					message = jmsConsumer.receive(timeout);
				}
				else {
					message = jmsConsumer.receive();
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (null == message) {
					sampleResult.sampleEnd();
					sampleResult.setSuccessful(false);
					sampleResult.setResponseCode("999");
					sampleResult.setResponseMessage("ERR");
					sampleResult.setResponseData("", "EUC-KR");
					return sampleResult;
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (message instanceof TextMessage) {
					TextMessage textMessage = (TextMessage) message;
					data = textMessage.getText();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
					String respCd = StringUtils.substring(data, 38, 41);
					if (!StringUtils.equals(respCd, "000")) {
						sampleResult.sampleEnd();
						sampleResult.setSuccessful(false);
						sampleResult.setResponseCode(respCd);
						sampleResult.setResponseMessage(respCd);
						sampleResult.setResponseData(data, "EUC-KR");
						return sampleResult;
					}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
					sampleResult.sampleEnd();
					sampleResult.setResponseOK();
					sampleResult.setResponseCode("000");
					sampleResult.setResponseData(data, "EUC-KR");
				}
			}
		} catch (Throwable t) {
			// TODO Auto-generated catch block
			if (log.isErrorEnabled()) {
				log.error("runTest", t);
			}
			sampleResult.sampleEnd();
			sampleResult.setSuccessful(false);
			sampleResult.setResponseCode("-1");
			sampleResult.setResponseMessage(ExceptionUtils.getRootCauseMessage(t));
			sampleResult.setResponseData(ExceptionUtils.getStackTrace(t), "EUC-KR");
		}
		return sampleResult;
	}

}