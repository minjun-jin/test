package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (당일)입금지시
 * <pre>{@code
 * KftCmsEC23T kftCmsEC23T  = new KftCmsEC23T(); // (당일)입금지시
 * kftCmsEC23T.setRecordType(""); // Record 구분
 * kftCmsEC23T.setSerialNumber(""); // 일련번호
 * kftCmsEC23T.setInstitutionCode(""); // 기관코드
 * kftCmsEC23T.setFileName(""); // File 이름
 * kftCmsEC23T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEC23T.setTotalCountOfWithdrawals(0); // 출금 총 건수
 * kftCmsEC23T.setTotalAmountOfWithdrawals(0L); // 출금 총액
 * kftCmsEC23T.setTotalAmountOfFee(0L); // 수수료 총액
 * kftCmsEC23T.setTotalFeeOfWithdrawalBank(0L); // 출금은행 총 수수료
 * kftCmsEC23T.setTotalFeeOfDepositBank(0L); // 입금은행 총 수수료
 * kftCmsEC23T.setTotalCountOfRequests(0); // 총 의뢰건수 합계
 * kftCmsEC23T.setFiller3(""); // FILLER
 * kftCmsEC23T.setMacValue(""); // MAC 검증값 
 * }</pre>
 */
@Data
public class KftCmsEC23T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int totalCountOfWithdrawals; // 출금 총 건수
	private long totalAmountOfWithdrawals; // 출금 총액
	private long totalAmountOfFee; // 수수료 총액
	private long totalFeeOfWithdrawalBank; // 출금은행 총 수수료
	private long totalFeeOfDepositBank; // 입금은행 총 수수료
	private int totalCountOfRequests; // 총 의뢰건수 합계
	private String filler3; // FILLER
	private String macValue; // MAC 검증값 
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalCountOfWithdrawals$; // 출금 총 건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalAmountOfWithdrawals$; // 출금 총액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalAmountOfFee$; // 수수료 총액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFeeOfWithdrawalBank$; // 출금은행 총 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFeeOfDepositBank$; // 입금은행 총 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalCountOfRequests$; // 총 의뢰건수 합계
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값 

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		totalCountOfWithdrawals$ = VOUtils.write(out, totalCountOfWithdrawals, 8); // 출금 총 건수
		totalAmountOfWithdrawals$ = VOUtils.write(out, totalAmountOfWithdrawals, 13); // 출금 총액
		totalAmountOfFee$ = VOUtils.write(out, totalAmountOfFee, 11); // 수수료 총액
		totalFeeOfWithdrawalBank$ = VOUtils.write(out, totalFeeOfWithdrawalBank, 11); // 출금은행 총 수수료
		totalFeeOfDepositBank$ = VOUtils.write(out, totalFeeOfDepositBank, 11); // 입금은행 총 수수료
		totalCountOfRequests$ = VOUtils.write(out, totalCountOfRequests, 8); // 총 의뢰건수 합계
		filler3$ = VOUtils.write(out, filler3, 43); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값 
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		totalCountOfWithdrawals = VOUtils.toInt(totalCountOfWithdrawals$ = VOUtils.read(in, 8)); // 출금 총 건수
		totalAmountOfWithdrawals = VOUtils.toLong(totalAmountOfWithdrawals$ = VOUtils.read(in, 13)); // 출금 총액
		totalAmountOfFee = VOUtils.toLong(totalAmountOfFee$ = VOUtils.read(in, 11)); // 수수료 총액
		totalFeeOfWithdrawalBank = VOUtils.toLong(totalFeeOfWithdrawalBank$ = VOUtils.read(in, 11)); // 출금은행 총 수수료
		totalFeeOfDepositBank = VOUtils.toLong(totalFeeOfDepositBank$ = VOUtils.read(in, 11)); // 입금은행 총 수수료
		totalCountOfRequests = VOUtils.toInt(totalCountOfRequests$ = VOUtils.read(in, 8)); // 총 의뢰건수 합계
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 43)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값 
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", totalCountOfWithdrawals=").append(totalCountOfWithdrawals).append(System.lineSeparator()); // 출금 총 건수
		sb.append(", totalAmountOfWithdrawals=").append(totalAmountOfWithdrawals).append(System.lineSeparator()); // 출금 총액
		sb.append(", totalAmountOfFee=").append(totalAmountOfFee).append(System.lineSeparator()); // 수수료 총액
		sb.append(", totalFeeOfWithdrawalBank=").append(totalFeeOfWithdrawalBank).append(System.lineSeparator()); // 출금은행 총 수수료
		sb.append(", totalFeeOfDepositBank=").append(totalFeeOfDepositBank).append(System.lineSeparator()); // 입금은행 총 수수료
		sb.append(", totalCountOfRequests=").append(totalCountOfRequests).append(System.lineSeparator()); // 총 의뢰건수 합계
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값 
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalCountOfWithdrawals", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalAmountOfWithdrawals", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "totalAmountOfFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "totalFeeOfWithdrawalBank", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "totalFeeOfDepositBank", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "totalCountOfRequests", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "43", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
