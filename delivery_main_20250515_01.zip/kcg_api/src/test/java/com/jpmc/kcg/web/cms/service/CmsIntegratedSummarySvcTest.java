package com.jpmc.kcg.web.cms.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletResponse;

import com.jpmc.kcg.cms.biz.vo.*;
import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.dao.ComBnkCdMDao;
import com.jpmc.kcg.com.dao.ComBnkCdMMapper;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwTractId;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.cms.dao.CmsCorpInfoDtlMWebDao;
import com.jpmc.kcg.web.cms.dao.CmsIntegratedSummaryWebDao;
import com.jpmc.kcg.web.cms.dto.CmsCorpInfoDtlMWeb;
import com.jpmc.kcg.web.cms.dto.CmsSndRcvFileLWeb;
import com.jpmc.kcg.web.com.constants.ReportConstant;
import com.jpmc.kcg.web.com.dao.ComMltlnDao;
import com.jpmc.kcg.web.com.service.IntegratedSummarySvc;
import com.jpmc.kcg.web.com.service.dto.*;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.ift.dto.SelectReportHeaderIn;
import com.jpmc.kcg.web.ift.dto.SelectReportHeaderOut;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@ExtendWith(MockitoExtension.class)
@Slf4j
class CmsIntegratedSummarySvcTest {

	@InjectMocks
	CmsIntegratedSummarySvc integratedSummarySvc;
	
	@InjectMocks
	IntegratedSummarySvc integratedSummary;

	@Mock
	private CmsIntegratedSummaryWebDao summaryDao;
    @Mock
    private BizCom bizCom;
    @Mock
    private ComBnkCdMMapper comBnkCdMMapper;
    @Mock
    private ComBnkCdMDao comBnkCdMDao;
    @Mock
    private ComMltlnDao comMltlnDao;
    @Mock
    private CmsCorpInfoDtlMWebDao cmsCorpInfoDtlMWebDao;
    @Mock
    private List<SelectReportHeaderOut> mockHeaderList; 

	@Mock FrwTractId frwTractId;
	@Mock
    private WebApplicationContext webApplicationContext;
	
    private MockedStatic<VOUtils> voUtilsMockedStatic;
    
    @BeforeEach
    void setUp() {
    	WebContextImpl webContextImpl = new WebContextImpl();
        Header header = new Header();
        header.setLngCd("ko");
        header.setRoles(List.of(""));
        webContextImpl.setHeader(header);
        FrwContextHolder.setContext(webContextImpl);
        voUtilsMockedStatic = mockStatic(VOUtils.class);
    }

    @AfterEach
    void tearDown() {
        // 테스트가 끝나면 ThreadLocal을 정리하여 다른 테스트에 영향이 없도록 함
        // FrwContextHolder.clearContext();
        
		if (voUtilsMockedStatic != null) {
			voUtilsMockedStatic.close();
		}
    }

	@Test
	void testEB11() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB11);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB11R mockVo = new KftCmsEB11R();
        mockVo.setDataSerialNumber("0000001");
        mockVo.setRequestDate("20240412");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(mockVo);

        CmsCorpInfoDtlMWeb mockCd= new CmsCorpInfoDtlMWeb();
//        mockCd.setRespCdNm("Message Code Name");
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB11Out> EB11Out = result.getReportEB11();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB11Out eb11 = EB11Out.get(0);
        assertEquals("0000001", eb11.getDataSerialNumber());
	}
    
	@Test
	void testEB12() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB12);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB11R mockVo = new KftCmsEB11R();
        mockVo.setDataSerialNumber("0000001");
        mockVo.setRequestDate("20240412");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB11Out> EB12Out = result.getReportEB12();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB11Out eb12 = EB12Out.get(0);
        assertEquals("0000001", eb12.getDataSerialNumber());
	}

	@Test
    void testGetEB12Data_kLessThanRowEB12() {
        // Arrange
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB12);
		in.setSrchDate("20240412");
		
        CmsSndRcvFileLWeb eb11Item = new CmsSndRcvFileLWeb();
        eb11Item.setSeqNo("00000001");
        eb11Item.setTlgCtt("EB11Content1");
        
        CmsSndRcvFileLWeb eb12Item = new CmsSndRcvFileLWeb();
        eb12Item.setSeqNo("00000001");
        eb12Item.setTlgCtt("EB12Content1");
        
        CmsSndRcvFileLWeb eb12Item2 = new CmsSndRcvFileLWeb();
        eb12Item2.setSeqNo("00000002");
        eb12Item2.setTlgCtt("EB12Content2");

        List<CmsSndRcvFileLWeb> EB11List = Collections.singletonList(eb11Item);
        List<CmsSndRcvFileLWeb> EB12List = new ArrayList<>();
        EB12List.add(eb12Item);
        EB12List.add(eb12Item2);

        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(EB11List).thenReturn(EB12List);
        
        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
       List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
       
       when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);

        // 목 객체를 이용한 VOUtils 파싱
       KftCmsEB11R mockVo1 = new KftCmsEB11R();
       mockVo1.setDataSerialNumber("0000001");
       mockVo1.setRequestDate("20240412");
       when(VOUtils.toVo(eq("EB11Content1"), eq(KftCmsEB11R.class))).thenReturn(mockVo1);
       
       KftCmsEB11R mockVo2 = new KftCmsEB11R();
       mockVo2.setDataSerialNumber("0000001");
       mockVo2.setRequestDate("20240412");
       when(VOUtils.toVo(eq("EB12Content1"), eq(KftCmsEB11R.class))).thenReturn(mockVo2);
        
        // Act
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
        List<IntegratedSummaryEB11Out> EB12Out = result.getReportEB12();
        
        // Assert
        assertNotNull(result);
        assertEquals(1, result.getReportEB12().size()); // Expecting 1 entry to be processed

        // 두 번째 EB12 항목에 대해 'EB11Content1'이 사용되었는지 확인 (k < rowEB12 조건)
        assertEquals("0000001", EB12Out.get(0).getDataSerialNumber());
        
    }
	
	@Test
	void testEB13() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB13);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB11R mockVo = new KftCmsEB11R();
        mockVo.setDataSerialNumber("0000001");
        mockVo.setRequestDate("20240412");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB11Out> EB13Out = result.getReportEB13();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB11Out eb13 = EB13Out.get(0);
        assertEquals("0000001", eb13.getDataSerialNumber());
	}

	@Test
	void testEB14() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB14);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB11R mockVo = new KftCmsEB11R();
        mockVo.setDataSerialNumber("0000001");
        mockVo.setRequestDate("20240412");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB11Out> EB14Out = result.getReportEB14();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB11Out eb14 = EB14Out.get(0);
        assertEquals("0000001", eb14.getDataSerialNumber());
	}
	

	@Test
	void testEB21() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB21);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB21Out> EB21Out = result.getReportEB21();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB21Out eb21 = EB21Out.get(0);
        assertEquals("0000001", eb21.getDataSerialNumber());
	}
	

	@Test
	void testEC21() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EC21);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB21Out> EC21Out = result.getReportEC21();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB21Out ec21 = EC21Out.get(0);
        assertEquals("0000001", ec21.getDataSerialNumber());
	}
	
	@Test
	void testEB22() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB22);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB21Out> EB22Out = result.getReportEB22();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB21Out eb22 = EB22Out.get(0);
        assertEquals("0000001", eb22.getDataSerialNumber());
	}
	
	@Test
	void testEC22() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EC22);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB21Out> EC22Out = result.getReportEC22();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB21Out ec22 = EC22Out.get(0);
        assertEquals("0000001", ec22.getDataSerialNumber());
	}
	
	@Test
	void testEB23() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB23);
		in.setSrchDate("20240412");

        // 목 객체 설정      
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB23R mockVo = new KftCmsEB23R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB23R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB23Out> EB23Out = result.getReportEB23();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB23Out eb23 = EB23Out.get(0);
        assertEquals("0000001", eb23.getDataSerialNumber());
	}
	
	@Test
	void testEC23() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EC23);
		in.setSrchDate("20240412");

        // 목 객체 설정      
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB23R mockVo = new KftCmsEB23R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB23R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB23Out> EC23Out = result.getReportEC23();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB23Out ec23 = EC23Out.get(0);
        assertEquals("0000001", ec23.getDataSerialNumber());
	}
	
	@Test
	void testPrintEB23Summary() throws Exception {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
	    in.setReportId(ReportConstant.EB23);
	    in.setSrchDate("20240412");

	    // 목 객체 설정
	    CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
	    mapperIn.setCorpCd("testCorpCd"); // 더미 값 설정
	    List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
	    when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);

	    // 더미 데이터 준비
	    CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
	    mockData.setTlgCtt("mockTlgCtt");
	    mockData.setTrDt("20240412");
	    List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
	    when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(mockOutList);

	    // 엑셀 파일 경로 설정
	    String fileSaveNm = ReportConstant.REPORTNM_EB23_KR;

	    // VOUtils.toVo에 대한 목 설정
	    KftCmsEB23R mockVo = new KftCmsEB23R();
	    mockVo.setDataSerialNumber("0000001");
	    mockVo.setInstitutionCode("testInstitutionCode");
	    mockVo.setMainBankBranchCode("testBankBranch");
	    mockVo.setDepositAccountNumber("1234567890");
	    mockVo.setCountOfTotalWithdrawals(5);
	    mockVo.setAmountOfTotalWithdrawals(100000);
	    mockVo.setWithdrawalBankFee(1000);
	    mockVo.setDepositBankFee(500);
	    when(VOUtils.toVo(any(String.class), eq(KftCmsEB23R.class))).thenReturn(mockVo);

	    // MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
	    
	    // 테스트 실행
	    integratedSummarySvc.printEB23Summary(in, mockResponse);

	    // 결과 검증
	    verify(summaryDao).selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class));
	    verify(cmsCorpInfoDtlMWebDao).getCorpInfoList(any(CmsCorpInfoDtlMWeb.class));
	    
	    // 응답 내용 검증
	    byte[] responseContent = mockResponse.getContentAsByteArray();
	    assertNotNull(responseContent);
	    assertTrue(responseContent.length > 0);  // 내용이 제대로 생성되었는지 확인
	    
	    // 파일명 검증
	    String contentDisposition = mockResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION);
	    assertNotNull(contentDisposition);
	    assertTrue(contentDisposition.contains("attachment"));
	    assertTrue(contentDisposition.contains(fileSaveNm));
	}
	
	@Test
	void testPrintEC23Summary() throws Exception {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
	    in.setReportId(ReportConstant.EC23);
	    in.setSrchDate("20240412");

	    // 목 객체 설정
	    CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
	    mapperIn.setCorpCd("testCorpCd"); // 더미 값 설정
	    List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
	    when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);

	    // 더미 데이터 준비
	    CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
	    mockData.setTlgCtt("mockTlgCtt");
	    mockData.setTrDt("20240412");
	    List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
	    when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(mockOutList);

	    // 엑셀 파일 경로 설정
	    String fileSaveNm = ReportConstant.REPORTNM_EC23_KR;

	    // VOUtils.toVo에 대한 목 설정
	    KftCmsEB23R mockVo = new KftCmsEB23R();
	    mockVo.setDataSerialNumber("0000001");
	    mockVo.setInstitutionCode("testInstitutionCode");
	    mockVo.setMainBankBranchCode("testBankBranch");
	    mockVo.setDepositAccountNumber("1234567890");
	    mockVo.setCountOfTotalWithdrawals(5);
	    mockVo.setAmountOfTotalWithdrawals(100000);
	    mockVo.setWithdrawalBankFee(1000);
	    mockVo.setDepositBankFee(500);
	    when(VOUtils.toVo(any(String.class), eq(KftCmsEB23R.class))).thenReturn(mockVo);

	    // MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
	    
	    // 테스트 실행
	    integratedSummarySvc.printEB23Summary(in, mockResponse);

	    // 결과 검증
	    verify(summaryDao).selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class));
	    verify(cmsCorpInfoDtlMWebDao).getCorpInfoList(any(CmsCorpInfoDtlMWeb.class));
	    
	    // 응답 내용 검증
	    byte[] responseContent = mockResponse.getContentAsByteArray();
	    assertNotNull(responseContent);
	    assertTrue(responseContent.length > 0);  // 내용이 제대로 생성되었는지 확인
	    
	    // 파일명 검증
	    String contentDisposition = mockResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION);
	    assertNotNull(contentDisposition);
	    assertTrue(contentDisposition.contains("attachment"));
	    assertTrue(contentDisposition.contains(fileSaveNm));
	}
	
	@Test
	void testEB31() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB31);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB31R mockVo = new KftCmsEB31R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB31R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB31Out> EB31Out = result.getReportEB31();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB31Out eb31 = EB31Out.get(0);
        assertEquals("0000001", eb31.getDataSerialNumber());
	}
	

	@Test
	void testEB32() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB32);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB31R mockVo = new KftCmsEB31R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB31R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB31Out> EB32Out = result.getReportEB32();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB31Out eb32 = EB32Out.get(0);
        assertEquals("0000001", eb32.getDataSerialNumber());
	}
	
	@Test
	void testEB33() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB33);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB33R mockVo = new KftCmsEB33R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB33R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB33Out> EB33Out = result.getReportEB33();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB33Out eb33 = EB33Out.get(0);
        assertEquals("0000001", eb33.getDataSerialNumber());
	}
	
	@Test
	void testEB34() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB34);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB33R mockVo = new KftCmsEB33R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB33R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB33Out> EB34Out = result.getReportEB34();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB33Out eb34 = EB34Out.get(0);
        assertEquals("0000001", eb34.getDataSerialNumber());
	}
	

	@Test
	void testEB35() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB35);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB35R mockVo = new KftCmsEB35R();
        mockVo.setDataSerialNumber("0000001");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB35R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB35Out> EB35Out = result.getReportEB35();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB35Out eb35 = EB35Out.get(0);
        assertEquals("0000001", eb35.getDataSerialNumber());
	}
	
	@Test
	void testPrintEB35Trailer() throws Exception {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
	    in.setReportId(ReportConstant.EB35);
	    in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 101
	    CmsSndRcvFileLWeb selectIn = new CmsSndRcvFileLWeb();
	    selectIn.setTrDt("20240412"); // 실제 호출될 값과 일치하도록 설정
	    selectIn.setFileNm("EB35");
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("101");
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
	    assertNotNull(result);
	    assertEquals(1, result.getTotCnt());
	    
	 // 데이터 세팅: summaryDao.selectEB35THeader 리턴값 설정
        SelectReportHeaderIn headerIn = new SelectReportHeaderIn();
        headerIn.setLngCd(WebApplicationContext.getHeader().getLngCd());
        
        List<SelectReportHeaderOut> mockHeaders = new ArrayList<>();
        SelectReportHeaderOut header1 = new SelectReportHeaderOut();
        header1.setFldNm("Header1");
        mockHeaders.add(header1);
        SelectReportHeaderOut header2 = new SelectReportHeaderOut();
        header2.setFldNm("Header2");
        mockHeaders.add(header2);

        when(summaryDao.selectEB35THeader(headerIn)).thenReturn(mockHeaders);

//        // 데이터 세팅: summaryDao.selectCmsTlgCtt 리턴값 설정
        CmsSndRcvFileLWeb mockCmsSndRcvFileLWeb = new CmsSndRcvFileLWeb();
        mockCmsSndRcvFileLWeb.setTlgCtt("testData");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockCmsSndRcvFileLWeb);
        when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(mockOutList);

        // VOUtils.toVo에 대한 목 설정
        KftCmsEB35T mockVo = new KftCmsEB35T();
        mockVo.setRecordType("testRecord");
        mockVo.setSerialNumber("123456");
        mockVo.setInstitutionCode("testInstitution");
        mockVo.setFileName("testFile");
        mockVo.setTotalDataRecordCount(100);
        mockVo.setTotalFailedDepositCount(2);
        mockVo.setTotalFailedDepositAmount(5000);
        mockVo.setFiller3("testFiller");
        mockVo.setMacValue("testMac");
        when(VOUtils.toVo(anyString(), eq(KftCmsEB35T.class))).thenReturn(mockVo);

     // MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
	    
        // 테스트 실행
        integratedSummarySvc.printEB35TrailerData(in, mockResponse);

        // 파일이 성공적으로 생성되었는지 검증
        byte[] responseContent = mockResponse.getContentAsByteArray();
        assertNotNull(responseContent);
        assertTrue(responseContent.length > 0, "엑셀 파일 데이터가 비어있지 않음을 확인");

        // 파일 이름을 확인
        String contentDisposition = mockResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION);
        assertNotNull(contentDisposition);
        assertTrue(contentDisposition.contains("attachment"));
        assertTrue(contentDisposition.contains(ReportConstant.REPORTNM_EB35_T));
        
        // 엑셀 파일이 제대로 작성되었는지 확인
        try (Workbook workbook = new XSSFWorkbook(new ByteArrayInputStream(responseContent))) {
            Sheet sheet = workbook.getSheetAt(0);
            assertNotNull(sheet, "엑셀 시트가 생성되었음을 확인");
            Row headerRow = sheet.getRow(0);
            assertNotNull(headerRow, "헤더가 제대로 생성되었음을 확인");

            // 헤더 검증
            assertEquals("Header1", headerRow.getCell(0).getStringCellValue());
            assertEquals("Header2", headerRow.getCell(1).getStringCellValue());

            // 데이터 행 검증
            Row rowData = sheet.getRow(1);
            assertNotNull(rowData);
            assertEquals("testRecord", rowData.getCell(0).getStringCellValue());
            assertEquals("123456", rowData.getCell(1).getStringCellValue());
            assertEquals("testInstitution", rowData.getCell(2).getStringCellValue());
            assertEquals("testFile", rowData.getCell(3).getStringCellValue());
            assertEquals("100", rowData.getCell(4).getStringCellValue()); // 쉼표 처리된 값
        }
	}

	@Test
	void testEB00() {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB00);
		in.setSrchDate("20240412");
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB00R mockVo = new KftCmsEB00R();
        mockVo.setSettlementOrderTypeCode("EB00");
        
        // VOUtils를 목으로 대체
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB00R.class))).thenReturn(mockVo);
        
        // 테스트 실행
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB00Out> EB00Out = result.getReportEB00();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB00Out eb00 = EB00Out.get(0);
        assertEquals("EB00", eb00.getSettlementOrderTypeCode());
	}
	
	@Test
	void testPrintEB00Summary() throws Exception {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
	    in.setReportId(ReportConstant.EB00);
	    in.setSrchDate("20240412");

	    // 더미 데이터 준비
	    CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
	    mockData.setTlgCtt("mockTlgCtt");
	    mockData.setTrDt("20240412");
	    List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
	    when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(mockOutList);

	    // 엑셀 파일 경로 설정
	    String fileSaveNm = ReportConstant.REPORTNM_EB00_KR;

	    // VOUtils.toVo에 대한 목 설정
	    KftCmsEB00R mockVo = new KftCmsEB00R();
	    mockVo.setDataSerialNumber("0000001");
	    mockVo.setInstitutionCode("testInstitutionCode");
	    mockVo.setSettlementOrderTypeCode("EB00");
	    when(VOUtils.toVo(any(String.class), eq(KftCmsEB00R.class))).thenReturn(mockVo);

	    // MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
	    
	    // 테스트 실행
	    integratedSummarySvc.printEB00Summary(in, mockResponse);

	    // 결과 검증
	    verify(summaryDao).selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class));
//	    verify(cmsCorpInfoDtlMWebDao).getCorpInfoList(any(CmsCorpInfoDtlMWeb.class));
	    
	    // 응답 내용 검증
	    byte[] responseContent = mockResponse.getContentAsByteArray();
	    assertNotNull(responseContent);
	    assertTrue(responseContent.length > 0);  // 내용이 제대로 생성되었는지 확인
	    
	    // 파일명 검증
	    String contentDisposition = mockResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION);
	    assertNotNull(contentDisposition);
	    assertTrue(contentDisposition.contains("attachment"));
	    assertTrue(contentDisposition.contains(fileSaveNm));
	}
	@Test
	void testPrintEB00Summary_EB50() throws Exception {
		IntegratedSummaryIn in = new IntegratedSummaryIn();
	    in.setReportId(ReportConstant.EB00);
	    in.setSrchDate("20240412");

	    // 더미 데이터 준비
	    CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
	    mockData.setTlgCtt("mockTlgCtt");
	    mockData.setTrDt("20240412");
	    List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
	    when(summaryDao.selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class))).thenReturn(mockOutList);

	    // 엑셀 파일 경로 설정
	    String fileSaveNm = ReportConstant.REPORTNM_EB00_KR;

	    // VOUtils.toVo에 대한 목 설정
	    KftCmsEB00R mockVo = new KftCmsEB00R();
	    mockVo.setDataSerialNumber("0000001");
	    mockVo.setInstitutionCode("testInstitutionCode");
	    mockVo.setSettlementOrderTypeCode("EB50");
	    when(VOUtils.toVo(any(String.class), eq(KftCmsEB00R.class))).thenReturn(mockVo);

	    // MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
	    
	    // 테스트 실행
	    integratedSummarySvc.printEB00Summary(in, mockResponse);

	    // 결과 검증
	    verify(summaryDao).selectCmsTlgCtt(any(CmsSndRcvFileLWeb.class));
//	    verify(cmsCorpInfoDtlMWebDao).getCorpInfoList(any(CmsCorpInfoDtlMWeb.class));
	    
	    // 응답 내용 검증
	    byte[] responseContent = mockResponse.getContentAsByteArray();
	    assertNotNull(responseContent);
	    assertTrue(responseContent.length > 0);  // 내용이 제대로 생성되었는지 확인
	    
	    // 파일명 검증
	    String contentDisposition = mockResponse.getHeader(HttpHeaders.CONTENT_DISPOSITION);
	    assertNotNull(contentDisposition);
	    assertTrue(contentDisposition.contains("attachment"));
	    assertTrue(contentDisposition.contains(fileSaveNm));
	}
	
	// reportId가 없을 때 예외 테스트
    @Test
    void testNoReportId_getIntegratedSummary() {
    	// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(null);
		in.setSrchDate("20240412");
		
		BusinessException exception = assertThrows(BusinessException.class, 
	            () -> integratedSummarySvc.getIntegratedSummary(in));
	        assertEquals("MCMNE01002", exception.getErrorCode());
    }
    
    @Test
    void testNoReportId_printEB00() {
    	// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(null);
		in.setSrchDate("20240412");
		
		// MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
		
		BusinessException exception = assertThrows(BusinessException.class, 
	            () -> integratedSummarySvc.printEB00Summary(in, mockResponse));
	        assertEquals("MCMNE01002", exception.getErrorCode());
    }
    
    @Test
    void testNoReportId_printEB23() {
    	// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(null);
		in.setSrchDate("20240412");
		
		// MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
		
		BusinessException exception = assertThrows(BusinessException.class, 
	            () -> integratedSummarySvc.printEB23Summary(in, mockResponse));
	        assertEquals("MCMNE01002", exception.getErrorCode());
    }

    @Test
    void testNoReportId_printEB35Trailer() {
    	// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(null);
		in.setSrchDate("20240412");
		
		// MockHttpServletResponse 설정 (파일 다운로드를 위한 응답 객체)
	    MockHttpServletResponse mockResponse = new MockHttpServletResponse();
		
		BusinessException exception = assertThrows(BusinessException.class, 
	            () -> integratedSummarySvc.printEB35TrailerData(in, mockResponse));
	        assertEquals("MCMNE01002", exception.getErrorCode());
    }

    // 데이터 개수 반환값이 '111'이 아닌 경우
	@Test
	void test_getEB11Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB11);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB11().isEmpty());
	}
	
	@Test
	void test_getEB00Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB00);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB00().isEmpty());
	}
	
	@Test
	void test_getEB12Data_noData_101() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB12);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("101");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB12().isEmpty());
	}
	
	@Test
	void test_getEB12Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB12);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB12().isEmpty());
	}
	
	@Test
	void test_getEB13Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB13);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB13().isEmpty());
	}
	
	@Test
	void test_getEB14Data_noData_101() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB14);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("101");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB14().isEmpty());
	}
	
	@Test
	void test_getEB14Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB14);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB14().isEmpty());
	}
	
	@Test
	void test_getEB21Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB21);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB21().isEmpty());
	}
	
	@Test
	void test_getEB22Data_noData_101() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB22);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("101");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB22().isEmpty());
	}
	
	@Test
	void test_getEB22Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB22);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB22().isEmpty());
	}
	
	@Test
	void test_getEB23Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB23);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB23().isEmpty());
	}
	
	@Test
	void test_getEB31Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB31);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB31().isEmpty());
	}
	
	@Test
	void test_getEB32Data_noData_101() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB32);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("101");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB32().isEmpty());
	}
	
	@Test
	void test_getEB32Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB32);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB32().isEmpty());
	}
	
	@Test
	void test_getEB33Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB33);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB33().isEmpty());
	}
	
	@Test
	void test_getEB35Data_noData() throws IOException {
		// Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB35);
		in.setSrchDate("20240412");

	    // Mock 데이터 설정: 데이터 개수 반환값이 111이 아님
	    when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("0");

	    // When: 메서드 호출
	    IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

	    // Then: 결과 검증
	    assertNotNull(result);
	    assertTrue(result.getReportEB35().isEmpty());
	}
	
	// 유효하지 않은 숫자 문자열로 NumberFormatException 발생 테스트
    @Test
    void testAddCommasToNumber_withInvalidNumericString() {
        // Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB21);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        mockData.setReqAmt("INVALID_NUMBER");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        // Act & Assert
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, 
            () -> integratedSummarySvc.getIntegratedSummary(in));
        assertEquals("Input string is not a valid integer.", exception.getMessage());
    }
   
    @Test
    void testAddCommasToNumber_withNumericString() {
        // Arrange
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
		in.setReportId(ReportConstant.EB21);
		in.setSrchDate("20240412");

        // 목 객체 설정
		 CmsCorpInfoDtlMWeb mapperIn = new CmsCorpInfoDtlMWeb();
		 mapperIn.setCorpCd("testCorpCd"); 
        List<CmsCorpInfoDtlMWeb> mockCorpList = Collections.singletonList(mapperIn);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any(CmsCorpInfoDtlMWeb.class))).thenReturn(mockCorpList);
        
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        mockData.setReqAmt("1234567");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
        
        when(summaryDao.countData(any(CmsSndRcvFileLWeb.class))).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);

        // 목 객체를 이용한 VOUtils 파싱
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);

        List<IntegratedSummaryEB21Out> EB21Out = result.getReportEB21();
        
        // 결과 검증
        assertNotNull(result);
        assertEquals(1, result.getTotCnt());

        IntegratedSummaryEB21Out eb21 = EB21Out.get(0);
        assertEquals("1,234,567", eb21.getReqAmt());
    }
    
    @Test
    void test_getIntegratedSummary_makeDate_fail() {
        IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId(ReportConstant.EB11);
        in.setSrchDate("20240412");
    
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
    
        when(summaryDao.countData(any())).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);
    
        KftCmsEB11R mockVo = new KftCmsEB11R();
        mockVo.setRequestDate("INVALID"); // yyMMdd 형식 아님
        mockVo.setDataSerialNumber("0000001");
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(mockVo);
//        when(VOUtils.toVo(anyString(), any(KftCmsEB11R.class))).thenReturn(mockVo);
    
        assertThrows(BusinessException.class, () -> integratedSummarySvc.getIntegratedSummary(in));
    }

    @Test
    void test_getIntegratedSummary_addComma_null_reqAmt() {
        IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId(ReportConstant.EB21);
        in.setSrchDate("20240412");
    
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        mockData.setReqAmt(null); // null 처리 분기 태움
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
    
        when(summaryDao.countData(any())).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);
    
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0000001");
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
    
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
        assertEquals("0", result.getReportEB21().get(0).getReqAmt());
    }
    
    @Test
    void test_getIntegratedSummary_resultCode_no_label() {
        IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId(ReportConstant.EB21);
        in.setSrchDate("20240412");
    
        CmsSndRcvFileLWeb mockData = new CmsSndRcvFileLWeb();
        mockData.setTlgCtt("mockTlgCtt");
        mockData.setReqAmt("10000");
        List<CmsSndRcvFileLWeb> mockOutList = Collections.singletonList(mockData);
    
        when(summaryDao.countData(any())).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(mockOutList);
    
        KftCmsEB21R mockVo = new KftCmsEB21R();
        mockVo.setDataSerialNumber("0001");
        mockVo.setWithdrawalResultWithdrawalYn("Y"); // 있지만 라벨 없음
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB21R.class))).thenReturn(mockVo);
        when(comMltlnDao.selectMltlnCdList(any())).thenReturn(new ArrayList<>()); // empty → Optional.empty()
    
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
        assertTrue(result.getReportEB21().get(0).getWithdrawalResultWithdrawalYn().startsWith("Y"));
    }

    @Test
    void test_getIntegratedSummary_unhandled_reportId() {
        IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId("UNKNOWN_ID");
        in.setSrchDate("20240412");
    
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
        assertNotNull(result);
        assertEquals("UNKNOWN_ID", result.getFileId()); // exception 없이 동작함
    }
    
    @Test
    void test_getEB14Data_seqNo_mismatch() {
        IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId(ReportConstant.EB14);
        in.setSrchDate("20240412");
    
        CmsSndRcvFileLWeb eb13Item = new CmsSndRcvFileLWeb();
        eb13Item.setTlgCtt("EB13Content");
        eb13Item.setSeqNo("1111");
    
        CmsSndRcvFileLWeb eb14Item = new CmsSndRcvFileLWeb();
        eb14Item.setTlgCtt("EB14Content");
        eb14Item.setSeqNo("9999");
    
        when(summaryDao.countData(any())).thenReturn("111");
        when(summaryDao.selectCmsTlgCtt(any())).thenReturn(List.of(eb13Item)).thenReturn(List.of(eb14Item));
    
        KftCmsEB11R vo = new KftCmsEB11R();
        vo.setDataSerialNumber("0001");
        when(VOUtils.toVo(Mockito.nullable(String.class), eq(KftCmsEB11R.class))).thenReturn(vo);
        
        when(cmsCorpInfoDtlMWebDao.getCorpInfoList(any())).thenReturn(Collections.emptyList());
        when(comMltlnDao.selectMltlnCdList(any())).thenReturn(Collections.emptyList());
    
        IntegratedSummaryOut result = integratedSummarySvc.getIntegratedSummary(in);
        assertEquals(1, result.getReportEB14().size()); // SeqNo 달라도 기본은 EB13 기준으로 1건
    }


}

