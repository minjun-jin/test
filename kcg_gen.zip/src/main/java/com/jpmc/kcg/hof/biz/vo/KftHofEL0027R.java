package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 한은금융망 연계 타행이체 및 반대거래 미완료 내역
 * <pre>{@code
 * KftHofEL0027R kftHofEL0027R  = new KftHofEL0027R(); // 한은금융망 연계 타행이체 및 반대거래 미완료 내역
 * kftHofEL0027R.setFileName(""); // 업무구분
 * kftHofEL0027R.setDataType(""); // 데이타구분
 * kftHofEL0027R.setSerialNumber(""); // 일련번호
 * kftHofEL0027R.setTransactionIdNumber(""); // 거래고유번호
 * kftHofEL0027R.setTransactionCode(""); // 거래구분코드
 * kftHofEL0027R.setRequestBankCode(""); // 취급기관코드
 * kftHofEL0027R.setRequestBranchCode(""); // 취급기관ㆍ점별코드
 * kftHofEL0027R.setBeneficiaryBankCode(""); // 개설기관코드
 * kftHofEL0027R.setBeneficiaryBranchCode(""); // 개설기관ㆍ점별코드
 * kftHofEL0027R.setBeneficiaryAccountNumber(""); // 수취계좌번호
 * kftHofEL0027R.setTransactionAmount(0L); // 거래금액
 * kftHofEL0027R.setWithdrawer(""); // 출금인
 * kftHofEL0027R.setBeneficiaryName(""); // 수취인
 * kftHofEL0027R.setMediaType(""); // 매체구분
 * kftHofEL0027R.setFundType(""); // 자금성격
 * kftHofEL0027R.setRequestorInformation(""); // 의뢰인정보
 * kftHofEL0027R.setWithdrawalAccountNumber(""); // 출금계좌번호
 * kftHofEL0027R.setRealSenderName(""); // 송금인실명
 * kftHofEL0027R.setHbkWireTransferSerialNumber(""); // 한은금융망자금이체일련번호
 * kftHofEL0027R.setFiller(""); // FILLER
 * kftHofEL0027R.setHbkWireApplicationTime(""); // 한은금융망신청시간
 * kftHofEL0027R.setHbkWirePaymentTime(""); // 한은금융망결제시간
 * kftHofEL0027R.setHbkWirePaymentMethod(""); // 한은금융망결제방법
 * kftHofEL0027R.setOriginalTransactionIDNumber(""); // 원거래거래고유번호
 * kftHofEL0027R.setOriginalTransactionFundTransferSerialNumber(""); // 원거래자금이체일련번호
 * kftHofEL0027R.setFiller1(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0027R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String transactionIdNumber; // 거래고유번호
	private String transactionCode; // 거래구분코드
	private String requestBankCode; // 취급기관코드
	private String requestBranchCode; // 취급기관ㆍ점별코드
	private String beneficiaryBankCode; // 개설기관코드
	private String beneficiaryBranchCode; // 개설기관ㆍ점별코드
	private String beneficiaryAccountNumber; // 수취계좌번호
	private long transactionAmount; // 거래금액
	private String withdrawer; // 출금인
	private String beneficiaryName; // 수취인
	private String mediaType; // 매체구분
	private String fundType; // 자금성격
	private String requestorInformation; // 의뢰인정보
	private String withdrawalAccountNumber; // 출금계좌번호
	private String realSenderName; // 송금인실명
	private String hbkWireTransferSerialNumber; // 한은금융망자금이체일련번호
	private String filler; // FILLER
	private String hbkWireApplicationTime; // 한은금융망신청시간
	private String hbkWirePaymentTime; // 한은금융망결제시간
	private String hbkWirePaymentMethod; // 한은금융망결제방법
	private String originalTransactionIDNumber; // 원거래거래고유번호
	private String originalTransactionFundTransferSerialNumber; // 원거래자금이체일련번호
	private String filler1; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankCode$; // 취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionAmount$; // 거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawer$; // 출금인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mediaType$; // 매체구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금성격
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestorInformation$; // 의뢰인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realSenderName$; // 송금인실명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireTransferSerialNumber$; // 한은금융망자금이체일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireApplicationTime$; // 한은금융망신청시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWirePaymentTime$; // 한은금융망결제시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWirePaymentMethod$; // 한은금융망결제방법
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalTransactionIDNumber$; // 원거래거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalTransactionFundTransferSerialNumber$; // 원거래자금이체일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		requestBankCode$ = VOUtils.write(out, requestBankCode, 3); // 취급기관코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 7); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취계좌번호
		transactionAmount$ = VOUtils.write(out, transactionAmount, 14); // 거래금액
		withdrawer$ = VOUtils.write(out, withdrawer, 20, "EUC-KR"); // 출금인
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인
		mediaType$ = VOUtils.write(out, mediaType, 2); // 매체구분
		fundType$ = VOUtils.write(out, fundType, 2); // 자금성격
		requestorInformation$ = VOUtils.write(out, requestorInformation, 32); // 의뢰인정보
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		realSenderName$ = VOUtils.write(out, realSenderName, 20, "EUC-KR"); // 송금인실명
		hbkWireTransferSerialNumber$ = VOUtils.write(out, hbkWireTransferSerialNumber, 5); // 한은금융망자금이체일련번호
		filler$ = VOUtils.write(out, filler, 9); // FILLER
		hbkWireApplicationTime$ = VOUtils.write(out, hbkWireApplicationTime, 6); // 한은금융망신청시간
		hbkWirePaymentTime$ = VOUtils.write(out, hbkWirePaymentTime, 6); // 한은금융망결제시간
		hbkWirePaymentMethod$ = VOUtils.write(out, hbkWirePaymentMethod, 1); // 한은금융망결제방법
		originalTransactionIDNumber$ = VOUtils.write(out, originalTransactionIDNumber, 13); // 원거래거래고유번호
		originalTransactionFundTransferSerialNumber$ = VOUtils.write(out, originalTransactionFundTransferSerialNumber, 5); // 원거래자금이체일련번호
		filler1$ = VOUtils.write(out, filler1, 259); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		requestBankCode = VOUtils.toString(requestBankCode$ = VOUtils.read(in, 3)); // 취급기관코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취계좌번호
		transactionAmount = VOUtils.toLong(transactionAmount$ = VOUtils.read(in, 14)); // 거래금액
		withdrawer = VOUtils.toString(withdrawer$ = VOUtils.read(in, 20, "EUC-KR")); // 출금인
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인
		mediaType = VOUtils.toString(mediaType$ = VOUtils.read(in, 2)); // 매체구분
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금성격
		requestorInformation = VOUtils.toString(requestorInformation$ = VOUtils.read(in, 32)); // 의뢰인정보
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		realSenderName = VOUtils.toString(realSenderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송금인실명
		hbkWireTransferSerialNumber = VOUtils.toString(hbkWireTransferSerialNumber$ = VOUtils.read(in, 5)); // 한은금융망자금이체일련번호
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 9)); // FILLER
		hbkWireApplicationTime = VOUtils.toString(hbkWireApplicationTime$ = VOUtils.read(in, 6)); // 한은금융망신청시간
		hbkWirePaymentTime = VOUtils.toString(hbkWirePaymentTime$ = VOUtils.read(in, 6)); // 한은금융망결제시간
		hbkWirePaymentMethod = VOUtils.toString(hbkWirePaymentMethod$ = VOUtils.read(in, 1)); // 한은금융망결제방법
		originalTransactionIDNumber = VOUtils.toString(originalTransactionIDNumber$ = VOUtils.read(in, 13)); // 원거래거래고유번호
		originalTransactionFundTransferSerialNumber = VOUtils.toString(originalTransactionFundTransferSerialNumber$ = VOUtils.read(in, 5)); // 원거래자금이체일련번호
		filler1 = VOUtils.toString(filler1$ = VOUtils.read(in, 259)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", requestBankCode=").append(requestBankCode).append(System.lineSeparator()); // 취급기관코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취계좌번호
		sb.append(", transactionAmount=").append(transactionAmount).append(System.lineSeparator()); // 거래금액
		sb.append(", withdrawer=").append(withdrawer).append(System.lineSeparator()); // 출금인
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인
		sb.append(", mediaType=").append(mediaType).append(System.lineSeparator()); // 매체구분
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금성격
		sb.append(", requestorInformation=").append(requestorInformation).append(System.lineSeparator()); // 의뢰인정보
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", realSenderName=").append(realSenderName).append(System.lineSeparator()); // 송금인실명
		sb.append(", hbkWireTransferSerialNumber=").append(hbkWireTransferSerialNumber).append(System.lineSeparator()); // 한은금융망자금이체일련번호
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", hbkWireApplicationTime=").append(hbkWireApplicationTime).append(System.lineSeparator()); // 한은금융망신청시간
		sb.append(", hbkWirePaymentTime=").append(hbkWirePaymentTime).append(System.lineSeparator()); // 한은금융망결제시간
		sb.append(", hbkWirePaymentMethod=").append(hbkWirePaymentMethod).append(System.lineSeparator()); // 한은금융망결제방법
		sb.append(", originalTransactionIDNumber=").append(originalTransactionIDNumber).append(System.lineSeparator()); // 원거래거래고유번호
		sb.append(", originalTransactionFundTransferSerialNumber=").append(originalTransactionFundTransferSerialNumber).append(System.lineSeparator()); // 원거래자금이체일련번호
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "requestBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "transactionAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "withdrawer", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "mediaType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "requestorInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "realSenderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "hbkWireTransferSerialNumber", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "9", "defltVal", ""),
			Map.of("fld", "hbkWireApplicationTime", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "hbkWirePaymentTime", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "hbkWirePaymentMethod", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "originalTransactionIDNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "originalTransactionFundTransferSerialNumber", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "filler1", "fldLen", "259", "defltVal", "")
		);
	}

}
