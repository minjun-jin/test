package com.jpmc.kcg.hof.biz;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.ThreadUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.hof.biz.vo.KftHof0200450000;
import com.jpmc.kcg.hof.biz.vo.KftHof0210450000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200450000;
import com.jpmc.kcg.hof.dto.HbkTrL;
import com.jpmc.kcg.hof.dto.HbkTransactionIn;
import com.jpmc.kcg.hof.dto.SelectHbkTransactionIn;
import com.jpmc.kcg.hof.enums.FundTypeEnum;
import com.jpmc.kcg.hof.enums.HbkConst;
import com.jpmc.kcg.hof.enums.HbkRespCdEnum;
import com.jpmc.kcg.hof.enums.HofConst;

import lombok.extern.slf4j.Slf4j;

/**
 * 거액타행이체 타발요청 (0200/450000)
 */
@Slf4j
@Component
public class HbkFundsTransferInReqIntf extends FrwServiceBean<KftHof0200450000> {

	@Autowired
	private FrwTemplate frwTemplate;

	@Autowired
	private FrwContext frwContext;

	@Autowired
	private HbkCom hbkCom;
	
	@Autowired
	private BizDate bizDate;
	
	@Autowired
	private BizCom bizCom;
	
	@Autowired
	private ComPshMsgBean comPshMsgBean;
	
	@Autowired
	private ConversionService conversionService;
	
	@Autowired
	private HbkFundsTransferReversalTransactionOutReqIntf hbkFundsTransferReversalTransactionOutReqIntf;

	/**
	 * 제어
	 */
	@Override
	public boolean control(KftHof0200450000 in) {

		// 전문 format validation check 
		int fieldNo = in.validate();
		if (fieldNo > 0) {
			String errCd = StringUtils.leftPad(String.valueOf(fieldNo), 3, ComConst.CHAR_0);
			throw new InternalResponseException(errCd);
		}

		// 전문시간 현재시간과 비교 체크.
		if (!in.getMessageTransmissionDate().format(DateTimeFormatter.BASIC_ISO_DATE)
				.equals(frwContext.getSysTmstmp().format(DateTimeFormatter.BASIC_ISO_DATE))) {
			throw new InternalResponseException(HbkRespCdEnum.RESP_CD_007.getCode());
		}
		
		// 주말, 공휴일일 경우 오류코드로 응답 (413)
		if(!bizDate.isWeekdayBizDay()) {
			throw new InternalResponseException(HbkRespCdEnum.RESP_CD_413.getCode());
		}
		
		// Cut-off Time 체크하여 에러 응답 전송 (413)
		if(hbkCom.checkCutOffTime()) {
			throw new InternalResponseException(HbkRespCdEnum.RESP_CD_413.getCode());
		}
		
		// 출금인 성명이 비어있으면 에러 (413)
		if(StringUtils.isEmpty(in.getWithdrawer())) {
			throw new InternalResponseException(HbkRespCdEnum.RESP_CD_413.getCode());
		}

		return super.control(in);
	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftHof0200450000 in) {
		
		if (log.isDebugEnabled()) {
			log.debug("타발 이체거래 요청 KftHof0200450000 in {}", in);
		}
		
		/**
		 * 1. Cut-off Time 조회
		 * 2. 중복 거래 체크 (거래고유번호)
		 * 3. 계좌상태 체크
		 * 4. 압류 금지 계좌 체크 (439)
		 * 5. 계좌 정상일 경우 HOST로 전문 전송 (HOSTNO채번)
		 * 6. 그외 오류일 경우 KFTC로 전문 전송 (0210)
		 */
		// 중복거래 확인
		SelectHbkTransactionIn selectIn = new SelectHbkTransactionIn();
		selectIn.setTrDt(in.getTraxOccurredDate().format(DateFormat.YYYYMMDD.getFormatter()));
		selectIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_02); // 당발
		selectIn.setHbkTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());

		HbkTrL reqTr = hbkCom.selectHBKTransaction(selectIn);
		
		if(reqTr != null) {
			if(!StringUtils.isEmpty(reqTr.getRespCd())) {
				KftHof0210450000 kcgIn = VOUtils.toVo(frwContext.getTlgCtt(), KftHof0210450000.class);
				kcgIn.setSendReceiveFlag(_getRespFlag(in.getSendReceiveFlag()));
				kcgIn.setMessageType(HbkConst.TLG_KND_DVSN_NO_0210);
				kcgIn.setResponseCode(reqTr.getRespCd());
				frwTemplate.send(FrwDestination.KFT_HOF, kcgIn);
			}
		}else {
			
			//host번호 채번
			String hostNo = bizCom.getNumbering(BizDvsnCdEnum.HBK.toString(), NumberingEnum.HBKLVB01.toString());
			
			// 계좌상태조회
			Map<String, String> acctInfo = bizCom.getAccountValidation(in.getBeneficiaryAccountNumber(),
					BizDvsnCdEnum.HBK.getValue(), ComConst.KFT);
			String rcpntNm = acctInfo.get("rtnAcctNm");
			String rtnAcctStsCd = acctInfo.get("rtnAcctStsCd");
			
			//압류 금지 계좌 체크 (439)
			if (FundTypeEnum.isNonseizableHofFundTr(in.getFundType())) {
				rtnAcctStsCd = HbkRespCdEnum.RESP_CD_439.getCode();
			}
			
			//계좌 정상일 경우 HOST로 전문 전송
			if(rtnAcctStsCd.equals(HbkRespCdEnum.RESP_CD_000.getCode())) {
				
			    //HOST로 전송 (0200/450000)
				LvbHof0200450000 hbkIn = new LvbHof0200450000(); // 타행이체_거액이체

				log.debug("hbkIn 전문vo ==========={}", hbkIn);
				hbkIn.setMsgType(HofConst.KCGLVB);
				hbkIn.setTransactionIdNumber(in.getTransactionIdNumber()); // 거래고유번호
				hbkIn.setBeneficiaryName(in.getBeneficiaryName()); // 거래고유번호
				hbkIn.setBeneficiaryBankCode(in.getBeneficiaryBankCode()); // 수취은행
				hbkIn.setMediaType(in.getMediaType()); // 매체구분
				hbkIn.setFundType(in.getFundType()); // 자금성격
				hbkIn.setRequestorInformation(in.getRequestorInformation()); // 의뢰인정보
				hbkIn.setWithdrawalAccountNumber(in.getWithdrawalAccountNumber()); // 출금계좌번호
				hbkIn.setBeneficiaryAccountNumber(in.getBeneficiaryAccountNumber());
				hbkIn.setMsgNo(hostNo);
				hbkIn.setSystemSendReceiveTime(frwContext.getSysTmstmp());
				hbkIn.setTransactionDate(LocalDate.now());
				hbkIn.setResponseCodeBOK(in.getHbkWireResponseCode()); // 응답코드(한국은행)
				hbkIn.setResponseCodeOpenBank(in.getBeneficiaryBankResponseCode()); // 응답코드(개설은행)
				hbkIn.setRequestBank(in.getHandlingInstitutionRepCode()); // 취급기관대표코드(요청은행)
				hbkIn.setBeneficiaryAmount(in.getTransactionAmount()); // 수취금액
				hbkIn.setSenderName(in.getWithdrawer()); // 출금인(송신자명)
				hbkIn.setBeneficiaryName(rcpntNm); // 수취인명
				hbkIn.setFillerOrRealRemitterName(in.getRealSenderName());  //송금인실명

				String trcId = frwTemplate.send(FrwDestination.LVB_HOF, hbkIn);
				
				//거래내역 insert
				HbkTransactionIn insertIn = _setInsertIn(in);
				insertIn.setRcpntNm(rcpntNm); // 수취인명
				insertIn.setHostNo(hostNo);  
				insertIn.setTrcId(trcId);
				
				hbkCom.insertHBKTransaction(insertIn);
				
			}else {  //그외 오류일 경우 KFTC로 전문 전송 (0210)
				throw new InternalResponseException(rtnAcctStsCd);
			}
			
			//  티볼리 SP 의심계좌
			if (HbkConst.CHANNEL_SP.equals(in.getSuspectedFraudInfo())) {
				try {
					Map<String, Object> paramValList = new Hashtable<>();
					// 에러 메시지 문자열 생성
					String errorMessage = String.format("[I N F O] SUSPICIOUS TRANSACTION RECEIVED [CODE=%s] [KFTC NO=%s]", HbkConst.CHANNEL_SP, in.getTransactionIdNumber());
					paramValList.put("errTlgId", HbkConst.SUSPICIOUS_TRANSACTION_TITLE);
					paramValList.put("errCtt", errorMessage);
					comPshMsgBean.sendAlarm(9, paramValList.get("errTlgId").toString(), paramValList, null, true);
					
					log.info(errorMessage);
				} catch (Exception e2) {
					log.error("Message Request Fail", e2);
				}
			}
			
		}

	} 

	/**
	 * 예외
	 */
	@Override
	public void handleError(KftHof0200450000 in, Throwable t) {
		
		String respCd = "";
		if (t instanceof InternalResponseException e) {
			respCd = e.getRespCd();
		} else {
			respCd = HbkRespCdEnum.RESP_CD_413.getCode();
		}
		
		in.setResponseCode(respCd);
		HbkTransactionIn insertIn = _setInsertIn(in);
		
		/**
		 * 1. KFTC 응답 전송 (0210/450000)
		 * - 한은금융망 응답코드, 결제실패원인, 복합대기순서 초기화
		 * 2. 반대거래 전송  (0200/451000)
		 * 3. 거래내역 insert
		 * 4. 거래집계 update
		 */
		if (respCd.startsWith(ComConst.CHAR_0)) {
			in.setMessageType(HbkConst.TLG_KND_DVSN_NO_9200);
			String trcId = frwTemplate.send(FrwDestination.KFT_HOF, in);
			
			insertIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_9200); // 전문구분
			insertIn.setRespCd(respCd);
			insertIn.setTrcId(trcId);
			insertIn.setTrStsCd(TrStsCdEnum.ERROR.getTrStsCd());
			hbkCom.insertHBKTransaction(insertIn);
			
			try {
				Map<String, Object> paramValList = new Hashtable<>();
				// 에러 메시지 문자열 생성
				String errorMessage = String.format( "Response Code : %s , Transaction Unique Number: %s", respCd, in.getTransactionIdNumber());
				paramValList.put("errTlgId", HbkConst.FORMAT_ERROR_TITLE);
				paramValList.put("errCtt", errorMessage);
				comPshMsgBean.sendAlarm(9, paramValList.get("errTlgId").toString(), paramValList, null, true);
			} catch (Exception e2) {
				log.error("Message Request Fail", e2);
			}
			
		}else {
			KftHof0210450000 kcgIn = conversionService.convert(in, KftHof0210450000.class);
			kcgIn.setMessageType(HbkConst.TLG_KND_DVSN_NO_0210);
			kcgIn.setBeneficiaryBranchCode(HbkConst.JPMC_BANK_CD + HbkConst.JPMC_BRNCH_CD);
			kcgIn.setSendReceiveFlag(_getRespFlag(in.getSendReceiveFlag()));
			kcgIn.setMessageSendTime(LocalTime.now());
			kcgIn.setHbkWireResponseCode(HbkConst.NULL);
			kcgIn.setFiller2(HbkConst.NULL); //한은망 결제실패원인 초기화
			kcgIn.setFiller4(HbkConst.NULL); //한은금융망 복합대기순서 초기화
			
			String mapRespCd = bizCom.getRespCdMap(ComConst.KFT, BizDvsnCdEnum.HOF.getValue(), respCd);
			kcgIn.setResponseCode(mapRespCd);  //코드 맵핑
			log.info("KftHof0210450000 kcgIn 전문vo ==========={}", kcgIn);
			
			String trcId =  frwTemplate.send(FrwDestination.KFT_HOF, kcgIn);
			
			//거래내역 insert 입금은행(JP) 오류가 발생하더라도 RESP_CD는 000으로 셋팅 (입금은행응답코드에 실제 오류응답코드 셋팅)
			insertIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0210); // 전문구분
			insertIn.setRespCd(HbkRespCdEnum.RESP_CD_000.getCode());
			insertIn.setHbkInitInstRespCd(respCd);
			insertIn.setTrcId(trcId);
			insertIn.setTrStsCd(TrStsCdEnum.COMPLETE.getTrStsCd());
			hbkCom.insertHBKTransaction(insertIn);

		}
		
		// 반대거래 요청 (반대거래요청을 먼저 받을 경우 결제원 에러 -> 3초sleep)
		HbkTrL reversalTrInfo = conversionService.convert(insertIn, HbkTrL.class);
		
		ThreadUtils.sleepQuietly(Duration.ofSeconds(3L));
		hbkFundsTransferReversalTransactionOutReqIntf.hbkFundsTransferReversalTransactionOutReq(reversalTrInfo);
		
		// 티볼리 반대거래
		try {
			
			log.info("[F A I L] HBK FUND TRANSFER ERROR RESPONSE FROM KCG [LVB NO={}] [KCG NO={}] [KFTC NO={}]", "00000000", in.getMessageTrackingNumber(), in.getTransactionIdNumber());
			
			Map<String, Object> paramValList = new Hashtable<>();
			// 에러 메시지 문자열 생성
			String errorMessage = String.format("[F A I L] HBK FUND TRANSFER ERROR RESPONSE FROM KCG [LVB NO=%s] [KCG NO=%s] [KFTC NO=%s]", "00000000", in.getMessageTrackingNumber(), in.getTransactionIdNumber());
			paramValList.put("errTlgId", HbkConst.REVERSE_TRANSACTION_TITLE);
			paramValList.put("errCtt", errorMessage);
			comPshMsgBean.sendAlarm(9, paramValList.get("errTlgId").toString(), paramValList, null, true);
		} catch (Exception e2) {
			log.error("Message Request Fail", e2);
		}
		
		return;
	}
	
	/**
	 * 
	 * @param reqFlag
	 * @return respFlag
	 */
	private String _getRespFlag(String reqFlag) {

		String respFlag = "";

		int flag = Integer.parseInt(reqFlag);
		respFlag = String.valueOf(flag + 1);

		return respFlag;
	}
	
	private HbkTransactionIn _setInsertIn(KftHof0200450000 vo) {

		HbkTransactionIn insertIn = new HbkTransactionIn();

		insertIn.setTrDt(vo.getTraxOccurredDate().format(DateFormat.YYYYMMDD.getFormatter())); // 거래일자
		insertIn.setOutinDvsnCd(HbkConst.OUTIN_DVSN_CD_02); // 당타발구분
		insertIn.setHbkTlgKndDvsnCd(HbkConst.TLG_KND_DVSN_NO_0200); // 전문구분
		insertIn.setTrStsCd(TrStsCdEnum.REQUEST.getTrStsCd());
		insertIn.setSndRcvDvsnCd(vo.getSendReceiveFlag());// 송수신flag
		insertIn.setHbkTlgTrDvsnCd(vo.getMessageCode());
		insertIn.setMsgSndDt(vo.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter())); // 전문전송일
		insertIn.setMsgSndTm(vo.getMessageSendTime().format(DateFormat.HHMMSS.getFormatter())); // 전문전송시간
		insertIn.setHbkTlgTrceNo(vo.getMessageTrackingNumber()); // 전문추적번호

		insertIn.setTrUnqNo(vo.getTransactionIdNumber()); // 거래고유번호
		insertIn.setHndlBnkCd(vo.getHandlingInstitutionRepCode()); // 취급은행
		insertIn.setHndlBrnchCd(vo.getRequestBranchCode()); // 취급은행지점
		insertIn.setOpnBnkCd(vo.getBeneficiaryBankCode());
		insertIn.setOpnBnkBrnchCd(vo.getBeneficiaryBranchCode());

		insertIn.setRcvAcctNo(vo.getBeneficiaryAccountNumber()); // 수취계좌번호
		insertIn.setTotTrAmt(BigDecimal.valueOf(vo.getTransactionAmount())); // 거래금액
		insertIn.setNoteExCd(HbkConst.NOTE_EX_CD_01); // 수취지역코드
		insertIn.setRqerNm(vo.getWithdrawer()); // 의뢰인
		insertIn.setRcpntNm(vo.getBeneficiaryName()); // 요청 수취인명
		insertIn.setRcpntNm2(vo.getBeneficiaryName()); // 요청 수취인명
		insertIn.setMediaTpCd(vo.getMediaType()); // 매체구분
		insertIn.setFundTpCd(vo.getFundType()); // 자금성격
		insertIn.setRqerInfo(vo.getRequestorInformation()); // 의뢰인정보
		insertIn.setWhdrwlAcctNo(vo.getWithdrawalAccountNumber()); // 출금계좌번호
		insertIn.setSndrRealNm(vo.getRealSenderName()); // 송금인실명
		insertIn.setSuspTrInfo(vo.getSuspectedFraudInfo()); // 금융사기의심유의정보
		insertIn.setTrmnlDvsnCd(ComConst.CHAR_00);  //채널구분

		insertIn.setHbkRcvInqryUnqNo(vo.getHbkTransactionId());// 거액타행이체수취조회거래고유번호
		insertIn.setHbkRespCd(vo.getHbkWireResponseCode()); // 한은망 응답코드
		insertIn.setHbkInitInstRespCd(vo.getBeneficiaryBankResponseCode()); // 개설기관응답코드
		insertIn.setHbkInitInstPostCd(vo.getHbkWireHandlingAccountInstitution()); // 한은망 취급기관 계정개설처
		insertIn.setHbkHndlInstPostCd(vo.getHbkWireOpenAccountInstitution()); // 한은망 개설기관 계정개설처
		insertIn.setHbkTrSeqNo(vo.getHbkWireTransferSerialNumber()); // 한은망 자금이체 일련번호
		insertIn.setHbkHoldNo(vo.getFiller1()); // 한은금융망대기번호 (FILLTER)
		insertIn.setHbkCplxHoldSeq(vo.getFiller4()); // 한은금융망복합대기순서 (FILLTER)
		insertIn.setHbkAcntgNo(vo.getFiller3()); // 한은금융망회계번호 (FILLTER)
		insertIn.setHbkRqstTm(vo.getHbkWireApplicationTime()); // 한은망 신청시간
		insertIn.setHbkPymntTm(vo.getHbkWirePaymentTime()); // 한은망 결제시간
		insertIn.setHbkPymntTp(vo.getHbkWirePaymentMethod()); // 한은망 결제방법
		insertIn.setHbkPymntFailRsn(vo.getFiller2()); // 한은금융망결제실패원인 (FILLTER)
		insertIn.setOrgnTrUnqNo(vo.getOriginalTransactionIDNumber()); // 원거래 거래고유번호
		insertIn.setOrgnTrSeqNo(vo.getOriginalTransactionFundTransferSerialNumber()); // 원거래 자급이체 일련번호

		return insertIn;
	}

}
