import { useRef, useState } from "react"

import Page from "@/components/Page"
import useI18n from "@/hooks/useI18n"
import Cron from "react-cron-generator"
import "@/public/assets/css/cron-builder.css"
import ButtonGroup from "@/components/ButtonGroup"
import Button from "@/components/Button"
import { $i18nUtils } from "@/utils/common.i18n"

// UCRONGEN 컴포넌트
function UCRONGEN() {
  const [cronExpr, setCronExpr] = useState<string>()

  const handleChange = (value: string, text: string) => {
    setCronExpr(value)
  }

  const handleClick = (e: any) => {
    if (cronExpr) {
      navigator.clipboard.writeText(cronExpr)
    }
  }

  return (
    <Page>
      <div className="content-wrap">
        <div className="sub-content">
          <div style={{ width: "100%", padding: "12px 0px 12px 24px" }}>
            <Button
              name="copy"
              i18n={$i18nUtils.trans("SCRNITM#copy")}
              color="white"
              onClick={handleClick}
            >
              복사
            </Button>
          </div>
          <div style={{ paddingLeft: "24px" }}>
            <Cron
              showResultText={true}
              showResultCron={true}
              value={cronExpr}
              onChange={handleChange}
            />
          </div>
        </div>
      </div>
    </Page>
  )
}

export default UCRONGEN
