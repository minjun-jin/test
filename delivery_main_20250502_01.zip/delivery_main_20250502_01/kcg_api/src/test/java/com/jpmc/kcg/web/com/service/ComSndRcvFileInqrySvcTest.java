package com.jpmc.kcg.web.com.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.dto.CodeLabelOut;
import com.jpmc.kcg.com.dto.ComFileLaytD;
import com.jpmc.kcg.com.dto.ComFileLaytM;
import com.jpmc.kcg.com.dto.PageableRequestList;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.ent.biz.vo.KftEntES0001R;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.cms.dao.CmsAtSndRcvFileLWebDao;
import com.jpmc.kcg.web.cms.dao.CmsSndRcvFileLWebDao;
import com.jpmc.kcg.web.cms.dto.CmsAtSndRcvFileLWeb;
import com.jpmc.kcg.web.cms.dto.CmsSndRcvFileLWeb;
import com.jpmc.kcg.web.com.dao.ComFileDao;
import com.jpmc.kcg.web.com.dao.ComFileLaytDDao;
import com.jpmc.kcg.web.com.service.dto.*;
import com.jpmc.kcg.web.ent.dao.EntSndRcvFileLWebDao;
import com.jpmc.kcg.web.ent.dto.EntSndRcvFileLWeb;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HofSndRcvFileLWebDao;
import com.jpmc.kcg.web.hof.dto.HofSndRcvFileLWeb;
import com.jpmc.kcg.web.ift.dao.IftSndRcvFileLWebDao;
import com.jpmc.kcg.web.ift.dto.IftSndRcvFileLWeb;
import com.jpmc.kcg.web.rpr.dao.RprSndRcvFileLWebDao;
import com.jpmc.kcg.web.rpr.dto.RprSndRcvFileLWeb;

import lombok.extern.slf4j.Slf4j;

@ExtendWith(MockitoExtension.class)
@Slf4j
class ComSndRcvFileInqrySvcTest {

    @Mock
    private ComFileDao comFileDao;
    @Mock
    private CmsSndRcvFileLWebDao cmsSndRcvFileLWebDao;
    @Mock
    private CmsAtSndRcvFileLWebDao cmsAtSndRcvFileLWebDao;
    @Mock
    private HofSndRcvFileLWebDao hofSndRcvFileLWebDao;
    @Mock
    private IftSndRcvFileLWebDao iftSndRcvFileLWebDao;
    @Mock
    private RprSndRcvFileLWebDao rprSndRcvFileLWebDao;
    @Mock
    private EntSndRcvFileLWebDao entSndRcvFileLWebDao; 
    @Mock
    private ComFileLaytDDao comFileLaytDDao;

    @InjectMocks
    private ComSndRcvFileInqrySvc service;
    
    private MockedStatic<VOUtils> voUtilsMockedStatic;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // Mock 객체 초기화
        
    	WebContextImpl webContextImpl = new WebContextImpl();
        Header header = new Header();
        header.setLngCd("ko");
        header.setRoles(List.of(""));
        webContextImpl.setHeader(header);
        FrwContextHolder.setContext(webContextImpl);
        
        // VOUtils static mock 설정
		voUtilsMockedStatic = mockStatic(VOUtils.class);
    }
    
    @AfterEach
	void afterEach() {
		// VOUtils static mock 해제
		if (voUtilsMockedStatic != null) {
			voUtilsMockedStatic.close();
		}
	}

    @Test
    void getFileNoListTest() {
        // Given
        ComFileNoListIn input = new ComFileNoListIn();
        input.setBizDvsnCd("ABC");

        List<ComFileLaytM> mockDataList = new ArrayList<>();
        ComFileLaytM mockData1 = new ComFileLaytM();
        mockData1.setFileNo("001");
        mockData1.setFileBizCtt("File Content 1");

        ComFileLaytM mockData2 = new ComFileLaytM();
        mockData2.setFileNo("002");
        mockData2.setFileBizCtt("File Content 2");

        mockDataList.add(mockData1);
        mockDataList.add(mockData2);

        when(comFileDao.selectFileNoList(any(ComFileLaytM.class))).thenReturn(mockDataList);

        // When
        ComFileNoListOut result = service.getFileNoList(input);

        // Then
        assertNotNull(result);
        assertEquals(2, result.getOutList().size());

        CodeLabelOut firstOutput = result.getOutList().get(0);
        assertEquals("001", firstOutput.getCodeField());
        assertEquals("File Content 1", firstOutput.getLabelField());

        CodeLabelOut secondOutput = result.getOutList().get(1);
        assertEquals("002", secondOutput.getCodeField());
        assertEquals("File Content 2", secondOutput.getLabelField());

        verify(comFileDao, times(1)).selectFileNoList(any(ComFileLaytM.class));
        
        log.info("getFileNoListTest - input : {}", input);
        log.info("getFileNoListTest - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_CMS() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("EB00");
        input.setBizDvsnCd("CMS");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<CmsSndRcvFileLWeb> mockDataList = new ArrayList<>();
        CmsSndRcvFileLWeb mockData1 = new CmsSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("EB000101");

        CmsSndRcvFileLWeb mockData2 = new CmsSndRcvFileLWeb();
        mockData2.setTrDt("20230102");
        mockData2.setFileNm("EB000102");

        mockDataList.add(mockData1);
        mockDataList.add(mockData2);

        // Mock 동작 정의
        when(cmsSndRcvFileLWebDao.countCmsSndRcvFileList(any(CmsSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(cmsSndRcvFileLWebDao.selectCmsSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<CmsSndRcvFileLWeb> result = out.getCmsListOut();

        // Then
        assertNotNull(result);
        assertEquals(2, result.size());

        CmsSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("EB000101", firstResult.getFileNm());

        // Verify
        verify(cmsSndRcvFileLWebDao, times(1)).countCmsSndRcvFileList(any(CmsSndRcvFileLWeb.class));
        verify(cmsSndRcvFileLWebDao, times(1)).selectCmsSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_CMS - input : {}", input);
        log.info("getSndRcvFileList_CMS - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_AT() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("EB00");
        input.setBizDvsnCd("AT");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<CmsAtSndRcvFileLWeb> mockDataList = new ArrayList<>();
        CmsAtSndRcvFileLWeb mockData1 = new CmsAtSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("AT1112");

        mockDataList.add(mockData1);

        // Mock 동작 정의
        when(cmsAtSndRcvFileLWebDao.countAtSndRcvFileList(any(CmsAtSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(cmsAtSndRcvFileLWebDao.selectAtSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<CmsAtSndRcvFileLWeb> result = out.getAtListOut();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());

        CmsAtSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("AT1112", firstResult.getFileNm());

        // Verify
        verify(cmsAtSndRcvFileLWebDao, times(1)).countAtSndRcvFileList(any(CmsAtSndRcvFileLWeb.class));
        verify(cmsAtSndRcvFileLWebDao, times(1)).selectAtSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_AT - input : {}", input);
        log.info("getSndRcvFileList_AT - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_HOF() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("CC0011");
        input.setBizDvsnCd("HOF");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<HofSndRcvFileLWeb> mockDataList = new ArrayList<>();
        HofSndRcvFileLWeb mockData1 = new HofSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("CC0011");

        mockDataList.add(mockData1);

        // Mock 동작 정의
        when(hofSndRcvFileLWebDao.countHofSndRcvFileList(any(HofSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(hofSndRcvFileLWebDao.selectHofSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<HofSndRcvFileLWeb> result = out.getHofListOut();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());

        HofSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("CC0011", firstResult.getFileNm());

        // Verify
        verify(hofSndRcvFileLWebDao, times(1)).countHofSndRcvFileList(any(HofSndRcvFileLWeb.class));
        verify(hofSndRcvFileLWebDao, times(1)).selectHofSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_HOF - input : {}", input);
        log.info("getSndRcvFileList_HOF - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_IFT() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("EB1111");
        input.setBizDvsnCd("IFT");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<IftSndRcvFileLWeb> mockDataList = new ArrayList<>();
        IftSndRcvFileLWeb mockData1 = new IftSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("EB1111");

        mockDataList.add(mockData1);

        // Mock 동작 정의
        when(iftSndRcvFileLWebDao.countIftSndRcvFileList(any(IftSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(iftSndRcvFileLWebDao.selectIftSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<IftSndRcvFileLWeb> result = out.getIftListOut();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());

        IftSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("EB1111", firstResult.getFileNm());

        // Verify
        verify(iftSndRcvFileLWebDao, times(1)).countIftSndRcvFileList(any(IftSndRcvFileLWeb.class));
        verify(iftSndRcvFileLWebDao, times(1)).selectIftSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_IFT - input : {}", input);
        log.info("getSndRcvFileList_IFT - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_RPR() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("RE0001");
        input.setBizDvsnCd("RPR");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<RprSndRcvFileLWeb> mockDataList = new ArrayList<>();
        RprSndRcvFileLWeb mockData1 = new RprSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("RE0001");

        mockDataList.add(mockData1);

        // Mock 동작 정의
        when(rprSndRcvFileLWebDao.countRprSndRcvFileList(any(RprSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(rprSndRcvFileLWebDao.selectRprSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<RprSndRcvFileLWeb> result = out.getRprListOut();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());

        RprSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("RE0001", firstResult.getFileNm());

        // Verify
        verify(rprSndRcvFileLWebDao, times(1)).countRprSndRcvFileList(any(RprSndRcvFileLWeb.class));
        verify(rprSndRcvFileLWebDao, times(1)).selectRprSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_RPR - input : {}", input);
        log.info("getSndRcvFileList_RPR - output : {}", result);
    }
    
    @Test
    void getSndRcvFileList_ENT() {
        // Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setTrStaDt("20230101");
        input.setTrEndDt("20231231");
        input.setFileBizDvsnCd("ES0001");
        input.setBizDvsnCd("ENT");
        input.setPgNbr(0);
        input.setPgCnt(1000);

        // Mock 데이터 준비
        Integer mockTotalCount = 2;

        List<EntSndRcvFileLWeb> mockDataList = new ArrayList<>();
        EntSndRcvFileLWeb mockData1 = new EntSndRcvFileLWeb();
        mockData1.setTrDt("20230101");
        mockData1.setFileNm("ES0001");

        mockDataList.add(mockData1);

        // Mock 동작 정의
        when(entSndRcvFileLWebDao.countEntSndRcvFileList(any(EntSndRcvFileLWeb.class))).thenReturn(mockTotalCount);
        when(entSndRcvFileLWebDao.selectEntSndRcvFileList(any(PageableRequestList.class))).thenReturn(mockDataList);

        // When
        SndRcvFileListOut out = service.getSndRcvFileList(input);
        List<EntSndRcvFileLWeb> result = out.getEntListOut();

        // Then
        assertNotNull(result);
        assertEquals(1, result.size());

        EntSndRcvFileLWeb firstResult = result.get(0);
        assertEquals("20230101", firstResult.getTrDt());
        assertEquals("ES0001", firstResult.getFileNm());

        // Verify
        verify(entSndRcvFileLWebDao, times(1)).countEntSndRcvFileList(any(EntSndRcvFileLWeb.class));
        verify(entSndRcvFileLWebDao, times(1)).selectEntSndRcvFileList(any(PageableRequestList.class));
        
        log.info("getSndRcvFileList_ENT - input : {}", input);
        log.info("getSndRcvFileList_ENT - output : {}", result);
    }
    
    @Test
    void getSndRcvFileDetailList_ENT() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("ENT");
        input.setFileNm("ES0001");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        
        // mock VO
        KftEntES0001R mockVo = new KftEntES0001R();
        mockVo.setDataType("R");
        
        when(VOUtils.toVo(anyString(), eq(KftEntES0001R.class))).thenReturn(mockVo);
        
        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_ENT - input : {}", input);
        log.info("getSndRcvFileDetailList_ENT - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_CMS_90A() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("CMS");
        input.setFileNm("EB90");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");
        input.setCustNo("A");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_CMS_90A - input : {}", input);
        log.info("getSndRcvFileDetailList_CMS_90A - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_CMS_90B() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("CMS");
        input.setFileNm("EB90");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");
        input.setCustNo("B");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_CMS_90B - input : {}", input);
        log.info("getSndRcvFileDetailList_CMS_90B - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_CMS_90C() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("CMS");
        input.setFileNm("EB90");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");
        input.setCustNo("C");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_CMS_90C - input : {}", input);
        log.info("getSndRcvFileDetailList_CMS_90C - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_CMS_90D() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("CMS");
        input.setFileNm("EB90");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");
        input.setCustNo("D");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_CMS_90D - input : {}", input);
        log.info("getSndRcvFileDetailList_CMS_90D - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_CMS_90E() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("CMS");
        input.setFileNm("EB90");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");
        input.setCustNo("E");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_CMS_90E - input : {}", input);
        log.info("getSndRcvFileDetailList_CMS_90E - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_AT() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("AT");
        input.setFileNm("AT1112");
        input.setTlgCtt("SomeContent");
        input.setDataTp("11");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_AT - input : {}", input);
        log.info("getSndRcvFileDetailList_AT - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_HOF() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("HOF");
        input.setFileNm("CC0011");
        input.setTlgCtt("SomeContent");
        input.setDataTp("33");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_HOF - input : {}", input);
        log.info("getSndRcvFileDetailList_HOF - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_IFT() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("IFT");
        input.setFileNm("EB1111");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_IFT - input : {}", input);
        log.info("getSndRcvFileDetailList_IFT - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_RPR() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("RPR");
        input.setFileNm("RE0001");
        input.setTlgCtt("SomeContent");
        input.setDataTp("22");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);

        // When
        SndRcvFileDtlListOut result = service.getSndRcvFileDetailList(input);

        // Then
        assertNotNull(result);
        assertEquals(1, result.getListOut().size());
        
        log.info("getSndRcvFileDetailList_RPR - input : {}", input);
        log.info("getSndRcvFileDetailList_RPR - output : {}", result);
    }

    @Test
    void getSndRcvFileDetailList_voClassNotFoundException() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("AT");
        input.setFileNm("INVALID_FILENM");
        input.setTlgCtt("SomeContent");
        input.setDataTp("11");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);     
        
     // When & Then
        BusinessException exception = assertThrows(BusinessException.class, () -> {
            service.getSndRcvFileDetailList(input);
        });

        assertEquals("MCMNE05014", exception.getErrorCode());
        log.info("getSndRcvFileDetailList_voClassNotFoundException, {}", exception.toString());
    }

    @Test
    void getSndRcvFileDetailList_voException() {
        // Given
        SndRcvFileDtlListIn input = new SndRcvFileDtlListIn();
        input.setBizDvsnCd("AT");
        input.setFileNm("");
        input.setTlgCtt("INVALID_TLGCTT");
        input.setDataTp("11");

        List<SndRcvFileDtlListDto> mockDataList = new ArrayList<>();
        SndRcvFileDtlListDto mockDto1 = new SndRcvFileDtlListDto();
        mockDto1.setDetailKey("key1");
        mockDto1.setField("field1");

        mockDataList.add(mockDto1);

        Map<String, String> mockVoMap = new HashMap<>();
        mockVoMap.put("field1", "value1");
        mockVoMap.put("field2", "value2");

        when(comFileLaytDDao.selectFileLayt(any(ComFileLaytD.class), any(String.class))).thenReturn(mockDataList);     
        
     // When & Then
        BusinessException exception = assertThrows(BusinessException.class, () -> {
            service.getSndRcvFileDetailList(input);
        });

        assertEquals("MCMNE05014", exception.getErrorCode());
        log.info("getSndRcvFileDetailList_voException, {}", exception.toString());
    }
    
    @Test
    void getSndRcvFileList_validationError() {
    	// Given
        SndRcvFileListIn input = new SndRcvFileListIn();
        input.setBizDvsnCd(null);
        
     // When & Then
        BusinessException exception = assertThrows(BusinessException.class, () -> {
            service.getSndRcvFileList(input);
        });
        
        assertEquals("MCMNE01002", exception.getErrorCode());
        log.info("getSndRcvFileList_validationError, {}", exception.toString());
    }
}
