package com.jpmc.kcg.web.com.dto;

import com.jpmc.kcg.com.dto.ComTlgLaytMapD;
import com.jpmc.kcg.web.com.enums.CrudType;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class CmnTlgLaytMapD extends ComTlgLaytMapD {
    private String crudType;
}
