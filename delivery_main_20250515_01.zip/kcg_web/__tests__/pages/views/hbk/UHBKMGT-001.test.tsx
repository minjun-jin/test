import React from "react"
import { fireEvent, render, waitFor, within } from "@testing-library/react"

// UHBKMGT001 컴포넌트를 불러옵니다.
import UHBKMGT001 from "@/pages/views/hbk/UHBKMGT-001"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(UHBKMGT001)

describe("[UHBKMGT-001] HBK라우팅스케줄을(HBK->HOF)", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValueOnce("20240101")
    mockStorageUtils.mockRoleList.mockReturnValue([
      { roleCd: CONFIG.ROLE_CD.ALL },
    ])
  })

  beforeEach(() => {
    mockUseParams.mockReturnValue({
      params: {},
    })
  })

  it("useEffect Test - baseDt is false", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        baseDt: false,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("useEffect Test - baseDt is true", async () => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: {
        isDashboard: true,
        baseDt: true,
      },
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    mockUseParams.mockRestore()
  })

  it("getListHbkRoutingSchedule Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 0,
        hbkExcpSchdMList: [],
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 0,
        hbkExcpSchdMList: undefined,
      },
    })
    render(component)
    pagingHandling[0](null, 2)
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it.each([
    {},
    {
      schdDt: "20240101",
      schdStaTm: "080000",
      schdEndTm: "080000",
      makeDttm: "2024010101010",
    },
  ])("valueFormatter Test", async (param) => {
    const { findAllByText } = render(component)

    const valueFormatterTestBtn = (
      await findAllByText(/valueFormatter Test/)
    )[0]
    fireEvent.click(valueFormatterTestBtn, {
      target: {
        data: param,
      },
    })
  })

  it("rowClassRules Test", async () => {
    const { findAllByText } = render(component)

    const rowClassRulesTestBtn = (await findAllByText(/rowClassRules Test/))[0]
    fireEvent.click(rowClassRulesTestBtn, {
      target: {
        data: {
          data: {
            aprvStsCd: "02",
          },
        },
      },
    })
  })

  it("onRowClicked Test", async () => {
    const { findAllByText } = render(component)
    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          makeDttm: "20040101",
        },
      },
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 01", async () => {
    const { findAllByText } = render(component)

    const onRowDoubleClickedTestBtn = (
      await findAllByText(/onRowDoubleClicked Test/)
    )[0]

    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "01",
        },
      },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 02", async () => {
    const { findAllByText } = render(component)

    const onRowDoubleClickedTestBtn = (
      await findAllByText(/onRowDoubleClicked Test/)
    )[0]

    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: {
        data: {
          aprvStsCd: "02",
        },
      },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("getListHbkRoutingScheduleExcel Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
      },
    })

    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })
    const { findByText } = render(component)

    const excelBtn = await findByText(/SCRNITM#excel/)
    fireEvent.click(excelBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("newClick, closeClick Test", async () => {
    const { findByText } = render(component)
    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)

    const closeBtn = await findByText(/SCRNITM#close/)
    fireEvent.click(closeBtn)
    fireEvent.click(closeBtn)
  })

  it("changeHbkRoutingSchedule Test - confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
        totLen: 0,
      },
    })

    const { findByText, findAllByText } = render(component)

    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          makeDttm: "20040101",
        },
      },
    })

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("changeHbkRoutingSchedule Test - not confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText, findAllByText } = render(component)

    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          makeDttm: "20040101",
        },
      },
    })

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("createHbkRoutingSchedule Test - confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
        totLen: 0,
      },
    })

    const { findByText } = render(component)

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("createHbkRoutingSchedule Test - not confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText } = render(component)

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("removeHbkRoutingSchedule Test - confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
        totLen: 0,
      },
    })

    const { findByText, findAllByText } = render(component)

    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          makeDttm: "20040101",
        },
      },
    })

    const delBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(delBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("removeHbkRoutingSchedule Test - not confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText, findAllByText } = render(component)

    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, {
      target: {
        data: {
          makeDttm: "20040101",
        },
      },
    })

    const delBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(delBtn)

    await waitFor(() => {
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("ctrlEnter Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        hbkExcpSchdMList: [],
        totLen: 0,
      },
    })
    const { container } = render(component)
    fireEvent.keyDown(container, { key: "Enter", ctrlKey: true, keyCode: 13 })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })
})
