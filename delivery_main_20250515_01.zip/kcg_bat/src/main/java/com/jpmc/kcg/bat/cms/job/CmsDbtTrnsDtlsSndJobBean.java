package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;
import static com.jpmc.kcg.cms.enums.CmsRqstDvsnCdEnum.ARBITRARY_TERMINATION;
import static com.jpmc.kcg.cms.enums.CmsRqstDvsnCdEnum.REGISTRATION;

import java.io.OutputStream;
import java.util.*;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.bat.ChunkBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsAtSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dao.BatCmsAtSndRcvFileLDao;
import com.jpmc.kcg.bat.cms.dao.BatCmsWhdrwlTrnAplyMDao;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.com.biz.ComFileTractLBean;
import com.jpmc.kcg.bat.utils.ExtFileProcessor;
import com.jpmc.kcg.cms.biz.CmsAccountValidator;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112H;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112R;
import com.jpmc.kcg.cms.biz.vo.KftCmsAT1112T;
import com.jpmc.kcg.cms.constants.CmsConst;
import com.jpmc.kcg.cms.dao.CmsAtSndRcvFileLMapper;
import com.jpmc.kcg.cms.dto.AccountOut;
import com.jpmc.kcg.cms.dto.CmsAtSndRcvFileL;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.cms.enums.CmsBatchRespCdEnum;
import com.jpmc.kcg.cms.enums.CmsRqstDvsnCdEnum;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.frw.bat.BatResourceHolder;

import lombok.extern.slf4j.Slf4j;

/**
 * CMS 자동납부 등록정보 신규/해지 내역 (KCG -> KFTC)
 * JPMC의 자동납부 원장을 기준으로 신규/해지가 발생한 자동납부 등록정보를 파일로 생성(변경분만 생성)
 * FILE NAME : AT1112 (은행공동 CMS 관련 사항 수록)
 *
 * 원장 변경일의 익 영업일에 전송
 *  (휴일 익 영업일 송신 파일은 전 영업일부터 전일(휴일)까지의 변경 내역을 수록)
 */
@Slf4j
@Component
public class CmsDbtTrnsDtlsSndJobBean extends ChunkBatJob<CmsWhdrwlTrnAplyM, KftCmsAT1112R> {

    private final BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao;
    private final BatCmsAtSndRcvFileLDao batCmsAtSndRcvFileLDao;
    private final CmsAtSndRcvFileLMapper cmsAtSndRcvFileLMapper;
    private final CmsAtSndRcvLogManager cmsAtSndRcvLogManager;
    private final CmsAccountValidator cmsAccountValidator;
    private final ComFileTractLBean comFileTractLBean;
    private final ExtFileProcessor fileProcessor;
    private final BizDate bizDate;

    public CmsDbtTrnsDtlsSndJobBean(BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao,
                                    BatCmsAtSndRcvFileLDao batCmsAtSndRcvFileLDao, 
                                    CmsAtSndRcvFileLMapper cmsAtSndRcvFileLMapper,
                                    CmsAtSndRcvLogManager cmsAtSndRcvLogManager,
                                    ComFileTractLBean comFileTractLBean,
                                    CmsAccountValidator cmsAccountValidator,
                                    ExtFileProcessor fileProcessor,
                                    BizDate bizDate) {
        this.batCmsWhdrwlTrnAplyMDao = batCmsWhdrwlTrnAplyMDao;
        this.batCmsAtSndRcvFileLDao = batCmsAtSndRcvFileLDao;
        this.cmsAtSndRcvFileLMapper = cmsAtSndRcvFileLMapper;
        this.cmsAtSndRcvLogManager = cmsAtSndRcvLogManager;
        this.comFileTractLBean = comFileTractLBean;
        this.cmsAccountValidator = cmsAccountValidator;
        this.fileProcessor = fileProcessor;
        this.bizDate = bizDate;
    }
    
    @Override
    protected void beforeJob(BatContext batContext) {
        // CMS Context 초기화
        BatCmsContextVo cmsContextVo = new BatCmsContextVo();
        cmsContextVo.initializeContext(batContext, AT1112);

        // 카운트를 위한 변수 선언
        batContext.setData(FILE_NO, AT1112);
        batContext.setData(CMS_CONTEXT, cmsContextVo);
        batContext.setData(TOT_RECORD_COUNT, 0);
        batContext.setData(NEW_COUNT, 0);
        batContext.setData(TERM_COUNT, 0);
        batContext.setData(ERROR_COUNT, 0);
        batContext.setData(SEQ, 0);
        batContext.setData(TARGET_LIST, new ArrayList<CmsWhdrwlTrnAplyM>());

        CmsAtSndRcvFileL in = new CmsAtSndRcvFileL();
        in.setTrDt      ( cmsContextVo.getTrDt()     );
        in.setSrDt      ( cmsContextVo.getSrDt()     );
        in.setFileNm    ( AT1112                     );
        List<CmsAtSndRcvFileL> dupList = batCmsAtSndRcvFileLDao.selectSndRcvFileList(in, false);

        if(!ObjectUtils.isEmpty(dupList)) {
            dupList.forEach(dup -> {
                log.debug("----- [D U P L I C A T E]  AT2112 deleteByPrimaryKey ----- {}", dup);
                cmsAtSndRcvFileLMapper.deleteByPrimaryKey(dup.getSrDt(), dup.getTrDt(),
                        dup.getFileNm(),dup.getDataTp(), dup.getSeqNo());
            });
        }
    }

    @Override
    protected Iterator<CmsWhdrwlTrnAplyM> openReader(BatContext batContext) {
        log.debug(" ##### openReader start ######");

        List<CmsWhdrwlTrnAplyM> targetList = (List<CmsWhdrwlTrnAplyM>) batContext.getData(TARGET_LIST);
        return targetList.iterator();
    }

    @Override
    protected OutputStream openWriter(BatContext batContext) {
        log.debug(" ##### openWriter ######");
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        OutputStream outputStream = fileProcessor.openOutputStream(AT1112);

        // record가 null이어도 Header 작성
        processHeader(outputStream, batContext, cmsContextVo.getTrDt(), cmsContextVo.getSrDt());
        return outputStream;
    }

    @Override
    protected long targetTotalCount(BatContext batContext) {
        log.debug(" ##### targetTotalCount ######");
        /*
         * 대상 데이터 조회 및 카운트 계산
         */
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        
        List<CmsWhdrwlTrnAplyM> targetList = getCmsWhdrwlTrnAplyMList(cmsContextVo.getTrDt(), batContext);
        batContext.setData(TARGET_LIST, targetList );
        batContext.setData(TOT_RECORD_COUNT, targetList.size());
        return targetList.size();
    }

    private List<CmsWhdrwlTrnAplyM> getCmsWhdrwlTrnAplyMList(String trDt, BatContext batContext) {
        /*
         * 출금이체신청원장에서 최종수정일자가 배치 실행일자와 동일한 데이터를 조회한다.
         */
        CmsWhdrwlTrnAplyM in = new CmsWhdrwlTrnAplyM();
        in.setLastChgDt(trDt);
        List<CmsWhdrwlTrnAplyM> todayTargetList = batCmsWhdrwlTrnAplyMDao.selectList(in);

        /*
         * 2전영업일에 AT2112 실패 Record 재시도
         */
        List<CmsWhdrwlTrnAplyM> retryTargetList = getRetryTargetList();
        if (!retryTargetList.isEmpty()) {
            log.debug("Retry target list size: {}", retryTargetList.size());
            todayTargetList.addAll(retryTargetList);
        }

        /*
         * 계좌 상태 비정상의 경우 대상에서 제외
         */
        List<CmsWhdrwlTrnAplyM> filteredList = todayTargetList.stream()
                .filter(Objects::nonNull)
                .map(trnAplyM -> this.validateAccountNo(trnAplyM, batContext))
                .filter(Objects::nonNull)
                .toList();
        log.debug("Filtered list size: {}", filteredList.size());
        return filteredList;
    }

    private List<CmsWhdrwlTrnAplyM> getRetryTargetList() {
        String prevBizDay = bizDate.getPrevWorkingDay(DateUtils.getISODate(), 2); // D-2 영업일

        CmsAtSndRcvFileL in = new CmsAtSndRcvFileL();
        in.setTrDt      ( prevBizDay     );
        in.setFileNm    ( AT2112         );
        in.setDataTp    ( CmsConst.DATA  );

        List<CmsAtSndRcvFileL> retryTargetList = batCmsAtSndRcvFileLDao.selectSndRcvFileList(in, true);
        log.debug("----- RETRY DATA TARGET DATE : {} -----", prevBizDay);

        if (CollectionUtils.isEmpty(retryTargetList)) {
            log.debug("----- RETRY DATA-NO DATA -----");
            return Collections.emptyList();
        }

        return retryTargetList.stream()
                .map(f -> batCmsWhdrwlTrnAplyMDao.findOne(f.getCorpCd(), f.getRtpyrId(), f.getAcctNo(), f.getCtzBizNo()))
                .toList();
    }

    @Override
    protected KftCmsAT1112R process(CmsWhdrwlTrnAplyM k) {
        BatContext batContext = (BatContext)FrwContextHolder.getContext();
        
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        String srDt = cmsContextVo.getSrDt();

        int seqValue = (int) batContext.getData(SEQ) + 1; 
        batContext.setData(SEQ, seqValue); 

        log.debug("seq: {}, newCnt: {}, termCnt: {}, errorCount: {}", seqValue, 
                batContext.getData(NEW_COUNT), batContext.getData(TERM_COUNT), batContext.getData(ERROR_COUNT));

        KftCmsAT1112R data = new KftCmsAT1112R();

        // 원장의 처리상태가 1이면 신규, 나머지는 삭제한다.
        CmsRqstDvsnCdEnum regStsCd = CmsRqstDvsnCdEnum.findByCode(k.getRegStsCd());

        if (regStsCd == REGISTRATION) { // 처리구분
            data.setProcessingType(CmsConst.REG_STS_REG); // 신규 : '10'
            batContext.setData(NEW_COUNT, (int)batContext.getData(NEW_COUNT) + 1 );
        } else {
            data.setProcessingType(CmsConst.REG_STS_TERM); // 해지 : '20'
            batContext.setData(TERM_COUNT, (int)batContext.getData(TERM_COUNT) + 1 );
        }
        
        data.setFileName               (AT1112                                );
        data.setDataType               (CmsConst.DATA                         ); // 데이타구분
        data.setSerialNumber           (String.format("%07d", seqValue)       ); // 일련번호
        data.setPaymentAccountNo       (k.getAcctNo()                         ); // 출금계좌번호
        data.setInstitutionCode        (ComConst.JPMC_BANK_CD                 ); // 기관코드
        data.setPayerNumber            (k.getRtpyrId()                        ); // 납부자번호
        data.setFiller2                (StringUtils.SPACE                     ); // FILLER
        data.setAccountHolderID        (k.getAcctNo()                         ); // 예금주실명번호
        data.setAccountHolderName      (k.getAcctNm()                         ); // 계좌예금주명
        data.setSubInstitutionCode     (k.getCorpCd()                         ); // 하위이용기관코드
        data.setNewClosedStatus        (getNewClosedStatus(k.getRegDvsnCd())  ); // 신규/해지접수구분
        data.setNewClosedReason        (getRegReason(k.getRegDvsnCd())        ); // 신규/해지요청사유

        // 해지이면 무조건 은행
        if (regStsCd == ARBITRARY_TERMINATION) {
            data.setNewClosedStatus("1"); // 금융회사
            data.setNewClosedReason(CmsConst.REG_REASON_ARBITRARY_TERMINATION); // 임의해지
        }

        data.setNewClosedRequestDate   (k.getLastChgDt()                       ); // 신규/해지신청일
        data.setNewClosedEffectiveDate (null                                   ); // 신규/해지적용일
        data.setNewClosedOffice        (getBkBrCd(data.getNewClosedStatus()) ); // 등록/해지사무소
        data.setBankCustomField        (""                                     ); // 금융회사임의필드
        data.setLedgerChangeDate       (data.getNewClosedRequestDate()       ); // 원장변경일
        data.setFiller3                (StringUtils.SPACE                      ); // FILLER

        if (isNewFromInstitution(data.getNewClosedStatus(), data.getProcessingType())) {
            data.setAdditionalIDInfo(srDt); // 부가식별정보
        }

        return data;
    }

    private String getNewClosedStatus(String regDvsnCd) {
        // 접수구분 0: 은행, 1: 이용기관, 이외: 통합관리시스템
        return switch (regDvsnCd) {
            case CmsConst.REG_DVSN_BANK -> "1"; // 금융회사
            case CmsConst.REG_DVSN_INST -> "2"; // 이용기관
            default -> "4";
        };
    }

    private String getRegReason(String regDvsnCd) {
        return CmsConst.REG_DVSN_INST.equals(regDvsnCd) ? StringUtils.SPACE : CmsConst.REG_REASON_CUSTOMER_REQUEST; // 고객요청
    }

    private String getBkBrCd(String newClosedStatus) {
        // 등록/해지사무소
        return switch (newClosedStatus) {
            case CmsConst.REG_DVSN_INST, CmsConst.REG_DVSN_INTEGRATED_INST -> CmsConst.JPJUMCD;
            default -> null;
        };
    }

    private boolean isNewFromInstitution(String newClosedStatus, String processingType) {
        // reg_gubun이 "2 이용기관"이고 reg_cd가 "10 신규"인 경우
        return CmsConst.REG_DVSN_INST.equals(newClosedStatus)
                && CmsConst.REG_STS_REG.equals(processingType);
    }

    @Override
    protected void write(List<KftCmsAT1112R> items) {
        log.debug(" ##### write ######");
        BatContext batContext = (BatContext)FrwContextHolder.getContext();
        
        OutputStream outputStream = BatResourceHolder.getWriter(AT1112);
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        items.forEach(item -> {
            //////////////////////////////////////////////////////////////////
            /*
             * write 파일 데이터
             */
            String message = VOUtils.toString(item);
            
            fileProcessor.append(outputStream, message);
            /////////////////////////////////////////////////////////////////

            /*
             * AT1112 파일 데이터를 파일 송수신내역에 insert
             */
            CmsAtSndRcvFileL in = new CmsAtSndRcvFileL();
            in.setRespCd    ( CmsBatchRespCdEnum.NORMAL.getCode() );
            in.setCorpCd    ( item.getInstitutionCode()           );
            in.setRtpyrId   ( item.getPayerNumber()               );
            in.setAcctNo    ( item.getAccountHolderID()           );
            in.setCtzBizNo  ( item.getAccountHolderID()           );
            
            log.debug("[I N F O]  RESP CD            : [{}]", in.getRespCd());
            log.debug("[I N F O]  CORP CD            : [{}]", in.getCorpCd());
            log.debug("[I N F O]  PAYER ID           : [{}]", in.getRtpyrId());
            log.debug("[I N F O]  ACCOUNT            : [{}]", in.getAcctNo());

            cmsAtSndRcvLogManager.insertAtDataSendLog(in, item.getSerialNumber(), cmsContextVo.getTrDt(), cmsContextVo.getSrDt(), AT1112, message, batContext.getBatId());
        });
    }

    private void processHeader(OutputStream outputStream, BatContext batContext, String trDt, String srDt) {
        KftCmsAT1112H header = new KftCmsAT1112H();
        header.setTotalDataRecordCount  ( (int)batContext.getData(TOT_RECORD_COUNT) );
        header.setProcessingBaseDate    ( trDt                                      );
        header.setSerialNumber          ( CmsConst.HEADER_SEQ_7                     );

        //////////////////////////////////////////////////////////////////
        String message = VOUtils.toString(header);
        log.debug("----- KftCmsAT1112H HEADER VO ----- {}" , header);

        fileProcessor.append(outputStream, message);
        /////////////////////////////////////////////////////////////////

        /*
         * AT1112 파일 데이터를 파일 송수신내역에 insert
         */
        cmsAtSndRcvLogManager.insertAtHeaderSendLog(trDt, srDt, AT1112, message, batContext.getBatId());
    }

    private void processTrailer(OutputStream outputStream, BatContext batContext, String trDt, String srDt) {
        KftCmsAT1112T trailer = new KftCmsAT1112T(); // 자동납부 등록정보 신규/해지 내역(은행공동CMS)
        trailer.setSerialNumber         ( CmsConst.TRALIER_SEQ_7                      );
        trailer.setTotalDataRecordCount ( (int)batContext.getData(TOT_RECORD_COUNT) ); // 총DATARECORD수
        trailer.setNewCount             ( (int)batContext.getData(NEW_COUNT)        ); // 신규건수
        trailer.setTerminationCount     ( (int)batContext.getData(TERM_COUNT)       ); // 해지건수

        //////////////////////////////////////////////////////////////////
        String message = VOUtils.toString(trailer);

        fileProcessor.append(outputStream, message);
        /////////////////////////////////////////////////////////////////

        /*
         * AT1112 파일 데이터를 파일 송수신내역에 insert
         */
        cmsAtSndRcvLogManager.insertAtTrailerSendLog(trDt, srDt, AT1112, message, batContext.getBatId());
    }

    private CmsWhdrwlTrnAplyM validateAccountNo(CmsWhdrwlTrnAplyM trnAplyM, BatContext batContext) {
        /*
         * 계좌를 검증한다.
         */
        AccountOut accountInfo = cmsAccountValidator.validateAccount(trnAplyM.getAcctNo());

        /*
         * 정상인 계좌일 경우 record를 생성한다.
         */
        if (CmsBatchRespCdEnum.isNormal(accountInfo.getRespCd())) {
            trnAplyM.setAcctNm(accountInfo.getAcctNm());
            trnAplyM.setCtzBizNo(accountInfo.getCtzBizNo());

            return trnAplyM;
        } else {
            batContext.setData(ERROR_COUNT, (int)batContext.getData(ERROR_COUNT) + 1 );
            log.debug("----- [E R R O R]  Account Validation Error Cnt ----- {}", batContext.getData(ERROR_COUNT));
            return null;
        }
    }

    @Override
    protected void afterJob(BatContext batContext) {
        log.debug(" ##### afterJob ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        /*
         * trailer 작성
         */
        OutputStream outputStream = BatResourceHolder.getWriter(AT1112);
        processTrailer(outputStream, batContext, cmsContextVo.getTrDt(), cmsContextVo.getSrDt());

        /*
         * 작성한 파일을 전송하기 위해 close
         */
        fileProcessor.closeOutputStream(AT1112);

        /*
         * 결제원으로 파일 전송 처리
         */
        fileProcessor.sendFile(AT1112);

        //////////////////////////////////////////////////////////////////
        // file tracking 정보 저장
        comFileTractLBean.insertBySndBatJob(AT1112);

        log.debug("[SUCCESS]  ===================================================] ");
        log.debug("[SUCCESS]  =                  AT1112 SUMMARY                 =] ");
        log.debug("[SUCCESS]  ===================================================] ");
        log.debug("[SUCCESS]  TR DATE            : [{}]", cmsContextVo.getTrDt());
        log.debug("[SUCCESS]  TOTAL RECORD COUNT : [{}]", batContext.getData(TOT_RECORD_COUNT));
        log.debug("[SUCCESS]  NEW COUNT          : [{}]", batContext.getData(NEW_COUNT));
        log.debug("[SUCCESS]  TERM COUNT         : [{}]", batContext.getData(TERM_COUNT));
        log.debug("[SUCCESS]  ERR COUNT          : [{}]", batContext.getData(ERROR_COUNT));
        log.debug("[SUCCESS]  ===================================================] ");
    }
}
