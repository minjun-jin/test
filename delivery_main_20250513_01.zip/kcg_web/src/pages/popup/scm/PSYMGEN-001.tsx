/** ***********************************************************************
 * @ 서비스경로  : 시스템 > 배치 > 배치작업관리 > Cron Generator
 * @ 페이지설명  : [PSYMGEN-001] Cron Generator
 * @ 파일명     : PSYMGEN-001.tsx
 * @ 작성자     : 이수현 (suehyun.lee@bankwareglobal.com)
 * @ 작성일     : 2023-07-10
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2023-07-10             이수현                 최초작성
 ************************************************************************ */
import { $eventUtils } from "@/utils/common.event"
import { $i18nUtils } from "@/utils/common.i18n"
import { useState } from "react"

import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import Modal from "@/components/Modal"

import "@/public/assets/css/cron-builder.css"
import Cron from "react-cron-generator"
import useModal from "@/hooks/useModal"

function PSYMGEN001({ modalInfo }: any) {
  const $modalHooks = useModal()
  const [cronExpr, setCronExpr] = useState<string>()

  const handleChange = (value: string, text: string) => {
    setCronExpr(value)
  }

  const handleClick = (e: any) => {
    if (cronExpr) {
      navigator.clipboard.writeText(cronExpr)
    }
  }

  /**
   * 확인 클릭
   */
  const confirmClick = (e: any) => {
    $eventUtils.setEventContext(e)

    const parmas = {
      cronExpr,
    }
    $modalHooks.closePopup(modalInfo, parmas)
  }

  /**
   * 취소 클릭(닫기)
   */
  const cancelClick = (e: any) => {
    $eventUtils.setEventContext(e)

    $modalHooks.closePopup(modalInfo)
  }

  return (
    <Modal width="660" height="700">
      <div className="content-desk">
        {/** Sub Content S */}
        <div className="sub-content">
          {/* <div style={{ width: "100%", padding: "12px 0px 12px 24px" }}>
            <Button
              name="copy"
              i18n={$i18nUtils.trans("SCRNITM#copy")}
              color="white"
              onClick={handleClick}
            >
              복사
            </Button>
          </div> */}
          <div style={{ paddingLeft: "24px" }}>
            <Cron
              showResultText={true}
              showResultCron={true}
              value={cronExpr}
              onChange={handleChange}
            />
          </div>
        </div>
        {/** Sub Content E */}
      </div>
      <ButtonGroup>
        <Button
          name="confirm"
          i18n={$i18nUtils.trans("SCRNITM#confirm")}
          color="green"
          onClick={confirmClick}
        >
          확인
        </Button>
        <Button
          name="cancel"
          i18n={$i18nUtils.trans("SCRNITM#cancel")}
          color="white"
          onClick={cancelClick}
        >
          취소
        </Button>
      </ButtonGroup>
    </Modal>
  )
}

export default PSYMGEN001
