import { $eventUtils } from "@/utils/common.event"
/** ***********************************************************************
 * @ 서비스경로  : 업무공통 > 금결원 > 전문변환맵핑
 * @ 페이지설명  : [USYMMAP-002] 전문변환맵핑
 * @ 파일명     : USYMMAP-002.tsx
 * @ 작성자     : 박상현 (sanghyeon.park@bankwareglobal.com)
 * @ 작성일     : 2024-04-16
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2024-04-16             박상현                 최초작성
 ************************************************************************ */
import useCode from "@/hooks/useCode"
import useModal from "@/hooks/useModal"
import useProxy from "@/hooks/useProxy"
import useForm from "@/hooks/useForm"
import { $i18nUtils } from "@/utils/common.i18n"
import {
  Children,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react"

import Page from "@/components/Page"
import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import CardCol from "@/components/CardCol"
import CardRow from "@/components/CardRow"
import ContentToggle from "@/components/ContentToggle"
import Grid from "@/components/Grid"
import GridCount from "@/components/GridCount"
import GridSelectBox from "@/components/GridSelectBox"
import InputBox from "@/components/InputBox"
import InputIconBox from "@/components/InputIconBox"
import LabelBox from "@/components/LabelBox"
import SelectBox from "@/components/SelectBox"

import {
  CodeItem,
  ComTlgLaytMapD,
  ComTlgLaytMapM,
  Message,
  PopupParam,
  TelegramDetail,
  TelegramDetailTree,
  TelegramMap,
} from "@/types/index"
import { $storageUtils } from "@/utils/common.storage"
import useGrid from "@/hooks/useGrid"
import AuthButton from "@/components/AuthButton"
import CONFIG from "@/config/siteConfig"

interface DtoCellRendererProps {
  data: any
  node: any
  cellClickEvent: (rowIndex: number) => void
}

/**
 * 그리드 소스전문필드 Cell
 */
function SelectCellRenderer({ data, node, onChange }: any) {
  const { fieldList, sorcTlgFld } = data

  useEffect(() => {
    setDataList(fieldList)
  }, [fieldList])

  const handleOnChange = (value: string) => {
    // gridRef.updateRowByIndex()가 포함된 함수를 prop으로 받아서 여기서 호출
    const findItem = fieldList.find((field: any) => field.codeField === value)
    onChange(node.rowIndex, findItem.codeField, findItem.labelField)
  }

  const { control, setValue, reset, validate } = useForm({
    formName: "srcFld",
    defaultValues: { sorcTlgFld },
  })

  const [dataList, setDataList] = useState([])

  return (
    <div data-form="srcFld">
      <SelectBox
        control={control}
        name="sorcTlgFld"
        i18n={$i18nUtils.trans("SCRNITM#staffId")}
        list={dataList}
        visibleName={false}
        onChange={handleOnChange}
      />
    </div>
  )
}

function USYMMAP002() {
  const $codeHooks = useCode()
  const $proxyHooks = useProxy()
  const $modalHooks = useModal()

  const comTlgLaytMapM: ComTlgLaytMapM = {
    tlgLaytMapId: "",
    tlgLaytMapNm: "",
    trgtTlgLaytId: "",
    sorcTlgLaytId: "",
  }

  // 조회 Form
  const { control, setValue, reset, validate } = useForm({
    formName: "searchForm",
    defaultValues: comTlgLaytMapM,
  })

  // const comTlgLaytMapL: ComTlgLaytMapD = {
  //   trgtTlgLaytId: "",
  //   trgtTlgFld: "",
  //   sorcTlgLaytId: "",
  //   sorcTlgFld: "",
  //   trgtTlgFldNm: "",
  //   trgtTlgDataTp: "",
  //   trgtTlgFldDpt: 1,
  //   trgtTlgFldLen: 0,
  //   sorcTlgFldNm: "",
  //   sorcTlgDataTp: "",
  //   sorcTlgFldDpt: 1,
  //   sorcTlgFldLen: 0,
  // }

  // 등록/수정 Form
  const {
    control: controlCU,
    setValue: setValueCU,
    getValues: getValueCU,
    reset: resetCU,
    validate: validateCU,
  } = useForm({
    formName: "updateForm",
    defaultValues: comTlgLaytMapM,
  })

  // 소스전문레이아웃 목록
  const [sorcTlgDetailList, setSorcTlgDetailList] = useState<TelegramDetail[]>(
    [],
  )

  // 소스전문 SelectList
  const [sorcTlgSelectList, setSorcTlgSelectList] = useState<CodeItem[]>()

  // 그리드 config
  const { gridConfig, setGridConfig } = useGrid({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#tlgLaytMapId"), // 전문매핑ID
        field: "tlgLaytMapId",
        flex: 1,
        minWidth: 10,
      },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#tlgLaytMapNm"), // 전문매핑이름
      //   field: "tlgLaytMapNm",
      //   filter: true,
      //   flex: 1,
      //   minWidth: 10,
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#trgtTlgLaytId"), // 타겟전문레이아웃ID
        field: "trgtTlgLaytId",
        flex: 1,
        minWidth: 10,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgLaytId"), // 소스전문레이아웃ID
        field: "sorcTlgLaytId",
        flex: 1,
        minWidth: 10,
      },
    ],
    onRowClicked: useCallback((event: any) => {
      // showBox(true)
      // setIsEditable(true)
      initMapping()

      setValueCU("tlgLaytMapId", event.data.tlgLaytMapId)
      // setValueCU("tlgLaytMapNm", event.data.tlgLaytMapNm)
      setValueCU("trgtTlgLaytId", event.data.trgtTlgLaytId)
      setValueCU("sorcTlgLaytId", event.data.sorcTlgLaytId)

      getTlgMapInfo(event.data.trgtTlgLaytId, event.data.sorcTlgLaytId)
    }, []),
    rowClassRules: {
      "rag-amber-outer": (params: { data: { aprvStsCd: string } }) =>
        params.data.aprvStsCd !== "02",
    },
  })
  // 그리드 data
  const [gridData, setGridData] = useState<ComTlgLaytMapM[]>([])

  // 그리드 건수
  const [totalCnt, setTotalCnt] = useState(0)

  // 그리드 Ref
  const gridRef = useRef<any>()

  // const onChangeHandler = (index: number, field: any, fieldNm: any) => {
  //   gridMapRef.current.updateRowByIndex(index, "sorcTlgFld", field)
  //   gridMapRef.current.updateRowByIndex(index, "sorcTlgFldNm", fieldNm)
  //   gridMapRef.current.updateRowByIndex(
  //     index,
  //     "sorcTlgLaytId",
  //     getValueCU("sorcTlgLaytId"),
  //   )
  // }

  const onChangeHandler = (rowIndex: number, codeField: string) => {
    if (!codeField) {
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgLaytId", null)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFld", null)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFldNm", null)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFldDpt", null)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgDataTp", null)
      gridMapRef.current.updateRowByIndex(
        rowIndex,
        "crudType",
        CONFIG.CRUD.DELETE,
      )

      return
    }

    const findTlg = sorcTlgDetailList.find((tlg) => tlg.field === codeField)

    if (findTlg) {
      const { field, fieldNm, depth, dataType } = findTlg

      gridMapRef.current.updateRowByIndex(
        rowIndex,
        "sorcTlgLaytId",
        getValueCU("sorcTlgLaytId"),
      )
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFld", field)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFldNm", fieldNm)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgFldDpt", depth)
      gridMapRef.current.updateRowByIndex(rowIndex, "sorcTlgDataTp", dataType)
    }
  }

  const mapConfig = {
    columnDefs: [
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#msgId"), // 타겟전문관리번호
      //   field: "tlgLaytId",
      //   filter: true,
      //   flex: 1,
      //   minWidth: 10,
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#tgmItm"), // 타겟전문필드
        field: "fld",
        cellClass: "t-left",
        flex: 1,
        minWidth: 10,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tgmNm"), // 타겟전문필드명
        field: "fldNm",
        cellClass: "t-left",
        flex: 1,
        minWidth: 10,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#depth"), // 타겟전문필드깊이
        field: "fldDpt",
        width: 120,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#dataType"), // 타겟전문필드유형
        field: "dataTp",
        width: 140,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tgmLngth"), // 타겟전문필드길이
        field: "fldLen",
        width: 140,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgLaytId"), // 소스전문레이아웃ID
        field: "sorcTlgLaytId",
        flex: 1,
        minWidth: 10,
      },
      // {
      //   headerName: "fieldList",
      //   field: "fieldList",
      // },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#sorcTlgFld"), // 소스전문필드
      //   field: "sorcTlgFld",
      //   filter: true,
      //   width: 180,
      //   // editable: true,
      //   cellRenderer: SelectCellRenderer,
      //   cellRendererParams: {
      //     onChange: onChangeHandler,
      //   },
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgFld"), // 소스전문필드
        field: "sorcTlgFld",
        width: 180,
        editable: true,
        cellEditor: GridSelectBox,
        cellEditorParams: {
          list: sorcTlgSelectList,
          onChange: onChangeHandler,
        },
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgFldNm"), // 소스전문필드명
        field: "sorcTlgFldNm",
        flex: 1,
        minWidth: 10,
        cellClass: "t-left",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgFldDpt"), // 소스전문필드깊이
        field: "sorcTlgFldDpt",
        flex: 1,
        minWidth: 10,
        hide: true,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sorcTlgDataTp"), // 소스전문필드유형
        field: "sorcTlgDataTp",
        flex: 1,
        minWidth: 10,
        hide: true,
      },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#sorcTlgFldLen"), // 소스전문필드길이
      //   field: "sorcTlgFldLen",
      //   filter: true,
      //   flex: 1,
      //   minWidth: 10,
      // },
    ],
    rowClassRules: {
      "rag-amber-outer": (params: { data: { aprvStsCd: string } }) =>
        params.data.aprvStsCd !== "02",
    },
  }

  const [dummyGridConfig, setDummyGridConfig] = useState(mapConfig)

  const [gridMapConfig, setGridMapConfig] = useState<any>()

  useEffect(() => {
    // config 내 바인딩 되어 있어, 값이 설정 된 후 그리드를 렌더링
    if (sorcTlgSelectList) {
      setGridMapConfig(() => mapConfig)
    }
  }, [sorcTlgSelectList])

  // const [gridMapConfig, setGridMapConfig] = useState(gridMapDefaultConfig)

  // 그리드 data
  const [gridMapData, setGridMapData] = useState<TelegramMap[]>([])

  // 그리드 건수
  const [totalMapCnt, setTotalMapCnt] = useState(0)

  // 그리드 Ref
  const gridMapRef = useRef<any>()

  /**
   * 초기화 버튼 클릭
   */
  const initClick = (e: any) => {
    $eventUtils.setEventContext(e)

    reset()
    setTotalCnt(0)
    setGridData([])
    initMapping()
    // showBox(false)
  }

  const initMapping = () => {
    resetCU()
    setTotalMapCnt(0)
    setGridMapData([])
    setIsEditable(false)
  }

  /**
   * 전문 목록 조회
   */
  const searchTargetTlg = (e: any) => {
    $eventUtils.setEventContext(e)

    openTgmPopup("target")
  }

  const searchSourceTlg = (e: any) => {
    $eventUtils.setEventContext(e)

    openTgmPopup("source")
  }

  const searchCUTargetTlg = (e: any) => {
    $eventUtils.setEventContext(e)

    openTgmPopup("createTarget")
  }

  const searchCUSourceTlg = (e: any) => {
    $eventUtils.setEventContext(e)

    openTgmPopup("createSource")
  }

  const blurEventHandler = () => {
    const trgtLaytId = getValueCU("trgtTlgLaytId")
    const sorcLaytId = getValueCU("sorcTlgLaytId")

    if (trgtLaytId && sorcLaytId) {
      setValueCU("tlgLaytMapId", `${trgtLaytId}_${sorcLaytId}`)
    } else {
      setValueCU("tlgLaytMapId", "")
    }
  }

  /**
   * 전문조회 팝업 열기
   */
  const openTgmPopup = (type: string) => {
    const popupInfo: PopupParam = {
      screenId: "PSYMMSG-002",
      instance: "pages/popup/bcm/PSYMMSG-002",
    }
    $modalHooks.openPopup(popupInfo).then((result: any) => {
      const { tgmMgmtNo } = result
      if (type === "target") {
        setValue("trgtTlgLaytId", tgmMgmtNo)
      } else if (type === "source") {
        setValue("sorcTlgLaytId", tgmMgmtNo)
      } else if (type === "createTarget") {
        setValueCU("trgtTlgLaytId", tgmMgmtNo)

        const sorcLaytId = getValueCU("sorcTlgLaytId")
        if (sorcLaytId) {
          setValueCU("tlgLaytMapId", `${tgmMgmtNo}_${sorcLaytId}`)
        }
      } else {
        setValueCU("sorcTlgLaytId", tgmMgmtNo)

        const trgtLaytId = getValueCU("trgtTlgLaytId")
        if (trgtLaytId) {
          setValueCU("tlgLaytMapId", `${trgtLaytId}_${tgmMgmtNo}`)
        }
      }
    })
  }

  /**
   * 전문 매핑 목록 조회
   */
  const searchTlgMapList = (e: any) => {
    $eventUtils.setEventContext(e)

    validate().then((data: any) => {
      const param = {
        interfaceCd: "cmn",
        interfaceId: "getTlgMapMList",
        tlgLaytMapId: data.tlgLaytMapId,
        trgtTlgLaytId: data.trgtTlgLaytId,
        sorcTlgLaytId: data.sorcTlgLaytId,
      }
      $proxyHooks.async(param).then((response: any) => {
        setGridData(() => response.data.mapMList)
        setTotalCnt(response.data.totLen)
        initMapping()
      })
    })
  }

  /**
   * CSV 다운로드
   */
  // const csvClick = () => {
  //   gridRef.current.exportCsv(
  //     {
  //       fileName: "test.csv",
  //     },
  //     () => {
  //       $modalHooks.alert({ content: $i18nUtils.trans("MSG#noOutputData") }) // 출력할 DATA 가 없습니다.
  //     },
  //   )
  // }

  // 전문매핑 수정/등록 여부
  const [isEditable, setIsEditable] = useState(false)

  // 매핑정보 조회
  const getTlgMapInfo = (trgtTlgLaytId: string, sorcTlgLaytId: string) => {
    const paramA = {
      interfaceCd: "cmn",
      interfaceId: "getTlgMapInfo",
      trgtTlgLaytId,
      sorcTlgLaytId,
    }

    const paramB = {
      interfaceCd: "cmn",
      interfaceId: "getTgmDtlList",
      tgmMgmtNo: sorcTlgLaytId,
    }

    $proxyHooks.promiseAllSettled(paramA, paramB).then((results: any[]) => {
      const sourceTlgList: TelegramDetail[] =
        results[1].value.data.subDtlOutList
      setSorcTlgDetailList(sourceTlgList)

      const selectFieldList = sourceTlgList.reduce(
        (acc: CodeItem[], tlg: TelegramDetail) => {
          const obj: CodeItem = {
            codeField: tlg.field,
            labelField: tlg.fieldNm,
            label: "",
          }
          acc.push(obj)
          return acc
        },
        [],
      )

      setSorcTlgSelectList(selectFieldList)

      const updateJoinOutList = results[0].value.data.joinOutList.reduce(
        (acc, out: TelegramMap) => {
          acc.push({
            ...out,
            aprvStsCd: out.aprvStsCd ?? "02",
            // fieldList: selectFieldList,
          })
          return acc
        },
        [],
      )
      setGridMapData(updateJoinOutList)
      setTotalMapCnt(results[0].value.data.totLen)
    })
  }

  // 신규
  const newClick = (e: any) => {
    $eventUtils.setEventContext(e)

    setIsEditable(true)
    // reset()
    resetCU()
    // setGridData([])
    // setTotalCnt(0)
    setGridMapData([])
    setTotalMapCnt(0)
  }

  const arrayToTree = (array: TelegramDetail[]): TelegramDetailTree[] => {
    const treeNode: TelegramDetailTree[] = []
    let parentNode: TelegramDetailTree

    for (let i = 0; i < array.length; i++) {
      const item = array[i]
      const { dataType, depth } = item

      if (dataType === "FIELD" && depth === 1) {
        treeNode.push(item)
        continue
      }

      if (dataType === "ARRAY") {
        parentNode = { ...item, children: [] }
        treeNode.push(parentNode)
        continue
      }

      if (dataType === "FIELD" && depth && depth > 1) {
        treeNode.forEach((tree) => {
          if (
            parentNode.field === tree.field &&
            parentNode.dataType === "ARRAY" &&
            parentNode.depth === depth - 1 &&
            tree.children
          ) {
            tree.children.push(item)
          }
        })
      }
    }

    return treeNode
  }

  const validationMapCheck = (telegramMapList: TelegramMap[]) => {
    const srcTlgDetailTree = arrayToTree(sorcTlgDetailList)
    let parent: TelegramMap

    // 매핑이 된 필드들만 필터링
    const isMappedFldList = telegramMapList.filter(
      (map) => map.sorcTlgDataTp && map.sorcTlgFldDpt && map.sorcTlgFld,
    )
    if (isMappedFldList.length === 0) {
      return false
    }

    return isMappedFldList.every((map) => {
      const { dataTp, fldDpt, sorcTlgDataTp, sorcTlgFldDpt, sorcTlgFld } = map
      if (dataTp !== sorcTlgDataTp || fldDpt !== sorcTlgFldDpt) {
        return false
      }

      if (sorcTlgDataTp === "ARRAY") {
        parent = map
      }

      // 매핑한 소스전문의 자식필드(sorcTlgFldDpt > 1)가 매핑된 부모의 자식필드가 맞는지 판별
      if (sorcTlgFldDpt && sorcTlgFldDpt > 1) {
        return srcTlgDetailTree.every((root) => {
          if (root.field === parent.sorcTlgFld) {
            return root.children?.some((child) => child.field === sorcTlgFld)
          }
          return true
        })
      }

      return true
    })
  }

  // 수정
  const updateTlgMapClick = (e: any) => {
    $eventUtils.setEventContext(e)
    validateCU().then((data: any) => {
      $modalHooks
        .confirm({ content: $i18nUtils.trans("MSG#updateCnfMsg") }) // 내용을 수정하시겠습니까?
        .then((ok) => {
          if (!ok) return

          const tlgLaytMapId = getValueCU("tlgLaytMapId")
          const gridMapList = gridMapRef.current.getAllRows()

          const tlgLaytMapDList = gridMapList.reduce(
            (acc: ComTlgLaytMapD[], row: TelegramMap) => {
              if (
                row.crudType == CONFIG.CRUD.DELETE ||
                (row.sorcTlgLaytId && row.sorcTlgFld)
              ) {
                acc.push({
                  crudType: row.crudType,
                  tlgLaytMapId,
                  trgtTlgLaytId: row.tlgLaytId,
                  trgtTlgFld: row.fld,
                  trgtTlgFldNm: row.fldNm,
                  sorcTlgLaytId: row.sorcTlgLaytId,
                  sorcTlgFld: row.sorcTlgFld,
                  sorcTlgFldNm: row.sorcTlgFldNm,
                  sorcTlgDataTp: row.sorcTlgDataTp,
                  sorcTlgFldDpt: row.sorcTlgFldDpt,
                })
              }
              return acc
            },
            [],
          )
          const isValid = validationMapCheck(gridMapList)

          if (!isValid) {
            $modalHooks.alert({
              content: $i18nUtils.trans("MSG#notValidFieldMapping"),
            })
            return
          }

          const param = {
            interfaceCd: "cmn",
            interfaceId: "updateTlgMap",
            tlgLaytMapId,
            tlgLaytMapDList,
            cmnTlgLaytMapDList: tlgLaytMapDList,
          }

          $proxyHooks.async(param).then((response: any) => {
            initClick(e)
            searchTlgMapList(null)
          })
        })
    })
  }

  // 저장
  const saveTlgMapClick = (e: any) => {
    $eventUtils.setEventContext(e)

    $modalHooks
      .confirm({ content: $i18nUtils.trans("MSG#saveCnfMsg") }) // 내용을 저장하시겠습니까?
      .then((ok) => {
        if (!ok) return

        const tlgLaytMapId = getValueCU("tlgLaytMapId")
        const trgtTlgLaytId = getValueCU("trgtTlgLaytId")
        const sorcTlgLaytId = getValueCU("sorcTlgLaytId")
        const gridMapList = gridMapRef.current.getAllRows()

        const tlgLaytMapDList = gridMapList.reduce(
          (acc: ComTlgLaytMapD[], row: TelegramMap) => {
            if (row.sorcTlgLaytId && row.sorcTlgFld) {
              acc.push({
                tlgLaytMapId,
                trgtTlgLaytId: row.tlgLaytId,
                trgtTlgFld: row.fld,
                trgtTlgFldNm: row.fldNm,
                sorcTlgLaytId: row.sorcTlgLaytId,
                sorcTlgFld: row.sorcTlgFld,
                sorcTlgFldNm: row.sorcTlgFldNm,
                sorcTlgDataTp: row.sorcTlgDataTp,
                sorcTlgFldDpt: row.sorcTlgFldDpt,
              })
            }
            return acc
          },
          [],
        )

        const isValid = validationMapCheck(gridMapList)

        if (!isValid) {
          $modalHooks.alert({
            content: $i18nUtils.trans("MSG#notValidFieldMapping"),
          })
          return
        }

        const param = {
          interfaceCd: "cmn",
          interfaceId: "saveTlgMap",
          tlgLaytMapId,
          trgtTlgLaytId,
          sorcTlgLaytId,
          tlgLaytMapDList,
        }

        $proxyHooks.async(param).then((response: any) => {
          initClick(e)
          searchTlgMapList(null)
        })
      })
  }

  // 매핑
  const mappingHandler = (e: any) => {
    $eventUtils.setEventContext(e)

    const paramA = {
      interfaceCd: "cmn",
      interfaceId: "getTgmDtlList",
      tgmMgmtNo: getValueCU("trgtTlgLaytId"),
    }

    const paramB = {
      interfaceCd: "cmn",
      interfaceId: "getTgmDtlList",
      tgmMgmtNo: getValueCU("sorcTlgLaytId"),
    }

    $proxyHooks.promiseAllSettled(paramA, paramB).then((results: any[]) => {
      // const targetTlgList = results[0].value.data.subDtlOutList

      const makeGridMapData = results[0].value.data.subDtlOutList.reduce(
        (acc: TelegramMap[], tlg: TelegramDetail) => {
          const {
            tgmMgmtNo,
            field,
            fieldNm,
            fieldEn,
            dataType,
            depth,
            length,
          } = tlg
          const newObj: TelegramMap = {
            tlgLaytId: tgmMgmtNo ?? "",
            fld: field ?? "",
            fldNm: fieldNm,
            fldDpt: depth,
            dataTp: dataType,
            fldLen: length,
            sorcTlgLaytId: "",
            sorcTlgFld: "",
            sorcTlgFldNm: "",
            // sorcTlgFldDpt: undefined,
            sorcTlgDataTp: "",
            // sorcTlgFldLen: undefined,
            aprvStsCd: "02",
          }

          acc.push(newObj)
          return acc
        },
        [],
      )

      const sourceTlgList = results[1].value.data.subDtlOutList
      setSorcTlgDetailList(sourceTlgList)

      const selectFieldList = sourceTlgList.reduce(
        (acc: CodeItem[], tlg: TelegramDetail) => {
          const obj: CodeItem = {
            codeField: tlg.field,
            labelField: tlg.fieldNm,
            label: "",
          }
          acc.push(obj)
          return acc
        },
        [],
      )

      setSorcTlgSelectList(selectFieldList)

      const sorcTlgLaytId = getValueCU("sorcTlgLaytId")

      const updatedGridMapData = makeGridMapData.map((tlgMap: TelegramMap) => {
        const matchingSourceTlg = sourceTlgList.find(
          (sourceTlg: TelegramDetail) =>
            tlgMap.fld === sourceTlg.field &&
            tlgMap.dataTp === sourceTlg.dataType &&
            tlgMap.fldDpt === sourceTlg.depth,
        )

        const result = {
          ...tlgMap,
          fieldList: selectFieldList,
        }

        if (matchingSourceTlg) {
          return {
            ...result,
            sorcTlgLaytId,
            sorcTlgFld: matchingSourceTlg.field,
            sorcTlgFldNm: matchingSourceTlg.fieldNm,
            sorcTlgDataTp: matchingSourceTlg.dataType,
            sorcTlgFldDpt: matchingSourceTlg.depth,
          }
        }

        return result
      })
      // const convertData = updatedConverGridMapData.map((item: any) => ({
      //   ...item,
      //   // fieldList: JSON.stringify(sourceFieldRef.current),
      //   fieldList: selectFieldList,
      // }))
      // gridMapRef.current.source = data
      // // gridMapRef.current.refreshCells()
      // setSourceTlgList(data)
      // // gridMapRef.current.updateRowByIndex(0, "sorcTlgLaytId", "")
      setGridMapData(updatedGridMapData)
    })
  }

  return (
    <Page ctrlEnter={searchTlgMapList}>
      <div className="row-group">
        {/** Sub Content S */}
        <div className="sub-content search-wrap" data-form="searchForm">
          <h3 className="tit">{$i18nUtils.trans("SCRNITM#srchCndtn")}</h3>
          <ButtonGroup>
            <Button
              name="init"
              i18n={$i18nUtils.trans("SCRNITM#init")}
              color="white btn-lg"
              onClick={initClick}
            >
              초기화
            </Button>
            <Button
              name="search"
              i18n={$i18nUtils.trans("SCRNITM#search")}
              color="green"
              onClick={searchTlgMapList}
            >
              조회
            </Button>
          </ButtonGroup>
          <ContentToggle />
          <div className="view-box">
            <CardRow cols={4}>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#tlgLaytMapId")}>
                  전문매핑ID
                </LabelBox>
                <InputBox
                  control={control}
                  name="tlgLaytMapId"
                  i18n={$i18nUtils.trans("SCRNITM#tlgLaytMapId")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#trgtTlgLaytId")}>
                  타겟전문레이아웃ID
                </LabelBox>
                <InputIconBox
                  icon="search"
                  control={control}
                  name="trgtTlgLaytId"
                  i18n={$i18nUtils.trans("SCRNITM#trgtTlgLaytId")}
                  onClick={searchTargetTlg}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#sorcTlgLaytId")}>
                  소스전문레이아웃ID
                </LabelBox>
                <InputIconBox
                  icon="search"
                  control={control}
                  name="sorcTlgLaytId"
                  i18n={$i18nUtils.trans("SCRNITM#sorcTlgLaytId")}
                  onClick={searchSourceTlg}
                />
              </CardCol>
            </CardRow>
          </div>
        </div>
        {/** // Sub Content E */}
        {/** Sub Content S */}
        <div className="sub-content">
          <GridCount
            i18n={$i18nUtils.trans("SCRNITM#mappingList")}
            count={totalCnt}
          />
          <div className="view-box active">
            <div className="col-01">
              <div className="cmm-table">
                <Grid
                  config={gridConfig}
                  rowData={gridData}
                  height={212}
                  ref={gridRef}
                />
              </div>
            </div>
          </div>
        </div>
        {/** // Sub Content E */}

        {/** Sub Content S */}
        <div className="detailListWrap">
          <div className="sub-content">
            <h3 className="tit">{$i18nUtils.trans("SCRNITM#mappingInfo")}</h3>
            <ButtonGroup className="m-right">
              <AuthButton
                name="new"
                i18n={$i18nUtils.trans("SCRNITM#new")}
                color="white"
                icon="add"
                onClick={newClick}
                roles={[CONFIG.ROLE_CD.ALL, CONFIG.ROLE_CD.KCG_TECH_SUPPORT]}
              >
                신규
              </AuthButton>
              {isEditable ? (
                <AuthButton
                  name="save"
                  i18n={$i18nUtils.trans("SCRNITM#save")}
                  color="green"
                  onClick={saveTlgMapClick}
                  // onClick={updateTlgMapClick}
                  roles={[CONFIG.ROLE_CD.ALL, CONFIG.ROLE_CD.KCG_TECH_SUPPORT]}
                >
                  저장
                </AuthButton>
              ) : (
                <AuthButton
                  name="modify"
                  i18n={$i18nUtils.trans("SCRNITM#modify")}
                  color="white"
                  icon="modify"
                  onClick={updateTlgMapClick}
                  roles={[CONFIG.ROLE_CD.ALL, CONFIG.ROLE_CD.KCG_TECH_SUPPORT]}
                >
                  수정
                </AuthButton>
              )}
            </ButtonGroup>
            <div className="view-box active" data-form="updateForm">
              <CardRow cols={4}>
                <CardCol>
                  <LabelBox i18n={$i18nUtils.trans("SCRNITM#tlgLaytMapId")}>
                    전문매핑ID
                  </LabelBox>
                  <InputBox
                    control={controlCU}
                    name="tlgLaytMapId"
                    i18n={$i18nUtils.trans("SCRNITM#tlgLaytMapId")}
                    disabled
                    rules={{
                      required: { value: true },
                    }}
                    // disabled={!isEditable}
                  />
                </CardCol>
                {isEditable && (
                  <>
                    <CardCol>
                      <LabelBox
                        i18n={$i18nUtils.trans("SCRNITM#trgtTlgLaytId")}
                      >
                        타겟전문레이아웃ID
                      </LabelBox>
                      <InputIconBox
                        icon="search"
                        control={controlCU}
                        name="trgtTlgLaytId"
                        i18n={$i18nUtils.trans("SCRNITM#trgtTlgLaytId")}
                        onClick={searchCUTargetTlg}
                        onBlur={blurEventHandler}
                      />
                    </CardCol>
                    <CardCol>
                      <LabelBox
                        i18n={$i18nUtils.trans("SCRNITM#sorcTlgLaytId")}
                      >
                        소스전문레이아웃ID
                      </LabelBox>
                      <InputIconBox
                        icon="search"
                        control={controlCU}
                        name="sorcTlgLaytId"
                        i18n={$i18nUtils.trans("SCRNITM#sorcTlgLaytId")}
                        onClick={searchCUSourceTlg}
                        onBlur={blurEventHandler}
                      />
                    </CardCol>
                  </>
                )}
              </CardRow>
            </div>
          </div>
          <div className="sub-content">
            <GridCount
              i18n={$i18nUtils.trans("SCRNITM#tgmFrmt")}
              count={totalMapCnt}
            />
            {isEditable && (
              <ButtonGroup className="m-right">
                <AuthButton
                  name="mapping"
                  i18n={$i18nUtils.trans("SCRNITM#mapping")}
                  color="white"
                  onClick={mappingHandler}
                  roles={[CONFIG.ROLE_CD.ALL, CONFIG.ROLE_CD.KCG_TECH_SUPPORT]}
                >
                  매핑
                </AuthButton>
                {/* <Button
                  i18n="TEST"
                  color="white"
                  onClick={() => {
                    const test = gridMapRef.current.getAllRows()
                  }}
                >
                  매핑
                </Button> */}
              </ButtonGroup>
            )}

            <div className="view-box active">
              <div className="col-01">
                <div className="cmm-table">
                  {/* gridMapConfig이 존재하기 전에 Grid가 그려지면 에러가 발생하므로, 없을 때 그려질 대체 그리드 생성 */}
                  {gridMapConfig ? (
                    <Grid
                      config={gridMapConfig}
                      rowData={gridMapData}
                      height={572}
                      ref={gridMapRef}
                    />
                  ) : (
                    <Grid
                      config={dummyGridConfig}
                      rowData={[]}
                      height={572}
                      ref={gridMapRef}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Page>
  )
}

export default USYMMAP002
