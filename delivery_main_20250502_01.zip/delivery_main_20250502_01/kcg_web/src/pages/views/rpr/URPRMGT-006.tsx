import { $eventUtils } from "@/utils/common.event"
/** ***********************************************************************
 * @ 서비스경로  : 자금청구반환 > 운영 > 자금반환 - FAX 청구접수 반환 등록
 * @ 페이지설명  : [URPRMGT-006] 자금반환 - FAX 청구접수 반환 등록
 * @ 파일명     : URPRMGT-006.tsx
 * @ 작성자     : 이주현 (joohyun.lee@bankwareglobal.com)
 * @ 작성일     : 2024-10-24
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2024-10-24            이주현                 최초작성
 *************************************************************************/
import CONFIG from "@/config/siteConfig"
import useProxy from "@/hooks/useProxy"
import useForm from "@/hooks/useForm"
import { $i18nUtils } from "@/utils/common.i18n"
import { useCallback, useRef, useState, useEffect } from "react"
import { $dateUtils } from "@/utils/common.date"
import { $bizUtils } from "@/utils/common.biz"
import { $formatUtils } from "@/utils/common.format"
import { $storageUtils } from "@/utils/common.storage"
import useCode from "@/hooks/useCode"
import useGrid from "@/hooks/useGrid"
import Page from "@/components/Page"
import useMenu from "@/hooks/useMenu"
import AuthButton from "@/components/AuthButton"
import useDownloader from "@/hooks/useDownloader"
import Grid from "@/components/Grid"
import GridCount from "@/components/GridCount"
import SelectBox from "@/components/SelectBox"
import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import CardCol from "@/components/CardCol"
import CardRow from "@/components/CardRow"
import ContentToggle from "@/components/ContentToggle"
import InputBox from "@/components/InputBox"
import LabelBox from "@/components/LabelBox"
import DatePicker from "@/components/DatePicker"

/**
 *
 * @returns 페이지 메인
 */
function URPRMGT006() {
  const $codeHooks = useCode()
  const $proxyHooks = useProxy()
  const $menuHooks = useMenu()

  //메인 조회조건Form
  const { control, validate, setValue, reset, getValues } = useForm({
    formName: "searchForm",
    defaultValues: {
      trStrDt: $dateUtils.today(),
      trEndDt: $dateUtils.today(),
    },
  })

  // 우측상세조회Form
  const {
    control: detailControl,
    setValue: setDetailValue,
    reset: resetDetail,
    validate: validateDetail,
    getValues: getDetailValues,
  } = useForm({
    formName: "detailForm",
    defaultValues: {
      makeId: $storageUtils.session("staffId"), // 등록자
      makeDttm: $dateUtils.today(), //등록일자
    },
  })

  //출력총건수
  const [totalCnt, setTotalCnt] = useState(0)

  // 우측 나타나는 창 controll
  const showBox = (show: boolean) => {
    if (show) {
      setDetailForm({
        grid: "gridList active",
        box: "detailView active",
      })
    } else {
      setDetailForm({ grid: "gridList", box: "detailView" })
    }
  }

  // 우측창 출력 여부
  const [cls, setDetailForm] = useState({
    grid: "gridList ",
    box: "detailView",
  }) // 안보이는 상태,, {grid: "detaList", box: "detailView active"}

  useEffect(() => {
    $codeHooks.getMsgTemplateList()
  }, [])

  // 목록조회
  const getListFaxFundReturn = (event: any, pgNbr: number) => {
    $eventUtils.setEventContext(event)
    resetDetail()
    showBox(false)

    validate().then((data: any) => {
      const param = {
        interfaceCd: "rpr",
        interfaceId: "getListFaxFundReturn",
        trStrDt: data?.trStrDt, //거래시작일
        trEndDt: data?.trEndDt, //거래종료일
        kftcTlgTrNo: data?.kftcTlgTrNo, //결제원전문번호
        orgnRcvAcctNo: data?.orgnRcvAcctNo, //원거래수취계좌번호
        pgNbr,
        pgCnt: 1000,
      }
      console.log(param)
      $proxyHooks.async(param).then((response: any) => {
        if (pgNbr > 1) {
          // 스크롤이 전부 내려졌을 경우 데이터 추가
          setGridCount((prev) => ({
            ...prev,
            currentCnt: prev.currentCnt + (response.data?.listOut?.length ?? 0),
          }))
          setGridData((prev) => [...prev, ...(response.data?.listOut ?? [])])
        } else {
          // 첫 회 조회
          setGridData(() => response.data?.listOut)
          setGridCount((prevState) => ({
            ...prevState,
            totalCnt: response.data.totCnt,
            currentCnt: response.data?.listOut?.length ?? 0,
          }))
          pagingRef.current.setPgNbr(pgNbr)
          pagingRef.current.setLastPgNbr(response.data.totCnt)
        }

        setTotalCnt(response.data.totCnt)
      })
    })
  }

  // Form 상태를 관리할 상태 추가
  const [disabled, setDisabled] = useState(false)

  // 그리드 config
  const {
    gridConfig,
    gridCount,
    gridData,
    gridRef,
    pagingRef,
    resetGrid,
    setGridConfig,
    setGridCount,
    setGridData,
  } = useGrid({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#aprvSts"), // 승인상태
        field: "aprvStsCd",
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("APRV_STS_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
        cellClass: "t-center",
        pinned: "left",
      },
      {
        field: "trStsCd", //거래상태코드
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("TR_STS_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
        cellClass: "t-center",
        pinned: "left",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#pymntRtnRegDt"), //자금반환등록일
        field: "trDt",
        pinned: "left",
        valueGetter: (param: any) => {
          if (param.data.rqstRtnDvsnCd === "01") {
            return null
          } else {
            return `${param.data.trDt}`
          }
        },
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#pymntRtnDt"), //자금반환일
        field: "trDt",
        pinned: "left",
        valueGetter: (param: any) => {
          if (param.data.rqstRtnDvsnCd === "01") {
            return null
          } else {
            return `${param.data.trDt}`
          }
        },
      },
      {
        field: "outinDvsnCd", //당타발구분, Inbound/Outbound Classification
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("OUTIN_DVSN_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
        cellClass: "t-center",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#kftcMsgNbr"), // 결제원 전문번호, KFTC Message Number
        field: "trUnqNo", //거래고유번호
      },
      {
        field: "hostNo", //LVB/CQE 번호, LVB/CQE Number
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tgmNo"), // 전문번호, Message Number
        field: "rprTlgTrceNo", //전문추적번호
      },
      {
        field: "orgnTrDt", //원거래일, Original Transaction Date
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#orgnTrUniqNo"), // 원거래고유번호, Original transaction unique number
        field: "orgnTrUnqNo", //원거래고유번호
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#orgnTractBenefAcctNbr"), // 원거래수취계좌번호, Original transaction beneficiary account number
        field: "orgnRcvAcctNo", //수취계좌번호
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#orgnTrAmt"), // 원거래금액, Original Trax amount
        field: "orgnTrAmt", //원거래금액, Original Trax amount
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rtnAmt"), // 반환금액
        field: "rqstRtnTrAmt",
      },
      {
        field: "rqstDt", //청구일자
      },
      {
        field: "rqstTrUnqNo", // [KR] 청구거래고유번호 [EN] Request Transaction Unique Number
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rqstAmt"), // 청구금액
        field: "rqstAmt",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#tlgKnd"), // 전문종별, Message Type
        field: "tlgKndTrDvsnCd",
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("RPR_TLG_KND_DVSN_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rspnCd"), //응답코드, Response Code
        field: "respCd", //응답코드, Response Code
        valueGetter: (param: any) => {
          if (param.data.respCd != null) {
            return `${param.data.respCd} ${param.data.respMsg}`
          }
        },
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rtnBnk"), //반환은행, Return bank
        field: "hndlBnkCd",
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("BNK_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rqstBnk"), //청구은행, Request bank
        field: "opnBnkCd",
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("BNK_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#wireTp"),
        field: "kftcBizDvsnCd", //공동망종류, Type of Shared Network
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("KFTC_BIZ_DVSN_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
        cellClass: "t-center",
      },
      {
        field: "fullRtnYn", //전액반환여부, Full Refund Status
      },
      {
        field: "onlineRqstYn", // [KR] 온라인청구여부 [EN] Online Request Yn
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("RPR_ONLINE_YN", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rtnRsnCd"), //반환사유코드
        field: "rtnRsnCd", // [KR] 반환사유코드 [EN] Return Reason Code
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("RQST_RTN_RSN_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#rtnRsn"), //반환사유
        field: "rtnRsn", // [KR] 반환사유 [EN] Return Reason
      },
      {
        field: "rtnYn", //반환여부, Return status
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("RPR_RECALL_YN", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        field: "rtnRjctRsnCd", // [KR] 반환거부사유코드 [EN] Return Rejection Reason Code
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("RQST_RTN_RSN_CD", param.value, {
            visibleCode: false,
            visibleName: true,
          }),
      },
      {
        field: "rtnRjctRsn", // [KR] 반환거부사유 [EN] Return Rejection Reason
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#beneNm"), //수취인명, Beneficiary Name
        field: "rcpntNm",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#benefRealNm"), //수취인실명, Beneficiary Real Name
        field: "rcpntNm2",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#snderRealNm"), //송금인실명, Sender Real Name
        field: "sndrRealNm", //송금인실명, Sender Real Name
      },
      {
        field: "mgrTelNo", //담당자연락처
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#maker"), //
        field: "makeId",
      },
      {
        field: "makeDttm",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#aprvr"), //
        field: "chkId",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#aprvrDt"), //
        field: "chkDttm",
      },
    ],
    rowClassRules: {
      "rag-amber-outer": (params: { data: { aprvStsCd: string } }) =>
        params.data.aprvStsCd !== "02" &&
        params.data.aprvStsCd !== "03" &&
        params.data.aprvStsCd !== null,
    },
    // 행 클릭시 세부정보 셋팅
    onRowClicked: useCallback((event: any) => {
      const { data } = event
      resetDetail()
      showBox(true)
      setDetailTransactionInfo(event.data) // 우측 세부정보 셋팅
      setIsNew(false)

      toggleDisabledField(data.kftcBizDvsnCd, data.aprvStsCd)
    }, []),

    onRowDoubleClicked: useCallback((event: any) => {
      if (event.data?.aprvStsCd !== "02" && event.data?.aprvStsCd) {
        // 승인 화면으로 이동
        const params: any = {
          aprvTpCd: "71",
          aprvKeyVal: event.data?.bnkCd,
        }
        $menuHooks.openMenuByScrnId("UOPSAPR-001", params)
      } else if (event.data.aprvStsCd !== null) {
        // 거래내역조회 화면으로 이동
        const params: any = {
          trStrDt: event.data?.trDt, // 자금반환등록일
          trEndDt: event.data?.trDt, // 자금반환일
          orgnTrUnqNo: event.data?.orgnTrUnqNo, //원거래고유번호
        }
        $menuHooks.openMenuByScrnId("URPRINQ-007", params)
      }
    }, []),

    suppressScrollOnNewData: true,
    pagingSetParam: {
      apiFunction: getListFaxFundReturn,
    },
  })

  /**
   * 반환거부사유 따라 반환거부사유 옵션 세팅
   */
  const [isDisabledRtnRjctRsn, setIsDisabledRtnRjctRsn] = useState(true)

  const updateRtnRjctRsnCd = useCallback((selectedValue: any) => {
    const rtnRjctRsnCd = selectedValue
    const rtnRjctRsnLabel = $codeHooks.codeValue(
      "RTN_RJCT_RSN_CD",
      rtnRjctRsnCd,
      {
        visibleCode: false,
      },
    )

    setDetailValue("rtnRjctRsn", null)

    if (rtnRjctRsnCd === "99") {
      setIsDisabledRtnRjctRsn(true)
    } else if (rtnRjctRsnCd === "51") {
      setIsDisabledRtnRjctRsn(true)
    } else {
      setIsDisabledRtnRjctRsn(false)
      setDetailValue("rtnRjctRsn", rtnRjctRsnLabel)
    }
  }, [])

  /*
   * kftcBizDvsnCd가 HOFI(03)이고, 승인완료 아닐때만 상세화면 등록버튼 활성화
   */
  const [isDuplicate, setIsDuplicate] = useState(false)

  const toggleDisabledField = (kftcBizDvsnCd: string, aprvStscd: string) => {
    if (kftcBizDvsnCd == "03" && aprvStscd != "02") {
      setIsDuplicate(true)
    } else {
      setIsDuplicate(false)
    }
  }

  const initRtnRjctRsn = () => {
    setIsDisabledRtnRjctRsnCd(false)
    setIsDisabledRtnRjctRsn(false)
    setDetailValue("rtnRjctRsnCd", "")
    setDetailValue("rtnRjctRsn", "")
  }

  /**
   * 반환여부 코드에 따라
   */
  const [isDisabledRtnRjctRsnCd, setIsDisabledRtnRjctRsnCd] = useState(true)
  const updateRtnYn = useCallback((selectedValue: any) => {
    const rtnYn = selectedValue
    if (rtnYn === "Y") {
      initRtnRjctRsn()

      setIsDisabledRtnRjctRsnCd(true)
    } else if (rtnYn === "N") {
      setIsDisabledRtnRjctRsnCd(false)
    } else {
      initRtnRjctRsn()
      setIsDisabledRtnRjctRsnCd(false)
    }
  }, [])

  /**
   * 청구반환사유코드에 따라 청구반환사유 옵션 세팅
   */
  const [isDisabledRsn, setIsDisabledRsn] = useState(true)

  const updateRtnRsn = useCallback((selectedValue: any) => {
    const rtnRsnCd = selectedValue
    const rtnRsnLabel = $codeHooks.codeValue("RQST_RTN_RSN_CD", rtnRsnCd, {
      visibleCode: false,
    })

    setDetailValue("rtnRsn", null)

    if (rtnRsnCd === "05") {
      setIsDisabledRsn(false)
    } else {
      setIsDisabledRsn(true)
      setDetailValue("rtnRsn", rtnRsnLabel)
    }
  }, [])

  // 추가: isNew 상태로 신규 여부를 구분
  const [isNew, setIsNew] = useState(false)

  const initClick = (e: any) => {
    $eventUtils.setEventContext(e)
    reset()
    resetDetail()
    setIsNew(false)
    showBox(false)
    setTotalCnt(0)
    setGridData([])
    setGridCount({ totalCnt: 0, currentCnt: 0 })
    pagingRef.current.setPgNbr(1)
    pagingRef.current.setLastPgNbr(1)
  }

  //상세내용 셋팅
  const setDetailTransactionInfo = (data: any) => {
    //PK
    setDetailValue("trDt", data.trDt)
    setDetailValue("outinDvsnCd", data.outinDvsnCd)
    setDetailValue("hostNo", data.hostNo)
    setDetailValue("trUnqNo", data.trUnqNo)
    //disabled
    setDetailValue("aprvStsCd", data.aprvStsCd)
    setDetailValue("trStsCd", data.trStsCd)
    setDetailValue("pymntRqstRcptRegDt", data.pymntRqstRcptRegDt)
    setDetailValue("pymntrqstRcptDt", data.pymntrqstRcptDt)
    setDetailValue("outinDvsnCd", data.outinDvsnCd)
    setDetailValue("trUnqNo", data.trUnqNo)
    setDetailValue("hostNo", data.hostNo)
    setDetailValue("hofTlgTrceNo", data.hofTlgTrceNo)
    setDetailValue("orgnTrDt", data.orgnTrDt)
    setDetailValue("orgnTrUnqNo", data.orgnTrUnqNo)
    setDetailValue("rcvAcctNo", data.rcvAcctNo)
    setDetailValue("orgnTrAmt", data.orgnTrAmt)
    setDetailValue("rqstRtnTrAmt", data.rqstRtnTrAmt)
    setDetailValue("rqstDt", data.rqstDt)
    setDetailValue("rqstAmt", data.rqstAmt)
    setDetailValue("rqstTrUnqNo", data.rqstTrUnqNo)
    setDetailValue("tlgKndDvsnCd", data.tlgKndDvsnCd)
    setDetailValue("respCd", data.respCd)
    setDetailValue("hndlBnkCd", data.hndlBnkCd)
    setDetailValue("opnBnkCd", data.opnBnkCd)
    setDetailValue("fullRtnYn", data.fullRtnYn)
    setDetailValue("onlineRqstYn", data.onlineRqstYn)
    setDetailValue("rtnRsn", data.rtnRsn)
    setDetailValue("rtnRsnCd", data.rtnRsnCd)
    setDetailValue("rtnYn", data.rtnYn)
    setDetailValue("rtnRjctRsnCd", data.rtnRjctRsnCd)
    setDetailValue("rtnRjctRsn", data.rtnRjctRsn)
    setDetailValue("rcpntNm", data.rcpntNm)
    setDetailValue("rcpntNm2", data.rcpntNm2)
    setDetailValue("sndrRealNm", data.sndrRealNm)
    setDetailValue("mgrTelNo", data.mgrTelNo)
    setDetailValue("makeId", data.makeId)
    setDetailValue("makeDttm", data.makeDttm)
    setDetailValue("chkId", data.chkId)
    setDetailValue("chkDttm", data.chkDttm)
    //audit
    setDetailValue("frstChngGuid", data.frstChngGuid)
    setDetailValue("frstChngStaffId", data.frstChngStaffId)
    setDetailValue("frstChngTmstmp", data.frstChngTmstmp)
    setDetailValue("lastChngGuid", data.lastChngGuid)
    setDetailValue("lastChngStaffId", data.lastChngStaffId)
    setDetailValue("lastChngTmstmp", data.lastChngTmstmp)

    setDisabled(true)
  }

  /**
   * 자금반환 - FAX 등록
   */
  const createFaxFundReturn = (e: any) => {
    validateDetail().then((data: any) => {
      console.log("🚀 ~ validate ~ data:", data)
      const param = {
        interfaceCd: "rpr",
        interfaceId: "createFaxFundReturn",
        trDt: $dateUtils.today(), // 거래일자 today
        outinDvsnCd: "01", // 당타발구분코드
        rqstDt: data.rqstDt,
        opnBnkCd: data.opnBnkCd,
        orgnTrDt: data.orgnTrDt,
        orgnTrUnqNo: data.orgnTrUnqNo,
        orgnRcvAcctNo: data.orgnRcvAcctNo,
        orgnTrAmt: data.orgnTrAmt,
        orgnTrDvsnCd: data.orgnTrDvsnCd,
        rtnRsnCd: data.rtnRsnCd,
        rtnRsn: data.rtnRsn,
        fullRtnYn: data.fullRtnYn,
        rtnYn: data.rtnYn,
        rtnRjctRsnCd: data.rtnRjctRsnCd,
        rtnRjctRsn: data.rtnRjctRsn,
        rqstRtnTrAmt: data.rqstRtnTrAmt,
        rqstAmt: data.rqstAmt,
        mgrTelNo: data.mgrTelNo,
      }
      console.log("🚀 ~ validate ~ param:", param)
      $proxyHooks.async(param).then((response: any) => {
        resetDetail()
        showBox(true)
        //재조회
        getListFaxFundReturn(null, data?.pageNo)
      })
    })
  }

  const [rtnRjctRsnCd, setRtnRjctRsnCd] = useState<string>("")
  const [rtnRjctRsn, setRtnRjctRsn] = useState<string>("")

  const handleRtnRjctRsnCdChange = (value: string) => {
    setRtnRjctRsnCd(value)
    if (value !== "99") {
      const nameValue = $codeHooks.codeValue("DENY_RESN", value, {
        visibleCode: false,
        visibleName: true,
      })
      setRtnRjctRsn(nameValue)
    } else {
      setRtnRjctRsn("")
    }
  }

  const { downloadExcel } = useDownloader(gridRef)

  /**
   * 신규버튼 눌렀을 경우
   */
  const newClick = (e: any) => {
    $eventUtils.setEventContext(e)
    resetDetail()
    showBox(true)
    setIsNew(true) // 신규 모드로 설정
    setDisabled(false) // 모든 필드 수정 가능
  }

  return (
    <Page title="자금반환 - FAX 청구접수 반환 등록">
      {/** Sub Content S */}
      <div className="content-wrap">
        <div className="sub-content search-wrap" data-form="searchForm">
          <h3 className="tit">{$i18nUtils.trans("SCRNITM#srchCndtn")}</h3>
          {/*조회조건*/}
          <ButtonGroup>
            <Button
              name="init"
              i18n={$i18nUtils.trans("SCRNITM#init")}
              color="white"
              onClick={initClick}
            >
              초기화
            </Button>
            <Button
              name="search"
              i18n={$i18nUtils.trans("SCRNITM#search")}
              color="blue"
              onClick={(event) => getListFaxFundReturn(event, 1)}
            >
              조회
            </Button>
          </ButtonGroup>
          <ContentToggle />
          {/* 조회조건 */}
          <div className="view-box">
            <CardRow cols={5}>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#trDt")} required />
                {/*거래일자*/}
                <div className="unit datepicker-wrap">
                  <DatePicker
                    control={control}
                    name="trStrDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchFromDt")}
                    rules={{
                      required: true,
                    }}
                  />
                  <DatePicker
                    control={control}
                    name="trEndDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchToDt")}
                    rules={{
                      required: true,
                      validate: {
                        validItem: (v: any) =>
                          $bizUtils.validateMessage({
                            value: getValues("trStrDt") > getValues("trEndDt"),
                            message: $i18nUtils.trans("MSG#validMinDate", {
                              0: $i18nUtils.trans("SCRNITM#strtDt"),
                              1: $formatUtils.dateFormat(getValues("trStrDt")),
                              2: $i18nUtils.trans("SCRNITM#endDt"),
                              3: $formatUtils.dateFormat(getValues("trEndDt")),
                            }),
                          }),
                      },
                    }}
                  />
                </div>
              </CardCol>
            </CardRow>
          </div>
        </div>
        {/* 조회조건 끝 */}

        <div className="col-group">
          <div className={cls.grid}>
            {/** 조회결과 그리드 시작 */}
            <div className="sub-content">
              <GridCount count={totalCnt} />
              <ButtonGroup className="m-right">
                <Button
                  name="excel"
                  i18n={$i18nUtils.trans("SCRNITM#excel")}
                  color="white"
                  icon="down"
                  onClick={downloadExcel}
                >
                  Excel
                </Button>
                <AuthButton
                  name="new"
                  i18n={$i18nUtils.trans("SCRNITM#new")}
                  color="white"
                  icon="add"
                  onClick={newClick}
                  roles={[
                    CONFIG.ROLE_CD.ALL,
                    CONFIG.ROLE_CD.KCG_OPS_STATIC_MAKER,
                  ]}
                >
                  신규
                </AuthButton>
              </ButtonGroup>
              <div className="view-box active">
                <div className="col-01">
                  <div className="cmm-table">
                    <Grid
                      config={gridConfig}
                      rowData={gridData}
                      ref={gridRef}
                      height={450}
                      selection="multiple"
                    />
                    {/** // 조회결과 그리드 종료 */}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 상세정보 */}
          <div className={cls.box}>
            <div className="sub-content" data-form="detailForm">
              <div className="title-wrap">
                <h3 className="tit">{$i18nUtils.trans("SCRNITM#entry")}</h3>
                <div className="btn-box m-right">
                  <AuthButton
                    name="register"
                    type="button"
                    className="btn-blue save"
                    onClick={createFaxFundReturn}
                    roles={[
                      CONFIG.ROLE_CD.ALL,
                      CONFIG.ROLE_CD.KCG_OPS_PAYMENT_MAKER,
                    ]}
                    disabled={!isNew} //신규버튼눌러서 상태가 new일때만 활성화
                  >
                    {/* 등록 */}
                    <span>{$i18nUtils.trans("SCRNITM#reg")}</span>
                  </AuthButton>
                  <button
                    type="button"
                    className="btn-white close"
                    onClick={() => {
                      showBox(false)
                      setIsNew(false) // isNew 상태 초기화
                    }}
                  >
                    {/*닫기*/}
                    <span>{$i18nUtils.trans("SCRNITM#close")}</span>
                  </button>
                </div>
              </div>
              <div className="tit">
                {$i18nUtils.trans("SCRNITM#rqstRtnTrInfo")}
              </div>
              <div className="view-box active">
                <CardRow cols={2}>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#aprvSts")} />
                    <SelectBox
                      control={detailControl}
                      name="aprvStsCd" //청구승인상태
                      listPromise={$codeHooks.getCodeList("APRV_STS_CD")}
                      i18n={$i18nUtils.trans("SCRNITM#aprvSts")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#trStsCd")} />
                    <SelectBox
                      control={detailControl}
                      listPromise={$codeHooks.getCodeList("TR_STS_CD")}
                      name="trStsCd" //거래상태
                      i18n={$i18nUtils.trans("SCRNITM#trSts")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#rqstDt")} />
                    <DatePicker
                      control={detailControl}
                      name="rqstDt" // 청구일자
                      i18n={$i18nUtils.trans("SCRNITM#rqstDt")}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#rqstBnk")} />
                    <SelectBox
                      control={detailControl}
                      name="opnBnkCd" //개설은행 = 청구은행
                      i18n={$i18nUtils.trans("SCRNITM#rqstBnk")}
                      listPromise={$codeHooks.getCodeList("BNK_CD")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      rules={{
                        required: { value: true },
                      }}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTrDt")} />
                    <DatePicker
                      control={detailControl}
                      name="orgnTrDt" //원거래일자
                      i18n={$i18nUtils.trans("SCRNITM#orgnTrDt")}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTrUniqNo")} />
                    <InputBox
                      control={detailControl}
                      name="orgnTrUnqNo" //원거래고유번호
                      i18n={$i18nUtils.trans("SCRNITM#orgnTrUniqNo")}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#orgnTractBenefAcctNbr")}
                    />
                    <InputBox
                      control={detailControl}
                      name="orgnRcvAcctNo" //원거래수취계좌번호
                      i18n={$i18nUtils.trans("SCRNITM#orgnTractBenefAcctNbr")}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#orgnTrAmt")} />
                    <InputBox
                      control={detailControl}
                      name="orgnTrAmt" //원거래금액
                      className="t-right"
                      i18n={$i18nUtils.trans("SCRNITM#orgnTrAmt")}
                      mask={{ mask: Number, thousandsSeparator: "," }}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#rtnRsnCd")}
                      required
                    />
                    <SelectBox
                      control={detailControl}
                      name="rtnRsnCd" // 반환사유코드
                      i18n={$i18nUtils.trans("SCRNITM#rtnRsnCd")}
                      exclude="00,01"
                      listPromise={$codeHooks.getCodeList("RQST_RTN_RSN_CD")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      rules={{
                        required: { value: true },
                      }}
                      onChange={(selectedValue) => updateRtnRsn(selectedValue)}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#rtnRsn")}
                      required
                    />
                    <InputBox
                      control={detailControl}
                      name="rtnRsn" // 반환사유
                      rules={{
                        required: { value: true },
                      }}
                      i18n={$i18nUtils.trans("SCRNITM#rtnRsn")}
                      disabled={isDisabledRsn}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#fullRtnYn")}
                      required
                    />
                    <SelectBox
                      control={detailControl}
                      name="fullRtnYn" // 전액반환여부
                      i18n={$i18nUtils.trans("SCRNITM#fullRtnYn")}
                      listPromise={$codeHooks.getCodeList("RPR_MATCH_YN")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      rules={{
                        required: { value: true },
                      }}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#rtnYn")}
                      required
                    />
                    <SelectBox
                      control={detailControl}
                      name="rtnYn" // 반환여부
                      i18n={$i18nUtils.trans("SCRNITM#rtnYn")}
                      listPromise={$codeHooks.getCodeList("RPR_RECALL_YN")}
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      rules={{
                        required: { value: true },
                      }}
                      onChange={(selectedValue) => updateRtnYn(selectedValue)}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#rtnRjctRsnCd")} />
                    <SelectBox
                      control={detailControl}
                      name="rtnRjctRsnCd" // 반환거부사유코드
                      i18n={$i18nUtils.trans("SCRNITM#rtnRjctRsnCd")}
                      listPromise={$codeHooks.getCodeList("RTN_RJCT_RSN_CD")}
                      exclude="00"
                      blankType={$i18nUtils.trans("SCRNITM#slct")}
                      onChange={(selectedValue) =>
                        updateRtnRjctRsnCd(selectedValue)
                      }
                      disabled={isDisabledRtnRjctRsnCd}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#rtnRjctRsn")} />
                    <InputBox
                      control={detailControl}
                      name="rtnRjctRsn" // 반환거부사유
                      i18n={$i18nUtils.trans("SCRNITM#rtnRjctRsn")}
                      disabled={!isDisabledRtnRjctRsn}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#rtnAmt")}
                      required
                    />
                    <InputBox
                      control={detailControl}
                      name="rqstRtnTrAmt" // 반환금액
                      i18n={$i18nUtils.trans("SCRNITM#rtnAmt")}
                      rules={{
                        required: { value: true },
                      }}
                      className="t-right"
                      mask={{ mask: Number, thousandsSeparator: "," }}
                      disabled={!isNew}
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#mgrTelNo")}
                      required
                    />
                    <InputBox
                      control={detailControl}
                      name="mgrTelNo" // 담당자연락처
                      i18n={$i18nUtils.trans("SCRNITM#mgrTelNo")}
                      mask={{ mask: /^.{1,15}$/ }} //15자리 숫자
                      rules={{
                        required: { value: true },
                      }}
                      disabled={!isNew}
                    />
                  </CardCol>
                  {/* audit                   */}
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#frstGuid")} />
                    <InputBox
                      control={detailControl}
                      name="frstChngGuid"
                      i18n={$i18nUtils.trans("SCRNITM#frstGuid")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#frstRegsStaff")}
                    />
                    <InputBox
                      control={detailControl}
                      name="frstChngStaffId" //최초등록자
                      i18n={$i18nUtils.trans("SCRNITM#frstRegsStaff")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#frstRegsDtm")} />
                    <InputBox
                      control={detailControl}
                      name="frstChngTmstmp" //최초등록일시
                      i18n={$i18nUtils.trans("SCRNITM#frstRegsDtm")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#lastGuid")} />
                    <InputBox
                      control={detailControl}
                      name="lastChngGuid" //최종guid
                      i18n={$i18nUtils.trans("SCRNITM#lastGuid")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox
                      i18n={$i18nUtils.trans("SCRNITM#lastChngStaff")}
                    />
                    <InputBox
                      control={detailControl}
                      name="lastChngStaffId"
                      i18n={$i18nUtils.trans("SCRNITM#lastChngStaff")}
                      disabled
                    />
                  </CardCol>
                  <CardCol className="half">
                    <LabelBox i18n={$i18nUtils.trans("SCRNITM#lastChngDttm")} />
                    <InputBox
                      control={detailControl}
                      name="lastChngTmstmp"
                      i18n={$i18nUtils.trans("SCRNITM#lastChngDttm")}
                      disabled
                    />
                  </CardCol>
                </CardRow>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/** // Sub Content E */}
    </Page>
  )
}
export default URPRMGT006
