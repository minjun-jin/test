package com.jpmc.kcg.frw;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Component;

import com.ibm.mq.constants.CMQC;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.jpmc.kcg.cms.biz.vo.LvbCmsComHdr;
import com.jpmc.kcg.cms.biz.vo.LvbCmsComHdrImpl;
import com.jpmc.kcg.cms.biz.vo.LvbCmsSumHdr;
import com.jpmc.kcg.cms.biz.vo.LvbCmsSumHdrImpl;
import com.jpmc.kcg.ent.biz.vo.CqeEntComHdr;
import com.jpmc.kcg.ent.biz.vo.CqeEntComHdrImpl;
import com.jpmc.kcg.ent.biz.vo.KftEntComHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntComHdrImpl;
import com.jpmc.kcg.ent.biz.vo.KftEntMngHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntMngHdrImpl;
import com.jpmc.kcg.frw.dao.FrwCfgMMapper;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.frw.dao.FrwMsgLMapper;
import com.jpmc.kcg.frw.dto.FrwCfgM;
import com.jpmc.kcg.frw.dto.FrwDtMgmtM;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.hof.biz.vo.GchHofComHdr;
import com.jpmc.kcg.hof.biz.vo.GchHofComHdrImpl;
import com.jpmc.kcg.hof.biz.vo.KftHofComHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofComHdrImpl;
import com.jpmc.kcg.hof.biz.vo.KftHofLcrHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofLcrHdrImpl;
import com.jpmc.kcg.hof.biz.vo.KftHofMngHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofMngHdrImpl;
import com.jpmc.kcg.hof.biz.vo.LvbHofComHdr;
import com.jpmc.kcg.hof.biz.vo.LvbHofComHdrImpl;
import com.jpmc.kcg.ift.biz.vo.CqeIftComHdr;
import com.jpmc.kcg.ift.biz.vo.CqeIftComHdrImpl;
import com.jpmc.kcg.ift.biz.vo.KftIftComHdr;
import com.jpmc.kcg.ift.biz.vo.KftIftComHdrImpl;
import com.jpmc.kcg.ift.biz.vo.KftIftMngHdr;
import com.jpmc.kcg.ift.biz.vo.KftIftMngHdrImpl;
import com.jpmc.kcg.ift.biz.vo.LvbIftComHdr;
import com.jpmc.kcg.ift.biz.vo.LvbIftComHdrImpl;
import com.jpmc.kcg.rpr.biz.vo.CqeRprComHdr;
import com.jpmc.kcg.rpr.biz.vo.CqeRprComHdrImpl;
import com.jpmc.kcg.rpr.biz.vo.KftRprComHdr;
import com.jpmc.kcg.rpr.biz.vo.KftRprComHdrImpl;
import com.jpmc.kcg.rpr.biz.vo.KftRprMngHdr;
import com.jpmc.kcg.rpr.biz.vo.KftRprMngHdrImpl;
import com.jpmc.kcg.rpr.biz.vo.LvbRprComHdr;
import com.jpmc.kcg.rpr.biz.vo.LvbRprComHdrImpl;

import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Slf4j
@Component
public class FrwTemplate {

	@Autowired
	private FrwContext frwContext;
	@Autowired
	private FrwExecutor frwExecutor;
	@Autowired
	private FrwTractId frwTractId;
	@Autowired
	private FrwMapper frwMapper;
	@Autowired
	private FrwCfgMMapper frwCfgMMapper;
	@Autowired
	private FrwMsgLMapper frwMsgLMapper;
	@Autowired
	private SystemProperties systemProperties;
	@Autowired(required = false)
	private JmsTemplate jmsTemplate;

	/**
	 * 
	 */
	protected Class<? extends Vo> findClass(FrwDestination frwDestination, String tlgCtt) {
		Class<? extends Vo> voClass = null;
		String strDestination = String.valueOf(frwDestination);
		if (StringUtils.endsWith(strDestination, "CMS")) {
			voClass = LvbCmsSumHdrImpl.class; // 호스트전문
			if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 30), "EB", "EC")) {
				voClass = LvbCmsComHdrImpl.class; // 호스트전문
			}
		} else if (StringUtils.endsWith(strDestination, "ENT")) {
			String msgType = StringUtils.left(tlgCtt, 6);
			if (StringUtils.contains(msgType, "CQE")) {
				voClass = CqeEntComHdrImpl.class; // 호스트전문
			} else {
				voClass = KftEntComHdrImpl.class; // 업무처리전문
				if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 12), "07", "08")) {
					voClass = KftEntMngHdrImpl.class; // 관리전문
				}
			}
		} else if (StringUtils.endsWith(strDestination, "HOF")) {
			String msgType = StringUtils.left(tlgCtt, 6);
			if (StringUtils.contains(msgType, "GCH")) {
				voClass = GchHofComHdrImpl.class; // 호스트전문
			} else if (StringUtils.contains(msgType, "LVB")) {
				voClass = LvbHofComHdrImpl.class; // 호스트전문
			} else {
				voClass = KftHofComHdrImpl.class; // 업무처리전문
				if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 12), "07", "08")) {
					voClass = KftHofMngHdrImpl.class; // 관리전문
				}
			}
		} else if (StringUtils.endsWith(strDestination, "LCR")) { // 순이체한도
			voClass = KftHofLcrHdrImpl.class; // 관리전문
		} else if (StringUtils.endsWith(strDestination, "RPR")) {
			String msgType = StringUtils.left(tlgCtt, 6);
			if (StringUtils.contains(msgType, "CQE")) {
				voClass = CqeRprComHdrImpl.class; // 호스트전문
			} else if (StringUtils.contains(msgType, "LVB")) {
				voClass = LvbRprComHdrImpl.class; // 호스트전문
			} else {
				voClass = KftRprComHdrImpl.class; // 업무처리전문
				if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 12), "07", "08")) {
					voClass = KftRprMngHdrImpl.class; // 관리전문
				}
			}
		} else if (StringUtils.endsWith(strDestination, "IFT")) {
			String msgType = StringUtils.left(tlgCtt, 6);
			if (StringUtils.contains(msgType, "CQE")) {
				voClass = CqeIftComHdrImpl.class; // 호스트전문
			} else if (StringUtils.contains(msgType, "LVB")) {
				voClass = LvbIftComHdrImpl.class; // 호스트전문
			} else {
				voClass = KftIftComHdrImpl.class; // 업무처리전문
				if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 14), "07", "08")) {
					voClass = KftIftMngHdrImpl.class; // 관리전문
				}
			}
		}
		return voClass;
	}

	/**
	 * 
	 */
	private String sendLocal(FrwDestination frwDestination, Vo vo, String tlgCtt, Map<String, String> tlgHdr, FrwMsgL frwMsgL) {
		log.debug("{}", vo);
		log.info(">{}]", tlgCtt);
		frwMsgL.setLogDttm(LocalDateTime.now());
		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
//		frwMsgL.setSvcGuid(frwMsgL.getSvcGuid());
//		frwMsgL.setInstnId(frwMsgL.getInstnId());
//		frwMsgL.setAppNm(frwMsgL.getAppNm());
//		frwMsgL.setHostCd(frwMsgL.getHostCd());
//		frwMsgL.setBizDvsnCd(frwMsgL.getBizDvsnCd());
//		frwMsgL.setTlgKndDvsnCd(frwMsgL.getTlgKndDvsnCd()); // 전문종별구분코드
//		frwMsgL.setTlgBizDvsnCd(frwMsgL.getTlgBizDvsnCd()); // 업무구분코드
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeEntComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(cqeEntComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeEntComHdr.);
			frwMsgL.setTrnsUnqNo(cqeEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeEntComHdr.getBnkCd());
//			frwMsgL.setHndlMsgNo(cqeEntComHdr.);
//			frwMsgL.setKftcMsgNo(cqeEntComHdr.);
//			frwMsgL.setInitInstCd(cqeEntComHdr.);
//			frwMsgL.setInitMsgNo(cqeEntComHdr.);
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeIftComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeIftComHdr.);
			frwMsgL.setTrnsUnqNo(cqeIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeIftComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(cqeIftComHdr.);
//			frwMsgL.setKftcMsgNo(cqeIftComHdr.);
//			frwMsgL.setInitInstCd(cqeIftComHdr.);
//			frwMsgL.setInitMsgNo(cqeIftComHdr.);
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeRprComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeRprComHdr.);
			frwMsgL.setTrnsUnqNo(cqeRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeRprComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(cqeRprComHdr.);
//			frwMsgL.setKftcMsgNo(cqeRprComHdr.);
//			frwMsgL.setInitInstCd(cqeRprComHdr.);
//			frwMsgL.setInitMsgNo(cqeRprComHdr.);
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(gchHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(gchHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(gchHofComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(gchHofComHdr.);
			frwMsgL.setTrnsUnqNo(gchHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(gchHofComHdr.getRequestBank());
//			frwMsgL.setHndlMsgNo(gchHofComHdr.);
//			frwMsgL.setKftcMsgNo(gchHofComHdr.);
//			frwMsgL.setInitInstCd(gchHofComHdr.);
//			frwMsgL.setInitMsgNo(gchHofComHdr.);
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntComHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntComHdr.getResponseCode1());
//			frwMsgL.setHostMsgNo(kftEntComHdr.);
			frwMsgL.setMsgTrckNo(kftEntComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftEntComHdr.);
//			frwMsgL.setHndlMsgNo(kftEntComHdr.);
//			frwMsgL.setKftcMsgNo(kftEntComHdr.);
//			frwMsgL.setInitInstCd(kftEntComHdr.);
//			frwMsgL.setInitMsgNo(kftEntComHdr.);
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntMngHdr.getResponseCode1());
//			frwMsgL.setHostMsgNo(kftEntMngHdr.);
			frwMsgL.setMsgTrckNo(kftEntMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntMngHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftEntMngHdr.);
//			frwMsgL.setHndlMsgNo(kftEntMngHdr.);
//			frwMsgL.setKftcMsgNo(kftEntMngHdr.);
//			frwMsgL.setInitInstCd(kftEntMngHdr.);
//			frwMsgL.setInitMsgNo(kftEntMngHdr.);
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofComHdr.);
			frwMsgL.setMsgTrckNo(kftHofComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftHofComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftHofComHdr.);
//			frwMsgL.setHndlMsgNo(kftHofComHdr.);
//			frwMsgL.setKftcMsgNo(kftHofComHdr.);
//			frwMsgL.setInitInstCd(kftHofComHdr.);
//			frwMsgL.setInitMsgNo(kftHofComHdr.);
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofMngHdr.);
			frwMsgL.setMsgTrckNo(kftHofMngHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftHofMngHdr.);
//			frwMsgL.setHndlInstCd(kftHofMngHdr.);
//			frwMsgL.setHndlMsgNo(kftHofMngHdr.);
//			frwMsgL.setKftcMsgNo(kftHofMngHdr.);
//			frwMsgL.setInitInstCd(kftHofMngHdr.);
//			frwMsgL.setInitMsgNo(kftHofMngHdr.);
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofLcrHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofLcrHdr.);
			frwMsgL.setMsgTrckNo(kftHofLcrHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftHofLcrHdr.);
//			frwMsgL.setHndlInstCd(kftHofLcrHdr.);
//			frwMsgL.setHndlMsgNo(kftHofLcrHdr.);
//			frwMsgL.setKftcMsgNo(kftHofLcrHdr.);
//			frwMsgL.setInitInstCd(kftHofLcrHdr.);
//			frwMsgL.setInitMsgNo(kftHofLcrHdr.);
		} else if (vo instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftComHdr.getKftcMessageTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftIftComHdr.);
//			frwMsgL.setMsgTrckNo(kftIftComHdr.);
//			frwMsgL.setTrnsUnqNo(kftIftComHdr.);
			frwMsgL.setHndlInstCd(kftIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(kftIftComHdr.getRequestMessageNumber());
			frwMsgL.setKftcMsgNo(kftIftComHdr.getKftcMessageNumber());
			frwMsgL.setInitInstCd(kftIftComHdr.getBeneficiaryBankCode());
			frwMsgL.setInitMsgNo(kftIftComHdr.getBeneficiaryMessageNumber());
		} else if (vo instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftIftMngHdr.);
//			frwMsgL.setMsgTrckNo(kftIftMngHdr.);
//			frwMsgL.setTrnsUnqNo(kftIftMngHdr.);
//			frwMsgL.setHndlInstCd(kftIftMngHdr.);
//			frwMsgL.setHndlMsgNo(kftIftMngHdr.);
//			frwMsgL.setKftcMsgNo(kftIftMngHdr.);
//			frwMsgL.setInitInstCd(kftIftMngHdr.);
//			frwMsgL.setInitMsgNo(kftIftMngHdr.);
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftRprComHdr.);
			frwMsgL.setMsgTrckNo(kftRprComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftRprComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftRprComHdr.);
//			frwMsgL.setHndlMsgNo(kftRprComHdr.);
//			frwMsgL.setKftcMsgNo(kftRprComHdr.);
//			frwMsgL.setInitInstCd(kftRprComHdr.);
//			frwMsgL.setInitMsgNo(kftRprComHdr.);
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftRprMngHdr.);
			frwMsgL.setMsgTrckNo(kftRprMngHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftRprMngHdr.);
//			frwMsgL.setHndlInstCd(kftRprMngHdr.);
//			frwMsgL.setHndlMsgNo(kftRprMngHdr.);
//			frwMsgL.setKftcMsgNo(kftRprMngHdr.);
//			frwMsgL.setInitInstCd(kftRprMngHdr.);
//			frwMsgL.setInitMsgNo(kftRprMngHdr.);
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbCmsComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbCmsComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbCmsComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbCmsComHdr.);
//			frwMsgL.setTrnsUnqNo(lvbCmsComHdr.);
//			frwMsgL.setHndlInstCd(lvbCmsComHdr.);
//			frwMsgL.setHndlMsgNo(lvbCmsComHdr.);
//			frwMsgL.setKftcMsgNo(lvbCmsComHdr.);
//			frwMsgL.setInitInstCd(lvbCmsComHdr.);
//			frwMsgL.setInitMsgNo(lvbCmsComHdr.);
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(frwMsgL.getLogDttm());
			frwMsgL.setRespCd("");
			frwMsgL.setHostMsgNo(lvbCmsSumHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbCmsSumHdr.);
//			frwMsgL.setTrnsUnqNo(lvbCmsSumHdr.);
//			frwMsgL.setHndlInstCd(lvbCmsSumHdr.);
//			frwMsgL.setHndlMsgNo(lvbCmsSumHdr.);
//			frwMsgL.setKftcMsgNo(lvbCmsSumHdr.);
//			frwMsgL.setInitInstCd(lvbCmsSumHdr.);
//			frwMsgL.setInitMsgNo(lvbCmsSumHdr.);
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbHofComHdr.);
			frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
//			frwMsgL.setHndlMsgNo(lvbHofComHdr.);
//			frwMsgL.setKftcMsgNo(lvbHofComHdr.);
//			frwMsgL.setInitInstCd(lvbHofComHdr.);
//			frwMsgL.setInitMsgNo(lvbHofComHdr.);
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbIftComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbIftComHdr.);
			frwMsgL.setTrnsUnqNo(lvbIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbIftComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(lvbIftComHdr.);
//			frwMsgL.setKftcMsgNo(lvbIftComHdr.);
//			frwMsgL.setInitInstCd(lvbIftComHdr.);
//			frwMsgL.setInitMsgNo(lvbIftComHdr.);
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbRprComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbRprComHdr.);
			frwMsgL.setTrnsUnqNo(lvbRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbRprComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(lvbRprComHdr.);
//			frwMsgL.setKftcMsgNo(lvbRprComHdr.);
//			frwMsgL.setInitInstCd(lvbRprComHdr.);
//			frwMsgL.setInitMsgNo(lvbRprComHdr.);
		}
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
			frwMsgL.setTractSortCd("22"); // 타발요구송신
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 내부요구송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("10"); // 내부요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			frwMsgL.setTractSortCd("24"); // 타발응답송신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("14"); // 당발응답송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 당발응답송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("14"); // 당발응답송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else { // 요구
			frwMsgL.setTractSortCd("12"); // 당발요구송신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("22"); // 타발요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 내부요구송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("10"); // 내부요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		}
//		frwMsgL.setTractId(frwMsgL.getTractId());
//		frwMsgL.setOrgnTractId(frwMsgL.getOrgnTractId());
//		frwMsgL.setFrstTractId(frwMsgL.getFrstTractId());
//		frwMsgL.setUsrId(frwMsgL.getUsrId());
//		frwMsgL.setCrltnId(frwMsgL.getCrltnId());
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
		if (StringUtils.isEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
			if (StringUtils.isAlpha(frwMsgL.getTlgLaytId())) {
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 일자강제보정 ///////////////////////////////////////////////////////////
		Map<String, String> frwCfg;
		if (StringUtils.startsWithAny(StringUtils.left(StringUtils.upperCase(systemProperties.getEnvCd()), 1), "D", "T", "U")) { // 개발 | 테스트
			frwCfg = frwCfgMMapper.selectAll().stream()
			.collect(Collectors.toMap(FrwCfgM::getCfgKey, FrwCfgM::getCfgVal, ObjectUtils::defaultIfNull, TreeMap::new));
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
				if (StringUtils.equals(frwCfg.get("FRCV_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwCfg.get("FSND_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwCfg.get("ORGN_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwCfg.get("RQST_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwCfg.get("TEMP_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwCfg.get("TEST_DT_USE_YN"), "Y")) {
					for (FrwDtMgmtM frwDtMgmtM : frwMapper.selectFrwDtMgmtM(StringUtils.join(
						frwMsgL.getHostCd(),
						frwMsgL.getBizDvsnCd(),
						frwMsgL.getTlgKndDvsnCd(),
						frwMsgL.getTlgBizDvsnCd()
					))) {
						String dtDvsnCd = frwDtMgmtM.getDtDvsnCd();
						if (StringUtils.equals(dtDvsnCd, "FRCV") && StringUtils.equals(frwCfg.get("FRCV_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "FSND") && StringUtils.equals(frwCfg.get("FSND_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "ORGN") && StringUtils.equals(frwCfg.get("ORGN_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "RQST") && StringUtils.equals(frwCfg.get("RQST_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "TEMP") && StringUtils.equals(frwCfg.get("TEMP_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "TEST") && StringUtils.equals(frwCfg.get("TEST_DT_USE_YN"), "Y")) {
							String dtPrcs = frwCfg.get(frwDtMgmtM.getDtPrcsCd());
							int fldLen  = frwDtMgmtM.getFldLen ().intValue();
							int fldPstn = frwDtMgmtM.getFldPstn().intValue();
							if ( 6 == fldLen ||
								12 == fldLen) {
								dtPrcs = StringUtils.right(dtPrcs, 6);
							}
							if (StringUtils.equalsAny(dtDvsnCd, "FRCV", "FSND")) {
								dtPrcs = StringUtils.right(dtPrcs, 4);
								fldPstn += fldLen - 4;
							}
							byte[] byteArray = StringUtils.getBytes(tlgCtt, Charsets.toCharset("EUC-KR"));
							byte[] tempArray = StringUtils.getBytes(dtPrcs, Charsets.toCharset("EUC-KR"));
							System.arraycopy(tempArray, 0, byteArray, fldPstn, tempArray.length);
							tlgCtt = StringUtils.toEncodedString(byteArray, Charsets.toCharset("EUC-KR"));
						}
					}
					log.debug("[{}]", tlgCtt);
				}
			}
		} else {
			frwCfg = Map.of();
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwMsgL.setTlgCtt(tlgCtt);
//		frwMsgL.setStckTrc(frwMsgL.getStckTrc());
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
//		frwMsgL.setLastChngGuid(frwMsgL.getLastChngGuid());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
//		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
//		frwMsgL.setFrstChngGuid(frwMsgL.getFrstChngGuid());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
//		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setAprvStsCd(null);
		frwMsgL.setMakeId(null);
		frwMsgL.setMakeDttm(null);
		frwMsgL.setChkId(null);
		frwMsgL.setChkDttm(null);
		log.debug("{}", frwMsgL);
		frwMsgLMapper.insert(frwMsgL);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 개발우회 ///////////////////////////////////////////////////////////////
		if (null == jmsTemplate) {
			return frwMsgL.getTractId();
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		String destinationName = systemProperties.getSndQueNm(frwDestination);
		destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 호스트큐속성설정 ///////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
			destinationName = systemProperties.getSndQueNm(frwDestination);
			destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
				WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			if (FrwDestination.LVB_CMS.equals(frwDestination) ||
				FrwDestination.LVB_HOF.equals(frwDestination) ||
				FrwDestination.LVB_RPR.equals(frwDestination)) {
				destinationName = systemProperties.getSndQueNm(frwDestination);
				if (FrwDestination.LVB_HOF.equals(frwDestination) &&
					StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
					destinationName = systemProperties.getLvb().getHof().getAck();
				}
				destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
					WMQConstants.WMQ_CCSID, "=970&",
					WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			}
			if (FrwDestination.GCH_HOF.equals(frwDestination)) {
				destinationName = systemProperties.getSndQueNm(frwDestination);
				destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
					WMQConstants.WMQ_MQMD_WRITE_ENABLED, "=true&",
					WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 동기응답처리 ///////////////////////////////////////////////////////////
		if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
			destinationName = systemProperties.getKcg().getFrw().getCmn();
			destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 시뮬레이터처리 /////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(StringUtils.left(StringUtils.upperCase(systemProperties.getEnvCd()), 1), "D", "T", "U")) { // 개발 | 테스트
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
				if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
					if (StringUtils.equals(frwCfg.get(StringUtils.join("SIM_HOST_",
						StringUtils.right(String.valueOf(frwDestination), 3),
					"_YN")), "Y")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
				} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
					StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
					if (StringUtils.equals(frwMsgL.getUsrId(), "SIMSYS")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
				} else { // 요구
					if (StringUtils.equals(frwCfg.get(StringUtils.join("SIM_HOST_",
						StringUtils.right(String.valueOf(frwDestination), 3),
					"_YN")), "Y")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
				}
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		log.debug("{}", destinationName);
		jmsTemplate.setExplicitQosEnabled(true);
		String string = tlgHdr.get(WMQConstants.JMS_PRIORITY);
		if (StringUtils.isNotEmpty(string)) {
			jmsTemplate.setPriority(NumberUtils.toInt(string));
		}
		if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
			jmsTemplate.setTimeToLive(60000L); // 만료설정
		}
		String tmpCtt = tlgCtt;
		jmsTemplate.send(destinationName, session -> {
			TextMessage textMessage = session.createTextMessage(tmpCtt);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 동기응답처리 ///////////////////////////////////////////////////////
			if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
				textMessage.setJMSCorrelationID(frwMsgL.getCrltnId());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 호스트헤더처리 /////////////////////////////////////////////////////
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (vo instanceof GchHofComHdr gchHofComHdr) {
					byte[] testArray = IOUtils.byteArray(24);
					byte[] tempArray = StringUtils.getBytes(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(gchHofComHdr.getMsgNo()), 8), 8, '0'), Charsets.toCharset("EUC-KR"));
					System.arraycopy(tempArray, 0, testArray, 0, tempArray.length);
					textMessage.setObjectProperty(WMQConstants.JMS_IBM_MQMD_MSGID, testArray);
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (StringUtils.equals(frwMsgL.getTlgKndDvsnCd(), "0210")) {
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_REPORT);
					if (StringUtils.startsWithAny(String.valueOf(frwDestination), "GCH", "KIB")) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_REPLY);
					}
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_NAN);
					if (StringUtils.containsOnly(frwMsgL.getRespCd(), '0')) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_PAN);
					}
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_NONE);
				} else {
					textMessage.setStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ, systemProperties.getRcvQueNm(frwDestination));
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_DATAGRAM);
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_NONE);
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_NONE);
					if (StringUtils.startsWithAny(String.valueOf(frwDestination), "GCH", "KIB")) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_COA_WITH_FULL_DATA + CMQC.MQRO_COD_WITH_FULL_DATA);
					}
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 전문헤더처리 ///////////////////////////////////////////////////////
//			textMessage.setStringProperty("USRX_ORGN_TRACT_ID", frwMsgL.getOrgnTractId());
			textMessage.setStringProperty("USRX_FRST_TRACT_ID", frwMsgL.getFrstTractId());
			textMessage.setStringProperty("USRX_USR_ID", frwMsgL.getUsrId());
			for (Entry<String, String> entry : tlgHdr.entrySet()) {
				textMessage.setStringProperty(StringUtils.join("USRX_", entry.getKey()), entry.getValue());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 시뮬레이터처리 /////////////////////////////////////////////////////
			if (StringUtils.startsWithAny(StringUtils.left(StringUtils.upperCase(systemProperties.getEnvCd()), 1), "D", "T", "U")) { // 개발 | 테스트
				if (StringUtils.startsWith(String.valueOf(frwDestination), "KFT")) { // 금결원
					if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
					} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
						StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
						if (StringUtils.equals(frwMsgL.getUsrId(), "SIMSYS")) {
							textMessage.setStringProperty("USRX_SIM_YN", "Y");
						}
					} else { // 요구
						if (StringUtils.equals(frwCfg.get(StringUtils.replace(StringUtils.join("SIM_KFTC_",
							StringUtils.right(String.valueOf(frwDestination), 3),
						"_YN"), "_LCR_", "_HOF_")), "Y")) {
							textMessage.setStringProperty("USRX_SIM_YN", "Y");
						}
					}
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			log.debug("{}", textMessage);
			return textMessage;
		});
		return frwMsgL.getTractId();
	}

	/**
	 * 
	 */
	private String sendLocal(FrwDestination frwDestination, Vo vo, String tlgCtt, Map<String, String> tlgHdr) {
		log.debug("{}", vo);
		log.info(">{}]", tlgCtt);
		FrwMsgL frwMsgL = new FrwMsgL();
		frwMsgL.setLogDttm(LocalDateTime.now());
		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
//		frwMsgL.setSvcGuid(frwContext.getSvcGuid());
		frwMsgL.setInstnId(frwContext.getInstnId());
		frwMsgL.setAppNm(frwContext.getAppNm());
		frwMsgL.setHostCd(StringUtils.left(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3));
		frwMsgL.setBizDvsnCd(StringUtils.substring(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3, 6));
		frwMsgL.setTlgKndDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 6, 10)); // 전문종별구분코드
		frwMsgL.setTlgBizDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 10)); // 업무구분코드
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeEntComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(cqeEntComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeIftComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeRprComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeRprComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(gchHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(gchHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(gchHofComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(gchHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(gchHofComHdr.getRequestBank());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntComHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftEntComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntMngHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftEntMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntMngHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofLcrHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofLcrHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftComHdr.getRequestMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(kftIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(kftIftComHdr.getRequestMessageNumber());
			frwMsgL.setKftcMsgNo(kftIftComHdr.getKftcMessageNumber());
			frwMsgL.setInitInstCd(kftIftComHdr.getBeneficiaryBankCode());
			frwMsgL.setInitMsgNo(kftIftComHdr.getBeneficiaryMessageNumber());
		} else if (vo instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftRprComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftRprMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbCmsComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbCmsComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbCmsComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(frwMsgL.getLogDttm());
			frwMsgL.setRespCd("");
			frwMsgL.setHostMsgNo(lvbCmsSumHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbIftComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbRprComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbRprComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		}
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
			frwMsgL.setTractSortCd("22"); // 타발요구송신
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 내부요구송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("10"); // 내부요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			frwMsgL.setTractSortCd("24"); // 타발응답송신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("14"); // 당발응답송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 당발응답송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("14"); // 당발응답송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else { // 요구
			frwMsgL.setTractSortCd("12"); // 당발요구송신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("22"); // 타발요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 내부요구송신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				frwMsgL.setTractSortCd("10"); // 내부요구송신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		}
		String tractSortCd = frwMsgL.getTractSortCd();
		if (StringUtils.endsWith(tractSortCd, "4")) {
			tractSortCd = StringUtils.join(StringUtils.left(tractSortCd, 1), "1");
		}
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeEntComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(StringUtils.containsOnly(gchHofComHdr.getMsgNo(), '0') ?
					gchHofComHdr.getTransactionIdNumber() :
					gchHofComHdr.getMsgNo()
				), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntMngHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofLcrHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftIftComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBankCode()), 3, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBranchCode()), 4, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestMessageNumber()), 6, '0'),
				StringUtils.substring(tlgCtt, 23, 36),
			tractSortCd));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 수취조회보정 ///////////////////////////////////////////////////////
			if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "02") &&
				StringUtils.startsWith(frwMsgL.getTlgBizDvsnCd(), "500")) {
				frwMsgL.setTractId(StringUtils.join(StringUtils.left(frwMsgL.getTractId(), 25),
				StringUtils.substring(tlgCtt, 94, 107), // 수취조회번호
				StringUtils.right(frwMsgL.getTractId(), 2)));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (vo instanceof KftIftMngHdr) { // 관리전문
			frwMsgL.setTractId(frwTractId.newTractId(
				frwMsgL.getLogDttm(),
				frwMsgL.getAppNm(),
				frwMsgL.getHostCd(),
				frwMsgL.getBizDvsnCd(),
				frwMsgL.getTlgKndDvsnCd(),
				frwMsgL.getTlgBizDvsnCd(),
			tractSortCd));
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"EB99",
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgKndDvsnCd()), 4, '0'),
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsSumHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbHofComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		}
		frwMsgL.setOrgnTractId(StringUtils.defaultIfEmpty(frwContext.getOrgnTractId(), frwMsgL.getTractId()));
		frwMsgL.setFrstTractId(StringUtils.defaultIfEmpty(frwContext.getFrstTractId(), frwMsgL.getTractId()));
		frwMsgL.setUsrId(frwContext.getUsrId());
//		frwMsgL.setCrltnId();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 동기응답처리 ///////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
		} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			frwMsgL.setCrltnId(frwContext.getCrltnId());
		} else { // 요구
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
		if (StringUtils.isEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
			if (StringUtils.isAlpha(frwMsgL.getTlgLaytId())) {
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 일자강제보정 ///////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwContext.getEnvCd(), "D", "T", "U")) { // 개발 | 테스트
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
				if (StringUtils.equals(frwContext.getTlgHdr().get("FRCV_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwContext.getTlgHdr().get("FSND_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwContext.getTlgHdr().get("ORGN_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwContext.getTlgHdr().get("RQST_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwContext.getTlgHdr().get("TEMP_DT_USE_YN"), "Y") ||
					StringUtils.equals(frwContext.getTlgHdr().get("TEST_DT_USE_YN"), "Y")) {
					for (FrwDtMgmtM frwDtMgmtM : frwMapper.selectFrwDtMgmtM(StringUtils.join(
						frwMsgL.getHostCd(),
						frwMsgL.getBizDvsnCd(),
						frwMsgL.getTlgKndDvsnCd(),
						frwMsgL.getTlgBizDvsnCd()
					))) {
						String dtDvsnCd = frwDtMgmtM.getDtDvsnCd();
						if (StringUtils.equals(dtDvsnCd, "FRCV") && StringUtils.equals(frwContext.getTlgHdr().get("FRCV_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "FSND") && StringUtils.equals(frwContext.getTlgHdr().get("FSND_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "ORGN") && StringUtils.equals(frwContext.getTlgHdr().get("ORGN_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "RQST") && StringUtils.equals(frwContext.getTlgHdr().get("RQST_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "TEMP") && StringUtils.equals(frwContext.getTlgHdr().get("TEMP_DT_USE_YN"), "Y") ||
							StringUtils.equals(dtDvsnCd, "TEST") && StringUtils.equals(frwContext.getTlgHdr().get("TEST_DT_USE_YN"), "Y")) {
							String dtPrcs = frwContext.getTlgHdr().get(frwDtMgmtM.getDtPrcsCd());
							int fldLen  = frwDtMgmtM.getFldLen ().intValue();
							int fldPstn = frwDtMgmtM.getFldPstn().intValue();
							if ( 6 == fldLen ||
								12 == fldLen) {
								dtPrcs = StringUtils.right(dtPrcs, 6);
							}
							if (StringUtils.equalsAny(dtDvsnCd, "FRCV", "FSND")) {
								dtPrcs = StringUtils.right(dtPrcs, 4);
								fldPstn += fldLen - 4;
							}
							byte[] byteArray = StringUtils.getBytes(tlgCtt, Charsets.toCharset("EUC-KR"));
							byte[] tempArray = StringUtils.getBytes(dtPrcs, Charsets.toCharset("EUC-KR"));
							System.arraycopy(tempArray, 0, byteArray, fldPstn, tempArray.length);
							tlgCtt = StringUtils.toEncodedString(byteArray, Charsets.toCharset("EUC-KR"));
						}
					}
					log.debug("[{}]", tlgCtt);
				}
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwMsgL.setTlgCtt(tlgCtt);
//		frwMsgL.setStckTrc();
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		frwMsgL.setLastChngGuid(frwContext.getSvcGuid());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setFrstChngGuid(frwMsgL.getLastChngGuid());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		log.debug("{}", frwMsgL);
		frwMsgLMapper.insert(frwMsgL);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 개발우회 ///////////////////////////////////////////////////////////////
		if (null == jmsTemplate) {
			return frwMsgL.getTractId();
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		String destinationName = systemProperties.getSndQueNm(frwDestination);
		destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 호스트큐속성설정 ///////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
			destinationName = systemProperties.getSndQueNm(frwDestination);
			destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
				WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			if (FrwDestination.LVB_CMS.equals(frwDestination) ||
				FrwDestination.LVB_HOF.equals(frwDestination) ||
				FrwDestination.LVB_RPR.equals(frwDestination)) {
				destinationName = systemProperties.getSndQueNm(frwDestination);
				if (FrwDestination.LVB_HOF.equals(frwDestination) &&
					StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
					destinationName = systemProperties.getLvb().getHof().getAck();
				}
				destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
					WMQConstants.WMQ_CCSID, "=970&",
					WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			}
			if (FrwDestination.GCH_HOF.equals(frwDestination)) {
				destinationName = systemProperties.getSndQueNm(frwDestination);
				destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName, "?",
					WMQConstants.WMQ_MQMD_WRITE_ENABLED, "=true&",
					WMQConstants.WMQ_TARGET_CLIENT, "=", String.valueOf(WMQConstants.WMQ_TARGET_DEST_MQ));
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 동기응답처리 ///////////////////////////////////////////////////////////
		if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
			destinationName = systemProperties.getKcg().getFrw().getCmn();
			destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 시뮬레이터처리 /////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwContext.getEnvCd(), "D", "T", "U")) { // 개발 | 테스트
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
				if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
					if (StringUtils.equals(frwContext.getTlgHdr().get(StringUtils.join("SIM_HOST_",
						StringUtils.right(String.valueOf(frwDestination), 3),
					"_YN")), "Y")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
				} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
					StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
					if (StringUtils.equals(frwContext.getUsrId(), "SIMSYS")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////// 성능테스트처리 /////////////////////////////////////////////
					if (StringUtils.equals(frwContext.getUsrId(), "JMETER")) {
						destinationName = systemProperties.getKcg().getFrw().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				} else { // 요구
					if (StringUtils.equals(frwContext.getTlgHdr().get(StringUtils.join("SIM_HOST_",
						StringUtils.right(String.valueOf(frwDestination), 3),
					"_YN")), "Y")) {
						destinationName = systemProperties.getKcg().getSim().getCmn();
						destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
					}
				}
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		log.debug("{}", destinationName);
		jmsTemplate.setExplicitQosEnabled(true);
		String string = tlgHdr.get(WMQConstants.JMS_PRIORITY);
		if (StringUtils.isNotEmpty(string)) {
			jmsTemplate.setPriority(NumberUtils.toInt(string));
		}
		if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
			jmsTemplate.setTimeToLive(60000L); // 만료설정
		}
		String tmpCtt = tlgCtt;
		jmsTemplate.send(destinationName, session -> {
			TextMessage textMessage = session.createTextMessage(tmpCtt);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 동기응답처리 ///////////////////////////////////////////////////////
			if (StringUtils.isNotEmpty(frwMsgL.getCrltnId())) {
				textMessage.setJMSCorrelationID(frwMsgL.getCrltnId());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 호스트헤더처리 /////////////////////////////////////////////////////
			if (StringUtils.startsWithAny(String.valueOf(frwDestination), "CQE", "GCH", "KIB", "LVB")) { // 호스트
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (vo instanceof GchHofComHdr gchHofComHdr) {
					byte[] testArray = IOUtils.byteArray(24);
					byte[] tempArray = StringUtils.getBytes(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(gchHofComHdr.getMsgNo()), 8), 8, '0'), Charsets.toCharset("EUC-KR"));
					System.arraycopy(tempArray, 0, testArray, 0, tempArray.length);
					textMessage.setObjectProperty(WMQConstants.JMS_IBM_MQMD_MSGID, testArray);
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				if (StringUtils.equals(frwMsgL.getTlgKndDvsnCd(), "0210")) {
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_REPORT);
					if (StringUtils.startsWithAny(String.valueOf(frwDestination), "GCH", "KIB")) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_REPLY);
					}
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_NAN);
					if (StringUtils.containsOnly(frwMsgL.getRespCd(), '0')) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_PAN);
					}
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_NONE);
				} else {
					textMessage.setStringProperty(WMQConstants.JMS_IBM_MQMD_REPLYTOQ, systemProperties.getRcvQueNm(frwDestination));
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_MSGTYPE, CMQC.MQMT_DATAGRAM);
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_FEEDBACK, CMQC.MQFB_NONE);
					textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_NONE);
					if (StringUtils.startsWithAny(String.valueOf(frwDestination), "GCH", "KIB")) {
						textMessage.setIntProperty(WMQConstants.JMS_IBM_MQMD_REPORT, CMQC.MQRO_COA_WITH_FULL_DATA + CMQC.MQRO_COD_WITH_FULL_DATA);
					}
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 전문헤더처리 ///////////////////////////////////////////////////////
//			textMessage.setStringProperty("USRX_ORGN_TRACT_ID", frwContext.getTractId());
			textMessage.setStringProperty("USRX_FRST_TRACT_ID", frwContext.getFrstTractId());
			textMessage.setStringProperty("USRX_USR_ID", frwContext.getUsrId());
			for (Entry<String, String> entry : tlgHdr.entrySet()) {
				textMessage.setStringProperty(StringUtils.join("USRX_", entry.getKey()), entry.getValue());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 시뮬레이터처리 /////////////////////////////////////////////////////
			if (StringUtils.startsWithAny(frwContext.getEnvCd(), "D", "T", "U")) { // 개발 | 테스트
				if (StringUtils.startsWith(String.valueOf(frwDestination), "KFT")) { // 금결원
					if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
					} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
						StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
						if (StringUtils.equals(frwContext.getUsrId(), "SIMSYS")) {
							textMessage.setStringProperty("USRX_SIM_YN", "Y");
						}
					} else { // 요구
						if (StringUtils.equals(frwContext.getTlgHdr().get(StringUtils.replace(StringUtils.join("SIM_KFTC_",
							StringUtils.right(String.valueOf(frwDestination), 3),
						"_YN"), "_LCR_", "_HOF_")), "Y")) {
							textMessage.setStringProperty("USRX_SIM_YN", "Y");
						}
					}
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			log.debug("{}", textMessage);
			return textMessage;
		});
		return frwMsgL.getTractId();
	}

	/**
	 * 
	 */
	private <VO extends Vo> VO sendAndReceiveLocal(FrwDestination frwDestination, Vo vo, String tlgCtt, Map<String, String> tlgHdr, Class<VO> voClass, Duration receiveTimeout) {
		log.debug("{}", vo);
		log.info(">{}]", tlgCtt);
		FrwMsgL frwMsgL = new FrwMsgL();
		frwMsgL.setLogDttm(LocalDateTime.now());
		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
//		frwMsgL.setSvcGuid(frwContext.getSvcGuid());
		frwMsgL.setInstnId(frwContext.getInstnId());
		frwMsgL.setAppNm(frwContext.getAppNm());
		frwMsgL.setHostCd(StringUtils.left(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3));
		frwMsgL.setBizDvsnCd(StringUtils.substring(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3, 6));
		frwMsgL.setTlgKndDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 6, 10)); // 전문종별구분코드
		frwMsgL.setTlgBizDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 10)); // 업무구분코드
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeEntComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(cqeEntComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeIftComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeRprComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(cqeRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeRprComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(gchHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(gchHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(gchHofComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(gchHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(gchHofComHdr.getRequestBank());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntComHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftEntComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntMngHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftEntMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntMngHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofLcrHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftHofLcrHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftComHdr.getRequestMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(kftIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(kftIftComHdr.getRequestMessageNumber());
			frwMsgL.setKftcMsgNo(kftIftComHdr.getKftcMessageNumber());
			frwMsgL.setInitInstCd(kftIftComHdr.getBeneficiaryBankCode());
			frwMsgL.setInitMsgNo(kftIftComHdr.getBeneficiaryMessageNumber());
		} else if (vo instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftRprComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprMngHdr.getResponseCode());
			frwMsgL.setHostMsgNo(frwContext.getHostMsgNo());
			frwMsgL.setMsgTrckNo(kftRprMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbCmsComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbCmsComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbCmsComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(frwMsgL.getLogDttm());
			frwMsgL.setRespCd("");
			frwMsgL.setHostMsgNo(lvbCmsSumHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(frwContext.getTrnsUnqNo());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbIftComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(frwContext.getHndlInstCd());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbRprComHdr.getMsgNo());
			frwMsgL.setMsgTrckNo(frwContext.getMsgTrckNo());
			frwMsgL.setTrnsUnqNo(lvbRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbRprComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(frwContext.getHndlMsgNo());
			frwMsgL.setKftcMsgNo(frwContext.getKftcMsgNo());
			frwMsgL.setInitInstCd(frwContext.getInitInstCd());
			frwMsgL.setInitMsgNo(frwContext.getInitMsgNo());
		}
		frwMsgL.setTractSortCd("12"); // 당발요구송신
		if (vo instanceof CqeEntComHdr ||
			vo instanceof CqeIftComHdr ||
			vo instanceof CqeRprComHdr ||
			vo instanceof GchHofComHdr ||
			vo instanceof LvbCmsComHdr ||
			vo instanceof LvbCmsSumHdr ||
			vo instanceof LvbHofComHdr ||
			vo instanceof LvbIftComHdr ||
			vo instanceof LvbRprComHdr) {
			frwMsgL.setTractSortCd("22"); // 타발요구송신
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 내부요구송신보정 ///////////////////////////////////////////////////////
		if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
			frwMsgL.setTractSortCd("10"); // 내부요구송신
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		String tractSortCd = frwMsgL.getTractSortCd();
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeEntComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(StringUtils.containsOnly(gchHofComHdr.getMsgNo(), '0') ?
					gchHofComHdr.getTransactionIdNumber() :
					gchHofComHdr.getMsgNo()
				), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntMngHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofLcrHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftIftComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBankCode()), 3, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBranchCode()), 4, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestMessageNumber()), 6, '0'),
				StringUtils.substring(tlgCtt, 23, 36),
			tractSortCd));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 수취조회보정 ///////////////////////////////////////////////////////
			if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "02") &&
				StringUtils.startsWith(frwMsgL.getTlgBizDvsnCd(), "500")) {
				frwMsgL.setTractId(StringUtils.join(StringUtils.left(frwMsgL.getTractId(), 25),
				StringUtils.substring(tlgCtt, 94, 107), // 수취조회번호
				StringUtils.right(frwMsgL.getTractId(), 2)));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (vo instanceof KftIftMngHdr) { // 관리전문
			frwMsgL.setTractId(frwTractId.newTractId(
				frwMsgL.getLogDttm(),
				frwMsgL.getAppNm(),
				frwMsgL.getHostCd(),
				frwMsgL.getBizDvsnCd(),
				frwMsgL.getTlgKndDvsnCd(),
				frwMsgL.getTlgBizDvsnCd(),
			tractSortCd));
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"EB99",
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgKndDvsnCd()), 4, '0'),
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsSumHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbHofComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		}
		frwMsgL.setOrgnTractId(StringUtils.defaultIfEmpty(frwContext.getOrgnTractId(), frwMsgL.getTractId()));
		frwMsgL.setFrstTractId(StringUtils.defaultIfEmpty(frwContext.getFrstTractId(), frwMsgL.getTractId()));
		frwMsgL.setUsrId(frwContext.getUsrId());
		frwMsgL.setCrltnId(String.valueOf(UUID.randomUUID()));
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
		if (StringUtils.isEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
			if (StringUtils.isAlpha(frwMsgL.getTlgLaytId())) {
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
			}
		}
		frwMsgL.setTlgCtt(tlgCtt);
//		frwMsgL.setStckTrc();
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		frwMsgL.setLastChngGuid(frwContext.getSvcGuid());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setFrstChngGuid(frwMsgL.getLastChngGuid());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		log.debug("{}", frwMsgL);
		return frwExecutor.requiresNew(() -> {
			frwMsgLMapper.insert(frwMsgL);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 개발우회 ///////////////////////////////////////////////////////////
			if (null == jmsTemplate) {
				return null;
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			String destinationName = systemProperties.getSndQueNm(frwDestination);
			destinationName = StringUtils.join(WMQConstants.QUEUE_PREFIX, "/", destinationName);
			log.debug("{}", destinationName);
			jmsTemplate.setExplicitQosEnabled(true);
			jmsTemplate.setPriority(9);
			jmsTemplate.setTimeToLive(60000L); // 만료설정
			if (null != receiveTimeout) {
				jmsTemplate.setReceiveTimeout(receiveTimeout.toMillis());
			}
			Message message = jmsTemplate.sendAndReceive(destinationName, session -> {
				TextMessage textMessage = session.createTextMessage(tlgCtt);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////// 동기응답처리 ///////////////////////////////////////////////////
				textMessage.setJMSCorrelationID(frwMsgL.getCrltnId());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////// 전문헤더처리 ///////////////////////////////////////////////////
//				textMessage.setStringProperty("USRX_ORGN_TRACT_ID", frwContext.getTractId());
				textMessage.setStringProperty("USRX_FRST_TRACT_ID", frwContext.getFrstTractId());
				textMessage.setStringProperty("USRX_USR_ID", frwContext.getUsrId());
				for (Entry<String, String> entry : tlgHdr.entrySet()) {
					textMessage.setStringProperty(StringUtils.join("USRX_", entry.getKey()), entry.getValue());
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////// 시뮬레이터처리 /////////////////////////////////////////////////
				if (StringUtils.startsWithAny(frwContext.getEnvCd(), "D", "T", "U")) { // 개발 | 테스트
					if (StringUtils.startsWith(String.valueOf(frwDestination), "KFT")) { // 금결원
						if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC")) {
						} else if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "9") ||
							StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
							if (StringUtils.equals(frwContext.getUsrId(), "SIMSYS")) {
								textMessage.setStringProperty("USRX_SIM_YN", "Y");
							}
						} else { // 요구
							if (StringUtils.equals(frwContext.getTlgHdr().get(StringUtils.replace(StringUtils.join("SIM_KFTC_",
								StringUtils.right(String.valueOf(frwDestination), 3),
							"_YN"), "_LCR_", "_HOF_")), "Y")) {
								textMessage.setStringProperty("USRX_SIM_YN", "Y");
							}
						}
					}
				}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
				log.debug("{}", textMessage);
				return textMessage;
			});
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 타임아웃 ///////////////////////////////////////////////////////////
			if (null == message) {
				return null;
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			TextMessage textMessage = (TextMessage) message;
			log.debug("{}", textMessage);
			String tmpCtt = textMessage.getText();
			log.info("<{}]", MethodUtils.invokeExactMethod(StringUtils.defaultString(tmpCtt), "toString"));
			VO to = VOUtils.toVo(tmpCtt, voClass);
			log.debug("{}", to);
			FrwMsgL tmpMsgL = new FrwMsgL();
			tmpMsgL.setLogDttm(LocalDateTime.now());
			tmpMsgL.setLogDt(tmpMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
//			tmpMsgL.setSvcGuid(frwMsgL.getSvcGuid());
			tmpMsgL.setInstnId(frwMsgL.getInstnId());
			tmpMsgL.setAppNm(frwMsgL.getAppNm());
			tmpMsgL.setHostCd(StringUtils.left(StringUtils.upperCase(ClassUtils.getSimpleName(voClass)), 3));
			tmpMsgL.setBizDvsnCd(StringUtils.substring(StringUtils.upperCase(ClassUtils.getSimpleName(voClass)), 3, 6));
			tmpMsgL.setTlgKndDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(voClass), 6, 10)); // 전문종별구분코드
			tmpMsgL.setTlgBizDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(voClass), 10)); // 업무구분코드
			if (to instanceof CqeEntComHdr cqeEntComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeEntComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(cqeEntComHdr.getResponseCode1());
				tmpMsgL.setHostMsgNo(cqeEntComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(cqeEntComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof CqeIftComHdr cqeIftComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeIftComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(cqeIftComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(cqeIftComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(cqeIftComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(cqeIftComHdr.getRequestBankCode());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof CqeRprComHdr cqeRprComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeRprComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(cqeRprComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(cqeRprComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(cqeRprComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(cqeRprComHdr.getRequestBankCode());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof GchHofComHdr gchHofComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(gchHofComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(gchHofComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(gchHofComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(gchHofComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(gchHofComHdr.getRequestBank());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntComHdr.getMessageSendTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(kftEntComHdr.getResponseCode1());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftEntComHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(kftEntComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntMngHdr.getMessageSendTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(kftEntMngHdr.getResponseCode1());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftEntMngHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(kftEntMngHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				if (ObjectUtils.allNotNull(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime())) {
					tmpMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime()));
				}
				tmpMsgL.setRespCd(kftHofComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftHofComHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(kftHofComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				if (ObjectUtils.allNotNull(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime())) {
					tmpMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime()));
				}
				tmpMsgL.setRespCd(kftHofMngHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftHofMngHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				if (ObjectUtils.allNotNull(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime())) {
					tmpMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime()));
				}
				tmpMsgL.setRespCd(kftHofLcrHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftHofLcrHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftComHdr.getRequestMessageSendTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(kftIftComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(kftIftComHdr.getRequestBankCode());
				tmpMsgL.setHndlMsgNo(kftIftComHdr.getRequestMessageNumber());
				tmpMsgL.setKftcMsgNo(kftIftComHdr.getKftcMessageNumber());
				tmpMsgL.setInitInstCd(kftIftComHdr.getBeneficiaryBankCode());
				tmpMsgL.setInitMsgNo(kftIftComHdr.getBeneficiaryMessageNumber());
			} else if (to instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftMngHdr.getMessageSendTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(kftIftMngHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				if (ObjectUtils.allNotNull(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime())) {
					tmpMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime()));
				}
				tmpMsgL.setRespCd(kftRprComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftRprComHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(kftRprComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				if (ObjectUtils.allNotNull(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime())) {
					tmpMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime()));
				}
				tmpMsgL.setRespCd(kftRprMngHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(frwMsgL.getHostMsgNo());
				tmpMsgL.setMsgTrckNo(kftRprMngHdr.getMessageTrackingNumber());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof LvbCmsComHdr lvbCmsComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(""); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbCmsComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(lvbCmsComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(lvbCmsComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof LvbCmsSumHdr lvbCmsSumHdr) {
				tmpMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(""); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(tmpMsgL.getLogDttm());
				tmpMsgL.setRespCd("");
				tmpMsgL.setHostMsgNo(lvbCmsSumHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof LvbHofComHdr lvbHofComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbHofComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(lvbHofComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof LvbIftComHdr lvbIftComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbIftComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(lvbIftComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(lvbIftComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(lvbIftComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(frwMsgL.getHndlInstCd());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			} else if (to instanceof LvbRprComHdr lvbRprComHdr) {
				tmpMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), tmpMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
				tmpMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), tmpMsgL.getTlgBizDvsnCd())); // 업무구분코드
				tmpMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbRprComHdr.getSystemSendReceiveTime(), tmpMsgL.getLogDttm()));
				tmpMsgL.setRespCd(lvbRprComHdr.getResponseCode());
				tmpMsgL.setHostMsgNo(lvbRprComHdr.getMsgNo());
				tmpMsgL.setMsgTrckNo(frwMsgL.getMsgTrckNo());
				tmpMsgL.setTrnsUnqNo(lvbRprComHdr.getTransactionIdNumber());
				tmpMsgL.setHndlInstCd(lvbRprComHdr.getRequestBankCode());
				tmpMsgL.setHndlMsgNo(frwMsgL.getHndlMsgNo());
				tmpMsgL.setKftcMsgNo(frwMsgL.getKftcMsgNo());
				tmpMsgL.setInitInstCd(frwMsgL.getInitInstCd());
				tmpMsgL.setInitMsgNo(frwMsgL.getInitMsgNo());
			}
			tmpMsgL.setTractSortCd("13"); // 당발응답수신
			if (to instanceof CqeEntComHdr ||
				to instanceof CqeIftComHdr ||
				to instanceof CqeRprComHdr ||
				to instanceof GchHofComHdr ||
				to instanceof LvbCmsComHdr ||
				to instanceof LvbCmsSumHdr ||
				to instanceof LvbHofComHdr ||
				to instanceof LvbIftComHdr ||
				to instanceof LvbRprComHdr) {
				tmpMsgL.setTractSortCd("23"); // 타발응답수신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 내부응답수신보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(String.valueOf(frwDestination), "KCG")) { // 내부
				tmpMsgL.setTractSortCd("15"); // 내부응답수신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			tmpMsgL.setTractId(frwMsgL.getTractId());
			tmpMsgL.setOrgnTractId(frwMsgL.getOrgnTractId());
			tmpMsgL.setFrstTractId(frwMsgL.getFrstTractId());
			tmpMsgL.setUsrId(frwMsgL.getUsrId());
			tmpMsgL.setCrltnId(frwMsgL.getCrltnId());
			tmpMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(voClass)));
			tmpMsgL.setTlgCtt(tmpCtt);
//			tmpMsgL.setStckTrc();
//			tmpMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
			tmpMsgL.setLastChngGuid(frwMsgL.getLastChngGuid());
			tmpMsgL.setLastChngTmstmp(tmpMsgL.getLogDttm());
			tmpMsgL.setLastChngStaffId(tmpMsgL.getUsrId());
			tmpMsgL.setFrstChngGuid(frwMsgL.getFrstChngGuid());
			tmpMsgL.setFrstChngTmstmp(tmpMsgL.getLogDttm());
			tmpMsgL.setFrstChngStaffId(tmpMsgL.getUsrId());
			log.debug("{}", tmpMsgL);
			frwMsgLMapper.insert(tmpMsgL);
			return to;
		});
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, Vo vo, Map<String, String> tlgHdr, FrwMsgL frwMsgL) {
		tlgHdr = new TreeMap<>(tlgHdr);
		tlgHdr.put("TLG_LAYT_ID", StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
		return sendLocal(frwDestination, vo, VOUtils.toString(vo), tlgHdr, frwMsgL);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, Vo vo, FrwMsgL frwMsgL) {
		return send(frwDestination, vo, Map.of(), frwMsgL);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, String tlgCtt, Map<String, String> tlgHdr, FrwMsgL frwMsgL) {
		return sendLocal(frwDestination, VOUtils.toVo(tlgCtt, findClass(frwDestination, tlgCtt)), tlgCtt, tlgHdr, frwMsgL);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, String tlgCtt, FrwMsgL frwMsgL) {
		return send(frwDestination, tlgCtt, Map.of(), frwMsgL);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, Vo vo, Map<String, String> tlgHdr) {
		tlgHdr = new TreeMap<>(tlgHdr);
		tlgHdr.put("TLG_LAYT_ID", StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
		return sendLocal(frwDestination, vo, VOUtils.toString(vo), tlgHdr);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, Vo vo) {
		return send(frwDestination, vo, Map.of());
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, String tlgCtt, Map<String, String> tlgHdr) {
		return sendLocal(frwDestination, VOUtils.toVo(tlgCtt, findClass(frwDestination, tlgCtt)), tlgCtt, tlgHdr);
	}

	/**
	 * 
	 */
	public String send(FrwDestination frwDestination, String tlgCtt) {
		return send(frwDestination, tlgCtt, Map.of());
	}

	/**
	 * 
	 */
	public <VO extends Vo> VO sendAndReceive(FrwDestination frwDestination, Vo vo, Map<String, String> tlgHdr, Class<VO> voClass, Duration receiveTimeout) {
		tlgHdr = new TreeMap<>(tlgHdr);
		tlgHdr.put("TLG_LAYT_ID", StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
		return sendAndReceiveLocal(frwDestination, vo, VOUtils.toString(vo), tlgHdr, voClass, receiveTimeout);
	}

	/**
	 * 
	 */
	public <VO extends Vo> VO sendAndReceive(FrwDestination frwDestination, Vo vo, Map<String, String> tlgHdr, Class<VO> voClass) {
		return sendAndReceive(frwDestination, vo, tlgHdr, voClass, null);
	}

	/**
	 * 
	 */
	public <VO extends Vo> VO sendAndReceive(FrwDestination frwDestination, Vo vo, Class<VO> voClass, Duration receiveTimeout) {
		return sendAndReceive(frwDestination, vo, Map.of(), voClass, receiveTimeout);
	}

	/**
	 * 
	 */
	public <VO extends Vo> VO sendAndReceive(FrwDestination frwDestination, Vo vo, Class<VO> voClass) {
		return sendAndReceive(frwDestination, vo, Map.of(), voClass, null);
	}

}
