package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 순이체한도통지
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+HDR
 * systemId 시스템-ID 고유 System ID (ELB)
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별코드 전문종별코드
 * messageCode 거래구분코드 거래구분코드
 * sendReceiveFlag 송수신FLAG 1:요구,2:지시,3:보고,4:통보,5:통보(지연/재요구응답)
 * status STATUS 오류전문 발생항목의 Bit Map번호
 * responseCode 응답코드 응답코드
 * messageTransmissionDate 전문전송일 YYYYMMDD
 * messageSendTime 전문전송시간 hhmmss
 * messageTrackingNumber 전문추적번호 전문추적번호
 * informationCount 한도정보갯수 
 * netDebitCapInformationArray 순채무한도정보Array 
 * netDebitCapInformationArray.limtInformationInstitutionCode 한도정보기관코드 
 * netDebitCapInformationArray.centerLimitAmount 센터한도금액 
 * netDebitCapInformationArray.netDebitCapRemainedAmount 채무한도잔여금액 
 * netDebitCapInformationArray.netDebitCapLimtspentRate 채무한도소진율 
 * netDebitCapInformationArray.maxNetDebitCapAmount 최대채무금액 
 * netDebitCapInformationArray.maxNetDebitCapOccurredDateTime 최대채무발생시각 
 * filler 예비정보 
 * 
 * KftHof0200020000 kftHof0200020000 = new KftHof0200020000(); // 순이체한도통지
 * kftHof0200020000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0200020000.setSystemId("LCS"); // 시스템-ID
 * kftHof0200020000.setInstitutionCode("057"); // 기관코드
 * kftHof0200020000.setMessageType("0200"); // 전문종별코드
 * kftHof0200020000.setMessageCode("020000"); // 거래구분코드
 * kftHof0200020000.setSendReceiveFlag("C"); // 송수신FLAG
 * kftHof0200020000.setStatus("000"); // STATUS
 * kftHof0200020000.setResponseCode(""); // 응답코드
 * kftHof0200020000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0200020000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0200020000.setMessageTrackingNumber("0000000000"); // 전문추적번호
 * kftHof0200020000.setInformationCount(0); // 한도정보갯수
 * KftHof0200020000.NetDebitCapInformation netDebitCapInformation = new KftHof0200020000.NetDebitCapInformation(); // 순채무한도정보Array
 * netDebitCapInformation.setLimtInformationInstitutionCode("000"); // 한도정보기관코드
 * netDebitCapInformation.setCenterLimitAmount(0L); // 센터한도금액
 * netDebitCapInformation.setNetDebitCapRemainedAmount(0L); // 채무한도잔여금액
 * netDebitCapInformation.setNetDebitCapLimtspentRate(BigDecimal.valueOf(0L)); // 채무한도소진율
 * netDebitCapInformation.setMaxNetDebitCapAmount(0L); // 최대채무금액
 * netDebitCapInformation.setMaxNetDebitCapOccurredDateTime("00000000000000"); // 최대채무발생시각
 * kftHof0200020000.getNetDebitCapInformationArray().add(netDebitCapInformation); // 순채무한도정보Array
 * kftHof0200020000.setFiller(""); // 예비정보
 * }</pre>
 */
@Data
public class KftHof0200020000 implements KftHofLcrHdr, Vo {

	/**
	 * 순채무한도정보Array
	 * <pre>{@code
	 * limtInformationInstitutionCode 한도정보기관코드 
	 * centerLimitAmount 센터한도금액 
	 * netDebitCapRemainedAmount 채무한도잔여금액 
	 * netDebitCapLimtspentRate 채무한도소진율 
	 * maxNetDebitCapAmount 최대채무금액 
	 * maxNetDebitCapOccurredDateTime 최대채무발생시각 
	 * 
	 * KftHof0200020000.NetDebitCapInformation netDebitCapInformation = new KftHof0200020000.NetDebitCapInformation(); // 순채무한도정보Array
	 * netDebitCapInformation.setLimtInformationInstitutionCode("000"); // 한도정보기관코드
	 * netDebitCapInformation.setCenterLimitAmount(0L); // 센터한도금액
	 * netDebitCapInformation.setNetDebitCapRemainedAmount(0L); // 채무한도잔여금액
	 * netDebitCapInformation.setNetDebitCapLimtspentRate(BigDecimal.valueOf(0L)); // 채무한도소진율
	 * netDebitCapInformation.setMaxNetDebitCapAmount(0L); // 최대채무금액
	 * netDebitCapInformation.setMaxNetDebitCapOccurredDateTime("00000000000000"); // 최대채무발생시각
	 * }</pre>
	 */
	@Data
	public static class NetDebitCapInformation implements Vo {

		private String limtInformationInstitutionCode = "000"; // 한도정보기관코드
		private long centerLimitAmount; // 센터한도금액
		private long netDebitCapRemainedAmount; // 채무한도잔여금액
		private BigDecimal netDebitCapLimtspentRate; // 채무한도소진율
		private long maxNetDebitCapAmount; // 최대채무금액
		private String maxNetDebitCapOccurredDateTime = "00000000000000"; // 최대채무발생시각
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String limtInformationInstitutionCode$; // 한도정보기관코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String centerLimitAmount$; // 센터한도금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String netDebitCapRemainedAmount$; // 채무한도잔여금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String netDebitCapLimtspentRate$; // 채무한도소진율
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String maxNetDebitCapAmount$; // 최대채무금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String maxNetDebitCapOccurredDateTime$; // 최대채무발생시각

		@Override
		public void write(OutputStream out) throws IOException {
			limtInformationInstitutionCode$ = VOUtils.write(out, limtInformationInstitutionCode, 3); // 한도정보기관코드
			centerLimitAmount$ = VOUtils.write(out, centerLimitAmount, 14); // 센터한도금액
			netDebitCapRemainedAmount$ = VOUtils.write(out, netDebitCapRemainedAmount, 14); // 채무한도잔여금액
			netDebitCapLimtspentRate$ = VOUtils.write(out, netDebitCapLimtspentRate, 5, 2); // 채무한도소진율
			maxNetDebitCapAmount$ = VOUtils.write(out, maxNetDebitCapAmount, 14); // 최대채무금액
			maxNetDebitCapOccurredDateTime$ = VOUtils.write(out, maxNetDebitCapOccurredDateTime, 14); // 최대채무발생시각
		}

		@Override
		public void read(InputStream in) throws IOException {
			limtInformationInstitutionCode = VOUtils.toString(limtInformationInstitutionCode$ = VOUtils.read(in, 3)); // 한도정보기관코드
			centerLimitAmount = VOUtils.toLong(centerLimitAmount$ = VOUtils.read(in, 14)); // 센터한도금액
			netDebitCapRemainedAmount = VOUtils.toLong(netDebitCapRemainedAmount$ = VOUtils.read(in, 14)); // 채무한도잔여금액
			netDebitCapLimtspentRate = VOUtils.createBigDecimal(netDebitCapLimtspentRate$ = VOUtils.read(in, 5), 5, 2); // 채무한도소진율
			maxNetDebitCapAmount = VOUtils.toLong(maxNetDebitCapAmount$ = VOUtils.read(in, 14)); // 최대채무금액
			maxNetDebitCapOccurredDateTime = VOUtils.toString(maxNetDebitCapOccurredDateTime$ = VOUtils.read(in, 14)); // 최대채무발생시각
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", limtInformationInstitutionCode=").append(limtInformationInstitutionCode).append(System.lineSeparator()); // 한도정보기관코드
			sb.append(", centerLimitAmount=").append(centerLimitAmount).append(System.lineSeparator()); // 센터한도금액
			sb.append(", netDebitCapRemainedAmount=").append(netDebitCapRemainedAmount).append(System.lineSeparator()); // 채무한도잔여금액
			sb.append(", netDebitCapLimtspentRate=").append(netDebitCapLimtspentRate).append(System.lineSeparator()); // 채무한도소진율
			sb.append(", maxNetDebitCapAmount=").append(maxNetDebitCapAmount).append(System.lineSeparator()); // 최대채무금액
			sb.append(", maxNetDebitCapOccurredDateTime=").append(maxNetDebitCapOccurredDateTime).append(System.lineSeparator()); // 최대채무발생시각
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "LCS"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0200"; // 전문종별코드
	private String messageCode = "020000"; // 거래구분코드
	private String sendReceiveFlag = "C"; // 송수신FLAG
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "0000000000"; // 전문추적번호
	private int informationCount; // 한도정보갯수
	private List<KftHof0200020000.NetDebitCapInformation> netDebitCapInformationArray = new ArrayList<>(); // 순채무한도정보Array
	private String filler; // 예비정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String informationCount$; // 한도정보갯수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // 예비정보

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 6;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 7;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 8;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 9;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 10;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 10); // 전문추적번호
		informationCount$ = VOUtils.write(out, informationCount, 1); // 한도정보갯수
		VOUtils.write(out, netDebitCapInformationArray, 4, KftHof0200020000.NetDebitCapInformation::new); // 순채무한도정보Array
		filler$ = VOUtils.write(out, filler, 16); // 예비정보
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 10)); // 전문추적번호
		informationCount = VOUtils.toInt(informationCount$ = VOUtils.read(in, 1)); // 한도정보갯수
		netDebitCapInformationArray = VOUtils.toVoList(in, 4, KftHof0200020000.NetDebitCapInformation.class); // 순채무한도정보Array
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 16)); // 예비정보
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", informationCount=").append(informationCount).append(System.lineSeparator()); // 한도정보갯수
		sb.append(", netDebitCapInformationArray=").append(netDebitCapInformationArray).append(System.lineSeparator()); // 순채무한도정보Array
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // 예비정보
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "LCS"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "020000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "C"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "10", "defltVal", "0000000000"),
			Map.of("fld", "informationCount", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "netDebitCapInformationArray", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "limtInformationInstitutionCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "centerLimitAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "netDebitCapRemainedAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "netDebitCapLimtspentRate", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "maxNetDebitCapAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "maxNetDebitCapOccurredDateTime", "fldLen", "14", "defltVal", "00000000000000"),
			Map.of("fld", "filler", "fldLen", "16", "defltVal", "")
		);
	}

}
