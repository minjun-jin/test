package com.jpmc.kcg.hof.biz;

import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.SvcHourStsCdEnum;
import com.jpmc.kcg.com.enums.SvcTmDvsnCdEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.hof.biz.vo.KftHof0200400000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200400000;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTransactionIn;
import com.jpmc.kcg.hof.enums.FundTypeEnum;
import com.jpmc.kcg.hof.enums.HofConst;
import com.jpmc.kcg.hof.enums.HofRespCdEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 2024.08.07 한성흔 타행이체 타발요청 (0200/400000)
 */
@Slf4j
@Component
public class HofFundsTransferInReqIntf extends FrwServiceBean<KftHof0200400000> {

	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private HofCom hofCom;
	@Autowired
	private BizCom bizCom;
	@Autowired
	private ComTrHoldLDao comTrHoldLDao;
	@Autowired
	private BizDate bizDate;
	@Autowired
	private ReleaseValidation releaseValidation;
	@Autowired
	private ConversionService conversionService;

	private boolean isHoliday = false;

	/**
	 * 전문 검증 및 제어
	 */
	@Override
	public boolean control(KftHof0200400000 in) {

		// 전문 format validation check
		if (in.validate() > 0) {
			String fieldNo = String.valueOf(in.validate());
			String errCd = StringUtils.leftPad(fieldNo, 3, ComConst.CHAR_0); // 000 ~ 필드번호가 응답코드로 리턴.

			// 거래금액 017, 매체구분 021, 자금성격 022
			throw new InternalResponseException(errCd);
		}

		// 영업시간 조회
		String hourStatus = releaseValidation.getReleaseServiceHour(SvcTmDvsnCdEnum.HOF_INBOUND_SERVICE_HOUR.getValue(),
				LocalDateTime.now());
		
		// 1. 거래고유번호로 중복거래 확인
		SelectHofTransactionIn selectIn = new SelectHofTransactionIn();
		selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02); // 타발
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());
		// 전문일자로 사용하여야 휴일거래 커버가능.
		selectIn.setTrDt(in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));

		/**
		 * HOF거래원장 조회
		 */
		HofTrL reqTrInfo = hofCom.selectHofTransaction(selectIn);

		// 1.1 신규거래일 경우
		if (reqTrInfo == null) {
			// 서비스 시간(22:00) 이후 모두 에러처리
			if (SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode().equals(hourStatus)) {
				throw new InternalResponseException(HofRespCdEnum.RESP_CD_413.getCode());
			}
		}
		/**
		 * 대기거래원장 조회 - TODO 업무구분코드 추가해야함
		 */
		ComTrHoldL holdingTr = comTrHoldLDao.selectHoldingTrByKeyValue(in.getTransactionIdNumber(), in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));
		if (holdingTr != null) return false;
		
		// 재처리 전문 아니면 hold 
//		if (!in.getMessageType().endsWith(ComConst.CHAR_1)) {	2025.04.30 재처리(0201)이 먼저 들어올 수 있으므로 
			
			boolean isBizDay = bizDate.isWeekdayBizDay(frwContext.getSysDt()); // 평일 영업일

			// 영업일이면서 거래개시시간 이전에는 대기거래 입력함.
			if (isBizDay) {
				if (SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode().equals(hourStatus)) {
					// 대기거래입력
					_createHoldTransaction(in, HoldRsnCdEnum.KCG_SERVICE_HOUR.getCode());
					return false;
				}
			} else { // 영업일이 아님.
				DayOfWeek today = frwContext.getSysTmstmp().getDayOfWeek();
				log.info("Not biz day!! now date {}", in.getMessageTransmissionDate());
				log.info("day {}", today);
				if (DayOfWeek.SATURDAY.equals(today)) { // 토요일인 경우, 영업시간 07:01~18:00
					hourStatus = releaseValidation.getReleaseServiceHour(
							SvcTmDvsnCdEnum.HOF_SAT_INBOUND_SERVICE_HOUR.getValue(), LocalDateTime.now());
					// 개시전/후 모두 대기거래입력 (사유코드 다름)
					if (SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode().equals(hourStatus)) {
						_createHoldTransaction(in, HoldRsnCdEnum.KCG_SERVICE_HOUR.getCode());
						return false;

					} else if (SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode().equals(hourStatus)) {
						_createHoldTransaction(in, HoldRsnCdEnum.HOLIDAY.getCode());
						isHoliday = true;
					}
				} else { // 일요일, 공휴일 대기거래입력
					_createHoldTransaction(in, HoldRsnCdEnum.HOLIDAY.getCode());
					isHoliday = true;
				}
			}
//		}

		return super.control(in);

	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftHof0200400000 in) {
		if (log.isDebugEnabled()) {
			log.debug("process Input Value :::: {}", in);
		}

		// 1. 거래고유번호로 중복거래 확인
		SelectHofTransactionIn selectIn = new SelectHofTransactionIn();
		selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02); // 타발
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());
		// 전문일자로 사용하여야 휴일거래 커버가능.
		selectIn.setTrDt(in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));

		HofTrL reqTrInfo = hofCom.selectHofTransaction(selectIn);

		// 1.1 조회결과가 있는 경우
		if (reqTrInfo != null) {
			// 1.1.1 중복이지만 해당전문이 재요청(message type 0201)인경우
			if (in.getMessageType().endsWith(ComConst.CHAR_1)) {
				// 1.1.1.1 요청중 && 응답코드가 없는 경우 -> 무시, 종료
				if (TrStsCdEnum.REQUEST.getTrStsCd().equals(reqTrInfo.getTrStsCd())
						&& StringUtils.isEmpty(reqTrInfo.getRespCd())) {
					return;
					// 1.1.1.2 응답코드가 있는 경우 -> 응답 셋팅하여 KFTC 전송 (FLAG 3), 종료
				} else {
					in.setMessageType(HofConst.TLG_KND_DVSN_NO_0210);
					in.setSendReceiveFlag(_getRespFlag(in.getSendReceiveFlag()));
					in.setResponseCode(StringUtils.isNotEmpty(reqTrInfo.getHostRespCd()) ? reqTrInfo.getHostRespCd()
							: reqTrInfo.getRespCd());
					frwTemplate.send(FrwDestination.KFT_HOF, in);
					return;
				}
				// 1.1.2 중복이지만 재요청이 아닌 경우 -> 종료
			} else {
				if (StringUtils.isEmpty(reqTrInfo.getHoliTrYn()) || ComConst.N.equals(reqTrInfo.getHoliTrYn())) {
					log.info("========== 중복요청이므로 무응답처리 end ==========");
					return;
				}
			}
		} else { 			// 1.2 조회결과가 없는 경우, 취소요청이 먼저 처리된 건지 / hold인 거래인지 확인.
			selectIn = new SelectHofTransactionIn();
			selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02); // 타발
			selectIn.setTlgKndDvsnCd(HofConst.TLG_KND_DVSN_NO_0400);
			selectIn.setTlgTrDvsnCd(in.getMessageCode());
			selectIn.setTrUnqNo(in.getTransactionIdNumber());

			HofTrL cancelTrInfo = hofCom.selectHofTransaction(selectIn);

			// 1.2.1 취소거래가 있는 경우 -> 무시, 종료
			if (cancelTrInfo != null) {
				return;
			}

			// 1.2.2 재처리요청의 원전문이 hold에 있는 경우 무시.
			if (in.getMessageType().endsWith(ComConst.CHAR_1)) {
				ComTrHoldL holdTr = comTrHoldLDao.selectHoldingTrByKeyValue(in.getTransactionIdNumber(),
						in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));
				if (holdTr != null) {
					return;
				}
			}
		}

		// 2. 계좌상태체크
		Map<String, String> acctInfo = bizCom.getAccountValidation(in.getBeneficiaryAccountNumber(),
				BizDvsnCdEnum.HOF.getValue(), ComConst.KFT);

		String respCd = acctInfo.get("rtnAcctStsCd");
		String rcpntNm = acctInfo.get("rtnAcctNm");

		// 2.1 압류금지계좌 체크하여 응답코드 업데이트.
		String fundTypeCd = in.getFundType();
		if (FundTypeEnum.isNonseizableHofFundTr(fundTypeCd)) {
			respCd = HofRespCdEnum.RESP_CD_439.getCode(); // 압류금지계좌 아님
		}

		// 2.2 계좌상태가 정상이 아니면 에러종료 및 결제원에 응답전송
		if (!HofRespCdEnum.RESP_CD_000.getCode().equals(respCd)) {
			throw new InternalResponseException(respCd);
		} else {
			respCd = "";
		}

		// 휴일거래 정보 입력

		// 3. 거래내역 insert
		String msgNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFLVB01);

		HofTrL insertIn = new HofTrL();
		insertIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02);
		insertIn.setTlgKndDvsnCd(isHoliday ? HofConst.TLG_KND_DVSN_NO_0210 : HofConst.TLG_KND_DVSN_NO_0200); // 재처리도 내려오기때문에 setting
		insertIn.setTlgTrDvsnCd(in.getMessageCode());
		insertIn.setTrUnqNo(in.getTransactionIdNumber()); // 13자리 거래고유번호
		insertIn.setHofTlgTrceNo(in.getMessageTrackingNumber()); // 8자리 전문추적번호
		insertIn.setRcpntNm(rcpntNm);
		insertIn.setTrStsCd(isHoliday ? TrStsCdEnum.COMPLETE.getTrStsCd() : TrStsCdEnum.REQUEST.getTrStsCd());
		insertIn.setRespCd(isHoliday ? HofRespCdEnum.RESP_CD_000.getCode() : respCd);
		insertIn.setHostNo(msgNo);
		if (StringUtils.isNotEmpty(in.getRequestBranchCode())) {
			insertIn.setHndlBnkCd(in.getRequestBranchCode().substring(0, 3));
			insertIn.setHndlBrnchCd(in.getRequestBranchCode().substring(3));
		}
		// 타발거래 holiday 관리
		insertIn.setHoliTrYn(isHoliday ? ComConst.Y : ComConst.N);
		boolean isHolidayRelease = false;

		// 휴일에서 release된 거래는 insert 다시 하지 않는다.
		String holdRsnCd = frwContext.getTlgHdr().get(ComConst.HOLD_RSN_CD);
		if (StringUtils.isNotEmpty(holdRsnCd) && holdRsnCd.equals(HoldRsnCdEnum.HOLIDAY.getCode())) { // 휴일에서 release된
																										// 거래 조건임.
			isHolidayRelease = true;
		} else {
			hofCom.insertHofTransaction(insertIn);
		}

		// 5. 전문전송
		// 5-1. 휴일이므로 KFTC에 '000' 전문 전송
		if (isHoliday) {
			in.setMessageType(HofConst.TLG_KND_DVSN_NO_0210);
			in.setSendReceiveFlag(_getRespFlag(in.getSendReceiveFlag()));
			in.setResponseCode(HofRespCdEnum.RESP_CD_000.getCode());
			frwTemplate.send(FrwDestination.KFT_HOF, in);

			// 5-2. host에 전문 전송
		} else {
			LvbHof0200400000 rqstIn = conversionService.convert(in, LvbHof0200400000.class);
			rqstIn.setSystemSendReceiveTime(LocalDateTime.now());
			rqstIn.setMsgType(HofConst.KCGLVB);
			rqstIn.setBeneficiaryName(rcpntNm);
			if (isHolidayRelease) {
				rqstIn.setTransactionDate(LocalDate.now());
				rqstIn.setMsgNo(reqTrInfo.getHostNo());
				rqstIn.setHolidayTransactionDate(
						in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));
				frwTemplate.send(FrwDestination.LVB_HOF, rqstIn);
			} else {
				log.debug("################holidayTransactionDate setting null######");
				rqstIn.setMsgNo(msgNo);
				rqstIn.setHolidayTransactionDate(null);
				frwTemplate.send(FrwDestination.LVB_HOF, rqstIn);
			}
		}
		isHoliday = false; // flag 초기화
		try {
			if (StringUtils.isNotBlank(frwContext.getTlgHdr().get(ComConst.HOLD_RSN_CD))) {
				bizCom.setComHoldStatusDone(in.getTransactionIdNumber(),
						in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter())); // hold -> release
			}
		} catch (Exception e) {
			log.info("INNER COMMIT EXCEPTION CATCH");
		}
	}

	/**
	 * 예외
	 */
	@Override
	public void handleError(KftHof0200400000 in, Throwable t) {

		String respCd;

		if (t instanceof InternalResponseException e) {
			respCd = e.getRespCd();
		} else {
			respCd = HofRespCdEnum.RESP_CD_413.getCode();
			log.info(t.getStackTrace().toString());
		}
		
		// 1. 거래고유번호로 중복거래 확인
		SelectHofTransactionIn selectIn = new SelectHofTransactionIn();
		selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02); // 타발
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());
		// 전문일자로 사용하여야 휴일거래 커버가능.
		selectIn.setTrDt(in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));

		HofTrL reqTrInfo = hofCom.selectHofTransaction(selectIn);
		
		if(reqTrInfo != null) {
			// 1.1.1 중복이지만 해당전문이 재요청(message type 0201)인경우
			if (in.getMessageType().endsWith(ComConst.CHAR_1)) {
				// 1.1.1.1 요청중 && 응답코드가 없는 경우 -> 무시, 종료
				if (TrStsCdEnum.REQUEST.getTrStsCd().equals(reqTrInfo.getTrStsCd())
						&& StringUtils.isEmpty(reqTrInfo.getRespCd())) {
					return;
					// 1.1.1.2 응답코드가 있는 경우 -> 응답 셋팅하여 KFTC 전송 (FLAG 3), 종료
				} else {
					in.setMessageType(HofConst.TLG_KND_DVSN_NO_0210);
					in.setSendReceiveFlag(_getRespFlag(in.getSendReceiveFlag()));
					in.setResponseCode(StringUtils.isNotEmpty(reqTrInfo.getHostRespCd()) ? reqTrInfo.getHostRespCd()
							: reqTrInfo.getRespCd());
					frwTemplate.send(FrwDestination.KFT_HOF, in);
					return;
				}
				// 1.1.2 중복이지만 재요청이 아닌 경우 -> 종료
			} else {
				if (StringUtils.isEmpty(reqTrInfo.getHoliTrYn()) || ComConst.N.equals(reqTrInfo.getHoliTrYn())) {
					log.info("========== 중복요청이므로 무응답처리 end ==========");
					return;
				}
			}
		}else {
			HofTrL insertIn = new HofTrL();
			insertIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02);
			insertIn.setTlgTrDvsnCd(HofConst.TR_DVSN_400000);
			insertIn.setTrStsCd(TrStsCdEnum.ERROR.getTrStsCd());
			insertIn.setTrUnqNo(in.getTransactionIdNumber()); // 13자리 거래고유번호
			insertIn.setRespCd(respCd);
			// process처리과정 롤백 및 에러종료를 HOF_TR_L INSERT
			
			// field값 에러인 경우 전문종별 : 9200으로 전송한다.
			if (respCd.startsWith(ComConst.CHAR_0) && !respCd.equals(HofRespCdEnum.RESP_CD_000.getCode())) {
				in.setMessageType(HofConst.TLG_KND_DVSN_NO_9200);
				insertIn.setTlgKndDvsnCd(HofConst.TLG_KND_DVSN_NO_9200);
			} else {
				in.setMessageType(HofConst.TLG_KND_DVSN_NO_0210);
				insertIn.setTlgKndDvsnCd(HofConst.TLG_KND_DVSN_NO_0210);
			}
			hofCom.insertHofTransaction(insertIn);
			
			String respFlag = _getRespFlag(in.getSendReceiveFlag());
			in.setResponseCode(respCd);
			in.setSendReceiveFlag(respFlag);
			
			frwTemplate.send(FrwDestination.KFT_HOF, in);
			bizCom.setComHoldStatusDone(in.getTransactionIdNumber(),
					in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter())); // hold -> release
			
		}

		return;
	}	private void _createHoldTransaction(KftHof0200400000 in, String holdRsnCd) {

	

		// 이미 등록되어있는 것은 풀고 insert한다.
		bizCom.setComHoldStatusDone(in.getTransactionIdNumber(),
				in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter())); // hold -> release

		ComTrHoldL holdIn = new ComTrHoldL();
		holdIn.setBizDvsnCd(BizDvsnCdEnum.HOF.getValue());
		holdIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_02);
		holdIn.setTlgKndDvsnCd(in.getMessageType());
		holdIn.setTlgTrDvsnCd(in.getMessageCode());
		holdIn.setRcvBnkCd(in.getBeneficiaryBankCode());
		holdIn.setRcvAcctNo(in.getBeneficiaryAccountNumber());
		holdIn.setSndrRealNm(in.getRealSenderName());
		holdIn.setTrAmt(new BigDecimal(in.getTransactionAmount()));
		holdIn.setTlgCtt(frwContext.getTlgCtt());
		holdIn.setTrcId(frwContext.getTractId());
		holdIn.setTrUnqNo(in.getTransactionIdNumber());
		holdIn.setHoldRsnCd(holdRsnCd);
		holdIn.setWhdrwlAcctNo(in.getWithdrawalAccountNumber());
		holdIn.setWhdrwlBnkCd(in.getHandlingInstitutionRepCode());
		holdIn.setWhdrwlNm(in.getRealSenderName());

		bizCom.createHoldTransaction(frwContext, holdIn);
	}

	/**
	 * 
	 * @param reqFlag
	 * @return respFlag
	 */
	public String _getRespFlag(String reqFlag) {

		String respFlag = "";

		int flag = Integer.parseInt(reqFlag);
		respFlag = String.valueOf(flag + 1);

		return respFlag;
	}

}
