package com.jpmc.kcg.bat.enums;

/**
 * CMPLT_STS_CD group code.
 */
public enum BatSchdDvsnCdEnum {
	CRON("00", null),
	DAY("11", null),	 // 매일
	TENDAY("12", null),  // 매월10일, 단 휴일일 경우 다음 영업일
	WEEKDAY("21", null), // 매영업일, 월~토 기본 영업일 달력 기준
	KOREAWEEKDAY("22", null),	// 매영업일, 월~금 한국 영업일 달력 기준
	FRSTWEEKDAY("25", 1),	//매월첫영업일, 월~금 한국 영업일 달력 기준
	THRDWEEKDAY("26", 3),	//매월3영업일, 월~금 한국 영업일 달력 기준
	BFWEEKDAY("27", null),	//직전일 영업일, 월~금 한국 영업일 달력 기준
	;
	
    private final String cd;
    private final Integer weekday;
	
	private BatSchdDvsnCdEnum(String cd, Integer weekday) {
		this.cd = cd;
		this.weekday = weekday;
	}
	
    public String getValue() {
        return this.cd;
    }
    
    public static BatSchdDvsnCdEnum findByCd(String cd) {
    	BatSchdDvsnCdEnum result = null;
         for (BatSchdDvsnCdEnum item : values()) {
             if (item.getValue().equalsIgnoreCase(cd)) {
                 result = item;
                 break;
             }
         }
         return result;
    }
    
    public static BatSchdDvsnCdEnum findByWeekDay(Integer weekday) {
    	BatSchdDvsnCdEnum result = null;
    	if (null == weekday) return result;
    	
        for (BatSchdDvsnCdEnum item : values()) {
             if (weekday.equals(item.weekday)) {
                 result = item;
                 break;
             }
         }
         return result;
    }
}
