package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 소지인 변경내역
 * <pre>{@code
 * KftEntES1121R kftEntES1121R  = new KftEntES1121R(); // 소지인 변경내역
 * kftEntES1121R.setFileName(""); // 업무구분
 * kftEntES1121R.setDataType(""); // 데이터구분
 * kftEntES1121R.setSerialNumber(""); // 일련번호
 * kftEntES1121R.setEnoteStatus(""); // 어음상태
 * kftEntES1121R.setEnoteNumber(""); // 어음번호
 * kftEntES1121R.setEnoteType(""); // 어음종류
 * kftEntES1121R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1121R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1121R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1121R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1121R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1121R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES1121R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES1121R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES1121R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES1121R.setIssuerAddress(""); // 발행인-주소
 * kftEntES1121R.setIssuerBankCode(""); // 발행인-은행코드
 * kftEntES1121R.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEntES1121R.setEndorserCorpIndvSort(""); // 배서인-법인개인구분
 * kftEntES1121R.setEndorserResidentBusinessNumber(""); // 배서인-주민사업자번호
 * kftEntES1121R.setEndorserCorpName(""); // 배서인-법인명
 * kftEntES1121R.setEndorserNameRepresentativeName(""); // 배서인-성명(대표자명)
 * kftEntES1121R.setEndorserAddress(""); // 배서인-주소
 * kftEntES1121R.setEndorserBankCode(""); // 배서인-은행코드
 * kftEntES1121R.setEndorserDepositAccountNumber(""); // 배서인-입금계좌번호
 * kftEntES1121R.setEndorserSplitNumber(""); // 배서인-분할번호
 * kftEntES1121R.setEndorserEndorsementNumber(""); // 배서인-배서번호
 * kftEntES1121R.setOldRecipientSplitNumber(""); // 구소지인-분할번호
 * kftEntES1121R.setOldRecipientEndorsementNumber(""); // 구소지인-배서번호
 * kftEntES1121R.setOldRecipientSplitEnoteAmount(0L); // 구소지인-(분할된)전자어음금액
 * kftEntES1121R.setOldRecipientCorpIndvSort(""); // 구소지인-법인개인구분
 * kftEntES1121R.setOldRecipientResidentBusinessNumber(""); // 구소지인-주민사업자번호
 * kftEntES1121R.setOldRecipientCorpName(""); // 구소지인-법인명
 * kftEntES1121R.setOldRecipientNameRepresentativeName(""); // 구소지인-성명(대표자명)
 * kftEntES1121R.setOldRecipientAddress(""); // 구소지인-주소
 * kftEntES1121R.setOldRecipientDepositAccountNumber(""); // 구소지인-입금계좌번호
 * kftEntES1121R.setNewRecipientCorpIndvSort(""); // 신소지인-법인개인구분
 * kftEntES1121R.setNewRecipientResidentBusinessNumber(""); // 신소지인-주민사업자번호
 * kftEntES1121R.setNewRecipientCorpName(""); // 신소지인-법인명
 * kftEntES1121R.setNewRecipientNameRepresentativeName(""); // 신소지인-성명(대표자명)
 * kftEntES1121R.setNewRecipientAddress(""); // 신소지인-주소
 * kftEntES1121R.setNewRecipientDepositAccountNumber(""); // 신소지인-입금계좌번호
 * kftEntES1121R.setChangeReason(""); // 변경사유
 * kftEntES1121R.setChangeRequestBankAndBranchCode(""); // 변경신청 은행 및 지점코드
 * kftEntES1121R.setChangeRequestDate(""); // 변경요청일자
 * kftEntES1121R.setNotificationTarget(""); // 통지대상
 * kftEntES1121R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1121R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String enoteStatus; // 어음상태
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerBankCode; // 발행인-은행코드
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String endorserCorpIndvSort; // 배서인-법인개인구분
	private String endorserResidentBusinessNumber; // 배서인-주민사업자번호
	private String endorserCorpName; // 배서인-법인명
	private String endorserNameRepresentativeName; // 배서인-성명(대표자명)
	private String endorserAddress; // 배서인-주소
	private String endorserBankCode; // 배서인-은행코드
	private String endorserDepositAccountNumber; // 배서인-입금계좌번호
	private String endorserSplitNumber; // 배서인-분할번호
	private String endorserEndorsementNumber; // 배서인-배서번호
	private String oldRecipientSplitNumber; // 구소지인-분할번호
	private String oldRecipientEndorsementNumber; // 구소지인-배서번호
	private long oldRecipientSplitEnoteAmount; // 구소지인-(분할된)전자어음금액
	private String oldRecipientCorpIndvSort; // 구소지인-법인개인구분
	private String oldRecipientResidentBusinessNumber; // 구소지인-주민사업자번호
	private String oldRecipientCorpName; // 구소지인-법인명
	private String oldRecipientNameRepresentativeName; // 구소지인-성명(대표자명)
	private String oldRecipientAddress; // 구소지인-주소
	private String oldRecipientDepositAccountNumber; // 구소지인-입금계좌번호
	private String newRecipientCorpIndvSort; // 신소지인-법인개인구분
	private String newRecipientResidentBusinessNumber; // 신소지인-주민사업자번호
	private String newRecipientCorpName; // 신소지인-법인명
	private String newRecipientNameRepresentativeName; // 신소지인-성명(대표자명)
	private String newRecipientAddress; // 신소지인-주소
	private String newRecipientDepositAccountNumber; // 신소지인-입금계좌번호
	private String changeReason; // 변경사유
	private String changeRequestBankAndBranchCode; // 변경신청 은행 및 지점코드
	private String changeRequestDate; // 변경요청일자
	private String notificationTarget; // 통지대상
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteStatus$; // 어음상태
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBankCode$; // 발행인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpIndvSort$; // 배서인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserResidentBusinessNumber$; // 배서인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpName$; // 배서인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserNameRepresentativeName$; // 배서인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserAddress$; // 배서인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBankCode$; // 배서인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserDepositAccountNumber$; // 배서인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserSplitNumber$; // 배서인-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserEndorsementNumber$; // 배서인-배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientSplitNumber$; // 구소지인-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientEndorsementNumber$; // 구소지인-배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientSplitEnoteAmount$; // 구소지인-(분할된)전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientCorpIndvSort$; // 구소지인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientResidentBusinessNumber$; // 구소지인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientCorpName$; // 구소지인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientNameRepresentativeName$; // 구소지인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientAddress$; // 구소지인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientDepositAccountNumber$; // 구소지인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientCorpIndvSort$; // 신소지인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientResidentBusinessNumber$; // 신소지인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientCorpName$; // 신소지인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientNameRepresentativeName$; // 신소지인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientAddress$; // 신소지인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientDepositAccountNumber$; // 신소지인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeReason$; // 변경사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeRequestBankAndBranchCode$; // 변경신청 은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeRequestDate$; // 변경요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationTarget$; // 통지대상
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		enoteStatus$ = VOUtils.write(out, enoteStatus, 1); // 어음상태
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerBankCode$ = VOUtils.write(out, issuerBankCode, 3); // 발행인-은행코드
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		endorserCorpIndvSort$ = VOUtils.write(out, endorserCorpIndvSort, 1); // 배서인-법인개인구분
		endorserResidentBusinessNumber$ = VOUtils.write(out, endorserResidentBusinessNumber, 13); // 배서인-주민사업자번호
		endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // 배서인-법인명
		endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // 배서인-성명(대표자명)
		endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // 배서인-주소
		endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // 배서인-은행코드
		endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // 배서인-입금계좌번호
		endorserSplitNumber$ = VOUtils.write(out, endorserSplitNumber, 2); // 배서인-분할번호
		endorserEndorsementNumber$ = VOUtils.write(out, endorserEndorsementNumber, 2); // 배서인-배서번호
		oldRecipientSplitNumber$ = VOUtils.write(out, oldRecipientSplitNumber, 2); // 구소지인-분할번호
		oldRecipientEndorsementNumber$ = VOUtils.write(out, oldRecipientEndorsementNumber, 2); // 구소지인-배서번호
		oldRecipientSplitEnoteAmount$ = VOUtils.write(out, oldRecipientSplitEnoteAmount, 15); // 구소지인-(분할된)전자어음금액
		oldRecipientCorpIndvSort$ = VOUtils.write(out, oldRecipientCorpIndvSort, 1); // 구소지인-법인개인구분
		oldRecipientResidentBusinessNumber$ = VOUtils.write(out, oldRecipientResidentBusinessNumber, 13); // 구소지인-주민사업자번호
		oldRecipientCorpName$ = VOUtils.write(out, oldRecipientCorpName, 40, "EUC-KR"); // 구소지인-법인명
		oldRecipientNameRepresentativeName$ = VOUtils.write(out, oldRecipientNameRepresentativeName, 20, "EUC-KR"); // 구소지인-성명(대표자명)
		oldRecipientAddress$ = VOUtils.write(out, oldRecipientAddress, 60, "EUC-KR"); // 구소지인-주소
		oldRecipientDepositAccountNumber$ = VOUtils.write(out, oldRecipientDepositAccountNumber, 16); // 구소지인-입금계좌번호
		newRecipientCorpIndvSort$ = VOUtils.write(out, newRecipientCorpIndvSort, 1); // 신소지인-법인개인구분
		newRecipientResidentBusinessNumber$ = VOUtils.write(out, newRecipientResidentBusinessNumber, 13); // 신소지인-주민사업자번호
		newRecipientCorpName$ = VOUtils.write(out, newRecipientCorpName, 40, "EUC-KR"); // 신소지인-법인명
		newRecipientNameRepresentativeName$ = VOUtils.write(out, newRecipientNameRepresentativeName, 20, "EUC-KR"); // 신소지인-성명(대표자명)
		newRecipientAddress$ = VOUtils.write(out, newRecipientAddress, 60, "EUC-KR"); // 신소지인-주소
		newRecipientDepositAccountNumber$ = VOUtils.write(out, newRecipientDepositAccountNumber, 16); // 신소지인-입금계좌번호
		changeReason$ = VOUtils.write(out, changeReason, 1); // 변경사유
		changeRequestBankAndBranchCode$ = VOUtils.write(out, changeRequestBankAndBranchCode, 7); // 변경신청 은행 및 지점코드
		changeRequestDate$ = VOUtils.write(out, changeRequestDate, 8); // 변경요청일자
		notificationTarget$ = VOUtils.write(out, notificationTarget, 1); // 통지대상
		filler2$ = VOUtils.write(out, filler2, 19); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		enoteStatus = VOUtils.toString(enoteStatus$ = VOUtils.read(in, 1)); // 어음상태
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerBankCode = VOUtils.toString(issuerBankCode$ = VOUtils.read(in, 3)); // 발행인-은행코드
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		endorserCorpIndvSort = VOUtils.toString(endorserCorpIndvSort$ = VOUtils.read(in, 1)); // 배서인-법인개인구분
		endorserResidentBusinessNumber = VOUtils.toString(endorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // 배서인-주민사업자번호
		endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 배서인-법인명
		endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 배서인-성명(대표자명)
		endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 배서인-주소
		endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // 배서인-은행코드
		endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // 배서인-입금계좌번호
		endorserSplitNumber = VOUtils.toString(endorserSplitNumber$ = VOUtils.read(in, 2)); // 배서인-분할번호
		endorserEndorsementNumber = VOUtils.toString(endorserEndorsementNumber$ = VOUtils.read(in, 2)); // 배서인-배서번호
		oldRecipientSplitNumber = VOUtils.toString(oldRecipientSplitNumber$ = VOUtils.read(in, 2)); // 구소지인-분할번호
		oldRecipientEndorsementNumber = VOUtils.toString(oldRecipientEndorsementNumber$ = VOUtils.read(in, 2)); // 구소지인-배서번호
		oldRecipientSplitEnoteAmount = VOUtils.toLong(oldRecipientSplitEnoteAmount$ = VOUtils.read(in, 15)); // 구소지인-(분할된)전자어음금액
		oldRecipientCorpIndvSort = VOUtils.toString(oldRecipientCorpIndvSort$ = VOUtils.read(in, 1)); // 구소지인-법인개인구분
		oldRecipientResidentBusinessNumber = VOUtils.toString(oldRecipientResidentBusinessNumber$ = VOUtils.read(in, 13)); // 구소지인-주민사업자번호
		oldRecipientCorpName = VOUtils.toString(oldRecipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 구소지인-법인명
		oldRecipientNameRepresentativeName = VOUtils.toString(oldRecipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 구소지인-성명(대표자명)
		oldRecipientAddress = VOUtils.toString(oldRecipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 구소지인-주소
		oldRecipientDepositAccountNumber = VOUtils.toString(oldRecipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 구소지인-입금계좌번호
		newRecipientCorpIndvSort = VOUtils.toString(newRecipientCorpIndvSort$ = VOUtils.read(in, 1)); // 신소지인-법인개인구분
		newRecipientResidentBusinessNumber = VOUtils.toString(newRecipientResidentBusinessNumber$ = VOUtils.read(in, 13)); // 신소지인-주민사업자번호
		newRecipientCorpName = VOUtils.toString(newRecipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 신소지인-법인명
		newRecipientNameRepresentativeName = VOUtils.toString(newRecipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 신소지인-성명(대표자명)
		newRecipientAddress = VOUtils.toString(newRecipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 신소지인-주소
		newRecipientDepositAccountNumber = VOUtils.toString(newRecipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 신소지인-입금계좌번호
		changeReason = VOUtils.toString(changeReason$ = VOUtils.read(in, 1)); // 변경사유
		changeRequestBankAndBranchCode = VOUtils.toString(changeRequestBankAndBranchCode$ = VOUtils.read(in, 7)); // 변경신청 은행 및 지점코드
		changeRequestDate = VOUtils.toString(changeRequestDate$ = VOUtils.read(in, 8)); // 변경요청일자
		notificationTarget = VOUtils.toString(notificationTarget$ = VOUtils.read(in, 1)); // 통지대상
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 19)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", enoteStatus=").append(enoteStatus).append(System.lineSeparator()); // 어음상태
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerBankCode=").append(issuerBankCode).append(System.lineSeparator()); // 발행인-은행코드
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", endorserCorpIndvSort=").append(endorserCorpIndvSort).append(System.lineSeparator()); // 배서인-법인개인구분
		sb.append(", endorserResidentBusinessNumber=").append(endorserResidentBusinessNumber).append(System.lineSeparator()); // 배서인-주민사업자번호
		sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // 배서인-법인명
		sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // 배서인-성명(대표자명)
		sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // 배서인-주소
		sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // 배서인-은행코드
		sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // 배서인-입금계좌번호
		sb.append(", endorserSplitNumber=").append(endorserSplitNumber).append(System.lineSeparator()); // 배서인-분할번호
		sb.append(", endorserEndorsementNumber=").append(endorserEndorsementNumber).append(System.lineSeparator()); // 배서인-배서번호
		sb.append(", oldRecipientSplitNumber=").append(oldRecipientSplitNumber).append(System.lineSeparator()); // 구소지인-분할번호
		sb.append(", oldRecipientEndorsementNumber=").append(oldRecipientEndorsementNumber).append(System.lineSeparator()); // 구소지인-배서번호
		sb.append(", oldRecipientSplitEnoteAmount=").append(oldRecipientSplitEnoteAmount).append(System.lineSeparator()); // 구소지인-(분할된)전자어음금액
		sb.append(", oldRecipientCorpIndvSort=").append(oldRecipientCorpIndvSort).append(System.lineSeparator()); // 구소지인-법인개인구분
		sb.append(", oldRecipientResidentBusinessNumber=").append(oldRecipientResidentBusinessNumber).append(System.lineSeparator()); // 구소지인-주민사업자번호
		sb.append(", oldRecipientCorpName=").append(oldRecipientCorpName).append(System.lineSeparator()); // 구소지인-법인명
		sb.append(", oldRecipientNameRepresentativeName=").append(oldRecipientNameRepresentativeName).append(System.lineSeparator()); // 구소지인-성명(대표자명)
		sb.append(", oldRecipientAddress=").append(oldRecipientAddress).append(System.lineSeparator()); // 구소지인-주소
		sb.append(", oldRecipientDepositAccountNumber=").append(oldRecipientDepositAccountNumber).append(System.lineSeparator()); // 구소지인-입금계좌번호
		sb.append(", newRecipientCorpIndvSort=").append(newRecipientCorpIndvSort).append(System.lineSeparator()); // 신소지인-법인개인구분
		sb.append(", newRecipientResidentBusinessNumber=").append(newRecipientResidentBusinessNumber).append(System.lineSeparator()); // 신소지인-주민사업자번호
		sb.append(", newRecipientCorpName=").append(newRecipientCorpName).append(System.lineSeparator()); // 신소지인-법인명
		sb.append(", newRecipientNameRepresentativeName=").append(newRecipientNameRepresentativeName).append(System.lineSeparator()); // 신소지인-성명(대표자명)
		sb.append(", newRecipientAddress=").append(newRecipientAddress).append(System.lineSeparator()); // 신소지인-주소
		sb.append(", newRecipientDepositAccountNumber=").append(newRecipientDepositAccountNumber).append(System.lineSeparator()); // 신소지인-입금계좌번호
		sb.append(", changeReason=").append(changeReason).append(System.lineSeparator()); // 변경사유
		sb.append(", changeRequestBankAndBranchCode=").append(changeRequestBankAndBranchCode).append(System.lineSeparator()); // 변경신청 은행 및 지점코드
		sb.append(", changeRequestDate=").append(changeRequestDate).append(System.lineSeparator()); // 변경요청일자
		sb.append(", notificationTarget=").append(notificationTarget).append(System.lineSeparator()); // 통지대상
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "enoteStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorserSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorserEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientSplitEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "oldRecipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "oldRecipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "oldRecipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "oldRecipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "oldRecipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "oldRecipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "newRecipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "newRecipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "newRecipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "newRecipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "newRecipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "newRecipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "changeReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "changeRequestBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "changeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "notificationTarget", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "19", "defltVal", "")
		);
	}

}
