package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 현금입금취소
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 
 * requestBankCode 취급기관코드 취급기관 구분코드
 * filler1 FILLER 
 * requestMessageNumber 취급전문관리번호 
 * requestMessageSendTime 취급전문전송시간 
 * kftcMessageNumber 중계센터전문관리번호 
 * kftcMessageTime 중계센터전문전송시간 
 * beneficiaryBankCode 개설기관코드 개설기관 구분코드
 * filler2 FILLER 
 * beneficiaryMessageNumber 개설전문관리번호 
 * beneficiaryMessageSendTime 개설전문전송시간 
 * originalRequestBankCode 원거래취급기관코드 
 * originalRequestBranchCode 원거래취급지점코드 
 * originalRequestMessageNumber 원거래취급전문관리번호 
 * originalRequestMessageTime 원거래취급전문전송시간 
 * originalKftcMessageNumber 원거래중계센터전문관리번호 
 * originalKftcMessageSendTime 원거래중계센터전문전송시간 
 * originalBeneficiaryBankCode 원거래개설기관코드 
 * originalBeneficiaryBranchCode 원거래개설지점코드 
 * originalBeneficiaryMessageNumber 원거래개설전문관리번호 
 * originalBeneficiaryMessageSendTime 원거래개설전문전송시간 
 * originalBeneficiaryAccountNumber 원거래수취인계좌번호 
 * originalTotalAmount 원거래총금액 
 * filler3 FILLER 
 * reservedInformationField11 예비정보FIELD 
 * requestBranchCode 취급기관ㆍ점별코드 
 * beneficiaryBranchCode 개설기관ㆍ점별코드 
 * cancelReasonCode 취소사유코드 01 이중입금 02 계좌입력오류 03 금액입력오류 04 전산오류 05 기타송금취소
 * filler4 FILLER 
 * 
 * KftIft0410200 kftIft0410200 = new KftIft0410200(); // 현금입금취소
 * kftIft0410200.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftIft0410200.setSystemId("03"); // 시스템-ID
 * kftIft0410200.setInstitutionCode("057"); // 기관코드
 * kftIft0410200.setMessageType("0410"); // 전문종별구분코드
 * kftIft0410200.setMessageCode("200"); // 업무구분코드
 * kftIft0410200.setSendReceiveFlag("4"); // 송수신FLAG
 * kftIft0410200.setResponseCode(""); // 응답코드
 * kftIft0410200.setRequestBankCode("000"); // 취급기관코드
 * kftIft0410200.setFiller1(0); // FILLER
 * kftIft0410200.setRequestMessageNumber("000000"); // 취급전문관리번호
 * kftIft0410200.setRequestMessageSendTime(LocalDateTime.now()); // 취급전문전송시간
 * kftIft0410200.setKftcMessageNumber("000000000"); // 중계센터전문관리번호
 * kftIft0410200.setKftcMessageTime(LocalDateTime.now()); // 중계센터전문전송시간
 * kftIft0410200.setBeneficiaryBankCode("000"); // 개설기관코드
 * kftIft0410200.setFiller2(0); // FILLER
 * kftIft0410200.setBeneficiaryMessageNumber("000000"); // 개설전문관리번호
 * kftIft0410200.setBeneficiaryMessageSendTime(LocalDateTime.now()); // 개설전문전송시간
 * kftIft0410200.setOriginalRequestBankCode("000"); // 원거래취급기관코드
 * kftIft0410200.setOriginalRequestBranchCode("0000"); // 원거래취급지점코드
 * kftIft0410200.setOriginalRequestMessageNumber("000000"); // 원거래취급전문관리번호
 * kftIft0410200.setOriginalRequestMessageTime(LocalDateTime.now()); // 원거래취급전문전송시간
 * kftIft0410200.setOriginalKftcMessageNumber("000000000"); // 원거래중계센터전문관리번호
 * kftIft0410200.setOriginalKftcMessageSendTime(LocalDateTime.now()); // 원거래중계센터전문전송시간
 * kftIft0410200.setOriginalBeneficiaryBankCode("000"); // 원거래개설기관코드
 * kftIft0410200.setOriginalBeneficiaryBranchCode("0000"); // 원거래개설지점코드
 * kftIft0410200.setOriginalBeneficiaryMessageNumber("000000"); // 원거래개설전문관리번호
 * kftIft0410200.setOriginalBeneficiaryMessageSendTime(LocalDateTime.now()); // 원거래개설전문전송시간
 * kftIft0410200.setOriginalBeneficiaryAccountNumber(""); // 원거래수취인계좌번호
 * kftIft0410200.setOriginalTotalAmount(0L); // 원거래총금액
 * kftIft0410200.setFiller3(0L); // FILLER
 * kftIft0410200.setReservedInformationField11(""); // 예비정보FIELD
 * kftIft0410200.setRequestBranchCode("0000000"); // 취급기관ㆍ점별코드
 * kftIft0410200.setBeneficiaryBranchCode("0000000"); // 개설기관ㆍ점별코드
 * kftIft0410200.setCancelReasonCode("00"); // 취소사유코드
 * kftIft0410200.setFiller4(""); // FILLER
 * }</pre>
 */
@Data
public class KftIft0410200 implements KftIftComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0410"; // 전문종별구분코드
	private String messageCode = "200"; // 업무구분코드
	private String sendReceiveFlag = "4"; // 송수신FLAG
	private String responseCode; // 응답코드
	private String requestBankCode = "000"; // 취급기관코드
	private int filler1; // FILLER
	private String requestMessageNumber = "000000"; // 취급전문관리번호
	private LocalDateTime requestMessageSendTime; // 취급전문전송시간
	private String kftcMessageNumber = "000000000"; // 중계센터전문관리번호
	private LocalDateTime kftcMessageTime; // 중계센터전문전송시간
	private String beneficiaryBankCode = "000"; // 개설기관코드
	private int filler2; // FILLER
	private String beneficiaryMessageNumber = "000000"; // 개설전문관리번호
	private LocalDateTime beneficiaryMessageSendTime; // 개설전문전송시간
	private String originalRequestBankCode = "000"; // 원거래취급기관코드
	private String originalRequestBranchCode = "0000"; // 원거래취급지점코드
	private String originalRequestMessageNumber = "000000"; // 원거래취급전문관리번호
	private LocalDateTime originalRequestMessageTime; // 원거래취급전문전송시간
	private String originalKftcMessageNumber = "000000000"; // 원거래중계센터전문관리번호
	private LocalDateTime originalKftcMessageSendTime; // 원거래중계센터전문전송시간
	private String originalBeneficiaryBankCode = "000"; // 원거래개설기관코드
	private String originalBeneficiaryBranchCode = "0000"; // 원거래개설지점코드
	private String originalBeneficiaryMessageNumber = "000000"; // 원거래개설전문관리번호
	private LocalDateTime originalBeneficiaryMessageSendTime; // 원거래개설전문전송시간
	private String originalBeneficiaryAccountNumber; // 원거래수취인계좌번호
	private long originalTotalAmount; // 원거래총금액
	private long filler3; // FILLER
	private String reservedInformationField11; // 예비정보FIELD
	private String requestBranchCode = "0000000"; // 취급기관ㆍ점별코드
	private String beneficiaryBranchCode = "0000000"; // 개설기관ㆍ점별코드
	private String cancelReasonCode = "00"; // 취소사유코드
	private String filler4; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankCode$; // 취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageNumber$; // 취급전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageSendTime$; // 취급전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageNumber$; // 중계센터전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageTime$; // 중계센터전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageNumber$; // 개설전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageSendTime$; // 개설전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalRequestBankCode$; // 원거래취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalRequestBranchCode$; // 원거래취급지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalRequestMessageNumber$; // 원거래취급전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalRequestMessageTime$; // 원거래취급전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalKftcMessageNumber$; // 원거래중계센터전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalKftcMessageSendTime$; // 원거래중계센터전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalBeneficiaryBankCode$; // 원거래개설기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalBeneficiaryBranchCode$; // 원거래개설지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalBeneficiaryMessageNumber$; // 원거래개설전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalBeneficiaryMessageSendTime$; // 원거래개설전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalBeneficiaryAccountNumber$; // 원거래수취인계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalTotalAmount$; // 원거래총금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String cancelReasonCode$; // 취소사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 업무구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(requestMessageNumber$)) { // 취급전문관리번호
			return 9;
		}
		if (VOUtils.isWhitespace(requestMessageSendTime$)) { // 취급전문전송시간
			return 10;
		}
		if (VOUtils.isWhitespace(kftcMessageNumber$)) { // 중계센터전문관리번호
			return 11;
		}
		if (VOUtils.isWhitespace(kftcMessageTime$)) { // 중계센터전문전송시간
			return 12;
		}
		if (VOUtils.isWhitespace(beneficiaryMessageNumber$)) { // 개설전문관리번호
			return 15;
		}
		if (VOUtils.isWhitespace(beneficiaryMessageSendTime$)) { // 개설전문전송시간
			return 16;
		}
		if (VOUtils.isWhitespace(originalKftcMessageNumber$)) { // 원거래중계센터전문관리번호
			return 21;
		}
		if (VOUtils.isWhitespace(originalKftcMessageSendTime$)) { // 원거래중계센터전문전송시간
			return 22;
		}
		if (VOUtils.isWhitespace(originalBeneficiaryBranchCode$)) { // 원거래개설지점코드
			return 24;
		}
		if (VOUtils.isWhitespace(originalBeneficiaryMessageNumber$)) { // 원거래개설전문관리번호
			return 25;
		}
		if (VOUtils.isWhitespace(originalBeneficiaryMessageSendTime$)) { // 원거래개설전문전송시간
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(originalBeneficiaryAccountNumber$)) { // 원거래수취인계좌번호
			return 27;
		}
		if (VOUtils.isWhitespace(beneficiaryBranchCode$)) { // 개설기관ㆍ점별코드
			return 32;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBankCode$ = VOUtils.write(out, requestBankCode, 3); // 취급기관코드
		filler1$ = VOUtils.write(out, filler1, 4); // FILLER
		requestMessageNumber$ = VOUtils.write(out, requestMessageNumber, 6); // 취급전문관리번호
		requestMessageSendTime$ = VOUtils.write(out, requestMessageSendTime, 12, "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber$ = VOUtils.write(out, kftcMessageNumber, 9); // 중계센터전문관리번호
		kftcMessageTime$ = VOUtils.write(out, kftcMessageTime, 12, "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관코드
		filler2$ = VOUtils.write(out, filler2, 4); // FILLER
		beneficiaryMessageNumber$ = VOUtils.write(out, beneficiaryMessageNumber, 6); // 개설전문관리번호
		beneficiaryMessageSendTime$ = VOUtils.write(out, beneficiaryMessageSendTime, 12, "yyMMddHHmmss"); // 개설전문전송시간
		originalRequestBankCode$ = VOUtils.write(out, originalRequestBankCode, 3); // 원거래취급기관코드
		originalRequestBranchCode$ = VOUtils.write(out, originalRequestBranchCode, 4); // 원거래취급지점코드
		originalRequestMessageNumber$ = VOUtils.write(out, originalRequestMessageNumber, 6); // 원거래취급전문관리번호
		originalRequestMessageTime$ = VOUtils.write(out, originalRequestMessageTime, 12, "yyMMddHHmmss"); // 원거래취급전문전송시간
		originalKftcMessageNumber$ = VOUtils.write(out, originalKftcMessageNumber, 9); // 원거래중계센터전문관리번호
		originalKftcMessageSendTime$ = VOUtils.write(out, originalKftcMessageSendTime, 12, "yyMMddHHmmss"); // 원거래중계센터전문전송시간
		originalBeneficiaryBankCode$ = VOUtils.write(out, originalBeneficiaryBankCode, 3); // 원거래개설기관코드
		originalBeneficiaryBranchCode$ = VOUtils.write(out, originalBeneficiaryBranchCode, 4); // 원거래개설지점코드
		originalBeneficiaryMessageNumber$ = VOUtils.write(out, originalBeneficiaryMessageNumber, 6); // 원거래개설전문관리번호
		originalBeneficiaryMessageSendTime$ = VOUtils.write(out, originalBeneficiaryMessageSendTime, 12, "yyMMddHHmmss"); // 원거래개설전문전송시간
		originalBeneficiaryAccountNumber$ = VOUtils.write(out, originalBeneficiaryAccountNumber, 14); // 원거래수취인계좌번호
		originalTotalAmount$ = VOUtils.write(out, originalTotalAmount, 12); // 원거래총금액
		filler3$ = VOUtils.write(out, filler3, 12); // FILLER
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 11); // 예비정보FIELD
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 7); // 개설기관ㆍ점별코드
		cancelReasonCode$ = VOUtils.write(out, cancelReasonCode, 2); // 취소사유코드
		filler4$ = VOUtils.write(out, filler4, 77); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBankCode = VOUtils.toString(requestBankCode$ = VOUtils.read(in, 3)); // 취급기관코드
		filler1 = VOUtils.toInt(filler1$ = VOUtils.read(in, 4)); // FILLER
		requestMessageNumber = VOUtils.toString(requestMessageNumber$ = VOUtils.read(in, 6)); // 취급전문관리번호
		requestMessageSendTime = VOUtils.toLocalDateTime(requestMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber = VOUtils.toString(kftcMessageNumber$ = VOUtils.read(in, 9)); // 중계센터전문관리번호
		kftcMessageTime = VOUtils.toLocalDateTime(kftcMessageTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관코드
		filler2 = VOUtils.toInt(filler2$ = VOUtils.read(in, 4)); // FILLER
		beneficiaryMessageNumber = VOUtils.toString(beneficiaryMessageNumber$ = VOUtils.read(in, 6)); // 개설전문관리번호
		beneficiaryMessageSendTime = VOUtils.toLocalDateTime(beneficiaryMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 개설전문전송시간
		originalRequestBankCode = VOUtils.toString(originalRequestBankCode$ = VOUtils.read(in, 3)); // 원거래취급기관코드
		originalRequestBranchCode = VOUtils.toString(originalRequestBranchCode$ = VOUtils.read(in, 4)); // 원거래취급지점코드
		originalRequestMessageNumber = VOUtils.toString(originalRequestMessageNumber$ = VOUtils.read(in, 6)); // 원거래취급전문관리번호
		originalRequestMessageTime = VOUtils.toLocalDateTime(originalRequestMessageTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 원거래취급전문전송시간
		originalKftcMessageNumber = VOUtils.toString(originalKftcMessageNumber$ = VOUtils.read(in, 9)); // 원거래중계센터전문관리번호
		originalKftcMessageSendTime = VOUtils.toLocalDateTime(originalKftcMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 원거래중계센터전문전송시간
		originalBeneficiaryBankCode = VOUtils.toString(originalBeneficiaryBankCode$ = VOUtils.read(in, 3)); // 원거래개설기관코드
		originalBeneficiaryBranchCode = VOUtils.toString(originalBeneficiaryBranchCode$ = VOUtils.read(in, 4)); // 원거래개설지점코드
		originalBeneficiaryMessageNumber = VOUtils.toString(originalBeneficiaryMessageNumber$ = VOUtils.read(in, 6)); // 원거래개설전문관리번호
		originalBeneficiaryMessageSendTime = VOUtils.toLocalDateTime(originalBeneficiaryMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 원거래개설전문전송시간
		originalBeneficiaryAccountNumber = VOUtils.toString(originalBeneficiaryAccountNumber$ = VOUtils.read(in, 14)); // 원거래수취인계좌번호
		originalTotalAmount = VOUtils.toLong(originalTotalAmount$ = VOUtils.read(in, 12)); // 원거래총금액
		filler3 = VOUtils.toLong(filler3$ = VOUtils.read(in, 12)); // FILLER
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 11)); // 예비정보FIELD
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		cancelReasonCode = VOUtils.toString(cancelReasonCode$ = VOUtils.read(in, 2)); // 취소사유코드
		filler4 = VOUtils.toString(filler4$ = VOUtils.read(in, 77)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBankCode=").append(requestBankCode).append(System.lineSeparator()); // 취급기관코드
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append(", requestMessageNumber=").append(requestMessageNumber).append(System.lineSeparator()); // 취급전문관리번호
		sb.append(", requestMessageSendTime=").append(requestMessageSendTime).append(System.lineSeparator()); // 취급전문전송시간
		sb.append(", kftcMessageNumber=").append(kftcMessageNumber).append(System.lineSeparator()); // 중계센터전문관리번호
		sb.append(", kftcMessageTime=").append(kftcMessageTime).append(System.lineSeparator()); // 중계센터전문전송시간
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관코드
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", beneficiaryMessageNumber=").append(beneficiaryMessageNumber).append(System.lineSeparator()); // 개설전문관리번호
		sb.append(", beneficiaryMessageSendTime=").append(beneficiaryMessageSendTime).append(System.lineSeparator()); // 개설전문전송시간
		sb.append(", originalRequestBankCode=").append(originalRequestBankCode).append(System.lineSeparator()); // 원거래취급기관코드
		sb.append(", originalRequestBranchCode=").append(originalRequestBranchCode).append(System.lineSeparator()); // 원거래취급지점코드
		sb.append(", originalRequestMessageNumber=").append(originalRequestMessageNumber).append(System.lineSeparator()); // 원거래취급전문관리번호
		sb.append(", originalRequestMessageTime=").append(originalRequestMessageTime).append(System.lineSeparator()); // 원거래취급전문전송시간
		sb.append(", originalKftcMessageNumber=").append(originalKftcMessageNumber).append(System.lineSeparator()); // 원거래중계센터전문관리번호
		sb.append(", originalKftcMessageSendTime=").append(originalKftcMessageSendTime).append(System.lineSeparator()); // 원거래중계센터전문전송시간
		sb.append(", originalBeneficiaryBankCode=").append(originalBeneficiaryBankCode).append(System.lineSeparator()); // 원거래개설기관코드
		sb.append(", originalBeneficiaryBranchCode=").append(originalBeneficiaryBranchCode).append(System.lineSeparator()); // 원거래개설지점코드
		sb.append(", originalBeneficiaryMessageNumber=").append(originalBeneficiaryMessageNumber).append(System.lineSeparator()); // 원거래개설전문관리번호
		sb.append(", originalBeneficiaryMessageSendTime=").append(originalBeneficiaryMessageSendTime).append(System.lineSeparator()); // 원거래개설전문전송시간
		sb.append(", originalBeneficiaryAccountNumber=").append(originalBeneficiaryAccountNumber).append(System.lineSeparator()); // 원거래수취인계좌번호
		sb.append(", originalTotalAmount=").append(originalTotalAmount).append(System.lineSeparator()); // 원거래총금액
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", cancelReasonCode=").append(cancelReasonCode).append(System.lineSeparator()); // 취소사유코드
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0410"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "200"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "4"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requestBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "filler1", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "requestMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "requestMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "kftcMessageNumber", "fldLen", "9", "defltVal", "000000000"),
			Map.of("fld", "kftcMessageTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "filler2", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "beneficiaryMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "beneficiaryMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "originalRequestBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "originalRequestBranchCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "originalRequestMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "originalRequestMessageTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "originalKftcMessageNumber", "fldLen", "9", "defltVal", "000000000"),
			Map.of("fld", "originalKftcMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "originalBeneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "originalBeneficiaryBranchCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "originalBeneficiaryMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "originalBeneficiaryMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "originalBeneficiaryAccountNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "originalTotalAmount", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "reservedInformationField11", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "cancelReasonCode", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "filler4", "fldLen", "77", "defltVal", "")
		);
	}

}
