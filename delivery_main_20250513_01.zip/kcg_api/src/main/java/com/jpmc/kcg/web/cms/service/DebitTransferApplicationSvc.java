package com.jpmc.kcg.web.cms.service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jpmc.kcg.cms.dao.CmsWhdrwlTrnAplyMMapper;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.cms.enums.CmsRqstDvsnCdEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.cms.dao.CmsWhdrwlTrnAplyMWebDao;
import com.jpmc.kcg.web.cms.dto.CmsWhdrwlTrnAplyMWeb;
import com.jpmc.kcg.web.cms.service.dto.DebitTransferApplicationLedgerIn;
import com.jpmc.kcg.web.cms.service.dto.DebitTransferApplicationLedgerOut;
import com.jpmc.kcg.web.com.constants.BCMN01;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.com.enums.AprvTpCdEnum;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.dto.ComAprvHIn;
import com.jpmc.kcg.web.utils.CpgObjectUtils;
import com.jpmc.kcg.web.utils.JwtUtils;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class DebitTransferApplicationSvc {

    @Autowired
    private CmsWhdrwlTrnAplyMWebDao cmsWhdrwlTrnAplyMWebDao;

    @Autowired
    private CmsWhdrwlTrnAplyMMapper cmsWhdrwlTrnAplyMMapper;

    @Autowired
    private CommonApprovalSvc commonApprovalSvc;

    @Autowired
    private JwtUtils jwtUtils;

    /**
     * 출금이체 신청 목록 조회
     */
    @Transactional(readOnly = true)
    public DebitTransferApplicationLedgerOut getListDebitTransferApplicationLedger(DebitTransferApplicationLedgerIn in) {

        CpgObjectUtils.isDtoValid(in);

        CmsWhdrwlTrnAplyMWeb cmsWhdrwlTrnAplyM = new CmsWhdrwlTrnAplyMWeb();
        cmsWhdrwlTrnAplyM.setCorpCd(in.getCorpCd());
        cmsWhdrwlTrnAplyM.setRtpyrId(in.getRtpyrId());
        cmsWhdrwlTrnAplyM.setRegStsCd(in.getRegStsCd());
        cmsWhdrwlTrnAplyM.setRegDvsnCd(in.getRegDvsnCd());
        cmsWhdrwlTrnAplyM.setAcctNo(in.getAcctNo());
        cmsWhdrwlTrnAplyM.setAcctNm(in.getAcctNm());
        cmsWhdrwlTrnAplyM.setCtzBizNo(in.getCtzBizNo());

//        boolean isMaker = jwtUtils.hasAnyStaticMakerRole();
//        log.info(">>> maker role check : {}", isMaker);

        List<CmsWhdrwlTrnAplyMWeb> outList = cmsWhdrwlTrnAplyMWebDao.selectCmsWhdrwlTrnAplyMList(cmsWhdrwlTrnAplyM, in.getStrtDt(), in.getEndDt(), true); // 모든 조회에서 승인상태 조건 삭제

        Map<String, Long> groupedCounts = outList.stream()
                .filter(dto -> StringUtils.isNotEmpty(dto.getRegStsCd()))
                .collect(Collectors.groupingBy(CmsWhdrwlTrnAplyMWeb::getRegStsCd, Collectors.counting()));

        groupedCounts.forEach((k, v) -> log.info("DebitTransferApplicationLedgerOut key: {}, value: {}", k, v));

        DebitTransferApplicationLedgerOut out = DebitTransferApplicationLedgerOut.builder()
                .outList(outList)
                .regCnt(Math.toIntExact(groupedCounts.getOrDefault(CmsRqstDvsnCdEnum.REGISTRATION.getCode(), 0L)))
                .trmnCnt(Math.toIntExact(groupedCounts.getOrDefault(CmsRqstDvsnCdEnum.TERMINATION.getCode(), 0L)))
                .forTrmnCnt(Math.toIntExact(groupedCounts.getOrDefault(CmsRqstDvsnCdEnum.ARBITRARY_TERMINATION.getCode(), 0L)))
                .build();

        log.debug("DebitTransferApplicationSvc CmsWhdrwlTrnAplyMList size{}", outList.size());

        out.setRsltCode(BCMN01.SUCCESS);
        out.setTotLen(outList.size());
        return out;
    }

    /**
     * 출금이체 신청 처리
     * 1. case 신규등록:
     *   - CMS_WHDRWL_TRN_APLY_M : INSERT
     *   - CMS_WHDRWL_TRN_APLY_DESC_M : INSERT
     * 2. case 해지등록:
     *   - CMS_WHDRWL_TRN_APLY_M : 해지상태로 UPDATE
     *   - CMS_WHDRWL_TRN_APLY_DESC_M : INSERT
     * 3. case 변경등록:
     *   - CMS_WHDRWL_TRN_APLY_M : UPDATE
     *   - CMS_WHDRWL_TRN_APLY_DESC_M : INSERT
     */
    @Transactional
    public DebitTransferApplicationLedgerOut processDebitTransferApplication(DebitTransferApplicationLedgerIn in) {

        log.debug("DebitTransferApplicationSvc processDebitTransferApplication In Dto : {}", in);

        /*
         * 유효값 체크
         */
        CpgObjectUtils.isDtoValid(in, "corpCd", "rtpyrId", "regStsCd", "acctNo", "acctNm", "ctzBizNo");


        CmsWhdrwlTrnAplyM whdrwlTrnAplyM = _setCmsWhdrwlTrnAplyM(in);

        String result = switch (in.getCrudType()) {
            // 신규
            case BCMN01.CREATE -> {
            	
                /*
                 * 기존 데이터 체크
                 */
                Optional<CmsWhdrwlTrnAplyM> beforeDto = Optional.ofNullable(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()));
                
                if (beforeDto.isPresent()) {
                    throw new BusinessException("MCMNI01016");  // 이미 출금이체신청 등록을 한 건 입니다. 신규 등록을 중복으로 할 수 없습니다.
                }
                yield this.create(whdrwlTrnAplyM, in);
            }
            case BCMN01.UPDATE -> {
            	
            	// update인데 1.신규 등록하려는 경우
            	if(StringUtils.equals(in.getRegStsCd(), CmsRqstDvsnCdEnum.REGISTRATION.getCode())) {
            		throw new BusinessException("MCMNE11015"); // 출금이체신청이 등록된 납부자번호입니다. 해지 또는 변경으로 저장하십시오.
            	}
                
                boolean isTerminate = StringUtils.equals(in.getRegStsCd(), CmsRqstDvsnCdEnum.TERMINATION.getCode());
                String pkAccount = isTerminate ? in.getAcctNo() : in.getBeforeAcctNo();  // 해지가 아닌 변경요청시, 계좌번호를 변경할 예정이므로, 계좌는 수정전 계좌 사용

                /*
                 * 기존 데이터 체크
                 */
                Optional<CmsWhdrwlTrnAplyM> beforeDto = Optional.ofNullable(cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(in.getCorpCd(), in.getRtpyrId(), pkAccount));
                
                if (StringUtils.equals(beforeDto.get().getRegStsCd(), CmsRqstDvsnCdEnum.TERMINATION.getCode())) {
                    throw new BusinessException("MCMNI01017");  // 이미 출금이체신청 해지를 한 건 입니다. 다시 해지 등록할 수 없습니다.
                }
                if (!isTerminate && StringUtils.equals(beforeDto.get().getAcctNo(), in.getAcctNo())) {
                    throw new BusinessException("MCMNE11014"); // 계좌번호만 수정 가능합니다.
                }
                
                yield this.change(beforeDto.get(), whdrwlTrnAplyM, in, isTerminate, pkAccount); // 해지 또는 변경
            }
            default -> BCMN01.FAIL;
        };

        DebitTransferApplicationLedgerOut out = new DebitTransferApplicationLedgerOut();
        out.setRsltCode(result);
        return out;
    }

    private String create(CmsWhdrwlTrnAplyM in, DebitTransferApplicationLedgerIn serviceDto) {
        log.debug("DebitTransferApplicationSvc create In Dto : {}", in);

        ComAprvHIn aprvIn = ComAprvHIn.builder().aprvTpCd(AprvTpCdEnum.CMS_WHDRWL_TRN_APLY.getValue())
                .aprvRqstDvsnCd(AprvRqstDvsnCdEnum.INSERT.getValue())
                .aprvKeyVal(StringUtils.joinWith(BCMN01.SPACE, in.getCorpCd(), in.getRtpyrId(), in.getAcctNo()))
                .aprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue())
                .build();
        /*
         * request approval
         */
        commonApprovalSvc.requestApproval(aprvIn, null, serviceDto);

        in.setAprvStsCd(AprvStsCdEnum.INSERT_NOT_APPROVED.getValue());
        in.setReqDt(DateUtils.getISODate());
        cmsWhdrwlTrnAplyMMapper.insert(in);

        return BCMN01.SUCCESS;
    }

    private String change(CmsWhdrwlTrnAplyM beforeDto, CmsWhdrwlTrnAplyM in, DebitTransferApplicationLedgerIn serviceDto, boolean isTerminate, String pkAccount) {
        log.debug("DebitTransferApplicationSvc changePaymentInstructionRequest In Dto : {}", in);

        ComAprvHIn aprvIn = ComAprvHIn.builder().aprvTpCd(AprvTpCdEnum.CMS_WHDRWL_TRN_APLY.getValue())
                .aprvRqstDvsnCd(isTerminate ? AprvRqstDvsnCdEnum.DELETE.getValue() : AprvRqstDvsnCdEnum.UPDATE.getValue())
                .aprvKeyVal(StringUtils.joinWith(BCMN01.SPACE, in.getCorpCd(), in.getRtpyrId(), serviceDto.getBeforeAcctNo()))
                .aprvStsCd(AprvStsCdEnum.NOT_APPROVED.getValue())
                .build();

        /*
         * request approval
         */
        commonApprovalSvc.requestApproval(aprvIn, beforeDto, serviceDto);

        log.info("requestApproval CmsWhdrwlTrnAplyM: {}", in);

        CmsWhdrwlTrnAplyM whdrwlTrnAplyM = new CmsWhdrwlTrnAplyM();
        whdrwlTrnAplyM.setCorpCd(in.getCorpCd()); // 이용기관CODE
        whdrwlTrnAplyM.setRtpyrId(in.getRtpyrId()); // 납부자ID
        whdrwlTrnAplyM.setAcctNo(pkAccount); // 계좌번호
        whdrwlTrnAplyM.setAprvStsCd(AprvStsCdEnum.NOT_APPROVED.getValue());

        log.info("update CmsWhdrwlTrnAplyM: {}", whdrwlTrnAplyM);

        cmsWhdrwlTrnAplyMWebDao.updateCmsWhdrwlTrnAplyM(whdrwlTrnAplyM);

        return BCMN01.SUCCESS;
    }

    private CmsWhdrwlTrnAplyM _setCmsWhdrwlTrnAplyM(DebitTransferApplicationLedgerIn in) {
        CmsWhdrwlTrnAplyM whdrwlTrnAplyM = new CmsWhdrwlTrnAplyM();
        whdrwlTrnAplyM.setCorpCd(in.getCorpCd()); // 이용기관CODE
        whdrwlTrnAplyM.setRtpyrId(in.getRtpyrId()); // 납부자ID
        whdrwlTrnAplyM.setAcctNo(in.getAcctNo()); // 계좌번호
        whdrwlTrnAplyM.setCustNo(in.getCustNo()); // 고객번호
        whdrwlTrnAplyM.setCtzBizNo(in.getCtzBizNo()); // 주민/사업자등록번호
        whdrwlTrnAplyM.setReqDt(in.getReqDt()); // 등록일자
        whdrwlTrnAplyM.setTrmnDt(in.getTrmnDt()); // 해지일자
        whdrwlTrnAplyM.setRegDvsnCd(in.getRegStsCd()); // 등록구분
        whdrwlTrnAplyM.setRegStsCd(in.getRegDvsnCd()); // STATUS
        whdrwlTrnAplyM.setAcctNm(in.getAcctNm()); // 예금주명
        whdrwlTrnAplyM.setTelNo(in.getTelNo()); // 전화번호
        whdrwlTrnAplyM.setWhdrwlFile(in.getWhdrwlFile()); // FILENAME
        whdrwlTrnAplyM.setWhdrwlRecSeq(in.getWhdrwlRecSeq()); // FILERecordSequenceNo.
        whdrwlTrnAplyM.setWhdrwlDt(in.getWhdrwlDt()); // 거래일자
        whdrwlTrnAplyM.setWhdrwlReqAmt(in.getWhdrwlReqAmt()); // 출금의뢰액
        whdrwlTrnAplyM.setWhdrwlAmt(in.getWhdrwlAmt()); // 출금액
        whdrwlTrnAplyM.setWhdrwlRespCd(in.getWhdrwlRespCd()); // 출금액_응답코드
        whdrwlTrnAplyM.setRespDt(in.getRespDt()); // 처리결과수신일자
        whdrwlTrnAplyM.setRespCd(in.getRespCd()); // 처리결과
        whdrwlTrnAplyM.setLastChgDt(in.getLastChgDt()); // 최종변경일
        whdrwlTrnAplyM.setFirstWhdrwlDt(in.getFirstWhdrwlDt()); // firstpaymentdate
        whdrwlTrnAplyM.setBnkBrnchCd(in.getBnkBrnchCd()); // 은행지점코드
        whdrwlTrnAplyM.setResidCheck(in.getResidCheck()); // resid_check
        whdrwlTrnAplyM.setFundTp(in.getFundTp()); // 자금종류
        whdrwlTrnAplyM.setMakeId(WebApplicationContext.getHeader().getStaffId()); // 접수자ID
        whdrwlTrnAplyM.setMakeDttm(DateUtils.getDttm()); // MAKER등록일시
        return whdrwlTrnAplyM;
    }

}
