package com.jpmc.kcg;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.core.convert.ConversionService;
import org.springframework.test.util.ReflectionTestUtils;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComAcctAlarmMDao;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dto.ComAcctAlarmM;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.dto.SelectTotSumForAcctAlarmOut;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwExecutor;
import com.jpmc.kcg.frw.FrwExecutorBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.frw.dao.FrwMsgLDao;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.hof.biz.HofCom;
import com.jpmc.kcg.hof.biz.vo.KcgHof0400400000;
import com.jpmc.kcg.hof.biz.vo.KftHof0200400000;
import com.jpmc.kcg.hof.biz.vo.KftHof0800302000;
import com.jpmc.kcg.hof.biz.vo.KftHof0800303000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200400000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0210400000;
import com.jpmc.kcg.hof.dao.HofBlockAcctInfoMDao;
import com.jpmc.kcg.hof.dao.HofBlockAcctLDao;
import com.jpmc.kcg.hof.dao.HofBlockAcctLMapper;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitMDao;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitMMapper;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitTrLDao;
import com.jpmc.kcg.hof.dao.HofTrLDao;
import com.jpmc.kcg.hof.dto.HofBlockAcctInfoM;
import com.jpmc.kcg.hof.dto.HofBlockAcctL;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitM;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrL;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrLSumOut;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTrListByHostNoDaoIn;
import com.jpmc.kcg.hof.enums.HofConst;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 */
@Slf4j
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class KftHofSchTests {

	@InjectMocks
	private KftHofSch kftHofSch;
	@Mock
	private ReleaseValidation releaseValidation;
	@Mock
	private HofBlockAcctInfoMDao hofBlockAcctInfoMDao;
	@Mock
	private HofBlockAcctLDao hofBlockAcctLDao;
	@Mock
	private HofBlockAcctLMapper hofBlockAcctLMapper;
	@Mock
	private HofTrLDao hofTrLDao;
	@Mock
	private FrwContext frwContext;
	@Mock
	private ConversionService conversionService;
	@Mock
	private BizCom bizCom;
	@Mock
	private FrwMapper frwMapper;
	@Mock
	private FrwMsgLDao frwMsgLDao;
	@Mock
	private HofCom hofCom;
	@Mock
	private HofLrgAmtSplitMMapper hofLrgAmtSplitMMapper;

	private FrwExecutor frwExecutor = new FrwExecutorBean();

	@Mock
	private FrwTemplate frwTemplate;

	@Mock
	private HofLrgAmtSplitMDao hofLrgAmtSplitMDao;

	@Mock
	private HofLrgAmtSplitTrLDao hofLrgAmtSplitTrLDao;

	@Mock
	private ComPshMsgBean comPshMsgBean;

	@Mock
	private ComAcctAlarmMDao comAcctAlarmMDao;
	
	@Mock
	private ComTrHoldLDao comTrHoldLDao;

	@Mock
	private static MockedStatic<VOUtils> voUtils;

	private static LvbHof0200400000 orgnReqVo400;
	private static KcgHof0400400000 cnclReqVo400;

	@BeforeEach
	void setUp() {
		ReflectionTestUtils.setField(kftHofSch, "frwExecutor", frwExecutor);
		orgnReqVo400 = new LvbHof0200400000();
		voUtils.when(() -> VOUtils.toVo(Mockito.nullable(String.class),
				Mockito.eq(LvbHof0200400000.class))).thenReturn(orgnReqVo400);
		cnclReqVo400 = new KcgHof0400400000();
		voUtils.when(() -> VOUtils.toVo(Mockito.nullable(String.class),
				Mockito.eq(KcgHof0400400000.class))).thenReturn(cnclReqVo400);
	}

	@AfterEach
	void tearDown() {
		voUtils.close();
	}

	@Test
	public void testHofFundsTransferOutReReqIntf_ServiceActive_NoReReqTransactions() {
		when(frwContext.getSysTmstmp()).thenReturn(LocalDateTime.now());
		when(frwContext.getSysTmstmp()).thenReturn(LocalDateTime.now());
		when(hofTrLDao.selectReReqHofTransactionList(any())).thenReturn(List.of());

		kftHofSch.hofFundsTransferOutReReqIntf();

		verify(hofTrLDao).selectReReqHofTransactionList(any());
	}

	@Test
	public void testHofFundsTransferOutReReqIntf() {
		when(frwContext.getSysTmstmp()).thenReturn(LocalDateTime.now());
		List<HofTrL> list = new ArrayList<HofTrL>();
		HofTrL reReqTransaction = new HofTrL();
		reReqTransaction.setHndlBnkCd("057");
		reReqTransaction.setOpnBnkCd("003");
		reReqTransaction.setTrcId("000000");
		reReqTransaction
				.setTrDt(LocalDate.now().minusDays(1).format(DateFormat.YYYYMMDD.getFormatter()));
		reReqTransaction.setOutinDvsnCd("01");
		reReqTransaction.setTrUnqNo("111111111");
		list.add(reReqTransaction);

		when(hofTrLDao.selectReReqHofTransactionList(anyString())).thenReturn(list);
		// 다른일자로 return
		kftHofSch.hofFundsTransferOutReReqIntf();

		reReqTransaction.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
		when(bizCom.getConnectivtyValidation(ComConst.JPMC_BANK_CD,
				BizDvsnCdEnum.HOF.getValue(), ComConst.HST)).thenReturn("123");
		// 은행상태 return
		kftHofSch.hofFundsTransferOutReReqIntf();

		when(bizCom.getConnectivtyValidation(reReqTransaction.getOpnBnkCd(),
				BizDvsnCdEnum.HOF.getValue(), ComConst.HST)).thenReturn("000");
		FrwMsgL frwMsgL = new FrwMsgL();
		frwMsgL.setTlgCtt("LVBKCG0200400000");
		;
		when(frwMsgLDao.selectFrwMsgLtlgCtt(any(FrwMsgL.class))).thenReturn(frwMsgL);

		KftHof0200400000 kftReqVo = new KftHof0200400000();
		kftReqVo.setWithdrawalAccountNumber("1199888");
		kftReqVo.setTransactionAmount(1000L);
		//vo변환없어서 exception
		kftHofSch.hofFundsTransferOutReReqIntf();

		voUtils.when(() -> VOUtils.toVo(Mockito.nullable(String.class),
				Mockito.eq(KftHof0200400000.class))).thenReturn(kftReqVo);

		when(hofCom.getPriorityCheck(kftReqVo.getWithdrawalAccountNumber(),
				new BigDecimal(kftReqVo.getTransactionAmount()))).thenReturn("default_priority");

		kftHofSch.hofFundsTransferOutReReqIntf();
	}

	@Test
	void testHofDebitBlockInformationShareOutReqIntf_Success() {
		// Given
		HofBlockAcctInfoM mockBlockAcctInfo = new HofBlockAcctInfoM();
		mockBlockAcctInfo.setAcctNo("1234567890");
		mockBlockAcctInfo.setMgrNm("Manager Name");
		mockBlockAcctInfo.setMgrTelNo("010-1234-5678");
		mockBlockAcctInfo.setRmk("Test Remark");
		mockBlockAcctInfo.setBnkCd("001");
		mockBlockAcctInfo.setAcctStsCd("ACTIVE");

		List<HofBlockAcctL> mockRelTrInfoList = new ArrayList<HofBlockAcctL>();
		HofBlockAcctL mockRelTrInfo = new HofBlockAcctL();
		mockRelTrInfo.setRecvBnkCd("001");
		mockRelTrInfo.setRelTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
		mockRelTrInfo.setRelTrTm(LocalTime.now().format(DateFormat.HHMMSS.getFormatter()));
		mockRelTrInfo.setRelTrUnqNo("123456");
		mockRelTrInfo.setDpstWhdrwlCd("W");
		mockRelTrInfo.setRecvAcctNo("9876543210");
		mockRelTrInfo.setRelTrTotAmt(new BigDecimal(100000));
		mockRelTrInfoList.add(mockRelTrInfo);

		when(hofBlockAcctInfoMDao.selectListHofBlockInfoTrgt())
				.thenReturn(List.of(mockBlockAcctInfo));
		when(releaseValidation.getReleaseConnectivityStatus(anyString(), anyString()))
				.thenReturn(false);
		when(hofBlockAcctLDao.selectBlockAcctRelTrInfo(anyString())).thenReturn(mockRelTrInfoList);
		when(bizCom.getNumbering(anyString(), anyString())).thenReturn("1234567890123");

		// 채번전
		kftHofSch.hofDebitBlockInformationShareOutReqIntf();

		//채번후
		when(bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01)).thenReturn("1233333");
		kftHofSch.hofDebitBlockInformationShareOutReqIntf();
	}

	@Test
	void testHofDebitBlockInformationShareOutReqIntf_NotConnected() {
		// Given
		when(hofBlockAcctInfoMDao.selectListHofBlockInfoTrgt())
				.thenReturn(List.of(new HofBlockAcctInfoM()));
		when(releaseValidation.getReleaseConnectivityStatus(anyString(), anyString()))
				.thenReturn(true);

		// When
		kftHofSch.hofDebitBlockInformationShareOutReqIntf();

		// Then
		verify(releaseValidation, times(1)).getReleaseConnectivityStatus(anyString(), anyString());
	}

	@Test
	void testHofDebitBlockInformationShareOutReqIntf_ExceptionInTransaction() {
		// Given
		HofBlockAcctInfoM mockBlockAcctInfo = new HofBlockAcctInfoM();
		mockBlockAcctInfo.setAcctNo("1234567890");

		when(hofBlockAcctInfoMDao.selectListHofBlockInfoTrgt())
				.thenReturn(List.of(mockBlockAcctInfo));
		when(releaseValidation.getReleaseConnectivityStatus(anyString(), anyString()))
				.thenReturn(false);
		when(hofBlockAcctLDao.selectBlockAcctRelTrInfo(anyString()))
				.thenThrow(new RuntimeException("Transaction Error"));

		// When
		assertDoesNotThrow(() -> kftHofSch.hofDebitBlockInformationShareOutReqIntf());

		// Then
		verify(hofBlockAcctLDao, times(1)).selectBlockAcctRelTrInfo(mockBlockAcctInfo.getAcctNo());
		verify(hofBlockAcctLMapper, times(0)).insert(any(HofBlockAcctL.class)); // 트랜잭션 오류 발생 시 insert가 호출되지 않음
	}

    @Test
    void testHofSystemMessageOutReqIntf() {
    	
    	when(bizCom.getNumbering(any(), any())).thenReturn("00000");
    	when(bizCom.getHofOracleSeqNo(any())).thenReturn("00000");
        // Act
    	kftHofSch.hofSystemMessageOutReqIntf();
        // Assert
        verify(frwTemplate, times(1)).send(eq(FrwDestination.KFT_HOF), any(KftHof0800302000.class));
        verify(frwTemplate, times(2)).send(eq(FrwDestination.KFT_HOF), any(KftHof0800303000.class));
    }

	@Test
	void testHofFundsTransferLrgAmtRelease() {
		// Arrange: 테스트 데이터를 설정
		String today = LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		HofLrgAmtSplitM splitMOut = new HofLrgAmtSplitM();
		splitMOut.setTrDt(today);
		splitMOut.setHostNo("host123");

		List<HofLrgAmtSplitTrL> splitListOut = Arrays.asList(
				createSplitTrL("host123", "seq1", 10000), createSplitTrL("host123", "seq2", 20000),
				createSplitTrL("host123", "seq3", 30000));
		
		List<HofLrgAmtSplitM> selectSplitMList = Arrays.asList(
				createSplitTrM("host123", Long.valueOf(10)), createSplitTrM("host123",Long.valueOf(10)),
				createSplitTrM("host123", Long.valueOf(10)));
		
		HofLrgAmtSplitTrLSumOut sumOut = new HofLrgAmtSplitTrLSumOut();
		sumOut.setErrCnt(10);
		sumOut.setNorCnt(10);
		sumOut.setProcCnt(0);
		
		List<HofTrL> trList = new ArrayList<HofTrL>();
		HofTrL trL = new HofTrL();
		trL.setRespCd("000");
		trL.setFundTpCd("01");
		trList.add(trL);

		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitM(any(HofLrgAmtSplitM.class)))
				.thenReturn(splitMOut);
		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitMForUpdate(any(HofLrgAmtSplitM.class)))
		.thenReturn(splitMOut);
		when(hofLrgAmtSplitTrLDao.selectHofLrgAmtSplitTrLList(any(HofLrgAmtSplitTrL.class)))
				.thenReturn(splitListOut);
		when(releaseValidation.getReleaseNetDebitCap(any())).thenReturn(false);
		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitMByStsCd(any(HofLrgAmtSplitM.class)))
		.thenReturn(selectSplitMList);
		when(hofCom.getHofLrgAmtSplitTrCnt(any(HofLrgAmtSplitTrL.class)))
		.thenReturn(sumOut);
        when(conversionService.convert(any(LvbHof0200400000.class), eq(LvbHof0210400000.class)))
        .thenReturn(new LvbHof0210400000());
		when(hofTrLDao.selectOrgnTrListByHostNo(any(SelectHofTrListByHostNoDaoIn.class)))
		.thenReturn(trList);

		// Act: 테스트 대상 메서드 호출
		kftHofSch.hofFundsTransferLrgAmtRelease();

		// Assert: 예상된 동작 검증
		verify(hofLrgAmtSplitTrLDao, times(splitListOut.size()))
				.updateHofLrgAmtSplitTrLTrStsCd(any(HofLrgAmtSplitTrL.class));
	}

	@Test
	void testHofFundsTransferCancelLrgAmtRelease() {
		// Arrange: 테스트 데이터를 설정
		String today = LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE);
		HofLrgAmtSplitM splitMOut = new HofLrgAmtSplitM();
		splitMOut.setTrDt(today);
		splitMOut.setHostNo("host123");

		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitMForUpdate(any(HofLrgAmtSplitM.class)))
				.thenReturn(splitMOut);

		List<HofTrL> fundTrList = new ArrayList<HofTrL>();
		HofTrL fundTr = new HofTrL();
		fundTr.setTrStsCd("02");
		fundTr.setRespCd("000");
		fundTr.setHostNo("testHost");
		fundTr.setTotTrAmt(BigDecimal.TEN);
		fundTrList.add(fundTr);
		
		when(hofCom.selectHofTrListByHostNo(splitMOut.getHostNo(), splitMOut.getTrDt()))
				.thenReturn(fundTrList);

		// Act: 테스트 대상 메서드 호출
		kftHofSch.hofFundsTransferCancelLrgAmtRelease();
		
		// 전문복원 후 처리
		FrwMsgL reqFrwMsg = new FrwMsgL();
		reqFrwMsg.setTlgBizDvsnCd(HofConst.TR_DVSN_400000);
		reqFrwMsg.setTrnsUnqNo(fundTr.getTrUnqNo());
		reqFrwMsg.setTlgCtt("0430HDR0200400000");
		when(frwMsgLDao.selectFrwMsgLForHofCancel(any(FrwMsgL.class))).thenReturn(reqFrwMsg);
		
		List<HofLrgAmtSplitTrL> splitListOut = Arrays.asList(
				createSplitTrL("host123", "seq1", 10000), createSplitTrL("host123", "seq2", 20000),
				createSplitTrL("host123", "seq3", 30000));
		
		List<HofLrgAmtSplitM> selectSplitMList = Arrays.asList(
				createSplitTrM("host123", Long.valueOf(10)), createSplitTrM("host123",Long.valueOf(10)),
				createSplitTrM("host123", Long.valueOf(10)));
		
		HofLrgAmtSplitTrLSumOut sumOut = new HofLrgAmtSplitTrLSumOut();
		sumOut.setErrCnt(10);
		sumOut.setNorCnt(10);
		sumOut.setProcCnt(0);

		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitM(any(HofLrgAmtSplitM.class)))
				.thenReturn(splitMOut);
		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitMForUpdate(any(HofLrgAmtSplitM.class)))
		.thenReturn(splitMOut);
		when(hofLrgAmtSplitTrLDao.selectHofLrgAmtSplitTrLList(any(HofLrgAmtSplitTrL.class)))
				.thenReturn(splitListOut);
		when(hofLrgAmtSplitMDao.selectHofLrgAmtSplitMByStsCd(any(HofLrgAmtSplitM.class)))
		.thenReturn(selectSplitMList);
		when(hofCom.getHofLrgAmtSplitTrCnt(any(HofLrgAmtSplitTrL.class)))
		.thenReturn(sumOut);
		
		KcgHof0400400000 cancelIn = new KcgHof0400400000();
		voUtils.when(() -> VOUtils.toVo(Mockito.nullable(String.class),
				Mockito.eq(KcgHof0400400000.class))).thenReturn(cancelIn);

		when(frwMsgLDao.selectFrwMsgLtlgCtt(any(FrwMsgL.class))).thenReturn(reqFrwMsg);
		kftHofSch.hofFundsTransferCancelLrgAmtRelease();
	}

	private HofLrgAmtSplitTrL createSplitTrL(String hostNo, String trSeq, int amount) {
		HofLrgAmtSplitTrL splitTrL = new HofLrgAmtSplitTrL();
		splitTrL.setHostNo(hostNo);
		splitTrL.setTrSeq(trSeq);
		splitTrL.setTotTrAmt(BigDecimal.valueOf(amount));
		splitTrL.setFrstChngGuid("guid_" + trSeq);
		return splitTrL;
	}
	
	private HofLrgAmtSplitM createSplitTrM(String hostNo, Long tot) {
		HofLrgAmtSplitM splitTrM = new HofLrgAmtSplitM();
		splitTrM.setHostNo(hostNo);
		splitTrM.setTrStsCd("01");
		splitTrM.setTrCnt(tot);
		return splitTrM;
	}

	@Test
	void testSendHofAcctAlarmMsg() {
		// Mock 데이터 준비
		String nowTm = LocalTime.now().format(DateFormat.HHMM.getFormatter());

		System.out.println("Current Time (nowTm): " + nowTm);

		// Alarm 대상 계좌 목록 Mock
		ComAcctAlarmM trgt1 = new ComAcctAlarmM();
		trgt1.setAcctNo("1234567890");
		trgt1.setAcctNm("John Doe");
		trgt1.setNoTrAlarmYn("Y");

		ComAcctAlarmM trgt2 = new ComAcctAlarmM();
		trgt2.setAcctNo("9876543210");
		trgt2.setAcctNm("Jane Doe");
		trgt2.setNoTrAlarmYn("Y");

		System.out.println("Mock Target Accounts: " + Arrays.asList(trgt1, trgt2));

		when(comAcctAlarmMDao.selectAlarmTrgtList(nowTm)).thenReturn(Arrays.asList(trgt1, trgt2));

		// Total summary Mock
		SelectTotSumForAcctAlarmOut totSumInfo1 = new SelectTotSumForAcctAlarmOut();
		totSumInfo1.setTotCnt("5");
		totSumInfo1.setTotAmt("1000M");

		SelectTotSumForAcctAlarmOut timeSumInfo1 = new SelectTotSumForAcctAlarmOut();
		timeSumInfo1.setTotCnt("3");
		timeSumInfo1.setTotAmt("500M");

		SelectTotSumForAcctAlarmOut totSumInfo2 = new SelectTotSumForAcctAlarmOut();
		totSumInfo2.setTotCnt("0");
		totSumInfo2.setTotAmt("");

		SelectTotSumForAcctAlarmOut timeSumInfo2 = new SelectTotSumForAcctAlarmOut();
		timeSumInfo2.setTotCnt("0");
		timeSumInfo2.setTotAmt("");

		when(comAcctAlarmMDao.selectTotSumForAcctAlarm(trgt1)).thenReturn(totSumInfo1);
		when(comAcctAlarmMDao.selectRecentTotSumForAcctAlarm(trgt1)).thenReturn(timeSumInfo1);

		when(comAcctAlarmMDao.selectTotSumForAcctAlarm(trgt1)).thenReturn(totSumInfo2);
		when(comAcctAlarmMDao.selectRecentTotSumForAcctAlarm(trgt2)).thenReturn(timeSumInfo2);

		System.out.println("Total Summary for 1234567890: " + totSumInfo1);
		System.out.println("Recent Summary for 1234567890: " + timeSumInfo1);

		System.out.println("Total Summary for 9876543210: " + totSumInfo2);
		System.out.println("Recent Summary for 9876543210: " + timeSumInfo2);

		// Test 실행
		kftHofSch.sendHofAcctAlarmMsg();

		// Verify 메시지 전송
		Map<String, Object> expectedParamVal1 = new Hashtable<>();
		expectedParamVal1.put("errTlgId", HofConst.HOFI_OUT_SUM_TITLE);
		expectedParamVal1.put("errCtt",
				"59: 08:30 HOFI Outward Summary [John Doe] Existing Alarm *1234567890  #3    500M KRW (Total #5    1000M KRW)  ");
		System.out.println("Expected Message 1: " + expectedParamVal1);

		Map<String, Object> expectedParamVal2 = new Hashtable<>();
		expectedParamVal2.put("errTlgId", HofConst.HOFI_OUT_SUM_TITLE);
		expectedParamVal2.put("errCtt", "59: 08:30 HOFI Outward Summary [Jane Doe] ");
		System.out.println("Expected Message 2: " + expectedParamVal2);
	}
	
	@Test
    void testSendHofHoldTrTrgt() {
	 
		ComTrHoldL comTrHoldL = new ComTrHoldL();
		
		comTrHoldL.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
		comTrHoldL.setHoldStsCd(ComConst.CHAR_01);
		comTrHoldL.setBizDvsnCd(BizDvsnCdEnum.HOF.getValue());
	 
		ComTrHoldL mockReleaseTrgt = new ComTrHoldL();
	 
		mockReleaseTrgt.setTrAmt(new BigDecimal("5000000"));
		mockReleaseTrgt.setTrSeq(10L);
	 
        when(comTrHoldLDao.selectTransactionReleaseCntAmt(comTrHoldL))
                .thenReturn(mockReleaseTrgt);
        
        kftHofSch.sendHofHoldTrTrgt();
        
        verify(comTrHoldLDao, times(1)).selectTransactionReleaseCntAmt(any(ComTrHoldL.class));
    }

}
