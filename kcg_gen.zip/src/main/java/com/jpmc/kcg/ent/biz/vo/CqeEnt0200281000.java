package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 상환청구 통지
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * type 구분 
 * repaymentClaimDate 상환청구일자 
 * eNoteNumber 어음내역전자어음번호 
 * eNoteType 어음내역어음종류 
 * eNoteIssueDate 어음내역전자어음발행일자 
 * eNoteIssuePlace 어음내역전자어음발행지 
 * eNoteAmount 어음내역전자어음금액 
 * eNoteMaturedDate 어음내역전자어음만기일자 
 * paymentBankAndBranchCode 어음내역지급은행및지점코드 
 * defaultReasonCode 부도사유코드 
 * defaultDate 부도일자 
 * repaymentObligorCorpIndvSortCode 상환의무인법인개인구분코드 
 * repaymentObligorResidentBusinessNumber 상환의무인주민사업자번호 
 * repaymentObligorCorpName 상환의무인법인명 
 * repaymentObligorNameRepresentativeName 상환의무인성명(대표자명) 
 * repaymentObligorAddress 상환의무인주소 
 * repaymentObligorBankCode 상환의무인은행코드 
 * repaymentObligorDepositAccountNumber 상환의무인입금계좌번호 
 * repaymentObligorSplitNumber 상환의무인분할번호 
 * repaymentObligorEndorsementNumber 상환의무인배서번호 
 * unsecuredEndorsementYn 부담보배서여부 
 * nonEndorsableEndorsementYn 배서금지배서여부 
 * repaymentClaimantCorpIndvSortCode 상환청구인법인개인구분코드 
 * repaymentClaimantResidentBusinessNumber 상환청구인주민사업자번호 
 * repaymentClaimantCorpName 상환청구인법인명 
 * repaymentClaimantNameRepresentativeName 상환청구인성명(대표자명) 
 * repaymentClaimantAddress 상환청구인주소 
 * repaymentClaimantBankCode 상환청구인은행코드 
 * repaymentClaimantDepositAccountNumber 상환청구인입금계좌번호 
 * repaymentClaimantSplitNumber 상환청구인분할번호 
 * repaymentClaimantEndorsementNumber 상환청구인배서번호 
 * repaymentClaimAmount 상환청구금액 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * CqeEnt0200281000 cqeEnt0200281000 = new CqeEnt0200281000(); // 상환청구 통지
 * cqeEnt0200281000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200281000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200281000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200281000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200281000.setTransactionCode("281000"); // 거래구분코드
 * cqeEnt0200281000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200281000.setBnkCd("057"); // 은행코드
 * cqeEnt0200281000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200281000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200281000.setFiller(""); // FILLER
 * cqeEnt0200281000.setType(""); // 구분
 * cqeEnt0200281000.setRepaymentClaimDate(""); // 상환청구일자
 * cqeEnt0200281000.setENoteNumber(""); // 어음내역전자어음번호
 * cqeEnt0200281000.setENoteType(""); // 어음내역어음종류
 * cqeEnt0200281000.setENoteIssueDate(""); // 어음내역전자어음발행일자
 * cqeEnt0200281000.setENoteIssuePlace(""); // 어음내역전자어음발행지
 * cqeEnt0200281000.setENoteAmount(0L); // 어음내역전자어음금액
 * cqeEnt0200281000.setENoteMaturedDate(""); // 어음내역전자어음만기일자
 * cqeEnt0200281000.setPaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * cqeEnt0200281000.setDefaultReasonCode(""); // 부도사유코드
 * cqeEnt0200281000.setDefaultDate(""); // 부도일자
 * cqeEnt0200281000.setRepaymentObligorCorpIndvSortCode(""); // 상환의무인법인개인구분코드
 * cqeEnt0200281000.setRepaymentObligorResidentBusinessNumber(""); // 상환의무인주민사업자번호
 * cqeEnt0200281000.setRepaymentObligorCorpName(""); // 상환의무인법인명
 * cqeEnt0200281000.setRepaymentObligorNameRepresentativeName(""); // 상환의무인성명(대표자명)
 * cqeEnt0200281000.setRepaymentObligorAddress(""); // 상환의무인주소
 * cqeEnt0200281000.setRepaymentObligorBankCode(""); // 상환의무인은행코드
 * cqeEnt0200281000.setRepaymentObligorDepositAccountNumber(""); // 상환의무인입금계좌번호
 * cqeEnt0200281000.setRepaymentObligorSplitNumber(""); // 상환의무인분할번호
 * cqeEnt0200281000.setRepaymentObligorEndorsementNumber(""); // 상환의무인배서번호
 * cqeEnt0200281000.setUnsecuredEndorsementYn(""); // 부담보배서여부
 * cqeEnt0200281000.setNonEndorsableEndorsementYn(""); // 배서금지배서여부
 * cqeEnt0200281000.setRepaymentClaimantCorpIndvSortCode(""); // 상환청구인법인개인구분코드
 * cqeEnt0200281000.setRepaymentClaimantResidentBusinessNumber(""); // 상환청구인주민사업자번호
 * cqeEnt0200281000.setRepaymentClaimantCorpName(""); // 상환청구인법인명
 * cqeEnt0200281000.setRepaymentClaimantNameRepresentativeName(""); // 상환청구인성명(대표자명)
 * cqeEnt0200281000.setRepaymentClaimantAddress(""); // 상환청구인주소
 * cqeEnt0200281000.setRepaymentClaimantBankCode(""); // 상환청구인은행코드
 * cqeEnt0200281000.setRepaymentClaimantDepositAccountNumber(""); // 상환청구인입금계좌번호
 * cqeEnt0200281000.setRepaymentClaimantSplitNumber("00"); // 상환청구인분할번호
 * cqeEnt0200281000.setRepaymentClaimantEndorsementNumber("00"); // 상환청구인배서번호
 * cqeEnt0200281000.setRepaymentClaimAmount(0L); // 상환청구금액
 * cqeEnt0200281000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * cqeEnt0200281000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class CqeEnt0200281000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "281000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String type; // 구분
	private String repaymentClaimDate; // 상환청구일자
	private String eNoteNumber; // 어음내역전자어음번호
	private String eNoteType; // 어음내역어음종류
	private String eNoteIssueDate; // 어음내역전자어음발행일자
	private String eNoteIssuePlace; // 어음내역전자어음발행지
	private long eNoteAmount; // 어음내역전자어음금액
	private String eNoteMaturedDate; // 어음내역전자어음만기일자
	private String paymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private String defaultReasonCode; // 부도사유코드
	private String defaultDate; // 부도일자
	private String repaymentObligorCorpIndvSortCode; // 상환의무인법인개인구분코드
	private String repaymentObligorResidentBusinessNumber; // 상환의무인주민사업자번호
	private String repaymentObligorCorpName; // 상환의무인법인명
	private String repaymentObligorNameRepresentativeName; // 상환의무인성명(대표자명)
	private String repaymentObligorAddress; // 상환의무인주소
	private String repaymentObligorBankCode; // 상환의무인은행코드
	private String repaymentObligorDepositAccountNumber; // 상환의무인입금계좌번호
	private String repaymentObligorSplitNumber; // 상환의무인분할번호
	private String repaymentObligorEndorsementNumber; // 상환의무인배서번호
	private String unsecuredEndorsementYn; // 부담보배서여부
	private String nonEndorsableEndorsementYn; // 배서금지배서여부
	private String repaymentClaimantCorpIndvSortCode; // 상환청구인법인개인구분코드
	private String repaymentClaimantResidentBusinessNumber; // 상환청구인주민사업자번호
	private String repaymentClaimantCorpName; // 상환청구인법인명
	private String repaymentClaimantNameRepresentativeName; // 상환청구인성명(대표자명)
	private String repaymentClaimantAddress; // 상환청구인주소
	private String repaymentClaimantBankCode; // 상환청구인은행코드
	private String repaymentClaimantDepositAccountNumber; // 상환청구인입금계좌번호
	private String repaymentClaimantSplitNumber = "00"; // 상환청구인분할번호
	private String repaymentClaimantEndorsementNumber = "00"; // 상환청구인배서번호
	private long repaymentClaimAmount; // 상환청구금액
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String type$; // 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimDate$; // 상환청구일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonCode$; // 부도사유코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 부도일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpIndvSortCode$; // 상환의무인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorResidentBusinessNumber$; // 상환의무인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorCorpName$; // 상환의무인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorNameRepresentativeName$; // 상환의무인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorAddress$; // 상환의무인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorBankCode$; // 상환의무인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorDepositAccountNumber$; // 상환의무인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorSplitNumber$; // 상환의무인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentObligorEndorsementNumber$; // 상환의무인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String unsecuredEndorsementYn$; // 부담보배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nonEndorsableEndorsementYn$; // 배서금지배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpIndvSortCode$; // 상환청구인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantResidentBusinessNumber$; // 상환청구인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantCorpName$; // 상환청구인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantNameRepresentativeName$; // 상환청구인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantAddress$; // 상환청구인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantBankCode$; // 상환청구인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantDepositAccountNumber$; // 상환청구인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantSplitNumber$; // 상환청구인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimantEndorsementNumber$; // 상환청구인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String repaymentClaimAmount$; // 상환청구금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음내역전자어음번호
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentObligorResidentBusinessNumber$)) { // 상환의무인주민사업자번호
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentObligorDepositAccountNumber$)) { // 상환의무인입금계좌번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantResidentBusinessNumber$)) { // 상환청구인주민사업자번호
			return 33;
		}
		if (VOUtils.isNotAlphanumericSpace(repaymentClaimantDepositAccountNumber$)) { // 상환청구인입금계좌번호
			return 38;
		}
		if (VOUtils.isWhitespace(repaymentClaimantSplitNumber$)) { // 상환청구인분할번호
			return 39;
		}
		if (VOUtils.isWhitespace(repaymentClaimantEndorsementNumber$)) { // 상환청구인배서번호
			return 40;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		type$ = VOUtils.write(out, type, 1); // 구분
		repaymentClaimDate$ = VOUtils.write(out, repaymentClaimDate, 8); // 상환청구일자
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음내역전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음내역어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음내역전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음내역전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음내역전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		defaultReasonCode$ = VOUtils.write(out, defaultReasonCode, 2); // 부도사유코드
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 부도일자
		repaymentObligorCorpIndvSortCode$ = VOUtils.write(out, repaymentObligorCorpIndvSortCode, 1); // 상환의무인법인개인구분코드
		repaymentObligorResidentBusinessNumber$ = VOUtils.write(out, repaymentObligorResidentBusinessNumber, 13); // 상환의무인주민사업자번호
		repaymentObligorCorpName$ = VOUtils.write(out, repaymentObligorCorpName, 40, "EUC-KR"); // 상환의무인법인명
		repaymentObligorNameRepresentativeName$ = VOUtils.write(out, repaymentObligorNameRepresentativeName, 20, "EUC-KR"); // 상환의무인성명(대표자명)
		repaymentObligorAddress$ = VOUtils.write(out, repaymentObligorAddress, 60, "EUC-KR"); // 상환의무인주소
		repaymentObligorBankCode$ = VOUtils.write(out, repaymentObligorBankCode, 3); // 상환의무인은행코드
		repaymentObligorDepositAccountNumber$ = VOUtils.write(out, repaymentObligorDepositAccountNumber, 16); // 상환의무인입금계좌번호
		repaymentObligorSplitNumber$ = VOUtils.write(out, repaymentObligorSplitNumber, 2); // 상환의무인분할번호
		repaymentObligorEndorsementNumber$ = VOUtils.write(out, repaymentObligorEndorsementNumber, 2); // 상환의무인배서번호
		unsecuredEndorsementYn$ = VOUtils.write(out, unsecuredEndorsementYn, 1); // 부담보배서여부
		nonEndorsableEndorsementYn$ = VOUtils.write(out, nonEndorsableEndorsementYn, 1); // 배서금지배서여부
		repaymentClaimantCorpIndvSortCode$ = VOUtils.write(out, repaymentClaimantCorpIndvSortCode, 1); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber$ = VOUtils.write(out, repaymentClaimantResidentBusinessNumber, 13); // 상환청구인주민사업자번호
		repaymentClaimantCorpName$ = VOUtils.write(out, repaymentClaimantCorpName, 40, "EUC-KR"); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName$ = VOUtils.write(out, repaymentClaimantNameRepresentativeName, 20, "EUC-KR"); // 상환청구인성명(대표자명)
		repaymentClaimantAddress$ = VOUtils.write(out, repaymentClaimantAddress, 60, "EUC-KR"); // 상환청구인주소
		repaymentClaimantBankCode$ = VOUtils.write(out, repaymentClaimantBankCode, 3); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber$ = VOUtils.write(out, repaymentClaimantDepositAccountNumber, 16); // 상환청구인입금계좌번호
		repaymentClaimantSplitNumber$ = VOUtils.write(out, repaymentClaimantSplitNumber, 2); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber$ = VOUtils.write(out, repaymentClaimantEndorsementNumber, 2); // 상환청구인배서번호
		repaymentClaimAmount$ = VOUtils.write(out, repaymentClaimAmount, 15); // 상환청구금액
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		type = VOUtils.toString(type$ = VOUtils.read(in, 1)); // 구분
		repaymentClaimDate = VOUtils.toString(repaymentClaimDate$ = VOUtils.read(in, 8)); // 상환청구일자
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		defaultReasonCode = VOUtils.toString(defaultReasonCode$ = VOUtils.read(in, 2)); // 부도사유코드
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 부도일자
		repaymentObligorCorpIndvSortCode = VOUtils.toString(repaymentObligorCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상환의무인법인개인구분코드
		repaymentObligorResidentBusinessNumber = VOUtils.toString(repaymentObligorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환의무인주민사업자번호
		repaymentObligorCorpName = VOUtils.toString(repaymentObligorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환의무인법인명
		repaymentObligorNameRepresentativeName = VOUtils.toString(repaymentObligorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환의무인성명(대표자명)
		repaymentObligorAddress = VOUtils.toString(repaymentObligorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환의무인주소
		repaymentObligorBankCode = VOUtils.toString(repaymentObligorBankCode$ = VOUtils.read(in, 3)); // 상환의무인은행코드
		repaymentObligorDepositAccountNumber = VOUtils.toString(repaymentObligorDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환의무인입금계좌번호
		repaymentObligorSplitNumber = VOUtils.toString(repaymentObligorSplitNumber$ = VOUtils.read(in, 2)); // 상환의무인분할번호
		repaymentObligorEndorsementNumber = VOUtils.toString(repaymentObligorEndorsementNumber$ = VOUtils.read(in, 2)); // 상환의무인배서번호
		unsecuredEndorsementYn = VOUtils.toString(unsecuredEndorsementYn$ = VOUtils.read(in, 1)); // 부담보배서여부
		nonEndorsableEndorsementYn = VOUtils.toString(nonEndorsableEndorsementYn$ = VOUtils.read(in, 1)); // 배서금지배서여부
		repaymentClaimantCorpIndvSortCode = VOUtils.toString(repaymentClaimantCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상환청구인법인개인구분코드
		repaymentClaimantResidentBusinessNumber = VOUtils.toString(repaymentClaimantResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상환청구인주민사업자번호
		repaymentClaimantCorpName = VOUtils.toString(repaymentClaimantCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상환청구인법인명
		repaymentClaimantNameRepresentativeName = VOUtils.toString(repaymentClaimantNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상환청구인성명(대표자명)
		repaymentClaimantAddress = VOUtils.toString(repaymentClaimantAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상환청구인주소
		repaymentClaimantBankCode = VOUtils.toString(repaymentClaimantBankCode$ = VOUtils.read(in, 3)); // 상환청구인은행코드
		repaymentClaimantDepositAccountNumber = VOUtils.toString(repaymentClaimantDepositAccountNumber$ = VOUtils.read(in, 16)); // 상환청구인입금계좌번호
		repaymentClaimantSplitNumber = VOUtils.toString(repaymentClaimantSplitNumber$ = VOUtils.read(in, 2)); // 상환청구인분할번호
		repaymentClaimantEndorsementNumber = VOUtils.toString(repaymentClaimantEndorsementNumber$ = VOUtils.read(in, 2)); // 상환청구인배서번호
		repaymentClaimAmount = VOUtils.toLong(repaymentClaimAmount$ = VOUtils.read(in, 15)); // 상환청구금액
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", type=").append(type).append(System.lineSeparator()); // 구분
		sb.append(", repaymentClaimDate=").append(repaymentClaimDate).append(System.lineSeparator()); // 상환청구일자
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", defaultReasonCode=").append(defaultReasonCode).append(System.lineSeparator()); // 부도사유코드
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 부도일자
		sb.append(", repaymentObligorCorpIndvSortCode=").append(repaymentObligorCorpIndvSortCode).append(System.lineSeparator()); // 상환의무인법인개인구분코드
		sb.append(", repaymentObligorResidentBusinessNumber=").append(repaymentObligorResidentBusinessNumber).append(System.lineSeparator()); // 상환의무인주민사업자번호
		sb.append(", repaymentObligorCorpName=").append(repaymentObligorCorpName).append(System.lineSeparator()); // 상환의무인법인명
		sb.append(", repaymentObligorNameRepresentativeName=").append(repaymentObligorNameRepresentativeName).append(System.lineSeparator()); // 상환의무인성명(대표자명)
		sb.append(", repaymentObligorAddress=").append(repaymentObligorAddress).append(System.lineSeparator()); // 상환의무인주소
		sb.append(", repaymentObligorBankCode=").append(repaymentObligorBankCode).append(System.lineSeparator()); // 상환의무인은행코드
		sb.append(", repaymentObligorDepositAccountNumber=").append(repaymentObligorDepositAccountNumber).append(System.lineSeparator()); // 상환의무인입금계좌번호
		sb.append(", repaymentObligorSplitNumber=").append(repaymentObligorSplitNumber).append(System.lineSeparator()); // 상환의무인분할번호
		sb.append(", repaymentObligorEndorsementNumber=").append(repaymentObligorEndorsementNumber).append(System.lineSeparator()); // 상환의무인배서번호
		sb.append(", unsecuredEndorsementYn=").append(unsecuredEndorsementYn).append(System.lineSeparator()); // 부담보배서여부
		sb.append(", nonEndorsableEndorsementYn=").append(nonEndorsableEndorsementYn).append(System.lineSeparator()); // 배서금지배서여부
		sb.append(", repaymentClaimantCorpIndvSortCode=").append(repaymentClaimantCorpIndvSortCode).append(System.lineSeparator()); // 상환청구인법인개인구분코드
		sb.append(", repaymentClaimantResidentBusinessNumber=").append(repaymentClaimantResidentBusinessNumber).append(System.lineSeparator()); // 상환청구인주민사업자번호
		sb.append(", repaymentClaimantCorpName=").append(repaymentClaimantCorpName).append(System.lineSeparator()); // 상환청구인법인명
		sb.append(", repaymentClaimantNameRepresentativeName=").append(repaymentClaimantNameRepresentativeName).append(System.lineSeparator()); // 상환청구인성명(대표자명)
		sb.append(", repaymentClaimantAddress=").append(repaymentClaimantAddress).append(System.lineSeparator()); // 상환청구인주소
		sb.append(", repaymentClaimantBankCode=").append(repaymentClaimantBankCode).append(System.lineSeparator()); // 상환청구인은행코드
		sb.append(", repaymentClaimantDepositAccountNumber=").append(repaymentClaimantDepositAccountNumber).append(System.lineSeparator()); // 상환청구인입금계좌번호
		sb.append(", repaymentClaimantSplitNumber=").append(repaymentClaimantSplitNumber).append(System.lineSeparator()); // 상환청구인분할번호
		sb.append(", repaymentClaimantEndorsementNumber=").append(repaymentClaimantEndorsementNumber).append(System.lineSeparator()); // 상환청구인배서번호
		sb.append(", repaymentClaimAmount=").append(repaymentClaimAmount).append(System.lineSeparator()); // 상환청구금액
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "281000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "type", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "defaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentObligorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentObligorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentObligorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentObligorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentObligorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentObligorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentObligorSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "repaymentObligorEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "unsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "nonEndorsableEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "repaymentClaimantResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "repaymentClaimantCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "repaymentClaimantNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "repaymentClaimantAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "repaymentClaimantBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "repaymentClaimantDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "repaymentClaimantSplitNumber", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "repaymentClaimantEndorsementNumber", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "repaymentClaimAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
