package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시 통보내역
 * <pre>{@code
 * KftEntES0002R kftEntES0002R  = new KftEntES0002R(); // 지급제시 통보내역
 * kftEntES0002R.setFileName(""); // 업무구분
 * kftEntES0002R.setDataType(""); // 데이터구분
 * kftEntES0002R.setSerialNumber(""); // 일련번호
 * kftEntES0002R.setPaymentDate(""); // 결제일자
 * kftEntES0002R.setPaymentPresentationNumber(""); // 지급제시번호
 * kftEntES0002R.setEnoteNumber(""); // 어음번호
 * kftEntES0002R.setEnoteType(""); // 어음종류
 * kftEntES0002R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES0002R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES0002R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES0002R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES0002R.setPaymentBankCode(""); // 지급은행코드
 * kftEntES0002R.setPaymentBranchClearingHouseCode(""); // 지급점포교환소코드
 * kftEntES0002R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES0002R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES0002R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES0002R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES0002R.setIssuerAddress(""); // 발행인-주소
 * kftEntES0002R.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEntES0002R.setRecipientCorpIndvSort(""); // 소지인-법인개인구분
 * kftEntES0002R.setRecipientResidentBusinessNumber(""); // 소지인-주민사업자번호
 * kftEntES0002R.setRecipientCorpName(""); // 소지인-법인명
 * kftEntES0002R.setRecipientNameRepresentativeName(""); // 소지인-성명(대표자명)
 * kftEntES0002R.setRecipientAddress(""); // 소지인-주소
 * kftEntES0002R.setRecipientDepositBankCode(""); // 소지인-입금은행코드
 * kftEntES0002R.setRecipientDepositAccountNumber(""); // 소지인-입금계좌번호
 * kftEntES0002R.setRecipientSplitEnoteAmount(0L); // 소지인(분할된)전자어음금액
 * kftEntES0002R.setRecipientSplitNumber(""); // 소지인분할번호
 * kftEntES0002R.setRecipientEndorsementNumber(""); // 소지인배서번호
 * kftEntES0002R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES0002R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String paymentDate; // 결제일자
	private String paymentPresentationNumber; // 지급제시번호
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행코드
	private String paymentBranchClearingHouseCode; // 지급점포교환소코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String recipientCorpIndvSort; // 소지인-법인개인구분
	private String recipientResidentBusinessNumber; // 소지인-주민사업자번호
	private String recipientCorpName; // 소지인-법인명
	private String recipientNameRepresentativeName; // 소지인-성명(대표자명)
	private String recipientAddress; // 소지인-주소
	private String recipientDepositBankCode; // 소지인-입금은행코드
	private String recipientDepositAccountNumber; // 소지인-입금계좌번호
	private long recipientSplitEnoteAmount; // 소지인(분할된)전자어음금액
	private String recipientSplitNumber; // 소지인분할번호
	private String recipientEndorsementNumber; // 소지인배서번호
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentDate$; // 결제일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationNumber$; // 지급제시번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpIndvSort$; // 소지인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientResidentBusinessNumber$; // 소지인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpName$; // 소지인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientNameRepresentativeName$; // 소지인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientAddress$; // 소지인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientDepositBankCode$; // 소지인-입금은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientDepositAccountNumber$; // 소지인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientSplitEnoteAmount$; // 소지인(분할된)전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientSplitNumber$; // 소지인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientEndorsementNumber$; // 소지인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		paymentDate$ = VOUtils.write(out, paymentDate, 8); // 결제일자
		paymentPresentationNumber$ = VOUtils.write(out, paymentPresentationNumber, 16); // 지급제시번호
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8, "EUC-KR"); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행코드
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포교환소코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13, "EUC-KR"); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		recipientCorpIndvSort$ = VOUtils.write(out, recipientCorpIndvSort, 1); // 소지인-법인개인구분
		recipientResidentBusinessNumber$ = VOUtils.write(out, recipientResidentBusinessNumber, 13, "EUC-KR"); // 소지인-주민사업자번호
		recipientCorpName$ = VOUtils.write(out, recipientCorpName, 40, "EUC-KR"); // 소지인-법인명
		recipientNameRepresentativeName$ = VOUtils.write(out, recipientNameRepresentativeName, 20, "EUC-KR"); // 소지인-성명(대표자명)
		recipientAddress$ = VOUtils.write(out, recipientAddress, 60, "EUC-KR"); // 소지인-주소
		recipientDepositBankCode$ = VOUtils.write(out, recipientDepositBankCode, 3); // 소지인-입금은행코드
		recipientDepositAccountNumber$ = VOUtils.write(out, recipientDepositAccountNumber, 16); // 소지인-입금계좌번호
		recipientSplitEnoteAmount$ = VOUtils.write(out, recipientSplitEnoteAmount, 15); // 소지인(분할된)전자어음금액
		recipientSplitNumber$ = VOUtils.write(out, recipientSplitNumber, 2); // 소지인분할번호
		recipientEndorsementNumber$ = VOUtils.write(out, recipientEndorsementNumber, 2); // 소지인배서번호
		filler2$ = VOUtils.write(out, filler2, 18); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		paymentDate = VOUtils.toString(paymentDate$ = VOUtils.read(in, 8)); // 결제일자
		paymentPresentationNumber = VOUtils.toString(paymentPresentationNumber$ = VOUtils.read(in, 16)); // 지급제시번호
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8, "EUC-KR")); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행코드
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포교환소코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13, "EUC-KR")); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		recipientCorpIndvSort = VOUtils.toString(recipientCorpIndvSort$ = VOUtils.read(in, 1)); // 소지인-법인개인구분
		recipientResidentBusinessNumber = VOUtils.toString(recipientResidentBusinessNumber$ = VOUtils.read(in, 13, "EUC-KR")); // 소지인-주민사업자번호
		recipientCorpName = VOUtils.toString(recipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 소지인-법인명
		recipientNameRepresentativeName = VOUtils.toString(recipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 소지인-성명(대표자명)
		recipientAddress = VOUtils.toString(recipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 소지인-주소
		recipientDepositBankCode = VOUtils.toString(recipientDepositBankCode$ = VOUtils.read(in, 3)); // 소지인-입금은행코드
		recipientDepositAccountNumber = VOUtils.toString(recipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 소지인-입금계좌번호
		recipientSplitEnoteAmount = VOUtils.toLong(recipientSplitEnoteAmount$ = VOUtils.read(in, 15)); // 소지인(분할된)전자어음금액
		recipientSplitNumber = VOUtils.toString(recipientSplitNumber$ = VOUtils.read(in, 2)); // 소지인분할번호
		recipientEndorsementNumber = VOUtils.toString(recipientEndorsementNumber$ = VOUtils.read(in, 2)); // 소지인배서번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 18)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", paymentDate=").append(paymentDate).append(System.lineSeparator()); // 결제일자
		sb.append(", paymentPresentationNumber=").append(paymentPresentationNumber).append(System.lineSeparator()); // 지급제시번호
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행코드
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포교환소코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", recipientCorpIndvSort=").append(recipientCorpIndvSort).append(System.lineSeparator()); // 소지인-법인개인구분
		sb.append(", recipientResidentBusinessNumber=").append(recipientResidentBusinessNumber).append(System.lineSeparator()); // 소지인-주민사업자번호
		sb.append(", recipientCorpName=").append(recipientCorpName).append(System.lineSeparator()); // 소지인-법인명
		sb.append(", recipientNameRepresentativeName=").append(recipientNameRepresentativeName).append(System.lineSeparator()); // 소지인-성명(대표자명)
		sb.append(", recipientAddress=").append(recipientAddress).append(System.lineSeparator()); // 소지인-주소
		sb.append(", recipientDepositBankCode=").append(recipientDepositBankCode).append(System.lineSeparator()); // 소지인-입금은행코드
		sb.append(", recipientDepositAccountNumber=").append(recipientDepositAccountNumber).append(System.lineSeparator()); // 소지인-입금계좌번호
		sb.append(", recipientSplitEnoteAmount=").append(recipientSplitEnoteAmount).append(System.lineSeparator()); // 소지인(분할된)전자어음금액
		sb.append(", recipientSplitNumber=").append(recipientSplitNumber).append(System.lineSeparator()); // 소지인분할번호
		sb.append(", recipientEndorsementNumber=").append(recipientEndorsementNumber).append(System.lineSeparator()); // 소지인배서번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentPresentationNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "recipientDepositBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "recipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientSplitEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "recipientSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recipientEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "18", "defltVal", "")
		);
	}

}
