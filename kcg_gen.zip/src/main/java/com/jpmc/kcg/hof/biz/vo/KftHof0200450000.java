package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * HBK 거액타행이체
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 
 * systemId 시스템-ID 
 * messageType 전문종별코드 
 * messageCode 거래구분코드 
 * sendReceiveFlag 송수신FLAG 
 * status STATUS 
 * responseCode 응답코드 
 * messageTransmissionDate 전문전송일 
 * messageSendTime 전문전송시간 
 * messageTrackingNumber 전문추적번호 
 * traxOccurredDate 거래발생일 
 * transactionIdNumber 거래고유번호 
 * handlingInstitutionRepCode 취급기관대표코드 
 * requestBranchCode 취급기관ㆍ점별코드 
 * beneficiaryBankCode 개설기관대표코드 
 * beneficiaryBranchCode 개설기관ㆍ점별코드 
 * beneficiaryAccountNumber 수취계좌번호 
 * transactionAmount 거래금액 
 * beneficiaryAreaCode 수취지역코드 
 * withdrawer 출금인 
 * beneficiaryName 수취인 
 * mediaType 매체구분 
 * fundType 자금성격 
 * requestorInformation 의뢰인정보 
 * withdrawalAccountNumber 출금계좌번호 
 * reservedInformationField1 예비정보FIELD 
 * reservedInformationField2 예비정보FIELD 
 * realSenderName 송금인실명 
 * suspectedFraudInfo 금융사기의심유의정보 향후 필드 미사용 예정
 * filler FILLER 
 * hbkTransactionId 거액타행이체수취조회거래고유번호 
 * hbkWireResponseCode 한은금융망응답코드 
 * beneficiaryBankResponseCode 개설기관응답코드 
 * hbkWireHandlingAccountInstitution 한은금융망취급기관계정개설처 
 * hbkWireOpenAccountInstitution 한은금융망개설기관계정개설처 
 * hbkWireTransferSerialNumber 한은금융망자금이체일련번호 
 * filler1 FILLER 
 * filler4 FILLER 
 * filler3 FILLER 
 * hbkWireApplicationTime 한은금융망신청시간 
 * hbkWirePaymentTime 한은금융망결제시간 
 * hbkWirePaymentMethod 한은금융망결제방법 
 * filler2 FILLER 
 * originalTransactionIDNumber 원거래거래고유번호 
 * originalTransactionFundTransferSerialNumber 원거래자금이체일련번호 
 * hbkWireInfoFiller 한은금융망정보부FILLER 
 * 
 * KftHof0200450000 kftHof0200450000 = new KftHof0200450000(); // HBK 거액타행이체
 * kftHof0200450000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0200450000.setSystemId("ELB"); // 시스템-ID
 * kftHof0200450000.setMessageType("0200"); // 전문종별코드
 * kftHof0200450000.setMessageCode("450000"); // 거래구분코드
 * kftHof0200450000.setSendReceiveFlag("1"); // 송수신FLAG
 * kftHof0200450000.setStatus("000"); // STATUS
 * kftHof0200450000.setResponseCode(""); // 응답코드
 * kftHof0200450000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0200450000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0200450000.setMessageTrackingNumber("00000000"); // 전문추적번호
 * kftHof0200450000.setTraxOccurredDate(LocalDate.now()); // 거래발생일
 * kftHof0200450000.setTransactionIdNumber(""); // 거래고유번호
 * kftHof0200450000.setHandlingInstitutionRepCode("000"); // 취급기관대표코드
 * kftHof0200450000.setRequestBranchCode("0000000"); // 취급기관ㆍ점별코드
 * kftHof0200450000.setBeneficiaryBankCode("000"); // 개설기관대표코드
 * kftHof0200450000.setBeneficiaryBranchCode("0000000"); // 개설기관ㆍ점별코드
 * kftHof0200450000.setBeneficiaryAccountNumber(""); // 수취계좌번호
 * kftHof0200450000.setTransactionAmount(0L); // 거래금액
 * kftHof0200450000.setBeneficiaryAreaCode("00"); // 수취지역코드
 * kftHof0200450000.setWithdrawer(""); // 출금인
 * kftHof0200450000.setBeneficiaryName(""); // 수취인
 * kftHof0200450000.setMediaType("01"); // 매체구분
 * kftHof0200450000.setFundType("00"); // 자금성격
 * kftHof0200450000.setRequestorInformation(""); // 의뢰인정보
 * kftHof0200450000.setWithdrawalAccountNumber(""); // 출금계좌번호
 * kftHof0200450000.setReservedInformationField1(""); // 예비정보FIELD
 * kftHof0200450000.setReservedInformationField2(""); // 예비정보FIELD
 * kftHof0200450000.setRealSenderName(""); // 송금인실명
 * kftHof0200450000.setSuspectedFraudInfo(""); // 금융사기의심유의정보
 * kftHof0200450000.setFiller(""); // FILLER
 * kftHof0200450000.setHbkTransactionId(""); // 거액타행이체수취조회거래고유번호
 * kftHof0200450000.setHbkWireResponseCode(""); // 한은금융망응답코드
 * kftHof0200450000.setBeneficiaryBankResponseCode(""); // 개설기관응답코드
 * kftHof0200450000.setHbkWireHandlingAccountInstitution("0000"); // 한은금융망취급기관계정개설처
 * kftHof0200450000.setHbkWireOpenAccountInstitution("0000"); // 한은금융망개설기관계정개설처
 * kftHof0200450000.setHbkWireTransferSerialNumber("00000"); // 한은금융망자금이체일련번호
 * kftHof0200450000.setFiller1(""); // FILLER
 * kftHof0200450000.setFiller4(""); // FILLER
 * kftHof0200450000.setFiller3(""); // FILLER
 * kftHof0200450000.setHbkWireApplicationTime("000000"); // 한은금융망신청시간
 * kftHof0200450000.setHbkWirePaymentTime("000000"); // 한은금융망결제시간
 * kftHof0200450000.setHbkWirePaymentMethod("0"); // 한은금융망결제방법
 * kftHof0200450000.setFiller2(""); // FILLER
 * kftHof0200450000.setOriginalTransactionIDNumber(""); // 원거래거래고유번호
 * kftHof0200450000.setOriginalTransactionFundTransferSerialNumber("00000"); // 원거래자금이체일련번호
 * kftHof0200450000.setHbkWireInfoFiller(""); // 한은금융망정보부FILLER
 * }</pre>
 */
@Data
public class KftHof0200450000 implements KftHofComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "ELB"; // 시스템-ID
	private String messageType = "0200"; // 전문종별코드
	private String messageCode = "450000"; // 거래구분코드
	private String sendReceiveFlag = "1"; // 송수신FLAG
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "00000000"; // 전문추적번호
	private LocalDate traxOccurredDate; // 거래발생일
	private String transactionIdNumber; // 거래고유번호
	private String handlingInstitutionRepCode = "000"; // 취급기관대표코드
	private String requestBranchCode = "0000000"; // 취급기관ㆍ점별코드
	private String beneficiaryBankCode = "000"; // 개설기관대표코드
	private String beneficiaryBranchCode = "0000000"; // 개설기관ㆍ점별코드
	private String beneficiaryAccountNumber; // 수취계좌번호
	private long transactionAmount; // 거래금액
	private String beneficiaryAreaCode = "00"; // 수취지역코드
	private String withdrawer; // 출금인
	private String beneficiaryName; // 수취인
	private String mediaType = "01"; // 매체구분
	private String fundType = "00"; // 자금성격
	private String requestorInformation; // 의뢰인정보
	private String withdrawalAccountNumber; // 출금계좌번호
	private String reservedInformationField1; // 예비정보FIELD
	private String reservedInformationField2; // 예비정보FIELD
	private String realSenderName; // 송금인실명
	private String suspectedFraudInfo; // 금융사기의심유의정보
	private String filler; // FILLER
	private String hbkTransactionId; // 거액타행이체수취조회거래고유번호
	private String hbkWireResponseCode; // 한은금융망응답코드
	private String beneficiaryBankResponseCode; // 개설기관응답코드
	private String hbkWireHandlingAccountInstitution = "0000"; // 한은금융망취급기관계정개설처
	private String hbkWireOpenAccountInstitution = "0000"; // 한은금융망개설기관계정개설처
	private String hbkWireTransferSerialNumber = "00000"; // 한은금융망자금이체일련번호
	private String filler1; // FILLER
	private String filler4; // FILLER
	private String filler3; // FILLER
	private String hbkWireApplicationTime = "000000"; // 한은금융망신청시간
	private String hbkWirePaymentTime = "000000"; // 한은금융망결제시간
	private String hbkWirePaymentMethod = "0"; // 한은금융망결제방법
	private String filler2; // FILLER
	private String originalTransactionIDNumber; // 원거래거래고유번호
	private String originalTransactionFundTransferSerialNumber = "00000"; // 원거래자금이체일련번호
	private String hbkWireInfoFiller; // 한은금융망정보부FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String traxOccurredDate$; // 거래발생일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingInstitutionRepCode$; // 취급기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionAmount$; // 거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAreaCode$; // 수취지역코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawer$; // 출금인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mediaType$; // 매체구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금성격
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestorInformation$; // 의뢰인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField1$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField2$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realSenderName$; // 송금인실명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String suspectedFraudInfo$; // 금융사기의심유의정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkTransactionId$; // 거액타행이체수취조회거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireResponseCode$; // 한은금융망응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankResponseCode$; // 개설기관응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireHandlingAccountInstitution$; // 한은금융망취급기관계정개설처
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireOpenAccountInstitution$; // 한은금융망개설기관계정개설처
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireTransferSerialNumber$; // 한은금융망자금이체일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireApplicationTime$; // 한은금융망신청시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWirePaymentTime$; // 한은금융망결제시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWirePaymentMethod$; // 한은금융망결제방법
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalTransactionIDNumber$; // 원거래거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalTransactionFundTransferSerialNumber$; // 원거래자금이체일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String hbkWireInfoFiller$; // 한은금융망정보부FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 4;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 7;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 8;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 9;
		}
		if (VOUtils.isWhitespace(traxOccurredDate$)) { // 거래발생일
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryAccountNumber$)) { // 수취계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(requestorInformation$)) { // 의뢰인정보
			return 23;
		}
		if (VOUtils.isNotAlphanumericSpace(withdrawalAccountNumber$)) { // 출금계좌번호
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(suspectedFraudInfo$)) { // 금융사기의심유의정보
			return 28;
		}
		if (VOUtils.isNotAlphanumericSpace(hbkTransactionId$)) { // 거액타행이체수취조회거래고유번호
			return 30;
		}
		if (VOUtils.isNotAlphanumericSpace(hbkWireResponseCode$)) { // 한은금융망응답코드
			return 31;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryBankResponseCode$)) { // 개설기관응답코드
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(originalTransactionIDNumber$)) { // 원거래거래고유번호
			return 43;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 8); // 전문추적번호
		traxOccurredDate$ = VOUtils.write(out, traxOccurredDate, 8, "yyyyMMdd"); // 거래발생일
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		handlingInstitutionRepCode$ = VOUtils.write(out, handlingInstitutionRepCode, 3); // 취급기관대표코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관대표코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 7); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취계좌번호
		transactionAmount$ = VOUtils.write(out, transactionAmount, 14); // 거래금액
		beneficiaryAreaCode$ = VOUtils.write(out, beneficiaryAreaCode, 2); // 수취지역코드
		withdrawer$ = VOUtils.write(out, withdrawer, 20, "EUC-KR"); // 출금인
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인
		mediaType$ = VOUtils.write(out, mediaType, 2); // 매체구분
		fundType$ = VOUtils.write(out, fundType, 2); // 자금성격
		requestorInformation$ = VOUtils.write(out, requestorInformation, 32); // 의뢰인정보
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		reservedInformationField1$ = VOUtils.write(out, reservedInformationField1, 10); // 예비정보FIELD
		reservedInformationField2$ = VOUtils.write(out, reservedInformationField2, 28); // 예비정보FIELD
		realSenderName$ = VOUtils.write(out, realSenderName, 20, "EUC-KR"); // 송금인실명
		suspectedFraudInfo$ = VOUtils.write(out, suspectedFraudInfo, 2); // 금융사기의심유의정보
		filler$ = VOUtils.write(out, filler, 133); // FILLER
		hbkTransactionId$ = VOUtils.write(out, hbkTransactionId, 13); // 거액타행이체수취조회거래고유번호
		hbkWireResponseCode$ = VOUtils.write(out, hbkWireResponseCode, 4); // 한은금융망응답코드
		beneficiaryBankResponseCode$ = VOUtils.write(out, beneficiaryBankResponseCode, 3); // 개설기관응답코드
		hbkWireHandlingAccountInstitution$ = VOUtils.write(out, hbkWireHandlingAccountInstitution, 4); // 한은금융망취급기관계정개설처
		hbkWireOpenAccountInstitution$ = VOUtils.write(out, hbkWireOpenAccountInstitution, 4); // 한은금융망개설기관계정개설처
		hbkWireTransferSerialNumber$ = VOUtils.write(out, hbkWireTransferSerialNumber, 5); // 한은금융망자금이체일련번호
		filler1$ = VOUtils.write(out, filler1, 5); // FILLER
		filler4$ = VOUtils.write(out, filler4, 16); // FILLER
		filler3$ = VOUtils.write(out, filler3, 9); // FILLER
		hbkWireApplicationTime$ = VOUtils.write(out, hbkWireApplicationTime, 6); // 한은금융망신청시간
		hbkWirePaymentTime$ = VOUtils.write(out, hbkWirePaymentTime, 6); // 한은금융망결제시간
		hbkWirePaymentMethod$ = VOUtils.write(out, hbkWirePaymentMethod, 1); // 한은금융망결제방법
		filler2$ = VOUtils.write(out, filler2, 2); // FILLER
		originalTransactionIDNumber$ = VOUtils.write(out, originalTransactionIDNumber, 13); // 원거래거래고유번호
		originalTransactionFundTransferSerialNumber$ = VOUtils.write(out, originalTransactionFundTransferSerialNumber, 5); // 원거래자금이체일련번호
		hbkWireInfoFiller$ = VOUtils.write(out, hbkWireInfoFiller, 104); // 한은금융망정보부FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 8)); // 전문추적번호
		traxOccurredDate = VOUtils.toLocalDate(traxOccurredDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 거래발생일
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		handlingInstitutionRepCode = VOUtils.toString(handlingInstitutionRepCode$ = VOUtils.read(in, 3)); // 취급기관대표코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관대표코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취계좌번호
		transactionAmount = VOUtils.toLong(transactionAmount$ = VOUtils.read(in, 14)); // 거래금액
		beneficiaryAreaCode = VOUtils.toString(beneficiaryAreaCode$ = VOUtils.read(in, 2)); // 수취지역코드
		withdrawer = VOUtils.toString(withdrawer$ = VOUtils.read(in, 20, "EUC-KR")); // 출금인
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인
		mediaType = VOUtils.toString(mediaType$ = VOUtils.read(in, 2)); // 매체구분
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금성격
		requestorInformation = VOUtils.toString(requestorInformation$ = VOUtils.read(in, 32)); // 의뢰인정보
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		reservedInformationField1 = VOUtils.toString(reservedInformationField1$ = VOUtils.read(in, 10)); // 예비정보FIELD
		reservedInformationField2 = VOUtils.toString(reservedInformationField2$ = VOUtils.read(in, 28)); // 예비정보FIELD
		realSenderName = VOUtils.toString(realSenderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송금인실명
		suspectedFraudInfo = VOUtils.toString(suspectedFraudInfo$ = VOUtils.read(in, 2)); // 금융사기의심유의정보
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 133)); // FILLER
		hbkTransactionId = VOUtils.toString(hbkTransactionId$ = VOUtils.read(in, 13)); // 거액타행이체수취조회거래고유번호
		hbkWireResponseCode = VOUtils.toString(hbkWireResponseCode$ = VOUtils.read(in, 4)); // 한은금융망응답코드
		beneficiaryBankResponseCode = VOUtils.toString(beneficiaryBankResponseCode$ = VOUtils.read(in, 3)); // 개설기관응답코드
		hbkWireHandlingAccountInstitution = VOUtils.toString(hbkWireHandlingAccountInstitution$ = VOUtils.read(in, 4)); // 한은금융망취급기관계정개설처
		hbkWireOpenAccountInstitution = VOUtils.toString(hbkWireOpenAccountInstitution$ = VOUtils.read(in, 4)); // 한은금융망개설기관계정개설처
		hbkWireTransferSerialNumber = VOUtils.toString(hbkWireTransferSerialNumber$ = VOUtils.read(in, 5)); // 한은금융망자금이체일련번호
		filler1 = VOUtils.toString(filler1$ = VOUtils.read(in, 5)); // FILLER
		filler4 = VOUtils.toString(filler4$ = VOUtils.read(in, 16)); // FILLER
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 9)); // FILLER
		hbkWireApplicationTime = VOUtils.toString(hbkWireApplicationTime$ = VOUtils.read(in, 6)); // 한은금융망신청시간
		hbkWirePaymentTime = VOUtils.toString(hbkWirePaymentTime$ = VOUtils.read(in, 6)); // 한은금융망결제시간
		hbkWirePaymentMethod = VOUtils.toString(hbkWirePaymentMethod$ = VOUtils.read(in, 1)); // 한은금융망결제방법
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 2)); // FILLER
		originalTransactionIDNumber = VOUtils.toString(originalTransactionIDNumber$ = VOUtils.read(in, 13)); // 원거래거래고유번호
		originalTransactionFundTransferSerialNumber = VOUtils.toString(originalTransactionFundTransferSerialNumber$ = VOUtils.read(in, 5)); // 원거래자금이체일련번호
		hbkWireInfoFiller = VOUtils.toString(hbkWireInfoFiller$ = VOUtils.read(in, 104)); // 한은금융망정보부FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", traxOccurredDate=").append(traxOccurredDate).append(System.lineSeparator()); // 거래발생일
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", handlingInstitutionRepCode=").append(handlingInstitutionRepCode).append(System.lineSeparator()); // 취급기관대표코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관대표코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취계좌번호
		sb.append(", transactionAmount=").append(transactionAmount).append(System.lineSeparator()); // 거래금액
		sb.append(", beneficiaryAreaCode=").append(beneficiaryAreaCode).append(System.lineSeparator()); // 수취지역코드
		sb.append(", withdrawer=").append(withdrawer).append(System.lineSeparator()); // 출금인
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인
		sb.append(", mediaType=").append(mediaType).append(System.lineSeparator()); // 매체구분
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금성격
		sb.append(", requestorInformation=").append(requestorInformation).append(System.lineSeparator()); // 의뢰인정보
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", reservedInformationField1=").append(reservedInformationField1).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", reservedInformationField2=").append(reservedInformationField2).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", realSenderName=").append(realSenderName).append(System.lineSeparator()); // 송금인실명
		sb.append(", suspectedFraudInfo=").append(suspectedFraudInfo).append(System.lineSeparator()); // 금융사기의심유의정보
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", hbkTransactionId=").append(hbkTransactionId).append(System.lineSeparator()); // 거액타행이체수취조회거래고유번호
		sb.append(", hbkWireResponseCode=").append(hbkWireResponseCode).append(System.lineSeparator()); // 한은금융망응답코드
		sb.append(", beneficiaryBankResponseCode=").append(beneficiaryBankResponseCode).append(System.lineSeparator()); // 개설기관응답코드
		sb.append(", hbkWireHandlingAccountInstitution=").append(hbkWireHandlingAccountInstitution).append(System.lineSeparator()); // 한은금융망취급기관계정개설처
		sb.append(", hbkWireOpenAccountInstitution=").append(hbkWireOpenAccountInstitution).append(System.lineSeparator()); // 한은금융망개설기관계정개설처
		sb.append(", hbkWireTransferSerialNumber=").append(hbkWireTransferSerialNumber).append(System.lineSeparator()); // 한은금융망자금이체일련번호
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", hbkWireApplicationTime=").append(hbkWireApplicationTime).append(System.lineSeparator()); // 한은금융망신청시간
		sb.append(", hbkWirePaymentTime=").append(hbkWirePaymentTime).append(System.lineSeparator()); // 한은금융망결제시간
		sb.append(", hbkWirePaymentMethod=").append(hbkWirePaymentMethod).append(System.lineSeparator()); // 한은금융망결제방법
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", originalTransactionIDNumber=").append(originalTransactionIDNumber).append(System.lineSeparator()); // 원거래거래고유번호
		sb.append(", originalTransactionFundTransferSerialNumber=").append(originalTransactionFundTransferSerialNumber).append(System.lineSeparator()); // 원거래자금이체일련번호
		sb.append(", hbkWireInfoFiller=").append(hbkWireInfoFiller).append(System.lineSeparator()); // 한은금융망정보부FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "ELB"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "450000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "1"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "traxOccurredDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "handlingInstitutionRepCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "transactionAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "beneficiaryAreaCode", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "withdrawer", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "mediaType", "fldLen", "2", "defltVal", "01"),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "requestorInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "reservedInformationField1", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "reservedInformationField2", "fldLen", "28", "defltVal", ""),
			Map.of("fld", "realSenderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "suspectedFraudInfo", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "133", "defltVal", ""),
			Map.of("fld", "hbkTransactionId", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "hbkWireResponseCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "beneficiaryBankResponseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "hbkWireHandlingAccountInstitution", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "hbkWireOpenAccountInstitution", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "hbkWireTransferSerialNumber", "fldLen", "5", "defltVal", "00000"),
			Map.of("fld", "filler1", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "filler4", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "9", "defltVal", ""),
			Map.of("fld", "hbkWireApplicationTime", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "hbkWirePaymentTime", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "hbkWirePaymentMethod", "fldLen", "1", "defltVal", "0"),
			Map.of("fld", "filler2", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "originalTransactionIDNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "originalTransactionFundTransferSerialNumber", "fldLen", "5", "defltVal", "00000"),
			Map.of("fld", "hbkWireInfoFiller", "fldLen", "104", "defltVal", "")
		);
	}

}
