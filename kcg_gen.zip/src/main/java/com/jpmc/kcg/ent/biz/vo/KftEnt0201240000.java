package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자어음 배서 통지 재요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID EBS
 * bnkCd 은행코드 
 * messageType 전문종별코드 0210
 * transactionCode 거래구분코드 230000
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * transactionType 거래구분 
 * eNoteNumber 전자어음번호 
 * eNoteType 어음종류 
 * eNoteIssueDate 전자어음발행일자 
 * eNoteIssuePlace 전자어음발행지 
 * eNoteAmount 전자어음금액 
 * eNoteMaturedDate 전자어음만기일자 
 * paymentBankAndBranchCode 지급은행및지점코드 1,2,3
 * issuerIndvCorpSort 발행인-개인법인구분 
 * issuerBusinessResidentRegistrationNumber 발행인-사업자(주민)등록번호 
 * issuerCorpName 발행인-법인명 
 * issuerNameRepresentativeName 발행인-성명(대표자명) 
 * issuerAddress 발행인-주소 
 * endorserCorpIndvSort 배서인법인개인구분 1,2,3
 * endorserBusinessResidentRegistrationNumber 배서인사업자(주민)등록번호 
 * endorserCorpName 배서인법인명 
 * endorserNameRepresentativeName 배서인성명(대표자명) 
 * endorserAddress 배서인주소 
 * endorserBankCode 배서인은행코드 
 * endorserDepositAccountNumber 배서인입금계좌번호 
 * endorseeCorpIndvSortCode 피배서인법인개인구분코드 Y,N,P
 * endorseeBusinessResidentRegistrationNumber 피배서인사업자(주민)등록번호 
 * endorseeCorpName 피배서인법인명 
 * endorseeNameRepresentativeName 피배서인성명(대표자명) 
 * endorseeAddress 피배서인주소 
 * endorseeDepositBankCode 피배서인입금은행코드 
 * endorseeDepositAccountNumber 피배서인입금계좌번호 
 * unsecuredEndorsementYn 무담보배서여부 
 * nonEndorsableEndorsementYn 배서금지배서여부 
 * originalSplitNumber 원분할번호 
 * originalEndorsementNumber 원배서번호 
 * splitNumber 분할번호 
 * endorsementNumber 배서번호 
 * endorsementAmount 배서금액 
 * notificationTarget 통지대상 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0201240000 kftEnt0201240000 = new KftEnt0201240000(); // 전자어음 배서 통지 재요청
 * kftEnt0201240000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0201240000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0201240000.setBnkCd("057"); // 은행코드
 * kftEnt0201240000.setMessageType("0200"); // 전문종별코드
 * kftEnt0201240000.setTransactionCode("240000"); // 거래구분코드
 * kftEnt0201240000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0201240000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0201240000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0201240000.setStatus("000"); // STATUS
 * kftEnt0201240000.setResponseCode1(""); // 응답코드1
 * kftEnt0201240000.setResponseCode2(""); // 응답코드2
 * kftEnt0201240000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0201240000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0201240000.setTransactionType(""); // 거래구분
 * kftEnt0201240000.setENoteNumber(""); // 전자어음번호
 * kftEnt0201240000.setENoteType(""); // 어음종류
 * kftEnt0201240000.setENoteIssueDate(""); // 전자어음발행일자
 * kftEnt0201240000.setENoteIssuePlace(""); // 전자어음발행지
 * kftEnt0201240000.setENoteAmount(0L); // 전자어음금액
 * kftEnt0201240000.setENoteMaturedDate(""); // 전자어음만기일자
 * kftEnt0201240000.setPaymentBankAndBranchCode(""); // 지급은행및지점코드
 * kftEnt0201240000.setIssuerIndvCorpSort(""); // 발행인-개인법인구분
 * kftEnt0201240000.setIssuerBusinessResidentRegistrationNumber(""); // 발행인-사업자(주민)등록번호
 * kftEnt0201240000.setIssuerCorpName(""); // 발행인-법인명
 * kftEnt0201240000.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEnt0201240000.setIssuerAddress(""); // 발행인-주소
 * kftEnt0201240000.setEndorserCorpIndvSort(""); // 배서인법인개인구분
 * kftEnt0201240000.setEndorserBusinessResidentRegistrationNumber(""); // 배서인사업자(주민)등록번호
 * kftEnt0201240000.setEndorserCorpName(""); // 배서인법인명
 * kftEnt0201240000.setEndorserNameRepresentativeName(""); // 배서인성명(대표자명)
 * kftEnt0201240000.setEndorserAddress(""); // 배서인주소
 * kftEnt0201240000.setEndorserBankCode(""); // 배서인은행코드
 * kftEnt0201240000.setEndorserDepositAccountNumber(""); // 배서인입금계좌번호
 * kftEnt0201240000.setEndorseeCorpIndvSortCode(""); // 피배서인법인개인구분코드
 * kftEnt0201240000.setEndorseeBusinessResidentRegistrationNumber(""); // 피배서인사업자(주민)등록번호
 * kftEnt0201240000.setEndorseeCorpName(""); // 피배서인법인명
 * kftEnt0201240000.setEndorseeNameRepresentativeName(""); // 피배서인성명(대표자명)
 * kftEnt0201240000.setEndorseeAddress(""); // 피배서인주소
 * kftEnt0201240000.setEndorseeDepositBankCode(""); // 피배서인입금은행코드
 * kftEnt0201240000.setEndorseeDepositAccountNumber(""); // 피배서인입금계좌번호
 * kftEnt0201240000.setUnsecuredEndorsementYn(""); // 무담보배서여부
 * kftEnt0201240000.setNonEndorsableEndorsementYn(""); // 배서금지배서여부
 * kftEnt0201240000.setOriginalSplitNumber(""); // 원분할번호
 * kftEnt0201240000.setOriginalEndorsementNumber(""); // 원배서번호
 * kftEnt0201240000.setSplitNumber(""); // 분할번호
 * kftEnt0201240000.setEndorsementNumber(""); // 배서번호
 * kftEnt0201240000.setEndorsementAmount(0L); // 배서금액
 * kftEnt0201240000.setNotificationTarget(""); // 통지대상
 * kftEnt0201240000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0201240000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0201240000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "240000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String transactionType; // 거래구분
	private String eNoteNumber; // 전자어음번호
	private String eNoteType; // 어음종류
	private String eNoteIssueDate; // 전자어음발행일자
	private String eNoteIssuePlace; // 전자어음발행지
	private long eNoteAmount; // 전자어음금액
	private String eNoteMaturedDate; // 전자어음만기일자
	private String paymentBankAndBranchCode; // 지급은행및지점코드
	private String issuerIndvCorpSort; // 발행인-개인법인구분
	private String issuerBusinessResidentRegistrationNumber; // 발행인-사업자(주민)등록번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String endorserCorpIndvSort; // 배서인법인개인구분
	private String endorserBusinessResidentRegistrationNumber; // 배서인사업자(주민)등록번호
	private String endorserCorpName; // 배서인법인명
	private String endorserNameRepresentativeName; // 배서인성명(대표자명)
	private String endorserAddress; // 배서인주소
	private String endorserBankCode; // 배서인은행코드
	private String endorserDepositAccountNumber; // 배서인입금계좌번호
	private String endorseeCorpIndvSortCode; // 피배서인법인개인구분코드
	private String endorseeBusinessResidentRegistrationNumber; // 피배서인사업자(주민)등록번호
	private String endorseeCorpName; // 피배서인법인명
	private String endorseeNameRepresentativeName; // 피배서인성명(대표자명)
	private String endorseeAddress; // 피배서인주소
	private String endorseeDepositBankCode; // 피배서인입금은행코드
	private String endorseeDepositAccountNumber; // 피배서인입금계좌번호
	private String unsecuredEndorsementYn; // 무담보배서여부
	private String nonEndorsableEndorsementYn; // 배서금지배서여부
	private String originalSplitNumber; // 원분할번호
	private String originalEndorsementNumber; // 원배서번호
	private String splitNumber; // 분할번호
	private String endorsementNumber; // 배서번호
	private long endorsementAmount; // 배서금액
	private String notificationTarget; // 통지대상
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionType$; // 거래구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerIndvCorpSort$; // 발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBusinessResidentRegistrationNumber$; // 발행인-사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpIndvSort$; // 배서인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBusinessResidentRegistrationNumber$; // 배서인사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpName$; // 배서인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserNameRepresentativeName$; // 배서인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserAddress$; // 배서인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBankCode$; // 배서인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserDepositAccountNumber$; // 배서인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeCorpIndvSortCode$; // 피배서인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeBusinessResidentRegistrationNumber$; // 피배서인사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeCorpName$; // 피배서인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeNameRepresentativeName$; // 피배서인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeAddress$; // 피배서인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeDepositBankCode$; // 피배서인입금은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeDepositAccountNumber$; // 피배서인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String unsecuredEndorsementYn$; // 무담보배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nonEndorsableEndorsementYn$; // 배서금지배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalSplitNumber$; // 원분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String originalEndorsementNumber$; // 원배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementNumber$; // 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementAmount$; // 배서금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationTarget$; // 통지대상
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteMaturedDate$)) { // 전자어음만기일자
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerIndvCorpSort$)) { // 발행인-개인법인구분
			return 21;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerBusinessResidentRegistrationNumber$)) { // 발행인-사업자(주민)등록번호
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserBusinessResidentRegistrationNumber$)) { // 배서인사업자(주민)등록번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserDepositAccountNumber$)) { // 배서인입금계좌번호
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(endorseeBusinessResidentRegistrationNumber$)) { // 피배서인사업자(주민)등록번호
			return 34;
		}
		if (VOUtils.isNotAlphanumericSpace(endorseeDepositAccountNumber$)) { // 피배서인입금계좌번호
			return 39;
		}
		if (VOUtils.isNotAlphanumericSpace(unsecuredEndorsementYn$)) { // 무담보배서여부
			return 40;
		}
		if (VOUtils.isNotAlphanumericSpace(nonEndorsableEndorsementYn$)) { // 배서금지배서여부
			return 41;
		}
		if (VOUtils.isNotAlphanumericSpace(notificationTarget$)) { // 통지대상
			return 47;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		transactionType$ = VOUtils.write(out, transactionType, 1); // 거래구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 지급은행및지점코드
		issuerIndvCorpSort$ = VOUtils.write(out, issuerIndvCorpSort, 1); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber$ = VOUtils.write(out, issuerBusinessResidentRegistrationNumber, 13); // 발행인-사업자(주민)등록번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		endorserCorpIndvSort$ = VOUtils.write(out, endorserCorpIndvSort, 1); // 배서인법인개인구분
		endorserBusinessResidentRegistrationNumber$ = VOUtils.write(out, endorserBusinessResidentRegistrationNumber, 13); // 배서인사업자(주민)등록번호
		endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // 배서인법인명
		endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // 배서인성명(대표자명)
		endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // 배서인주소
		endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // 배서인은행코드
		endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // 배서인입금계좌번호
		endorseeCorpIndvSortCode$ = VOUtils.write(out, endorseeCorpIndvSortCode, 1); // 피배서인법인개인구분코드
		endorseeBusinessResidentRegistrationNumber$ = VOUtils.write(out, endorseeBusinessResidentRegistrationNumber, 13); // 피배서인사업자(주민)등록번호
		endorseeCorpName$ = VOUtils.write(out, endorseeCorpName, 40, "EUC-KR"); // 피배서인법인명
		endorseeNameRepresentativeName$ = VOUtils.write(out, endorseeNameRepresentativeName, 20, "EUC-KR"); // 피배서인성명(대표자명)
		endorseeAddress$ = VOUtils.write(out, endorseeAddress, 60, "EUC-KR"); // 피배서인주소
		endorseeDepositBankCode$ = VOUtils.write(out, endorseeDepositBankCode, 3); // 피배서인입금은행코드
		endorseeDepositAccountNumber$ = VOUtils.write(out, endorseeDepositAccountNumber, 16); // 피배서인입금계좌번호
		unsecuredEndorsementYn$ = VOUtils.write(out, unsecuredEndorsementYn, 1); // 무담보배서여부
		nonEndorsableEndorsementYn$ = VOUtils.write(out, nonEndorsableEndorsementYn, 1); // 배서금지배서여부
		originalSplitNumber$ = VOUtils.write(out, originalSplitNumber, 2); // 원분할번호
		originalEndorsementNumber$ = VOUtils.write(out, originalEndorsementNumber, 2); // 원배서번호
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // 배서번호
		endorsementAmount$ = VOUtils.write(out, endorsementAmount, 15); // 배서금액
		notificationTarget$ = VOUtils.write(out, notificationTarget, 1); // 통지대상
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		transactionType = VOUtils.toString(transactionType$ = VOUtils.read(in, 1)); // 거래구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 지급은행및지점코드
		issuerIndvCorpSort = VOUtils.toString(issuerIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber = VOUtils.toString(issuerBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 발행인-사업자(주민)등록번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		endorserCorpIndvSort = VOUtils.toString(endorserCorpIndvSort$ = VOUtils.read(in, 1)); // 배서인법인개인구분
		endorserBusinessResidentRegistrationNumber = VOUtils.toString(endorserBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 배서인사업자(주민)등록번호
		endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 배서인법인명
		endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 배서인성명(대표자명)
		endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 배서인주소
		endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // 배서인은행코드
		endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // 배서인입금계좌번호
		endorseeCorpIndvSortCode = VOUtils.toString(endorseeCorpIndvSortCode$ = VOUtils.read(in, 1)); // 피배서인법인개인구분코드
		endorseeBusinessResidentRegistrationNumber = VOUtils.toString(endorseeBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 피배서인사업자(주민)등록번호
		endorseeCorpName = VOUtils.toString(endorseeCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 피배서인법인명
		endorseeNameRepresentativeName = VOUtils.toString(endorseeNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 피배서인성명(대표자명)
		endorseeAddress = VOUtils.toString(endorseeAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 피배서인주소
		endorseeDepositBankCode = VOUtils.toString(endorseeDepositBankCode$ = VOUtils.read(in, 3)); // 피배서인입금은행코드
		endorseeDepositAccountNumber = VOUtils.toString(endorseeDepositAccountNumber$ = VOUtils.read(in, 16)); // 피배서인입금계좌번호
		unsecuredEndorsementYn = VOUtils.toString(unsecuredEndorsementYn$ = VOUtils.read(in, 1)); // 무담보배서여부
		nonEndorsableEndorsementYn = VOUtils.toString(nonEndorsableEndorsementYn$ = VOUtils.read(in, 1)); // 배서금지배서여부
		originalSplitNumber = VOUtils.toString(originalSplitNumber$ = VOUtils.read(in, 2)); // 원분할번호
		originalEndorsementNumber = VOUtils.toString(originalEndorsementNumber$ = VOUtils.read(in, 2)); // 원배서번호
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // 배서번호
		endorsementAmount = VOUtils.toLong(endorsementAmount$ = VOUtils.read(in, 15)); // 배서금액
		notificationTarget = VOUtils.toString(notificationTarget$ = VOUtils.read(in, 1)); // 통지대상
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", transactionType=").append(transactionType).append(System.lineSeparator()); // 거래구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 지급은행및지점코드
		sb.append(", issuerIndvCorpSort=").append(issuerIndvCorpSort).append(System.lineSeparator()); // 발행인-개인법인구분
		sb.append(", issuerBusinessResidentRegistrationNumber=").append(issuerBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 발행인-사업자(주민)등록번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", endorserCorpIndvSort=").append(endorserCorpIndvSort).append(System.lineSeparator()); // 배서인법인개인구분
		sb.append(", endorserBusinessResidentRegistrationNumber=").append(endorserBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 배서인사업자(주민)등록번호
		sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // 배서인법인명
		sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // 배서인성명(대표자명)
		sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // 배서인주소
		sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // 배서인은행코드
		sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // 배서인입금계좌번호
		sb.append(", endorseeCorpIndvSortCode=").append(endorseeCorpIndvSortCode).append(System.lineSeparator()); // 피배서인법인개인구분코드
		sb.append(", endorseeBusinessResidentRegistrationNumber=").append(endorseeBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 피배서인사업자(주민)등록번호
		sb.append(", endorseeCorpName=").append(endorseeCorpName).append(System.lineSeparator()); // 피배서인법인명
		sb.append(", endorseeNameRepresentativeName=").append(endorseeNameRepresentativeName).append(System.lineSeparator()); // 피배서인성명(대표자명)
		sb.append(", endorseeAddress=").append(endorseeAddress).append(System.lineSeparator()); // 피배서인주소
		sb.append(", endorseeDepositBankCode=").append(endorseeDepositBankCode).append(System.lineSeparator()); // 피배서인입금은행코드
		sb.append(", endorseeDepositAccountNumber=").append(endorseeDepositAccountNumber).append(System.lineSeparator()); // 피배서인입금계좌번호
		sb.append(", unsecuredEndorsementYn=").append(unsecuredEndorsementYn).append(System.lineSeparator()); // 무담보배서여부
		sb.append(", nonEndorsableEndorsementYn=").append(nonEndorsableEndorsementYn).append(System.lineSeparator()); // 배서금지배서여부
		sb.append(", originalSplitNumber=").append(originalSplitNumber).append(System.lineSeparator()); // 원분할번호
		sb.append(", originalEndorsementNumber=").append(originalEndorsementNumber).append(System.lineSeparator()); // 원배서번호
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // 배서번호
		sb.append(", endorsementAmount=").append(endorsementAmount).append(System.lineSeparator()); // 배서금액
		sb.append(", notificationTarget=").append(notificationTarget).append(System.lineSeparator()); // 통지대상
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "240000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "transactionType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorseeCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorseeBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorseeCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorseeNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorseeAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorseeDepositBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorseeDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "unsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "nonEndorsableEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "originalSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "originalEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "notificationTarget", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
