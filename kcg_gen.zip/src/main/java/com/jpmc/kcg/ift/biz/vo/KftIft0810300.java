package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회선시험(TestCall)
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 전문의 처리결과를 정의해 주는 코드
 * messageSendTime 전문전송시간 중계센터 또는 각행센터에서의 전문전송시간
 * failureInstitutionCode 장애기관코드 장애가 발생된 기관 코드
 * reservedInformationField11 예비정보FIELD 중계센터 및 참가기관에서 임의 사용 가능한 FIELD
 * 
 * KftIft0810300 kftIft0810300 = new KftIft0810300(); // 회선시험(TestCall)
 * kftIft0810300.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftIft0810300.setSystemId("03"); // 시스템-ID
 * kftIft0810300.setInstitutionCode("057"); // 기관코드
 * kftIft0810300.setMessageType("0810"); // 전문종별구분코드
 * kftIft0810300.setMessageCode("300"); // 업무구분코드
 * kftIft0810300.setSendReceiveFlag("4"); // 송수신FLAG
 * kftIft0810300.setResponseCode(""); // 응답코드
 * kftIft0810300.setMessageSendTime(LocalDateTime.now()); // 전문전송시간
 * kftIft0810300.setFailureInstitutionCode("057"); // 장애기관코드
 * kftIft0810300.setReservedInformationField11(""); // 예비정보FIELD
 * }</pre>
 */
@Data
public class KftIft0810300 implements KftIftMngHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0810"; // 전문종별구분코드
	private String messageCode = "300"; // 업무구분코드
	private String sendReceiveFlag = "4"; // 송수신FLAG
	private String responseCode; // 응답코드
	private LocalDateTime messageSendTime; // 전문전송시간
	private String failureInstitutionCode = "057"; // 장애기관코드
	private String reservedInformationField11; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failureInstitutionCode$; // 장애기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(institutionCode$)) { // 기관코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 업무구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageSendTime$ = VOUtils.write(out, messageSendTime, 12, "yyMMddHHmmss"); // 전문전송시간
		failureInstitutionCode$ = VOUtils.write(out, failureInstitutionCode, 3); // 장애기관코드
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 10); // 예비정보FIELD
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 전문전송시간
		failureInstitutionCode = VOUtils.toString(failureInstitutionCode$ = VOUtils.read(in, 3)); // 장애기관코드
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 10)); // 예비정보FIELD
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", failureInstitutionCode=").append(failureInstitutionCode).append(System.lineSeparator()); // 장애기관코드
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0810"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "300"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "4"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "failureInstitutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "reservedInformationField11", "fldLen", "10", "defltVal", "")
		);
	}

}
