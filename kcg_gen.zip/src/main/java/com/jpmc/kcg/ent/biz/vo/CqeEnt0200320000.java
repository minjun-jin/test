package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 소지인 변경 통지
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * billStatus 어음상태 
 * eNoteNumber 어음내역전자어음번호 
 * eNoteType 어음내역어음종류 
 * eNoteIssueDate 어음내역전자어음발행일자 
 * eNoteIssuePlace 어음내역전자어음발행지 
 * eNoteAmount 어음내역전자어음금액 
 * eNoteMaturedDate 어음내역전자어음만기일자 
 * paymentBankAndBranchCode 어음내역지급은행및지점코드 
 * issuerInfoCorpIndvSortCode 발행인정보법인개인구분코드 
 * issuerInfoResidentBusinessNumber 발행인정보주민사업자번호 
 * issuerInfoCorpName 발행인정보법인명 
 * issuerInfoNameRepresentativeName 발행인정보성명(대표자명) 
 * issuerInfoAddress 발행인정보주소 
 * issuerInfoBankCode 발행인정보은행코드 
 * issuerInfoCurrentAccountNumber 발행인정보당좌계좌번호 
 * endorserCorpIndvSortCode 배서인정보법인개인구분코드 
 * endorserResidentBusinessNumber 배서인정보주민사업자번호 
 * endorserCorpName 배서인정보법인명 
 * endorserNameRepresentativeName 배서인정보성명(대표자명) 
 * endorserAddress 배서인정보주소 
 * endorserBankCode 배서인정보은행코드 
 * endorserDepositAccountNumber 배서인정보수취계좌번호 
 * endorserSplitNumber 배서인정보분할번호 
 * endorserEndorsementNumber 배서인정보배서번호 
 * oldRecipientSplitNumber 구소지인정보분할번호 
 * oldRecipientEndorsementNumber 구소지인정보배서번호 
 * oldRecipientSpliteNoteAmount 구소지인정보분할전자어음금액 
 * oldRecipientCorpIndvSortCode 구소지인정보법인개인구분코드 
 * oldRecipientResidentBusinessNumber 구소지인정보주민사업자번호 
 * oldRecipientCorpName 구소지인정보법인명 
 * oldRecipientNameRepresentativeName 구소지인정보성명(대표자명) 
 * oldRecipientAddress 구소지인정보주소 
 * oldRecipientDepositAccountNumber 구소지인정보입금계좌번호 
 * newRecipientCorpIndvSortCode 신소지인정보법인개인구분코드 
 * newRecipientResidentBusinessNumber 신소지인정보주민사업자번호 
 * newRecipientCorpName 신소지인정보법인명 
 * newRecipientNameRepresentativeName 신소지인정보성명(대표자명) 
 * newRecipientAddress 신소지인정보주소 
 * newRecipientDepositAccountNumber 신소지인정보입금계좌번호 
 * changeReason 변경사유 
 * changeRequestBankAndBranchCode 변경신청은행및지점코드 
 * changeRequestDate 변경요청일자 
 * notificationTarget 통지대상 
 * 
 * CqeEnt0200320000 cqeEnt0200320000 = new CqeEnt0200320000(); // 소지인 변경 통지
 * cqeEnt0200320000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200320000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200320000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200320000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200320000.setTransactionCode("320000"); // 거래구분코드
 * cqeEnt0200320000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200320000.setBnkCd("057"); // 은행코드
 * cqeEnt0200320000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200320000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200320000.setFiller(""); // FILLER
 * cqeEnt0200320000.setBillStatus(""); // 어음상태
 * cqeEnt0200320000.setENoteNumber(""); // 어음내역전자어음번호
 * cqeEnt0200320000.setENoteType(""); // 어음내역어음종류
 * cqeEnt0200320000.setENoteIssueDate(""); // 어음내역전자어음발행일자
 * cqeEnt0200320000.setENoteIssuePlace(""); // 어음내역전자어음발행지
 * cqeEnt0200320000.setENoteAmount(0L); // 어음내역전자어음금액
 * cqeEnt0200320000.setENoteMaturedDate(""); // 어음내역전자어음만기일자
 * cqeEnt0200320000.setPaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * cqeEnt0200320000.setIssuerInfoCorpIndvSortCode(""); // 발행인정보법인개인구분코드
 * cqeEnt0200320000.setIssuerInfoResidentBusinessNumber(""); // 발행인정보주민사업자번호
 * cqeEnt0200320000.setIssuerInfoCorpName(""); // 발행인정보법인명
 * cqeEnt0200320000.setIssuerInfoNameRepresentativeName(""); // 발행인정보성명(대표자명)
 * cqeEnt0200320000.setIssuerInfoAddress(""); // 발행인정보주소
 * cqeEnt0200320000.setIssuerInfoBankCode(""); // 발행인정보은행코드
 * cqeEnt0200320000.setIssuerInfoCurrentAccountNumber(""); // 발행인정보당좌계좌번호
 * cqeEnt0200320000.setEndorserCorpIndvSortCode(""); // 배서인정보법인개인구분코드
 * cqeEnt0200320000.setEndorserResidentBusinessNumber(""); // 배서인정보주민사업자번호
 * cqeEnt0200320000.setEndorserCorpName(""); // 배서인정보법인명
 * cqeEnt0200320000.setEndorserNameRepresentativeName(""); // 배서인정보성명(대표자명)
 * cqeEnt0200320000.setEndorserAddress(""); // 배서인정보주소
 * cqeEnt0200320000.setEndorserBankCode(""); // 배서인정보은행코드
 * cqeEnt0200320000.setEndorserDepositAccountNumber(""); // 배서인정보수취계좌번호
 * cqeEnt0200320000.setEndorserSplitNumber(""); // 배서인정보분할번호
 * cqeEnt0200320000.setEndorserEndorsementNumber(""); // 배서인정보배서번호
 * cqeEnt0200320000.setOldRecipientSplitNumber(""); // 구소지인정보분할번호
 * cqeEnt0200320000.setOldRecipientEndorsementNumber(""); // 구소지인정보배서번호
 * cqeEnt0200320000.setOldRecipientSpliteNoteAmount(0L); // 구소지인정보분할전자어음금액
 * cqeEnt0200320000.setOldRecipientCorpIndvSortCode(""); // 구소지인정보법인개인구분코드
 * cqeEnt0200320000.setOldRecipientResidentBusinessNumber(""); // 구소지인정보주민사업자번호
 * cqeEnt0200320000.setOldRecipientCorpName(""); // 구소지인정보법인명
 * cqeEnt0200320000.setOldRecipientNameRepresentativeName(""); // 구소지인정보성명(대표자명)
 * cqeEnt0200320000.setOldRecipientAddress(""); // 구소지인정보주소
 * cqeEnt0200320000.setOldRecipientDepositAccountNumber(""); // 구소지인정보입금계좌번호
 * cqeEnt0200320000.setNewRecipientCorpIndvSortCode(""); // 신소지인정보법인개인구분코드
 * cqeEnt0200320000.setNewRecipientResidentBusinessNumber(""); // 신소지인정보주민사업자번호
 * cqeEnt0200320000.setNewRecipientCorpName(""); // 신소지인정보법인명
 * cqeEnt0200320000.setNewRecipientNameRepresentativeName(""); // 신소지인정보성명(대표자명)
 * cqeEnt0200320000.setNewRecipientAddress(""); // 신소지인정보주소
 * cqeEnt0200320000.setNewRecipientDepositAccountNumber(""); // 신소지인정보입금계좌번호
 * cqeEnt0200320000.setChangeReason(""); // 변경사유
 * cqeEnt0200320000.setChangeRequestBankAndBranchCode(""); // 변경신청은행및지점코드
 * cqeEnt0200320000.setChangeRequestDate(""); // 변경요청일자
 * cqeEnt0200320000.setNotificationTarget(""); // 통지대상
 * }</pre>
 */
@Data
public class CqeEnt0200320000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "320000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String billStatus; // 어음상태
	private String eNoteNumber; // 어음내역전자어음번호
	private String eNoteType; // 어음내역어음종류
	private String eNoteIssueDate; // 어음내역전자어음발행일자
	private String eNoteIssuePlace; // 어음내역전자어음발행지
	private long eNoteAmount; // 어음내역전자어음금액
	private String eNoteMaturedDate; // 어음내역전자어음만기일자
	private String paymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private String issuerInfoCorpIndvSortCode; // 발행인정보법인개인구분코드
	private String issuerInfoResidentBusinessNumber; // 발행인정보주민사업자번호
	private String issuerInfoCorpName; // 발행인정보법인명
	private String issuerInfoNameRepresentativeName; // 발행인정보성명(대표자명)
	private String issuerInfoAddress; // 발행인정보주소
	private String issuerInfoBankCode; // 발행인정보은행코드
	private String issuerInfoCurrentAccountNumber; // 발행인정보당좌계좌번호
	private String endorserCorpIndvSortCode; // 배서인정보법인개인구분코드
	private String endorserResidentBusinessNumber; // 배서인정보주민사업자번호
	private String endorserCorpName; // 배서인정보법인명
	private String endorserNameRepresentativeName; // 배서인정보성명(대표자명)
	private String endorserAddress; // 배서인정보주소
	private String endorserBankCode; // 배서인정보은행코드
	private String endorserDepositAccountNumber; // 배서인정보수취계좌번호
	private String endorserSplitNumber; // 배서인정보분할번호
	private String endorserEndorsementNumber; // 배서인정보배서번호
	private String oldRecipientSplitNumber; // 구소지인정보분할번호
	private String oldRecipientEndorsementNumber; // 구소지인정보배서번호
	private long oldRecipientSpliteNoteAmount; // 구소지인정보분할전자어음금액
	private String oldRecipientCorpIndvSortCode; // 구소지인정보법인개인구분코드
	private String oldRecipientResidentBusinessNumber; // 구소지인정보주민사업자번호
	private String oldRecipientCorpName; // 구소지인정보법인명
	private String oldRecipientNameRepresentativeName; // 구소지인정보성명(대표자명)
	private String oldRecipientAddress; // 구소지인정보주소
	private String oldRecipientDepositAccountNumber; // 구소지인정보입금계좌번호
	private String newRecipientCorpIndvSortCode; // 신소지인정보법인개인구분코드
	private String newRecipientResidentBusinessNumber; // 신소지인정보주민사업자번호
	private String newRecipientCorpName; // 신소지인정보법인명
	private String newRecipientNameRepresentativeName; // 신소지인정보성명(대표자명)
	private String newRecipientAddress; // 신소지인정보주소
	private String newRecipientDepositAccountNumber; // 신소지인정보입금계좌번호
	private String changeReason; // 변경사유
	private String changeRequestBankAndBranchCode; // 변경신청은행및지점코드
	private String changeRequestDate; // 변경요청일자
	private String notificationTarget; // 통지대상
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String billStatus$; // 어음상태
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpIndvSortCode$; // 발행인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoResidentBusinessNumber$; // 발행인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpName$; // 발행인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoNameRepresentativeName$; // 발행인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoAddress$; // 발행인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoBankCode$; // 발행인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCurrentAccountNumber$; // 발행인정보당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpIndvSortCode$; // 배서인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserResidentBusinessNumber$; // 배서인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpName$; // 배서인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserNameRepresentativeName$; // 배서인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserAddress$; // 배서인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBankCode$; // 배서인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserDepositAccountNumber$; // 배서인정보수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserSplitNumber$; // 배서인정보분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserEndorsementNumber$; // 배서인정보배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientSplitNumber$; // 구소지인정보분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientEndorsementNumber$; // 구소지인정보배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientSpliteNoteAmount$; // 구소지인정보분할전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientCorpIndvSortCode$; // 구소지인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientResidentBusinessNumber$; // 구소지인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientCorpName$; // 구소지인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientNameRepresentativeName$; // 구소지인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientAddress$; // 구소지인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String oldRecipientDepositAccountNumber$; // 구소지인정보입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientCorpIndvSortCode$; // 신소지인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientResidentBusinessNumber$; // 신소지인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientCorpName$; // 신소지인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientNameRepresentativeName$; // 신소지인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientAddress$; // 신소지인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newRecipientDepositAccountNumber$; // 신소지인정보입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeReason$; // 변경사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeRequestBankAndBranchCode$; // 변경신청은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeRequestDate$; // 변경요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationTarget$; // 통지대상

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음내역전자어음번호
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoResidentBusinessNumber$)) { // 발행인정보주민사업자번호
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoCurrentAccountNumber$)) { // 발행인정보당좌계좌번호
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserResidentBusinessNumber$)) { // 배서인정보주민사업자번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserDepositAccountNumber$)) { // 배서인정보수취계좌번호
			return 31;
		}
		if (VOUtils.isNotAlphanumericSpace(oldRecipientResidentBusinessNumber$)) { // 구소지인정보주민사업자번호
			return 38;
		}
		if (VOUtils.isNotAlphanumericSpace(oldRecipientDepositAccountNumber$)) { // 구소지인정보입금계좌번호
			return 42;
		}
		if (VOUtils.isNotAlphanumericSpace(newRecipientResidentBusinessNumber$)) { // 신소지인정보주민사업자번호
			return 44;
		}
		if (VOUtils.isNotAlphanumericSpace(newRecipientDepositAccountNumber$)) { // 신소지인정보입금계좌번호
			return 48;
		}
		if (VOUtils.isNotAlphanumericSpace(notificationTarget$)) { // 통지대상
			return 52;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		billStatus$ = VOUtils.write(out, billStatus, 1); // 어음상태
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음내역전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음내역어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음내역전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음내역전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음내역전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode$ = VOUtils.write(out, issuerInfoCorpIndvSortCode, 1); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // 발행인정보주민사업자번호
		issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // 발행인정보법인명
		issuerInfoNameRepresentativeName$ = VOUtils.write(out, issuerInfoNameRepresentativeName, 20, "EUC-KR"); // 발행인정보성명(대표자명)
		issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // 발행인정보주소
		issuerInfoBankCode$ = VOUtils.write(out, issuerInfoBankCode, 3); // 발행인정보은행코드
		issuerInfoCurrentAccountNumber$ = VOUtils.write(out, issuerInfoCurrentAccountNumber, 16); // 발행인정보당좌계좌번호
		endorserCorpIndvSortCode$ = VOUtils.write(out, endorserCorpIndvSortCode, 1); // 배서인정보법인개인구분코드
		endorserResidentBusinessNumber$ = VOUtils.write(out, endorserResidentBusinessNumber, 13); // 배서인정보주민사업자번호
		endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // 배서인정보법인명
		endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // 배서인정보성명(대표자명)
		endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // 배서인정보주소
		endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // 배서인정보은행코드
		endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // 배서인정보수취계좌번호
		endorserSplitNumber$ = VOUtils.write(out, endorserSplitNumber, 2); // 배서인정보분할번호
		endorserEndorsementNumber$ = VOUtils.write(out, endorserEndorsementNumber, 2); // 배서인정보배서번호
		oldRecipientSplitNumber$ = VOUtils.write(out, oldRecipientSplitNumber, 2); // 구소지인정보분할번호
		oldRecipientEndorsementNumber$ = VOUtils.write(out, oldRecipientEndorsementNumber, 2); // 구소지인정보배서번호
		oldRecipientSpliteNoteAmount$ = VOUtils.write(out, oldRecipientSpliteNoteAmount, 15); // 구소지인정보분할전자어음금액
		oldRecipientCorpIndvSortCode$ = VOUtils.write(out, oldRecipientCorpIndvSortCode, 1); // 구소지인정보법인개인구분코드
		oldRecipientResidentBusinessNumber$ = VOUtils.write(out, oldRecipientResidentBusinessNumber, 13); // 구소지인정보주민사업자번호
		oldRecipientCorpName$ = VOUtils.write(out, oldRecipientCorpName, 40, "EUC-KR"); // 구소지인정보법인명
		oldRecipientNameRepresentativeName$ = VOUtils.write(out, oldRecipientNameRepresentativeName, 20, "EUC-KR"); // 구소지인정보성명(대표자명)
		oldRecipientAddress$ = VOUtils.write(out, oldRecipientAddress, 60, "EUC-KR"); // 구소지인정보주소
		oldRecipientDepositAccountNumber$ = VOUtils.write(out, oldRecipientDepositAccountNumber, 16); // 구소지인정보입금계좌번호
		newRecipientCorpIndvSortCode$ = VOUtils.write(out, newRecipientCorpIndvSortCode, 1); // 신소지인정보법인개인구분코드
		newRecipientResidentBusinessNumber$ = VOUtils.write(out, newRecipientResidentBusinessNumber, 13); // 신소지인정보주민사업자번호
		newRecipientCorpName$ = VOUtils.write(out, newRecipientCorpName, 40, "EUC-KR"); // 신소지인정보법인명
		newRecipientNameRepresentativeName$ = VOUtils.write(out, newRecipientNameRepresentativeName, 20, "EUC-KR"); // 신소지인정보성명(대표자명)
		newRecipientAddress$ = VOUtils.write(out, newRecipientAddress, 60, "EUC-KR"); // 신소지인정보주소
		newRecipientDepositAccountNumber$ = VOUtils.write(out, newRecipientDepositAccountNumber, 16); // 신소지인정보입금계좌번호
		changeReason$ = VOUtils.write(out, changeReason, 1); // 변경사유
		changeRequestBankAndBranchCode$ = VOUtils.write(out, changeRequestBankAndBranchCode, 7); // 변경신청은행및지점코드
		changeRequestDate$ = VOUtils.write(out, changeRequestDate, 8); // 변경요청일자
		notificationTarget$ = VOUtils.write(out, notificationTarget, 1); // 통지대상
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		billStatus = VOUtils.toString(billStatus$ = VOUtils.read(in, 1)); // 어음상태
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode = VOUtils.toString(issuerInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인정보주민사업자번호
		issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인정보법인명
		issuerInfoNameRepresentativeName = VOUtils.toString(issuerInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인정보성명(대표자명)
		issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인정보주소
		issuerInfoBankCode = VOUtils.toString(issuerInfoBankCode$ = VOUtils.read(in, 3)); // 발행인정보은행코드
		issuerInfoCurrentAccountNumber = VOUtils.toString(issuerInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인정보당좌계좌번호
		endorserCorpIndvSortCode = VOUtils.toString(endorserCorpIndvSortCode$ = VOUtils.read(in, 1)); // 배서인정보법인개인구분코드
		endorserResidentBusinessNumber = VOUtils.toString(endorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // 배서인정보주민사업자번호
		endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 배서인정보법인명
		endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 배서인정보성명(대표자명)
		endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 배서인정보주소
		endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // 배서인정보은행코드
		endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // 배서인정보수취계좌번호
		endorserSplitNumber = VOUtils.toString(endorserSplitNumber$ = VOUtils.read(in, 2)); // 배서인정보분할번호
		endorserEndorsementNumber = VOUtils.toString(endorserEndorsementNumber$ = VOUtils.read(in, 2)); // 배서인정보배서번호
		oldRecipientSplitNumber = VOUtils.toString(oldRecipientSplitNumber$ = VOUtils.read(in, 2)); // 구소지인정보분할번호
		oldRecipientEndorsementNumber = VOUtils.toString(oldRecipientEndorsementNumber$ = VOUtils.read(in, 2)); // 구소지인정보배서번호
		oldRecipientSpliteNoteAmount = VOUtils.toLong(oldRecipientSpliteNoteAmount$ = VOUtils.read(in, 15)); // 구소지인정보분할전자어음금액
		oldRecipientCorpIndvSortCode = VOUtils.toString(oldRecipientCorpIndvSortCode$ = VOUtils.read(in, 1)); // 구소지인정보법인개인구분코드
		oldRecipientResidentBusinessNumber = VOUtils.toString(oldRecipientResidentBusinessNumber$ = VOUtils.read(in, 13)); // 구소지인정보주민사업자번호
		oldRecipientCorpName = VOUtils.toString(oldRecipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 구소지인정보법인명
		oldRecipientNameRepresentativeName = VOUtils.toString(oldRecipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 구소지인정보성명(대표자명)
		oldRecipientAddress = VOUtils.toString(oldRecipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 구소지인정보주소
		oldRecipientDepositAccountNumber = VOUtils.toString(oldRecipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 구소지인정보입금계좌번호
		newRecipientCorpIndvSortCode = VOUtils.toString(newRecipientCorpIndvSortCode$ = VOUtils.read(in, 1)); // 신소지인정보법인개인구분코드
		newRecipientResidentBusinessNumber = VOUtils.toString(newRecipientResidentBusinessNumber$ = VOUtils.read(in, 13)); // 신소지인정보주민사업자번호
		newRecipientCorpName = VOUtils.toString(newRecipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 신소지인정보법인명
		newRecipientNameRepresentativeName = VOUtils.toString(newRecipientNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 신소지인정보성명(대표자명)
		newRecipientAddress = VOUtils.toString(newRecipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 신소지인정보주소
		newRecipientDepositAccountNumber = VOUtils.toString(newRecipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 신소지인정보입금계좌번호
		changeReason = VOUtils.toString(changeReason$ = VOUtils.read(in, 1)); // 변경사유
		changeRequestBankAndBranchCode = VOUtils.toString(changeRequestBankAndBranchCode$ = VOUtils.read(in, 7)); // 변경신청은행및지점코드
		changeRequestDate = VOUtils.toString(changeRequestDate$ = VOUtils.read(in, 8)); // 변경요청일자
		notificationTarget = VOUtils.toString(notificationTarget$ = VOUtils.read(in, 1)); // 통지대상
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", billStatus=").append(billStatus).append(System.lineSeparator()); // 어음상태
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", issuerInfoCorpIndvSortCode=").append(issuerInfoCorpIndvSortCode).append(System.lineSeparator()); // 발행인정보법인개인구분코드
		sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행인정보주민사업자번호
		sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // 발행인정보법인명
		sb.append(", issuerInfoNameRepresentativeName=").append(issuerInfoNameRepresentativeName).append(System.lineSeparator()); // 발행인정보성명(대표자명)
		sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // 발행인정보주소
		sb.append(", issuerInfoBankCode=").append(issuerInfoBankCode).append(System.lineSeparator()); // 발행인정보은행코드
		sb.append(", issuerInfoCurrentAccountNumber=").append(issuerInfoCurrentAccountNumber).append(System.lineSeparator()); // 발행인정보당좌계좌번호
		sb.append(", endorserCorpIndvSortCode=").append(endorserCorpIndvSortCode).append(System.lineSeparator()); // 배서인정보법인개인구분코드
		sb.append(", endorserResidentBusinessNumber=").append(endorserResidentBusinessNumber).append(System.lineSeparator()); // 배서인정보주민사업자번호
		sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // 배서인정보법인명
		sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // 배서인정보성명(대표자명)
		sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // 배서인정보주소
		sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // 배서인정보은행코드
		sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // 배서인정보수취계좌번호
		sb.append(", endorserSplitNumber=").append(endorserSplitNumber).append(System.lineSeparator()); // 배서인정보분할번호
		sb.append(", endorserEndorsementNumber=").append(endorserEndorsementNumber).append(System.lineSeparator()); // 배서인정보배서번호
		sb.append(", oldRecipientSplitNumber=").append(oldRecipientSplitNumber).append(System.lineSeparator()); // 구소지인정보분할번호
		sb.append(", oldRecipientEndorsementNumber=").append(oldRecipientEndorsementNumber).append(System.lineSeparator()); // 구소지인정보배서번호
		sb.append(", oldRecipientSpliteNoteAmount=").append(oldRecipientSpliteNoteAmount).append(System.lineSeparator()); // 구소지인정보분할전자어음금액
		sb.append(", oldRecipientCorpIndvSortCode=").append(oldRecipientCorpIndvSortCode).append(System.lineSeparator()); // 구소지인정보법인개인구분코드
		sb.append(", oldRecipientResidentBusinessNumber=").append(oldRecipientResidentBusinessNumber).append(System.lineSeparator()); // 구소지인정보주민사업자번호
		sb.append(", oldRecipientCorpName=").append(oldRecipientCorpName).append(System.lineSeparator()); // 구소지인정보법인명
		sb.append(", oldRecipientNameRepresentativeName=").append(oldRecipientNameRepresentativeName).append(System.lineSeparator()); // 구소지인정보성명(대표자명)
		sb.append(", oldRecipientAddress=").append(oldRecipientAddress).append(System.lineSeparator()); // 구소지인정보주소
		sb.append(", oldRecipientDepositAccountNumber=").append(oldRecipientDepositAccountNumber).append(System.lineSeparator()); // 구소지인정보입금계좌번호
		sb.append(", newRecipientCorpIndvSortCode=").append(newRecipientCorpIndvSortCode).append(System.lineSeparator()); // 신소지인정보법인개인구분코드
		sb.append(", newRecipientResidentBusinessNumber=").append(newRecipientResidentBusinessNumber).append(System.lineSeparator()); // 신소지인정보주민사업자번호
		sb.append(", newRecipientCorpName=").append(newRecipientCorpName).append(System.lineSeparator()); // 신소지인정보법인명
		sb.append(", newRecipientNameRepresentativeName=").append(newRecipientNameRepresentativeName).append(System.lineSeparator()); // 신소지인정보성명(대표자명)
		sb.append(", newRecipientAddress=").append(newRecipientAddress).append(System.lineSeparator()); // 신소지인정보주소
		sb.append(", newRecipientDepositAccountNumber=").append(newRecipientDepositAccountNumber).append(System.lineSeparator()); // 신소지인정보입금계좌번호
		sb.append(", changeReason=").append(changeReason).append(System.lineSeparator()); // 변경사유
		sb.append(", changeRequestBankAndBranchCode=").append(changeRequestBankAndBranchCode).append(System.lineSeparator()); // 변경신청은행및지점코드
		sb.append(", changeRequestDate=").append(changeRequestDate).append(System.lineSeparator()); // 변경요청일자
		sb.append(", notificationTarget=").append(notificationTarget).append(System.lineSeparator()); // 통지대상
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "320000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "billStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorserSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorserEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "oldRecipientSpliteNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "oldRecipientCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "oldRecipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "oldRecipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "oldRecipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "oldRecipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "oldRecipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "newRecipientCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "newRecipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "newRecipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "newRecipientNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "newRecipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "newRecipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "changeReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "changeRequestBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "changeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "notificationTarget", "fldLen", "1", "defltVal", "")
		);
	}

}
