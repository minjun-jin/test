package com.jpmc.kcg.web.rpr.service;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.hof.dao.HofTrLMapper;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.rpr.biz.enums.RprConst;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HofTrLWebDao;
import com.jpmc.kcg.web.rpr.dao.RprHofTrLDao;
import com.jpmc.kcg.web.rpr.dto.SelectRprHofTrDaoIn;
import com.jpmc.kcg.web.rpr.service.dto.CreateFundRequestApprovalIn;
import com.jpmc.kcg.web.rpr.service.dto.CreateFundRequestIn;
import com.jpmc.kcg.web.rpr.service.dto.CreateListFundRequestIn;
import com.jpmc.kcg.web.rpr.service.dto.CreateListFundRequestSubIn;
import com.jpmc.kcg.web.rpr.service.dto.GetFundRequestListIn;
import com.jpmc.kcg.web.rpr.service.dto.GetFundRequestListOut;
import com.jpmc.kcg.web.rpr.service.dto.GetFundRequestTargetOut;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundRequestTargetIn;
import com.jpmc.kcg.web.rpr.service.dto.GetListFundRequestTargetOut;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(OrderAnnotation.class)
class RprFundRequestSvcTest {

	@Mock
	private RprHofTrLDao rprHofTrLDao;
	@Mock
	private HofTrLWebDao hofTrLDao;
	@Mock
	private HofTrLMapper hofTrLMapper;
	@Mock
	private CommonApprovalSvc commonApprovalSvc;
	@Mock
	private BizCom bizCom;
	
    private static MockedStatic<WebApplicationContext> webApplicationContext;

	@InjectMocks
	private RprFundRequestSvc rprFundRequestSvc;

	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}
	
    @AfterAll
    static void tearDown() {
        if (webApplicationContext != null) {
            webApplicationContext.close();
        }
    }

	@Test
	@Order(1)
	public void testGetListFundRequestTarget_001() {

		GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
		input.setTrStrDt("2024-09-24");
		input.setTrEndDt("2024-09-24");

		SelectRprHofTrDaoIn daoIn = new SelectRprHofTrDaoIn();
		daoIn.setTrStrDt(input.getTrStrDt());
		daoIn.setTrEndDt(input.getTrEndDt());

		List<HofTrL> listInfoOut = new ArrayList<HofTrL>();

		HofTrL listInfo = new HofTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("02");

		listInfoOut.add(listInfo);

		when(rprHofTrLDao.selectListHofTrCnt(any(SelectRprHofTrDaoIn.class))).thenReturn(1);

		GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(input);

		// Then: 결과 값 검증
		assertNotNull(result);
		assertEquals(1, result.getTotCnt());

		System.out.println("성공 조회건수 === " + result.getTotCnt());

		// DAO 메서드가 호출되었는지 확인
		verify(rprHofTrLDao, times(1)).selectListHofTrCnt(any(SelectRprHofTrDaoIn.class));

	}

	@Test
	@Order(2)
	public void testGetListFundRequestTarget_002() {

		// Given
		GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("20240924");
		input.setTrEndDt("");

		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getListFundRequestTarget(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrEndDt === " + exception.getErrorCode());
	}

	@Test
	@Order(3)
	public void testGetListFundRequestTarget_003() {

		// Given
		GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();

		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("");
		input.setTrEndDt("20240924");

		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getListFundRequestTarget(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrStrDt === " + exception.getErrorCode());
	}

	@Test
	@Order(4)
	public void testGetListFundRequestTarget_004() {

		// Given
		GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();

		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("");
		input.setTrEndDt("");

		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getListFundRequestTarget(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrStrDt, TrEndDt === " + exception.getErrorCode());
	}

	@Test
	@Order(5)
	public void testGetFundRequestList_01() {

		GetFundRequestListIn input = new GetFundRequestListIn();
		input.setTrStrDt("2024-09-24");
		input.setTrEndDt("2024-09-24");

		SelectRprHofTrDaoIn daoIn = new SelectRprHofTrDaoIn();
		daoIn.setTrStrDt(input.getTrStrDt());
		daoIn.setTrEndDt(input.getTrEndDt());

		List<HofTrL> listInfoOut = new ArrayList<HofTrL>();

		HofTrL listInfo = new HofTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("01");

		listInfoOut.add(listInfo);

		when(rprHofTrLDao.selectFundRequestListCnt(any(SelectRprHofTrDaoIn.class))).thenReturn(1);

		GetFundRequestListOut result = rprFundRequestSvc.getFundRequestList(input);

		// Then: 결과 값 검증
		assertNotNull(result);
		assertEquals(1, result.getTotCnt());

		System.out.println("성공 조회건수 === " + result.getTotCnt());

		// DAO 메서드가 호출되었는지 확인
		verify(rprHofTrLDao, times(1)).selectFundRequestListCnt(any(SelectRprHofTrDaoIn.class));

	}

	@Test
	@Order(6)
	public void testGetFundRequestList_02() {

		// Given
		GetFundRequestListIn input = new GetFundRequestListIn();

		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("");
		input.setTrEndDt("2024-09-24");

		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getFundRequestList(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrStrDt === " + exception.getErrorCode());
	}

	@Test
	@Order(7)
	public void testGetFundRequestList_03() {

		// Given
		GetFundRequestListIn input = new GetFundRequestListIn();

		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("2024-09-24");
		input.setTrEndDt("");
		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getFundRequestList(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrEndDt === " + exception.getErrorCode());
	}

	@Test
	@Order(8)
	public void testGetFundRequestList_04() {

		// Given
		GetFundRequestListIn input = new GetFundRequestListIn();

		// 거래 시작일,종료일을 설정하지 않음
		input.setTrStrDt("");
		input.setTrEndDt("");

		// When
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.getFundRequestList(input);
		});

		// Then: BusinessException 예외가 발생해야 함
		assertTrue("MCMNI01003".contains(exception.getErrorCode()));
		System.out.println("에러 TrStrDt, TrEndDt === " + exception.getErrorCode());
	}

	//	@Test
	//	@Order(9)
	//	public void testCreateFundRequest_01() {
	//		
	//		CreateFundRequestIn in = new CreateFundRequestIn();
	//		in.setTrDt("20240910");
	//		in.setOutinDvsnCd("01");
	//		in.setTlgKndDvsnCd("0210");
	//		in.setTlgTrDvsnCd("400000");
	//		in.setTrUnqNo("0570000000005");
	//		in.setHofTlgTrceNo("00000005");
	//		in.setHostNo("90000120");
	//		
	//		HofTrL hofTrL = new HofTrL();
	//		hofTrL.setTrDt("20240910");
	//		hofTrL.setOutinDvsnCd("01");
	//		hofTrL.setTlgKndDvsnCd("0210");
	//		hofTrL.setTlgTrDvsnCd("400000");
	//		hofTrL.setTrUnqNo("0570000000005");
	//		hofTrL.setHofTlgTrceNo("00000005");
	//		hofTrL.setHostNo("90000120");
	//		
	//		when(hofTrLMapper.selectByPrimaryKey("20240910", "01", "0210", "400000", 
	//				"0570000000005", "00000005", "90000120")).thenReturn(hofTrL);
	//		
	//		//when
	//		rprFundRequestSvc.createFundRequest(in);
	//		
	//		// then
	//        verify(commonApprovalSvc, times(1)).requestApproval(any(), eq(null), any());
	//        
	//        System.out.println("========= insert value ::" +  in);
	//        System.out.println("========= result :: success" );
	//
	//	}

	@Test
	@Order(10)
	public void testCreateFundRequest_02() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing TrDt: " + exception.getErrorCode());
	}

	@Test
	@Order(11)
	public void testCreateFundRequest_03() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		//in.setOutinDvsnCd("01"); // 누락
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing OutinDvsnCd: " + exception.getErrorCode());
	}

	@Test
	@Order(12)
	public void testCreateFundRequest_04() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		//in.setTlgKndDvsnCd("0210"); // 누락
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing TlgKndDvsnCd: " + exception.getErrorCode());
	}

	@Test
	@Order(13)
	public void testCreateFundRequest_05() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		//in.setTlgTrDvsnCd("400000"); // 누락
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing TlgTrDvsnCd: " + exception.getErrorCode());
	}

	@Test
	@Order(14)
	public void testCreateFundRequest_06() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		//in.setTrUnqNo("0570000000005"); // 누락
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing TrUnqNo: " + exception.getErrorCode());
	}

	@Test
	@Order(15)
	public void testCreateFundRequest_07() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		//in.setHofTlgTrceNo("00000005"); // 누락
		in.setHostNo("90000120");

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing HofTlgTrceNo: " + exception.getErrorCode());
	}

	@Test
	@Order(16)
	public void testCreateFundRequest_08() {
		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		//in.setHostNo("90000120"); // 누락

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
		System.out.println("#@@# Missing HostNo: " + exception.getErrorCode());
	}

	@Test
	@Order(17)
	public void testCreateFundRequest_09() {

		CreateFundRequestIn in = new CreateFundRequestIn();
		in.setTrDt("20240910");
		in.setOutinDvsnCd("01");
		in.setTlgKndDvsnCd("0210");
		in.setTlgTrDvsnCd("400000");
		in.setTrUnqNo("0570000000005");
		in.setHofTlgTrceNo("00000005");
		in.setHostNo("90000120");

		when(hofTrLMapper.selectByPrimaryKey("20240910", "01", "0570000000005", "90000120", "00000005"))
				.thenReturn(null);

		//when
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());

		// then
		System.out.println("#@@# hofTrLNull: " + exception.getErrorCode());

	}

	@Test
	@Order(18)
	public void testPrivateGetCdNm_01() {

		String cd = "00";
		ComRespCdM out = new ComRespCdM();
		out.setRespCd("정상");
		when(bizCom.getRespCode(any(), any(), any())).thenReturn(out);

		ComRespCdM result = rprFundRequestSvc._getCdNm(cd);
		// Then: 결과 값 검증
		assertNotNull(result);
	}

	@Test
	@Order(19)
	public void testPrivateSetOutPut_01() {

		HofTrL listInfo = new HofTrL();
		listInfo.setHostCd("host");
		GetFundRequestTargetOut result = rprFundRequestSvc._setOutPutTarget(listInfo);
		// Then: 결과 값 검증
		assertNotNull(result);
	}

	@Test
	public void testCreateListFundRequest_02() {
		// Arrange
		CreateListFundRequestIn svcIn = new CreateListFundRequestIn();
		svcIn.setFundRequestSubIn(Collections.emptyList()); // Empty list

		//when
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createListFundRequest(svcIn);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());

	}
	
	@Test
	@Order(1)
	void getListFundRequestTarget_정상조회() {
	    // given
	    GetListFundRequestTargetIn in = new GetListFundRequestTargetIn();
	    in.setTrStrDt("20250101");
	    in.setTrEndDt("20250101");

	    when(rprHofTrLDao.selectListHofTrCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectListHofTr(any())).thenReturn(Collections.emptyList());

	    // when
	    GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(in);

	    // then
	    assertNotNull(result);
	    assertEquals(1, result.getTotCnt());
	    assertTrue(result.getListOut().isEmpty());

	    verify(rprHofTrLDao, times(1)).selectListHofTrCnt(any());
	    verify(rprHofTrLDao, times(1)).selectListHofTr(any());
	}
	
	@Test
	@Order(2)
	void getListFundRequestTarget_필수값누락() {
	    // given
	    GetListFundRequestTargetIn in = new GetListFundRequestTargetIn();
	    in.setTrStrDt(""); // 누락
	    in.setTrEndDt("");

	    // when & then
	    BusinessException exception = assertThrows(BusinessException.class, () -> {
	        rprFundRequestSvc.getListFundRequestTarget(in);
	    });

	    assertEquals("MCMNI01003", exception.getErrorCode());
	}
	
	@Test
	@Order(20)
	void createFundRequest_정상흐름() {
	    // given
	    CreateFundRequestIn in = new CreateFundRequestIn();
	    in.setTrDt("20240910");
	    in.setOutinDvsnCd("01");
	    in.setTlgKndDvsnCd("0210");
	    in.setTlgTrDvsnCd("400000");
	    in.setTrUnqNo("TRX123456");
	    in.setHofTlgTrceNo("00000001");
	    in.setHostNo("HOST001");

	    HofTrL hofTrL = new HofTrL();
	    hofTrL.setTrDt("20240910");
	    hofTrL.setOutinDvsnCd("01");
	    hofTrL.setTlgKndDvsnCd("0210");
	    hofTrL.setTlgTrDvsnCd("400000");
	    hofTrL.setTrUnqNo("TRX123456");
	    hofTrL.setHofTlgTrceNo("00000001");
	    hofTrL.setHostNo("HOST001");

	    when(hofTrLMapper.selectByPrimaryKey(any(), any(), any(), any(), any()))
	        .thenReturn(hofTrL);

	    // when & then
	    assertDoesNotThrow(() -> rprFundRequestSvc.createFundRequest(in));
	    verify(hofTrLMapper, times(1)).selectByPrimaryKey(any(), any(), any(), any(), any());
	    verify(commonApprovalSvc, times(1)).requestApproval(any(), any(), any());
	}

	@Test
	@Order(21)
	void createListFundRequest_정상흐름() {
	    // given
	    CreateListFundRequestSubIn subIn = new CreateListFundRequestSubIn();
	    subIn.setTrDt("20240910");
	    subIn.setOutinDvsnCd("01");
	    subIn.setTrUnqNo("TRX9999");
	    subIn.setHostNo("HOST002");
	    subIn.setHofTlgTrceNo("00000002");

	    CreateListFundRequestIn in = new CreateListFundRequestIn();
	    in.setFundRequestSubIn(List.of(subIn));

	    HofTrL hofTrL = new HofTrL();
	    hofTrL.setTrDt("20240910");
	    hofTrL.setOutinDvsnCd("01");
	    hofTrL.setTrUnqNo("TRX9999");
	    hofTrL.setHostNo("HOST002");
	    hofTrL.setHofTlgTrceNo("00000002");

	    when(hofTrLMapper.selectByPrimaryKey(any(), any(), any(), any(), any()))
	        .thenReturn(hofTrL);

	    // when & then
	    assertDoesNotThrow(() -> rprFundRequestSvc.createListFundRequest(in));
	    verify(hofTrLMapper, times(1)).selectByPrimaryKey(any(), any(), any(), any(), any());
	    verify(commonApprovalSvc, times(1)).requestApproval(any(), any(), any());
	}
	
	@Test
	@Order(21)
	void createListFundRequest_원거래없음() {
	    // given
	    CreateListFundRequestSubIn subIn = new CreateListFundRequestSubIn();
	    subIn.setTrDt("20240910");
	    subIn.setOutinDvsnCd("01");
	    subIn.setTrUnqNo("TRX9999");
	    subIn.setHostNo("HOST002");
	    subIn.setHofTlgTrceNo("00000002");
	
	    CreateListFundRequestIn in = new CreateListFundRequestIn();
	    in.setFundRequestSubIn(List.of(subIn));
	
	    HofTrL hofTrL = new HofTrL();
	    hofTrL.setTrDt("20240910");
	    hofTrL.setOutinDvsnCd("01");
	    hofTrL.setTrUnqNo("TRX9999");
	    hofTrL.setHostNo("HOST002");
	    hofTrL.setHofTlgTrceNo("00000002");
	
	    when(hofTrLMapper.selectByPrimaryKey(any(), any(), any(), any(), any()))
	        .thenReturn(null);
	
		//when
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			rprFundRequestSvc.createListFundRequest(in);
		});
		assertEquals("MCMNE01006", exception.getErrorCode());
	}

	@Test
	@Order(23)
	void setAfterDto_FromCreateFundRequestIn_검증() {
	    // given
	    CreateFundRequestIn svcIn = new CreateFundRequestIn();
	    svcIn.setRqstDt("20240910");

	    HofTrL hofTrL = new HofTrL();
	    hofTrL.setTrDt("20240910");
	    hofTrL.setOutinDvsnCd("01");
	    hofTrL.setTlgKndDvsnCd("0210");
	    hofTrL.setTlgTrDvsnCd("400000");
	    hofTrL.setTrUnqNo("TRX123456");
	    hofTrL.setHofTlgTrceNo("00000001");
	    hofTrL.setHostNo("HOST001");

	    // when
	    CreateFundRequestApprovalIn result = rprFundRequestSvc._setAfterDto(svcIn, "staff01", hofTrL);

	    // then
	    assertEquals("20240910", result.getTrDt());
	    assertEquals("01", result.getOutinDvsnCd());
	    assertEquals("TRX123456", result.getOrgnTrUnqNo());
	}
	
	@Test
	@Order(24)
	void setAfterDto_FromCreateListFundRequestSubIn_검증() {
	    // given
	    CreateListFundRequestSubIn svcIn = new CreateListFundRequestSubIn();
	    svcIn.setRqstDt("20240910");

	    HofTrL hofTrL = new HofTrL();
	    hofTrL.setTrDt("20240910");
	    hofTrL.setOutinDvsnCd("01");
	    hofTrL.setTlgKndDvsnCd("0210");
	    hofTrL.setTlgTrDvsnCd("400000");
	    hofTrL.setTrUnqNo("TRX123456");
	    hofTrL.setHofTlgTrceNo("00000001");
	    hofTrL.setHostNo("HOST001");

	    // when
	    CreateFundRequestApprovalIn result = rprFundRequestSvc._setAfterDto(svcIn, "staff01", hofTrL);

	    // then
	    assertEquals("20240910", result.getTrDt());
	    assertEquals("01", result.getOutinDvsnCd());
	    assertEquals("TRX123456", result.getOrgnTrUnqNo());
	}
	
	@Test
	@Order(25)
	void setOutPut_필드매핑확인() {
	    GetFundRequestTargetOut listInfo = new GetFundRequestTargetOut();
	    listInfo.setTrDt("20240401");
	    listInfo.setTrUnqNo("TR123");
	    listInfo.setTlgKndDvsnCd("0210");
	    listInfo.setTlgTrDvsnCd("400000");

	    GetFundRequestTargetOut result = rprFundRequestSvc._setOutPut(listInfo);

	    assertEquals("TR123", result.getTrUnqNo());
	    assertEquals("0210", result.getTlgKndDvsnCd());
	    assertEquals("400000", result.getTlgTrDvsnCd());
	    assertEquals("0210400000", result.getTlgKndTrDvsnCd());
	}
	
	@Test
	@Order(26)
	void getFundRequestList_rprReqTrYn_Y_분기() {
	    GetFundRequestListIn input = new GetFundRequestListIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240102");
	    input.setRprReqTrYn("Y");

	    when(rprHofTrLDao.selectFundRequestListCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectFundRequestList(any())).thenReturn(Collections.emptyList());

	    GetFundRequestListOut result = rprFundRequestSvc.getFundRequestList(input);

	    assertEquals(1, result.getTotCnt());
	    verify(rprHofTrLDao, times(1)).selectFundRequestListCnt(any());
	}
	
	@Test
	@Order(27)
	void getFundRequestList_rprReqTrYn_null_분기() {
	    GetFundRequestListIn input = new GetFundRequestListIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240102");
	    input.setRprReqTrYn(null); // 분기 회피

	    when(rprHofTrLDao.selectFundRequestListCnt(any())).thenReturn(0);
	    when(rprHofTrLDao.selectFundRequestList(any())).thenReturn(Collections.emptyList());

	    GetFundRequestListOut result = rprFundRequestSvc.getFundRequestList(input);

	    assertEquals(0, result.getTotCnt());
	}
	
	@Test
	@Order(27)
	void getFundRequestList_rprReqTrYn_null_분기2() {
	    GetFundRequestListIn input = new GetFundRequestListIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240102");
	    input.setRprReqTrYn("N"); // 분기 회피

	    when(rprHofTrLDao.selectFundRequestListCnt(any())).thenReturn(0);
	    when(rprHofTrLDao.selectFundRequestList(any())).thenReturn(Collections.emptyList());

	    GetFundRequestListOut result = rprFundRequestSvc.getFundRequestList(input);

	    assertEquals(0, result.getTotCnt());
	}

	@Test
	@Order(28)
	void getListFundRequestTarget_respCd_null_분기() {
	    GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240101");

	    HofTrL dummy = new HofTrL();
	    dummy.setTrDt("20240101");
	    dummy.setRespCd(null); // 분기 조건

	    when(rprHofTrLDao.selectListHofTrCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectListHofTr(any())).thenReturn(List.of(dummy));

	    GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(input);

	    assertEquals(1, result.getTotCnt());
	    assertEquals(1, result.getListOut().size());
	}

	@Test
	@Order(29)
	void getListFundRequestTarget_respCd_정상값() {
	    GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240101");

	    HofTrL dummy = new HofTrL();
	    dummy.setTrDt("20240101");
	    dummy.setRespCd("00");

	    ComRespCdM resp = new ComRespCdM();
	    resp.setRespCdNm("정상응답");

	    when(rprHofTrLDao.selectListHofTrCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectListHofTr(any())).thenReturn(List.of(dummy));
	    when(bizCom.getRespCode(any(), any(), any())).thenReturn(resp);

	    GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(input);

	    assertEquals("정상응답", result.getListOut().get(0).getRespMsg());
	}

	@Test
	@Order(29)
	void getListFundRequestTarget_respCd_정상값_EN() {
	    GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240101");
	
	    HofTrL dummy = new HofTrL();
	    dummy.setTrDt("20240101");
	    dummy.setRespCd("00");
	
	    ComRespCdM resp = new ComRespCdM();
	    resp.setRespCdNm("정상응답");
	
	    when(rprHofTrLDao.selectListHofTrCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectListHofTr(any())).thenReturn(List.of(dummy));
	    when(bizCom.getRespCode(any(), any(), any())).thenReturn(resp);
	
	    GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(input);
	
	    assertEquals("정상응답", result.getListOut().get(0).getRespMsg());
	}
	
	@Test
	@Order(30)
	void getListFundRequestTarget_respCd_영문응답분기_커버() {
	    // Given
	    GetListFundRequestTargetIn input = new GetListFundRequestTargetIn();
	    input.setTrStrDt("20240101");
	    input.setTrEndDt("20240101");

	    HofTrL dummy = new HofTrL();
	    dummy.setTrDt("20240101");
	    dummy.setRespCd("00");

	    ComRespCdM resp = new ComRespCdM();
	    resp.setRespCdEngNm("SuccessEng");
	    resp.setRespCdNm("정상"); // fallback 용

	    when(rprHofTrLDao.selectListHofTrCnt(any())).thenReturn(1);
	    when(rprHofTrLDao.selectListHofTr(any())).thenReturn(List.of(dummy));
	    when(bizCom.getRespCode(any(), any(), any())).thenReturn(resp);

	    // When
	    GetListFundRequestTargetOut result = rprFundRequestSvc.getListFundRequestTarget(input);

	    // Then
	    assertEquals("SuccessEng", result.getListOut().get(0).getRespMsg());
	    System.out.println(">>> 영문 메시지 정상 분기 :: " + result.getListOut().get(0).getRespMsg());
	}

	@Test
	@Order(5)
	public void testGetFundRequestList_EN() {
	
		GetFundRequestListIn input = new GetFundRequestListIn();
		input.setTrStrDt("2024-09-24");
		input.setTrEndDt("2024-09-24");
		input.setRprReqTrYn(RprConst.Y);
	
		SelectRprHofTrDaoIn daoIn = new SelectRprHofTrDaoIn();
		daoIn.setTrStrDt(input.getTrStrDt());
		daoIn.setTrEndDt(input.getTrEndDt());
	
		List<HofTrL> listInfoOut = new ArrayList<HofTrL>();
	
		HofTrL listInfo = new HofTrL();
		listInfo.setTrDt("20240924");
		listInfo.setOutinDvsnCd("01");
	
		listInfoOut.add(listInfo);
	
		when(rprHofTrLDao.selectFundRequestListCnt(any(SelectRprHofTrDaoIn.class))).thenReturn(1);
	
		GetFundRequestListOut result = rprFundRequestSvc.getFundRequestList(input);
	
		// Then: 결과 값 검증
		assertNotNull(result);
		assertEquals(1, result.getTotCnt());
	
		System.out.println("성공 조회건수 === " + result.getTotCnt());
	
		// DAO 메서드가 호출되었는지 확인
		verify(rprHofTrLDao, times(1)).selectFundRequestListCnt(any(SelectRprHofTrDaoIn.class));
	
	}


}
