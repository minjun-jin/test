package com.jpmc.kcg.rpr.biz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.core.convert.ConversionService;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.BizDate;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.SvcHourStsCdEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.hof.dao.HofTrLDao;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTransactionDaoIn;
import com.jpmc.kcg.ift.dao.IftTrLDao;
import com.jpmc.kcg.ift.dto.IftTrL;
import com.jpmc.kcg.rpr.biz.enums.RprConst;
import com.jpmc.kcg.rpr.biz.enums.RprRespCdEnum;
import com.jpmc.kcg.rpr.biz.vo.CqeRpr0200400000;
import com.jpmc.kcg.rpr.biz.vo.KftRpr0200400000;
import com.jpmc.kcg.rpr.dto.InsertRprTransactionIn;
import com.jpmc.kcg.rpr.dto.RprTrL;

@ExtendWith(MockitoExtension.class)
class RprFundRequestRecallOutReqIntfTest {
	
    @InjectMocks
    private RprFundRequestRecallOutReqIntf service;
	
    @Mock
    private FrwTemplate frwTemplate;
    
    @Mock
	private BizDate bizDate;

    @Mock
    private RprCom rprCom;

    @Mock
    private ConversionService conversionService;
    
    @Mock
	private ReleaseValidation releaseValidation;
    
    @Mock
	private HofTrLDao hofTrLDao;
    
    @Mock
    private IftTrLDao iftTrLDao;
    
    @Mock
    private  CqeRpr0200400000 in;
    
    @Mock
    private BizCom bizCom;
    
    @Mock
    private FrwContext frwContext;
    
    @Test
    @Order(1)
    void testControl_01() {
    	
    	when(in.validate()).thenReturn(1);
    	in.setResponseCode(StringUtils.leftPad("1", 3, ComConst.CHAR_0));
    	
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals("001", exception.getRespCd());
    }
    
    @Test
    @Order(2)
    void testControl_02() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_1);
        when(bizDate.isWeekdayBizDay()).thenReturn(false);
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_312.getCode(), exception.getRespCd());
    }
    
    @Test
    @Order(3)
    void testControl_03_serviceHourBefore() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_1);
        when(bizDate.isWeekdayBizDay()).thenReturn(true);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode());
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_142.getCode(), exception.getRespCd());
    }
    
    @Test
    @Order(4)
    void testControl_04_serviceHourAfter() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_1);
        when(bizDate.isWeekdayBizDay()).thenReturn(true);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode());
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_143.getCode(), exception.getRespCd());
    }
    
    @Test
    @Order(3)
    void testControl_05_serviceHourBefore() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_3);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode());
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_142.getCode(), exception.getRespCd());
    }
    
    @Test
    @Order(4)
    void testControl_06_serviceHourAfter() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_3);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode());
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service.control(in)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_143.getCode(), exception.getRespCd());
    }
    
    @Test
    @Order(4)
    void testControl_07_else() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_3);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR.getCode());
        // when
        service.control(in);
    }
    
    @Test
    @Order(4)
    void testControl_08_else() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_1);
        when(bizDate.isWeekdayBizDay()).thenReturn(true);
        when(releaseValidation.getReleaseServiceHour(anyString(), any(LocalDateTime.class)))
                .thenReturn(SvcHourStsCdEnum.SERVICE_HOUR.getCode());
        // when
        service.control(in);
    }
    
    @Test
    @Order(4)
    void testControl_09_else() {
        when(in.validate()).thenReturn(0);
        when(in.getWireType()).thenReturn(ComConst.CHAR_2);
        // when
        service.control(in);
    }
    
    
    
    @Test
    void testProcess_Success() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.Y);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(10000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }
    
    @Test
    void testProcess_Success_02() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.N);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(20000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }    
    
    @Test
    void testProcess_Success_03() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.Y);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(20000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }    
    
    @Test
    void testProcess_Success_04() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.N);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(10000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }        
    
    @Test
	void testProcess_Success_05() {
	    // given
	    CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
	    input.setWireType(ComConst.CHAR_1);
	    input.setReturnYn(RprConst.Y);
	    RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
	    KftRpr0200400000 mockKftIn = new KftRpr0200400000();
	    mockKftIn.setRequestReturnTraxAmount(10000L);
	    
	    IftTrL iftTrL = new IftTrL();
		iftTrL.setTrUnqNo("1234");
		
		
	    when(iftTrLDao.selectIftTransaction(any())).thenReturn(iftTrL);
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
	    when(iftTrLDao.selectIftTransaction(any())).thenReturn(iftTrL);
	    when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
	    
	    // when
	    service.process(input);
	
	    // then
	    verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
	    verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
	}

	@Test
    void testProcess_Success_06() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.N);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(1000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }        
    
	@Test
    void testProcess_Success_07() {
        // given
        CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
        input.setWireType(ComConst.CHAR_3);
        input.setReturnYn(RprConst.N);
        RprTrL mockTransaction = mockTransactionData(); // 원거래 존재 데이터
        KftRpr0200400000 mockKftIn = new KftRpr0200400000();
        mockKftIn.setRequestReturnTraxAmount(200000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(mockTransaction);
        
		Map<String, String> tlgHdr = new HashMap<String, String>();
        String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
        when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
        
        // when
        service.process(input);

        // then
        verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
        verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
    }        
    
    @Test
    void testProcess_ThrowsException_WhenLessThanOneDay() {
        // given
        CqeRpr0200400000 input = new CqeRpr0200400000();
        input.setOriginalDate(LocalDate.now()); // 오늘 날짜 설정

        // when & then
        assertThrows(InternalResponseException.class, () -> service.process(input));
    }
    
    @Test
    void testCheckRequestTr_01() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(null);
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service._checkRequestTr(input)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_312.getCode(), exception.getRespCd());

    }
    
    @Test
    void testCheckRequestTr_02() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        
        RprTrL rprTrL = mockTransactionData();
        when(rprCom.selectRPRTransaction(any())).thenReturn(rprTrL);
        // when
        service._checkRequestTr(input);

    }    
    
    @Test
    void testCheckRequestTr_03() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
        when(hofTrLDao.selectHofTransaction(any())).thenReturn(hofTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(null);
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service._checkRequestTr(input)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_312.getCode(), exception.getRespCd());

    }      
    
    @Test
    void testCheckRequestTr_IFT_01() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        input.setWireType(ComConst.CHAR_1);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		IftTrL iftTrL = new IftTrL();
		iftTrL.setTrUnqNo("1234");
        when(iftTrLDao.selectIftTransaction(any())).thenReturn(iftTrL);
        
        RprTrL rprTrL = mockTransactionData();
        when(rprCom.selectRPRTransaction(any())).thenReturn(rprTrL);
        // when
        service._checkRequestTr(input);

    }    
    
    @Test
    void testCheckRequestTr_IFT_02() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        input.setWireType(ComConst.CHAR_1);
        
        when(iftTrLDao.selectIftTransaction(any())).thenReturn(null);
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service._checkRequestTr(input)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_312.getCode(), exception.getRespCd());

    }      
    
    @Test
    void testCheckRequestTr_IFT_03() {
        // given
        CqeRpr0200400000 input = mockValidInput();
        input.setWireType(ComConst.CHAR_1);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
        
		IftTrL iftTrL = new IftTrL();
		iftTrL.setTrUnqNo("1234");
        when(iftTrLDao.selectIftTransaction(any())).thenReturn(iftTrL);
        when(rprCom.selectRPRTransaction(any())).thenReturn(null);
        
        InternalResponseException exception = assertThrows(
                InternalResponseException.class, () -> service._checkRequestTr(input)
        );
        
        assertEquals(RprRespCdEnum.RESP_CD_312.getCode(), exception.getRespCd());

    }  
    
    @Test
    void testCheckRequestTr_setInsertRprTrL() {
        // given
    	InsertRprTransactionIn insertIn = new InsertRprTransactionIn();
    	CqeRpr0200400000 cqe = mockValidInput();
    	KftRpr0200400000 kftIn = new KftRpr0200400000();
    	String trcId = "1234";
    	String msgTrcNumber = "1234";
    	service._setInsertRprTrL(insertIn, cqe, kftIn, trcId, msgTrcNumber);       

    }  
    
    @Test
    void testCheckRequestTr_setInsertRprTrL2() {
        // given
    	InsertRprTransactionIn insertIn = new InsertRprTransactionIn();
    	CqeRpr0200400000 cqe = mockValidInput();
    	KftRpr0200400000 kftIn = new KftRpr0200400000();
    	kftIn.setMessageSendTime(LocalTime.now());
    	String trcId = "1234";
    	String msgTrcNumber = "1234";
    	service._setInsertRprTrL(insertIn, cqe, kftIn, trcId, msgTrcNumber);       

    }      

    @Test
    public void testHandleError_internalException_01() {
        // Given
    	InternalResponseException internalException = new InternalResponseException("001");

    	CqeRpr0200400000 input = mockValidInput();
        input.setMsgType("KCG");
        input.setWireType(ComConst.CHAR_3);
        
        when(bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKCG01.toString())).thenReturn("0000000001");
        when(bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKFT01.toString())).thenReturn("00000001");
        // When
        service.handleError(input, internalException);
    }
    
    @Test
    public void testHandleError_internalException_02() {
        // Given
    	InternalResponseException internalException = new InternalResponseException("001");

    	CqeRpr0200400000 input = mockValidInput();
        input.setMsgType("KCG");
        input.setWireType(ComConst.CHAR_1);
        
        when(bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKCG01.toString())).thenReturn("0000000001");
        when(bizCom.getNumbering(BizDvsnCdEnum.RPR.toString(), NumberingEnum.RPRKFT01.toString())).thenReturn("00000001");
        // When
        service.handleError(input, internalException);
    }
    
    @Test
    public void testHandleError_internalException_03() {
        // Given
    	InternalResponseException internalException = new InternalResponseException("001");

    	CqeRpr0200400000 input = mockValidInput();
        input.setMsgType("CQE");
        
        // When
        service.handleError(input, internalException);
    }

    @Test
    public void testHandleError_internalException_04() {
        // Given
    	InternalResponseException internalException = new InternalResponseException("312");

    	CqeRpr0200400000 input = mockValidInput();
        input.setMsgType("CQE");
        
        // When
        service.handleError(input, internalException);
    }
    
    @Test
    public void testHandleError_internalException_05() {
        // Given
    	BusinessException businessException = new BusinessException("312");

    	CqeRpr0200400000 input = mockValidInput();
        input.setMsgType("CQE");
        
        // When
        service.handleError(input, businessException);
    }
    
	private RprTrL mockTransactionData() {
	    RprTrL transaction = new RprTrL();
	    transaction.setOrgnTrDvsnCd("OTD001");
	    transaction.setOrgnTrUnqNo("OTU001");
	    transaction.setOrgnRcvAcctNo("1234567890");
	    transaction.setRqstDt(LocalDate.now().minusDays(1).toString()); 
	    transaction.setRqstTrUnqNo("RQ123");
	    transaction.setRtnRsnCd("RC02");
	    transaction.setRtnRsn("반환사유");
	    transaction.setOrgnTrAmt(new BigDecimal("10000")); 
	    return transaction;
	}

	private CqeRpr0200400000 mockValidInput() {
	    CqeRpr0200400000 input = new CqeRpr0200400000();
	    input.setOriginalDate(LocalDate.now().minusDays(2)); // 유효한 과거 날짜 설정
	    input.setOnlineRequestYn("Y");
	    input.setReturnYn("N");
	    input.setReasonCode("RC01");
	    input.setReason("반환거절 사유");
	    input.setAmount(10000L);  // long 타입으로 변경
	    input.setWireType("3"); // HOF
	    input.setMsgType("CQE");
	    input.setMessageCode("300000");
	    input.setMessageTransmissionDate(LocalDate.now());
	    input.setOriginalMsgNo("123456");
	    input.setTransactionIdNumber("987654");
	    return input;
	}

	@Test
	void testProcess_Success_N_01() {
	    // given
	    CqeRpr0200400000 input = mockValidInput(); // 유효한 입력 데이터 생성
	    input.setOnlineRequestYn(RprConst.N);
	    input.setWireType(ComConst.CHAR_3);
	    input.setReturnYn(RprConst.N);
	    KftRpr0200400000 mockKftIn = new KftRpr0200400000();
	    mockKftIn.setRequestReturnTraxAmount(20000L);
		SelectHofTransactionDaoIn hofDaoIn = new SelectHofTransactionDaoIn();
		hofDaoIn.setOutinDvsnCd(RprConst.OUTIN_DVSN_CD_02);
		hofDaoIn.setTrDt(input.getOriginalDate().format(DateTimeFormatter.BASIC_ISO_DATE));
		hofDaoIn.setTrUnqNo(input.getTransactionIdNumber());
		hofDaoIn.setHostNo(input.getOriginalMsgNo());
	    
		HofTrL hofTrL = new HofTrL();
		hofTrL.setTrUnqNo("1234");
		when(conversionService.convert(any(), eq(KftRpr0200400000.class))).thenReturn(mockKftIn);
	    
		Map<String, String> tlgHdr = new HashMap<String, String>();
	    String currentTimestamp = LocalDateTime.now().format(DateFormat.YYYYMMDDHHMMSS.getFormatter());
		tlgHdr.put("makeId", "test");
		tlgHdr.put("makeDttm", currentTimestamp);
		tlgHdr.put("chkId", "test");
		tlgHdr.put("chkDttm", currentTimestamp);
	    when(frwContext.getTlgHdr()).thenReturn(tlgHdr);
	    
	    // when
	    service.process(input);
	
	    // then
	    verify(rprCom).insertRPRTransaction(any(InsertRprTransactionIn.class));
	    verify(frwTemplate).send(eq(FrwDestination.KFT_RPR), any(KftRpr0200400000.class));
	}
    
}
