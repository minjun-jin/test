package com.jpmc.kcg.com.biz;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComBnkStsMDao;
import com.jpmc.kcg.com.dao.ComCdDMapper;
import com.jpmc.kcg.com.dao.ComLcsDao;
import com.jpmc.kcg.com.dao.ComLcsMapper;
import com.jpmc.kcg.com.dao.ComRespCdMMapper;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dto.ComBnkStsMIn;
import com.jpmc.kcg.com.dto.ComBnkStsMOut;
import com.jpmc.kcg.com.dto.ComCdD;
import com.jpmc.kcg.com.dto.ComLcs;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.dto.SelectNetDebitRatioOut;
import com.jpmc.kcg.com.enums.BankStatusEnum;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.SvcHourStsCdEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;

import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class ReleaseValidation {

	@Autowired
	private ComCdDMapper comCdDMapper;
	@Autowired
	private ComRespCdMMapper comRespCdMMapper;
	@Autowired
	private ComBnkStsMDao comBnkStsMDao;
	@Autowired
	private ComTrHoldLDao comTrHoldLDao;
	@Autowired
	private BatScheduleBean batScheduleBean;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private ComLcsMapper comLcsMapper;
	@Autowired
	private ComLcsDao comLcsDao;
	@Autowired
	private ComPshMsgBean comPshMsgBean;
	
	//	순이체한도 체크오류: 
	static final String KCG_ALERT_NET_DEBIT_CAPS = "KCG-ALERT:Net Debit CAPS";
	static final String KCG_INFO_CHECK_NET_DEBIT_CAP_TITLE = "KCG-INFO:CHECK NET_DEBIT_CABS";

	/**
	 * 서비스 시간/이전/이후 를 리턴한다.
	 * 
	 * @param svcTmDvsnCd
	 * @param currentTime
	 * @return
	 */
	public String getReleaseServiceHour(String svcTmDvsnCd, LocalDateTime currentTime) {

		String svcHourStsCd = "";

		if (svcTmDvsnCd == null || svcTmDvsnCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", svcTmDvsnCd);
		}
		if (currentTime == null) {
			throw new BusinessException("MCMNE01002");
		}
		ComCdD comCdD = comCdDMapper.selectByPrimaryKey("SVC_TM_DVSN_CD", svcTmDvsnCd);

		String strCurrDate = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd"));

		LocalDateTime currentDateLimitStartTime = LocalDateTime.parse(
				strCurrDate.concat(comCdD.getSubCdChar1()),
				DateTimeFormatter.ofPattern("yyyyMMddHH:mm"));
		LocalDateTime currentDateLimitEndTime = LocalDateTime.parse(
				strCurrDate.concat(comCdD.getSubCdChar2()),
				DateTimeFormatter.ofPattern("yyyyMMddHH:mm"));

		if (currentDateLimitStartTime.compareTo(currentTime) > 0) { // 서비스 시간 이전
			svcHourStsCd = SvcHourStsCdEnum.SERVICE_HOUR_BEFORE.getCode();
		} else if (currentDateLimitEndTime.compareTo(currentTime) < 0) { // 서비스 시간 이후
			svcHourStsCd = SvcHourStsCdEnum.SERVICE_HOUR_AFTER.getCode();
		} else { // 서비스 시간
			svcHourStsCd = SvcHourStsCdEnum.SERVICE_HOUR.getCode();
		}
		return svcHourStsCd;
	}

	/**
	 * HOLD 대상이 되는 응답코드인 경우 true 리턴한다.
	 * 
	 * @param hostCd
	 * @param bizDvsnCd
	 * @param respCd
	 * @return boolean
	 */
	public boolean getReleaseResponseCode(String hostCd, String bizDvsnCd, String respCd) {

		if (hostCd == null || hostCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", hostCd);
		}

		if (bizDvsnCd == null || bizDvsnCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", bizDvsnCd);
		}

		if (respCd == null || respCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", respCd);
		}

		ComRespCdM comRespCdM = comRespCdMMapper.selectByPrimaryKey(hostCd, bizDvsnCd, respCd);

		if (comRespCdM != null) {
			if ("Y".equals(comRespCdM.getHoldYn())) {
				return true;
			}
		}

		return false;

	}

	/**
	 * 망상태가 정상개시상태가 아닌 경우 HOLD의 대상이므로 true 리턴한다.
	 * '057', '099' 망상태 조회는 고정, bnkCd입력되는대로 조회
	 * @param bnkCd
	 * @param bizDvsnCd
	 * @return
	 */
	public boolean getReleaseConnectivityStatus(String bnkCd, String bizDvsnCd) {

		return this.getReleaseConnectivityStatus(bnkCd, bizDvsnCd,
				StringUtils.rightPad("", 6, ComConst.CHAR_0));
	}

	/**
	 * 망상태가 정상개시상태가 아닌 경우 HOLD의 대상이므로 true 리턴한다.
	 * 
	 * @param bnkCd
	 * @param bizDvsnCd
	 * @return
	 */
	public boolean getReleaseConnectivityStatus(String bnkCd, String bizDvsnCd,
			String tlgTrDvsnCd) {

		if (bnkCd == null || bnkCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", bnkCd);
		}

		if (bizDvsnCd == null || bizDvsnCd.isEmpty()) {
			throw new BusinessException("MCMNE01002", bizDvsnCd);
		}

		ComBnkStsMIn comBnkStsMIn = new ComBnkStsMIn();
		comBnkStsMIn.setBnkCd(bnkCd);
		comBnkStsMIn.setBizDvsnCd(bizDvsnCd);
		comBnkStsMIn.setTlgTrDvsnCd(tlgTrDvsnCd);  //거래구분코드

		ComBnkStsMOut comBnkStsMOut = comBnkStsMDao.selectBnkStatusHoldCheck(comBnkStsMIn);

		// kftc, jpmc, bnk 가 하나라도 미개시이면 결과값 true
		if (BankStatusEnum.INIT_V.getCode().equals(comBnkStsMOut.getKftcStsCd())
				|| BankStatusEnum.INIT_V.getCode().equals(comBnkStsMOut.getJpStsCd())
				|| BankStatusEnum.INIT_V.getCode().equals(comBnkStsMOut.getBnkStsCd())) {
			return true;
		}
		// kftc, jpmc, bnk 가 하나라도 장애이면 결과값 true
		if (BankStatusEnum.BUSY_V.getCode().equals(comBnkStsMOut.getKftcStsCd())
				|| BankStatusEnum.BUSY_V.getCode().equals(comBnkStsMOut.getJpStsCd())
				|| BankStatusEnum.BUSY_V.getCode().equals(comBnkStsMOut.getBnkStsCd())) {
			return true;
		}

		return false;

	}

	/**
	 * 계좌 개시 시간이 미도래하여 HOLD의 대상인 경우 TRUE를 리턴한다.
	 * @param inAcctNO
	 * @return
	 */
	public boolean getReleaseAccount(String inAcctNO, String hostNo) {

		String currTime = LocalDateTime.now().format(DateTimeFormatter.ofPattern("HHmmss"));

		ComTrHoldL comTrHoldL = new ComTrHoldL();

		comTrHoldL.setRcvAcctNo(inAcctNO);

		List<ComTrHoldL> releaseTraget = comTrHoldLDao.selectAcctStatmReleaseTarget(comTrHoldL);

		if (!ObjectUtils.isEmpty(releaseTraget)) {

			String staTime = releaseTraget.get(0).getRelsStaTm();

			log.debug("currTime : {} ", currTime);
			log.debug("staTime  : {} ", staTime);

			if (Integer.parseInt(currTime) < Integer.parseInt(staTime)) {

			    SimpleDateFormat formatter = new SimpleDateFormat(DateFormat.YYYY_MM_DD_HH_MM_SS.getPattern());

			    // LocalTime 및 LocalDateTime 변환
			    LocalDateTime opnTm = LocalDate.now().atTime(LocalTime.parse(staTime, DateFormat.HHMMSS.getFormatter()));

			    try {
			        // LocalDateTime을 문자열로 변환 후 Date로 변환
			        Date opnDttm = formatter.parse(opnTm.format(DateFormat.YYYY_MM_DD_HH_MM_SS.getFormatter()));

			        // 배치스케줄러 파라미터값 설정
			        Map<String, Object> dataMap = new HashMap<>();
			        dataMap.put("bizDvsnCd", BizDvsnCdEnum.HOF.getValue());
			        dataMap.put(ComConst.HOLD_RSN_CD, HoldRsnCdEnum.ACCOUNT_SERVICE_HOUR.getCode());
			        dataMap.put("outinDvsnCd", "01");
			        dataMap.put("acctNo", inAcctNO);
			        dataMap.put("hostNo", hostNo);

			        // 배치스케줄러 계좌개시시간으로 등록
			        batScheduleBean.runJobAtStartDatetime("B00309", BizDvsnCdEnum.COM.getValue(),
			                null, dataMap, opnDttm, null);
			        return true;
			    } catch (Exception e) {
			        log.debug(e.getMessage(), e);
			        throw new BusinessException("배치스케줄러 등록 실패");
			    }
			}
		}
		return false;
	}

	/**
	 * 순이체한도요율 조회 2024-11-15 HSH 
	 * 현재 거래금액을 포함하여 순이체한도를 초과하지 않는지 판단한다.
	 * HOLD 대상이 되는 경우 true 리턴한다.
	 * @param trAmt
	 * @return boolean
	 * @param inAmount
	 * @return
	 */
	public boolean getReleaseNetDebitCap(BigDecimal trAmt) {

		try {
			SelectNetDebitRatioOut netDebitOut = _getNetDebitCapInfo();
			
			if(netDebitOut.isOk()) return true;

			// 현재 입력된 금액까지 한도율을 체크한다.
			Map<String, Object> result = _calculateAfterAmountAndRatio(netDebitOut.getCurrSum(), netDebitOut.getLimitAmt(), trAmt);
			BigDecimal afterCurRatio = (BigDecimal) result.get("afterCurRatio");
			BigDecimal afterCurAmt = (BigDecimal) result.get("afterCurAmt");
			log.info(">>>>>>>afterCurRatio:{}, afterCurAmt : {}", afterCurRatio, afterCurAmt);

			// 스위치가 ON 인 경우, 한도 상관없이 거래
			if (ComConst.ON.equals(netDebitOut.getOverride())) {
				_insertNetDebitCap(afterCurAmt, afterCurRatio, netDebitOut.getLimitAmt());
				return false;
			} else {
				if (ComConst.Y.equals(netDebitOut.getLimitOverYn())) {// 이미 한도율을 넘은 경우
					return true;
				} else { // 아직 한도금을 넘지 않은 경우, 
					if (afterCurRatio.compareTo(netDebitOut.getLimitRatio()) < 0) {
						_insertNetDebitCap(afterCurAmt, afterCurRatio, netDebitOut.getLimitAmt());
						return false;
					} else {
						return true;
					}
				}
			}
		} catch (Exception e) {
			_sendNetDebitCapAlarm(KCG_INFO_CHECK_NET_DEBIT_CAP_TITLE, "11 [F A I L] CHECK NET_DEBIT_CAP");
		}
		
		return false;
	}
	
	/**
	 * 거액분할 Release 체크 시 순이체한도 현재금액 저장 여부 판단
	 * 현재 거래금액을 포함하여 순이체한도를 초과하지 않는지 판단한다.
	 * HOLD 대상이 되는 경우 true 리턴한다.
	 * ※ 2025.04.16 변경 전 
	 * 1) 분할 전 거액인 경우 체크만 진행 - isLargeAmtSplitYn false
	 * 2) 분할 완료 후 release 시에는 체크 + 순이체한도 현재금액 저장 - isLargeAmtSplitYn true
	 * ※ 2025.04.16 변경 후
	 * 1) 거액 분할 전 1회 체크만 하는 것으로 변경 - isLargeAmtSplitYn -> isInsertNetDebitCap 변수명 변경
	 * 2) 일반/거액의 순이체한도체크로직 분기 유지 - 추 후 변경사항 대비
	 * @param isInsertNetDebitCap 순이체한도 저장 여부
	 * @param trAmt
	 * @return boolean
	 * @return
	 */
	public boolean getReleaseLrgAmtNetDebitCap(boolean isInsertNetDebitCap, BigDecimal trAmt) {
		
		try {
			SelectNetDebitRatioOut netDebitOut = _getNetDebitCapInfo();
			
			if(netDebitOut.isOk()) return true;
			
			// 현재 입력된 금액까지 한도율을 체크한다.
			Map<String, Object> result = _calculateAfterAmountAndRatio(netDebitOut.getCurrSum(), netDebitOut.getLimitAmt(), trAmt);
			BigDecimal afterCurRatio = (BigDecimal) result.get("afterCurRatio");
			BigDecimal afterCurAmt = (BigDecimal) result.get("afterCurAmt");
			log.info(">>>>>>>afterCurRatio:{}, afterCurAmt : {}", afterCurRatio, afterCurAmt);
			
			// 스위치가 ON 인 경우, 한도 상관없이 거래
			if (ComConst.ON.equals(netDebitOut.getOverride())) {
				
				if(isInsertNetDebitCap) _insertNetDebitCap(afterCurAmt, afterCurRatio, netDebitOut.getLimitAmt());	// 순이체한도 저장 여부
				
				return false;
				
			} else {
				
				if (ComConst.Y.equals(netDebitOut.getLimitOverYn())) {// 이미 한도율을 넘은 경우
					
					return true;
					
				} else { // 아직 한도금을 넘지 않은 경우, 
					
					if (afterCurRatio.compareTo(netDebitOut.getLimitRatio()) < 0) {
						
						if(isInsertNetDebitCap) _insertNetDebitCap(afterCurAmt, afterCurRatio, netDebitOut.getLimitAmt());	// 순이체한도 저장 여부
						
						return false;
						
					} else {
						
						return true;
					}
				}
			}
		} catch (Exception e) {
			_sendNetDebitCapAlarm(KCG_INFO_CHECK_NET_DEBIT_CAP_TITLE, "11 [F A I L] CHECK NET_DEBIT_CAP");
		}
		
		return false;
	}
	
	/**
	 * 순이체한도 체크 정보 조회
	 * 단건 / 거액분할 체크로직 분기로 인해 공통화
	 * @return
	 */
	private SelectNetDebitRatioOut _getNetDebitCapInfo() {
		
		SelectNetDebitRatioOut netDebitOut = new SelectNetDebitRatioOut();
		
		try {
			// 현재 한도데이터 조회하기
			// SelectNetDebitRatioOut netDebitOut = comLcsDao.selectNetDebitRatio();
			
			/******************************************************************************************/
			/** 쿼리 쪼개기 반영 **/
			
			//select holdAmtSum
			SelectNetDebitRatioOut selectOut = new SelectNetDebitRatioOut();
			selectOut = comLcsDao.selectNetDebitRatioHoldSum();
			log.info(">>>>>>>> 1 selectOut is now : {} ", selectOut);
			netDebitOut.setHoldAmtSum(selectOut.getHoldAmtSum());
			//select limitAmt, limitRatio, autoLimitAmt, override (JPMC지정한 한도정보 공통코드값)
			selectOut = comLcsDao.selectNetDebitRatioComCdD();
			log.info(">>>>>>>>2 selectOut is now : {} ", selectOut);
			netDebitOut.setLimitAmt(selectOut.getLimitAmt());
			netDebitOut.setLimitRatio(selectOut.getLimitRatio());
			netDebitOut.setAutoLimitAmt(selectOut.getAutoLimitAmt());
			netDebitOut.setOverride(selectOut.getOverride());
			//select currSum (최근 한도사용금액 데이터)
			selectOut = comLcsDao.selectNetDebitRatioComLcs();
			log.info(">>>>>>>>3 selectOut is now : {}", selectOut);
			netDebitOut.setCurrSum(selectOut.getCurrSum());
			/*-----------------------------------------------------*/
			log.info(">>>>>>>> netDebitOut is {}", netDebitOut);
			
			if (netDebitOut.getLimitAmt().compareTo(BigDecimal.ZERO) == 0) {
				log.info(">>>>>>>> netDebitOut.getLimitAmt() is {} now, transaction into hold.",
						netDebitOut);
				//return true; netDebitCap 공통화로 객체 넘겨서 return 처리
				netDebitOut.setOk(true);
				return netDebitOut;
			}
			
			BigDecimal currRatio = netDebitOut.getCurrSum().multiply(BigDecimal.valueOf(100))
					.divide(netDebitOut.getLimitAmt(), RoundingMode.DOWN);
			netDebitOut.setCurrRatio(currRatio);
			
			BigDecimal limitOverYNValue = netDebitOut.getCurrSum()
					.multiply(BigDecimal.valueOf(100))
					.divide(netDebitOut.getLimitAmt(), RoundingMode.DOWN);
//						BigDecimal limitOverYNValue = (netDebitOut.getCurrSum().add(netDebitOut.getHoldAmtSum()))
//								.multiply(BigDecimal.valueOf(100))
//								.divide(netDebitOut.getLimitAmt(), RoundingMode.DOWN);
			
			ComCdD cdOut = comCdDMapper.selectByPrimaryKey(ComConst.NET_AMT_CD, ComConst.CHAR_02);
			BigDecimal limitThreshold = BigDecimal
					.valueOf(Math.min(netDebitOut.getLimitRatio().intValue(), Integer.parseInt(cdOut.getSubCdChar2())));
			
			log.info(">>>>>>>limitOverYNValue:{}, limitThreshold : {}", limitOverYNValue, limitThreshold);
			String limitOverYN = limitOverYNValue.compareTo(limitThreshold) >= 0 ? ComConst.Y
					: ComConst.N;
			netDebitOut.setLimitOverYn(limitOverYN);
			
			/******************************************************************************************/
			log.info(">>>>>>>overrideYn:{}, dataBase currAmt : {}, dataBase lmtAmt :{}",
					netDebitOut.getLimitOverYn(), netDebitOut.getCurrSum(), netDebitOut.getLimitAmt());
			
			/**
			 * 순이체한도 초과 알람 전송
			 */
			if(netDebitOut.getCurrRatio().compareTo(netDebitOut.getLimitRatio()) > 0) {
				String errorMessage = String.format(
						"01 [I N F O] NET DEBIT CAPS [CURRENT AMT=%s] [PERCENT=%s]\n",
						netDebitOut.getCurrSum(), netDebitOut.getCurrRatio());
				
				_sendNetDebitCapAlarm(KCG_ALERT_NET_DEBIT_CAPS, errorMessage);
			}
			
		} catch (Exception e) {
			_sendNetDebitCapAlarm(KCG_INFO_CHECK_NET_DEBIT_CAP_TITLE, "11 [F A I L] CHECK NET_DEBIT_CAP");
		}
		return netDebitOut;
	}

	/**
	 * 순이체한도요율 삽입
	 * @param inAmount
	 */
	public void insertNetDebitCap(BigDecimal inAmount) {
		// 현재 순이체 한도율 조회
		ComLcs currDebitCap = comLcsDao.selectNetTransferInfo();

		if (currDebitCap != null) {
			// 금액과 비율을 동시에 계산
			if (currDebitCap.getLcsLitAmt().compareTo(BigDecimal.ZERO) <= 0) {
				// 순이체한도금액조회
				ComCdD cdOut1 = comCdDMapper.selectByPrimaryKey(ComConst.NET_AMT_CD,
						ComConst.CHAR_01);
				if (cdOut1 != null) {
					currDebitCap.setLcsLitAmt(new BigDecimal(cdOut1.getSubCdChar1()));
				}
			}
			Map<String, Object> result = _calculateAfterAmountAndRatio(currDebitCap.getLcsCurAmt(),
					currDebitCap.getLcsLitAmt(), inAmount);

			BigDecimal afterCurRatio = (BigDecimal) result.get("afterCurRatio");
			BigDecimal afterCurAmt = (BigDecimal) result.get("afterCurAmt");

			// Net Debit Cap 정보 삽입
			_insertNetDebitCap(afterCurAmt, afterCurRatio, currDebitCap.getLcsLitAmt());
		}
	}

	/**
	 * 금액과 비율을 동시에 계산하는 메서드, Map으로 결과 반환
	 */
	private Map<String, Object> _calculateAfterAmountAndRatio(BigDecimal currAmt, BigDecimal lmtAmt,
			BigDecimal inAmount) {
		BigDecimal afterCurAmt = currAmt.add(inAmount);

		double calRatio = 0;

		if (lmtAmt.compareTo(BigDecimal.ZERO) > 0) {
			calRatio = afterCurAmt.divide(lmtAmt, 2, RoundingMode.HALF_UP).doubleValue() * 100;
		}

		BigDecimal afterCurRatio = BigDecimal.valueOf(calRatio);

		log.info(
				">>>>>>>lmtAmt:{}, currAmt : {}, inAmount : {}, afterCurAmt : {}, afterCurRatio : {}",
				lmtAmt, currAmt, inAmount, afterCurAmt, afterCurRatio);

		Map<String, Object> result = new HashMap<>();
		result.put("afterCurAmt", afterCurAmt);
		result.put("afterCurRatio", afterCurRatio);

		return result;
	}

	/**
	 * Net Debit Cap 정보를 DB에 삽입하는 메서드
	 */
	private void _insertNetDebitCap(BigDecimal afterCurAmt, BigDecimal afterCurRatio,
			BigDecimal lmtAmt) {

		ComLcs lcsIn = new ComLcs();
		lcsIn.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
		lcsIn.setLcsLitAmt(lmtAmt);
		lcsIn.setLcsCurAmt(afterCurAmt);
		lcsIn.setLcsRatio(afterCurRatio);
		lcsIn.setFrstChngGuid(frwContext.getSvcGuid());
		lcsIn.setFrstChngTmstmp(LocalDateTime.now());
		lcsIn.setFrstChngStaffId(frwContext.getUsrId());
		lcsIn.setLastChngGuid(frwContext.getSvcGuid());
		lcsIn.setLastChngTmstmp(LocalDateTime.now());
		lcsIn.setLastChngStaffId(frwContext.getUsrId());

		comLcsMapper.insert(lcsIn);
	}
	
	private void _sendNetDebitCapAlarm(String errorSubject, String errorMessage) {
		try {
			Map<String, Object> paramValList = new Hashtable<>();
			log.info(errorMessage);
			paramValList.put("errTlgId", errorSubject);
			paramValList.put("errCtt", errorMessage);
			comPshMsgBean.sendAlarm(8, paramValList.get("errTlgId").toString(),
					paramValList, null, true);
		} catch (Exception e2) {
			log.error("Message Request Fail", e2);
		}
	}
}
