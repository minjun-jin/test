package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자어음 보증 발행 결과 통지 재요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 260000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * guaranteeRequestIssueBeforeAfterSort 보증요청발행전후구분 
 * guaranteeRequestGuaranteeRequestDate 보증요청보증요청일자 
 * guaranteeRequestGuaranteeProcessDate 보증요청보증처리일자 
 * guaranteeRequestGuaranteeProcessSort 보증요청보증처리구분 
 * eNoteNumber 어음내역전자어음번호 
 * eNoteType 어음내역어음종류 
 * eNoteIssueDate 어음내역전자어음발행일자 
 * eNoteIssuePlace 어음내역전자어음발행지 
 * eNoteAmount 어음내역전자어음금액 
 * eNoteMaturedDate 어음내역전자어음만기일자 
 * paymentBankAndBranchCode 어음내역지급은행및지점코드 
 * issuerInfoCorpIndvSortCode 발행인정보법인개인구분코드 
 * issuerInfoResidentBusinessNumber 발행인정보주민사업자번호 
 * issuerInfoCorpName 발행인정보법인명 
 * issuerInfoNameRepresentativeName 발행인정보성명(대표자명) 
 * issuerInfoAddress 발행인정보주소 
 * issuerInfoBankCode 발행인정보은행코드 
 * issuerInfoCurrentAccountNumber 발행인정보당좌계좌번호 
 * beneCorpIndvSortCode 수취인법인개인구분코드 
 * beneResidentBusinessNumber 수취인주민사업자번호 
 * beneCorpName 수취인법인명 
 * beneNameRepresentativeName 수취인성명(대표자명) 
 * beneAddress 수취인주소 
 * beneBankCode 수취인은행코드 
 * beneDepositAccountNumber 수취인입금계좌번호 
 * prohibitedInstructionYn 지시금지여부 
 * guarantorInfoCorpIndvSortCode 보증인정보법인개인구분코드 
 * guarantorInfoResidentBusinessNumber 보증인정보주민사업자번호 
 * guarantorInfoCorpName 보증인정보법인명 
 * guarantorInfoNameRepresentativeName 보증인정보성명(대표자명) 
 * guarantorInfoAddress 보증인정보주소 
 * guarantorInfoBankCode 보증인정보은행코드 
 * guarantorInfoDepositAccountNumber 보증인정보입금계좌번호 
 * guarantorInfoGuaranteeNumber 보증인정보보증번호 
 * guaranteeProcessingParticipationSort 보증처리참가구분 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0201260000 kftEnt0201260000 = new KftEnt0201260000(); // 전자어음 보증 발행 결과 통지 재요청
 * kftEnt0201260000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0201260000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0201260000.setBnkCd("057"); // 은행코드
 * kftEnt0201260000.setMessageType("0200"); // 전문종별코드
 * kftEnt0201260000.setTransactionCode("260000"); // 거래구분코드
 * kftEnt0201260000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0201260000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0201260000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0201260000.setStatus("000"); // STATUS
 * kftEnt0201260000.setResponseCode1(""); // 응답코드1
 * kftEnt0201260000.setResponseCode2(""); // 응답코드2
 * kftEnt0201260000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0201260000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0201260000.setGuaranteeRequestIssueBeforeAfterSort(""); // 보증요청발행전후구분
 * kftEnt0201260000.setGuaranteeRequestGuaranteeRequestDate(""); // 보증요청보증요청일자
 * kftEnt0201260000.setGuaranteeRequestGuaranteeProcessDate(""); // 보증요청보증처리일자
 * kftEnt0201260000.setGuaranteeRequestGuaranteeProcessSort(""); // 보증요청보증처리구분
 * kftEnt0201260000.setENoteNumber(""); // 어음내역전자어음번호
 * kftEnt0201260000.setENoteType(""); // 어음내역어음종류
 * kftEnt0201260000.setENoteIssueDate(""); // 어음내역전자어음발행일자
 * kftEnt0201260000.setENoteIssuePlace(""); // 어음내역전자어음발행지
 * kftEnt0201260000.setENoteAmount(0L); // 어음내역전자어음금액
 * kftEnt0201260000.setENoteMaturedDate(""); // 어음내역전자어음만기일자
 * kftEnt0201260000.setPaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * kftEnt0201260000.setIssuerInfoCorpIndvSortCode(""); // 발행인정보법인개인구분코드
 * kftEnt0201260000.setIssuerInfoResidentBusinessNumber(""); // 발행인정보주민사업자번호
 * kftEnt0201260000.setIssuerInfoCorpName(""); // 발행인정보법인명
 * kftEnt0201260000.setIssuerInfoNameRepresentativeName(""); // 발행인정보성명(대표자명)
 * kftEnt0201260000.setIssuerInfoAddress(""); // 발행인정보주소
 * kftEnt0201260000.setIssuerInfoBankCode(""); // 발행인정보은행코드
 * kftEnt0201260000.setIssuerInfoCurrentAccountNumber(""); // 발행인정보당좌계좌번호
 * kftEnt0201260000.setBeneCorpIndvSortCode(""); // 수취인법인개인구분코드
 * kftEnt0201260000.setBeneResidentBusinessNumber(""); // 수취인주민사업자번호
 * kftEnt0201260000.setBeneCorpName(""); // 수취인법인명
 * kftEnt0201260000.setBeneNameRepresentativeName(""); // 수취인성명(대표자명)
 * kftEnt0201260000.setBeneAddress(""); // 수취인주소
 * kftEnt0201260000.setBeneBankCode(""); // 수취인은행코드
 * kftEnt0201260000.setBeneDepositAccountNumber(""); // 수취인입금계좌번호
 * kftEnt0201260000.setProhibitedInstructionYn(""); // 지시금지여부
 * kftEnt0201260000.setGuarantorInfoCorpIndvSortCode(""); // 보증인정보법인개인구분코드
 * kftEnt0201260000.setGuarantorInfoResidentBusinessNumber(""); // 보증인정보주민사업자번호
 * kftEnt0201260000.setGuarantorInfoCorpName(""); // 보증인정보법인명
 * kftEnt0201260000.setGuarantorInfoNameRepresentativeName(""); // 보증인정보성명(대표자명)
 * kftEnt0201260000.setGuarantorInfoAddress(""); // 보증인정보주소
 * kftEnt0201260000.setGuarantorInfoBankCode(""); // 보증인정보은행코드
 * kftEnt0201260000.setGuarantorInfoDepositAccountNumber(""); // 보증인정보입금계좌번호
 * kftEnt0201260000.setGuarantorInfoGuaranteeNumber(""); // 보증인정보보증번호
 * kftEnt0201260000.setGuaranteeProcessingParticipationSort(""); // 보증처리참가구분
 * kftEnt0201260000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0201260000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0201260000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "260000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String guaranteeRequestIssueBeforeAfterSort; // 보증요청발행전후구분
	private String guaranteeRequestGuaranteeRequestDate; // 보증요청보증요청일자
	private String guaranteeRequestGuaranteeProcessDate; // 보증요청보증처리일자
	private String guaranteeRequestGuaranteeProcessSort; // 보증요청보증처리구분
	private String eNoteNumber; // 어음내역전자어음번호
	private String eNoteType; // 어음내역어음종류
	private String eNoteIssueDate; // 어음내역전자어음발행일자
	private String eNoteIssuePlace; // 어음내역전자어음발행지
	private long eNoteAmount; // 어음내역전자어음금액
	private String eNoteMaturedDate; // 어음내역전자어음만기일자
	private String paymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private String issuerInfoCorpIndvSortCode; // 발행인정보법인개인구분코드
	private String issuerInfoResidentBusinessNumber; // 발행인정보주민사업자번호
	private String issuerInfoCorpName; // 발행인정보법인명
	private String issuerInfoNameRepresentativeName; // 발행인정보성명(대표자명)
	private String issuerInfoAddress; // 발행인정보주소
	private String issuerInfoBankCode; // 발행인정보은행코드
	private String issuerInfoCurrentAccountNumber; // 발행인정보당좌계좌번호
	private String beneCorpIndvSortCode; // 수취인법인개인구분코드
	private String beneResidentBusinessNumber; // 수취인주민사업자번호
	private String beneCorpName; // 수취인법인명
	private String beneNameRepresentativeName; // 수취인성명(대표자명)
	private String beneAddress; // 수취인주소
	private String beneBankCode; // 수취인은행코드
	private String beneDepositAccountNumber; // 수취인입금계좌번호
	private String prohibitedInstructionYn; // 지시금지여부
	private String guarantorInfoCorpIndvSortCode; // 보증인정보법인개인구분코드
	private String guarantorInfoResidentBusinessNumber; // 보증인정보주민사업자번호
	private String guarantorInfoCorpName; // 보증인정보법인명
	private String guarantorInfoNameRepresentativeName; // 보증인정보성명(대표자명)
	private String guarantorInfoAddress; // 보증인정보주소
	private String guarantorInfoBankCode; // 보증인정보은행코드
	private String guarantorInfoDepositAccountNumber; // 보증인정보입금계좌번호
	private String guarantorInfoGuaranteeNumber; // 보증인정보보증번호
	private String guaranteeProcessingParticipationSort; // 보증처리참가구분
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestIssueBeforeAfterSort$; // 보증요청발행전후구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestGuaranteeRequestDate$; // 보증요청보증요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestGuaranteeProcessDate$; // 보증요청보증처리일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestGuaranteeProcessSort$; // 보증요청보증처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpIndvSortCode$; // 발행인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoResidentBusinessNumber$; // 발행인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpName$; // 발행인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoNameRepresentativeName$; // 발행인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoAddress$; // 발행인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoBankCode$; // 발행인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCurrentAccountNumber$; // 발행인정보당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpIndvSortCode$; // 수취인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneResidentBusinessNumber$; // 수취인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpName$; // 수취인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneNameRepresentativeName$; // 수취인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneAddress$; // 수취인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneBankCode$; // 수취인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneDepositAccountNumber$; // 수취인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prohibitedInstructionYn$; // 지시금지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoCorpIndvSortCode$; // 보증인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoResidentBusinessNumber$; // 보증인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoCorpName$; // 보증인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoNameRepresentativeName$; // 보증인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoAddress$; // 보증인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoBankCode$; // 보증인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoDepositAccountNumber$; // 보증인정보입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorInfoGuaranteeNumber$; // 보증인정보보증번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeProcessingParticipationSort$; // 보증처리참가구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(guaranteeRequestIssueBeforeAfterSort$)) { // 보증요청발행전후구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(guaranteeRequestGuaranteeProcessSort$)) { // 보증요청보증처리구분
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음내역전자어음번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoResidentBusinessNumber$)) { // 발행인정보주민사업자번호
			return 25;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoCurrentAccountNumber$)) { // 발행인정보당좌계좌번호
			return 30;
		}
		if (VOUtils.isNotAlphanumericSpace(beneResidentBusinessNumber$)) { // 수취인주민사업자번호
			return 32;
		}
		if (VOUtils.isNotAlphanumericSpace(beneDepositAccountNumber$)) { // 수취인입금계좌번호
			return 37;
		}
		if (VOUtils.isNotAlphanumericSpace(prohibitedInstructionYn$)) { // 지시금지여부
			return 38;
		}
		if (VOUtils.isNotAlphanumericSpace(guarantorInfoCorpIndvSortCode$)) { // 보증인정보법인개인구분코드
			return 39;
		}
		if (VOUtils.isNotAlphanumericSpace(guarantorInfoResidentBusinessNumber$)) { // 보증인정보주민사업자번호
			return 40;
		}
		if (VOUtils.isNotAlphanumericSpace(guarantorInfoDepositAccountNumber$)) { // 보증인정보입금계좌번호
			return 45;
		}
		if (VOUtils.isNotAlphanumericSpace(guaranteeProcessingParticipationSort$)) { // 보증처리참가구분
			return 47;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		guaranteeRequestIssueBeforeAfterSort$ = VOUtils.write(out, guaranteeRequestIssueBeforeAfterSort, 1); // 보증요청발행전후구분
		guaranteeRequestGuaranteeRequestDate$ = VOUtils.write(out, guaranteeRequestGuaranteeRequestDate, 8); // 보증요청보증요청일자
		guaranteeRequestGuaranteeProcessDate$ = VOUtils.write(out, guaranteeRequestGuaranteeProcessDate, 8); // 보증요청보증처리일자
		guaranteeRequestGuaranteeProcessSort$ = VOUtils.write(out, guaranteeRequestGuaranteeProcessSort, 1); // 보증요청보증처리구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음내역전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음내역어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음내역전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음내역전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음내역전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode$ = VOUtils.write(out, issuerInfoCorpIndvSortCode, 1); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // 발행인정보주민사업자번호
		issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // 발행인정보법인명
		issuerInfoNameRepresentativeName$ = VOUtils.write(out, issuerInfoNameRepresentativeName, 20, "EUC-KR"); // 발행인정보성명(대표자명)
		issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // 발행인정보주소
		issuerInfoBankCode$ = VOUtils.write(out, issuerInfoBankCode, 3); // 발행인정보은행코드
		issuerInfoCurrentAccountNumber$ = VOUtils.write(out, issuerInfoCurrentAccountNumber, 16); // 발행인정보당좌계좌번호
		beneCorpIndvSortCode$ = VOUtils.write(out, beneCorpIndvSortCode, 1); // 수취인법인개인구분코드
		beneResidentBusinessNumber$ = VOUtils.write(out, beneResidentBusinessNumber, 13); // 수취인주민사업자번호
		beneCorpName$ = VOUtils.write(out, beneCorpName, 40, "EUC-KR"); // 수취인법인명
		beneNameRepresentativeName$ = VOUtils.write(out, beneNameRepresentativeName, 20, "EUC-KR"); // 수취인성명(대표자명)
		beneAddress$ = VOUtils.write(out, beneAddress, 60, "EUC-KR"); // 수취인주소
		beneBankCode$ = VOUtils.write(out, beneBankCode, 3); // 수취인은행코드
		beneDepositAccountNumber$ = VOUtils.write(out, beneDepositAccountNumber, 16); // 수취인입금계좌번호
		prohibitedInstructionYn$ = VOUtils.write(out, prohibitedInstructionYn, 1); // 지시금지여부
		guarantorInfoCorpIndvSortCode$ = VOUtils.write(out, guarantorInfoCorpIndvSortCode, 1); // 보증인정보법인개인구분코드
		guarantorInfoResidentBusinessNumber$ = VOUtils.write(out, guarantorInfoResidentBusinessNumber, 13); // 보증인정보주민사업자번호
		guarantorInfoCorpName$ = VOUtils.write(out, guarantorInfoCorpName, 40, "EUC-KR"); // 보증인정보법인명
		guarantorInfoNameRepresentativeName$ = VOUtils.write(out, guarantorInfoNameRepresentativeName, 20, "EUC-KR"); // 보증인정보성명(대표자명)
		guarantorInfoAddress$ = VOUtils.write(out, guarantorInfoAddress, 60, "EUC-KR"); // 보증인정보주소
		guarantorInfoBankCode$ = VOUtils.write(out, guarantorInfoBankCode, 3); // 보증인정보은행코드
		guarantorInfoDepositAccountNumber$ = VOUtils.write(out, guarantorInfoDepositAccountNumber, 16); // 보증인정보입금계좌번호
		guarantorInfoGuaranteeNumber$ = VOUtils.write(out, guarantorInfoGuaranteeNumber, 4); // 보증인정보보증번호
		guaranteeProcessingParticipationSort$ = VOUtils.write(out, guaranteeProcessingParticipationSort, 1); // 보증처리참가구분
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		guaranteeRequestIssueBeforeAfterSort = VOUtils.toString(guaranteeRequestIssueBeforeAfterSort$ = VOUtils.read(in, 1)); // 보증요청발행전후구분
		guaranteeRequestGuaranteeRequestDate = VOUtils.toString(guaranteeRequestGuaranteeRequestDate$ = VOUtils.read(in, 8)); // 보증요청보증요청일자
		guaranteeRequestGuaranteeProcessDate = VOUtils.toString(guaranteeRequestGuaranteeProcessDate$ = VOUtils.read(in, 8)); // 보증요청보증처리일자
		guaranteeRequestGuaranteeProcessSort = VOUtils.toString(guaranteeRequestGuaranteeProcessSort$ = VOUtils.read(in, 1)); // 보증요청보증처리구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode = VOUtils.toString(issuerInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인정보주민사업자번호
		issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인정보법인명
		issuerInfoNameRepresentativeName = VOUtils.toString(issuerInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인정보성명(대표자명)
		issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인정보주소
		issuerInfoBankCode = VOUtils.toString(issuerInfoBankCode$ = VOUtils.read(in, 3)); // 발행인정보은행코드
		issuerInfoCurrentAccountNumber = VOUtils.toString(issuerInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인정보당좌계좌번호
		beneCorpIndvSortCode = VOUtils.toString(beneCorpIndvSortCode$ = VOUtils.read(in, 1)); // 수취인법인개인구분코드
		beneResidentBusinessNumber = VOUtils.toString(beneResidentBusinessNumber$ = VOUtils.read(in, 13)); // 수취인주민사업자번호
		beneCorpName = VOUtils.toString(beneCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 수취인법인명
		beneNameRepresentativeName = VOUtils.toString(beneNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인성명(대표자명)
		beneAddress = VOUtils.toString(beneAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 수취인주소
		beneBankCode = VOUtils.toString(beneBankCode$ = VOUtils.read(in, 3)); // 수취인은행코드
		beneDepositAccountNumber = VOUtils.toString(beneDepositAccountNumber$ = VOUtils.read(in, 16)); // 수취인입금계좌번호
		prohibitedInstructionYn = VOUtils.toString(prohibitedInstructionYn$ = VOUtils.read(in, 1)); // 지시금지여부
		guarantorInfoCorpIndvSortCode = VOUtils.toString(guarantorInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 보증인정보법인개인구분코드
		guarantorInfoResidentBusinessNumber = VOUtils.toString(guarantorInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 보증인정보주민사업자번호
		guarantorInfoCorpName = VOUtils.toString(guarantorInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 보증인정보법인명
		guarantorInfoNameRepresentativeName = VOUtils.toString(guarantorInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 보증인정보성명(대표자명)
		guarantorInfoAddress = VOUtils.toString(guarantorInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 보증인정보주소
		guarantorInfoBankCode = VOUtils.toString(guarantorInfoBankCode$ = VOUtils.read(in, 3)); // 보증인정보은행코드
		guarantorInfoDepositAccountNumber = VOUtils.toString(guarantorInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // 보증인정보입금계좌번호
		guarantorInfoGuaranteeNumber = VOUtils.toString(guarantorInfoGuaranteeNumber$ = VOUtils.read(in, 4)); // 보증인정보보증번호
		guaranteeProcessingParticipationSort = VOUtils.toString(guaranteeProcessingParticipationSort$ = VOUtils.read(in, 1)); // 보증처리참가구분
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", guaranteeRequestIssueBeforeAfterSort=").append(guaranteeRequestIssueBeforeAfterSort).append(System.lineSeparator()); // 보증요청발행전후구분
		sb.append(", guaranteeRequestGuaranteeRequestDate=").append(guaranteeRequestGuaranteeRequestDate).append(System.lineSeparator()); // 보증요청보증요청일자
		sb.append(", guaranteeRequestGuaranteeProcessDate=").append(guaranteeRequestGuaranteeProcessDate).append(System.lineSeparator()); // 보증요청보증처리일자
		sb.append(", guaranteeRequestGuaranteeProcessSort=").append(guaranteeRequestGuaranteeProcessSort).append(System.lineSeparator()); // 보증요청보증처리구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", issuerInfoCorpIndvSortCode=").append(issuerInfoCorpIndvSortCode).append(System.lineSeparator()); // 발행인정보법인개인구분코드
		sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행인정보주민사업자번호
		sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // 발행인정보법인명
		sb.append(", issuerInfoNameRepresentativeName=").append(issuerInfoNameRepresentativeName).append(System.lineSeparator()); // 발행인정보성명(대표자명)
		sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // 발행인정보주소
		sb.append(", issuerInfoBankCode=").append(issuerInfoBankCode).append(System.lineSeparator()); // 발행인정보은행코드
		sb.append(", issuerInfoCurrentAccountNumber=").append(issuerInfoCurrentAccountNumber).append(System.lineSeparator()); // 발행인정보당좌계좌번호
		sb.append(", beneCorpIndvSortCode=").append(beneCorpIndvSortCode).append(System.lineSeparator()); // 수취인법인개인구분코드
		sb.append(", beneResidentBusinessNumber=").append(beneResidentBusinessNumber).append(System.lineSeparator()); // 수취인주민사업자번호
		sb.append(", beneCorpName=").append(beneCorpName).append(System.lineSeparator()); // 수취인법인명
		sb.append(", beneNameRepresentativeName=").append(beneNameRepresentativeName).append(System.lineSeparator()); // 수취인성명(대표자명)
		sb.append(", beneAddress=").append(beneAddress).append(System.lineSeparator()); // 수취인주소
		sb.append(", beneBankCode=").append(beneBankCode).append(System.lineSeparator()); // 수취인은행코드
		sb.append(", beneDepositAccountNumber=").append(beneDepositAccountNumber).append(System.lineSeparator()); // 수취인입금계좌번호
		sb.append(", prohibitedInstructionYn=").append(prohibitedInstructionYn).append(System.lineSeparator()); // 지시금지여부
		sb.append(", guarantorInfoCorpIndvSortCode=").append(guarantorInfoCorpIndvSortCode).append(System.lineSeparator()); // 보증인정보법인개인구분코드
		sb.append(", guarantorInfoResidentBusinessNumber=").append(guarantorInfoResidentBusinessNumber).append(System.lineSeparator()); // 보증인정보주민사업자번호
		sb.append(", guarantorInfoCorpName=").append(guarantorInfoCorpName).append(System.lineSeparator()); // 보증인정보법인명
		sb.append(", guarantorInfoNameRepresentativeName=").append(guarantorInfoNameRepresentativeName).append(System.lineSeparator()); // 보증인정보성명(대표자명)
		sb.append(", guarantorInfoAddress=").append(guarantorInfoAddress).append(System.lineSeparator()); // 보증인정보주소
		sb.append(", guarantorInfoBankCode=").append(guarantorInfoBankCode).append(System.lineSeparator()); // 보증인정보은행코드
		sb.append(", guarantorInfoDepositAccountNumber=").append(guarantorInfoDepositAccountNumber).append(System.lineSeparator()); // 보증인정보입금계좌번호
		sb.append(", guarantorInfoGuaranteeNumber=").append(guarantorInfoGuaranteeNumber).append(System.lineSeparator()); // 보증인정보보증번호
		sb.append(", guaranteeProcessingParticipationSort=").append(guaranteeProcessingParticipationSort).append(System.lineSeparator()); // 보증처리참가구분
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "260000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "guaranteeRequestIssueBeforeAfterSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guaranteeRequestGuaranteeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeRequestGuaranteeProcessDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeRequestGuaranteeProcessSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prohibitedInstructionYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "guarantorInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "guarantorInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "guarantorInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "guarantorInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "guarantorInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guarantorInfoGuaranteeNumber", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "guaranteeProcessingParticipationSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
