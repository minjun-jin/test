package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자동납부 해지 결과내역(AT3112의 처리 결과)
 * <pre>{@code
 * KftCmsAT4112R kftCmsAT4112R  = new KftCmsAT4112R(); // 자동납부 해지 결과내역(AT3112의 처리 결과)
 * kftCmsAT4112R.setFileName("AT4112"); // 업무구분
 * kftCmsAT4112R.setDataType("22"); // 데이타구분
 * kftCmsAT4112R.setSerialNumber("0000000"); // 일련번호
 * kftCmsAT4112R.setProcessingType(""); // 처리구분
 * kftCmsAT4112R.setPaymentAccountNo(""); // 출금계좌번호
 * kftCmsAT4112R.setInstitutionCode("057"); // 기관코드
 * kftCmsAT4112R.setPayerNumber(""); // 납부자번호
 * kftCmsAT4112R.setFiller2(""); // FILLER
 * kftCmsAT4112R.setAccountHolderID(""); // 예금주실명번호
 * kftCmsAT4112R.setAccountHolderName(""); // 계좌예금주명
 * kftCmsAT4112R.setSubInstitutionCode(""); // 하위이용기관코드
 * kftCmsAT4112R.setClosedStatus(""); // 해지접수구분
 * kftCmsAT4112R.setClosedReason(""); // 해지요청사유
 * kftCmsAT4112R.setClosedRequestDate(""); // 해지신청일
 * kftCmsAT4112R.setClosedApplyBankCode(""); // 해지접수금융회사코드
 * kftCmsAT4112R.setFiller3(""); // FILLER
 * kftCmsAT4112R.setNewClosedOffice(""); // 등록/해지사무소
 * kftCmsAT4112R.setBankCustomField(""); // 금융회사임의필드
 * kftCmsAT4112R.setReponseCodeType(""); // 결과코드구분
 * kftCmsAT4112R.setResponseCode(""); // 결과코드
 * kftCmsAT4112R.setFiller4(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsAT4112R implements Vo {

	private String fileName = "AT4112"; // 업무구분
	private String dataType = "22"; // 데이타구분
	private String serialNumber = "0000000"; // 일련번호
	private String processingType; // 처리구분
	private String paymentAccountNo; // 출금계좌번호
	private String institutionCode = "057"; // 기관코드
	private String payerNumber; // 납부자번호
	private String filler2; // FILLER
	private String accountHolderID; // 예금주실명번호
	private String accountHolderName; // 계좌예금주명
	private String subInstitutionCode; // 하위이용기관코드
	private String closedStatus; // 해지접수구분
	private String closedReason; // 해지요청사유
	private String closedRequestDate; // 해지신청일
	private String closedApplyBankCode; // 해지접수금융회사코드
	private String filler3; // FILLER
	private String newClosedOffice; // 등록/해지사무소
	private String bankCustomField; // 금융회사임의필드
	private String reponseCodeType; // 결과코드구분
	private String responseCode; // 결과코드
	private String filler4; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingType$; // 처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentAccountNo$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumber$; // 납부자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderID$; // 예금주실명번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderName$; // 계좌예금주명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String subInstitutionCode$; // 하위이용기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedStatus$; // 해지접수구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedReason$; // 해지요청사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedRequestDate$; // 해지신청일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String closedApplyBankCode$; // 해지접수금융회사코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String newClosedOffice$; // 등록/해지사무소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCustomField$; // 금융회사임의필드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reponseCodeType$; // 결과코드구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 결과코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		processingType$ = VOUtils.write(out, processingType, 2); // 처리구분
		paymentAccountNo$ = VOUtils.write(out, paymentAccountNo, 20); // 출금계좌번호
		institutionCode$ = VOUtils.write(out, institutionCode, 20); // 기관코드
		payerNumber$ = VOUtils.write(out, payerNumber, 30); // 납부자번호
		filler2$ = VOUtils.write(out, filler2, 1); // FILLER
		accountHolderID$ = VOUtils.write(out, accountHolderID, 13); // 예금주실명번호
		accountHolderName$ = VOUtils.write(out, accountHolderName, 20); // 계좌예금주명
		subInstitutionCode$ = VOUtils.write(out, subInstitutionCode, 10); // 하위이용기관코드
		closedStatus$ = VOUtils.write(out, closedStatus, 1); // 해지접수구분
		closedReason$ = VOUtils.write(out, closedReason, 1); // 해지요청사유
		closedRequestDate$ = VOUtils.write(out, closedRequestDate, 8); // 해지신청일
		closedApplyBankCode$ = VOUtils.write(out, closedApplyBankCode, 3); // 해지접수금융회사코드
		filler3$ = VOUtils.write(out, filler3, 5); // FILLER
		newClosedOffice$ = VOUtils.write(out, newClosedOffice, 7); // 등록/해지사무소
		bankCustomField$ = VOUtils.write(out, bankCustomField, 10); // 금융회사임의필드
		reponseCodeType$ = VOUtils.write(out, reponseCodeType, 1); // 결과코드구분
		responseCode$ = VOUtils.write(out, responseCode, 4); // 결과코드
		filler4$ = VOUtils.write(out, filler4, 229); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		processingType = VOUtils.toString(processingType$ = VOUtils.read(in, 2)); // 처리구분
		paymentAccountNo = VOUtils.toString(paymentAccountNo$ = VOUtils.read(in, 20)); // 출금계좌번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 20)); // 기관코드
		payerNumber = VOUtils.toString(payerNumber$ = VOUtils.read(in, 30)); // 납부자번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 1)); // FILLER
		accountHolderID = VOUtils.toString(accountHolderID$ = VOUtils.read(in, 13)); // 예금주실명번호
		accountHolderName = VOUtils.toString(accountHolderName$ = VOUtils.read(in, 20)); // 계좌예금주명
		subInstitutionCode = VOUtils.toString(subInstitutionCode$ = VOUtils.read(in, 10)); // 하위이용기관코드
		closedStatus = VOUtils.toString(closedStatus$ = VOUtils.read(in, 1)); // 해지접수구분
		closedReason = VOUtils.toString(closedReason$ = VOUtils.read(in, 1)); // 해지요청사유
		closedRequestDate = VOUtils.toString(closedRequestDate$ = VOUtils.read(in, 8)); // 해지신청일
		closedApplyBankCode = VOUtils.toString(closedApplyBankCode$ = VOUtils.read(in, 3)); // 해지접수금융회사코드
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 5)); // FILLER
		newClosedOffice = VOUtils.toString(newClosedOffice$ = VOUtils.read(in, 7)); // 등록/해지사무소
		bankCustomField = VOUtils.toString(bankCustomField$ = VOUtils.read(in, 10)); // 금융회사임의필드
		reponseCodeType = VOUtils.toString(reponseCodeType$ = VOUtils.read(in, 1)); // 결과코드구분
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 4)); // 결과코드
		filler4 = VOUtils.toString(filler4$ = VOUtils.read(in, 229)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", processingType=").append(processingType).append(System.lineSeparator()); // 처리구분
		sb.append(", paymentAccountNo=").append(paymentAccountNo).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", payerNumber=").append(payerNumber).append(System.lineSeparator()); // 납부자번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", accountHolderID=").append(accountHolderID).append(System.lineSeparator()); // 예금주실명번호
		sb.append(", accountHolderName=").append(accountHolderName).append(System.lineSeparator()); // 계좌예금주명
		sb.append(", subInstitutionCode=").append(subInstitutionCode).append(System.lineSeparator()); // 하위이용기관코드
		sb.append(", closedStatus=").append(closedStatus).append(System.lineSeparator()); // 해지접수구분
		sb.append(", closedReason=").append(closedReason).append(System.lineSeparator()); // 해지요청사유
		sb.append(", closedRequestDate=").append(closedRequestDate).append(System.lineSeparator()); // 해지신청일
		sb.append(", closedApplyBankCode=").append(closedApplyBankCode).append(System.lineSeparator()); // 해지접수금융회사코드
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append(", newClosedOffice=").append(newClosedOffice).append(System.lineSeparator()); // 등록/해지사무소
		sb.append(", bankCustomField=").append(bankCustomField).append(System.lineSeparator()); // 금융회사임의필드
		sb.append(", reponseCodeType=").append(reponseCodeType).append(System.lineSeparator()); // 결과코드구분
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 결과코드
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", "AT4112"),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", "22"),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "processingType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "paymentAccountNo", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "20", "defltVal", "057"),
			Map.of("fld", "payerNumber", "fldLen", "30", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "accountHolderID", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accountHolderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "subInstitutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "closedStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "closedReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "closedRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "closedApplyBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "newClosedOffice", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCustomField", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "reponseCodeType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "responseCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "filler4", "fldLen", "229", "defltVal", "")
		);
	}

}
