package com.jpmc.kcg.frw;

import java.beans.Introspector;
import java.lang.reflect.ParameterizedType;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.io.Charsets;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.logging.LogLevel;
import org.springframework.context.ApplicationContext;
import org.springframework.core.ResolvableType;
import org.springframework.jms.support.JmsUtils;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.jpmc.kcg.cms.biz.vo.LvbCmsComHdr;
import com.jpmc.kcg.cms.biz.vo.LvbCmsSumHdr;
import com.jpmc.kcg.ent.biz.vo.CqeEntComHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntComHdr;
import com.jpmc.kcg.ent.biz.vo.KftEntMngHdr;
import com.jpmc.kcg.frw.dao.FrwCfgMMapper;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.frw.dao.FrwMsgLMapper;
import com.jpmc.kcg.frw.dto.FrwCfgM;
import com.jpmc.kcg.frw.dto.FrwDtMgmtM;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.frw.dto.FrwSvcP;
import com.jpmc.kcg.hof.biz.vo.GchHofComHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofComHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofLcrHdr;
import com.jpmc.kcg.hof.biz.vo.KftHofMngHdr;
import com.jpmc.kcg.hof.biz.vo.LvbHofComHdr;
import com.jpmc.kcg.ift.biz.vo.CqeIftComHdr;
import com.jpmc.kcg.ift.biz.vo.KftIftComHdr;
import com.jpmc.kcg.ift.biz.vo.KftIftMngHdr;
import com.jpmc.kcg.ift.biz.vo.LvbIftComHdr;
import com.jpmc.kcg.rpr.biz.vo.CqeRprComHdr;
import com.jpmc.kcg.rpr.biz.vo.KftRprComHdr;
import com.jpmc.kcg.rpr.biz.vo.KftRprMngHdr;
import com.jpmc.kcg.rpr.biz.vo.LvbRprComHdr;

import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.TextMessage;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Transactional(propagation = Propagation.REQUIRED)
public class FrwServiceExecutor {

	@Autowired
	private ApplicationContext applicationContext;
	@Autowired
	private FrwExecutor frwExecutor;
	@Autowired
	private FrwMapper frwMapper;
	@Autowired
	private FrwCfgMMapper frwCfgMMapper;
	@Autowired
	private FrwMsgLMapper frwMsgLMapper;
	@Autowired
	private FrwTractId frwTractId;
	@Value("${spring.application.name}")
	private String appNm;
	@Value("${system.env-cd}")
	private String envCd;
	@Value("${system.instn-id}")
	private String instnId;

	/**
	 * 
	 */
	private <VO extends Vo> void executeLocal(FrwSvcP<VO> frwSvcP, FrwMsgL frwMsgL) {
		VO vo = frwSvcP.getVo();
//		frwMsgL.setLogDttm(LocalDateTime.now());
//		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
//		frwMsgL.setSvcGuid(String.valueOf(UUID.randomUUID()));
//		frwMsgL.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(instnId), 2), 2, '0'));
		frwMsgL.setAppNm(frwSvcP.getAppNm());
		frwMsgL.setHostCd(frwSvcP.getHostCd());
		frwMsgL.setBizDvsnCd(frwSvcP.getBizDvsnCd());
		frwMsgL.setTlgKndDvsnCd(frwSvcP.getTlgKndDvsnCd()); // 전문종별구분코드
		frwMsgL.setTlgBizDvsnCd(frwSvcP.getTlgBizDvsnCd()); // 업무구분코드
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeEntComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeEntComHdr.getResponseCode1());
			frwMsgL.setHostMsgNo(cqeEntComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeEntComHdr.);
			frwMsgL.setTrnsUnqNo(cqeEntComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeEntComHdr.getBnkCd());
//			frwMsgL.setHndlMsgNo(cqeEntComHdr.);
//			frwMsgL.setKftcMsgNo(cqeEntComHdr.);
//			frwMsgL.setInitInstCd(cqeEntComHdr.);
//			frwMsgL.setInitMsgNo(cqeEntComHdr.);
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeIftComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeIftComHdr.);
			frwMsgL.setTrnsUnqNo(cqeIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeIftComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(cqeIftComHdr.);
//			frwMsgL.setKftcMsgNo(cqeIftComHdr.);
//			frwMsgL.setInitInstCd(cqeIftComHdr.);
//			frwMsgL.setInitMsgNo(cqeIftComHdr.);
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(cqeRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(cqeRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(cqeRprComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(cqeRprComHdr.);
			frwMsgL.setTrnsUnqNo(cqeRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(cqeRprComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(cqeRprComHdr.);
//			frwMsgL.setKftcMsgNo(cqeRprComHdr.);
//			frwMsgL.setInitInstCd(cqeRprComHdr.);
//			frwMsgL.setInitMsgNo(cqeRprComHdr.);
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(gchHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(gchHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(gchHofComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(gchHofComHdr.);
			frwMsgL.setTrnsUnqNo(gchHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(gchHofComHdr.getRequestBank());
//			frwMsgL.setHndlMsgNo(gchHofComHdr.);
//			frwMsgL.setKftcMsgNo(gchHofComHdr.);
//			frwMsgL.setInitInstCd(gchHofComHdr.);
//			frwMsgL.setInitMsgNo(gchHofComHdr.);
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntComHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntComHdr.getResponseCode1());
//			frwMsgL.setHostMsgNo(kftEntComHdr.);
			frwMsgL.setMsgTrckNo(kftEntComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftEntComHdr.);
//			frwMsgL.setHndlMsgNo(kftEntComHdr.);
//			frwMsgL.setKftcMsgNo(kftEntComHdr.);
//			frwMsgL.setInitInstCd(kftEntComHdr.);
//			frwMsgL.setInitMsgNo(kftEntComHdr.);
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftEntMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftEntMngHdr.getResponseCode1());
//			frwMsgL.setHostMsgNo(kftEntMngHdr.);
			frwMsgL.setMsgTrckNo(kftEntMngHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftEntMngHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftEntMngHdr.);
//			frwMsgL.setHndlMsgNo(kftEntMngHdr.);
//			frwMsgL.setKftcMsgNo(kftEntMngHdr.);
//			frwMsgL.setInitInstCd(kftEntMngHdr.);
//			frwMsgL.setInitMsgNo(kftEntMngHdr.);
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofComHdr.getMessageTransmissionDate(), kftHofComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofComHdr.);
			frwMsgL.setMsgTrckNo(kftHofComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftHofComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftHofComHdr.);
//			frwMsgL.setHndlMsgNo(kftHofComHdr.);
//			frwMsgL.setKftcMsgNo(kftHofComHdr.);
//			frwMsgL.setInitInstCd(kftHofComHdr.);
//			frwMsgL.setInitMsgNo(kftHofComHdr.);
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofMngHdr.getMessageTransmissionDate(), kftHofMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofMngHdr.);
			frwMsgL.setMsgTrckNo(kftHofMngHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftHofMngHdr.);
//			frwMsgL.setHndlInstCd(kftHofMngHdr.);
//			frwMsgL.setHndlMsgNo(kftHofMngHdr.);
//			frwMsgL.setKftcMsgNo(kftHofMngHdr.);
//			frwMsgL.setInitInstCd(kftHofMngHdr.);
//			frwMsgL.setInitMsgNo(kftHofMngHdr.);
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftHofLcrHdr.getMessageTransmissionDate(), kftHofLcrHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftHofLcrHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftHofLcrHdr.);
			frwMsgL.setMsgTrckNo(kftHofLcrHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftHofLcrHdr.);
//			frwMsgL.setHndlInstCd(kftHofLcrHdr.);
//			frwMsgL.setHndlMsgNo(kftHofLcrHdr.);
//			frwMsgL.setKftcMsgNo(kftHofLcrHdr.);
//			frwMsgL.setInitInstCd(kftHofLcrHdr.);
//			frwMsgL.setInitMsgNo(kftHofLcrHdr.);
		} else if (vo instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftComHdr.getKftcMessageTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftIftComHdr.);
//			frwMsgL.setMsgTrckNo(kftIftComHdr.);
//			frwMsgL.setTrnsUnqNo(kftIftComHdr.);
			frwMsgL.setHndlInstCd(kftIftComHdr.getRequestBankCode());
			frwMsgL.setHndlMsgNo(kftIftComHdr.getRequestMessageNumber());
			frwMsgL.setKftcMsgNo(kftIftComHdr.getKftcMessageNumber());
			frwMsgL.setInitInstCd(kftIftComHdr.getBeneficiaryBankCode());
			frwMsgL.setInitMsgNo(kftIftComHdr.getBeneficiaryMessageNumber());
		} else if (vo instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(kftIftMngHdr.getMessageSendTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(kftIftMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftIftMngHdr.);
//			frwMsgL.setMsgTrckNo(kftIftMngHdr.);
//			frwMsgL.setTrnsUnqNo(kftIftMngHdr.);
//			frwMsgL.setHndlInstCd(kftIftMngHdr.);
//			frwMsgL.setHndlMsgNo(kftIftMngHdr.);
//			frwMsgL.setKftcMsgNo(kftIftMngHdr.);
//			frwMsgL.setInitInstCd(kftIftMngHdr.);
//			frwMsgL.setInitMsgNo(kftIftMngHdr.);
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprComHdr.getMessageTransmissionDate(), kftRprComHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprComHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftRprComHdr.);
			frwMsgL.setMsgTrckNo(kftRprComHdr.getMessageTrackingNumber());
			frwMsgL.setTrnsUnqNo(kftRprComHdr.getTransactionIdNumber());
//			frwMsgL.setHndlInstCd(kftRprComHdr.);
//			frwMsgL.setHndlMsgNo(kftRprComHdr.);
//			frwMsgL.setKftcMsgNo(kftRprComHdr.);
//			frwMsgL.setInitInstCd(kftRprComHdr.);
//			frwMsgL.setInitMsgNo(kftRprComHdr.);
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			if (ObjectUtils.allNotNull(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime())) {
				frwMsgL.setTlgSndRcvDttm(LocalDateTime.of(kftRprMngHdr.getMessageTransmissionDate(), kftRprMngHdr.getMessageSendTime()));
			}
			frwMsgL.setRespCd(kftRprMngHdr.getResponseCode());
//			frwMsgL.setHostMsgNo(kftRprMngHdr.);
			frwMsgL.setMsgTrckNo(kftRprMngHdr.getMessageTrackingNumber());
//			frwMsgL.setTrnsUnqNo(kftRprMngHdr.);
//			frwMsgL.setHndlInstCd(kftRprMngHdr.);
//			frwMsgL.setHndlMsgNo(kftRprMngHdr.);
//			frwMsgL.setKftcMsgNo(kftRprMngHdr.);
//			frwMsgL.setInitInstCd(kftRprMngHdr.);
//			frwMsgL.setInitMsgNo(kftRprMngHdr.);
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbCmsComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbCmsComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbCmsComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbCmsComHdr.);
//			frwMsgL.setTrnsUnqNo(lvbCmsComHdr.);
//			frwMsgL.setHndlInstCd(lvbCmsComHdr.);
//			frwMsgL.setHndlMsgNo(lvbCmsComHdr.);
//			frwMsgL.setKftcMsgNo(lvbCmsComHdr.);
//			frwMsgL.setInitInstCd(lvbCmsComHdr.);
//			frwMsgL.setInitMsgNo(lvbCmsComHdr.);
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(frwMsgL.getLogDttm());
//			frwMsgL.setRespCd(lvbCmsComHdr.);
			frwMsgL.setHostMsgNo(lvbCmsSumHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbCmsSumHdr.);
//			frwMsgL.setTrnsUnqNo(lvbCmsSumHdr.);
//			frwMsgL.setHndlInstCd(lvbCmsSumHdr.);
//			frwMsgL.setHndlMsgNo(lvbCmsSumHdr.);
//			frwMsgL.setKftcMsgNo(lvbCmsSumHdr.);
//			frwMsgL.setInitInstCd(lvbCmsSumHdr.);
//			frwMsgL.setInitMsgNo(lvbCmsSumHdr.);
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbHofComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbHofComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbHofComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbHofComHdr.);
			frwMsgL.setTrnsUnqNo(lvbHofComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbHofComHdr.getRequestBank());
//			frwMsgL.setHndlMsgNo(lvbHofComHdr.);
//			frwMsgL.setKftcMsgNo(lvbHofComHdr.);
//			frwMsgL.setInitInstCd(lvbHofComHdr.);
//			frwMsgL.setInitMsgNo(lvbHofComHdr.);
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbIftComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbIftComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbIftComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbIftComHdr.);
			frwMsgL.setTrnsUnqNo(lvbIftComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbIftComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(lvbIftComHdr.);
//			frwMsgL.setKftcMsgNo(lvbIftComHdr.);
//			frwMsgL.setInitInstCd(lvbIftComHdr.);
//			frwMsgL.setInitMsgNo(lvbIftComHdr.);
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
			frwMsgL.setTlgSndRcvDttm(ObjectUtils.defaultIfNull(lvbRprComHdr.getSystemSendReceiveTime(), frwMsgL.getLogDttm()));
			frwMsgL.setRespCd(lvbRprComHdr.getResponseCode());
			frwMsgL.setHostMsgNo(lvbRprComHdr.getMsgNo());
//			frwMsgL.setMsgTrckNo(lvbRprComHdr.);
			frwMsgL.setTrnsUnqNo(lvbRprComHdr.getTransactionIdNumber());
			frwMsgL.setHndlInstCd(lvbRprComHdr.getRequestBankCode());
//			frwMsgL.setHndlMsgNo(lvbRprComHdr.);
//			frwMsgL.setKftcMsgNo(lvbRprComHdr.);
//			frwMsgL.setInitInstCd(lvbRprComHdr.);
//			frwMsgL.setInitMsgNo(lvbRprComHdr.);
		}		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC", "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			frwMsgL.setTractSortCd("13"); // 당발응답수신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("23"); // 타발응답수신
			}
		} else { // 요구
			frwMsgL.setTractSortCd("21"); // 타발요구수신
			if (vo instanceof CqeEntComHdr ||
				vo instanceof CqeIftComHdr ||
				vo instanceof CqeRprComHdr ||
				vo instanceof GchHofComHdr ||
				vo instanceof LvbCmsComHdr ||
				vo instanceof LvbCmsSumHdr ||
				vo instanceof LvbHofComHdr ||
				vo instanceof LvbIftComHdr ||
				vo instanceof LvbRprComHdr) {
				frwMsgL.setTractSortCd("11"); // 당발요구수신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 당발요구수신보정 ///////////////////////////////////////////////////
			if (StringUtils.equals(frwMsgL.getHostCd(), "KCG")) {
				frwMsgL.setTractSortCd("11"); // 당발요구수신
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		}
		String tractSortCd = frwMsgL.getTractSortCd();
		if (StringUtils.endsWith(tractSortCd, "3")) {
			tractSortCd = StringUtils.join(StringUtils.left(tractSortCd, 1), "2");
		}
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeEntComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(cqeRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(StringUtils.containsOnly(gchHofComHdr.getMsgNo(), '0') ?
					gchHofComHdr.getTransactionIdNumber() :
					gchHofComHdr.getMsgNo()
				), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftEntMngHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftHofLcrHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftIftComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBankCode()), 3, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestBranchCode()), 4, '0'),
//				StringUtils.leftPad(StringUtils.defaultString(kftIftComHdr.getRequestMessageNumber()), 6, '0'),
				StringUtils.substring(frwSvcP.getTlgCtt(), 23, 36),
			tractSortCd));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 수취조회보정 ///////////////////////////////////////////////////////
			if (StringUtils.startsWith(frwMsgL.getTlgKndDvsnCd(), "02") &&
				StringUtils.startsWith(frwMsgL.getTlgBizDvsnCd(), "500")) {
				frwMsgL.setTractId(StringUtils.join(StringUtils.left(frwMsgL.getTractId(), 25),
				StringUtils.substring(frwSvcP.getTlgCtt(), 94, 107), // 수취조회번호
				StringUtils.right(frwMsgL.getTractId(), 2)));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (vo instanceof KftIftMngHdr) { // 관리전문
			frwMsgL.setTractId(frwTractId.newTractId(
				frwMsgL.getLogDttm(),
				frwMsgL.getAppNm(),
				frwMsgL.getHostCd(),
				frwMsgL.getBizDvsnCd(),
				frwMsgL.getTlgKndDvsnCd(),
				frwMsgL.getTlgBizDvsnCd(),
			tractSortCd));
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprComHdr.getTransactionIdNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(kftRprMngHdr.getMessageTrackingNumber()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"EB99",
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbCmsSumHdr lvbCmsSumHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgKndDvsnCd()), 4, '0'),
				"000000",
				StringUtils.leftPad(StringUtils.defaultString(lvbCmsSumHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbHofComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbIftComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTractId(StringUtils.join(StringUtils.right(frwMsgL.getLogDt(), 6),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getAppNm()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getHostCd()), 3, 'X'),
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getBizDvsnCd()), 3, 'X'),
				"0", StringUtils.defaultIfEmpty(StringUtils.right(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 2), 1), "0"), "00",
				StringUtils.rightPad(StringUtils.defaultString(frwMsgL.getTlgBizDvsnCd()), 6, '0'),
				StringUtils.leftPad(StringUtils.defaultString(lvbRprComHdr.getMsgNo()), 13, '0'),
			tractSortCd));
		}
		Map<String, String> tlgHdr = frwSvcP.getTlgHdr();
		frwMsgL.setOrgnTractId(StringUtils.defaultIfEmpty(tlgHdr.get("ORGN_TRACT_ID"), frwMsgL.getTractId()));
		frwMsgL.setFrstTractId(StringUtils.defaultIfEmpty(tlgHdr.get("FRST_TRACT_ID"), frwMsgL.getTractId()));
		frwMsgL.setUsrId(StringUtils.defaultIfEmpty(tlgHdr.get("USR_ID"), StringUtils.join(frwMsgL.getAppNm(), "SYS")));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 시뮬레이터처리 /////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC", "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
		} else { // 요구
			if (StringUtils.equals(tlgHdr.get("SIM_YN"), "Y")) {
				frwMsgL.setUsrId("SIMSYS");
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwMsgL.setCrltnId(frwSvcP.getCrltnId());
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
		if (StringUtils.isEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
			if (StringUtils.isAlpha(frwMsgL.getTlgLaytId())) {
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
			}
		}
		frwMsgL.setTlgCtt(frwSvcP.getTlgCtt());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 컨텍스트복구 ///////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC", "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			FrwMsgL tmpMsgL = frwMapper.selectFrwMsgL(frwMsgL.getTractId());
			if (null != tmpMsgL) {
				log.debug("{}", tmpMsgL);
				frwMsgL.setHostMsgNo(StringUtils.defaultIfEmpty(frwMsgL.getHostMsgNo(), tmpMsgL.getHostMsgNo()));
				frwMsgL.setMsgTrckNo(StringUtils.defaultIfEmpty(frwMsgL.getMsgTrckNo(), tmpMsgL.getMsgTrckNo()));
				frwMsgL.setTrnsUnqNo(StringUtils.defaultIfEmpty(frwMsgL.getTrnsUnqNo(), tmpMsgL.getTrnsUnqNo()));
				frwMsgL.setHndlInstCd(StringUtils.defaultIfEmpty(frwMsgL.getHndlInstCd(), tmpMsgL.getHndlInstCd()));
				frwMsgL.setHndlMsgNo(StringUtils.defaultIfEmpty(frwMsgL.getHndlMsgNo(), tmpMsgL.getHndlMsgNo()));
				frwMsgL.setKftcMsgNo(StringUtils.defaultIfEmpty(frwMsgL.getKftcMsgNo(), tmpMsgL.getKftcMsgNo()));
				frwMsgL.setInitInstCd(StringUtils.defaultIfEmpty(frwMsgL.getInitInstCd(), tmpMsgL.getInitInstCd()));
				frwMsgL.setInitMsgNo(StringUtils.defaultIfEmpty(frwMsgL.getInitMsgNo(), tmpMsgL.getInitMsgNo()));
//				frwMsgL.setTractSortCd(tmpMsgL.getTractSortCd());
//				frwMsgL.setTractId(tmpMsgL.getTractId());
				frwMsgL.setOrgnTractId(StringUtils.defaultIfEmpty(tmpMsgL.getOrgnTractId(), frwMsgL.getOrgnTractId()));
				frwMsgL.setFrstTractId(StringUtils.defaultIfEmpty(tmpMsgL.getFrstTractId(), frwMsgL.getFrstTractId()));
				frwMsgL.setUsrId(StringUtils.defaultIfEmpty(tmpMsgL.getUsrId(), frwMsgL.getUsrId()));
			}
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//		frwMsgL.setStckTrc();
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		frwMsgL.setFrstChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setLastChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 컨텍스트설정 ///////////////////////////////////////////////////////////
		FrwContextImpl frwContextImpl = new FrwContextImpl();
		frwContextImpl.setSysDt(frwMsgL.getLogDt());
		frwContextImpl.setSysTmstmp(frwMsgL.getLogDttm());
		frwContextImpl.setEnvCd(StringUtils.left(StringUtils.upperCase(envCd), 1));
		frwContextImpl.setSvcGuid(frwMsgL.getSvcGuid());
		frwContextImpl.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(instnId), 2), 2, '0'));
		frwContextImpl.setAppNm(frwSvcP.getAppNm());
		frwContextImpl.setHostCd(frwSvcP.getHostCd());
		frwContextImpl.setBizDvsnCd(frwSvcP.getBizDvsnCd());
		frwContextImpl.setTlgKndDvsnCd(frwMsgL.getTlgKndDvsnCd()); // 전문종별구분코드
		frwContextImpl.setTlgBizDvsnCd(frwMsgL.getTlgBizDvsnCd()); // 업무구분코드
		frwContextImpl.setTlgSndRcvDttm(frwMsgL.getTlgSndRcvDttm());
		frwContextImpl.setRespCd(frwMsgL.getRespCd());
		frwContextImpl.setHostMsgNo(frwMsgL.getHostMsgNo());
		frwContextImpl.setMsgTrckNo(frwMsgL.getMsgTrckNo());
		frwContextImpl.setTrnsUnqNo(frwMsgL.getTrnsUnqNo());
		frwContextImpl.setHndlInstCd(frwMsgL.getHndlInstCd());
		frwContextImpl.setHndlMsgNo(frwMsgL.getHndlMsgNo());
		frwContextImpl.setKftcMsgNo(frwMsgL.getKftcMsgNo());
		frwContextImpl.setTractSortCd(frwMsgL.getTractSortCd());
		frwContextImpl.setTractId(frwMsgL.getTractId());
		frwContextImpl.setOrgnTractId(frwMsgL.getOrgnTractId());
		frwContextImpl.setFrstTractId(frwMsgL.getFrstTractId());
		frwContextImpl.setUsrId(frwMsgL.getUsrId());
		frwContextImpl.setCrltnId(frwMsgL.getCrltnId());
		frwContextImpl.setTlgCtt(frwMsgL.getTlgCtt());
		frwContextImpl.setOrgnTlgCtt(frwMsgL.getTlgCtt());
		frwContextImpl.setTlgHdr(Collections.unmodifiableMap(frwSvcP.getTlgHdr()));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 원전문복구 /////////////////////////////////////////////////////////////
		if (StringUtils.startsWithAny(frwMsgL.getTlgKndDvsnCd(), "EB", "EC", "9") ||
			StringUtils.endsWith(StringUtils.left(frwMsgL.getTlgKndDvsnCd(), 3), "1")) { // 응답
			FrwMsgL tmpMsgL = frwMapper.selectFrwMsgL(frwMsgL.getOrgnTractId());
			if (null != tmpMsgL) {
				log.debug("{}", tmpMsgL);
				frwContextImpl.setCrltnId(tmpMsgL.getCrltnId());
				frwContextImpl.setOrgnTlgCtt(tmpMsgL.getTlgCtt());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 테스트보정 /////////////////////////////////////////////////////////
			if (StringUtils.isNotEmpty(frwSvcP.getOrgnTlgCtt())) {
				frwContextImpl.setOrgnTlgCtt(frwSvcP.getOrgnTlgCtt());
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		log.debug("{}", frwContextImpl);
		FrwContextHolder.setContext(frwContextImpl);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		MDC.clear();
		MDC.put("X-GUID", frwMsgL.getSvcGuid());
		MDC.put("X-LOG-LEVEL", StringUtils.defaultIfEmpty(frwSvcP.getLogLvl(), String.valueOf(LogLevel.DEBUG)));
		log.debug("{}", frwMsgL);
		FrwService<VO> frwService = frwSvcP.getFrwService();
		try {
			frwExecutor.nested(() -> {
				frwService.execute(vo);
			});
		} catch (Throwable t) {
			log.error(ExceptionUtils.getRootCauseMessage(t), t);
			frwService.handleError(vo, t);
		} finally {
			MDC.clear();
			FrwContextHolder.clearContext();
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public <VO extends Vo> void execute(Message message) {
		log.debug("{}", message);
		Map<String, String> tlgHdr = frwCfgMMapper.selectAll().stream()
		.collect(Collectors.toMap(FrwCfgM::getCfgKey, FrwCfgM::getCfgVal, ObjectUtils::defaultIfNull, TreeMap::new));
		String crltnId = null;
		String tlgCtt = null;
		try {
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 최대배달횟수초과처리 ///////////////////////////////////////////////
			int dlvrCnt = message.getIntProperty(WMQConstants.JMSX_DELIVERY_COUNT);
			if (NumberUtils.toInt(tlgHdr.get("MAX_DLVR_CNT"), 1) < dlvrCnt) {
				log.warn("dlvrCnt = {}", dlvrCnt);
				return;
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 전문헤더처리 ///////////////////////////////////////////////////////
			Enumeration<?> enumeration = message.getPropertyNames();
			while (enumeration.hasMoreElements()) {
				String string = (String) enumeration.nextElement();
				if (StringUtils.startsWith(string, "USRX_")) {
					tlgHdr.put(StringUtils.removeStart(string, "USRX_"), message.getStringProperty(string));
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 연관ID처리 /////////////////////////////////////////////////////////
			crltnId = message.getJMSCorrelationID();
			if (36 != StringUtils.length(crltnId)) { // 연관ID필터링
				crltnId = null;
			}
			log.debug("crltnId = {}", crltnId);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			tlgCtt = ((TextMessage) message).getText();
			log.info("<{}]", tlgCtt);
		} catch (JMSException e) {
			throw JmsUtils.convertJmsAccessException(e);
		}
		FrwMsgL frwMsgL = new FrwMsgL();
		frwMsgL.setLogDttm(LocalDateTime.now());
		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		frwMsgL.setSvcGuid(String.valueOf(UUID.randomUUID()));
		frwMsgL.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(instnId), 2), 2, '0'));
		frwMsgL.setAppNm(StringUtils.right(StringUtils.upperCase(appNm), 3));
		frwMsgL.setHostCd("KFT");
		if (StringUtils.startsWithAny(tlgCtt, "CQE", "GCH", "KCG", "KIB", "LVB")) { // 호스트
			frwMsgL.setHostCd(StringUtils.left(tlgCtt, 3));
			if (StringUtils.startsWith(tlgCtt, "KCG")) {
				frwMsgL.setHostCd(StringUtils.right(StringUtils.left(tlgCtt, 6), 3));
			}
		}
		frwMsgL.setBizDvsnCd(frwMsgL.getAppNm());
		if (StringUtils.equals(frwMsgL.getAppNm(), "CMS")) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			if (StringUtils.endsWithAny(StringUtils.left(tlgCtt, 30), "EB", "EC")) {
				frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 28, 32)); // 전문종별구분코드
			}
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
		} else if (StringUtils.startsWithAny(tlgCtt, "CQE", "GCH", "KCG", "KIB", "LVB")) { // 호스트
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 28, 32)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 32, 38)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 업무구분코드보정 ///////////////////////////////////////////////////
			if (StringUtils.startsWith(frwMsgL.getTlgBizDvsnCd(), "000")) { // IFT
				frwMsgL.setTlgBizDvsnCd(StringUtils.right(frwMsgL.getTlgBizDvsnCd(), 3)); // 업무구분코드
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (StringUtils.equals(frwMsgL.getAppNm(), "ENT")) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 10, 14)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 14, 20)); // 업무구분코드
		} else if (StringUtils.equals(frwMsgL.getAppNm(), "HOF")) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 10, 14)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 14, 20)); // 업무구분코드
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 순이체한도보정 /////////////////////////////////////////////////////
			if (StringUtils.endsWith(StringUtils.left(tlgCtt, 10), "LCS")) {
				frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 13, 17)); // 전문종별구분코드
				frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 17, 23)); // 업무구분코드
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		} else if (StringUtils.equals(frwMsgL.getAppNm(), "RPR")) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 10, 14)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 14, 20)); // 업무구분코드
		} else if (StringUtils.equals(frwMsgL.getAppNm(), "IFT")) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(tlgCtt, 12, 16)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(tlgCtt, 16, 19)); // 업무구분코드
		}
//		frwMsgL.setRespCd();
//		frwMsgL.setHostMsgNo();
//		frwMsgL.setMsgTrckNo();
//		frwMsgL.setTrnsUnqNo();
//		frwMsgL.setHndlInstCd();
//		frwMsgL.setHndlMsgNo();
//		frwMsgL.setKftcMsgNo();
//		frwMsgL.setInitInstCd();
//		frwMsgL.setInitMsgNo();
//		frwMsgL.setTractSortCd();
		frwMsgL.setTractId(frwTractId.newTractId(frwMsgL.getLogDttm()));
		frwMsgL.setOrgnTractId(frwMsgL.getTractId());
		frwMsgL.setFrstTractId(frwMsgL.getTractId());
		frwMsgL.setUsrId(StringUtils.join(frwMsgL.getAppNm(), "SYS"));
//		frwMsgL.setCrltnId();
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////// 전문정보강제보정 ///////////////////////////////////////////////////////
		if (StringUtils.isNotEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setHostCd(StringUtils.left(frwMsgL.getTlgLaytId(), 3));
			frwMsgL.setBizDvsnCd(StringUtils.substring(frwMsgL.getTlgLaytId(), 3, 6));
			frwMsgL.setTlgKndDvsnCd(StringUtils.substring(frwMsgL.getTlgLaytId(), 6, 10)); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.substring(frwMsgL.getTlgLaytId(), 10)); // 업무구분코드
		}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
		frwMsgL.setTlgCtt(tlgCtt);
//		frwMsgL.setStckTrc();
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		frwMsgL.setFrstChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setLastChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
		try {
			String tlgKndDvsnCd = frwMsgL.getTlgKndDvsnCd();
			String tlgBizDvsnCd = frwMsgL.getTlgBizDvsnCd();
			if (StringUtils.startsWithAny(tlgKndDvsnCd, "EB", "EC")) {
				tlgBizDvsnCd = "000000";
			} else {
				tlgKndDvsnCd = StringUtils.join(StringUtils.left(tlgKndDvsnCd, 3), "0");
			}
			FrwSvcP<VO> frwSvcP = frwMapper.selectFrwSvcM(
				frwMsgL.getAppNm(),
				frwMsgL.getHostCd(),
				frwMsgL.getBizDvsnCd(),
				tlgKndDvsnCd,
				tlgBizDvsnCd,
			"Y");
			if (null == frwSvcP) {
				throw new UnsupportedOperationException(StringUtils.joinWith(", ",
					frwMsgL.getAppNm(),
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					tlgKndDvsnCd,
					tlgBizDvsnCd
				));
			}
			log.debug("{}", frwSvcP);
			FrwService<VO> frwService = applicationContext.getBean(Introspector.decapitalize(frwSvcP.getSvcBeanNm()), FrwService.class);
			log.debug("frwService = {}", frwService);
			ParameterizedType parameterizedType = (ParameterizedType) frwService.getClass().getGenericSuperclass();
			log.debug("parameterizedType = {}", parameterizedType);
			Class<VO> voClass = (Class<VO>) parameterizedType.getActualTypeArguments()[0];
			log.debug("voClass = {}", voClass);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 일자강제보정 ///////////////////////////////////////////////////////
			if (StringUtils.startsWithAny(StringUtils.left(StringUtils.upperCase(envCd), 1), "D", "T", "U")) { // 개발 | 테스트
				if (StringUtils.startsWithAny(tlgCtt, "CQE", "GCH", "KCG", "KIB", "LVB")) { // 호스트
					if (StringUtils.equals(tlgHdr.get("FRCV_DT_USE_YN"), "Y") ||
						StringUtils.equals(tlgHdr.get("FSND_DT_USE_YN"), "Y") ||
						StringUtils.equals(tlgHdr.get("ORGN_DT_USE_YN"), "Y") ||
						StringUtils.equals(tlgHdr.get("RQST_DT_USE_YN"), "Y") ||
						StringUtils.equals(tlgHdr.get("TEMP_DT_USE_YN"), "Y") ||
						StringUtils.equals(tlgHdr.get("TEST_DT_USE_YN"), "Y")) {
						for (FrwDtMgmtM frwDtMgmtM : frwMapper.selectFrwDtMgmtM(StringUtils.join(
							frwMsgL.getHostCd(),
							frwMsgL.getBizDvsnCd(),
							frwMsgL.getTlgKndDvsnCd(),
							frwMsgL.getTlgBizDvsnCd()
						))) {
							String dtDvsnCd = frwDtMgmtM.getDtDvsnCd();
							if (StringUtils.equals(dtDvsnCd, "FRCV") && StringUtils.equals(tlgHdr.get("FRCV_DT_USE_YN"), "Y") ||
								StringUtils.equals(dtDvsnCd, "FSND") && StringUtils.equals(tlgHdr.get("FSND_DT_USE_YN"), "Y") ||
								StringUtils.equals(dtDvsnCd, "ORGN") && StringUtils.equals(tlgHdr.get("ORGN_DT_USE_YN"), "Y") ||
								StringUtils.equals(dtDvsnCd, "RQST") && StringUtils.equals(tlgHdr.get("RQST_DT_USE_YN"), "Y") ||
								StringUtils.equals(dtDvsnCd, "TEMP") && StringUtils.equals(tlgHdr.get("TEMP_DT_USE_YN"), "Y") ||
								StringUtils.equals(dtDvsnCd, "TEST") && StringUtils.equals(tlgHdr.get("TEST_DT_USE_YN"), "Y")) {
								String dtPrcs = tlgHdr.get(frwDtMgmtM.getDtPrcsCd());
								int fldLen  = frwDtMgmtM.getFldLen ().intValue();
								int fldPstn = frwDtMgmtM.getFldPstn().intValue();
								if (StringUtils.equalsAny(dtDvsnCd, "ORGN", "TEST")) {
									dtPrcs = frwMsgL.getLogDt();
								}
								if ( 6 == fldLen ||
									12 == fldLen) {
									dtPrcs = StringUtils.right(dtPrcs, 6);
								}
								if (StringUtils.equalsAny(dtDvsnCd, "FRCV", "FSND")) {
									dtPrcs = StringUtils.right(dtPrcs, 4);
									fldPstn += fldLen - 4;
								}
								byte[] byteArray = StringUtils.getBytes(tlgCtt, Charsets.toCharset("EUC-KR"));
								byte[] tempArray = StringUtils.getBytes(dtPrcs, Charsets.toCharset("EUC-KR"));
								System.arraycopy(tempArray, 0, byteArray, fldPstn, tempArray.length);
								tlgCtt = StringUtils.toEncodedString(byteArray, Charsets.toCharset("EUC-KR"));
							}
						}
						log.debug("[{}]", tlgCtt);
					}
				}
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			VO vo = VOUtils.toVo(tlgCtt, voClass);
			log.debug("{}", vo);
			frwSvcP.setFrwService(frwService);
			frwSvcP.setVo(vo);
			frwSvcP.setCrltnId(crltnId);
			frwSvcP.setTlgCtt(tlgCtt);
//			frwSvcP.setOrgnTlgCtt();
			frwSvcP.setTlgHdr(tlgHdr);
			log.debug("{}", frwSvcP);
			executeLocal(frwSvcP, frwMsgL);
//			frwMsgL.setStckTrc();
			frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		} catch (Throwable t) {
			frwMsgL.setStckTrc(ExceptionUtils.getStackTrace(t));
			frwMsgL.setExitCd(NumberUtils.INTEGER_MINUS_ONE);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// SQL오류코드처리 ////////////////////////////////////////////////////
			SQLException sqlException = ExceptionUtils.throwableOfType(t, SQLException.class);
			if ((null != sqlException)) {
				frwMsgL.setExitCd(Integer.valueOf(sqlException.getErrorCode()));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			ExceptionUtils.wrapAndThrow(t);
		} finally {
			frwExecutor.requiresNew(() -> {
				log.debug("{}", frwMsgL);
				frwMsgLMapper.insert(frwMsgL);
			});
		}
	}

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public <VO extends Vo> void execute(VO vo, VO orgnVo, Map<String, String> tlgHdr) {
		log.debug("{}", vo);
		String tlgCtt = VOUtils.toString(vo);
		log.info("<{}]", tlgCtt);
		ResolvableType resolvableType = ResolvableType.forClassWithGenerics(FrwService.class, vo.getClass());
		log.debug("resolvableType = {}", resolvableType);
		FrwService<VO> frwService = (FrwService<VO>) applicationContext.getBeanProvider(resolvableType).getObject();
		log.debug("frwService = {}", frwService);
		FrwMsgL frwMsgL = new FrwMsgL();
		frwMsgL.setLogDttm(LocalDateTime.now());
		frwMsgL.setLogDt(frwMsgL.getLogDttm().format(DateTimeFormatter.ofPattern("yyyyMMdd")));
		frwMsgL.setSvcGuid(String.valueOf(UUID.randomUUID()));
		frwMsgL.setInstnId(StringUtils.leftPad(StringUtils.right(StringUtils.defaultString(instnId), 2), 2, '0'));
		frwMsgL.setAppNm(StringUtils.right(StringUtils.upperCase(appNm), 3));
		frwMsgL.setHostCd(StringUtils.left(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3));
		frwMsgL.setBizDvsnCd(StringUtils.substring(StringUtils.upperCase(ClassUtils.getSimpleName(vo)), 3, 6));
		frwMsgL.setTlgKndDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 6, 10)); // 전문종별구분코드
		frwMsgL.setTlgBizDvsnCd(StringUtils.substring(ClassUtils.getSimpleName(vo), 10)); // 업무구분코드
		if (vo instanceof CqeEntComHdr cqeEntComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof CqeIftComHdr cqeIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof CqeRprComHdr cqeRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(cqeRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof GchHofComHdr gchHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(gchHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftEntComHdr kftEntComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntComHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftEntMngHdr kftEntMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftEntMngHdr.getTransactionCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftHofComHdr kftHofComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftHofMngHdr kftHofMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftHofLcrHdr kftHofLcrHdr) { // 순이체한도
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftHofLcrHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftIftComHdr kftIftComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftIftMngHdr kftIftMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftIftMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftRprComHdr kftRprComHdr) { // 업무처리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof KftRprMngHdr kftRprMngHdr) { // 관리전문
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(kftRprMngHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof LvbCmsComHdr lvbCmsComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbCmsComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
		} else if (vo instanceof LvbCmsSumHdr) {
			frwMsgL.setTlgKndDvsnCd("EB00"); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(""); // 업무구분코드
		} else if (vo instanceof LvbHofComHdr lvbHofComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbHofComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof LvbIftComHdr lvbIftComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbIftComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		} else if (vo instanceof LvbRprComHdr lvbRprComHdr) {
			frwMsgL.setTlgKndDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageType(), frwMsgL.getTlgKndDvsnCd())); // 전문종별구분코드
			frwMsgL.setTlgBizDvsnCd(StringUtils.defaultIfEmpty(lvbRprComHdr.getMessageCode(), frwMsgL.getTlgBizDvsnCd())); // 업무구분코드
		}
//		frwMsgL.setRespCd();
//		frwMsgL.setHostMsgNo();
//		frwMsgL.setMsgTrckNo();
//		frwMsgL.setTrnsUnqNo();
//		frwMsgL.setHndlInstCd();
//		frwMsgL.setHndlMsgNo();
//		frwMsgL.setKftcMsgNo();
//		frwMsgL.setInitInstCd();
//		frwMsgL.setInitMsgNo();
//		frwMsgL.setTractSortCd();
		frwMsgL.setTractId(frwTractId.newTractId(frwMsgL.getLogDttm()));
		frwMsgL.setOrgnTractId(frwMsgL.getTractId());
		frwMsgL.setFrstTractId(frwMsgL.getTractId());
		frwMsgL.setUsrId(StringUtils.join(frwMsgL.getAppNm(), "SYS"));
//		frwMsgL.setCrltnId();
		frwMsgL.setTlgLaytId(tlgHdr.get("TLG_LAYT_ID"));
		if (StringUtils.isEmpty(frwMsgL.getTlgLaytId())) {
			frwMsgL.setTlgLaytId(StringUtils.upperCase(ClassUtils.getSimpleName(vo)));
			if (StringUtils.isAlpha(frwMsgL.getTlgLaytId())) {
				frwMsgL.setTlgLaytId(StringUtils.join(
					frwMsgL.getHostCd(),
					frwMsgL.getBizDvsnCd(),
					frwMsgL.getTlgKndDvsnCd(),
					frwMsgL.getTlgBizDvsnCd()
				));
			}
		}
		frwMsgL.setTlgCtt(tlgCtt);
//		frwMsgL.setStckTrc();
//		frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		frwMsgL.setFrstChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setFrstChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setFrstChngTmstmp(frwMsgL.getLogDttm());
		frwMsgL.setLastChngGuid(frwMsgL.getSvcGuid());
		frwMsgL.setLastChngStaffId(frwMsgL.getUsrId());
		frwMsgL.setLastChngTmstmp(frwMsgL.getLogDttm());
		try {
			String tlgKndDvsnCd = frwMsgL.getTlgKndDvsnCd();
			String tlgBizDvsnCd = frwMsgL.getTlgBizDvsnCd();
			if (StringUtils.startsWithAny(tlgKndDvsnCd, "EB", "EC")) {
				tlgBizDvsnCd = "000000";
			} else {
				tlgKndDvsnCd = StringUtils.join(StringUtils.left(tlgKndDvsnCd, 3), "0");
			}
			FrwSvcP<VO> frwSvcP = frwMapper.selectFrwSvcM(
				frwMsgL.getAppNm(),
				frwMsgL.getHostCd(),
				frwMsgL.getBizDvsnCd(),
				tlgKndDvsnCd,
				tlgBizDvsnCd,
			"Y");
			if (null == frwSvcP) {
				frwSvcP = new FrwSvcP<>();
				frwSvcP.setAppNm(frwMsgL.getAppNm());
				frwSvcP.setHostCd(frwMsgL.getHostCd());
				frwSvcP.setBizDvsnCd(frwMsgL.getBizDvsnCd());
				frwSvcP.setTlgKndDvsnCd(tlgKndDvsnCd);
				frwSvcP.setTlgBizDvsnCd(tlgBizDvsnCd);
				frwSvcP.setSvcBeanNm(StringUtils.substringBefore(ClassUtils.getSimpleName(frwService), '$'));
				frwSvcP.setSvcNm(frwSvcP.getSvcBeanNm());
				frwSvcP.setLogLvl(String.valueOf(LogLevel.DEBUG));
				frwSvcP.setUseYn("Y");
			}
			frwSvcP.setFrwService(frwService);
			frwSvcP.setVo(vo);
//			frwSvcP.setCrltnId();
			frwSvcP.setTlgCtt(tlgCtt);
//			frwSvcP.setOrgnTlgCtt();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// 원전문보정 /////////////////////////////////////////////////////////
			if (null != orgnVo) {
				frwSvcP.setOrgnTlgCtt(VOUtils.toString(orgnVo));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			frwSvcP.setTlgHdr(tlgHdr);
			log.debug("{}", frwSvcP);
			executeLocal(frwSvcP, frwMsgL);
//			frwMsgL.setStckTrc();
			frwMsgL.setExitCd(NumberUtils.INTEGER_ZERO);
		} catch (Throwable t) {
			frwMsgL.setStckTrc(ExceptionUtils.getStackTrace(t));
			frwMsgL.setExitCd(NumberUtils.INTEGER_MINUS_ONE);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////// SQL오류코드처리 ////////////////////////////////////////////////////
			SQLException sqlException = ExceptionUtils.throwableOfType(t, SQLException.class);
			if ((null != sqlException)) {
				frwMsgL.setExitCd(Integer.valueOf(sqlException.getErrorCode()));
			}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
			ExceptionUtils.wrapAndThrow(t);
		} finally {
			frwExecutor.requiresNew(() -> {
				log.debug("{}", frwMsgL);
				frwMsgLMapper.insert(frwMsgL);
			});
		}
	}

	/**
	 * 
	 */
	public <VO extends Vo> void execute(VO vo, VO orgnVo) {
		execute(vo, orgnVo, Map.of());
	}

	/**
	 * 
	 */
	public <VO extends Vo> void execute(VO vo, Map<String, String> tlgHdr) {
		execute(vo, null, tlgHdr);
	}

	/**
	 * 
	 */
	public <VO extends Vo> void execute(VO vo) {
		execute(vo, Map.of());
	}

}
