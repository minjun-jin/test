package com.jpmc.kcg.web.sim.service;

import org.springframework.stereotype.Service;

import com.jpmc.kcg.web.sim.dto.SimCmsSndRcvFileL;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CmsSimDataSvc {
	
	public SimCmsSndRcvFileL saveCmsSimData(SimCmsSndRcvFileL svcIn) {
		
		
		
		return null;
		
	}

}
