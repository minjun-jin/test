package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 지급제시결과보고 통지 응답
 * <pre>{@code
 * msgType 메시지구분 CQEKCG
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 270000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * paymentPresentationDate 지급제시일자 
 * paymentPresentationNumber 지급제시번호 
 * settlementProcessSort 결제처리구분 
 * eNoteNumber 전자어음번호 
 * eNoteType 어음종류 
 * eNoteIssueDate 전자어음발행일자 
 * eNoteIssuePlace 전자어음발행지 
 * eNoteAmount 전자어음금액 1,2,3
 * eNoteMaturedDate 전자어음만기일자 
 * paymentBankAndBranchCode 지급은행및지점코드 
 * paymentBranchClearingHouseCode 지급점포교환소코드 
 * issuerIndvCorpSort 발행인-개인법인구분 
 * issuerBusinessResidentRegistrationNumber 발행인-사업자(주민)등록번호 
 * issuerCorpName 발행인-법인명 1,2,3
 * issuerNameRepresentativeName 발행인-성명(대표자명) 
 * issuerAddress 발행인-주소 
 * issuerCurrentAccountNumber 발행인-당좌계좌번호 
 * recipientCorpIndvSort 소지인법인개인구분 
 * recipientBusinessResidentRegistrationNumber 소지인사업자(주민)등록번호 
 * recipientCorpName 소지인법인명 
 * recipientNameRepresentative 소지인성명(대표자명) Y,N,P
 * recipientAddress 소지인주소 
 * recipientBankCode 소지인은행코드 
 * recipientDepositAccountNumber 소지인입금계좌번호 
 * recipientSpliteNoteAmount 소지인(분할된)전자어음금액 
 * recipientSplitNumber 소지인분할번호 
 * recipientEndorsementNumber 소지인배서번호 
 * eNoteMaturedSettlementDateTime 전자어음만기결제일시 Y,N
 * defaultDate 부도일 Y,N
 * defaultReasoneNoteDefaultReason 부도사유-전자어음부도사유 
 * defaultReasonAccidentReportReason 부도사유-사고신고서사유 
 * defaultReasonPaymentSuspensionProvisionalDisposition 부도사유-지급정지가처분 
 * defaultReasonSpecialDeposit 부도사유-별단예금입금 
 * defaultReasonBankManagementCompanyYn 부도사유-은행관리기업여부 
 * defaultReasonRestructuringTargetCompanyYn 부도사유-구조조정대상기업여부 Y,N,P
 * defaultReasonDepositShortageCause 부도사유-예금부족원인 
 * defaultDepositDateTime 부도입금-입금일시 
 * defaultDepositBankAndBranchCode 부도입금-입금은행및지점코드 
 * defaultReasonChangeYn 부도사유변경여부 
 * beforeChangeeNoteDefaultReason 변경전전자어음부도사유 
 * afterChangeeNoteDefaultReason 변경후전자어음부도사유 
 * reportingInstitutionSort 보고기관구분 
 * filler2 FILLER2 
 * 
 * CqeEnt0210270000 cqeEnt0210270000 = new CqeEnt0210270000(); // 지급제시결과보고 통지 응답
 * cqeEnt0210270000.setMsgType("KCGCQE"); // 메시지구분
 * cqeEnt0210270000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0210270000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0210270000.setMessageType("0210"); // 전문종별코드
 * cqeEnt0210270000.setTransactionCode("270000"); // 거래구분코드
 * cqeEnt0210270000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0210270000.setBnkCd("057"); // 은행코드
 * cqeEnt0210270000.setResponseCode1("000"); // 응답코드1
 * cqeEnt0210270000.setResponseCode2(""); // 응답코드2
 * cqeEnt0210270000.setFiller(""); // FILLER
 * cqeEnt0210270000.setPaymentPresentationDate(""); // 지급제시일자
 * cqeEnt0210270000.setPaymentPresentationNumber(""); // 지급제시번호
 * cqeEnt0210270000.setSettlementProcessSort(""); // 결제처리구분
 * cqeEnt0210270000.setENoteNumber(""); // 전자어음번호
 * cqeEnt0210270000.setENoteType(""); // 어음종류
 * cqeEnt0210270000.setENoteIssueDate(""); // 전자어음발행일자
 * cqeEnt0210270000.setENoteIssuePlace(""); // 전자어음발행지
 * cqeEnt0210270000.setENoteAmount(0L); // 전자어음금액
 * cqeEnt0210270000.setENoteMaturedDate(""); // 전자어음만기일자
 * cqeEnt0210270000.setPaymentBankAndBranchCode(""); // 지급은행및지점코드
 * cqeEnt0210270000.setPaymentBranchClearingHouseCode(""); // 지급점포교환소코드
 * cqeEnt0210270000.setIssuerIndvCorpSort(""); // 발행인-개인법인구분
 * cqeEnt0210270000.setIssuerBusinessResidentRegistrationNumber(""); // 발행인-사업자(주민)등록번호
 * cqeEnt0210270000.setIssuerCorpName(""); // 발행인-법인명
 * cqeEnt0210270000.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * cqeEnt0210270000.setIssuerAddress(""); // 발행인-주소
 * cqeEnt0210270000.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * cqeEnt0210270000.setRecipientCorpIndvSort(""); // 소지인법인개인구분
 * cqeEnt0210270000.setRecipientBusinessResidentRegistrationNumber(""); // 소지인사업자(주민)등록번호
 * cqeEnt0210270000.setRecipientCorpName(""); // 소지인법인명
 * cqeEnt0210270000.setRecipientNameRepresentative(""); // 소지인성명(대표자명)
 * cqeEnt0210270000.setRecipientAddress(""); // 소지인주소
 * cqeEnt0210270000.setRecipientBankCode(""); // 소지인은행코드
 * cqeEnt0210270000.setRecipientDepositAccountNumber(""); // 소지인입금계좌번호
 * cqeEnt0210270000.setRecipientSpliteNoteAmount(0L); // 소지인(분할된)전자어음금액
 * cqeEnt0210270000.setRecipientSplitNumber(""); // 소지인분할번호
 * cqeEnt0210270000.setRecipientEndorsementNumber(""); // 소지인배서번호
 * cqeEnt0210270000.setENoteMaturedSettlementDateTime(LocalDateTime.now()); // 전자어음만기결제일시
 * cqeEnt0210270000.setDefaultDate(""); // 부도일
 * cqeEnt0210270000.setDefaultReasoneNoteDefaultReason(""); // 부도사유-전자어음부도사유
 * cqeEnt0210270000.setDefaultReasonAccidentReportReason(""); // 부도사유-사고신고서사유
 * cqeEnt0210270000.setDefaultReasonPaymentSuspensionProvisionalDisposition(""); // 부도사유-지급정지가처분
 * cqeEnt0210270000.setDefaultReasonSpecialDeposit(""); // 부도사유-별단예금입금
 * cqeEnt0210270000.setDefaultReasonBankManagementCompanyYn(""); // 부도사유-은행관리기업여부
 * cqeEnt0210270000.setDefaultReasonRestructuringTargetCompanyYn(""); // 부도사유-구조조정대상기업여부
 * cqeEnt0210270000.setDefaultReasonDepositShortageCause(""); // 부도사유-예금부족원인
 * cqeEnt0210270000.setDefaultDepositDateTime(LocalDateTime.now()); // 부도입금-입금일시
 * cqeEnt0210270000.setDefaultDepositBankAndBranchCode(""); // 부도입금-입금은행및지점코드
 * cqeEnt0210270000.setDefaultReasonChangeYn(""); // 부도사유변경여부
 * cqeEnt0210270000.setBeforeChangeeNoteDefaultReason(""); // 변경전전자어음부도사유
 * cqeEnt0210270000.setAfterChangeeNoteDefaultReason(""); // 변경후전자어음부도사유
 * cqeEnt0210270000.setReportingInstitutionSort(""); // 보고기관구분
 * cqeEnt0210270000.setFiller2(""); // FILLER2
 * }</pre>
 */
@Data
public class CqeEnt0210270000 implements CqeEntComHdr, Vo {

	private String msgType = "KCGCQE"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "270000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "000"; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String paymentPresentationDate; // 지급제시일자
	private String paymentPresentationNumber; // 지급제시번호
	private String settlementProcessSort; // 결제처리구분
	private String eNoteNumber; // 전자어음번호
	private String eNoteType; // 어음종류
	private String eNoteIssueDate; // 전자어음발행일자
	private String eNoteIssuePlace; // 전자어음발행지
	private long eNoteAmount; // 전자어음금액
	private String eNoteMaturedDate; // 전자어음만기일자
	private String paymentBankAndBranchCode; // 지급은행및지점코드
	private String paymentBranchClearingHouseCode; // 지급점포교환소코드
	private String issuerIndvCorpSort; // 발행인-개인법인구분
	private String issuerBusinessResidentRegistrationNumber; // 발행인-사업자(주민)등록번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String recipientCorpIndvSort; // 소지인법인개인구분
	private String recipientBusinessResidentRegistrationNumber; // 소지인사업자(주민)등록번호
	private String recipientCorpName; // 소지인법인명
	private String recipientNameRepresentative; // 소지인성명(대표자명)
	private String recipientAddress; // 소지인주소
	private String recipientBankCode; // 소지인은행코드
	private String recipientDepositAccountNumber; // 소지인입금계좌번호
	private long recipientSpliteNoteAmount; // 소지인(분할된)전자어음금액
	private String recipientSplitNumber; // 소지인분할번호
	private String recipientEndorsementNumber; // 소지인배서번호
	private LocalDateTime eNoteMaturedSettlementDateTime; // 전자어음만기결제일시
	private String defaultDate; // 부도일
	private String defaultReasoneNoteDefaultReason; // 부도사유-전자어음부도사유
	private String defaultReasonAccidentReportReason; // 부도사유-사고신고서사유
	private String defaultReasonPaymentSuspensionProvisionalDisposition; // 부도사유-지급정지가처분
	private String defaultReasonSpecialDeposit; // 부도사유-별단예금입금
	private String defaultReasonBankManagementCompanyYn; // 부도사유-은행관리기업여부
	private String defaultReasonRestructuringTargetCompanyYn; // 부도사유-구조조정대상기업여부
	private String defaultReasonDepositShortageCause; // 부도사유-예금부족원인
	private LocalDateTime defaultDepositDateTime; // 부도입금-입금일시
	private String defaultDepositBankAndBranchCode; // 부도입금-입금은행및지점코드
	private String defaultReasonChangeYn; // 부도사유변경여부
	private String beforeChangeeNoteDefaultReason; // 변경전전자어음부도사유
	private String afterChangeeNoteDefaultReason; // 변경후전자어음부도사유
	private String reportingInstitutionSort; // 보고기관구분
	private String filler2; // FILLER2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationNumber$; // 지급제시번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String settlementProcessSort$; // 결제처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBranchClearingHouseCode$; // 지급점포교환소코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerIndvCorpSort$; // 발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBusinessResidentRegistrationNumber$; // 발행인-사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpIndvSort$; // 소지인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientBusinessResidentRegistrationNumber$; // 소지인사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientCorpName$; // 소지인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientNameRepresentative$; // 소지인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientAddress$; // 소지인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientBankCode$; // 소지인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientDepositAccountNumber$; // 소지인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientSpliteNoteAmount$; // 소지인(분할된)전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientSplitNumber$; // 소지인분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recipientEndorsementNumber$; // 소지인배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedSettlementDateTime$; // 전자어음만기결제일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDate$; // 부도일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasoneNoteDefaultReason$; // 부도사유-전자어음부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonAccidentReportReason$; // 부도사유-사고신고서사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonPaymentSuspensionProvisionalDisposition$; // 부도사유-지급정지가처분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonSpecialDeposit$; // 부도사유-별단예금입금
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonBankManagementCompanyYn$; // 부도사유-은행관리기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonRestructuringTargetCompanyYn$; // 부도사유-구조조정대상기업여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonDepositShortageCause$; // 부도사유-예금부족원인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositDateTime$; // 부도입금-입금일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultDepositBankAndBranchCode$; // 부도입금-입금은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultReasonChangeYn$; // 부도사유변경여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeeNoteDefaultReason$; // 변경전전자어음부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeeNoteDefaultReason$; // 변경후전자어음부도사유
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reportingInstitutionSort$; // 보고기관구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER2

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteMaturedDate$)) { // 전자어음만기일자
			return 18;
		}
		if (VOUtils.isNotAlphanumericSpace(paymentBankAndBranchCode$)) { // 지급은행및지점코드
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerCurrentAccountNumber$)) { // 발행인-당좌계좌번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(recipientDepositAccountNumber$)) { // 소지인입금계좌번호
			return 33;
		}
		if (VOUtils.isNotAlphanumericSpace(recipientEndorsementNumber$)) { // 소지인배서번호
			return 36;
		}
		if (VOUtils.isNotAlphanumericSpace(defaultReasonChangeYn$)) { // 부도사유변경여부
			return 48;
		}
		if (VOUtils.isNotAlphanumericSpace(reportingInstitutionSort$)) { // 보고기관구분
			return 51;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		paymentPresentationNumber$ = VOUtils.write(out, paymentPresentationNumber, 16); // 지급제시번호
		settlementProcessSort$ = VOUtils.write(out, settlementProcessSort, 2); // 결제처리구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 지급은행및지점코드
		paymentBranchClearingHouseCode$ = VOUtils.write(out, paymentBranchClearingHouseCode, 2); // 지급점포교환소코드
		issuerIndvCorpSort$ = VOUtils.write(out, issuerIndvCorpSort, 1); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber$ = VOUtils.write(out, issuerBusinessResidentRegistrationNumber, 13); // 발행인-사업자(주민)등록번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		recipientCorpIndvSort$ = VOUtils.write(out, recipientCorpIndvSort, 1); // 소지인법인개인구분
		recipientBusinessResidentRegistrationNumber$ = VOUtils.write(out, recipientBusinessResidentRegistrationNumber, 13); // 소지인사업자(주민)등록번호
		recipientCorpName$ = VOUtils.write(out, recipientCorpName, 40, "EUC-KR"); // 소지인법인명
		recipientNameRepresentative$ = VOUtils.write(out, recipientNameRepresentative, 20, "EUC-KR"); // 소지인성명(대표자명)
		recipientAddress$ = VOUtils.write(out, recipientAddress, 60, "EUC-KR"); // 소지인주소
		recipientBankCode$ = VOUtils.write(out, recipientBankCode, 3); // 소지인은행코드
		recipientDepositAccountNumber$ = VOUtils.write(out, recipientDepositAccountNumber, 16); // 소지인입금계좌번호
		recipientSpliteNoteAmount$ = VOUtils.write(out, recipientSpliteNoteAmount, 15); // 소지인(분할된)전자어음금액
		recipientSplitNumber$ = VOUtils.write(out, recipientSplitNumber, 2); // 소지인분할번호
		recipientEndorsementNumber$ = VOUtils.write(out, recipientEndorsementNumber, 2); // 소지인배서번호
		eNoteMaturedSettlementDateTime$ = VOUtils.write(out, eNoteMaturedSettlementDateTime, 14, "yyyyMMddHHmmss"); // 전자어음만기결제일시
		defaultDate$ = VOUtils.write(out, defaultDate, 8); // 부도일
		defaultReasoneNoteDefaultReason$ = VOUtils.write(out, defaultReasoneNoteDefaultReason, 2); // 부도사유-전자어음부도사유
		defaultReasonAccidentReportReason$ = VOUtils.write(out, defaultReasonAccidentReportReason, 1); // 부도사유-사고신고서사유
		defaultReasonPaymentSuspensionProvisionalDisposition$ = VOUtils.write(out, defaultReasonPaymentSuspensionProvisionalDisposition, 1); // 부도사유-지급정지가처분
		defaultReasonSpecialDeposit$ = VOUtils.write(out, defaultReasonSpecialDeposit, 1); // 부도사유-별단예금입금
		defaultReasonBankManagementCompanyYn$ = VOUtils.write(out, defaultReasonBankManagementCompanyYn, 1); // 부도사유-은행관리기업여부
		defaultReasonRestructuringTargetCompanyYn$ = VOUtils.write(out, defaultReasonRestructuringTargetCompanyYn, 1); // 부도사유-구조조정대상기업여부
		defaultReasonDepositShortageCause$ = VOUtils.write(out, defaultReasonDepositShortageCause, 1); // 부도사유-예금부족원인
		defaultDepositDateTime$ = VOUtils.write(out, defaultDepositDateTime, 14, "yyyyMMddHHmmss"); // 부도입금-입금일시
		defaultDepositBankAndBranchCode$ = VOUtils.write(out, defaultDepositBankAndBranchCode, 7); // 부도입금-입금은행및지점코드
		defaultReasonChangeYn$ = VOUtils.write(out, defaultReasonChangeYn, 1); // 부도사유변경여부
		beforeChangeeNoteDefaultReason$ = VOUtils.write(out, beforeChangeeNoteDefaultReason, 2); // 변경전전자어음부도사유
		afterChangeeNoteDefaultReason$ = VOUtils.write(out, afterChangeeNoteDefaultReason, 2); // 변경후전자어음부도사유
		reportingInstitutionSort$ = VOUtils.write(out, reportingInstitutionSort, 1); // 보고기관구분
		filler2$ = VOUtils.write(out, filler2, 9); // FILLER2
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		paymentPresentationNumber = VOUtils.toString(paymentPresentationNumber$ = VOUtils.read(in, 16)); // 지급제시번호
		settlementProcessSort = VOUtils.toString(settlementProcessSort$ = VOUtils.read(in, 2)); // 결제처리구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 지급은행및지점코드
		paymentBranchClearingHouseCode = VOUtils.toString(paymentBranchClearingHouseCode$ = VOUtils.read(in, 2)); // 지급점포교환소코드
		issuerIndvCorpSort = VOUtils.toString(issuerIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber = VOUtils.toString(issuerBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 발행인-사업자(주민)등록번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		recipientCorpIndvSort = VOUtils.toString(recipientCorpIndvSort$ = VOUtils.read(in, 1)); // 소지인법인개인구분
		recipientBusinessResidentRegistrationNumber = VOUtils.toString(recipientBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 소지인사업자(주민)등록번호
		recipientCorpName = VOUtils.toString(recipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 소지인법인명
		recipientNameRepresentative = VOUtils.toString(recipientNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // 소지인성명(대표자명)
		recipientAddress = VOUtils.toString(recipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 소지인주소
		recipientBankCode = VOUtils.toString(recipientBankCode$ = VOUtils.read(in, 3)); // 소지인은행코드
		recipientDepositAccountNumber = VOUtils.toString(recipientDepositAccountNumber$ = VOUtils.read(in, 16)); // 소지인입금계좌번호
		recipientSpliteNoteAmount = VOUtils.toLong(recipientSpliteNoteAmount$ = VOUtils.read(in, 15)); // 소지인(분할된)전자어음금액
		recipientSplitNumber = VOUtils.toString(recipientSplitNumber$ = VOUtils.read(in, 2)); // 소지인분할번호
		recipientEndorsementNumber = VOUtils.toString(recipientEndorsementNumber$ = VOUtils.read(in, 2)); // 소지인배서번호
		eNoteMaturedSettlementDateTime = VOUtils.toLocalDateTime(eNoteMaturedSettlementDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전자어음만기결제일시
		defaultDate = VOUtils.toString(defaultDate$ = VOUtils.read(in, 8)); // 부도일
		defaultReasoneNoteDefaultReason = VOUtils.toString(defaultReasoneNoteDefaultReason$ = VOUtils.read(in, 2)); // 부도사유-전자어음부도사유
		defaultReasonAccidentReportReason = VOUtils.toString(defaultReasonAccidentReportReason$ = VOUtils.read(in, 1)); // 부도사유-사고신고서사유
		defaultReasonPaymentSuspensionProvisionalDisposition = VOUtils.toString(defaultReasonPaymentSuspensionProvisionalDisposition$ = VOUtils.read(in, 1)); // 부도사유-지급정지가처분
		defaultReasonSpecialDeposit = VOUtils.toString(defaultReasonSpecialDeposit$ = VOUtils.read(in, 1)); // 부도사유-별단예금입금
		defaultReasonBankManagementCompanyYn = VOUtils.toString(defaultReasonBankManagementCompanyYn$ = VOUtils.read(in, 1)); // 부도사유-은행관리기업여부
		defaultReasonRestructuringTargetCompanyYn = VOUtils.toString(defaultReasonRestructuringTargetCompanyYn$ = VOUtils.read(in, 1)); // 부도사유-구조조정대상기업여부
		defaultReasonDepositShortageCause = VOUtils.toString(defaultReasonDepositShortageCause$ = VOUtils.read(in, 1)); // 부도사유-예금부족원인
		defaultDepositDateTime = VOUtils.toLocalDateTime(defaultDepositDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 부도입금-입금일시
		defaultDepositBankAndBranchCode = VOUtils.toString(defaultDepositBankAndBranchCode$ = VOUtils.read(in, 7)); // 부도입금-입금은행및지점코드
		defaultReasonChangeYn = VOUtils.toString(defaultReasonChangeYn$ = VOUtils.read(in, 1)); // 부도사유변경여부
		beforeChangeeNoteDefaultReason = VOUtils.toString(beforeChangeeNoteDefaultReason$ = VOUtils.read(in, 2)); // 변경전전자어음부도사유
		afterChangeeNoteDefaultReason = VOUtils.toString(afterChangeeNoteDefaultReason$ = VOUtils.read(in, 2)); // 변경후전자어음부도사유
		reportingInstitutionSort = VOUtils.toString(reportingInstitutionSort$ = VOUtils.read(in, 1)); // 보고기관구분
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 9)); // FILLER2
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", paymentPresentationNumber=").append(paymentPresentationNumber).append(System.lineSeparator()); // 지급제시번호
		sb.append(", settlementProcessSort=").append(settlementProcessSort).append(System.lineSeparator()); // 결제처리구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 지급은행및지점코드
		sb.append(", paymentBranchClearingHouseCode=").append(paymentBranchClearingHouseCode).append(System.lineSeparator()); // 지급점포교환소코드
		sb.append(", issuerIndvCorpSort=").append(issuerIndvCorpSort).append(System.lineSeparator()); // 발행인-개인법인구분
		sb.append(", issuerBusinessResidentRegistrationNumber=").append(issuerBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 발행인-사업자(주민)등록번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", recipientCorpIndvSort=").append(recipientCorpIndvSort).append(System.lineSeparator()); // 소지인법인개인구분
		sb.append(", recipientBusinessResidentRegistrationNumber=").append(recipientBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 소지인사업자(주민)등록번호
		sb.append(", recipientCorpName=").append(recipientCorpName).append(System.lineSeparator()); // 소지인법인명
		sb.append(", recipientNameRepresentative=").append(recipientNameRepresentative).append(System.lineSeparator()); // 소지인성명(대표자명)
		sb.append(", recipientAddress=").append(recipientAddress).append(System.lineSeparator()); // 소지인주소
		sb.append(", recipientBankCode=").append(recipientBankCode).append(System.lineSeparator()); // 소지인은행코드
		sb.append(", recipientDepositAccountNumber=").append(recipientDepositAccountNumber).append(System.lineSeparator()); // 소지인입금계좌번호
		sb.append(", recipientSpliteNoteAmount=").append(recipientSpliteNoteAmount).append(System.lineSeparator()); // 소지인(분할된)전자어음금액
		sb.append(", recipientSplitNumber=").append(recipientSplitNumber).append(System.lineSeparator()); // 소지인분할번호
		sb.append(", recipientEndorsementNumber=").append(recipientEndorsementNumber).append(System.lineSeparator()); // 소지인배서번호
		sb.append(", eNoteMaturedSettlementDateTime=").append(eNoteMaturedSettlementDateTime).append(System.lineSeparator()); // 전자어음만기결제일시
		sb.append(", defaultDate=").append(defaultDate).append(System.lineSeparator()); // 부도일
		sb.append(", defaultReasoneNoteDefaultReason=").append(defaultReasoneNoteDefaultReason).append(System.lineSeparator()); // 부도사유-전자어음부도사유
		sb.append(", defaultReasonAccidentReportReason=").append(defaultReasonAccidentReportReason).append(System.lineSeparator()); // 부도사유-사고신고서사유
		sb.append(", defaultReasonPaymentSuspensionProvisionalDisposition=").append(defaultReasonPaymentSuspensionProvisionalDisposition).append(System.lineSeparator()); // 부도사유-지급정지가처분
		sb.append(", defaultReasonSpecialDeposit=").append(defaultReasonSpecialDeposit).append(System.lineSeparator()); // 부도사유-별단예금입금
		sb.append(", defaultReasonBankManagementCompanyYn=").append(defaultReasonBankManagementCompanyYn).append(System.lineSeparator()); // 부도사유-은행관리기업여부
		sb.append(", defaultReasonRestructuringTargetCompanyYn=").append(defaultReasonRestructuringTargetCompanyYn).append(System.lineSeparator()); // 부도사유-구조조정대상기업여부
		sb.append(", defaultReasonDepositShortageCause=").append(defaultReasonDepositShortageCause).append(System.lineSeparator()); // 부도사유-예금부족원인
		sb.append(", defaultDepositDateTime=").append(defaultDepositDateTime).append(System.lineSeparator()); // 부도입금-입금일시
		sb.append(", defaultDepositBankAndBranchCode=").append(defaultDepositBankAndBranchCode).append(System.lineSeparator()); // 부도입금-입금은행및지점코드
		sb.append(", defaultReasonChangeYn=").append(defaultReasonChangeYn).append(System.lineSeparator()); // 부도사유변경여부
		sb.append(", beforeChangeeNoteDefaultReason=").append(beforeChangeeNoteDefaultReason).append(System.lineSeparator()); // 변경전전자어음부도사유
		sb.append(", afterChangeeNoteDefaultReason=").append(afterChangeeNoteDefaultReason).append(System.lineSeparator()); // 변경후전자어음부도사유
		sb.append(", reportingInstitutionSort=").append(reportingInstitutionSort).append(System.lineSeparator()); // 보고기관구분
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER2
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "KCGCQE"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "270000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentPresentationNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "settlementProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentBranchClearingHouseCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "issuerIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recipientBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recipientNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "recipientBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "recipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientSpliteNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "recipientSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "recipientEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "eNoteMaturedSettlementDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "defaultDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "defaultReasoneNoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "defaultReasonAccidentReportReason", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonPaymentSuspensionProvisionalDisposition", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonSpecialDeposit", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonBankManagementCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonRestructuringTargetCompanyYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultReasonDepositShortageCause", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultDepositDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "defaultDepositBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "defaultReasonChangeYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beforeChangeeNoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "afterChangeeNoteDefaultReason", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "reportingInstitutionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "9", "defltVal", "")
		);
	}

}
