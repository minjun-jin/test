package com.jpmc.kcg.com.biz;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.dao.ComDateMDao;
import com.jpmc.kcg.com.dao.ComDateMMapper;
import com.jpmc.kcg.com.dto.ComDateM;

@ExtendWith(MockitoExtension.class)
class BizDateTest {

    @Mock
    private ComDateMDao comDateMDao;

    @Mock
    private ComDateMMapper comDateMMapper;

    @InjectMocks
    private BizDate bizDate;

    @Test
    void test_returns_true_for_known_business_day() {
        ComDateM comDateM = new ComDateM();
        comDateM.setHoliDvsnCd("00");
        when(comDateMMapper.selectByPrimaryKey("20231001")).thenReturn(comDateM);

        boolean result = bizDate.isBizDay("20231001");

        assertTrue(result);
    }

    @Test
    void test_returns_false_for_known_holiday() {

        ComDateM comDateM = new ComDateM();
        comDateM.setHoliDvsnCd("01");
        when(comDateMMapper.selectByPrimaryKey("20231225")).thenReturn(comDateM);

        boolean result = bizDate.isBizDay("20231225");

        assertFalse(result);
    }

    @Test
    void test_returns_next_business_day_without_parameters() {
        when(comDateMDao.selectNextBizDt(null, 1)).thenReturn("20231002");

        String nextBizDay = bizDate.getNextBizDay();

        assertNotNull(nextBizDay);
        assertEquals("20231002", nextBizDay);
    }

    @Test
    void test_handles_end_of_year_transition_correctly() {
        when(comDateMDao.selectNextBizDt(null, 1)).thenReturn("20240102");

        String nextBizDay = bizDate.getNextBizDay();

        assertNotNull(nextBizDay);
        assertEquals("20240102", nextBizDay);
    }

    @Test
    void test_handles_leap_years_correctly() {
        when(comDateMDao.selectNextBizDt(null, 1)).thenReturn("20240229");

        String nextBizDay = bizDate.getNextBizDay();

        assertNotNull(nextBizDay);
        assertEquals("20240229", nextBizDay);
    }
    
    @Test
    void test_returns_next_working_day() {
        when(comDateMDao.selectNextWorkingDt("20250404", 1)).thenReturn("20250407");

        String nextBizDay = bizDate.getNextWorkingDay("20250404", 1);

        assertNotNull(nextBizDay);
        assertEquals("20250407", nextBizDay);
    }
    
        @Test
    void test_returns_previous_working_day() {
        when(comDateMDao.selectNextWorkingDt(anyString(), anyInt())).thenReturn("20250407");

        String nextBizDay = bizDate.getNextWorkingDay("20250404", 1);

        assertNotNull(nextBizDay);
        assertEquals("20250407", nextBizDay);
    }

    @Test
    void test_returns_previous_business_day_no_params() {
        when(comDateMDao.selectPreviousBizDt(null, 1)).thenReturn("20231005");

        String result = bizDate.getPrevBizDay();

        assertEquals("20231005", result);
    }

    @Test
    void test_returns_previous_business_day_with_base_date() {
        when(comDateMDao.selectPreviousBizDt("20231010", 1)).thenReturn("20231009");

        String result = bizDate.getPrevBizDay("20231010", 1);

        assertEquals("20231009", result);
    }
    
    @Test
    void test_returns_cms_next_business_day_with_base_date() {
        when(comDateMDao.selectNextWorkingDt("20231010", 1)).thenReturn("20231009");

        String result = bizDate.getNextWorkingDay("20231010", 1);

        assertEquals("20231009", result);
    }
    
    @Test
    void test_returns_cms_previous_business_day_with_base_date() {
        when(comDateMDao.selectPreviousWorkingDt("20231010", 1)).thenReturn("20231009");

        String result = bizDate.getPrevWorkingDay("20231010", 1);

        assertEquals("20231009", result);
    }

    @Test
    void test_handles_month_end_transition() {
        when(comDateMDao.selectPreviousBizDt("20231001", 1)).thenReturn("20230929");

        String result = bizDate.getPrevBizDay("20231001", 1);

        assertEquals("20230929", result);
    }

    @Test
    void test_handles_year_end_transition() {
        when(comDateMDao.selectPreviousBizDt("20230101", 1)).thenReturn("20221230");

        String result = bizDate.getPrevBizDay("20230101", 1);

        assertEquals("20221230", result);
    }
    
    @Test
    void test_isBizDay() {
        ComDateM comDateM = new ComDateM();
        comDateM.setHoliDvsnCd("00");
        when(comDateMMapper.selectByPrimaryKey(anyString())).thenReturn(comDateM);

        boolean result = bizDate.isBizDay();

        assertTrue(result);
    }
    
    @Test
    void test_isWeekdayBizDay() {
        ComDateM comDateM = new ComDateM();
        comDateM.setHoliDvsnCd("00");
        when(comDateMMapper.selectByPrimaryKey(anyString())).thenReturn(comDateM);
    	
    	boolean result = bizDate.isWeekdayBizDay();
    	
    	assertTrue(result);
    }
    
    @Test
    void test_isWeekdayBizDay_null() {
    	when(comDateMMapper.selectByPrimaryKey(anyString())).thenReturn(null);
    	
    	boolean result = bizDate.isWeekdayBizDay();
    	
    	assertFalse(result);
    }
}