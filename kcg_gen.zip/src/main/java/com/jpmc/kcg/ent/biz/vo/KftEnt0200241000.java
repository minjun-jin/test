package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 분할배서 후 잔존내역 통지
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 241000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * transactionType 거래구분 
 * eNoteNumber 어음내역전자어음번호 
 * eNoteType 어음내역어음종류 
 * eNoteIssueDate 어음내역전자어음발행일자 
 * eNoteIssuePlace 어음내역전자어음발행지 
 * eNoteAmount 어음내역전자어음금액 
 * eNoteMaturedDate 어음내역전자어음만기일자 
 * noteDetailspaymentBankAndBranchCode 어음내역지급은행및지점코드 
 * issuerInfoCorpIndvSortCode 발행인정보법인개인구분코드 
 * issuerInfoResidentBusinessNumber 발행인정보주민사업자번호 
 * issuerInfoCorpName 발행인정보법인명 
 * issuerInfoNameRepresentativeName 발행인정보성명(대표자명) 
 * issuerInfoAddress 발행인정보주소 
 * endorserCorpIndvSortCode 배서인법인개인구분코드 
 * endorserResidentBusinessNumber 배서인주민사업자번호 
 * endorserCorpName 배서인법인명 
 * endorserNameRepresentativeName 배서인성명(대표자명) 
 * endorserAddress 배서인주소 
 * endorserBankCode 배서인은행코드 
 * endorserDepositAccountNumber 배서인입금계좌번호 
 * remainingDetailsProcessSort 잔존내역-처리구분 
 * remainingDetailsSplitNumber 잔존내역-분할번호 
 * remainingDetailsEndorsementNumber 잔존내역-배서번호 
 * remainingDetailsRemainingAmount 잔존내역-잔존금액 
 * splitEndorsementDetailsSplitNumber 분할배서내역분할번호 
 * splitEndorsementDetailsEndorsementNumber 분할배서내역배서번호 
 * splitEndorsementDetailsEndorsementAmount 분할배서내역배서금액 
 * notificationTarget 통지대상 
 * 
 * KftEnt0200241000 kftEnt0200241000 = new KftEnt0200241000(); // 분할배서 후 잔존내역 통지
 * kftEnt0200241000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200241000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200241000.setBnkCd("057"); // 은행코드
 * kftEnt0200241000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200241000.setTransactionCode("241000"); // 거래구분코드
 * kftEnt0200241000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200241000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200241000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200241000.setStatus("000"); // STATUS
 * kftEnt0200241000.setResponseCode1(""); // 응답코드1
 * kftEnt0200241000.setResponseCode2(""); // 응답코드2
 * kftEnt0200241000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200241000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200241000.setTransactionType(""); // 거래구분
 * kftEnt0200241000.setENoteNumber(""); // 어음내역전자어음번호
 * kftEnt0200241000.setENoteType(""); // 어음내역어음종류
 * kftEnt0200241000.setENoteIssueDate(""); // 어음내역전자어음발행일자
 * kftEnt0200241000.setENoteIssuePlace(""); // 어음내역전자어음발행지
 * kftEnt0200241000.setENoteAmount(0L); // 어음내역전자어음금액
 * kftEnt0200241000.setENoteMaturedDate(""); // 어음내역전자어음만기일자
 * kftEnt0200241000.setNoteDetailspaymentBankAndBranchCode(""); // 어음내역지급은행및지점코드
 * kftEnt0200241000.setIssuerInfoCorpIndvSortCode(""); // 발행인정보법인개인구분코드
 * kftEnt0200241000.setIssuerInfoResidentBusinessNumber(""); // 발행인정보주민사업자번호
 * kftEnt0200241000.setIssuerInfoCorpName(""); // 발행인정보법인명
 * kftEnt0200241000.setIssuerInfoNameRepresentativeName(""); // 발행인정보성명(대표자명)
 * kftEnt0200241000.setIssuerInfoAddress(""); // 발행인정보주소
 * kftEnt0200241000.setEndorserCorpIndvSortCode(""); // 배서인법인개인구분코드
 * kftEnt0200241000.setEndorserResidentBusinessNumber(""); // 배서인주민사업자번호
 * kftEnt0200241000.setEndorserCorpName(""); // 배서인법인명
 * kftEnt0200241000.setEndorserNameRepresentativeName(""); // 배서인성명(대표자명)
 * kftEnt0200241000.setEndorserAddress(""); // 배서인주소
 * kftEnt0200241000.setEndorserBankCode(""); // 배서인은행코드
 * kftEnt0200241000.setEndorserDepositAccountNumber(""); // 배서인입금계좌번호
 * kftEnt0200241000.setRemainingDetailsProcessSort(""); // 잔존내역-처리구분
 * kftEnt0200241000.setRemainingDetailsSplitNumber(""); // 잔존내역-분할번호
 * kftEnt0200241000.setRemainingDetailsEndorsementNumber(""); // 잔존내역-배서번호
 * kftEnt0200241000.setRemainingDetailsRemainingAmount(0L); // 잔존내역-잔존금액
 * kftEnt0200241000.setSplitEndorsementDetailsSplitNumber(""); // 분할배서내역분할번호
 * kftEnt0200241000.setSplitEndorsementDetailsEndorsementNumber(""); // 분할배서내역배서번호
 * kftEnt0200241000.setSplitEndorsementDetailsEndorsementAmount(0L); // 분할배서내역배서금액
 * kftEnt0200241000.setNotificationTarget(""); // 통지대상
 * }</pre>
 */
@Data
public class KftEnt0200241000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "241000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String transactionType; // 거래구분
	private String eNoteNumber; // 어음내역전자어음번호
	private String eNoteType; // 어음내역어음종류
	private String eNoteIssueDate; // 어음내역전자어음발행일자
	private String eNoteIssuePlace; // 어음내역전자어음발행지
	private long eNoteAmount; // 어음내역전자어음금액
	private String eNoteMaturedDate; // 어음내역전자어음만기일자
	private String noteDetailspaymentBankAndBranchCode; // 어음내역지급은행및지점코드
	private String issuerInfoCorpIndvSortCode; // 발행인정보법인개인구분코드
	private String issuerInfoResidentBusinessNumber; // 발행인정보주민사업자번호
	private String issuerInfoCorpName; // 발행인정보법인명
	private String issuerInfoNameRepresentativeName; // 발행인정보성명(대표자명)
	private String issuerInfoAddress; // 발행인정보주소
	private String endorserCorpIndvSortCode; // 배서인법인개인구분코드
	private String endorserResidentBusinessNumber; // 배서인주민사업자번호
	private String endorserCorpName; // 배서인법인명
	private String endorserNameRepresentativeName; // 배서인성명(대표자명)
	private String endorserAddress; // 배서인주소
	private String endorserBankCode; // 배서인은행코드
	private String endorserDepositAccountNumber; // 배서인입금계좌번호
	private String remainingDetailsProcessSort; // 잔존내역-처리구분
	private String remainingDetailsSplitNumber; // 잔존내역-분할번호
	private String remainingDetailsEndorsementNumber; // 잔존내역-배서번호
	private long remainingDetailsRemainingAmount; // 잔존내역-잔존금액
	private String splitEndorsementDetailsSplitNumber; // 분할배서내역분할번호
	private String splitEndorsementDetailsEndorsementNumber; // 분할배서내역배서번호
	private long splitEndorsementDetailsEndorsementAmount; // 분할배서내역배서금액
	private String notificationTarget; // 통지대상
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionType$; // 거래구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음내역전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음내역어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음내역전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음내역전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음내역전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음내역전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String noteDetailspaymentBankAndBranchCode$; // 어음내역지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpIndvSortCode$; // 발행인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoResidentBusinessNumber$; // 발행인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoCorpName$; // 발행인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoNameRepresentativeName$; // 발행인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerInfoAddress$; // 발행인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpIndvSortCode$; // 배서인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserResidentBusinessNumber$; // 배서인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpName$; // 배서인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserNameRepresentativeName$; // 배서인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserAddress$; // 배서인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBankCode$; // 배서인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserDepositAccountNumber$; // 배서인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String remainingDetailsProcessSort$; // 잔존내역-처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String remainingDetailsSplitNumber$; // 잔존내역-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String remainingDetailsEndorsementNumber$; // 잔존내역-배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String remainingDetailsRemainingAmount$; // 잔존내역-잔존금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitEndorsementDetailsSplitNumber$; // 분할배서내역분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitEndorsementDetailsEndorsementNumber$; // 분할배서내역배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitEndorsementDetailsEndorsementAmount$; // 분할배서내역배서금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String notificationTarget$; // 통지대상

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionType$)) { // 거래구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음내역전자어음번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerInfoResidentBusinessNumber$)) { // 발행인정보주민사업자번호
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserResidentBusinessNumber$)) { // 배서인주민사업자번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(endorserDepositAccountNumber$)) { // 배서인입금계좌번호
			return 32;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		transactionType$ = VOUtils.write(out, transactionType, 1); // 거래구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음내역전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음내역어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음내역전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음내역전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음내역전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음내역전자어음만기일자
		noteDetailspaymentBankAndBranchCode$ = VOUtils.write(out, noteDetailspaymentBankAndBranchCode, 7); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode$ = VOUtils.write(out, issuerInfoCorpIndvSortCode, 1); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber$ = VOUtils.write(out, issuerInfoResidentBusinessNumber, 13); // 발행인정보주민사업자번호
		issuerInfoCorpName$ = VOUtils.write(out, issuerInfoCorpName, 40, "EUC-KR"); // 발행인정보법인명
		issuerInfoNameRepresentativeName$ = VOUtils.write(out, issuerInfoNameRepresentativeName, 20, "EUC-KR"); // 발행인정보성명(대표자명)
		issuerInfoAddress$ = VOUtils.write(out, issuerInfoAddress, 60, "EUC-KR"); // 발행인정보주소
		endorserCorpIndvSortCode$ = VOUtils.write(out, endorserCorpIndvSortCode, 1); // 배서인법인개인구분코드
		endorserResidentBusinessNumber$ = VOUtils.write(out, endorserResidentBusinessNumber, 13); // 배서인주민사업자번호
		endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // 배서인법인명
		endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // 배서인성명(대표자명)
		endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // 배서인주소
		endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // 배서인은행코드
		endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // 배서인입금계좌번호
		remainingDetailsProcessSort$ = VOUtils.write(out, remainingDetailsProcessSort, 2); // 잔존내역-처리구분
		remainingDetailsSplitNumber$ = VOUtils.write(out, remainingDetailsSplitNumber, 2); // 잔존내역-분할번호
		remainingDetailsEndorsementNumber$ = VOUtils.write(out, remainingDetailsEndorsementNumber, 2); // 잔존내역-배서번호
		remainingDetailsRemainingAmount$ = VOUtils.write(out, remainingDetailsRemainingAmount, 15); // 잔존내역-잔존금액
		splitEndorsementDetailsSplitNumber$ = VOUtils.write(out, splitEndorsementDetailsSplitNumber, 2); // 분할배서내역분할번호
		splitEndorsementDetailsEndorsementNumber$ = VOUtils.write(out, splitEndorsementDetailsEndorsementNumber, 2); // 분할배서내역배서번호
		splitEndorsementDetailsEndorsementAmount$ = VOUtils.write(out, splitEndorsementDetailsEndorsementAmount, 15); // 분할배서내역배서금액
		notificationTarget$ = VOUtils.write(out, notificationTarget, 1); // 통지대상
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		transactionType = VOUtils.toString(transactionType$ = VOUtils.read(in, 1)); // 거래구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음내역전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음내역어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음내역전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음내역전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음내역전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음내역전자어음만기일자
		noteDetailspaymentBankAndBranchCode = VOUtils.toString(noteDetailspaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음내역지급은행및지점코드
		issuerInfoCorpIndvSortCode = VOUtils.toString(issuerInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 발행인정보법인개인구분코드
		issuerInfoResidentBusinessNumber = VOUtils.toString(issuerInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인정보주민사업자번호
		issuerInfoCorpName = VOUtils.toString(issuerInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인정보법인명
		issuerInfoNameRepresentativeName = VOUtils.toString(issuerInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인정보성명(대표자명)
		issuerInfoAddress = VOUtils.toString(issuerInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인정보주소
		endorserCorpIndvSortCode = VOUtils.toString(endorserCorpIndvSortCode$ = VOUtils.read(in, 1)); // 배서인법인개인구분코드
		endorserResidentBusinessNumber = VOUtils.toString(endorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // 배서인주민사업자번호
		endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 배서인법인명
		endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 배서인성명(대표자명)
		endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 배서인주소
		endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // 배서인은행코드
		endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // 배서인입금계좌번호
		remainingDetailsProcessSort = VOUtils.toString(remainingDetailsProcessSort$ = VOUtils.read(in, 2)); // 잔존내역-처리구분
		remainingDetailsSplitNumber = VOUtils.toString(remainingDetailsSplitNumber$ = VOUtils.read(in, 2)); // 잔존내역-분할번호
		remainingDetailsEndorsementNumber = VOUtils.toString(remainingDetailsEndorsementNumber$ = VOUtils.read(in, 2)); // 잔존내역-배서번호
		remainingDetailsRemainingAmount = VOUtils.toLong(remainingDetailsRemainingAmount$ = VOUtils.read(in, 15)); // 잔존내역-잔존금액
		splitEndorsementDetailsSplitNumber = VOUtils.toString(splitEndorsementDetailsSplitNumber$ = VOUtils.read(in, 2)); // 분할배서내역분할번호
		splitEndorsementDetailsEndorsementNumber = VOUtils.toString(splitEndorsementDetailsEndorsementNumber$ = VOUtils.read(in, 2)); // 분할배서내역배서번호
		splitEndorsementDetailsEndorsementAmount = VOUtils.toLong(splitEndorsementDetailsEndorsementAmount$ = VOUtils.read(in, 15)); // 분할배서내역배서금액
		notificationTarget = VOUtils.toString(notificationTarget$ = VOUtils.read(in, 1)); // 통지대상
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", transactionType=").append(transactionType).append(System.lineSeparator()); // 거래구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음내역전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음내역어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음내역전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음내역전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음내역전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음내역전자어음만기일자
		sb.append(", noteDetailspaymentBankAndBranchCode=").append(noteDetailspaymentBankAndBranchCode).append(System.lineSeparator()); // 어음내역지급은행및지점코드
		sb.append(", issuerInfoCorpIndvSortCode=").append(issuerInfoCorpIndvSortCode).append(System.lineSeparator()); // 발행인정보법인개인구분코드
		sb.append(", issuerInfoResidentBusinessNumber=").append(issuerInfoResidentBusinessNumber).append(System.lineSeparator()); // 발행인정보주민사업자번호
		sb.append(", issuerInfoCorpName=").append(issuerInfoCorpName).append(System.lineSeparator()); // 발행인정보법인명
		sb.append(", issuerInfoNameRepresentativeName=").append(issuerInfoNameRepresentativeName).append(System.lineSeparator()); // 발행인정보성명(대표자명)
		sb.append(", issuerInfoAddress=").append(issuerInfoAddress).append(System.lineSeparator()); // 발행인정보주소
		sb.append(", endorserCorpIndvSortCode=").append(endorserCorpIndvSortCode).append(System.lineSeparator()); // 배서인법인개인구분코드
		sb.append(", endorserResidentBusinessNumber=").append(endorserResidentBusinessNumber).append(System.lineSeparator()); // 배서인주민사업자번호
		sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // 배서인법인명
		sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // 배서인성명(대표자명)
		sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // 배서인주소
		sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // 배서인은행코드
		sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // 배서인입금계좌번호
		sb.append(", remainingDetailsProcessSort=").append(remainingDetailsProcessSort).append(System.lineSeparator()); // 잔존내역-처리구분
		sb.append(", remainingDetailsSplitNumber=").append(remainingDetailsSplitNumber).append(System.lineSeparator()); // 잔존내역-분할번호
		sb.append(", remainingDetailsEndorsementNumber=").append(remainingDetailsEndorsementNumber).append(System.lineSeparator()); // 잔존내역-배서번호
		sb.append(", remainingDetailsRemainingAmount=").append(remainingDetailsRemainingAmount).append(System.lineSeparator()); // 잔존내역-잔존금액
		sb.append(", splitEndorsementDetailsSplitNumber=").append(splitEndorsementDetailsSplitNumber).append(System.lineSeparator()); // 분할배서내역분할번호
		sb.append(", splitEndorsementDetailsEndorsementNumber=").append(splitEndorsementDetailsEndorsementNumber).append(System.lineSeparator()); // 분할배서내역배서번호
		sb.append(", splitEndorsementDetailsEndorsementAmount=").append(splitEndorsementDetailsEndorsementAmount).append(System.lineSeparator()); // 분할배서내역배서금액
		sb.append(", notificationTarget=").append(notificationTarget).append(System.lineSeparator()); // 통지대상
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "241000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "transactionType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailspaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "remainingDetailsProcessSort", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "remainingDetailsSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "remainingDetailsEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "remainingDetailsRemainingAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "splitEndorsementDetailsSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "splitEndorsementDetailsEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "splitEndorsementDetailsEndorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "notificationTarget", "fldLen", "1", "defltVal", "")
		);
	}

}
