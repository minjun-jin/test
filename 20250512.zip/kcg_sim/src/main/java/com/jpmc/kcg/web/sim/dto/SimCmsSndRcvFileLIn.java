package com.jpmc.kcg.web.sim.dto;

import java.util.List;

import lombok.Data;

@Data
public class SimCmsSndRcvFileLIn {
	List<SimCmsSndRcvFileL> simCmsSndRcvFilelIn;
}