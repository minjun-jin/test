package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90RB kftCmsEB90RB  = new KftCmsEB90RB(); // 이용기관정보통지
 * kftCmsEB90RB.setRecordType(""); // Record 구분
 * kftCmsEB90RB.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB90RB.setDataRecordType(""); // Data Record 구분코드
 * kftCmsEB90RB.setInstitutionCode(""); // 기관코드
 * kftCmsEB90RB.setChangeSeqBitMap(""); // 변경항번BitMap
 * kftCmsEB90RB.setCustomerComplaintsDepartmentName(""); // 민원 담당자  부서명
 * kftCmsEB90RB.setCustomerComplaintsOfficerName(""); // 민원 담당자 성명
 * kftCmsEB90RB.setCustomerComplaintsOfficerPosition(""); // 민원 담당자 직위
 * kftCmsEB90RB.setCustomerComplaintsOfficerPhoneNumber(""); // 민원 담당자 전화번호
 * kftCmsEB90RB.setItDepartmentName(""); // 전산 담당자 부서명
 * kftCmsEB90RB.setItOfficerName(""); // 전산 담당자 성명
 * kftCmsEB90RB.setItOfficerPosition(""); // 전산 담당자 직위
 * kftCmsEB90RB.setItOfficerPhoneNumber(""); // 전산 담당자 전화번호
 * kftCmsEB90RB.setAdministratorDepartmentName(""); // 총괄 담당자 부서명
 * kftCmsEB90RB.setAdministratorName(""); // 총괄 담당자 성명
 * kftCmsEB90RB.setAdministratorPosition(""); // 총괄 담당자 직위
 * kftCmsEB90RB.setAdministratorPhoneNumber(""); // 총괄 담당자 전화번호
 * kftCmsEB90RB.setFiller3(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90RB implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String dataRecordType; // Data Record 구분코드
	private String institutionCode; // 기관코드
	private String changeSeqBitMap; // 변경항번BitMap
	private String customerComplaintsDepartmentName; // 민원 담당자  부서명
	private String customerComplaintsOfficerName; // 민원 담당자 성명
	private String customerComplaintsOfficerPosition; // 민원 담당자 직위
	private String customerComplaintsOfficerPhoneNumber; // 민원 담당자 전화번호
	private String itDepartmentName; // 전산 담당자 부서명
	private String itOfficerName; // 전산 담당자 성명
	private String itOfficerPosition; // 전산 담당자 직위
	private String itOfficerPhoneNumber; // 전산 담당자 전화번호
	private String administratorDepartmentName; // 총괄 담당자 부서명
	private String administratorName; // 총괄 담당자 성명
	private String administratorPosition; // 총괄 담당자 직위
	private String administratorPhoneNumber; // 총괄 담당자 전화번호
	private String filler3; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataRecordType$; // Data Record 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeSeqBitMap$; // 변경항번BitMap
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String customerComplaintsDepartmentName$; // 민원 담당자  부서명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String customerComplaintsOfficerName$; // 민원 담당자 성명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String customerComplaintsOfficerPosition$; // 민원 담당자 직위
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String customerComplaintsOfficerPhoneNumber$; // 민원 담당자 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String itDepartmentName$; // 전산 담당자 부서명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String itOfficerName$; // 전산 담당자 성명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String itOfficerPosition$; // 전산 담당자 직위
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String itOfficerPhoneNumber$; // 전산 담당자 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String administratorDepartmentName$; // 총괄 담당자 부서명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String administratorName$; // 총괄 담당자 성명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String administratorPosition$; // 총괄 담당자 직위
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String administratorPhoneNumber$; // 총괄 담당자 전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		dataRecordType$ = VOUtils.write(out, dataRecordType, 1); // Data Record 구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		changeSeqBitMap$ = VOUtils.write(out, changeSeqBitMap, 15); // 변경항번BitMap
		customerComplaintsDepartmentName$ = VOUtils.write(out, customerComplaintsDepartmentName, 20, "EUC-KR"); // 민원 담당자  부서명
		customerComplaintsOfficerName$ = VOUtils.write(out, customerComplaintsOfficerName, 20, "EUC-KR"); // 민원 담당자 성명
		customerComplaintsOfficerPosition$ = VOUtils.write(out, customerComplaintsOfficerPosition, 10, "EUC-KR"); // 민원 담당자 직위
		customerComplaintsOfficerPhoneNumber$ = VOUtils.write(out, customerComplaintsOfficerPhoneNumber, 14); // 민원 담당자 전화번호
		itDepartmentName$ = VOUtils.write(out, itDepartmentName, 20, "EUC-KR"); // 전산 담당자 부서명
		itOfficerName$ = VOUtils.write(out, itOfficerName, 20, "EUC-KR"); // 전산 담당자 성명
		itOfficerPosition$ = VOUtils.write(out, itOfficerPosition, 10, "EUC-KR"); // 전산 담당자 직위
		itOfficerPhoneNumber$ = VOUtils.write(out, itOfficerPhoneNumber, 14); // 전산 담당자 전화번호
		administratorDepartmentName$ = VOUtils.write(out, administratorDepartmentName, 20, "EUC-KR"); // 총괄 담당자 부서명
		administratorName$ = VOUtils.write(out, administratorName, 20, "EUC-KR"); // 총괄 담당자 성명
		administratorPosition$ = VOUtils.write(out, administratorPosition, 10, "EUC-KR"); // 총괄 담당자 직위
		administratorPhoneNumber$ = VOUtils.write(out, administratorPhoneNumber, 14); // 총괄 담당자 전화번호
		filler3$ = VOUtils.write(out, filler3, 23); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		dataRecordType = VOUtils.toString(dataRecordType$ = VOUtils.read(in, 1)); // Data Record 구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		changeSeqBitMap = VOUtils.toString(changeSeqBitMap$ = VOUtils.read(in, 15)); // 변경항번BitMap
		customerComplaintsDepartmentName = VOUtils.toString(customerComplaintsDepartmentName$ = VOUtils.read(in, 20, "EUC-KR")); // 민원 담당자  부서명
		customerComplaintsOfficerName = VOUtils.toString(customerComplaintsOfficerName$ = VOUtils.read(in, 20, "EUC-KR")); // 민원 담당자 성명
		customerComplaintsOfficerPosition = VOUtils.toString(customerComplaintsOfficerPosition$ = VOUtils.read(in, 10, "EUC-KR")); // 민원 담당자 직위
		customerComplaintsOfficerPhoneNumber = VOUtils.toString(customerComplaintsOfficerPhoneNumber$ = VOUtils.read(in, 14)); // 민원 담당자 전화번호
		itDepartmentName = VOUtils.toString(itDepartmentName$ = VOUtils.read(in, 20, "EUC-KR")); // 전산 담당자 부서명
		itOfficerName = VOUtils.toString(itOfficerName$ = VOUtils.read(in, 20, "EUC-KR")); // 전산 담당자 성명
		itOfficerPosition = VOUtils.toString(itOfficerPosition$ = VOUtils.read(in, 10, "EUC-KR")); // 전산 담당자 직위
		itOfficerPhoneNumber = VOUtils.toString(itOfficerPhoneNumber$ = VOUtils.read(in, 14)); // 전산 담당자 전화번호
		administratorDepartmentName = VOUtils.toString(administratorDepartmentName$ = VOUtils.read(in, 20, "EUC-KR")); // 총괄 담당자 부서명
		administratorName = VOUtils.toString(administratorName$ = VOUtils.read(in, 20, "EUC-KR")); // 총괄 담당자 성명
		administratorPosition = VOUtils.toString(administratorPosition$ = VOUtils.read(in, 10, "EUC-KR")); // 총괄 담당자 직위
		administratorPhoneNumber = VOUtils.toString(administratorPhoneNumber$ = VOUtils.read(in, 14)); // 총괄 담당자 전화번호
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 23)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", dataRecordType=").append(dataRecordType).append(System.lineSeparator()); // Data Record 구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", changeSeqBitMap=").append(changeSeqBitMap).append(System.lineSeparator()); // 변경항번BitMap
		sb.append(", customerComplaintsDepartmentName=").append(customerComplaintsDepartmentName).append(System.lineSeparator()); // 민원 담당자  부서명
		sb.append(", customerComplaintsOfficerName=").append(customerComplaintsOfficerName).append(System.lineSeparator()); // 민원 담당자 성명
		sb.append(", customerComplaintsOfficerPosition=").append(customerComplaintsOfficerPosition).append(System.lineSeparator()); // 민원 담당자 직위
		sb.append(", customerComplaintsOfficerPhoneNumber=").append(customerComplaintsOfficerPhoneNumber).append(System.lineSeparator()); // 민원 담당자 전화번호
		sb.append(", itDepartmentName=").append(itDepartmentName).append(System.lineSeparator()); // 전산 담당자 부서명
		sb.append(", itOfficerName=").append(itOfficerName).append(System.lineSeparator()); // 전산 담당자 성명
		sb.append(", itOfficerPosition=").append(itOfficerPosition).append(System.lineSeparator()); // 전산 담당자 직위
		sb.append(", itOfficerPhoneNumber=").append(itOfficerPhoneNumber).append(System.lineSeparator()); // 전산 담당자 전화번호
		sb.append(", administratorDepartmentName=").append(administratorDepartmentName).append(System.lineSeparator()); // 총괄 담당자 부서명
		sb.append(", administratorName=").append(administratorName).append(System.lineSeparator()); // 총괄 담당자 성명
		sb.append(", administratorPosition=").append(administratorPosition).append(System.lineSeparator()); // 총괄 담당자 직위
		sb.append(", administratorPhoneNumber=").append(administratorPhoneNumber).append(System.lineSeparator()); // 총괄 담당자 전화번호
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "dataRecordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "changeSeqBitMap", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "customerComplaintsDepartmentName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "customerComplaintsOfficerName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "customerComplaintsOfficerPosition", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "customerComplaintsOfficerPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "itDepartmentName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "itOfficerName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "itOfficerPosition", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "itOfficerPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "administratorDepartmentName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "administratorName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "administratorPosition", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "administratorPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler3", "fldLen", "23", "defltVal", "")
		);
	}

}
