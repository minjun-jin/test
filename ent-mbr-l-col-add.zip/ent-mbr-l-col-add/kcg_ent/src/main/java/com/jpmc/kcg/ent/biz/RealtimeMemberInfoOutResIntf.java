package com.jpmc.kcg.ent.biz;

import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0210220000;
import com.jpmc.kcg.ent.biz.vo.KftEnt0210220000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dao.EntMbrLDao;
import com.jpmc.kcg.ent.dto.EntMbrL;
import com.jpmc.kcg.ent.enums.EntRespCdEnum;
import com.jpmc.kcg.ent.enums.EntTlgKndDvsnCdEnum;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Mapping;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class RealtimeMemberInfoOutResIntf extends FrwServiceBean<KftEnt0210220000> {
    private final FrwTemplate frwTemplate;
    private final FrwContext frwContext;
    private final EntCom entCom;
    private final EntMbrLDao entMbrLDao;
    private final ConversionService conversionService;

    @Override
    public boolean control(KftEnt0210220000 in) {

        log.debug("----------------- KftEnt0210220000: {} -----------------", in);

        /*
         * 원거래내역 조회
         */
        EntMbrL originTrax = entCom.getOriginTraxEntMbrL(in.getMessageTrackingNumber(), in.getTransactionIdNumber());

        log.debug("----------------- originTrax EntMbrL -----------------: {}", originTrax);

        /*
         * 당발 보낸 전문이 format error return 인 경우
         * - 원거래 조회전문거래내역 수정
         * - host 에러 응답 전문 전송
         * - return false
         */
        if (EntTlgKndDvsnCdEnum.isFormatErrorResponseCode(in.getMessageType())) {

            if (originTrax != null) {
                // PK 필드 설정
                originTrax.setTrDt(DateUtils.getISODate());
                originTrax.setEntTlgKndDvsnCd(in.getMessageType());            // 전문종별코드
                originTrax.setEntTlgTrDvsnCd(in.getTransactionCode());        // 거래구분코드
                originTrax.setTrUnqNo(in.getTransactionIdNumber());
                originTrax.setRespCd1(in.getResponseCode1());
                originTrax.setRespCd2(in.getResponseCode2());
                originTrax.setTrSts(in.getStatus());
                originTrax.setSndRcvDvsnCd(EntConst.RCV_FLAG);
                originTrax.setHostNo(frwContext.getHostMsgNo());

                log.debug("----------------- update origin EntMbrL -----------------: {}", originTrax);
                entMbrLDao.updateOriginalTransaction(originTrax);

                /*
                 * Cqe 전문 생성
                 * KftEnt0210330000CqeEnt0210330000
                 */
                CqeEnt0210220000 sendVo = conversionService.convert(in, CqeEnt0210220000.class);
                sendVo.setMsgType("KCGCQE");
                sendVo.setMsgNo(originTrax.getHostNo());    // 원거래의 hostNo

                /*
                 * KCG -> CQE 전송
                 */
                log.debug("----------------- CqeEnt0210330000 -----------------: {}", sendVo);
                frwTemplate.send(FrwDestination.CQE_ENT, sendVo);

            }

            return false;
        }

        // 원거래없음 에러 -> status = 거래고유번호의 위치 set(asis : respCd2 = " 099") 
        if (originTrax == null) {
            throw new InternalResponseException(EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "007");
        }

        /*
         * 이중응답 check
         * 원거래.전문종별구분코드 = 0210 and 원거래.응답코드 != null -> 무시
         */
        if (StringUtils.equals(EntTlgKndDvsnCdEnum.RESPONSE.getCode(), originTrax.getEntTlgKndDvsnCd())
                && StringUtils.isNotEmpty(originTrax.getRespCd1())) {
            return false;
        }

        /*
         * 입력값 검증
         */
        entCom.nullCheckKftInput(in);

        /*
         * 공통 전문 필드 검증
         */
        entCom.validateReceivingHeader(in);

        return super.control(in);
    }

    @Override
    public void process(KftEnt0210220000 in) {
        /*
         * 원거래내역 조회
         */
        EntMbrL originTrax = entCom.getOriginTraxEntMbrL(in.getMessageTrackingNumber(), in.getTransactionIdNumber());

        originTrax.setEntTlgKndDvsnCd(in.getMessageType());            // 전문종별코드
        originTrax.setEntTlgTrDvsnCd(in.getTransactionCode());        // 거래구분코드
        originTrax.setEntTlgTrceNo(in.getMessageTrackingNumber());
        originTrax.setEntOutinDvsnCd(EntConst.OUTBOUND_CD);
        originTrax.setRespCd1(in.getResponseCode1());
        originTrax.setRespCd2(in.getResponseCode2());
        originTrax.setTrSts(in.getStatus());
        originTrax.setSndRcvDvsnCd(EntConst.RCV_FLAG);

        /*
         * 내역 Update
         */
        originTrax.setCorpIndvDvsnCd(in.getResultCorpIndvSort());
        originTrax.setCtzBizNoEnc(entCom.encryptCtzBizNo(in.getResultResidentBusinessNumber()));
        originTrax.setCtzBizNo(entCom.sliceCtzBizNo(in.getResultResidentBusinessNumber()));
        originTrax.setRepNm(in.getResultNameRepresentativeName());
        originTrax.setCorpNm(in.getResultCorpName());
        originTrax.setMbrAddr(in.getResultAddress());
        originTrax.setMbrTelNo(in.getResultPhoneNumber());
        originTrax.setMbrMobileNo(in.getResultMobilePhoneNumber());
        originTrax.setMbrEmail(in.getResultEmail());
        originTrax.setMbrDvsnCd(in.getResultMemberSort());
        originTrax.setCorpSizeCd(in.getResultCompanySize());
        originTrax.setBizCd(in.getResultIndustryCode());

        entMbrLDao.updateOriginalTransaction(originTrax);

        /*
         * kftc 전문 생성
         * KftEnt0210220000CqeEnt0210220000
         */
        CqeEnt0210220000 sendVo = conversionService.convert(in, CqeEnt0210220000.class);
        sendVo.setMsgNo(originTrax.getHostNo());    // 원거래의 hostNo

        /*
         * KCG -> CQE 전송 : 전자어음 발행 응답
         */
        frwTemplate.send(FrwDestination.CQE_ENT, sendVo);
    }

    @Override
    public void handleError(KftEnt0210220000 in, Throwable t) {
        // 에러 응답 값 세팅 (공통화 메서드 호출)
        entCom.setOutboundResponseErrorVo(in, t);

        // 로그 출력: 전송 전에 inVo 내용 확인
        log.info("----------------- KftEnt0210220000: {} -----------------", in);

        // 에러 응답 전송은 본 handleError에서 처리
        frwTemplate.send(FrwDestination.KFT_ENT, in);
    }
}
