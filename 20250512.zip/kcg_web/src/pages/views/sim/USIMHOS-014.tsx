import { $eventUtils } from "@/utils/common.event"
/** ***********************************************************************
 * @ 서비스경로  : 시스템 > 시뮬레이션 > CMS시뮬데이터관리
 * @ 페이지설명  : [USIMHOS-014] CMS시뮬데이터관리
 * @ 파일명     : USIMHOS-014.tsx
 * @ 작성자     : 박민호 (minho.park2@bankwareglobal.com)
 * @ 작성일     : 2025-04-29
 ************************** 수정이력 ****************************************
 * 날짜                    작업자                 변경내용
 *_________________________________________________________________________
 * 2025-04-29             박민호                 최초작성
 ************************************************************************ */
import useProxy from "@/hooks/useProxy"
import useForm from "@/hooks/useForm"
import { $i18nUtils } from "@/utils/common.i18n"
import { useCallback, useEffect, useRef, useState } from "react"
import useCode from "@/hooks/useCode"
import useModal from "@/hooks/useModal"
import useGrid from "@/hooks/useGrid"
import useMenu from "@/hooks/useMenu"
import Grid from "@/components/Grid"
import SelectBox from "@/components/SelectBox"
import Button from "@/components/Button"
import ButtonGroup from "@/components/ButtonGroup"
import CardCol from "@/components/CardCol"
import CardRow from "@/components/CardRow"
import ContentToggle from "@/components/ContentToggle"
import DatePicker from "@/components/DatePicker"
import InputBox from "@/components/InputBox"
import LabelBox from "@/components/LabelBox"
import { $dateUtils } from "@/utils/common.date"
import { $bizUtils } from "@/utils/common.biz"
import { $formatUtils } from "@/utils/common.format"
import Page from "@/components/Page"
import useParams from "@/hooks/useParams"
import { CodeItem } from "@/types/index"

function USIMHOS014() {
  const _bizDvsnCd = "CMS"
  const $codeHooks = useCode()
  const $proxyHooks = useProxy()
  const $modalHooks = useModal()
  const $menuHooks = useMenu()
  const { params } = useParams()

  // 컴포넌트가 마운트될 때 데이터 조회
  useEffect(() => {
    if (params?.trDt && params?.fileBizDvsnCd && params?.fileBizDvsnCd) {
      initClick(null)
      setValue("trStaDt", params?.trDt)
      setValue("trEndDt", params?.trDt)
      setValue("fileBizDvsnCd", params?.fileBizDvsnCd)
      //setValue("bizDvsnCd", params?.bizDvsnCd)

      searchData(null, 1)
    } else if (params?.isDashboard) {
      initClick(null)
      setValue("inqryTp", "02") // 조회구분
      setValue("trStaDt", params.trDt)
      setValue("trEndDt", params.trDt)
      searchData(null, 1)
    }
  }, [params])

  // 조회조건 Form
  const { control, validate, getValues, setValue, reset } = useForm({
    formName: "searchForm",
    defaultValues: {
      inqryTp: "01", // 조회구분
      trStaDt: $dateUtils.today(),
      trEndDt: $dateUtils.today(),
      // srStaDt: $dateUtils.today(),
      // srEndDt: $dateUtils.today(),
      fileBizDvsnCd: "",
      prcsStsDvsnCd: "", // 상태코드
      acctNo: "", // 계좌번호
    },
  })

  const [isSrDtSearch, setIsSrDtSearch] = useState(false)

  const handleInqryTpChange = useCallback(() => {
    const inqryTp = getValues("inqryTp")

    if (inqryTp === "02") {
      // 거래일자별
      setIsSrDtSearch(false)
      // setValue("srStaDt", "") // Clear 송수신 시작일자
      // setValue("srEndDt", "") // Clear 송수신 종료일자
    } else {
      // 송수신일자별
      setIsSrDtSearch(true)
      // setValue("trStaDt", "") // Clear 거래 시작일자
      // setValue("trEndDt", "") // Clear 거래 종료일자
    }
  }, [getValues, setValue])

  useEffect(() => {
    handleInqryTpChange()
  }, getValues("inqryTp"))

  // 상세 조회 슬라이드창 controll
  const showBox = (show: boolean) => {
    if (show) {
      setCls({
        grid: "gridList active",
        box: "detailView active",
      })
    } else {
      setCls({ grid: "gridList", box: "detailView" })
    }
  }

  // 상세 조회 슬라이드창 출력 여부
  const [cls, setCls] = useState({
    grid: "gridList ",
    box: "detailView",
  })

  const searchData = (event: any, pgNbr: number) => {
    $eventUtils.setEventContext(event)
    validate().then((data: any) => {
      const param = {
        interfaceCd: "cms",
        interfaceId: "getCmsSndRcvFileList",
        trStaDt: data.trStaDt,
        trEndDt: data.trEndDt,
        bizDvsnCd: _bizDvsnCd, // CMS 고정
        //inqryTp: data?.inqryTp, // 조회구분   헤더/테일도 출력위해 주석
        fileBizDvsnCd: data.fileBizDvsnCd,
        acctNo: data.acctNo,
        prcsStsDvsnCd: data.prcsStsDvsnCd,
        pgNbr,
        pgCnt: 1000,
      }

      $proxyHooks.async(param).then((response: any) => {
        const bizDvsnCd = response.data.bizDvsnCd
        const listOutKey = `${bizDvsnCd.toLowerCase()}ListOut` // 동적으로 필드 이름 생성

        const listOutData = response.data[listOutKey] // 동적으로 데이터 접근

        if (pgNbr > 1) {
          // 스크롤이 전부 내려졌을 경우 데이터 추가
          setGridCount((prev) => ({
            ...prev,
            currentCnt: prev.currentCnt + (listOutData?.length ?? 0),
          }))
          setGridData((prev) => [...prev, ...(listOutData ?? [])])
        } else {
          // 첫 회 조회
          setGridData(() => listOutData)
          setGridCount((prevState) => ({
            ...prevState,
            totalCnt: response.data.totCnt,
            currentCnt: listOutData?.length,
          }))
          pagingRef.current.setPgNbr(pgNbr)
          pagingRef.current.setLastPgNbr(response.data.totCnt)
        }
        setTotalCnt(response.data.totCnt)
      })
    }),
      showBox(false)
  }
  const searchDtlData = (data: any) => {
    const param = {
      interfaceCd: "cmn",
      interfaceId: "getSndRcvFileDetailList",
      bizDvsnCd: data.bizDvsnCd,
      fileNm: data.fileNm,
      dataTp: data.dataTp,
      tlgCtt: data.tlgCtt || "",
      custNo: data.custNo || "",
    }
    $proxyHooks.async(param).then((response: any) => {
      setDtlGridData(() => response.data.listOut)
    })
  }

  // 그리드 config
  const [totalCnt, setTotalCnt] = useState(0)
  const gridRef = useRef<any>()
  const { gridConfig, setGridConfig, pagingRef } = useGrid({
    columnDefs: [
      {
        headerName: "",
        field: "check",
        checkboxSelection: true,
        headerCheckboxSelection: true,
        showDisabledCheckboxes: true,
        width: 50,
        pinned: "left",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#txDt"), //거래일자
        field: "trDt",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#srDt"), //송수신일자
        field: "srDt",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#fileNm"), //파일명
        field: "fileNm",
        cellClass: "t-center",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#seqNbr"), //seqNo
        field: "seqNo",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#prcsSts"), //프로세스상태
        field: "prcsStsDvsnCd",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#corpCd"), //이용기관코드
        field: "corpCd",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#payerNbr"), //납부자번호
        field: "rtpyrId",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#acctNbr"), //계좌번호
        field: "acctNo",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#reqAmt"), //의뢰금액
        field: "reqAmt",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#realPrcsAmt"), //실처리금액
        field: "realPrcsAmt",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#respCd"), //응답코드
        field: "respCd",
        valueFormatter: (param: any) =>
          $codeHooks.codeValue("CMS_RESP_CD", param.value, {
            visibleCode: true,
            visibleName: true,
          }),
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#svcFee"), //수수료
        field: "prcsFee",
        cellClass: "t-right",
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#sRFlag"), //송수신FLAG
        field: "srTp",
      },
      // {
      //   headerName: $i18nUtils.trans("SCRNITM#custNbr"), //고객번호
      //   field: "custNo",
      // },
      {
        headerName: $i18nUtils.trans("SCRNITM#msg"), //전문 내용
        field: "tlgCtt",
        minWidth: 800,
        cellClass: "t-left",
        cellStyle: {
          whiteSpace: "pre",
        },
      },
    ],
    // allFlexOption: "auto",

    suppressScrollOnNewData: true,
    pagingSetParam: {
      apiFunction: searchData,
    },

    // 행 클릭시 상세 조회 슬라이드창 출력
    onRowClicked: useCallback((event: any) => {
      showBox(true)
      searchDtlData(event.data)
    }, []),
  })

  // 그리드 data
  const [gridCount, setGridCount] = useState({ totalCnt: 0, currentCnt: 0 })
  const [gridData, setGridData] = useState<any[]>([])

  const initClick = (e: any) => {
    $eventUtils.setEventContext(e)

    reset()
    setGridData([])
    setTotalCnt(0)
    pagingRef.current.setPgNbr(1)
    pagingRef.current.setLastPgNbr(1)
    setGridCount({ totalCnt: 0, currentCnt: 0 })

    showBox(false)
    setDtlGridData([])
  }

  /**
   * 파일전문 상세 항목 그리드
   */
  const dtlGridRef = useRef<any>(null)
  const [dtlGridConfig, setDtlGridConfig] = useState({
    columnDefs: [
      {
        headerName: $i18nUtils.trans("SCRNITM#fieldName"), //항목명
        field: "detailKey",
        flex: 1,
      },
      {
        headerName: $i18nUtils.trans("SCRNITM#value"), //값
        field: "detailValue",
        flex: 1,
        cellClass: "t-left",
      },
    ],
  })

  const [dtlGridData, setDtlGridData] = useState<any[]>([])

  /**
   * 데이터 복사
   */
  const copyClick = (e: any) => {
    $eventUtils.setEventContext(e)

    const list = gridRef.current.getSelectedRows()

    if (list && list.length === 0) {
      $modalHooks.alert({ content: $i18nUtils.trans("MSG#noSelectedRow") }) // 선택된 행이 없습니다.
      return false
    }

    const simCmsSndRcvFilelIn = list.map((item: any) => ({
      ...item,
    }))

    $modalHooks
      .confirm({
        content: $i18nUtils.trans("MSG#exctConfirm"), // 실행하시겠습니까?
      })
      .then((ok) => {
        if (ok) {
          const param = {
            interfaceCd: "sim",
            interfaceId: "saveCmsSimData",
            simCmsSndRcvFilelIn: simCmsSndRcvFilelIn,
          }

          $proxyHooks.async(param).then(() => {
            setGridData([])
            setTotalCnt(0)
            setGridCount({ totalCnt: 0, currentCnt: 0 })
            pagingRef.current.setPgNbr(1)
            pagingRef.current.setLastPgNbr(1)
            gridRef.current.refreshCells()

            searchData(null, 1) // 재조회
          })
        }
      })
  }

  /**
   * 데이터 삭제
   */
  const deleteClick = (e: any) => {
    $eventUtils.setEventContext(e)

    const list = gridRef.current.getSelectedRows()

    if (list && list.length === 0) {
      $modalHooks.alert({ content: $i18nUtils.trans("MSG#noSelectedRow") }) // 선택된 행이 없습니다.
      return false
    }

    const simCmsSndRcvFilelIn = list.map((item: any) => ({
      ...item,
    }))

    $modalHooks
      .confirm({
        content: $i18nUtils.trans("MSG#exctConfirm"), // 실행하시겠습니까?
      })
      .then((ok) => {
        if (ok) {
          const param = {
            interfaceCd: "sim",
            interfaceId: "deleteCmsSimData",
            simCmsSndRcvFilelIn: simCmsSndRcvFilelIn,
          }

          $proxyHooks.async(param).then(() => {
            setGridData([])
            setTotalCnt(0)
            setGridCount({ totalCnt: 0, currentCnt: 0 })
            pagingRef.current.setPgNbr(1)
            pagingRef.current.setLastPgNbr(1)
            gridRef.current.refreshCells()

            searchData(null, 1) // 재조회
          })
        }
      })
  }

  const modifyClick = (e: any) => {
    $eventUtils.setEventContext(e)

    $modalHooks
      .confirm({ content: $i18nUtils.trans("MSG#updateCnfMsg") }) // 내용을 수정하시겠습니까?
      .then((ok) => {
        if (!ok) return

        const param = {
          interfaceCd: "sim",
          interfaceId: "modifyCmsSimData",
        }

        $proxyHooks.async(param).then((response: any) => {
          initClick(e)
          searchData(null, 1) // 재조회
        })
      })
  }

  /**
   * xlsx 다운로드
   */
  const xlsxClick = () => {
    const printData = gridData.map((obj: any) => {
      const {
        srDt,
        trDt,
        fileNm,
        dataTp,
        seqNo,
        srTp,
        prcsStsDvsnCd,
        respCd,
        corpCd,
        rtpyrId,
        custNo,
        acctNo,
        reqAmt,
        realPrcsAmt,
        prcsFee,
        tlgCtt,
      } = obj
      return {
        srDt,
        trDt,
        fileNm,
        dataTp,
        seqNo,
        srTp,
        prcsStsDvsnCd: $codeHooks.codeValue("PRCS_STS_DVSN_CD", prcsStsDvsnCd),
        respCd,
        corpCd,
        rtpyrId,
        custNo,
        acctNo,
        reqAmt,
        realPrcsAmt,
        prcsFee,
        tlgCtt,
      }
    })
    gridRef.current.exportExcel(
      {
        fileName: "USIMHOS-014",
        printData: printData,
      },
      () => {
        $modalHooks.alert({ content: $i18nUtils.trans("MSG#noOutputData") }) // 출력할 DATA 가 없습니다.
      },
    )
  }

  const selectList: CodeItem[] = [
    {
      labelField: $i18nUtils.trans("SCRNITM#srDt"),
      codeField: "01",
    },
    {
      labelField: $i18nUtils.trans("SCRNITM#txDt"),
      codeField: "02",
    },
  ]
  /**
   * 파일구분번호 Select Box
   */
  const [fileNoList, setfileNoList] = useState([])

  useEffect(() => {
    searchFileNoList() // 자동조회
  }, [])

  const searchFileNoList = () => {
    const options = {
      disableLoading: true, // 로딩창
      toastLoading: false, // 토스트
    }

    const param = {
      interfaceCd: "cmn",
      interfaceId: "getFileNoList",
      bizDvsnCd: _bizDvsnCd,
    }
    $proxyHooks.async(param, options).then((response: any) => {
      setfileNoList(response.data.outList)
    })
  }

  return (
    <Page>
      <div className="row-group">
        {/** Sub Content S */}
        <div className="sub-content search-wrap">
          <h3 className="tit">{$i18nUtils.trans("SCRNITM#srchCndtn")}</h3>
          <ButtonGroup>
            <Button
              name="init"
              i18n={$i18nUtils.trans("SCRNITM#init")}
              color="white"
              onClick={initClick}
            >
              초기화
            </Button>
            <Button
              name="search"
              i18n={$i18nUtils.trans("SCRNITM#search")}
              color="blue"
              onClick={(event) => searchData(event, 1)}
            >
              조회
            </Button>
          </ButtonGroup>
          <ContentToggle />

          {/* 조회조건 시작 */}
          <div className="view-box" data-form="searchForm">
            <CardRow cols={6}>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#inqryTp")}>
                  조회구분
                </LabelBox>
                <SelectBox
                  control={control}
                  name="inqryTp"
                  list={selectList}
                  blankType="all"
                  i18n={$i18nUtils.trans("SCRNITM#inqryTp")}
                  onChange={handleInqryTpChange}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#srDt")}>
                  송수신일자
                </LabelBox>
                <div className="unit datepicker-wrap">
                  <DatePicker
                    control={control}
                    name="trStaDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchFromDt")}
                    rules={{
                      required: { value: isSrDtSearch },
                    }}
                    disabled={!isSrDtSearch} // inqryTp 값에 따라 disabled 속성 설정
                  />
                  <DatePicker
                    control={control}
                    name="trEndDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchToDt")}
                    rules={{
                      validate: {
                        validItem: (v: any) =>
                          $bizUtils.validateMessage({
                            value: getValues("trStaDt") > getValues("trEndDt"),
                            message: $i18nUtils.trans("MSG#validMinDate", {
                              0: $i18nUtils.trans("SCRNITM#strtDt"),
                              1: $formatUtils.dateFormat(getValues("trStaDt")),
                              2: $i18nUtils.trans("SCRNITM#endDt"),
                              3: $formatUtils.dateFormat(v),
                            }),
                          }),
                      },
                      required: { value: isSrDtSearch },
                    }}
                    disabled={!isSrDtSearch} // inqryTp 값에 따라 disabled 속성 설정
                  />
                </div>
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#txDt")}>
                  거래일자
                </LabelBox>
                <div className="unit datepicker-wrap">
                  <DatePicker
                    control={control}
                    name="trStaDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchFromDt")}
                    rules={{
                      required: { value: !isSrDtSearch },
                    }}
                    disabled={isSrDtSearch} // inqryTp 값에 따라 disabled 속성 설정
                  />
                  <DatePicker
                    control={control}
                    name="trEndDt"
                    i18n={$i18nUtils.trans("SCRNITM#srchToDt")}
                    rules={{
                      validate: {
                        validItem: (v: any) =>
                          $bizUtils.validateMessage({
                            value: getValues("trStaDt") > getValues("trEndDt"),
                            message: $i18nUtils.trans("MSG#validMinDate", {
                              0: $i18nUtils.trans("SCRNITM#strtDt"),
                              1: $formatUtils.dateFormat(getValues("trStaDt")),
                              2: $i18nUtils.trans("SCRNITM#endDt"),
                              3: $formatUtils.dateFormat(v),
                            }),
                          }),
                      },
                      required: { value: !isSrDtSearch },
                    }}
                    disabled={isSrDtSearch} // inqryTp 값에 따라 disabled 속성 설정
                  />
                </div>
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#fileGbNo")}>
                  파일구분번호
                </LabelBox>
                <SelectBox
                  control={control}
                  name="fileBizDvsnCd"
                  list={fileNoList}
                  i18n={$i18nUtils.trans("SCRNITM#fileGbNo")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#endrStsCd")}>
                  상태 코드
                </LabelBox>
                <SelectBox
                  control={control}
                  name="prcsStsDvsnCd"
                  listPromise={$codeHooks.getCodeList("PRCS_STS_DVSN_CD")}
                  blankType="all"
                  i18n={$i18nUtils.trans("SCRNITM#endrStsCd")}
                />
              </CardCol>
              <CardCol>
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#acctNbr")} />
                <span className="unit">
                  <InputBox
                    control={control}
                    name="acctNo"
                    i18n={$i18nUtils.trans("SCRNITM#acctNbr")}
                    mask={{
                      mask: "00000000000000",
                    }}
                    rules={{
                      pattern: {
                        value: /[0-9]/,
                        message: $i18nUtils.trans("MSG#checkNum", {
                          0: $i18nUtils.trans("SCRNITM#acctNo"),
                        }),
                        maxLength: { value: 14 },
                      },
                    }}
                  />
                </span>
              </CardCol>
            </CardRow>
          </div>
        </div>
        {/* 조회조건 끝 */}
        <div className="col-group">
          {/** 조회결과 그리드 시작 */}
          <div className={cls.grid}>
            <div className="sub-content">
              <h3 className="tit">
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#totCnt")} />{" "}
                {gridCount?.currentCnt} / {totalCnt}{" "}
                <LabelBox i18n={$i18nUtils.trans("SCRNITM#case")} />
              </h3>
              <ButtonGroup className="m-right">
                <Button
                  name="copy"
                  i18n={$i18nUtils.trans("SCRNITM#copy")}
                  color="white btn-sm"
                  onClick={copyClick}
                >
                  복사
                </Button>
                <Button
                  name="delete"
                  i18n={$i18nUtils.trans("SCRNITM#delete")}
                  color="white"
                  icon="delete"
                  onClick={deleteClick}
                >
                  삭제
                </Button>
                <Button
                  name="excel"
                  i18n={$i18nUtils.trans("SCRNITM#excel")}
                  color="white"
                  icon="down"
                  onClick={xlsxClick}
                >
                  Excel
                </Button>
              </ButtonGroup>
              <div className="view-box active">
                <div className="col-01">
                  <div className="cmm-table">
                    <Grid
                      config={gridConfig}
                      rowData={gridData}
                      ref={gridRef}
                      height={480}
                      selection="multiple"
                    ></Grid>
                  </div>
                </div>
              </div>
            </div>

            {/** // 조회결과 그리드 종료 */}

            {/** Sub Content E */}
          </div>
          {/** Sub Content S */}
          <div className={cls.box}>
            <div className="sub-content">
              <div className="title-wrap" data-form="detailSearchForm">
                <h3 className="tit">{$i18nUtils.trans("SCRNITM#dtl")}</h3>
                <ButtonGroup className="m-right">
                  <Button
                    name="close"
                    i18n={$i18nUtils.trans("SCRNITM#close")}
                    color="white"
                    onClick={() => showBox(false)}
                    icon="close"
                  >
                    닫기
                  </Button>
                  <Button
                    name="modify"
                    i18n={$i18nUtils.trans("SCRNITM#modify")}
                    color="white"
                    icon="modify"
                    onClick={modifyClick}
                  >
                    수정
                  </Button>
                </ButtonGroup>
              </div>
              <div className="view-box active">
                <div className="col-01">
                  <div className="cmm-table">
                    <Grid
                      config={dtlGridConfig}
                      rowData={dtlGridData}
                      ref={dtlGridRef}
                      height={500}
                    ></Grid>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Page>
  )
}

export default USIMHOS014
