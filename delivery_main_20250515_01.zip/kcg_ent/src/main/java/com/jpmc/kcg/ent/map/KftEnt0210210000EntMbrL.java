package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.KftEnt0210210000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Mapper(componentModel = "spring", imports = {LocalDateTime.class, BigDecimal.class, DateUtils.class, EntConst.class, ComConst.class})
public interface KftEnt0210210000EntMbrL extends Converter<KftEnt0210210000, EntMbrL> {

    @Override
    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())")
    @Mapping(target = "entTlgTrceNo", source = "messageTrackingNumber")
    @Mapping(target = "trUnqNo", source = "transactionIdNumber")
    @Mapping(target = "hostNo", ignore = true)
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.INBOUND_CD)")
    @Mapping(target = "othrPartyBnkCd", ignore = true)
    @Mapping(target = "sysDvsn", source = "systemId")
    @Mapping(target = "bnkCd", source = "bnkCd")
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType")
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode")
    @Mapping(target = "sndRcvDvsnCd", source = "sendReceiveFlag")
    @Mapping(target = "trSts", source = "status")
    @Mapping(target = "respCd1", source = "responseCode1")
    @Mapping(target = "respCd2", source = "responseCode2")
    @Mapping(target = "tlgTrDt", source = "messageSendTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "messageSendTime", dateFormat = "HHmmss")
    @Mapping(target = "kftcStattcCd", source = "kftcStatisticsCode")
    @Mapping(target = "trMemo", ignore = true)
    @Mapping(target = "srchCondSort", ignore = true)
    @Mapping(target = "condCtzBizNoEnc", ignore = true)
    @Mapping(target = "condBnkCd", ignore = true)
    @Mapping(target = "condDpstAcctNo", ignore = true)
    @Mapping(target = "ctzBizNoEnc", ignore = true)
    @Mapping(target = "currAcctNo", source = "currentAccountNumber")
    @Mapping(target = "dpstAcctNo", source = "depositAccountNumber")
    @Mapping(target = "ctzBizNo", source = "residentBusinessNumber")
    @Mapping(target = "entPrcsDvsnCd", source = "processSort")
    @Mapping(target = "corpIndvDvsnCd", source = "corpIndvSort")
    @Mapping(target = "repNm", source = "nameRepresentativeName")
    @Mapping(target = "corpNm", source = "corpName")
    @Mapping(target = "mbrAddr", source = "address")
    @Mapping(target = "mbrTelNo", source = "phoneNumber")
    @Mapping(target = "mbrMobileNo", source = "mobilePhoneNumber")
    @Mapping(target = "mbrEmail", source = "emailAddress")
    @Mapping(target = "pymntExCd", source = "paymentBranchClearingHouseCode")
    @Mapping(target = "pymntRqstRegBnkCd", source = "paymentRegisterRequestBankCode")
    @Mapping(target = "pymntBnkBrnchCd", source = "paymentRegisterRequestBankBranchCode")
    @Mapping(target = "entCurrOpnDt", source = "ENoteCurrentTransactionStartEndDate")
    @Mapping(target = "corpSizeCd", source = "companySize")
    @Mapping(target = "bizCd", source = "industryCode")

    @Mapping(target = "srchCondSort2", ignore = true)
    @Mapping(target = "condCtzBizNoEnc2", ignore = true)
    @Mapping(target = "condBnkCd2", ignore = true)
    @Mapping(target = "condDpstAcctNo2", ignore = true)
    @Mapping(target = "corpIndvDvsnCd2", ignore = true)
    @Mapping(target = "repNm2", ignore = true)
    @Mapping(target = "corpNm2", ignore = true)
    @Mapping(target = "mbrAddr2", ignore = true)
    @Mapping(target = "mbrTelNo2", ignore = true)
    @Mapping(target = "mbrMobileNo2", ignore = true)
    @Mapping(target = "mbrEmail2", ignore = true)
    @Mapping(target = "corpSizeCd2", ignore = true)
    @Mapping(target = "mbrDvsnCd2", ignore = true)
    @Mapping(target = "bizCd2", ignore = true)

    @Mapping(target = "lmtAmt", expression = "java(BigDecimal.valueOf(source.getLimitAmount()))")
    @Mapping(target = "mbrDvsnCd", source = "memberSort")
    @Mapping(target = "chgAfCurrAcctNo", source = "afterChangeCurrentAccountNumber")
    @Mapping(target = "chgAfDpstAcctNo", source = "afterChangeDepositAccountNumber")
    @Mapping(target = "frstChngGuid", ignore = true)
    @Mapping(target = "frstChngStaffId", ignore = true)
    @Mapping(target = "frstChngTmstmp", ignore = true)
    @Mapping(target = "lastChngGuid", ignore = true)
    @Mapping(target = "lastChngStaffId", ignore = true)
    @Mapping(target = "lastChngTmstmp", ignore = true)
    EntMbrL convert(KftEnt0210210000 source);
}
