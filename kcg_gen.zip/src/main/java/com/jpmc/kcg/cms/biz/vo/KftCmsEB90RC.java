package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 이용기관정보통지
 * <pre>{@code
 * KftCmsEB90RC kftCmsEB90RC  = new KftCmsEB90RC(); // 이용기관정보통지
 * kftCmsEB90RC.setRecordType(""); // Record 구분
 * kftCmsEB90RC.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB90RC.setDataRecordType(""); // Data Record 구분코드
 * kftCmsEB90RC.setInstitutionCode(""); // 기관코드
 * kftCmsEB90RC.setChangeSeqBitMap(""); // 변경항번BitMap
 * kftCmsEB90RC.setDepositPaymentAcctBranchCode(""); // 입금이체지급계좌점코드
 * kftCmsEB90RC.setDepositPaymentAcctNo(""); // 입금이체지급계좌번호
 * kftCmsEB90RC.setWithdrawal3DayCollectionAcctBranchCode(""); // 출금이체(3일)수납계좌점코드
 * kftCmsEB90RC.setWithdrawal3DayCollectionAcctNo(""); // 출금이체(3일)수납계좌번호
 * kftCmsEB90RC.setRealTimeWithdrawalAcctBranchCode(""); // 실시간출금계좌점코드
 * kftCmsEB90RC.setRealTimeWithdrawalAcctNo(""); // 실시간출금계좌번호
 * kftCmsEB90RC.setPayerNumberSystem1(""); // 납부자번호 체계 1
 * kftCmsEB90RC.setPayerNumberSystem2(""); // 납부자번호 체계 2
 * kftCmsEB90RC.setPayerNumberSystem3(""); // 납부자번호 체계 3
 * kftCmsEB90RC.setPayerNumberSystem4(""); // 납부자번호 체계 4
 * kftCmsEB90RC.setPayerNumberSystem5(""); // 납부자번호 체계 5
 * kftCmsEB90RC.setWithdrawalSameDayCollectionAcctBranchCode(""); // 출금이체(당일)수납계좌점코드
 * kftCmsEB90RC.setWithdrawalSameDayCollectionAcctNo(""); // 출금이체(당일)수납계좌번호
 * kftCmsEB90RC.setFiller4(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB90RC implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String dataRecordType; // Data Record 구분코드
	private String institutionCode; // 기관코드
	private String changeSeqBitMap; // 변경항번BitMap
	private String depositPaymentAcctBranchCode; // 입금이체지급계좌점코드
	private String depositPaymentAcctNo; // 입금이체지급계좌번호
	private String withdrawal3DayCollectionAcctBranchCode; // 출금이체(3일)수납계좌점코드
	private String withdrawal3DayCollectionAcctNo; // 출금이체(3일)수납계좌번호
	private String realTimeWithdrawalAcctBranchCode; // 실시간출금계좌점코드
	private String realTimeWithdrawalAcctNo; // 실시간출금계좌번호
	private String payerNumberSystem1; // 납부자번호 체계 1
	private String payerNumberSystem2; // 납부자번호 체계 2
	private String payerNumberSystem3; // 납부자번호 체계 3
	private String payerNumberSystem4; // 납부자번호 체계 4
	private String payerNumberSystem5; // 납부자번호 체계 5
	private String withdrawalSameDayCollectionAcctBranchCode; // 출금이체(당일)수납계좌점코드
	private String withdrawalSameDayCollectionAcctNo; // 출금이체(당일)수납계좌번호
	private String filler4; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataRecordType$; // Data Record 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String changeSeqBitMap$; // 변경항번BitMap
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositPaymentAcctBranchCode$; // 입금이체지급계좌점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositPaymentAcctNo$; // 입금이체지급계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawal3DayCollectionAcctBranchCode$; // 출금이체(3일)수납계좌점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawal3DayCollectionAcctNo$; // 출금이체(3일)수납계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeWithdrawalAcctBranchCode$; // 실시간출금계좌점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realTimeWithdrawalAcctNo$; // 실시간출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystem1$; // 납부자번호 체계 1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystem2$; // 납부자번호 체계 2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystem3$; // 납부자번호 체계 3
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystem4$; // 납부자번호 체계 4
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumberSystem5$; // 납부자번호 체계 5
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalSameDayCollectionAcctBranchCode$; // 출금이체(당일)수납계좌점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalSameDayCollectionAcctNo$; // 출금이체(당일)수납계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		dataRecordType$ = VOUtils.write(out, dataRecordType, 1); // Data Record 구분코드
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		changeSeqBitMap$ = VOUtils.write(out, changeSeqBitMap, 15); // 변경항번BitMap
		depositPaymentAcctBranchCode$ = VOUtils.write(out, depositPaymentAcctBranchCode, 7); // 입금이체지급계좌점코드
		depositPaymentAcctNo$ = VOUtils.write(out, depositPaymentAcctNo, 20); // 입금이체지급계좌번호
		withdrawal3DayCollectionAcctBranchCode$ = VOUtils.write(out, withdrawal3DayCollectionAcctBranchCode, 7); // 출금이체(3일)수납계좌점코드
		withdrawal3DayCollectionAcctNo$ = VOUtils.write(out, withdrawal3DayCollectionAcctNo, 20); // 출금이체(3일)수납계좌번호
		realTimeWithdrawalAcctBranchCode$ = VOUtils.write(out, realTimeWithdrawalAcctBranchCode, 7); // 실시간출금계좌점코드
		realTimeWithdrawalAcctNo$ = VOUtils.write(out, realTimeWithdrawalAcctNo, 20); // 실시간출금계좌번호
		payerNumberSystem1$ = VOUtils.write(out, payerNumberSystem1, 20); // 납부자번호 체계 1
		payerNumberSystem2$ = VOUtils.write(out, payerNumberSystem2, 20); // 납부자번호 체계 2
		payerNumberSystem3$ = VOUtils.write(out, payerNumberSystem3, 20); // 납부자번호 체계 3
		payerNumberSystem4$ = VOUtils.write(out, payerNumberSystem4, 20); // 납부자번호 체계 4
		payerNumberSystem5$ = VOUtils.write(out, payerNumberSystem5, 20); // 납부자번호 체계 5
		withdrawalSameDayCollectionAcctBranchCode$ = VOUtils.write(out, withdrawalSameDayCollectionAcctBranchCode, 7); // 출금이체(당일)수납계좌점코드
		withdrawalSameDayCollectionAcctNo$ = VOUtils.write(out, withdrawalSameDayCollectionAcctNo, 20); // 출금이체(당일)수납계좌번호
		filler4$ = VOUtils.write(out, filler4, 7); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		dataRecordType = VOUtils.toString(dataRecordType$ = VOUtils.read(in, 1)); // Data Record 구분코드
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		changeSeqBitMap = VOUtils.toString(changeSeqBitMap$ = VOUtils.read(in, 15)); // 변경항번BitMap
		depositPaymentAcctBranchCode = VOUtils.toString(depositPaymentAcctBranchCode$ = VOUtils.read(in, 7)); // 입금이체지급계좌점코드
		depositPaymentAcctNo = VOUtils.toString(depositPaymentAcctNo$ = VOUtils.read(in, 20)); // 입금이체지급계좌번호
		withdrawal3DayCollectionAcctBranchCode = VOUtils.toString(withdrawal3DayCollectionAcctBranchCode$ = VOUtils.read(in, 7)); // 출금이체(3일)수납계좌점코드
		withdrawal3DayCollectionAcctNo = VOUtils.toString(withdrawal3DayCollectionAcctNo$ = VOUtils.read(in, 20)); // 출금이체(3일)수납계좌번호
		realTimeWithdrawalAcctBranchCode = VOUtils.toString(realTimeWithdrawalAcctBranchCode$ = VOUtils.read(in, 7)); // 실시간출금계좌점코드
		realTimeWithdrawalAcctNo = VOUtils.toString(realTimeWithdrawalAcctNo$ = VOUtils.read(in, 20)); // 실시간출금계좌번호
		payerNumberSystem1 = VOUtils.toString(payerNumberSystem1$ = VOUtils.read(in, 20)); // 납부자번호 체계 1
		payerNumberSystem2 = VOUtils.toString(payerNumberSystem2$ = VOUtils.read(in, 20)); // 납부자번호 체계 2
		payerNumberSystem3 = VOUtils.toString(payerNumberSystem3$ = VOUtils.read(in, 20)); // 납부자번호 체계 3
		payerNumberSystem4 = VOUtils.toString(payerNumberSystem4$ = VOUtils.read(in, 20)); // 납부자번호 체계 4
		payerNumberSystem5 = VOUtils.toString(payerNumberSystem5$ = VOUtils.read(in, 20)); // 납부자번호 체계 5
		withdrawalSameDayCollectionAcctBranchCode = VOUtils.toString(withdrawalSameDayCollectionAcctBranchCode$ = VOUtils.read(in, 7)); // 출금이체(당일)수납계좌점코드
		withdrawalSameDayCollectionAcctNo = VOUtils.toString(withdrawalSameDayCollectionAcctNo$ = VOUtils.read(in, 20)); // 출금이체(당일)수납계좌번호
		filler4 = VOUtils.toString(filler4$ = VOUtils.read(in, 7)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", dataRecordType=").append(dataRecordType).append(System.lineSeparator()); // Data Record 구분코드
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", changeSeqBitMap=").append(changeSeqBitMap).append(System.lineSeparator()); // 변경항번BitMap
		sb.append(", depositPaymentAcctBranchCode=").append(depositPaymentAcctBranchCode).append(System.lineSeparator()); // 입금이체지급계좌점코드
		sb.append(", depositPaymentAcctNo=").append(depositPaymentAcctNo).append(System.lineSeparator()); // 입금이체지급계좌번호
		sb.append(", withdrawal3DayCollectionAcctBranchCode=").append(withdrawal3DayCollectionAcctBranchCode).append(System.lineSeparator()); // 출금이체(3일)수납계좌점코드
		sb.append(", withdrawal3DayCollectionAcctNo=").append(withdrawal3DayCollectionAcctNo).append(System.lineSeparator()); // 출금이체(3일)수납계좌번호
		sb.append(", realTimeWithdrawalAcctBranchCode=").append(realTimeWithdrawalAcctBranchCode).append(System.lineSeparator()); // 실시간출금계좌점코드
		sb.append(", realTimeWithdrawalAcctNo=").append(realTimeWithdrawalAcctNo).append(System.lineSeparator()); // 실시간출금계좌번호
		sb.append(", payerNumberSystem1=").append(payerNumberSystem1).append(System.lineSeparator()); // 납부자번호 체계 1
		sb.append(", payerNumberSystem2=").append(payerNumberSystem2).append(System.lineSeparator()); // 납부자번호 체계 2
		sb.append(", payerNumberSystem3=").append(payerNumberSystem3).append(System.lineSeparator()); // 납부자번호 체계 3
		sb.append(", payerNumberSystem4=").append(payerNumberSystem4).append(System.lineSeparator()); // 납부자번호 체계 4
		sb.append(", payerNumberSystem5=").append(payerNumberSystem5).append(System.lineSeparator()); // 납부자번호 체계 5
		sb.append(", withdrawalSameDayCollectionAcctBranchCode=").append(withdrawalSameDayCollectionAcctBranchCode).append(System.lineSeparator()); // 출금이체(당일)수납계좌점코드
		sb.append(", withdrawalSameDayCollectionAcctNo=").append(withdrawalSameDayCollectionAcctNo).append(System.lineSeparator()); // 출금이체(당일)수납계좌번호
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "dataRecordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "changeSeqBitMap", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositPaymentAcctBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "depositPaymentAcctNo", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "withdrawal3DayCollectionAcctBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "withdrawal3DayCollectionAcctNo", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "realTimeWithdrawalAcctBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "realTimeWithdrawalAcctNo", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "payerNumberSystem1", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "payerNumberSystem2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "payerNumberSystem3", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "payerNumberSystem4", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "payerNumberSystem5", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "withdrawalSameDayCollectionAcctBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "withdrawalSameDayCollectionAcctNo", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler4", "fldLen", "7", "defltVal", "")
		);
	}

}
