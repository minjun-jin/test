package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금융공동망 월간 총거래현황
 * <pre>{@code
 * KftHofEL1133R kftHofEL1133R  = new KftHofEL1133R(); // 전자금융공동망 월간 총거래현황
 * kftHofEL1133R.setFileName(""); // 업무구분
 * kftHofEL1133R.setDataType(""); // 데이타구분
 * kftHofEL1133R.setSerialNumber(""); // 일련번호
 * kftHofEL1133R.setOpenHandlingClassification(""); // 개설/취급구분
 * kftHofEL1133R.setBnkCd(""); // 은행코드
 * kftHofEL1133R.setTransactionCode(""); // 거래구분코드
 * kftHofEL1133R.setHandlingCount(0L); // 취급건수
 * kftHofEL1133R.setOpenTransactionCount(0L); // 개설건수
 * kftHofEL1133R.setNormalProcessApprovalCount(0L); // 정상처리승인거래건수
 * kftHofEL1133R.setNormalProcessRejectCount(0L); // 정상처리거부거래건수
 * kftHofEL1133R.setAgentProcessNoResponseCount(0L); // 대행처리무응답건수
 * kftHofEL1133R.setAgentProcessDelayedResponseCount(0L); // 대행처리지연응답건수
 * kftHofEL1133R.setAgentProcessOpenFailureCount(0L); // 대행처리개설장애건수
 * kftHofEL1133R.setAgentProcessOpenPendingCount(0L); // 대행처리개설미완료건수
 * kftHofEL1133R.setHandlingCancelCount(0L); // 취급취소건수
 * kftHofEL1133R.setErrorTransactionCount(0L); // 오류거래건수
 * kftHofEL1133R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL1133R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String openHandlingClassification; // 개설/취급구분
	private String bnkCd; // 은행코드
	private String transactionCode; // 거래구분코드
	private long handlingCount; // 취급건수
	private long openTransactionCount; // 개설건수
	private long normalProcessApprovalCount; // 정상처리승인거래건수
	private long normalProcessRejectCount; // 정상처리거부거래건수
	private long agentProcessNoResponseCount; // 대행처리무응답건수
	private long agentProcessDelayedResponseCount; // 대행처리지연응답건수
	private long agentProcessOpenFailureCount; // 대행처리개설장애건수
	private long agentProcessOpenPendingCount; // 대행처리개설미완료건수
	private long handlingCancelCount; // 취급취소건수
	private long errorTransactionCount; // 오류거래건수
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String openHandlingClassification$; // 개설/취급구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingCount$; // 취급건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String openTransactionCount$; // 개설건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String normalProcessApprovalCount$; // 정상처리승인거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String normalProcessRejectCount$; // 정상처리거부거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String agentProcessNoResponseCount$; // 대행처리무응답건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String agentProcessDelayedResponseCount$; // 대행처리지연응답건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String agentProcessOpenFailureCount$; // 대행처리개설장애건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String agentProcessOpenPendingCount$; // 대행처리개설미완료건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingCancelCount$; // 취급취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String errorTransactionCount$; // 오류거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		openHandlingClassification$ = VOUtils.write(out, openHandlingClassification, 1); // 개설/취급구분
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		handlingCount$ = VOUtils.write(out, handlingCount, 10); // 취급건수
		openTransactionCount$ = VOUtils.write(out, openTransactionCount, 10); // 개설건수
		normalProcessApprovalCount$ = VOUtils.write(out, normalProcessApprovalCount, 10); // 정상처리승인거래건수
		normalProcessRejectCount$ = VOUtils.write(out, normalProcessRejectCount, 10); // 정상처리거부거래건수
		agentProcessNoResponseCount$ = VOUtils.write(out, agentProcessNoResponseCount, 10); // 대행처리무응답건수
		agentProcessDelayedResponseCount$ = VOUtils.write(out, agentProcessDelayedResponseCount, 10); // 대행처리지연응답건수
		agentProcessOpenFailureCount$ = VOUtils.write(out, agentProcessOpenFailureCount, 10); // 대행처리개설장애건수
		agentProcessOpenPendingCount$ = VOUtils.write(out, agentProcessOpenPendingCount, 10); // 대행처리개설미완료건수
		handlingCancelCount$ = VOUtils.write(out, handlingCancelCount, 10); // 취급취소건수
		errorTransactionCount$ = VOUtils.write(out, errorTransactionCount, 10); // 오류거래건수
		filler$ = VOUtils.write(out, filler, 55); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		openHandlingClassification = VOUtils.toString(openHandlingClassification$ = VOUtils.read(in, 1)); // 개설/취급구분
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		handlingCount = VOUtils.toLong(handlingCount$ = VOUtils.read(in, 10)); // 취급건수
		openTransactionCount = VOUtils.toLong(openTransactionCount$ = VOUtils.read(in, 10)); // 개설건수
		normalProcessApprovalCount = VOUtils.toLong(normalProcessApprovalCount$ = VOUtils.read(in, 10)); // 정상처리승인거래건수
		normalProcessRejectCount = VOUtils.toLong(normalProcessRejectCount$ = VOUtils.read(in, 10)); // 정상처리거부거래건수
		agentProcessNoResponseCount = VOUtils.toLong(agentProcessNoResponseCount$ = VOUtils.read(in, 10)); // 대행처리무응답건수
		agentProcessDelayedResponseCount = VOUtils.toLong(agentProcessDelayedResponseCount$ = VOUtils.read(in, 10)); // 대행처리지연응답건수
		agentProcessOpenFailureCount = VOUtils.toLong(agentProcessOpenFailureCount$ = VOUtils.read(in, 10)); // 대행처리개설장애건수
		agentProcessOpenPendingCount = VOUtils.toLong(agentProcessOpenPendingCount$ = VOUtils.read(in, 10)); // 대행처리개설미완료건수
		handlingCancelCount = VOUtils.toLong(handlingCancelCount$ = VOUtils.read(in, 10)); // 취급취소건수
		errorTransactionCount = VOUtils.toLong(errorTransactionCount$ = VOUtils.read(in, 10)); // 오류거래건수
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 55)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", openHandlingClassification=").append(openHandlingClassification).append(System.lineSeparator()); // 개설/취급구분
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", handlingCount=").append(handlingCount).append(System.lineSeparator()); // 취급건수
		sb.append(", openTransactionCount=").append(openTransactionCount).append(System.lineSeparator()); // 개설건수
		sb.append(", normalProcessApprovalCount=").append(normalProcessApprovalCount).append(System.lineSeparator()); // 정상처리승인거래건수
		sb.append(", normalProcessRejectCount=").append(normalProcessRejectCount).append(System.lineSeparator()); // 정상처리거부거래건수
		sb.append(", agentProcessNoResponseCount=").append(agentProcessNoResponseCount).append(System.lineSeparator()); // 대행처리무응답건수
		sb.append(", agentProcessDelayedResponseCount=").append(agentProcessDelayedResponseCount).append(System.lineSeparator()); // 대행처리지연응답건수
		sb.append(", agentProcessOpenFailureCount=").append(agentProcessOpenFailureCount).append(System.lineSeparator()); // 대행처리개설장애건수
		sb.append(", agentProcessOpenPendingCount=").append(agentProcessOpenPendingCount).append(System.lineSeparator()); // 대행처리개설미완료건수
		sb.append(", handlingCancelCount=").append(handlingCancelCount).append(System.lineSeparator()); // 취급취소건수
		sb.append(", errorTransactionCount=").append(errorTransactionCount).append(System.lineSeparator()); // 오류거래건수
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "openHandlingClassification", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "handlingCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "openTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "normalProcessApprovalCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "normalProcessRejectCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "agentProcessNoResponseCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "agentProcessDelayedResponseCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "agentProcessOpenFailureCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "agentProcessOpenPendingCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "handlingCancelCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "errorTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "55", "defltVal", "")
		);
	}

}
