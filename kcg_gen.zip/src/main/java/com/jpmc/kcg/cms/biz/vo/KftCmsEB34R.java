package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.Mac;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 출금통보
 * <pre>{@code
 * KftCmsEB34R kftCmsEB34R  = new KftCmsEB34R(); // 출금통보
 * kftCmsEB34R.setRecordType(""); // Record 구분
 * kftCmsEB34R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB34R.setInstitutionCode(""); // 기관코드
 * kftCmsEB34R.setMainBankBranchCode(""); // 주거래은행점코드
 * kftCmsEB34R.setWithdrawalAccountNumber(""); // 출금계좌번호
 * kftCmsEB34R.setRequestedWithdrawalCount(0); // 출금의뢰건수
 * kftCmsEB34R.setWithdrawalAmount(0L); // 출금액
 * kftCmsEB34R.setWithdrawalResultWithdrawalYn(""); // 출금결과 출금여부
 * kftCmsEB34R.setWithdrawalResultFailedCode(""); // 출금결과 불능코드
 * kftCmsEB34R.setTotalFee(0L); // 총수수료
 * kftCmsEB34R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB34R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String mainBankBranchCode; // 주거래은행점코드
	private String withdrawalAccountNumber; // 출금계좌번호
	private int requestedWithdrawalCount; // 출금의뢰건수
	private long withdrawalAmount; // 출금액
	private String withdrawalResultWithdrawalYn; // 출금결과 출금여부
	private String withdrawalResultFailedCode; // 출금결과 불능코드
	private long totalFee; // 총수수료
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mainBankBranchCode$; // 주거래은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestedWithdrawalCount$; // 출금의뢰건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAmount$; // 출금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalResultWithdrawalYn$; // 출금결과 출금여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalResultFailedCode$; // 출금결과 불능코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFee$; // 총수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void calculate(Mac mac) {
		mac.calculate(withdrawalAccountNumber);
		mac.calculate(withdrawalAmount, 13);
	}

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		mainBankBranchCode$ = VOUtils.write(out, mainBankBranchCode, 7); // 주거래은행점코드
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		requestedWithdrawalCount$ = VOUtils.write(out, requestedWithdrawalCount, 8); // 출금의뢰건수
		withdrawalAmount$ = VOUtils.write(out, withdrawalAmount, 13); // 출금액
		withdrawalResultWithdrawalYn$ = VOUtils.write(out, withdrawalResultWithdrawalYn, 1); // 출금결과 출금여부
		withdrawalResultFailedCode$ = VOUtils.write(out, withdrawalResultFailedCode, 4); // 출금결과 불능코드
		totalFee$ = VOUtils.write(out, totalFee, 11); // 총수수료
		filler2$ = VOUtils.write(out, filler2, 71); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		mainBankBranchCode = VOUtils.toString(mainBankBranchCode$ = VOUtils.read(in, 7)); // 주거래은행점코드
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		requestedWithdrawalCount = VOUtils.toInt(requestedWithdrawalCount$ = VOUtils.read(in, 8)); // 출금의뢰건수
		withdrawalAmount = VOUtils.toLong(withdrawalAmount$ = VOUtils.read(in, 13)); // 출금액
		withdrawalResultWithdrawalYn = VOUtils.toString(withdrawalResultWithdrawalYn$ = VOUtils.read(in, 1)); // 출금결과 출금여부
		withdrawalResultFailedCode = VOUtils.toString(withdrawalResultFailedCode$ = VOUtils.read(in, 4)); // 출금결과 불능코드
		totalFee = VOUtils.toLong(totalFee$ = VOUtils.read(in, 11)); // 총수수료
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 71)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", mainBankBranchCode=").append(mainBankBranchCode).append(System.lineSeparator()); // 주거래은행점코드
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", requestedWithdrawalCount=").append(requestedWithdrawalCount).append(System.lineSeparator()); // 출금의뢰건수
		sb.append(", withdrawalAmount=").append(withdrawalAmount).append(System.lineSeparator()); // 출금액
		sb.append(", withdrawalResultWithdrawalYn=").append(withdrawalResultWithdrawalYn).append(System.lineSeparator()); // 출금결과 출금여부
		sb.append(", withdrawalResultFailedCode=").append(withdrawalResultFailedCode).append(System.lineSeparator()); // 출금결과 불능코드
		sb.append(", totalFee=").append(totalFee).append(System.lineSeparator()); // 총수수료
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "mainBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requestedWithdrawalCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "withdrawalAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "withdrawalResultWithdrawalYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "withdrawalResultFailedCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "totalFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "71", "defltVal", "")
		);
	}

}
