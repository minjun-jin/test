package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금용공동망 결제지시서
 * <pre>{@code
 * KftHofEL0099R kftHofEL0099R  = new KftHofEL0099R(); // 전자금용공동망 결제지시서
 * kftHofEL0099R.setFileName(""); // 업무구분
 * kftHofEL0099R.setDataType(""); // 데이타구분
 * kftHofEL0099R.setSerialNumber(""); // 일련번호
 * kftHofEL0099R.setContentType(""); // 내용구분
 * kftHofEL0099R.setDebitCreditCode(""); // 대차구분코드
 * kftHofEL0099R.setInterBankTransferAmount(0L); // 타행이체금액
 * kftHofEL0099R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0099R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String contentType; // 내용구분
	private String debitCreditCode; // 대차구분코드
	private long interBankTransferAmount; // 타행이체금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String contentType$; // 내용구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCreditCode$; // 대차구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String interBankTransferAmount$; // 타행이체금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		contentType$ = VOUtils.write(out, contentType, 1); // 내용구분
		debitCreditCode$ = VOUtils.write(out, debitCreditCode, 1); // 대차구분코드
		interBankTransferAmount$ = VOUtils.write(out, interBankTransferAmount, 15); // 타행이체금액
		filler$ = VOUtils.write(out, filler, 42); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		contentType = VOUtils.toString(contentType$ = VOUtils.read(in, 1)); // 내용구분
		debitCreditCode = VOUtils.toString(debitCreditCode$ = VOUtils.read(in, 1)); // 대차구분코드
		interBankTransferAmount = VOUtils.toLong(interBankTransferAmount$ = VOUtils.read(in, 15)); // 타행이체금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 42)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", contentType=").append(contentType).append(System.lineSeparator()); // 내용구분
		sb.append(", debitCreditCode=").append(debitCreditCode).append(System.lineSeparator()); // 대차구분코드
		sb.append(", interBankTransferAmount=").append(interBankTransferAmount).append(System.lineSeparator()); // 타행이체금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "contentType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "debitCreditCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "interBankTransferAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "42", "defltVal", "")
		);
	}

}
