package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 수표조회
 * <pre>{@code
 * msgType 메시지구분 
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 
 * messageCode 거래구분코드 
 * responseCode 응답코드 
 * requestBank 요청은행 
 * beneficiaryBankCode 수취은행 
 * transactionDate 전송일자 
 * transactionIdNumber 거래고유번호 
 * chequeIssuanceBranchCode 수표발행지점코드 
 * chequeIssuanceDate 수표발행일자 
 * chequeSerialNumber 수표발행번호 
 * chequeCode 수표분류코드 
 * chequeAmount 수표금액 
 * checkAccountNumber 수표계좌번호 
 * 
 * GchHof0210500000 gchHof0210500000 = new GchHof0210500000(); // 수표조회
 * gchHof0210500000.setMsgType("KCGGCH"); // 메시지구분
 * gchHof0210500000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * gchHof0210500000.setMsgNo("00000000"); // 메시지번호(Key)
 * gchHof0210500000.setMessageType("0210"); // 전문종별코드
 * gchHof0210500000.setMessageCode("500000"); // 거래구분코드
 * gchHof0210500000.setResponseCode("000"); // 응답코드
 * gchHof0210500000.setRequestBank("000"); // 요청은행
 * gchHof0210500000.setBeneficiaryBankCode("000"); // 수취은행
 * gchHof0210500000.setTransactionDate(LocalDate.now()); // 전송일자
 * gchHof0210500000.setTransactionIdNumber(""); // 거래고유번호
 * gchHof0210500000.setChequeIssuanceBranchCode("0000000"); // 수표발행지점코드
 * gchHof0210500000.setChequeIssuanceDate(LocalDate.now()); // 수표발행일자
 * gchHof0210500000.setChequeSerialNumber(""); // 수표발행번호
 * gchHof0210500000.setChequeCode(""); // 수표분류코드
 * gchHof0210500000.setChequeAmount(""); // 수표금액
 * gchHof0210500000.setCheckAccountNumber(""); // 수표계좌번호
 * }</pre>
 */
@Data
public class GchHof0210500000 implements GchHofComHdr, Vo {

	private String msgType = "KCGGCH"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0210"; // 전문종별코드
	private String messageCode = "500000"; // 거래구분코드
	private String responseCode = "000"; // 응답코드
	private String requestBank = "000"; // 요청은행
	private String beneficiaryBankCode = "000"; // 수취은행
	private LocalDate transactionDate; // 전송일자
	private String transactionIdNumber; // 거래고유번호
	private String chequeIssuanceBranchCode = "0000000"; // 수표발행지점코드
	private LocalDate chequeIssuanceDate; // 수표발행일자
	private String chequeSerialNumber; // 수표발행번호
	private String chequeCode; // 수표분류코드
	private String chequeAmount; // 수표금액
	private String checkAccountNumber; // 수표계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBank$; // 요청은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 수취은행
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionDate$; // 전송일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeIssuanceBranchCode$; // 수표발행지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeIssuanceDate$; // 수표발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeSerialNumber$; // 수표발행번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeCode$; // 수표분류코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeAmount$; // 수표금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String checkAccountNumber$; // 수표계좌번호

	@Override
	public int validate() {
		if (VOUtils.isWhitespace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isWhitespace(systemSendReceiveTime$)) { // 시스템송수신시간
			return 1;
		}
		if (VOUtils.isWhitespace(msgNo$)) { // 메시지번호(Key)
			return 2;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isWhitespace(responseCode$)) { // 응답코드
			return 5;
		}
		if (VOUtils.isNotNumeric(requestBank$)) { // 요청은행
			return 6;
		}
		if (VOUtils.isNotNumeric(beneficiaryBankCode$)) { // 수취은행
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 9;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBank$ = VOUtils.write(out, requestBank, 3); // 요청은행
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 수취은행
		transactionDate$ = VOUtils.write(out, transactionDate, 8, "yyyyMMdd"); // 전송일자
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		chequeIssuanceBranchCode$ = VOUtils.write(out, chequeIssuanceBranchCode, 7); // 수표발행지점코드
		chequeIssuanceDate$ = VOUtils.write(out, chequeIssuanceDate, 8, "yyyyMMdd"); // 수표발행일자
		chequeSerialNumber$ = VOUtils.write(out, chequeSerialNumber, 8); // 수표발행번호
		chequeCode$ = VOUtils.write(out, chequeCode, 2); // 수표분류코드
		chequeAmount$ = VOUtils.write(out, chequeAmount, 10); // 수표금액
		checkAccountNumber$ = VOUtils.write(out, checkAccountNumber, 6); // 수표계좌번호
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBank = VOUtils.toString(requestBank$ = VOUtils.read(in, 3)); // 요청은행
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 수취은행
		transactionDate = VOUtils.toLocalDate(transactionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전송일자
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		chequeIssuanceBranchCode = VOUtils.toString(chequeIssuanceBranchCode$ = VOUtils.read(in, 7)); // 수표발행지점코드
		chequeIssuanceDate = VOUtils.toLocalDate(chequeIssuanceDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 수표발행일자
		chequeSerialNumber = VOUtils.toString(chequeSerialNumber$ = VOUtils.read(in, 8)); // 수표발행번호
		chequeCode = VOUtils.toString(chequeCode$ = VOUtils.read(in, 2)); // 수표분류코드
		chequeAmount = VOUtils.toString(chequeAmount$ = VOUtils.read(in, 10)); // 수표금액
		checkAccountNumber = VOUtils.toString(checkAccountNumber$ = VOUtils.read(in, 6)); // 수표계좌번호
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBank=").append(requestBank).append(System.lineSeparator()); // 요청은행
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 수취은행
		sb.append(", transactionDate=").append(transactionDate).append(System.lineSeparator()); // 전송일자
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", chequeIssuanceBranchCode=").append(chequeIssuanceBranchCode).append(System.lineSeparator()); // 수표발행지점코드
		sb.append(", chequeIssuanceDate=").append(chequeIssuanceDate).append(System.lineSeparator()); // 수표발행일자
		sb.append(", chequeSerialNumber=").append(chequeSerialNumber).append(System.lineSeparator()); // 수표발행번호
		sb.append(", chequeCode=").append(chequeCode).append(System.lineSeparator()); // 수표분류코드
		sb.append(", chequeAmount=").append(chequeAmount).append(System.lineSeparator()); // 수표금액
		sb.append(", checkAccountNumber=").append(checkAccountNumber).append(System.lineSeparator()); // 수표계좌번호
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "KCGGCH"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "500000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBank", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "transactionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "chequeIssuanceBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "chequeIssuanceDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "chequeSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "chequeCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "chequeAmount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "checkAccountNumber", "fldLen", "6", "defltVal", "")
		);
	}

}
