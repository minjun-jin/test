package com.jpmc.kcg;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComAcctAlarmMDao;
import com.jpmc.kcg.com.dao.ComTrHoldLDao;
import com.jpmc.kcg.com.dto.ComAcctAlarmIn;
import com.jpmc.kcg.com.dto.ComAcctAlarmM;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwExecutor;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.dao.FrwMsgLDao;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.hof.biz.HofCom;
import com.jpmc.kcg.hof.biz.vo.KcgHof0200010000;
import com.jpmc.kcg.hof.biz.vo.KcgHof0200010000.NetDebitCapInformation;
import com.jpmc.kcg.hof.biz.vo.KcgHof0400400000;
import com.jpmc.kcg.hof.biz.vo.KftHof0200400000;
import com.jpmc.kcg.hof.biz.vo.KftHof0200950000;
import com.jpmc.kcg.hof.biz.vo.KftHof0210400000;
import com.jpmc.kcg.hof.biz.vo.KftHof0800302000;
import com.jpmc.kcg.hof.biz.vo.KftHof0800303000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200400000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0210400000;
import com.jpmc.kcg.hof.dao.HofBlockAcctInfoMDao;
import com.jpmc.kcg.hof.dao.HofBlockAcctLDao;
import com.jpmc.kcg.hof.dao.HofBlockAcctLMapper;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitMDao;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitMMapper;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitTrLDao;
import com.jpmc.kcg.hof.dao.HofTrLDao;
import com.jpmc.kcg.hof.dto.HofBlockAcctInfoM;
import com.jpmc.kcg.hof.dto.HofBlockAcctL;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitM;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrL;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrLSumOut;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTrListByHostNoDaoIn;
import com.jpmc.kcg.hof.dto.UpdateHofTransactionIn;
import com.jpmc.kcg.hof.enums.FundTypeEnum;
import com.jpmc.kcg.hof.enums.HbkConst;
import com.jpmc.kcg.hof.enums.HofConst;
import com.jpmc.kcg.hof.enums.HofRespCdEnum;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@Transactional
public class KftHofSch {

	@Autowired
	private BizCom bizCom;
	@Autowired
	private HofTrLDao hofTrLDao;
	@Autowired
	private HofCom hofCom;
	@Autowired
	private ReleaseValidation releaseValidation;
	@Autowired
	private HofBlockAcctInfoMDao hofBlockAcctInfoMDao;
	@Autowired
	private HofBlockAcctLDao hofBlockAcctLDao;
	@Autowired
	private HofBlockAcctLMapper hofBlockAcctLMapper;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private FrwExecutor frwExecutor;
	@Autowired
	private FrwMsgLDao frwMsgLDao;
	@Autowired
	private HofLrgAmtSplitMDao hofLrgAmtSplitMDao;
	@Autowired
	private HofLrgAmtSplitTrLDao hofLrgAmtSplitTrLDao;
	@Autowired
	private ComAcctAlarmMDao comAcctAlarmMDao;
	@Autowired
	private HofLrgAmtSplitMMapper hofLrgAmtSplitMMapper;
	@Autowired
	private ComTrHoldLDao comTrHoldLDao;
	@Autowired
	private ComPshMsgBean comPshMsgBean;
	@Autowired
	private ConversionService conversionService;

	// @Scheduled(fixedRate = 10000)
	@Scheduled(fixedDelay = 10000)
	public void hofFundsTransferOutReReqIntf() {

		/**
		 * 1. 재요청 거래 조회 -> 당발, 현재시간-전문전송시간 > 60초 , 응답코드 null 2. Hof 서비스시간/은행개설상태 확인
		 * ->아닐경우 return 3. 0200 -> 0201으로 변경 후 KFTC로 전송 4. 거래내역 HOF_TR_L 전문전송시간 업데이트
		 */

		String trDt = frwContext.getSysTmstmp().format(DateTimeFormatter.BASIC_ISO_DATE);
		List<HofTrL> reReqTrList = hofTrLDao.selectReReqHofTransactionList(trDt);

		for (HofTrL reReq : reReqTrList) {

			if (log.isDebugEnabled()) {
				log.debug("HofFundsTransferOutReReqIntf target List {}", reReq);
			}
			if (!reReq.getTrDt().equals(frwContext.getSysTmstmp().format(DateTimeFormatter.BASIC_ISO_DATE))) {
				log.info(">>>>>>Transaction date is not today {}", reReq.getTrDt());
				return;
			}
			String bankConnectStatus = bizCom.getConnectivtyValidation(ComConst.JPMC_BANK_CD,
					BizDvsnCdEnum.HOF.getValue(), ComConst.HST);

			// 종료일때 오는게 123, 113, 143
			if (!bankConnectStatus.equals(HofRespCdEnum.RESP_CD_000.getCode())) {
				log.info(">>>>>>BankConnectStatus is not normal {}", bankConnectStatus);
				return;
			}

			try {
				// 트랜잭션 분리 서비스 호출
				frwExecutor.requiresNew((tr) -> {

					// ASIS 전문추적번호만 채번, 거래고유번호 유지
					String tlgTrceNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01);

					FrwMsgL frwMsgL = new FrwMsgL();
					frwMsgL.setTlgBizDvsnCd(HofConst.TR_DVSN_400000);
					frwMsgL.setOrgnTractId(reReq.getTrcId());
					frwMsgL = frwMsgLDao.selectFrwMsgLtlgCtt(frwMsgL);

					// KFT QUE전송
					KftHof0200400000 kftReqVo = VOUtils.toVo(frwMsgL.getTlgCtt(), KftHof0200400000.class);
					log.info("---------- {}", kftReqVo);

					// LVB전문 -> KFTC 전문 변환
					kftReqVo.setMessageType(HofConst.TLG_KND_DVSN_NO_0201);
					kftReqVo.setSendReceiveFlag(ComConst.CHAR_1);
					kftReqVo.setMessageTrackingNumber(tlgTrceNo); /* 전문추적 관리번호 새로채번 */
					kftReqVo.setTraxOccurredDate(LocalDate.now());
					kftReqVo.setMessageSendTime(LocalTime.now());

					// 우선순위
					String priority = hofCom.getPriorityCheck(kftReqVo.getWithdrawalAccountNumber(),
							new BigDecimal(kftReqVo.getTransactionAmount()));

					// KFTC QUEUE에 송신 (tractId 묶기+ 우선순위 설정)
					frwTemplate.send(FrwDestination.KFT_HOF, kftReqVo, Map.of(WMQConstants.JMS_PRIORITY, priority),
							frwMsgL);

					log.info(">>>>>>kft send Vo {}", kftReqVo);

					// 전문전송시간 update
					UpdateHofTransactionIn updateIn = new UpdateHofTransactionIn();
					updateIn.setLastChngGuid(frwContext.getSvcGuid());
					updateIn.setLastChngStaffId(frwContext.getUsrId());
					updateIn.setRqstTm(LocalDateTime.now().format(DateFormat.HHMMSS.getFormatter()));

					// key값
					updateIn.setTrDt(reReq.getTrDt());
					updateIn.setTrUnqNo(reReq.getTrUnqNo());
					updateIn.setHostNo(reReq.getHostNo());
					updateIn.setOutinDvsnCd(reReq.getOutinDvsnCd());
					hofTrLDao.updateHofTransaction(updateIn);

				}, List.of(reReqTrList));

			} catch (Exception e) {
				// 에러가 발생하더라도 다음 건을 계속 진행
				log.info(reReq.getTrUnqNo().toString());
				log.info(e.getMessage());
				log.error("Fail", e);
			}
		}
	}

	/**
	 * 인출정지정보공유 1분에 한번씩 실행
	 */
	@Scheduled(fixedRate = 60000)
	public void hofDebitBlockInformationShareOutReqIntf() {

		// 인출정지정보 대상 조회
		List<HofBlockAcctInfoM> trgtList = hofBlockAcctInfoMDao.selectListHofBlockInfoTrgt();

		for (HofBlockAcctInfoM trgt : trgtList) {
			// 통신망 개시 상태인지 확인
			boolean isNotConnected = releaseValidation.getReleaseConnectivityStatus(ComConst.JPMC_BANK_CD,
					BizDvsnCdEnum.HOF.getValue());
			if (isNotConnected) {
				log.info("###### 0200/950000 sending is Not possible, not Connected ");
				return;
			} else {
				try {
					// 트랜잭션 분리 서비스 호출
					frwExecutor.requiresNew((tr) -> {
						log.info("###### 0200/950000 sending start");
						// 정지계좌의 연관거래 조회
						List<HofBlockAcctL> relTrInfoList = hofBlockAcctLDao.selectBlockAcctRelTrInfo(trgt.getAcctNo());

						for (HofBlockAcctL relTrInfo : relTrInfoList) {
							log.info("###### 0200/950000 sending relTrInfo ::: {}", relTrInfo);
							String bnkCd = relTrInfo.getBnkCd();

							// 전문추적번호 채번
							String tlgTrceNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01);
							
							HofBlockAcctL select = hofBlockAcctLMapper.selectByPrimaryKey(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()), trgt.getBnkCd(), trgt.getAcctNo());
							
							if(select == null) {
								// 인출정지정보공유 원장에 입력
								relTrInfo.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
								relTrInfo.setBnkCd(trgt.getBnkCd());
								relTrInfo.setAcctNo(trgt.getAcctNo());
								relTrInfo.setAcctStsCd(trgt.getAcctStsCd());
								relTrInfo.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
								relTrInfo.setMgrNm(trgt.getMgrNm());
								relTrInfo.setMgrTelNo(trgt.getMgrTelNo());
								relTrInfo.setSndRecvCnt(1L);
								relTrInfo.setRmk(trgt.getRmk());
								relTrInfo.setTrUnqNo(ComConst.JPMC_BANK_CD.concat(tlgTrceNo));
								relTrInfo.setMakeId(trgt.getMakeId());
								relTrInfo.setMakeDttm(trgt.getMakeDttm());
								relTrInfo.setChkId(trgt.getChkId());
								relTrInfo.setChkDttm(trgt.getChkDttm());
								
								hofBlockAcctLMapper.insert(relTrInfo);
								log.info("###### 0200/950000 sending relTrInfo insert done");
							}

							// 전문조립
							KftHof0200950000 reqVo = new KftHof0200950000();
							reqVo.setMessageTransmissionDate(LocalDate.now());
							reqVo.setMessageSendTime(LocalTime.now());

							reqVo.setMessageTrackingNumber(tlgTrceNo);
							reqVo.setTransactionIdNumber(ComConst.JPMC_BANK_CD + ComConst.CHAR_00 + tlgTrceNo); // 거래고유번호
							reqVo.setTraxOccurredDate(LocalDate.now());
							reqVo.setHandlingInstitutionRepCode(ComConst.JPMC_BANK_CD);
							reqVo.setRequestBranchCode(ComConst.JPMC_BANK_CD + ComConst.JPMC_BRNCH_CD);
							reqVo.setBeneficiaryBankCode(relTrInfo.getRecvBnkCd());
							reqVo.setWithdrawSuspendedAccountNumber(trgt.getAcctNo());

							reqVo.setRelatedTransactionProcessDate(relTrInfo.getRelTrDt());
							reqVo.setRelatedTransactionProcessTime(relTrInfo.getRelTrTm());
							reqVo.setRelatedTransactionSystemCode("EL");
							reqVo.setRelatedTransactionId(relTrInfo.getRelTrUnqNo());
							reqVo.setRelatedTransactionDebitCreditFlag(relTrInfo.getDpstWhdrwlCd());
							reqVo.setCounterAccountNumber(relTrInfo.getRecvAcctNo());
							reqVo.setRelatedTransactionAmount(relTrInfo.getRelTrTotAmt().longValue());
							reqVo.setEmployeeName(trgt.getMgrNm());
							reqVo.setEmployeeContact(trgt.getMgrTelNo());
							reqVo.setReferenceContent(trgt.getRmk());

							log.info("###### 0200/950000 sending VO ::: {} ", reqVo);

							// KFTC QUEUE에 송신
							frwTemplate.send(FrwDestination.KFT_HOF, reqVo);
						}
					}, List.of(trgtList));
				} catch (Exception e) {
					// 에러가 발생하더라도 다음 건을 계속 진행
					log.info(trgt.getAcctNo());
					log.info(e.getMessage());
					log.error("Fail", e);
				}
			}
		}

	}

	@Scheduled(fixedRate = 300000)
	public void hofSystemMessageOutReqIntf() {

		// 기관상태확인 전문 송신
		KftHof0800302000 insitutStsReq = new KftHof0800302000();
		insitutStsReq.setMessageTrackingNumber(
				StringUtils.substring(LocalDateTime.now().format(DateFormat.HHMMSSSSS.getFormatter()), 1)); // 전문추적번호
		insitutStsReq.setInstitutionCode(ComConst.JPMC_BANK_CD);
		insitutStsReq.setMessageTransmissionDate(LocalDate.now());
		insitutStsReq.setMessageSendTime(LocalTime.now());
		insitutStsReq.setTraxOccurredDateTime(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));

		log.debug("insitutStsReq {}", insitutStsReq);

		frwTemplate.send(FrwDestination.KFT_HOF, insitutStsReq);

		// 거래별 기관상태확인 전문 송신(HOF 타행이체)
		KftHof0800303000 trStsReq = new KftHof0800303000();
		trStsReq.setMessageTrackingNumber(
				StringUtils.substring(LocalDateTime.now().format(DateFormat.HHMMSSSSS.getFormatter()), 1)); // 전문추적번호
		trStsReq.setInstitutionCode(ComConst.JPMC_BANK_CD);
		trStsReq.setMessageCode1(HofConst.TR_DVSN_400000);
		trStsReq.setMessageTransmissionDate(LocalDate.now());
		trStsReq.setMessageSendTime(LocalTime.now());
		trStsReq.setTraxOccurredDateTime(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		log.debug("trStsReq {}", trStsReq);

		frwTemplate.send(FrwDestination.KFT_HOF, trStsReq);

		// 거래별 기관상태확인 전문 송신(HBK 타행이체)
		KftHof0800303000 trStsReqHbk = new KftHof0800303000();
		trStsReqHbk.setMessageTrackingNumber(
				StringUtils.substring(LocalDateTime.now().format(DateFormat.HHMMSSSSS.getFormatter()), 1)); // 전문추적번호
		trStsReqHbk.setInstitutionCode(ComConst.JPMC_BANK_CD);
		trStsReqHbk.setMessageCode1(HbkConst.TR_DVSN_450000);
		trStsReqHbk.setMessageTransmissionDate(LocalDate.now());
		trStsReqHbk.setMessageSendTime(LocalTime.now());
		trStsReqHbk.setTraxOccurredDateTime(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		log.debug("trStsReqHbk {}", trStsReqHbk);

		frwTemplate.send(FrwDestination.KFT_HOF, trStsReqHbk);

		// 순이체한도조회 전문 송신
		KcgHof0200010000 outReq0200010000 = new KcgHof0200010000();
		List<NetDebitCapInformation> targetList = new ArrayList<KcgHof0200010000.NetDebitCapInformation>();
		NetDebitCapInformation target = new NetDebitCapInformation();
		target.setLimtInformationInstitutionCode(ComConst.JPMC_BANK_CD);
		targetList.add(target);
		outReq0200010000.setNetDebitCapInformationArray(targetList);
		outReq0200010000.setInformationCount(1);
		outReq0200010000.setMessageTransmissionDate(LocalDate.now());
		outReq0200010000.setMessageSendTime(LocalTime.now());

		String tlgTrceNo = bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01);
		outReq0200010000.setMessageTrackingNumber(ComConst.CHAR_00.concat(tlgTrceNo));
		log.debug("outReq0200010000 {}", outReq0200010000);

		frwTemplate.send(FrwDestination.KCG_HOF, outReq0200010000);

	}

	@Scheduled(fixedDelay = 10000)
	public void hofFundsTransferLrgAmtRelease() {

		// HOF_LRG_AMT_SPLIT_M 요청전(00)인 거래 조회
		HofLrgAmtSplitM splitMIn = new HofLrgAmtSplitM();
		splitMIn.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		splitMIn.setTrStsCd(TrStsCdEnum.PRE_REQUEST.getTrStsCd());

		HofLrgAmtSplitM splitMout = hofLrgAmtSplitMDao.selectHofLrgAmtSplitM(splitMIn);

		if (splitMout != null) {

			// HOF_LRG_AMT_SPLIT_M 요청중(01)로 update
			HofLrgAmtSplitM update = new HofLrgAmtSplitM();
			update.setTrStsCd(TrStsCdEnum.REQUEST.getTrStsCd());
			update.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
			update.setHostNo(splitMout.getHostNo());
			hofLrgAmtSplitMDao.updateHofLrgAmtSplitMTrStsCd(update);

			// HOSTNO로 HOF_LRG_AMT_SPLIT_TR_L 요청전(00)거래 리스트 조회
			HofLrgAmtSplitTrL splitListIn = new HofLrgAmtSplitTrL();
			splitListIn.setTrDt(splitMout.getTrDt());
			splitListIn.setHostNo(splitMout.getHostNo());
			splitListIn.setTrStsCd(TrStsCdEnum.PRE_REQUEST.getTrStsCd());

			List<HofLrgAmtSplitTrL> splitListOut = hofLrgAmtSplitTrLDao.selectHofLrgAmtSplitTrLList(splitListIn);

			for (HofLrgAmtSplitTrL item : splitListOut) {
				// 이체 KCG큐 전송
				LvbHof0200400000 fundsIn = VOUtils.toVo(splitMout.getTlgCtt(), LvbHof0200400000.class);
				fundsIn.setTransactionIdNumber(item.getTrUnqNo());
				fundsIn.setBeneficiaryAmount(item.getTotTrAmt().longValue());
				frwTemplate.send(FrwDestination.KCG_HOF, fundsIn);

				// HOF_LRG_AMT_SPLIT_TR_L 요청중(01)로 update
				HofLrgAmtSplitTrL listUpdate = new HofLrgAmtSplitTrL();
				listUpdate.setLastChngTmstmp(LocalDateTime.now());
				listUpdate.setTrStsCd(TrStsCdEnum.REQUEST.getTrStsCd());
				listUpdate.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
				listUpdate.setHostNo(item.getHostNo());
				listUpdate.setTrSeq(item.getTrSeq());
				hofLrgAmtSplitTrLDao.updateHofLrgAmtSplitTrLTrStsCd(listUpdate);
			}

		}

		// HOF_LRG_AMT_SPLIT_M 요청전(01)인 거래 조회
		HofLrgAmtSplitM splitM = new HofLrgAmtSplitM();
		splitM.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		splitM.setTrStsCd(TrStsCdEnum.REQUEST.getTrStsCd());

		List<HofLrgAmtSplitM> selectSplitMList = hofLrgAmtSplitMDao.selectHofLrgAmtSplitMByStsCd(splitM);

		for (HofLrgAmtSplitM selectSplitM : selectSplitMList) {
			String trSts = selectSplitM.getTrStsCd();

			HofLrgAmtSplitTrL lrgTrL = new HofLrgAmtSplitTrL();
			lrgTrL.setTrDt(selectSplitM.getTrDt());
			lrgTrL.setHostNo(selectSplitM.getHostNo());

			HofLrgAmtSplitTrLSumOut sumCnt = hofCom.getHofLrgAmtSplitTrCnt(lrgTrL);

			// 전체건 처리후
			if (sumCnt.getProcCnt() == 0) {
				
				// 응답전문송신 (1회)
				LvbHof0200400000 lvbReq = VOUtils.toVo(selectSplitM.getTlgCtt(), LvbHof0200400000.class);
				LvbHof0210400000 lvbRes = conversionService.convert(lvbReq, LvbHof0210400000.class);
				
				// 응답리턴할 데이터 조회 -> hostNo로 거래원장 select
				SelectHofTrListByHostNoDaoIn in = new SelectHofTrListByHostNoDaoIn();
				in.setHostNo(selectSplitM.getHostNo());
				in.setTrDt(selectSplitM.getTrDt());
				in.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
				List<HofTrL> outList = hofTrLDao.selectOrgnTrListByHostNo(in);
				
				if(!CollectionUtils.isEmpty(outList)) {
					lvbRes.setMsgType(HofConst.KCGLVB);
					lvbRes.setResponseCode(outList.get(0).getRespCd());
					lvbRes.setTransactionIdNumber(outList.get(0).getTrUnqNo());
					lvbRes.setBeneficiaryName(outList.get(0).getRcpntNm());
					if(FundTypeEnum.PAYROLL.getCode().equals(outList.get(0).getFundTpCd()) && StringUtils.isEmpty(lvbReq.getDetailInformation())) {
						lvbRes.setDetailInformation(outList.get(0).getRqerNm());    //적요에 출금인명 set
					}
					
					Map<String, String> tlgHdr = new HashMap<String, String>();
					tlgHdr.put(ComConst.ORGN_TRACT_ID, outList.get(0).getTrcId());
					
					/*
					 * HOF_LRG_AMT_SPLIT_M 상태 update
					 *  - 전체 거절(03) : host로 마지막거래 거절      응답 전송 & 알림 전송
					 *  - 전체 정상(02) : host로 마지막거래 정상(000) 응답 전송 & 알림 전송
					 *  - 부분 거절(99) : 정상거래에 한해 취소요청 진행 (상태값만 99로 update)
					 */
					if (sumCnt.getErrCnt() == selectSplitM.getTrCnt()) { // 전체 에러
						trSts = TrStsCdEnum.ERROR.getTrStsCd();
						frwTemplate.send(FrwDestination.LVB_HOF, lvbRes, tlgHdr); 
						log.debug("############[HOST_SEND] LrgAmtRelease error return hostNo : {} ", outList.get(0).getHostNo());
						_sendDrctAcctAlarm(outList.get(0)); 
						
					} else if (sumCnt.getNorCnt() == selectSplitM.getTrCnt()) { // 전체 정상
						trSts = TrStsCdEnum.COMPLETE.getTrStsCd();
						frwTemplate.send(FrwDestination.LVB_HOF, lvbRes, tlgHdr);  
						log.debug("############[HOST_SEND] LrgAmtRelease complete return hostNo : {} ", outList.get(0).getHostNo());
						_sendDrctAcctAlarm(outList.get(0));  
						
					} else if (sumCnt.getErrCnt() > 0) { // 부분 거절
						trSts = TrStsCdEnum.ERROR_TR.getTrStsCd();
					}
				}
			}
			log.debug("############ LrgAmtRelease trSts : {} ", trSts);
			selectSplitM.setTrStsCd(trSts);
			hofLrgAmtSplitMMapper.updateByPrimaryKey(selectSplitM);

		}
	}
	
	private void _sendDrctAcctAlarm(HofTrL in) {
		try {
			//2025-02-03 추가. 계좌번호에 대한 즉시 알람인 경우 처리.
			ComAcctAlarmIn comAcctAlarmIn = new ComAcctAlarmIn();
			comAcctAlarmIn.setTranDt		(	in.getTrDt());
			comAcctAlarmIn.setTrUnqNo		(	in.getTrUnqNo()		);
			comAcctAlarmIn.setAcctNo		(	in.getWhdrwlAcctNo()	);
			String alarmTrDvsnCd = ComConst.CHAR_01;
			if(!ComConst.NORMAL_RESPONSE_CODE.equals(in.getRespCd())) {
				alarmTrDvsnCd = ComConst.CHAR_02;
				comAcctAlarmIn.setDfltSendFlag(ComConst.Y);
			}
			comAcctAlarmIn.setAlarmTrDvsnCd	(	alarmTrDvsnCd					);
			hofCom.sendDrctAcctAlarm(comAcctAlarmIn);
		} catch (Exception e) {
			log.error("Message Request Fail", e);
		}
	}

	@Scheduled(fixedDelay = 10000)
	public void hofFundsTransferCancelLrgAmtRelease() {

		// HOF_LRG_AMT_SPLIT_M 거절(03)인 거래 조회
		HofLrgAmtSplitM splitMIn = new HofLrgAmtSplitM();
		splitMIn.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		// 99 : 이체건 중 에러건 있는 경우->취소전문필요/ 03 : 모든 거래가 에러종료로 취소전문 불필요.
		splitMIn.setTrStsCd(TrStsCdEnum.ERROR_TR.getTrStsCd());

		HofLrgAmtSplitM splitMout = hofLrgAmtSplitMDao.selectHofLrgAmtSplitM(splitMIn);

		if (splitMout != null) {
			// 있을 경우 HOF_LRG_AMT_SPLIT_M 취소요청(04)로 update
			HofLrgAmtSplitM update = new HofLrgAmtSplitM();
			update.setTrStsCd(TrStsCdEnum.CANCEL_REQUEST.getTrStsCd());
			update.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
			update.setHostNo(splitMout.getHostNo());
			hofLrgAmtSplitMDao.updateHofLrgAmtSplitMTrStsCd(update);

			// HOSTNO로 HOF_TR_L 거래 리스트 조회
			List<HofTrL> fundTrList = hofCom.selectHofTrListByHostNo(splitMout.getHostNo(), splitMout.getTrDt());

			for (HofTrL fundTr : fundTrList) {
				log.info("############ AutoCancel fund Transfer history : {} ", fundTr);
				// 정상완료(02)거래만 취소전송
				if (TrStsCdEnum.COMPLETE.getTrStsCd().equals(fundTr.getTrStsCd())
						&& HofRespCdEnum.RESP_CD_000.getCode().equals(fundTr.getRespCd())) {
					try {
						// 트랜잭션 분리 서비스 호출
						frwExecutor.requiresNew((tr) -> {
							FrwMsgL reqFrwMsg = new FrwMsgL();
							reqFrwMsg.setTlgBizDvsnCd(HofConst.TR_DVSN_400000);
							reqFrwMsg.setTrnsUnqNo(fundTr.getTrUnqNo());
							// 결제원에 전송한 이체전문 SELECT (12번 kftc송신 전문)
							reqFrwMsg = frwMsgLDao.selectFrwMsgLForHofCancel(reqFrwMsg);

							// 이체 kftc 전문 복원
							KcgHof0400400000 cancelIn = VOUtils.toVo(reqFrwMsg.getTlgCtt(), KcgHof0400400000.class);
							cancelIn.setMessageType(HofConst.TLG_KND_DVSN_NO_0400); // 이체전문 -> 이체취소전문
							cancelIn.setTransactionIdNumber(fundTr.getTrUnqNo());
							cancelIn.setTransactionAmount(fundTr.getTotTrAmt().longValue());

							// HOF_LRG_AMT_SPLIT_TR_L 취소요청(04)로 update
							HofLrgAmtSplitTrL listUpdate = new HofLrgAmtSplitTrL();
							listUpdate.setTrDt(splitMout.getTrDt());
							listUpdate.setTrUnqNo(cancelIn.getTransactionIdNumber());
							listUpdate.setTrStsCd(TrStsCdEnum.CANCEL_REQUEST.getTrStsCd());
							hofCom.updateLrgAmtSplitTransaction(listUpdate);

							// 로그 묶기 위해 최초거래(lvb)의 frwMsgL 입력
							FrwMsgL orgnFrwMsg = new FrwMsgL();
							orgnFrwMsg.setTlgBizDvsnCd(HofConst.TR_DVSN_400000);
							orgnFrwMsg.setHostMsgNo(fundTr.getHostNo());
							orgnFrwMsg.setOrgnTractId(fundTr.getTrcId());
							orgnFrwMsg = frwMsgLDao.selectFrwMsgLtlgCtt(orgnFrwMsg);

							// 이체취소 KCG큐 전송(이체전문서비스 호출)
							frwTemplate.send(FrwDestination.KCG_HOF, cancelIn,
									Map.of("ORGN_TRACT_ID", orgnFrwMsg.getOrgnTractId()), orgnFrwMsg);
						}, List.of(fundTrList));
					} catch (Exception e) {
						log.info("############ No history for sending funds transfer telegram to KFTC############");
						log.error("Fail", e);
					}
				}
			}
		}

		// HOF_LRG_AMT_SPLIT_M 요청전(00)인 거래 조회
		HofLrgAmtSplitM splitM = new HofLrgAmtSplitM();
		splitM.setTrDt(LocalDateTime.now().format(DateTimeFormatter.BASIC_ISO_DATE));
		splitM.setTrStsCd(TrStsCdEnum.CANCEL_REQUEST.getTrStsCd());

		List<HofLrgAmtSplitM> selectSplitMList = hofLrgAmtSplitMDao.selectHofLrgAmtSplitMByStsCd(splitM);

		for (HofLrgAmtSplitM selectSplitM : selectSplitMList) {
			String trSts = selectSplitM.getTrStsCd();

			HofLrgAmtSplitTrL lrgTrL = new HofLrgAmtSplitTrL();
			lrgTrL.setTrDt(selectSplitM.getTrDt());
			lrgTrL.setHostNo(selectSplitM.getHostNo());

			HofLrgAmtSplitTrLSumOut sumCnt = hofCom.getHofLrgAmtSplitTrCnt(lrgTrL);

			// 전체건 처리후
			if (sumCnt.getCnclProcCnt() == 0) {
				// 취소오류가 하나라도 있으면 취소에러
				if (sumCnt.getCnclErrCnt() > 0) {
					trSts = TrStsCdEnum.CANCEL_ERROR.getTrStsCd();
				} else if ((sumCnt.getCnclNorCnt() + sumCnt.getErrCnt()) == selectSplitM.getTrCnt()) { // 원거래(거절)+취소완료 = 총금액일 경우 취소완료
					trSts = TrStsCdEnum.CANCEL_COMPLETE.getTrStsCd();
				}

				log.debug("############ cancel LrgAmtRelease trSts : {} ", trSts);
				selectSplitM.setTrStsCd(trSts);
				hofLrgAmtSplitMMapper.updateByPrimaryKey(selectSplitM);
			}
		}
	}

	/**
	 * 계좌 알람설정된 경우, 알람전송, 1분에 한번씩 기동 TODO accum_yn에 대한 로직을 적용 못 함. --> 오픈 후 누적여부에 대한
	 * 처리는 미사용!! 거액거래는 따로 치는지에 대해서도 accum_yn이 y이면 sum그대로 사용해서 전송하면 됨. accum_yn이 n이면
	 * 거래내역을 list로 받아서 전송해야함.
	 */
	@Scheduled(fixedRate = 60000)
	public void sendHofAcctAlarmMsg() {

		String nowTm = LocalTime.now().format(DateFormat.HHMM.getFormatter());
		// 적용여부가 Y이고, 현재 알람을 보내야하는 주기인 계좌 select
		List<ComAcctAlarmM> trgtList = comAcctAlarmMDao.selectAlarmTrgtList(nowTm);

		trgtList.forEach(trgtItem -> {
			try {
				hofCom.sendSchAcctAlarm(trgtItem);
			} catch (Exception e) {
				log.info(trgtItem.getAcctNo());
				log.info(e.getMessage());
				log.error("Fail", e);
			}
		});
	}

	@Scheduled(cron = "0 0 7 * * *")
	public void sendHofHoldTrTrgt() {
		String startTm = LocalTime.now().format(DateFormat.HHMMSSSSS.getFormatter());
		log.debug("############# sendHofHoldTrTrgt Start [{}] #############", startTm);

		ComTrHoldL comTrHoldL = new ComTrHoldL();

		comTrHoldL.setTrDt(LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()));
		comTrHoldL.setHoldStsCd(ComConst.CHAR_01);
		comTrHoldL.setBizDvsnCd(BizDvsnCdEnum.HOF.getValue());

		ComTrHoldL releaseTrgt = comTrHoldLDao.selectTransactionReleaseCntAmt(comTrHoldL);

		Map<String, Object> errorValList = new Hashtable<>();
		// 에러 메시지 문자열 생성
		String errorMessage = String.format("[I N F O] HOFI Pending Transaction Notification Count : %s , Amount: %s",
				releaseTrgt.getTrSeq(), releaseTrgt.getTrAmt());
		log.info(errorMessage);
		errorValList.put("errTlgId", HofConst.HOF_HOLD_TR_TRGT);
		errorValList.put("errCtt", errorMessage);
		comPshMsgBean.sendAlarm(8, errorValList.get("errTlgId").toString(), errorValList, null, true);

		String endTm = LocalTime.now().format(DateFormat.HHMMSSSSS.getFormatter());
		log.debug("############# sendHofHoldTrTrgt End [{}] #############", endTm);
	}

}
