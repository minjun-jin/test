package com.jpmc.kcg.frw.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.jpmc.kcg.frw.dto.FrwBatRsltL;
import com.jpmc.kcg.frw.dto.FrwBatWorkM;

@Mapper
public interface FrwBatExtDao {
	@Deprecated
	List<FrwBatWorkM> selectListNextBatWorkOnReady(@Param("ordDt") String ordDt, @Param("preBatWrkId") String preBatWrkId);
	
	List<FrwBatRsltL> selectListPrevBatLtstRslt(@Param("ordDt") String ordDt, @Param("batWrkId") String batWrkId);
	
	List<FrwBatWorkM> selectListBySchdDvsnCd(@Param("ordDt") String ordDt, @Param("listSchdDvsnCd") List<String> listSchdDvsnCd, @Param("listSchdDvsnCdWithSaturdayHoilday") List<String> listSchdDvsnCdWithSaturdayHoilday);
	
	int updateStrt(FrwBatRsltL frwBatRsltL);
	
	int updateCntr(FrwBatRsltL frwBatRsltL);
	
	int updateRslt(FrwBatRsltL frwBatRsltL);
}
