package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0200221000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.springframework.core.convert.converter.Converter;

import java.time.LocalDateTime;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE, // 매핑되지 않은 필드는 무시
        imports = {LocalDateTime.class, DateUtils.class, EntConst.class, ComConst.class}
)
public interface CqeEnt0200221000EntMbrL extends Converter<CqeEnt0200221000, EntMbrL> {
    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())")
    @Mapping(target = "entTlgTrceNo", ignore = true)
    @Mapping(target = "trUnqNo", source = "transactionIdNumber")
    @Mapping(target = "hostNo", source = "msgNo")
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.OUTBOUND_CD)")
    @Mapping(target = "othrPartyBnkCd", ignore = true)
    @Mapping(target = "sysDvsn", expression = "java(EntConst.SYS_ID)")
    @Mapping(target = "bnkCd", source = "bnkCd")
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType")
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode")
    @Mapping(target = "sndRcvDvsnCd", expression = "java(EntConst.SND_FLAG)")

    @Mapping(target = "respCd1", source = "responseCode1")
    @Mapping(target = "respCd2", source = "responseCode2")

    @Mapping(target = "tlgTrDt", source = "systemSendReceiveTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "systemSendReceiveTime", dateFormat = "HHmmss")

    // 11. conditionBeneSearchConditionSort → SRCH_COND_SORT
    @Mapping(target = "srchCondSort", source = "conditionBeneSearchConditionSort")

    // 12. conditionBeneResidentBusinessNumber → COND_CTZ_BIZ_NO_ENC
    @Mapping(target = "condCtzBizNoEnc", source = "conditionBeneResidentBusinessNumber")

    // 13. conditionBeneBankCode → COND_BNK_CD
    @Mapping(target = "condBnkCd", source = "conditionBeneBankCode")

    // 14. conditionBeneDepositAccountNumber → COND_DPST_ACCT_NO
    @Mapping(target = "condDpstAcctNo", source = "conditionBeneDepositAccountNumber")

    // 15. conditionGuarantorSearchConditionSort → SRCH_COND_SORT_2
    @Mapping(target = "srchCondSort2", source = "conditionGuarantorSearchConditionSort")

    // 16. conditionGuarantorResidentBusinessNumber → COND_CTZ_BIZ_NO_ENC_2
    @Mapping(target = "condCtzBizNoEnc2", source = "conditionGuarantorResidentBusinessNumber")

    // 17. conditionGuarantorBankCode → COND_BNK_CD_2
    @Mapping(target = "condBnkCd2", source = "conditionGuarantorBankCode")

    // 18. conditionGuarantorDepositAccountNumber → COND_DPST_ACCT_NO_2
    @Mapping(target = "condDpstAcctNo2", source = "conditionGuarantorDepositAccountNumber")

    // 19. resultbeneCorpIndvSort → CORP_INDV_DVSN_CD (수취인 법인/개인 구분)
    @Mapping(target = "corpIndvDvsnCd", source = "resultbeneCorpIndvSort")

    // 20. resultbeneResidentBusinessNumber (소스에 있지만 매퍼에선 condCtzBizNoEnc...?
    //      만약 target에 "ctzBizNo"나 "ctzBizNoEnc"로 매핑해야 한다면 추가/수정
    @Mapping(target = "ctzBizNoEnc", ignore = true) // 예: 필요하다면 수정
    // (기본 예시는 ignore로 처리)

    // 21. resultbeneNameRepresentativeName → REP_NM
    @Mapping(target = "repNm", source = "resultbeneNameRepresentativeName")

    // 22. resultbeneCorpName → CORP_NM
    @Mapping(target = "corpNm", source = "resultbeneCorpName")

    // 23. resultbeneAddress → MBR_ADDR
    @Mapping(target = "mbrAddr", source = "resultbeneAddress")

    // 24. resultbenePhoneNumber → MBR_TEL_NO
    @Mapping(target = "mbrTelNo", source = "resultbenePhoneNumber")

    // 25. resultbeneMobilePhoneNumber → MBR_MOBILE_NO
    @Mapping(target = "mbrMobileNo", source = "resultbeneMobilePhoneNumber")

    // 26. resultbeneEmail → MBR_EMAIL
    @Mapping(target = "mbrEmail", source = "resultbeneEmail")

    // 27. resultbeneMemberSort → MBR_DVSN_CD
    @Mapping(target = "mbrDvsnCd", source = "resultbeneMemberSort")

    // 28. resultbeneCompanySize → CORP_SIZE_CD
    @Mapping(target = "corpSizeCd", source = "resultbeneCompanySize")

    // 29. resultbeneIndustryCode → BIZ_CD
    @Mapping(target = "bizCd", source = "resultbeneIndustryCode")

    // 30. resultGuarantorCorpIndvSort → CORP_INDV_DVSN_CD_2 (보증인)
    @Mapping(target = "corpIndvDvsnCd2", source = "resultGuarantorCorpIndvSort")

    // 31. resultGuarantorResidentBusinessNumber
    //     (마찬가지로 타겟에 매핑할 필드가 있으면 지정, 없으면 ignore)
//    @Mapping(target = "ctzBizNoEnc2", ignore = true) // 예시

    // 32. resultGuarantorNameRepresentativeName → REP_NM_2
    @Mapping(target = "repNm2", source = "resultGuarantorNameRepresentativeName")

    // 33. resultGuarantorCorpName → CORP_NM_2
    @Mapping(target = "corpNm2", source = "resultGuarantorCorpName")

    // 34. resultGuarantorAddress → MBR_ADDR_2
    @Mapping(target = "mbrAddr2", source = "resultGuarantorAddress")

    // 35. resultGuarantorPhoneNumber → MBR_TEL_NO_2
    @Mapping(target = "mbrTelNo2", source = "resultGuarantorPhoneNumber")

    // 36. resultGuarantorMobilePhoneNumber → MBR_MOBILE_NO_2
    @Mapping(target = "mbrMobileNo2", source = "resultGuarantorMobilePhoneNumber")

    // 37. resultGuarantorEmail → MBR_EMAIL_2
    @Mapping(target = "mbrEmail2", source = "resultGuarantorEmail")

    // 38. resultGuarantorMemberSort → MBR_DVSN_CD_2
    @Mapping(target = "mbrDvsnCd2", source = "resultGuarantorMemberSort")

    // 39. resultGuarantorCompanySize → CORP_SIZE_CD_2
    @Mapping(target = "corpSizeCd2", source = "resultGuarantorCompanySize")

    // 40. resultGuarantorIndustryCode → BIZ_CD_2
    @Mapping(target = "bizCd2", source = "resultGuarantorIndustryCode")

    @Override
    EntMbrL convert(CqeEnt0200221000 source);
}
