package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 배서보증 요청내역
 * <pre>{@code
 * KftEntES1123R kftEntES1123R  = new KftEntES1123R(); // 배서보증 요청내역
 * kftEntES1123R.setFileName(""); // 업무구분
 * kftEntES1123R.setDataType(""); // 데이터구분
 * kftEntES1123R.setSerialNumber(""); // 일련번호
 * kftEntES1123R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1123R.setBankCode(""); // 은행코드
 * kftEntES1123R.setGuaranteeRequestDate(""); // 보증요청일자
 * kftEntES1123R.setEnoteNumber(""); // 어음번호
 * kftEntES1123R.setEnoteType(""); // 어음종류
 * kftEntES1123R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1123R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1123R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1123R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1123R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1123R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES1123R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES1123R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES1123R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES1123R.setIssuerAddress(""); // 발행인-주소
 * kftEntES1123R.setEndorserCorpIndvSort(""); // 배서인(피보증인)-법인개인구분
 * kftEntES1123R.setEndorserResidentBusinessNumber(""); // 배서인(피보증인)-주민사업자번호
 * kftEntES1123R.setEndorserCorpName(""); // 배서인(피보증인)-법인명
 * kftEntES1123R.setEndorserNameRepresentativeName(""); // 배서인(피보증인)-성명(대표자명)
 * kftEntES1123R.setEndorserAddress(""); // 배서인(피보증인)-주소
 * kftEntES1123R.setEndorserBankCode(""); // 배서인(피보증인)-은행코드
 * kftEntES1123R.setEndorserDepositAccountNumber(""); // 배서인(피보증인)-입금계좌번호
 * kftEntES1123R.setEndorseeCorpIndvSort(""); // 피배서인-법인개인구분
 * kftEntES1123R.setEndorseeResidentBusinessNumber(""); // 피배서인-주민사업자번호
 * kftEntES1123R.setEndorseeCorpName(""); // 피배서인-법인명
 * kftEntES1123R.setEndorseeNameRepresentativeName(""); // 피배서인-성명(대표자명)
 * kftEntES1123R.setEndorseeAddress(""); // 피배서인-주소
 * kftEntES1123R.setEndorseeBankCode(""); // 피배서인-은행코드
 * kftEntES1123R.setEndorseeDepositAccountNumber(""); // 피배서인-입금계좌번호
 * kftEntES1123R.setUnsecuredEndorsementYn(""); // 무담보배서여부
 * kftEntES1123R.setNonEndorsableEndorsementYn(""); // 배서금지배서여부
 * kftEntES1123R.setGuaranteeTargetSplitNumber(""); // 보증대상 분할번호
 * kftEntES1123R.setGuaranteeTargetEndorsementNumber(""); // 보증대상 배서번호
 * kftEntES1123R.setEndorsementAmount(""); // 배서금액
 * kftEntES1123R.setGuarantorCorpIndvSort(""); // 보증인-법인개인구분
 * kftEntES1123R.setGuarantorResidentBusinessNumber(""); // 보증인-주민사업자번호
 * kftEntES1123R.setGuarantorCorpName(""); // 보증인-법인명
 * kftEntES1123R.setGuarantorNameRepresentativeName(""); // 보증인-성명(대표자명)
 * kftEntES1123R.setGuarantorAddress(""); // 보증인-주소
 * kftEntES1123R.setGuarantorBankCode(""); // 보증인-은행코드
 * kftEntES1123R.setGuarantorDepositAccountNumber(""); // 보증인-입금계좌번호
 * kftEntES1123R.setGuaranteeNumber(""); // 보증번호
 * kftEntES1123R.setGuaranteeProcessingParticipationSort(""); // 보증처리 참가구분
 * kftEntES1123R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1123R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String guaranteeRequestDate; // 보증요청일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String endorserCorpIndvSort; // 배서인(피보증인)-법인개인구분
	private String endorserResidentBusinessNumber; // 배서인(피보증인)-주민사업자번호
	private String endorserCorpName; // 배서인(피보증인)-법인명
	private String endorserNameRepresentativeName; // 배서인(피보증인)-성명(대표자명)
	private String endorserAddress; // 배서인(피보증인)-주소
	private String endorserBankCode; // 배서인(피보증인)-은행코드
	private String endorserDepositAccountNumber; // 배서인(피보증인)-입금계좌번호
	private String endorseeCorpIndvSort; // 피배서인-법인개인구분
	private String endorseeResidentBusinessNumber; // 피배서인-주민사업자번호
	private String endorseeCorpName; // 피배서인-법인명
	private String endorseeNameRepresentativeName; // 피배서인-성명(대표자명)
	private String endorseeAddress; // 피배서인-주소
	private String endorseeBankCode; // 피배서인-은행코드
	private String endorseeDepositAccountNumber; // 피배서인-입금계좌번호
	private String unsecuredEndorsementYn; // 무담보배서여부
	private String nonEndorsableEndorsementYn; // 배서금지배서여부
	private String guaranteeTargetSplitNumber; // 보증대상 분할번호
	private String guaranteeTargetEndorsementNumber; // 보증대상 배서번호
	private String endorsementAmount; // 배서금액
	private String guarantorCorpIndvSort; // 보증인-법인개인구분
	private String guarantorResidentBusinessNumber; // 보증인-주민사업자번호
	private String guarantorCorpName; // 보증인-법인명
	private String guarantorNameRepresentativeName; // 보증인-성명(대표자명)
	private String guarantorAddress; // 보증인-주소
	private String guarantorBankCode; // 보증인-은행코드
	private String guarantorDepositAccountNumber; // 보증인-입금계좌번호
	private String guaranteeNumber; // 보증번호
	private String guaranteeProcessingParticipationSort; // 보증처리 참가구분
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDate$; // 보증요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpIndvSort$; // 배서인(피보증인)-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserResidentBusinessNumber$; // 배서인(피보증인)-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserCorpName$; // 배서인(피보증인)-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserNameRepresentativeName$; // 배서인(피보증인)-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserAddress$; // 배서인(피보증인)-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserBankCode$; // 배서인(피보증인)-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorserDepositAccountNumber$; // 배서인(피보증인)-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeCorpIndvSort$; // 피배서인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeResidentBusinessNumber$; // 피배서인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeCorpName$; // 피배서인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeNameRepresentativeName$; // 피배서인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeAddress$; // 피배서인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeBankCode$; // 피배서인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorseeDepositAccountNumber$; // 피배서인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String unsecuredEndorsementYn$; // 무담보배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String nonEndorsableEndorsementYn$; // 배서금지배서여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeTargetSplitNumber$; // 보증대상 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeTargetEndorsementNumber$; // 보증대상 배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String endorsementAmount$; // 배서금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorCorpIndvSort$; // 보증인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorResidentBusinessNumber$; // 보증인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorCorpName$; // 보증인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorNameRepresentativeName$; // 보증인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorAddress$; // 보증인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorBankCode$; // 보증인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorDepositAccountNumber$; // 보증인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeNumber$; // 보증번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeProcessingParticipationSort$; // 보증처리 참가구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		guaranteeRequestDate$ = VOUtils.write(out, guaranteeRequestDate, 8); // 보증요청일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		endorserCorpIndvSort$ = VOUtils.write(out, endorserCorpIndvSort, 1); // 배서인(피보증인)-법인개인구분
		endorserResidentBusinessNumber$ = VOUtils.write(out, endorserResidentBusinessNumber, 13); // 배서인(피보증인)-주민사업자번호
		endorserCorpName$ = VOUtils.write(out, endorserCorpName, 40, "EUC-KR"); // 배서인(피보증인)-법인명
		endorserNameRepresentativeName$ = VOUtils.write(out, endorserNameRepresentativeName, 20, "EUC-KR"); // 배서인(피보증인)-성명(대표자명)
		endorserAddress$ = VOUtils.write(out, endorserAddress, 60, "EUC-KR"); // 배서인(피보증인)-주소
		endorserBankCode$ = VOUtils.write(out, endorserBankCode, 3); // 배서인(피보증인)-은행코드
		endorserDepositAccountNumber$ = VOUtils.write(out, endorserDepositAccountNumber, 16); // 배서인(피보증인)-입금계좌번호
		endorseeCorpIndvSort$ = VOUtils.write(out, endorseeCorpIndvSort, 1); // 피배서인-법인개인구분
		endorseeResidentBusinessNumber$ = VOUtils.write(out, endorseeResidentBusinessNumber, 13); // 피배서인-주민사업자번호
		endorseeCorpName$ = VOUtils.write(out, endorseeCorpName, 40, "EUC-KR"); // 피배서인-법인명
		endorseeNameRepresentativeName$ = VOUtils.write(out, endorseeNameRepresentativeName, 20, "EUC-KR"); // 피배서인-성명(대표자명)
		endorseeAddress$ = VOUtils.write(out, endorseeAddress, 60, "EUC-KR"); // 피배서인-주소
		endorseeBankCode$ = VOUtils.write(out, endorseeBankCode, 3); // 피배서인-은행코드
		endorseeDepositAccountNumber$ = VOUtils.write(out, endorseeDepositAccountNumber, 16); // 피배서인-입금계좌번호
		unsecuredEndorsementYn$ = VOUtils.write(out, unsecuredEndorsementYn, 1); // 무담보배서여부
		nonEndorsableEndorsementYn$ = VOUtils.write(out, nonEndorsableEndorsementYn, 1); // 배서금지배서여부
		guaranteeTargetSplitNumber$ = VOUtils.write(out, guaranteeTargetSplitNumber, 2); // 보증대상 분할번호
		guaranteeTargetEndorsementNumber$ = VOUtils.write(out, guaranteeTargetEndorsementNumber, 2); // 보증대상 배서번호
		endorsementAmount$ = VOUtils.write(out, endorsementAmount, 15); // 배서금액
		guarantorCorpIndvSort$ = VOUtils.write(out, guarantorCorpIndvSort, 1); // 보증인-법인개인구분
		guarantorResidentBusinessNumber$ = VOUtils.write(out, guarantorResidentBusinessNumber, 13); // 보증인-주민사업자번호
		guarantorCorpName$ = VOUtils.write(out, guarantorCorpName, 40, "EUC-KR"); // 보증인-법인명
		guarantorNameRepresentativeName$ = VOUtils.write(out, guarantorNameRepresentativeName, 20, "EUC-KR"); // 보증인-성명(대표자명)
		guarantorAddress$ = VOUtils.write(out, guarantorAddress, 60, "EUC-KR"); // 보증인-주소
		guarantorBankCode$ = VOUtils.write(out, guarantorBankCode, 3); // 보증인-은행코드
		guarantorDepositAccountNumber$ = VOUtils.write(out, guarantorDepositAccountNumber, 16); // 보증인-입금계좌번호
		guaranteeNumber$ = VOUtils.write(out, guaranteeNumber, 4); // 보증번호
		guaranteeProcessingParticipationSort$ = VOUtils.write(out, guaranteeProcessingParticipationSort, 1); // 보증처리 참가구분
		filler2$ = VOUtils.write(out, filler2, 35); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		guaranteeRequestDate = VOUtils.toString(guaranteeRequestDate$ = VOUtils.read(in, 8)); // 보증요청일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		endorserCorpIndvSort = VOUtils.toString(endorserCorpIndvSort$ = VOUtils.read(in, 1)); // 배서인(피보증인)-법인개인구분
		endorserResidentBusinessNumber = VOUtils.toString(endorserResidentBusinessNumber$ = VOUtils.read(in, 13)); // 배서인(피보증인)-주민사업자번호
		endorserCorpName = VOUtils.toString(endorserCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 배서인(피보증인)-법인명
		endorserNameRepresentativeName = VOUtils.toString(endorserNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 배서인(피보증인)-성명(대표자명)
		endorserAddress = VOUtils.toString(endorserAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 배서인(피보증인)-주소
		endorserBankCode = VOUtils.toString(endorserBankCode$ = VOUtils.read(in, 3)); // 배서인(피보증인)-은행코드
		endorserDepositAccountNumber = VOUtils.toString(endorserDepositAccountNumber$ = VOUtils.read(in, 16)); // 배서인(피보증인)-입금계좌번호
		endorseeCorpIndvSort = VOUtils.toString(endorseeCorpIndvSort$ = VOUtils.read(in, 1)); // 피배서인-법인개인구분
		endorseeResidentBusinessNumber = VOUtils.toString(endorseeResidentBusinessNumber$ = VOUtils.read(in, 13)); // 피배서인-주민사업자번호
		endorseeCorpName = VOUtils.toString(endorseeCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 피배서인-법인명
		endorseeNameRepresentativeName = VOUtils.toString(endorseeNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 피배서인-성명(대표자명)
		endorseeAddress = VOUtils.toString(endorseeAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 피배서인-주소
		endorseeBankCode = VOUtils.toString(endorseeBankCode$ = VOUtils.read(in, 3)); // 피배서인-은행코드
		endorseeDepositAccountNumber = VOUtils.toString(endorseeDepositAccountNumber$ = VOUtils.read(in, 16)); // 피배서인-입금계좌번호
		unsecuredEndorsementYn = VOUtils.toString(unsecuredEndorsementYn$ = VOUtils.read(in, 1)); // 무담보배서여부
		nonEndorsableEndorsementYn = VOUtils.toString(nonEndorsableEndorsementYn$ = VOUtils.read(in, 1)); // 배서금지배서여부
		guaranteeTargetSplitNumber = VOUtils.toString(guaranteeTargetSplitNumber$ = VOUtils.read(in, 2)); // 보증대상 분할번호
		guaranteeTargetEndorsementNumber = VOUtils.toString(guaranteeTargetEndorsementNumber$ = VOUtils.read(in, 2)); // 보증대상 배서번호
		endorsementAmount = VOUtils.toString(endorsementAmount$ = VOUtils.read(in, 15)); // 배서금액
		guarantorCorpIndvSort = VOUtils.toString(guarantorCorpIndvSort$ = VOUtils.read(in, 1)); // 보증인-법인개인구분
		guarantorResidentBusinessNumber = VOUtils.toString(guarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 보증인-주민사업자번호
		guarantorCorpName = VOUtils.toString(guarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 보증인-법인명
		guarantorNameRepresentativeName = VOUtils.toString(guarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 보증인-성명(대표자명)
		guarantorAddress = VOUtils.toString(guarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 보증인-주소
		guarantorBankCode = VOUtils.toString(guarantorBankCode$ = VOUtils.read(in, 3)); // 보증인-은행코드
		guarantorDepositAccountNumber = VOUtils.toString(guarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // 보증인-입금계좌번호
		guaranteeNumber = VOUtils.toString(guaranteeNumber$ = VOUtils.read(in, 4)); // 보증번호
		guaranteeProcessingParticipationSort = VOUtils.toString(guaranteeProcessingParticipationSort$ = VOUtils.read(in, 1)); // 보증처리 참가구분
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 35)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", guaranteeRequestDate=").append(guaranteeRequestDate).append(System.lineSeparator()); // 보증요청일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", endorserCorpIndvSort=").append(endorserCorpIndvSort).append(System.lineSeparator()); // 배서인(피보증인)-법인개인구분
		sb.append(", endorserResidentBusinessNumber=").append(endorserResidentBusinessNumber).append(System.lineSeparator()); // 배서인(피보증인)-주민사업자번호
		sb.append(", endorserCorpName=").append(endorserCorpName).append(System.lineSeparator()); // 배서인(피보증인)-법인명
		sb.append(", endorserNameRepresentativeName=").append(endorserNameRepresentativeName).append(System.lineSeparator()); // 배서인(피보증인)-성명(대표자명)
		sb.append(", endorserAddress=").append(endorserAddress).append(System.lineSeparator()); // 배서인(피보증인)-주소
		sb.append(", endorserBankCode=").append(endorserBankCode).append(System.lineSeparator()); // 배서인(피보증인)-은행코드
		sb.append(", endorserDepositAccountNumber=").append(endorserDepositAccountNumber).append(System.lineSeparator()); // 배서인(피보증인)-입금계좌번호
		sb.append(", endorseeCorpIndvSort=").append(endorseeCorpIndvSort).append(System.lineSeparator()); // 피배서인-법인개인구분
		sb.append(", endorseeResidentBusinessNumber=").append(endorseeResidentBusinessNumber).append(System.lineSeparator()); // 피배서인-주민사업자번호
		sb.append(", endorseeCorpName=").append(endorseeCorpName).append(System.lineSeparator()); // 피배서인-법인명
		sb.append(", endorseeNameRepresentativeName=").append(endorseeNameRepresentativeName).append(System.lineSeparator()); // 피배서인-성명(대표자명)
		sb.append(", endorseeAddress=").append(endorseeAddress).append(System.lineSeparator()); // 피배서인-주소
		sb.append(", endorseeBankCode=").append(endorseeBankCode).append(System.lineSeparator()); // 피배서인-은행코드
		sb.append(", endorseeDepositAccountNumber=").append(endorseeDepositAccountNumber).append(System.lineSeparator()); // 피배서인-입금계좌번호
		sb.append(", unsecuredEndorsementYn=").append(unsecuredEndorsementYn).append(System.lineSeparator()); // 무담보배서여부
		sb.append(", nonEndorsableEndorsementYn=").append(nonEndorsableEndorsementYn).append(System.lineSeparator()); // 배서금지배서여부
		sb.append(", guaranteeTargetSplitNumber=").append(guaranteeTargetSplitNumber).append(System.lineSeparator()); // 보증대상 분할번호
		sb.append(", guaranteeTargetEndorsementNumber=").append(guaranteeTargetEndorsementNumber).append(System.lineSeparator()); // 보증대상 배서번호
		sb.append(", endorsementAmount=").append(endorsementAmount).append(System.lineSeparator()); // 배서금액
		sb.append(", guarantorCorpIndvSort=").append(guarantorCorpIndvSort).append(System.lineSeparator()); // 보증인-법인개인구분
		sb.append(", guarantorResidentBusinessNumber=").append(guarantorResidentBusinessNumber).append(System.lineSeparator()); // 보증인-주민사업자번호
		sb.append(", guarantorCorpName=").append(guarantorCorpName).append(System.lineSeparator()); // 보증인-법인명
		sb.append(", guarantorNameRepresentativeName=").append(guarantorNameRepresentativeName).append(System.lineSeparator()); // 보증인-성명(대표자명)
		sb.append(", guarantorAddress=").append(guarantorAddress).append(System.lineSeparator()); // 보증인-주소
		sb.append(", guarantorBankCode=").append(guarantorBankCode).append(System.lineSeparator()); // 보증인-은행코드
		sb.append(", guarantorDepositAccountNumber=").append(guarantorDepositAccountNumber).append(System.lineSeparator()); // 보증인-입금계좌번호
		sb.append(", guaranteeNumber=").append(guaranteeNumber).append(System.lineSeparator()); // 보증번호
		sb.append(", guaranteeProcessingParticipationSort=").append(guaranteeProcessingParticipationSort).append(System.lineSeparator()); // 보증처리 참가구분
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorserResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorserCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorserNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorserAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorserBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorserDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "endorseeCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "endorseeResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "endorseeCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "endorseeNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "endorseeAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "endorseeBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "endorseeDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "unsecuredEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "nonEndorsableEndorsementYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guaranteeTargetSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "guaranteeTargetEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "guarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "guarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "guarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "guarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "guarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "guarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeNumber", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "guaranteeProcessingParticipationSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "35", "defltVal", "")
		);
	}

}
