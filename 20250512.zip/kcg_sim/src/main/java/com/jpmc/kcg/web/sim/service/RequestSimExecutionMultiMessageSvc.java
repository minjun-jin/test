package com.jpmc.kcg.web.sim.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.sim.biz.SimulDatabaseBean;
import com.jpmc.kcg.sim.biz.SimulMsgBuilderBean;
import com.jpmc.kcg.sim.dto.SimulMessage;
import com.jpmc.kcg.sim.dto.SimulMessageField;
import com.jpmc.kcg.sim.util.SimulBizUtils;
import com.jpmc.kcg.web.sim.service.dto.AddBulkExecutionMessagesIn;
import com.jpmc.kcg.web.sim.service.dto.AddBulkExecutionMessagesOut;
import com.jpmc.kcg.web.sim.service.dto.AddBulkExecutionMessagesSubIn;
import com.jpmc.kcg.web.sim.service.dto.AddBulkExecutionMessagesSubOut;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class RequestSimExecutionMultiMessageSvc {

	private SimulDatabaseBean database;
	private SimulMsgBuilderBean msgBuilder;

	public RequestSimExecutionMultiMessageSvc(SimulDatabaseBean database, SimulMsgBuilderBean msgBuilder) {
		this.database = database;
		this.msgBuilder = msgBuilder;
	}

	public AddBulkExecutionMessagesOut addBulkExecutionMessages(AddBulkExecutionMessagesIn svcIn) {

	    // 1. 필수입력 체크
	    if (StringUtils.isEmpty(svcIn.getTlgLaytId())) {
	        // 1-1. 전문레이아웃ID input 체크
	        throw new BusinessException("MCMNI01003", "tlgLaytId");
	    }

	    // 생성 건수
	    int crtCnt = Integer.parseInt(svcIn.getCrtCnt());
	    
	    // 입력 리스트
	    List<AddBulkExecutionMessagesSubIn> list = svcIn.getSubInList();

	    // 결과 리스트
	    List<AddBulkExecutionMessagesSubOut> subOutLists = new ArrayList<>();

	    // Loop for crtCnt
	    for (int count = 0; count < crtCnt; count++) {
	        Map<String, String> map = new LinkedHashMap<>();

	        for (AddBulkExecutionMessagesSubIn item : list) {
	            if (StringUtils.isNotEmpty(item.getFld())) {
	                String fldValues = item.getFldValues();

	                // crtBaseCd 처리
	                if ("01".equals(item.getCrtBaseCd())) {
	                    // Increase the fldValues by increaseVal
	                    long newValue = Long.parseLong(fldValues) + (Long.parseLong(item.getIncreaseVal()) * count);
	                    // newValue 값을 fldValues와 같은 길이의 0으로 채운 문자열로 포맷팅
	                    fldValues = String.format("%0" + fldValues.length() + "d", newValue);
	                } else if ("02".equals(item.getCrtBaseCd())) {
	                    // Append sequence number to fldValues
	                	fldValues = fldValues + String.valueOf(count+1);
	                }

	                map.put(item.getFld(), fldValues);
	            }
	        }

	        SimulMessage request = new SimulMessage();
	        request.setHostCd(svcIn.getHostCd());
	        request.setBizDvsnCd(svcIn.getBizDvsnCd());
	        request.setTlgLaytId(svcIn.getTlgLaytId());
	        request.setFieldMap(database.getTlgLaytFieldMap(svcIn.getTlgLaytId()));
	        Map<String, SimulMessageField> fieldIdMap = SimulBizUtils.convertToFldIdMap(request.getFieldMap());
		    Map<String, String> fldvalues = map;
		    if (fldvalues != null && !fldvalues.isEmpty()) {
	    	    fieldIdMap.forEach((k, v) -> {
	    	        v.setValue(fldvalues.get(k));
	    	        log.info("#@@# k, fldvalues.get(k) ::: [" + k + "],"+ fldvalues.get(k));
	    	    });
		    }
	        request.setFlagKeepReservedFields(false);

	        String tlgCtt = this.msgBuilder.marshalMessage(request);

	        log.info("#@@# tlgCtt :::" + tlgCtt);

	        AddBulkExecutionMessagesSubOut subList = new AddBulkExecutionMessagesSubOut();
	        //시작 count가 1이라서 -1
	        subList.setSeq(String.valueOf(count));
	        subList.setTlgCtt(tlgCtt);
	        subOutLists.add(subList);
	    }

	    AddBulkExecutionMessagesOut svcOut = new AddBulkExecutionMessagesOut();
	    svcOut.setMultiMsgList(subOutLists);
	    log.info("#@@# subOutLists :::" + subOutLists);

	    return svcOut;
	}
}
