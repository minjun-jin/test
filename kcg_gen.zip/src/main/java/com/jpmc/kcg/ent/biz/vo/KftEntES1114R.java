package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 발행인 소지어음 지급필 처리내역
 * <pre>{@code
 * KftEntES1114R kftEntES1114R  = new KftEntES1114R(); // 발행인 소지어음 지급필 처리내역
 * kftEntES1114R.setFileName(""); // 업무구분
 * kftEntES1114R.setDataType(""); // 데이터구분
 * kftEntES1114R.setSerialNumber(""); // 일련번호
 * kftEntES1114R.setPaymentPresentationDate(""); // 지급제시일자
 * kftEntES1114R.setEnoteNumber(""); // 어음번호
 * kftEntES1114R.setEnoteType(""); // 어음종류
 * kftEntES1114R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1114R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1114R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1114R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1114R.setIssuerCorpIndvSort(""); // 발행인-법인개인구분
 * kftEntES1114R.setIssuerResidentBusinessNumber(""); // 발행인-주민사업자번호
 * kftEntES1114R.setIssuerCorpName(""); // 발행인-법인명
 * kftEntES1114R.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEntES1114R.setIssuerAddress(""); // 발행인-주소
 * kftEntES1114R.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEntES1114R.setSplitNumber(""); // 분할번호
 * kftEntES1114R.setFinalEndorsementNumber(""); // 최종배서번호
 * kftEntES1114R.setBeforeChangeENoteProcessStatus(""); // 변경전-전자어음 처리상태 코드
 * kftEntES1114R.setAfterChangeENoteProcessStatus(""); // 변경후-전자어음 처리상태 코드
 * kftEntES1114R.setCorrectionDateAndTime(""); // 정정일시
 * kftEntES1114R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1114R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String paymentPresentationDate; // 지급제시일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String issuerCorpIndvSort; // 발행인-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인-주민사업자번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String splitNumber; // 분할번호
	private String finalEndorsementNumber; // 최종배서번호
	private String beforeChangeENoteProcessStatus; // 변경전-전자어음 처리상태 코드
	private String afterChangeENoteProcessStatus; // 변경후-전자어음 처리상태 코드
	private String correctionDateAndTime; // 정정일시
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentPresentationDate$; // 지급제시일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String finalEndorsementNumber$; // 최종배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeChangeENoteProcessStatus$; // 변경전-전자어음 처리상태 코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String afterChangeENoteProcessStatus$; // 변경후-전자어음 처리상태 코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String correctionDateAndTime$; // 정정일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		paymentPresentationDate$ = VOUtils.write(out, paymentPresentationDate, 8); // 지급제시일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13, "EUC-KR"); // 발행인-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		finalEndorsementNumber$ = VOUtils.write(out, finalEndorsementNumber, 2); // 최종배서번호
		beforeChangeENoteProcessStatus$ = VOUtils.write(out, beforeChangeENoteProcessStatus, 2); // 변경전-전자어음 처리상태 코드
		afterChangeENoteProcessStatus$ = VOUtils.write(out, afterChangeENoteProcessStatus, 2); // 변경후-전자어음 처리상태 코드
		correctionDateAndTime$ = VOUtils.write(out, correctionDateAndTime, 14); // 정정일시
		filler2$ = VOUtils.write(out, filler2, 16); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		paymentPresentationDate = VOUtils.toString(paymentPresentationDate$ = VOUtils.read(in, 8)); // 지급제시일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13, "EUC-KR")); // 발행인-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		finalEndorsementNumber = VOUtils.toString(finalEndorsementNumber$ = VOUtils.read(in, 2)); // 최종배서번호
		beforeChangeENoteProcessStatus = VOUtils.toString(beforeChangeENoteProcessStatus$ = VOUtils.read(in, 2)); // 변경전-전자어음 처리상태 코드
		afterChangeENoteProcessStatus = VOUtils.toString(afterChangeENoteProcessStatus$ = VOUtils.read(in, 2)); // 변경후-전자어음 처리상태 코드
		correctionDateAndTime = VOUtils.toString(correctionDateAndTime$ = VOUtils.read(in, 14)); // 정정일시
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 16)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", paymentPresentationDate=").append(paymentPresentationDate).append(System.lineSeparator()); // 지급제시일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", finalEndorsementNumber=").append(finalEndorsementNumber).append(System.lineSeparator()); // 최종배서번호
		sb.append(", beforeChangeENoteProcessStatus=").append(beforeChangeENoteProcessStatus).append(System.lineSeparator()); // 변경전-전자어음 처리상태 코드
		sb.append(", afterChangeENoteProcessStatus=").append(afterChangeENoteProcessStatus).append(System.lineSeparator()); // 변경후-전자어음 처리상태 코드
		sb.append(", correctionDateAndTime=").append(correctionDateAndTime).append(System.lineSeparator()); // 정정일시
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "paymentPresentationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "finalEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "beforeChangeENoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "afterChangeENoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "correctionDateAndTime", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "16", "defltVal", "")
		);
	}

}
