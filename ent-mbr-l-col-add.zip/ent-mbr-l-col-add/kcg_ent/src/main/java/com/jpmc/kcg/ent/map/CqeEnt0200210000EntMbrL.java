package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0200210000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Mapper(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, imports = {LocalDateTime.class, BigDecimal.class, DateUtils.class, EntConst.class, ComConst.class})
public interface CqeEnt0200210000EntMbrL extends Converter<CqeEnt0200210000, EntMbrL> {

    @Override
    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())") // 거래일자
    @Mapping(target = "entTlgTrceNo", source = "transactionIdNumber") // 전문추적번호
    @Mapping(target = "trUnqNo", source = "transactionIdNumber") // 거래고유번호
    @Mapping(target = "hostNo", source = "msgNo") // 호스트거래번호
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.OUTBOUND_CD)") // 송수신FLAG
    @Mapping(target = "othrPartyBnkCd", ignore = true) // 상대은행코드
    @Mapping(target = "sysDvsn", expression = "java(EntConst.SYS_ID)") // 시스템구분
    @Mapping(target = "bnkCd", source = "bnkCd") // 은행코드
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType") // 전문종별코드
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode") // 거래구분코드
    @Mapping(target = "sndRcvDvsnCd", expression = "java(EntConst.SND_FLAG)") // 송수신FLAG
    @Mapping(target = "trSts", ignore = true) // 상태
    @Mapping(target = "respCd1", source = "responseCode1") // 응답코드1
    @Mapping(target = "respCd2", source = "responseCode2") // 응답코드2
    @Mapping(target = "tlgTrDt", source = "systemSendReceiveTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "systemSendReceiveTime", dateFormat = "HHmmss")
    @Mapping(target = "kftcStattcCd", ignore = true) // 관리기관통계코드
    @Mapping(target = "trMemo", ignore = true) // 거래메모
    @Mapping(target = "srchCondSort", ignore = true) // 검색조건구분1
    @Mapping(target = "condCtzBizNoEnc", ignore = true) // 검색조건주민사업자번호1(암호화)
    @Mapping(target = "condBnkCd", ignore = true) // 검색조건은행코드1
    @Mapping(target = "condDpstAcctNo", ignore = true) // 검색조건입금계좌번호1
    @Mapping(target = "srchCondSort2", ignore = true) // 검색조건구분2
    @Mapping(target = "condCtzBizNoEnc2", ignore = true)// 검색조건주민사업자번호2(암호화)
    @Mapping(target = "condBnkCd2", ignore = true)// 검색조건은행코드2
    @Mapping(target = "condDpstAcctNo2", ignore = true)// 검색조건입금계좌번호2
    @Mapping(target = "ctzBizNoEnc", ignore = true)// 주민사업자번호(암호화)
    @Mapping(target = "currAcctNo", source = "currentAccountNumber")// 당좌계좌번호
    @Mapping(target = "dpstAcctNo", source = "depositAccountNumber")// 입금계좌번호
    @Mapping(target = "ctzBizNo", source = "residentBusinessNumber")// 주민사업자번호
    @Mapping(target = "entPrcsDvsnCd", source = "processSort")// 처리구분
    @Mapping(target = "corpIndvDvsnCd", source = "corpIndvSort")// 법인개인구분
    @Mapping(target = "repNm", source = "nameRepresentativeName")// 성명(대표자명)
    @Mapping(target = "corpNm", source = "corpName")// 법인명
    @Mapping(target = "mbrAddr", source = "address")// 주소
    @Mapping(target = "mbrTelNo", source = "phoneNumber")// 전화번호
    @Mapping(target = "mbrMobileNo", source = "mobilePhoneNumber")// 핸드폰번호
    @Mapping(target = "mbrEmail", source = "emailAddress")// 이메일주소
    @Mapping(target = "pymntExCd", source = "paymentBranchClearingHouseCode")// 지급점포교환소코드
    @Mapping(target = "pymntRqstRegBnkCd", source = "paymentRegisterRequestBankCode")// 지급등록의뢰은행코드
    @Mapping(target = "pymntBnkBrnchCd", source = "paymentRegisterRequestBankBranchCode")// 지급등록의뢰은행지점코드
    @Mapping(target = "entCurrOpnDt", source = "ENoteCurrentTransactionStartEndDate")// 전자어음당좌거래개시해지일자
    @Mapping(target = "corpSizeCd", source = "companySize")// 기업규모
    @Mapping(target = "bizCd", source = "industryCode")// 업종코드
    @Mapping(target = "lmtAmt", expression = "java(BigDecimal.valueOf(source.getLimitAmount()))")// 한도금액
    @Mapping(target = "mbrDvsnCd", source = "memberSort") // 주소2
    @Mapping(target = "corpIndvDvsnCd2", ignore = true) // 전화번호2
    @Mapping(target = "repNm2", ignore = true) // 핸드폰번호2
    @Mapping(target = "corpNm2", ignore = true) // 이메일주소2
    @Mapping(target = "mbrAddr2", ignore = true) // 주소2
    @Mapping(target = "mbrTelNo2", ignore = true) // 전화번호2
    @Mapping(target = "mbrMobileNo2", ignore = true) // 핸드폰번호2
    @Mapping(target = "mbrEmail2", ignore = true) // 이메일주소2
    @Mapping(target = "corpSizeCd2", ignore = true) // 기업규모2
    @Mapping(target = "bizCd2", ignore = true) // 업종코드2
    @Mapping(target = "mbrDvsnCd2", ignore = true) // 회원구분2
    @Mapping(target = "chgAfCurrAcctNo", source = "afterChangeCurrentAccountNumber") // 변경후당좌계좌번호
    @Mapping(target = "chgAfDpstAcctNo", source = "afterChangeDepositAccountNumber") // 변경후입금계좌번호
    @Mapping(target = "frstChngGuid", ignore = true) // 최초변경GUID
    @Mapping(target = "frstChngStaffId", ignore = true) // 최초변경직원ID
    @Mapping(target = "frstChngTmstmp", ignore = true) // 최초변경타임스탬프
    @Mapping(target = "lastChngGuid", ignore = true) // 최종변경GUID
    @Mapping(target = "lastChngStaffId", ignore = true) // 최종변경직원ID
    @Mapping(target = "lastChngTmstmp", ignore = true)
        // 최종변경타임스탬프
    EntMbrL convert(CqeEnt0200210000 source);
}