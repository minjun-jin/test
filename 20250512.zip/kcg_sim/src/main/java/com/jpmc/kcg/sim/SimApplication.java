package com.jpmc.kcg.sim;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.AutoConfigurationExcludeFilter;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.TypeExcludeFilter;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.FilterType;
import org.springframework.context.annotation.FullyQualifiedAnnotationBeanNameGenerator;
import org.springframework.context.annotation.Import;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.jpmc.kcg.KcgSimCmn;
import com.jpmc.kcg.com.ComApplication;
import com.jpmc.kcg.com.dao.ComMapper;
import com.jpmc.kcg.frw.FrwApplication;
import com.jpmc.kcg.frw.FrwService;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.sim.dao.SimMapper;

@MapperScan(basePackageClasses = {
	FrwMapper.class,
	ComMapper.class,
	SimMapper.class,
}, basePackages = {
	"com.jpmc.kcg.web.*.dao",
}, nameGenerator = FullyQualifiedAnnotationBeanNameGenerator.class)
@ComponentScan(basePackageClasses = {
	FrwApplication.class,
	ComApplication.class,
	SimApplication.class,
}, basePackages = "com.jpmc.kcg.web", excludeFilters = {
	@Filter(type = FilterType.CUSTOM, classes = TypeExcludeFilter.class),
	@Filter(type = FilterType.CUSTOM, classes = AutoConfigurationExcludeFilter.class),
	@Filter(type = FilterType.ANNOTATION, classes = SpringBootApplication.class),
	@Filter(type = FilterType.ASSIGNABLE_TYPE, classes = FrwService.class),
})
@SpringBootConfiguration
@EnableAutoConfiguration
@Import({
	KcgSimCmn.class,
})
@EnableJms
@EnableAsync
@EnableScheduling
public class SimApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimApplication.class, args);
	}

}
