package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보 조회 요청
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * conditionSearchConditionSort 조건-검색조건구분 
 * conditionResidentBusinessNumber 조건-주민(사업자)번호 
 * conditionBankCode 조건-은행코드 
 * conditionDepositAccountNumber 조건-입금계좌번호 
 * resultCorpIndvSort 결과-법인개인구분 
 * resultResidentBusinessNumber 결과-주민(사업자)번호 
 * resultNameRepresentativeName 결과-성명(대표자명) 
 * resultCorpName 결과-법인명 
 * resultAddress 결과-주소 
 * resultPhoneNumber 결과-전화번호 
 * resultMobilePhoneNumber 결과-핸드폰번호 
 * resultEmail 결과-이메일 
 * resultMemberSort 결과-회원구분 
 * resultCompanySize 결과-기업규모 
 * resultIndustryCode 결과-업종코드 
 * 
 * CqeEnt0200220000 cqeEnt0200220000 = new CqeEnt0200220000(); // 회원정보 조회 요청
 * cqeEnt0200220000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200220000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200220000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200220000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200220000.setTransactionCode("220000"); // 거래구분코드
 * cqeEnt0200220000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200220000.setBnkCd("057"); // 은행코드
 * cqeEnt0200220000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200220000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200220000.setFiller(""); // FILLER
 * cqeEnt0200220000.setConditionSearchConditionSort(""); // 조건-검색조건구분
 * cqeEnt0200220000.setConditionResidentBusinessNumber(""); // 조건-주민(사업자)번호
 * cqeEnt0200220000.setConditionBankCode(""); // 조건-은행코드
 * cqeEnt0200220000.setConditionDepositAccountNumber(""); // 조건-입금계좌번호
 * cqeEnt0200220000.setResultCorpIndvSort(""); // 결과-법인개인구분
 * cqeEnt0200220000.setResultResidentBusinessNumber(""); // 결과-주민(사업자)번호
 * cqeEnt0200220000.setResultNameRepresentativeName(""); // 결과-성명(대표자명)
 * cqeEnt0200220000.setResultCorpName(""); // 결과-법인명
 * cqeEnt0200220000.setResultAddress(""); // 결과-주소
 * cqeEnt0200220000.setResultPhoneNumber(""); // 결과-전화번호
 * cqeEnt0200220000.setResultMobilePhoneNumber(""); // 결과-핸드폰번호
 * cqeEnt0200220000.setResultEmail(""); // 결과-이메일
 * cqeEnt0200220000.setResultMemberSort(""); // 결과-회원구분
 * cqeEnt0200220000.setResultCompanySize(""); // 결과-기업규모
 * cqeEnt0200220000.setResultIndustryCode(""); // 결과-업종코드
 * }</pre>
 */
@Data
public class CqeEnt0200220000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "220000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String conditionSearchConditionSort; // 조건-검색조건구분
	private String conditionResidentBusinessNumber; // 조건-주민(사업자)번호
	private String conditionBankCode; // 조건-은행코드
	private String conditionDepositAccountNumber; // 조건-입금계좌번호
	private String resultCorpIndvSort; // 결과-법인개인구분
	private String resultResidentBusinessNumber; // 결과-주민(사업자)번호
	private String resultNameRepresentativeName; // 결과-성명(대표자명)
	private String resultCorpName; // 결과-법인명
	private String resultAddress; // 결과-주소
	private String resultPhoneNumber; // 결과-전화번호
	private String resultMobilePhoneNumber; // 결과-핸드폰번호
	private String resultEmail; // 결과-이메일
	private String resultMemberSort; // 결과-회원구분
	private String resultCompanySize; // 결과-기업규모
	private String resultIndustryCode; // 결과-업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionSearchConditionSort$; // 조건-검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionResidentBusinessNumber$; // 조건-주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBankCode$; // 조건-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionDepositAccountNumber$; // 조건-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCorpIndvSort$; // 결과-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultResidentBusinessNumber$; // 결과-주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultNameRepresentativeName$; // 결과-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCorpName$; // 결과-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultAddress$; // 결과-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultPhoneNumber$; // 결과-전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultMobilePhoneNumber$; // 결과-핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultEmail$; // 결과-이메일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultMemberSort$; // 결과-회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultCompanySize$; // 결과-기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultIndustryCode$; // 결과-업종코드

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isNotAlphanumericSpace(conditionDepositAccountNumber$)) { // 조건-입금계좌번호
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(resultResidentBusinessNumber$)) { // 결과-주민(사업자)번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(resultPhoneNumber$)) { // 결과-전화번호
			return 19;
		}
		if (VOUtils.isNotAlphanumericSpace(resultMobilePhoneNumber$)) { // 결과-핸드폰번호
			return 20;
		}
		if (VOUtils.isNotAlphanumericSpace(resultEmail$)) { // 결과-이메일
			return 21;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		conditionSearchConditionSort$ = VOUtils.write(out, conditionSearchConditionSort, 1); // 조건-검색조건구분
		conditionResidentBusinessNumber$ = VOUtils.write(out, conditionResidentBusinessNumber, 13); // 조건-주민(사업자)번호
		conditionBankCode$ = VOUtils.write(out, conditionBankCode, 3); // 조건-은행코드
		conditionDepositAccountNumber$ = VOUtils.write(out, conditionDepositAccountNumber, 16); // 조건-입금계좌번호
		resultCorpIndvSort$ = VOUtils.write(out, resultCorpIndvSort, 1); // 결과-법인개인구분
		resultResidentBusinessNumber$ = VOUtils.write(out, resultResidentBusinessNumber, 13); // 결과-주민(사업자)번호
		resultNameRepresentativeName$ = VOUtils.write(out, resultNameRepresentativeName, 20, "EUC-KR"); // 결과-성명(대표자명)
		resultCorpName$ = VOUtils.write(out, resultCorpName, 40, "EUC-KR"); // 결과-법인명
		resultAddress$ = VOUtils.write(out, resultAddress, 60, "EUC-KR"); // 결과-주소
		resultPhoneNumber$ = VOUtils.write(out, resultPhoneNumber, 14); // 결과-전화번호
		resultMobilePhoneNumber$ = VOUtils.write(out, resultMobilePhoneNumber, 14); // 결과-핸드폰번호
		resultEmail$ = VOUtils.write(out, resultEmail, 40); // 결과-이메일
		resultMemberSort$ = VOUtils.write(out, resultMemberSort, 1); // 결과-회원구분
		resultCompanySize$ = VOUtils.write(out, resultCompanySize, 1); // 결과-기업규모
		resultIndustryCode$ = VOUtils.write(out, resultIndustryCode, 2); // 결과-업종코드
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		conditionSearchConditionSort = VOUtils.toString(conditionSearchConditionSort$ = VOUtils.read(in, 1)); // 조건-검색조건구분
		conditionResidentBusinessNumber = VOUtils.toString(conditionResidentBusinessNumber$ = VOUtils.read(in, 13)); // 조건-주민(사업자)번호
		conditionBankCode = VOUtils.toString(conditionBankCode$ = VOUtils.read(in, 3)); // 조건-은행코드
		conditionDepositAccountNumber = VOUtils.toString(conditionDepositAccountNumber$ = VOUtils.read(in, 16)); // 조건-입금계좌번호
		resultCorpIndvSort = VOUtils.toString(resultCorpIndvSort$ = VOUtils.read(in, 1)); // 결과-법인개인구분
		resultResidentBusinessNumber = VOUtils.toString(resultResidentBusinessNumber$ = VOUtils.read(in, 13)); // 결과-주민(사업자)번호
		resultNameRepresentativeName = VOUtils.toString(resultNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 결과-성명(대표자명)
		resultCorpName = VOUtils.toString(resultCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 결과-법인명
		resultAddress = VOUtils.toString(resultAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 결과-주소
		resultPhoneNumber = VOUtils.toString(resultPhoneNumber$ = VOUtils.read(in, 14)); // 결과-전화번호
		resultMobilePhoneNumber = VOUtils.toString(resultMobilePhoneNumber$ = VOUtils.read(in, 14)); // 결과-핸드폰번호
		resultEmail = VOUtils.toString(resultEmail$ = VOUtils.read(in, 40)); // 결과-이메일
		resultMemberSort = VOUtils.toString(resultMemberSort$ = VOUtils.read(in, 1)); // 결과-회원구분
		resultCompanySize = VOUtils.toString(resultCompanySize$ = VOUtils.read(in, 1)); // 결과-기업규모
		resultIndustryCode = VOUtils.toString(resultIndustryCode$ = VOUtils.read(in, 2)); // 결과-업종코드
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", conditionSearchConditionSort=").append(conditionSearchConditionSort).append(System.lineSeparator()); // 조건-검색조건구분
		sb.append(", conditionResidentBusinessNumber=").append(conditionResidentBusinessNumber).append(System.lineSeparator()); // 조건-주민(사업자)번호
		sb.append(", conditionBankCode=").append(conditionBankCode).append(System.lineSeparator()); // 조건-은행코드
		sb.append(", conditionDepositAccountNumber=").append(conditionDepositAccountNumber).append(System.lineSeparator()); // 조건-입금계좌번호
		sb.append(", resultCorpIndvSort=").append(resultCorpIndvSort).append(System.lineSeparator()); // 결과-법인개인구분
		sb.append(", resultResidentBusinessNumber=").append(resultResidentBusinessNumber).append(System.lineSeparator()); // 결과-주민(사업자)번호
		sb.append(", resultNameRepresentativeName=").append(resultNameRepresentativeName).append(System.lineSeparator()); // 결과-성명(대표자명)
		sb.append(", resultCorpName=").append(resultCorpName).append(System.lineSeparator()); // 결과-법인명
		sb.append(", resultAddress=").append(resultAddress).append(System.lineSeparator()); // 결과-주소
		sb.append(", resultPhoneNumber=").append(resultPhoneNumber).append(System.lineSeparator()); // 결과-전화번호
		sb.append(", resultMobilePhoneNumber=").append(resultMobilePhoneNumber).append(System.lineSeparator()); // 결과-핸드폰번호
		sb.append(", resultEmail=").append(resultEmail).append(System.lineSeparator()); // 결과-이메일
		sb.append(", resultMemberSort=").append(resultMemberSort).append(System.lineSeparator()); // 결과-회원구분
		sb.append(", resultCompanySize=").append(resultCompanySize).append(System.lineSeparator()); // 결과-기업규모
		sb.append(", resultIndustryCode=").append(resultIndustryCode).append(System.lineSeparator()); // 결과-업종코드
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "220000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "conditionSearchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "conditionResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "conditionBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "conditionDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "resultCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "resultNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "resultCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "resultPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultMobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultEmail", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultMemberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultCompanySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultIndustryCode", "fldLen", "2", "defltVal", "")
		);
	}

}
