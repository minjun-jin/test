package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 출금취소지시
 * <pre>{@code
 * KftCmsEB35R kftCmsEB35R  = new KftCmsEB35R(); // 출금취소지시
 * kftCmsEB35R.setRecordType(""); // Record 구분
 * kftCmsEB35R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB35R.setInstitutionCode(""); // 기관코드
 * kftCmsEB35R.setMainBankBranchCode(""); // 주거래은행점코드
 * kftCmsEB35R.setDepositAccountNumber(""); // 입금계좌번호
 * kftCmsEB35R.setFailedDepositCount(0); // 입금불능건수
 * kftCmsEB35R.setFailedDepositAmount(0L); // 입금불능금액
 * kftCmsEB35R.setTotalFee(0L); // 총수수료
 * kftCmsEB35R.setWithdrawalBankFee(0L); // 출금은행수수료
 * kftCmsEB35R.setDepositBankFee(0L); // 입금은행수수료
 * kftCmsEB35R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB35R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String mainBankBranchCode; // 주거래은행점코드
	private String depositAccountNumber; // 입금계좌번호
	private int failedDepositCount; // 입금불능건수
	private long failedDepositAmount; // 입금불능금액
	private long totalFee; // 총수수료
	private long withdrawalBankFee; // 출금은행수수료
	private long depositBankFee; // 입금은행수수료
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mainBankBranchCode$; // 주거래은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failedDepositCount$; // 입금불능건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String failedDepositAmount$; // 입금불능금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalFee$; // 총수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalBankFee$; // 출금은행수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositBankFee$; // 입금은행수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		mainBankBranchCode$ = VOUtils.write(out, mainBankBranchCode, 7); // 주거래은행점코드
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		failedDepositCount$ = VOUtils.write(out, failedDepositCount, 8); // 입금불능건수
		failedDepositAmount$ = VOUtils.write(out, failedDepositAmount, 13); // 입금불능금액
		totalFee$ = VOUtils.write(out, totalFee, 11); // 총수수료
		withdrawalBankFee$ = VOUtils.write(out, withdrawalBankFee, 11); // 출금은행수수료
		depositBankFee$ = VOUtils.write(out, depositBankFee, 11); // 입금은행수수료
		filler2$ = VOUtils.write(out, filler2, 54); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		mainBankBranchCode = VOUtils.toString(mainBankBranchCode$ = VOUtils.read(in, 7)); // 주거래은행점코드
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		failedDepositCount = VOUtils.toInt(failedDepositCount$ = VOUtils.read(in, 8)); // 입금불능건수
		failedDepositAmount = VOUtils.toLong(failedDepositAmount$ = VOUtils.read(in, 13)); // 입금불능금액
		totalFee = VOUtils.toLong(totalFee$ = VOUtils.read(in, 11)); // 총수수료
		withdrawalBankFee = VOUtils.toLong(withdrawalBankFee$ = VOUtils.read(in, 11)); // 출금은행수수료
		depositBankFee = VOUtils.toLong(depositBankFee$ = VOUtils.read(in, 11)); // 입금은행수수료
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 54)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", mainBankBranchCode=").append(mainBankBranchCode).append(System.lineSeparator()); // 주거래은행점코드
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", failedDepositCount=").append(failedDepositCount).append(System.lineSeparator()); // 입금불능건수
		sb.append(", failedDepositAmount=").append(failedDepositAmount).append(System.lineSeparator()); // 입금불능금액
		sb.append(", totalFee=").append(totalFee).append(System.lineSeparator()); // 총수수료
		sb.append(", withdrawalBankFee=").append(withdrawalBankFee).append(System.lineSeparator()); // 출금은행수수료
		sb.append(", depositBankFee=").append(depositBankFee).append(System.lineSeparator()); // 입금은행수수료
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "mainBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "failedDepositCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "failedDepositAmount", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "totalFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "withdrawalBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "depositBankFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "54", "defltVal", "")
		);
	}

}
