import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// URPRINQ003 컴포넌트를 불러옵니다.
import URPRINQ003 from "@/pages/views/rpr/URPRINQ-003"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(URPRINQ003)

describe("[URPRINQ-003] 자금청구 일괄등록", () => {
  beforeAll(() => {
    mockDateUtils.mockToday.mockReturnValue("19900101")
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })
  it("valueFormatter Test", async () => {
    const { findByText } = render(component)
    const valueFormatterTestBtn = await findByText(/valueFormatter Test/)
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("valueGetter Test - respCd is null", async () => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: null,
        },
      },
    })
  })

  it("valueGetter Test - respCd is not null", async () => {
    const { findByText } = render(component)
    const valueGetterTestBtn = await findByText(/valueGetter Test/)
    fireEvent.click(valueGetterTestBtn, {
      target: {
        data: {
          respCd: "test",
        },
      },
    })
  })

  it.each([
    {
      colDef: {
        field: "fullRtnYn",
      },
      data: {
        fullRtnYn: "N",
        totTrAmt: "10",
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "fullRtnYn",
      },
      data: {
        fullRtnYn: "N",
        totTrAmt: undefined,
        originalTotTrAmt: "10",
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "fullRtnYn",
      },
      data: {
        fullRtnYn: "Y",
        totTrAmt: "10",
        originalTotTrAmt: "10",
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "fullRtnYn",
      },
      data: {
        fullRtnYn: "Y",
        totTrAmt: "10",
        originalTotTrAmt: undefined,
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "fullRtnYn",
      },
      data: {
        fullRtnYn: "C",
        totTrAmt: "10",
        originalTotTrAmt: undefined,
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "rtnRsnCd",
      },
      data: {
        rtnRsnCd: "05",
      },
      node: {
        setData: jest.fn(),
      },
    },
    {
      colDef: {
        field: "rtnRsnCd",
      },
      data: {
        rtnRsnCd: "04",
      },
      node: {
        setData: jest.fn(),
      },
    },
  ])("onCellValueChanged Test", async (event) => {
    const { findByText } = render(component)
    const onCellValueChangedTestBtn = await findByText(
      /onCellValueChanged Test/,
    )
    fireEvent.click(onCellValueChangedTestBtn, {
      target: { data: { onCellValueChanged: event } },
    })
  })

  it("editable Test", async () => {
    const { findByText } = render(component)
    const editableTestBtn = await findByText(/editable Test/)
    fireEvent.click(editableTestBtn, { target: { data: {} } })
  })

  it("rowClassRules Test", async () => {
    const { findByText } = render(component)
    const rowClassRulesTestBtn = await findByText(/rowClassRules Test/)
    fireEvent.click(rowClassRulesTestBtn, {
      target: { data: { data: { aprvStsCd: "01" } } },
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 01", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: "01" } },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is 02", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: "02" } },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).toHaveBeenCalled()
    })
  })

  it("onRowDoubleClicked Test - aprvStsCd is null", async () => {
    const { findByText } = render(component)
    const onRowDoubleClickedTestBtn = await findByText(
      /onRowDoubleClicked Test/,
    )
    fireEvent.click(onRowDoubleClickedTestBtn, {
      target: { data: { aprvStsCd: null } },
    })
    await waitFor(() => {
      expect(mockUseMenu.mockOpenMenuByScrnId).not.toHaveBeenCalled()
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("searchClick Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("batRegClick Test - selectedList.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const batRegBtn = await findByText(/SCRNITM#batReg/)
    fireEvent.click(batRegBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("batRegClick Test - mgrTelNo is undefined", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([{}])
    mockUseForm.mockGetValues.mockReturnValueOnce(undefined)
    const { findByText } = render(component)
    const batRegBtn = await findByText(/SCRNITM#batReg/)
    fireEvent.click(batRegBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("batRegClick Test - list is Invalid", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        fullRtnYn: "test",
        rqstRsnCd: "test",
        rqstRsn: "test",
      },
    ])
    mockUseForm.mockGetValues.mockReturnValueOnce("test")

    const { findByText } = render(component)
    const batRegBtn = await findByText(/SCRNITM#batReg/)
    fireEvent.click(batRegBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("batRegClick Test", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        fullRtnYn: "test",
        rtnRsnCd: "test",
        rtnRsn: "test",
        rqstRtnTrAmt: "test",
      },
    ])
    mockUseForm.mockGetValues.mockReturnValueOnce("test")
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {},
      })
      .mockResolvedValueOnce({
        data: {
          listOut: [],
          totCnt: 0,
        },
      })
    const { findByText } = render(component)
    const batRegBtn = await findByText(/SCRNITM#batReg/)
    fireEvent.click(batRegBtn)

    await waitFor(() => {
      expect(mockGrid.mockRefreshCells).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("validate Test", async () => {
    mockUseForm.mockGetValues.mockReturnValueOnce(1).mockReturnValueOnce(0)
    const { findByTestId } = render(component)
    const validateTestBtn = await within(
      await findByTestId(/SCRNITM#srchToDt/),
    ).findByTestId("validate")
    fireEvent.click(validateTestBtn, { target: { data: {} } })
  })
})
