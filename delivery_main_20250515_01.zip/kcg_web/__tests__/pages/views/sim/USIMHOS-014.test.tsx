import React from "react"
import {
  findByTestId,
  fireEvent,
  render,
  waitFor,
  within,
} from "@testing-library/react"

// USIMHOS014 컴포넌트를 불러옵니다.
import USIMHOS014 from "@/pages/views/sim/USIMHOS-014"
import { Component } from "@/hoc/TestUtil"

const component = Component(USIMHOS014)

describe("[USIMHOS-014] CMS시뮬데이터관리", () => {
  // default useEffect process
  beforeEach(() => {
    // first useEffect
    mockUseParams.mockReturnValue({
      params: undefined,
    })

    // second useEffect (do not need)

    // third useEffect
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        outList: [],
      },
    })
  })

  it.each([
    {
      trDt: "20250101",
      fileBizDvsnCd: "01",
    },
    {
      isDashboard: true,
    },
  ])("first useEffect Test", async (params) => {
    mockUseParams.mockRestore()
    mockUseParams.mockReturnValue({
      params: params,
    })

    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bizDvsnCd: "ift",
        iftListOut: undefined,
        totCnt: 0,
      },
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("second useEffect Test", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      if (key === "inqryTp") return "02"
      return key
    })
    render(component)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
    })
  })

  it("pagingHandling Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        bizDvsnCd: "ift",
        iftListOut: undefined,
        totCnt: 0,
      },
    })
    render(component)
    pagingHandling[0](null, 2)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("valueFormatter Test", async () => {
    const { findAllByText } = render(component)
    const valueFormatterTestBtn = (
      await findAllByText(/valueFormatter Test/)
    )[0]
    fireEvent.click(valueFormatterTestBtn, { target: { data: {} } })
  })

  it("onRowClicked Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        listOut: [],
      },
    })
    const { findAllByText } = render(component)
    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]
    fireEvent.click(onRowClickedTestBtn, { target: { data: {} } })

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("copyClick Test - list.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const copyClickBtn = await findByText(/SCRNITM#copy/)
    fireEvent.click(copyClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("copyClick Test - list.length > 0, confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce(["test"])
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        bizDvsnCd: "ift",
        iftListOut: undefined,
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const copyClickBtn = await findByText(/SCRNITM#copy/)
    fireEvent.click(copyClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("copyClick Test - list.length > 0, not confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce(["test"])
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)
    const { findByText } = render(component)
    const copyClickBtn = await findByText(/SCRNITM#copy/)
    fireEvent.click(copyClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("deleteClick Test - list.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const deleteClickBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(deleteClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("deleteClick Test - list.length > 0, confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce(["test"])
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        bizDvsnCd: "ift",
        iftListOut: undefined,
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const deleteClickBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(deleteClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("deleteClick Test - list.length > 0, not confirm", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce(["test"])
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)
    const { findByText } = render(component)
    const deleteClickBtn = await findByText(/SCRNITM#delete/)
    fireEvent.click(deleteClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("modifyClick Test - confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        bizDvsnCd: "ift",
        iftListOut: undefined,
        totCnt: 0,
      },
    })
    const { findByText } = render(component)
    const modifyClickBtn = await findByText(/SCRNITM#modify/)
    fireEvent.click(modifyClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("modifyClick Test - not confirm", async () => {
    mockUseModal.mockConfirm.mockResolvedValueOnce(false)
    const { findByText } = render(component)
    const modifyClickBtn = await findByText(/SCRNITM#modify/)
    fireEvent.click(modifyClickBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(1)
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
    })
  })

  it("xlsxClick Test", async () => {
    mockGrid.mockExportExcel.mockImplementationOnce((obj, fn) => {
      fn()
    })
    const { findByText } = render(component)
    const xlsxClickBtn = await findByText(/SCRNITM#excel/)

    fireEvent.click(xlsxClickBtn)
    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("validate Test", async () => {
    const { findAllByTestId } = render(component)

    const srchToDts = await findAllByTestId(/SCRNITM#srchToDt/)

    const validateBtn0 = await within(srchToDts[0]).findByTestId("validate")
    const validateBtn1 = await within(srchToDts[0]).findByTestId("validate")
    fireEvent.click(validateBtn0, { target: { data: "" } })
    fireEvent.click(validateBtn1, { target: { data: "" } })
  })
})
