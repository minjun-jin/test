package com.jpmc.kcg.web.hof.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mockStatic;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import com.jpmc.kcg.web.hof.dto.SelectListHofNetDebitCapDaoOut;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dto.ComRespCdM;
import com.jpmc.kcg.com.dto.PageableRequestList;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.NumberingEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.hof.biz.vo.KcgHof0200010000;
import com.jpmc.kcg.hof.biz.vo.KcgHof0210010000;
import com.jpmc.kcg.hof.biz.vo.KftHofLC0011R;
import com.jpmc.kcg.hof.dto.HofNetTrCapTlgM;
import com.jpmc.kcg.hof.dto.HofSndRcvFileL;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dao.HofNetTrCapTlgMWebDao;
import com.jpmc.kcg.web.hof.dao.HofSndRcvFileLWebDao;
import com.jpmc.kcg.web.hof.dto.GetListHofNetDebitLCRIn;
import com.jpmc.kcg.web.hof.dto.GetListHofNetDebitLCROut;
import com.jpmc.kcg.web.hof.service.dto.GetListHofNetDebitCapIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHofNetDebitCapOut;
import com.jpmc.kcg.web.hof.service.dto.SendNetDebitCapOut;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ExtendWith(MockitoExtension.class)
public class HofNetDebitCapInquirySvcTest {

	@Mock
	private FrwTemplate frwTemplate;

	@Mock
	private BizCom bizCom;

	@Mock
	private HofNetTrCapTlgMWebDao hofNetCapWebDao;

	@Mock
	private HofSndRcvFileLWebDao hofSndRcvFileLWebDao;

	@InjectMocks
	private HofNetDebitCapInquirySvc service;

	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}

	@Test
	void testSendHofNetDebitCapInquirySuccess() {
		KcgHof0210010000 outRes0210010000 = new KcgHof0210010000();
		outRes0210010000.setResponseCode("000");
		com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation targetOut = new com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation();
		List<com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation> targetOutList = new ArrayList<>();
		targetOutList.add(targetOut);
		outRes0210010000.setNetDebitCapInformationArray(targetOutList);
		when(bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01)).thenReturn("1232333");
		when(frwTemplate.sendAndReceive(eq(FrwDestination.KCG_HOF),                       // 정확한 Destination 값
				any(KcgHof0200010000.class),                      // KcgHof0200010000 타입 허용
				argThat(map -> map != null && map.containsKey("TRMNL_DVSN_CD")), // Map에 특정 키 포함 확인
				eq(KcgHof0210010000.class), any(Duration.class)                        // 결과 클래스 확인
		)).thenReturn(outRes0210010000);

		ComRespCdM respInfo = new ComRespCdM();
		when(bizCom.getRespCode(anyString(), anyString(), anyString())).thenReturn(respInfo);
		ComRespCdM respCdM = new ComRespCdM();
		respCdM.setRespCdNm("Success");
		//		when(bizCom.getRespCode(eq(ComConst.KFT), eq(BizDvsnCdEnum.HOF.getValue()), eq("0000")))
		//				.thenReturn(respCdM);

		SendNetDebitCapOut result = service.sendHofNetDebitCapInquiry();

		assertNotNull(result);
		log.info("================inputValue: {}", outRes0210010000);
		log.info("================result {}", "true");
	}

	@Test
	void testSendHofNetDebitCapInquiryFailure() {
		KcgHof0210010000 outRes0210010000 = new KcgHof0210010000();
		outRes0210010000.setResponseCode("000");
		com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation targetOut = new com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation();
		List<com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation> targetOutList = new ArrayList<>();
		targetOutList.add(targetOut);
		outRes0210010000.setNetDebitCapInformationArray(targetOutList);
		when(bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01)).thenReturn("1232333");
		when(frwTemplate.sendAndReceive(eq(FrwDestination.KCG_HOF),                       // 정확한 Destination 값
				any(KcgHof0200010000.class),                      // KcgHof0200010000 타입 허용
				argThat(map -> map != null && map.containsKey("TRMNL_DVSN_CD")), // Map에 특정 키 포함 확인
				eq(KcgHof0210010000.class)    , any(Duration.class)                    // 결과 클래스 확인
		)).thenReturn(null);

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			service.sendHofNetDebitCapInquiry();
		});

		assertEquals("MCMNE11004", exception.getErrorCode());
	}

	@Test
	void testSendHofNetDebitCapInquiryException() {
		KcgHof0210010000 outRes0210010000 = new KcgHof0210010000();
		outRes0210010000.setResponseCode("000");
		com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation targetOut = new com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation();
		List<com.jpmc.kcg.hof.biz.vo.KcgHof0210010000.NetDebitCapInformation> targetOutList = new ArrayList<>();
		targetOutList.add(targetOut);
		outRes0210010000.setNetDebitCapInformationArray(targetOutList);
		when(bizCom.getHofOracleSeqNo(NumberingEnum.HOFKFT01)).thenReturn("1232333");
		when(frwTemplate.sendAndReceive(eq(FrwDestination.KCG_HOF),                       // 정확한 Destination 값
				any(KcgHof0200010000.class),                      // KcgHof0200010000 타입 허용
				argThat(map -> map != null && map.containsKey("TRMNL_DVSN_CD")), // Map에 특정 키 포함 확인
				eq(KcgHof0210010000.class)  , any(Duration.class)                      // 결과 클래스 확인
		)).thenThrow(new RuntimeException("Test Exception"));

		BusinessException exception = assertThrows(BusinessException.class, () -> {
			service.sendHofNetDebitCapInquiry();
		});

		assertEquals("MCMNE11004", exception.getErrorCode());
		log.info("================inputValue: {}");
		log.info("================result {}", exception.getMessage());
	}

	@Test
	public void testGetListHofNetDebitCap() {
		// Given
		GetListHofNetDebitCapIn in = new GetListHofNetDebitCapIn();
		in.setTrStrDt("20240101");
		in.setTrEndDt("20241231");
		in.setInqryDvsnCd("01");
		in.setPgNbr(1);
		in.setPgCnt(10);

		// Mocked data for selectListHofHofNetDebitCapCnt
		when(hofNetCapWebDao.selectListHofHofNetDebitCapCnt(any())).thenReturn(1);

		// Mocked data for selectListHofHofNetDebitCap
		List<SelectListHofNetDebitCapDaoOut> mockedList = new ArrayList<>();
		SelectListHofNetDebitCapDaoOut mockData = new SelectListHofNetDebitCapDaoOut();
		mockData.setTrDt("20240101");
		mockData.setInqryDvsnCd("01");
		mockData.setNetDebitLmtAmt(new BigDecimal(100000));
		mockData.setRespCd("000");
		mockedList.add(mockData);
		
		ComRespCdM out = new ComRespCdM();
		
		when(bizCom.getRespCode(ComConst.HST, BizDvsnCdEnum.HOF.getValue(), mockData.getRespCd())).thenReturn(out);

		when(hofNetCapWebDao.selectListHofHofNetDebitCap(any(PageableRequestList.class)))
				.thenReturn(mockedList);

		// When
		GetListHofNetDebitCapOut result = service.getListHofNetDebitCap(in);

		// Then
		assertEquals(1, result.getTotCnt());
		assertEquals(1, result.getListOut().size());
		assertEquals("20240101", result.getListOut().get(0).getTrDt());

		log.info("================inputValue: {}", in);
		log.info("================result {}", "true");

	}

	@Test
	void testGetListHofNetDebitLCRSuccess() {
		// Given
		GetListHofNetDebitLCRIn in = new GetListHofNetDebitLCRIn();
		in.setInqrStrtDt("20240101");
		in.setInqrEndDt("20241231");

		// Mock the data for selectHofSndRcvFileLByDateAndFileName
		List<HofSndRcvFileL> hofSndRcvFileLS = new ArrayList<>();
		HofSndRcvFileL mockFile = new HofSndRcvFileL();
		mockFile.setTrDt("20240101");
		mockFile.setTlgCtt("mockedContent");
        mockFile.setDataTp("22");
		hofSndRcvFileLS.add(mockFile);

		when(hofSndRcvFileLWebDao.selectHofSndRcvFileLByDateAndFileName(eq("20240101"),
				eq("20241231"), eq("LC0011"))).thenReturn(hofSndRcvFileLS);

		// Mock for VOUtils.toVo method
		KftHofLC0011R kftHofLC0011R = new KftHofLC0011R();
		kftHofLC0011R.setFileName("mockedFileName");
		kftHofLC0011R.setInstitutionCode("mockedInstitutionCode");
		kftHofLC0011R.setRegisterTransferLimitAmount(500000);
		kftHofLC0011R.setRemainedAmountOfNetTransferLimit(200000);
		kftHofLC0011R.setSpentRate(4);
		try (MockedStatic<VOUtils> voUtils = mockStatic(VOUtils.class)) {
			voUtils.when(() -> VOUtils.toVo(any(String.class), eq(KftHofLC0011R.class)))
					.thenReturn(kftHofLC0011R);

			// When
			GetListHofNetDebitLCROut result = service.getListHofNetDebitLCR(in);

			// Then
			assertNotNull(result);
			assertEquals(1, result.getOutListLength());
			assertEquals("20240101", result.getOutList().get(0).getTrDt());
			assertEquals("mockedFileName", result.getOutList().get(0).getFileName());
			assertEquals("mockedInstitutionCode", result.getOutList().get(0).getBnkCd());
			assertEquals("500000", result.getOutList().get(0).getNetDebitLmtAmt());
			assertEquals("200000", result.getOutList().get(0).getDebitLmtBalAmt());
			assertEquals("4", result.getOutList().get(0).getDebitLmtUsageRt());
		}
	}

	@Test
	void testGetListHofNetDebitLCREmptyList() {
		// Given
		GetListHofNetDebitLCRIn in = new GetListHofNetDebitLCRIn();
		in.setInqrStrtDt("20240101");
		in.setInqrEndDt("20241231");

		when(hofSndRcvFileLWebDao.selectHofSndRcvFileLByDateAndFileName(eq("20240101"),
				eq("20241231"), eq("LC0011"))).thenReturn(new ArrayList<>());

		// When
		GetListHofNetDebitLCROut result = service.getListHofNetDebitLCR(in);

		// Then
		assertNotNull(result);
		assertEquals(0, result.getOutListLength());
		log.info("OutList Length: {}", result.getOutListLength());
	}

	@Test
	void testGetListHofNetDebitLCRInvalidInput() {
		// Given
		GetListHofNetDebitLCRIn in = new GetListHofNetDebitLCRIn();
		// intentionally leaving fields empty to test validation failure

		// Expect BusinessException due to missing required fields
		BusinessException exception = assertThrows(BusinessException.class, () -> {
			service.getListHofNetDebitLCR(in);
		});

		assertEquals("MCMNE01002", exception.getErrorCode());
		log.info("Error Code: {}", exception.getErrorCode());
	}
}
