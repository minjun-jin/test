package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자동납부 등록정보 신규/해지 오류내역(AT1112 처리 결과)
 * <pre>{@code
 * KftCmsAT2112T kftCmsAT2112T  = new KftCmsAT2112T(); // 자동납부 등록정보 신규/해지 오류내역(AT1112 처리 결과)
 * kftCmsAT2112T.setFileName("AT2112"); // 업무구분
 * kftCmsAT2112T.setDataType("33"); // 데이터구분
 * kftCmsAT2112T.setSerialNumber("9999999"); // 일련번호
 * kftCmsAT2112T.setInstitutionCode("057"); // 기관코드
 * kftCmsAT2112T.setTotalDataRecordCount(0); // 총DATA RECORD 수
 * kftCmsAT2112T.setTotalReceiveCount(0); // 총수신건수합계
 * kftCmsAT2112T.setSuccessCount(0); // 정상처리건수합계
 * kftCmsAT2112T.setErrorCount(0); // 오류레코드건수합계
 * kftCmsAT2112T.setFiller4(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsAT2112T implements Vo {

	private String fileName = "AT2112"; // 업무구분
	private String dataType = "33"; // 데이터구분
	private String serialNumber = "9999999"; // 일련번호
	private String institutionCode = "057"; // 기관코드
	private int totalDataRecordCount; // 총DATA RECORD 수
	private int totalReceiveCount; // 총수신건수합계
	private int successCount; // 정상처리건수합계
	private int errorCount; // 오류레코드건수합계
	private String filler4; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalReceiveCount$; // 총수신건수합계
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String successCount$; // 정상처리건수합계
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String errorCount$; // 오류레코드건수합계
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler4$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 7); // 총DATA RECORD 수
		totalReceiveCount$ = VOUtils.write(out, totalReceiveCount, 7); // 총수신건수합계
		successCount$ = VOUtils.write(out, successCount, 7); // 정상처리건수합계
		errorCount$ = VOUtils.write(out, errorCount, 7); // 오류레코드건수합계
		filler4$ = VOUtils.write(out, filler4, 354); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 7)); // 총DATA RECORD 수
		totalReceiveCount = VOUtils.toInt(totalReceiveCount$ = VOUtils.read(in, 7)); // 총수신건수합계
		successCount = VOUtils.toInt(successCount$ = VOUtils.read(in, 7)); // 정상처리건수합계
		errorCount = VOUtils.toInt(errorCount$ = VOUtils.read(in, 7)); // 오류레코드건수합계
		filler4 = VOUtils.toString(filler4$ = VOUtils.read(in, 354)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총DATA RECORD 수
		sb.append(", totalReceiveCount=").append(totalReceiveCount).append(System.lineSeparator()); // 총수신건수합계
		sb.append(", successCount=").append(successCount).append(System.lineSeparator()); // 정상처리건수합계
		sb.append(", errorCount=").append(errorCount).append(System.lineSeparator()); // 오류레코드건수합계
		sb.append(", filler4=").append(filler4).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", "AT2112"),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", "33"),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", "9999999"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "totalDataRecordCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "totalReceiveCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "successCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "errorCount", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "filler4", "fldLen", "354", "defltVal", "")
		);
	}

}
