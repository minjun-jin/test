package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금음공동망 월간 은행별 거래집계현황
 * <pre>{@code
 * KftHofEL1111R kftHofEL1111R  = new KftHofEL1111R(); // 전자금음공동망 월간 은행별 거래집계현황
 * kftHofEL1111R.setFileName(""); // 업무구분
 * kftHofEL1111R.setDataType(""); // 데이타구분
 * kftHofEL1111R.setSerialNumber(""); // 일련번호
 * kftHofEL1111R.setTransactionCode(""); // 거래구분코드
 * kftHofEL1111R.setBnkCd(""); // 은행코드
 * kftHofEL1111R.setDebitPendingTransactionCount(0L); // 대변미완료거래건수
 * kftHofEL1111R.setCreditCancelTransactionCount(0L); // 차변취소거래건수
 * kftHofEL1111R.setCreditTransactionCount(0L); // 차변거래건수
 * kftHofEL1111R.setDebitTransactionCount(0L); // 대변거래건수
 * kftHofEL1111R.setDebitCancelTransactionCount(0L); // 대변취소거래건수
 * kftHofEL1111R.setDebitPendingTransactionAmount(0L); // 대변미완료거래금액
 * kftHofEL1111R.setCreditCancelTransactionAmount(0L); // 차변취소거래금액
 * kftHofEL1111R.setCreditTransactionAmount(0L); // 차변거래금액
 * kftHofEL1111R.setDebitTransactionAmount(0L); // 대변거래금액
 * kftHofEL1111R.setDebitCancelTransactionAmount(0L); // 대변취소거래금액
 * kftHofEL1111R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL1111R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String transactionCode; // 거래구분코드
	private String bnkCd; // 은행코드
	private long debitPendingTransactionCount; // 대변미완료거래건수
	private long creditCancelTransactionCount; // 차변취소거래건수
	private long creditTransactionCount; // 차변거래건수
	private long debitTransactionCount; // 대변거래건수
	private long debitCancelTransactionCount; // 대변취소거래건수
	private long debitPendingTransactionAmount; // 대변미완료거래금액
	private long creditCancelTransactionAmount; // 차변취소거래금액
	private long creditTransactionAmount; // 차변거래금액
	private long debitTransactionAmount; // 대변거래금액
	private long debitCancelTransactionAmount; // 대변취소거래금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitPendingTransactionCount$; // 대변미완료거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelTransactionCount$; // 차변취소거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionCount$; // 차변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionCount$; // 대변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelTransactionCount$; // 대변취소거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitPendingTransactionAmount$; // 대변미완료거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelTransactionAmount$; // 차변취소거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionAmount$; // 차변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionAmount$; // 대변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelTransactionAmount$; // 대변취소거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		debitPendingTransactionCount$ = VOUtils.write(out, debitPendingTransactionCount, 10); // 대변미완료거래건수
		creditCancelTransactionCount$ = VOUtils.write(out, creditCancelTransactionCount, 10); // 차변취소거래건수
		creditTransactionCount$ = VOUtils.write(out, creditTransactionCount, 10); // 차변거래건수
		debitTransactionCount$ = VOUtils.write(out, debitTransactionCount, 10); // 대변거래건수
		debitCancelTransactionCount$ = VOUtils.write(out, debitCancelTransactionCount, 10); // 대변취소거래건수
		debitPendingTransactionAmount$ = VOUtils.write(out, debitPendingTransactionAmount, 16); // 대변미완료거래금액
		creditCancelTransactionAmount$ = VOUtils.write(out, creditCancelTransactionAmount, 16); // 차변취소거래금액
		creditTransactionAmount$ = VOUtils.write(out, creditTransactionAmount, 16); // 차변거래금액
		debitTransactionAmount$ = VOUtils.write(out, debitTransactionAmount, 16); // 대변거래금액
		debitCancelTransactionAmount$ = VOUtils.write(out, debitCancelTransactionAmount, 16); // 대변취소거래금액
		filler$ = VOUtils.write(out, filler, 26); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		debitPendingTransactionCount = VOUtils.toLong(debitPendingTransactionCount$ = VOUtils.read(in, 10)); // 대변미완료거래건수
		creditCancelTransactionCount = VOUtils.toLong(creditCancelTransactionCount$ = VOUtils.read(in, 10)); // 차변취소거래건수
		creditTransactionCount = VOUtils.toLong(creditTransactionCount$ = VOUtils.read(in, 10)); // 차변거래건수
		debitTransactionCount = VOUtils.toLong(debitTransactionCount$ = VOUtils.read(in, 10)); // 대변거래건수
		debitCancelTransactionCount = VOUtils.toLong(debitCancelTransactionCount$ = VOUtils.read(in, 10)); // 대변취소거래건수
		debitPendingTransactionAmount = VOUtils.toLong(debitPendingTransactionAmount$ = VOUtils.read(in, 16)); // 대변미완료거래금액
		creditCancelTransactionAmount = VOUtils.toLong(creditCancelTransactionAmount$ = VOUtils.read(in, 16)); // 차변취소거래금액
		creditTransactionAmount = VOUtils.toLong(creditTransactionAmount$ = VOUtils.read(in, 16)); // 차변거래금액
		debitTransactionAmount = VOUtils.toLong(debitTransactionAmount$ = VOUtils.read(in, 16)); // 대변거래금액
		debitCancelTransactionAmount = VOUtils.toLong(debitCancelTransactionAmount$ = VOUtils.read(in, 16)); // 대변취소거래금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 26)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", debitPendingTransactionCount=").append(debitPendingTransactionCount).append(System.lineSeparator()); // 대변미완료거래건수
		sb.append(", creditCancelTransactionCount=").append(creditCancelTransactionCount).append(System.lineSeparator()); // 차변취소거래건수
		sb.append(", creditTransactionCount=").append(creditTransactionCount).append(System.lineSeparator()); // 차변거래건수
		sb.append(", debitTransactionCount=").append(debitTransactionCount).append(System.lineSeparator()); // 대변거래건수
		sb.append(", debitCancelTransactionCount=").append(debitCancelTransactionCount).append(System.lineSeparator()); // 대변취소거래건수
		sb.append(", debitPendingTransactionAmount=").append(debitPendingTransactionAmount).append(System.lineSeparator()); // 대변미완료거래금액
		sb.append(", creditCancelTransactionAmount=").append(creditCancelTransactionAmount).append(System.lineSeparator()); // 차변취소거래금액
		sb.append(", creditTransactionAmount=").append(creditTransactionAmount).append(System.lineSeparator()); // 차변거래금액
		sb.append(", debitTransactionAmount=").append(debitTransactionAmount).append(System.lineSeparator()); // 대변거래금액
		sb.append(", debitCancelTransactionAmount=").append(debitCancelTransactionAmount).append(System.lineSeparator()); // 대변취소거래금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "debitPendingTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditCancelTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitCancelTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitPendingTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditCancelTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitCancelTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "26", "defltVal", "")
		);
	}

}
