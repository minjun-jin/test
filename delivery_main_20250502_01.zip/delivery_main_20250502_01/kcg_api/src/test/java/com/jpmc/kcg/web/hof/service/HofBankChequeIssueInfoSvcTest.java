package com.jpmc.kcg.web.hof.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyBoolean;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;

import com.jpmc.kcg.com.dao.ComChequeInfoMgmtMMapper;
import com.jpmc.kcg.com.dao.ComMltlnMMapper;
import com.jpmc.kcg.com.dto.ComChequeInfoMgmtM;
import com.jpmc.kcg.com.dto.PageableRequestList;
import com.jpmc.kcg.com.enums.ChequeIssueStsCdEnum;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.web.WebContextImpl;
import com.jpmc.kcg.web.com.dao.ComChequeInfoMgmtMWebDao;
import com.jpmc.kcg.web.com.dao.ComMltlnDao;
import com.jpmc.kcg.web.com.dto.MltlnIn;
import com.jpmc.kcg.web.com.dto.MltlnOut;
import com.jpmc.kcg.web.com.service.CommonApprovalSvc;
import com.jpmc.kcg.web.com.service.dto.IntegratedSummaryIn;
import com.jpmc.kcg.web.frw.dto.Header;
import com.jpmc.kcg.web.hof.dto.SelectChequeReportOut;
import com.jpmc.kcg.web.hof.service.dto.GetHofMaxChequeNoIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHofBankChequeIssueInfoIn;
import com.jpmc.kcg.web.hof.service.dto.GetListHofBankChequeIssueInfoOut;
import com.jpmc.kcg.web.hof.service.dto.HofBankChequeIssueInfoIn;
import com.jpmc.kcg.web.utils.JwtUtils;

import lombok.extern.slf4j.Slf4j;


@ExtendWith(MockitoExtension.class)
@Slf4j
class HofBankChequeIssueInfoSvcTest {

    @Mock
    private ComChequeInfoMgmtMWebDao comChequeInfoMgmtMWebDao;

    @Mock
    private ComChequeInfoMgmtMMapper comChequeInfoMgmtMMapper;

    @Mock
    private CommonApprovalSvc commonApprovalSvc;
    
    @Mock
    private ComMltlnMMapper comMltlnMMapper;
    
    @Mock
    private ComMltlnDao comMltlnDao;

    @InjectMocks
    private HofBankChequeIssueInfoSvc hofBankChequeIssueInfoSvc;
    
    @Mock
    private JwtUtils jwtUtils;

	@BeforeAll
	static void setup() {
		WebContextImpl webContextImpl = new WebContextImpl();
		Header header = new Header();
		header.setLngCd("en");
		header.setStaffId("JUNIT");
		header.setRoles(List.of(""));
		webContextImpl.setHeader(header);

		FrwContextHolder.setContext(webContextImpl);
	}

    @Test
    void testGetListHofBankChequeIssueInfo_Success() {
        GetListHofBankChequeIssueInfoIn getListHofBankChequeIssueInfoIn = new GetListHofBankChequeIssueInfoIn();
        getListHofBankChequeIssueInfoIn.setChequeTp("1");

        ComChequeInfoMgmtM comChequeInfoMgmtM = new ComChequeInfoMgmtM();
        comChequeInfoMgmtM.setChequeTp("1");
        
        when(jwtUtils.hasAnyRole(anyString(), anyString(), anyString())).thenReturn(true);
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(PageableRequestList.class), anyBoolean())).thenReturn(Collections.singletonList(comChequeInfoMgmtM));

        GetListHofBankChequeIssueInfoOut result = hofBankChequeIssueInfoSvc.getListHofBankChequeIssueInfo(getListHofBankChequeIssueInfoIn);

        List<ComChequeInfoMgmtM> list = result.getComChequeInfoMgmtM();
        assertEquals("1", list.get(0).getChequeTp());

        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(PageableRequestList.class), anyBoolean());
        verify(jwtUtils, times(1)).hasAnyRole(anyString(), anyString(), anyString());
    }
    
    @Test
    void testGetListHofBankChequeIssueInfo_fail_ChequeTp() {
    	
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("");

        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	hofBankChequeIssueInfoSvc.getListHofBankChequeIssueInfo(in);
        });

        assertEquals("MCMNE01002", exception.getErrorCode());

    }
    
    @Test
    void testCreateHofBankChequeIssueInfo_Success() {
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNoFrom("0000001");
        in.setChequeNoTo("0000004");
        in.setCheckNolength(6);

        hofBankChequeIssueInfoSvc.createHofBankChequeIssueInfo(in);

        verify(comChequeInfoMgmtMMapper, times(4)).insert(any(ComChequeInfoMgmtM.class));
        verify(commonApprovalSvc, times(4)).requestApproval(any(), any(), any());
    }
    
    @Test
    void testCreateHofBankChequeIssueInfo_fail_ChequeNo() {
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNo("");

        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	hofBankChequeIssueInfoSvc.createHofBankChequeIssueInfo(in);

        });

        assertEquals("MCMNE01002", exception.getErrorCode());

        verify(jwtUtils, times(0)).hasAnyRole(anyString(), anyString(), anyString());
    }
    
    @Test
    void testCreateHofBankChequeIssueInfo_fail_ChequeTp() {
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("");
        in.setChequeNo("00000000");

        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	hofBankChequeIssueInfoSvc.createHofBankChequeIssueInfo(in);

        });

        assertEquals("MCMNE01002", exception.getErrorCode());

        verify(jwtUtils, times(0)).hasAnyRole(anyString(), anyString(), anyString());
    }
    
    @Test
    void testCreateHofBankChequeIssueInfo_fail_Duplicate() {
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNoFrom("0000001");
        in.setChequeNoTo("0000004");
    	
        ComChequeInfoMgmtM comChequeInfoMgmtM = new ComChequeInfoMgmtM();
        comChequeInfoMgmtM.setChequeTp("1");
        comChequeInfoMgmtM.setChequeNo("0000000");
    	
    	when(comChequeInfoMgmtMMapper.selectByPrimaryKey(anyString(), anyString(), anyString())).thenReturn(comChequeInfoMgmtM);
    	
    	BusinessException exception = assertThrows(BusinessException.class, () -> {
    		hofBankChequeIssueInfoSvc.createHofBankChequeIssueInfo(in);
    	});
    	
    	assertEquals("MCMNE01003", exception.getErrorCode());
    	
    }
    
    @Test
    void testChangeHofBankChequeIssueInfo_Success() {
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNoFrom("0000001");
        in.setChequeNoTo("0000004");
        in.setUpdateCheckTinvSoldYn(true);
        in.setChequeIssueStsCd("01");
        in.setTinvDt("20240905");
        in.setInvenDt("20240904");

        ComChequeInfoMgmtM comChequeInfoMgmtM = new ComChequeInfoMgmtM();
        comChequeInfoMgmtM.setChequeTp("1");
        comChequeInfoMgmtM.setChequeNo("0000000");
        comChequeInfoMgmtM.setChequeIssueStsCd("01");
        comChequeInfoMgmtM.setInvenDt("20240904");
        comChequeInfoMgmtM.setSoldDt("20240905");

        when(comChequeInfoMgmtMWebDao.selectChequeInfo(any())).thenReturn(comChequeInfoMgmtM);

        hofBankChequeIssueInfoSvc.changeHofBankChequeIssueInfo(in);
        
        verify(comChequeInfoMgmtMWebDao, times(4)).updateComChequeInfoMgmtM(any(HofBankChequeIssueInfoIn.class));
    }

    @Test
    void testChangeHofBankChequeIssueInfo_fail_NotFound() {
    	
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNo("0000000");
        
        BusinessException exception = assertThrows(BusinessException.class, () -> {
        	hofBankChequeIssueInfoSvc.changeHofBankChequeIssueInfo(in);
        });

        assertEquals("MCMNE01004", exception.getErrorCode());

    }
    
    
    @Test
    void testRemoveHofBankChequeIssueInfo_Success() {
    	
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNo("0000000");

        ComChequeInfoMgmtM comChequeInfoMgmtM = new ComChequeInfoMgmtM();
        comChequeInfoMgmtM.setChequeTp("1");
        comChequeInfoMgmtM.setChequeNo("0000000");
        
        when(comChequeInfoMgmtMWebDao.selectChequeInfo(any())).thenReturn(comChequeInfoMgmtM);

        hofBankChequeIssueInfoSvc.removeHofBankChequeIssueInfo(in);

    }

    @Test
    void testRemoveHofBankChequeIssueInfo_fail_ChequeNo() {
    	
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNo("");

        BusinessException exception = assertThrows(BusinessException.class, () -> {
            hofBankChequeIssueInfoSvc.removeHofBankChequeIssueInfo(in);
        });

        assertEquals("MCMNE01002", exception.getErrorCode());

        verify(comChequeInfoMgmtMMapper, times(0)).selectByPrimaryKey(anyString(), anyString(), anyString());
    }
    
    @Test
    void testRemoveHofBankChequeIssueInfo_fail_ChequeTp() {
    	
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("");
        in.setChequeNo("000000");

        BusinessException exception = assertThrows(BusinessException.class, () -> {
            hofBankChequeIssueInfoSvc.removeHofBankChequeIssueInfo(in);
        });

        assertEquals("MCMNE01002", exception.getErrorCode());

    }

    @Test
    void testRemoveHofBankChequeIssueInfo_fail_NotFound() {
    	
    	HofBankChequeIssueInfoIn in = new HofBankChequeIssueInfoIn();
        in.setChequeTp("1");
        in.setChequeNo("0000000");
    	
        BusinessException exception = assertThrows(BusinessException.class, () -> {
            hofBankChequeIssueInfoSvc.removeHofBankChequeIssueInfo(in);
        });

        assertEquals("MCMNE01005", exception.getErrorCode());

    }
    
    @Test
    void testGetMaxChequeNo_fail_ChequeTp() {

        GetHofMaxChequeNoIn in = new GetHofMaxChequeNoIn();

        BusinessException exception = assertThrows(BusinessException.class, () -> {
    		hofBankChequeIssueInfoSvc.getMaxChequeNo(in);
    	});
    	
    	assertEquals("MCMNE01002", exception.getErrorCode());
    	
    }
    
    @Test
    void testGetMaxChequeNo_success() {
    	String chequeTp = "1";
    	GetHofMaxChequeNoIn in = new GetHofMaxChequeNoIn();
    	in.setChequeTp(chequeTp);
    	when(comChequeInfoMgmtMWebDao.selectMaxChequeNo(in)).thenReturn("000001");
    	
    	hofBankChequeIssueInfoSvc.getMaxChequeNo(in);
    	
    	verify(comChequeInfoMgmtMWebDao, times(1)).selectMaxChequeNo(in);
    	
    }
    
    

    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_Success_MGK() throws Exception {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("1");

        List<ComChequeInfoMgmtM> mockedList = new ArrayList<>();
        // Mocked data 추가
        ComChequeInfoMgmtM mockItem = new ComChequeInfoMgmtM();
        mockItem.setChequeNo("0000000");
        mockItem.setChequeTp("1");
        mockItem.setChequeAmt(BigDecimal.TEN);
        mockedList.add(mockItem);

        MockHttpServletResponse response = new MockHttpServletResponse();

        List<MltlnOut> mltlnOut = new ArrayList<>();
        // 올바른 Mockito 설정: 모든 인자를 매처로 처리
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(), anyBoolean())).thenReturn(mockedList);
        when(comChequeInfoMgmtMWebDao.selectListChequeInfoCnt(any(), anyBoolean())).thenReturn(1);
        when( comMltlnDao.selectMltlnCdList(any(MltlnIn.class))).thenReturn(mltlnOut);

        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoExcel(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0); 
        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(), anyBoolean());
    }

    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_Success_Collection() throws Exception {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("2");

        List<ComChequeInfoMgmtM> mockedList = new ArrayList<>();
        // Mocked data 추가
        ComChequeInfoMgmtM mockItem = new ComChequeInfoMgmtM();
        mockItem.setChequeNo("0000000");
        mockItem.setChequeTp("2");
        mockItem.setChequeAmt(BigDecimal.TEN);
        mockedList.add(mockItem);

        MockHttpServletResponse response = new MockHttpServletResponse();


        List<MltlnOut> mltlnOut = new ArrayList<>();

        // 올바른 Mockito 설정: 모든 인자를 매처로 처리
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(), anyBoolean())).thenReturn(mockedList);
        when(comChequeInfoMgmtMWebDao.selectListChequeInfoCnt(any(), anyBoolean())).thenReturn(1);
        when( comMltlnDao.selectMltlnCdList(any(MltlnIn.class))).thenReturn(mltlnOut);

        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoExcel(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0);
        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(), anyBoolean());
    }
    
    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_Success_Corporate() throws Exception {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("3");

        List<ComChequeInfoMgmtM> mockedList = new ArrayList<>();
        // Mocked data 추가
        ComChequeInfoMgmtM mockItem = new ComChequeInfoMgmtM();
        mockItem.setChequeNo("0000000");
        mockItem.setChequeTp("3");
        mockItem.setRtnAmt(BigDecimal.TEN);
        mockedList.add(mockItem);

        MockHttpServletResponse response = new MockHttpServletResponse();


        // 올바른 Mockito 설정: 모든 인자를 매처로 처리
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(), anyBoolean())).thenReturn(mockedList);
        when(comChequeInfoMgmtMWebDao.selectListChequeInfoCnt(any(), anyBoolean())).thenReturn(1);

        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoExcel(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0);
        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(), anyBoolean());
    }
    
    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_Success_Woori() throws Exception {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("4");

        List<ComChequeInfoMgmtM> mockedList = new ArrayList<>();
        // Mocked data 추가
        ComChequeInfoMgmtM mockItem = new ComChequeInfoMgmtM();
        mockItem.setChequeNo("0000000");
        mockItem.setChequeTp("4");
        mockItem.setChequeAmt(BigDecimal.TEN);
        mockedList.add(mockItem);

        MockHttpServletResponse response = new MockHttpServletResponse();


        // 올바른 Mockito 설정: 모든 인자를 매처로 처리
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(), anyBoolean())).thenReturn(mockedList);
        when(comChequeInfoMgmtMWebDao.selectListChequeInfoCnt(any(), anyBoolean())).thenReturn(1);

        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoExcel(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0);
        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(), anyBoolean());
    }
    
    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_Success_CDTD() throws Exception {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("5");

        List<ComChequeInfoMgmtM> mockedList = new ArrayList<>();
        // Mocked data 추가
        ComChequeInfoMgmtM mockItem = new ComChequeInfoMgmtM();
        mockItem.setChequeNo("0000000");
        mockItem.setChequeTp("5");
        mockItem.setChequeAmt(BigDecimal.TEN);
        mockedList.add(mockItem);

        MockHttpServletResponse response = new MockHttpServletResponse();

        // 올바른 Mockito 설정: 모든 인자를 매처로 처리
        when(comChequeInfoMgmtMWebDao.selectListComChequeInfoMgmtM(any(), anyBoolean())).thenReturn(mockedList);
        when(comChequeInfoMgmtMWebDao.selectListChequeInfoCnt(any(), anyBoolean())).thenReturn(1);

        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoExcel(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0);
        verify(comChequeInfoMgmtMWebDao, times(1)).selectListComChequeInfoMgmtM(any(), anyBoolean());
    }
    
    
    @Test
    public void testDownloadHofBankChequeIssueInfoExcel_FileNotFoundException() {
        // Given
        GetListHofBankChequeIssueInfoIn in = new GetListHofBankChequeIssueInfoIn();
        in.setChequeTp("ss");
        MockHttpServletResponse response = new MockHttpServletResponse();

        // 스파이 객체 생성
        HofBankChequeIssueInfoSvc spySvc = spy(hofBankChequeIssueInfoSvc);

        // When & Then
        Exception exception = assertThrows(Exception.class, () -> {
            spySvc.downloadHofBankChequeIssueInfoExcel(in, response);
        });

        // 메시지가 기대한 내용을 포함하는지 확인
        assertEquals("MCMNE05011", exception.getMessage());
    }
    
    @Test
    public void testdownloadHofBankChequeIssueInfoReport_Success_CD() throws Exception {
        // Given
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
        in.setReportId("5");
        in.setSrchDate("20240924");
        
        MockHttpServletResponse response = new MockHttpServletResponse();
        
        // When
        hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);

        // Then
        assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
        assertTrue(response.getContentAsByteArray().length > 0);
    }
    
    @Test
    public void testdownloadHofBankChequeIssueInfoReport_Success_TD() throws Exception {
    	// Given
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
    	in.setReportId("6");
    	in.setSrchDate("20240924");
    	
    	MockHttpServletResponse response = new MockHttpServletResponse();
    	
    	// When
    	hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);
    	
    	// Then
    	assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
    	assertTrue(response.getContentAsByteArray().length > 0);
    }
    
    @Test
    public void testdownloadHofBankChequeIssueInfoReport_Success_MGK() throws Exception {
    	// Given
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
    	in.setReportId("1");
    	in.setSrchDate("20240924");
    	
    	MockHttpServletResponse response = new MockHttpServletResponse();
    	
    	// When
    	hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);
    	
    	// Then
    	assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
    	assertTrue(response.getContentAsByteArray().length > 0);
    }
    
//    @Test
//    public void testdownloadHofBankChequeIssueInfoReport_Success_Corporate() throws Exception {
//    	// Given
//    	IntegratedSummaryIn in = new IntegratedSummaryIn();
//    	in.setReportId("3");
//    	in.setSrchDate("20240924");
//
//    	MockHttpServletResponse response = new MockHttpServletResponse();
//
//    	List<SelectChequeReportOut> mockedList = new ArrayList<>();
//	      // Mocked data 추가
//		SelectChequeReportOut mockItem = new SelectChequeReportOut();
//	    mockItem.setKbn(ChequeIssueStsCdEnum.INVENTORY.getValue());
//	    mockItem.setChequeNo("0000000");
//	    mockItem.setChequeNo2("0000001");
//	    mockItem.setCnt("1");
//	    mockItem.setAmt("1");
//	    mockedList.add(mockItem);
//
//	    mockItem = new SelectChequeReportOut();
//	    mockItem.setKbn(ChequeIssueStsCdEnum.CHECK_BOOK_SOLD.getValue());
//	    mockItem.setChequeNo("0000000");
//	    mockItem.setChequeNo2("0000001");
//	    mockItem.setCnt("1");
//	    mockItem.setAmt("1");
//	    mockedList.add(mockItem);
//
//	    mockItem = new SelectChequeReportOut();
//	    mockItem.setKbn(ChequeIssueStsCdEnum.CHECK_RETURNED.getValue());
//	    mockItem.setChequeNo("0000000");
//	    mockItem.setChequeNo2("0000001");
//	    mockItem.setCnt("1");
//	    mockItem.setAmt("1");
//	    mockedList.add(mockItem);
//
//	    mockItem = new SelectChequeReportOut();
//	    mockItem.setKbn(ChequeIssueStsCdEnum.CHECK_CANCELLED.getValue());
//	    mockItem.setChequeNo("0000000");
//	    mockItem.setChequeNo2("0000001");
//	    mockItem.setCnt("1");
//	    mockItem.setAmt("1");
//	    mockedList.add(mockItem);
//
//	    // 올바른 Mockito 설정: 모든 인자를 매처로 처리
//	    when(comChequeInfoMgmtMWebDao.getReportListCorporate(any())).thenReturn(mockedList);
//
//    	// When
//    	hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);
//
//    	// Then
//    	assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
//    	assertTrue(response.getContentAsByteArray().length > 0);
//    }
    
    @Test
    public void testdownloadHofBankChequeIssueInfoReport_Success_Woori() throws Exception {
    	// Given
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
    	in.setReportId("4");
    	in.setSrchDate("20240924");
    	
    	MockHttpServletResponse response = new MockHttpServletResponse();
    	
    	// When
    	hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);
    	
    	// Then
    	assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
    	assertTrue(response.getContentAsByteArray().length > 0);
    }
    
    @Test
    public void testdownloadHofBankChequeIssueInfoReport_Success_MGK_Woori() throws Exception {
    	// Given
    	IntegratedSummaryIn in = new IntegratedSummaryIn();
    	in.setReportId("1_4");
    	in.setSrchDate("20240924");
    	
    	MockHttpServletResponse response = new MockHttpServletResponse();
    	
    	// When
    	hofBankChequeIssueInfoSvc.downloadHofBankChequeIssueInfoReport(in, response);
    	
    	// Then
    	assertEquals(MediaType.APPLICATION_OCTET_STREAM_VALUE, response.getContentType());
    	assertTrue(response.getContentAsByteArray().length > 0);
    }
    
//  @Test
//  public void testdownloadHofBankChequeIssueInfoReport_FileNotFoundException() {
//      // Given
//	  IntegratedSummaryIn in = new IntegratedSummaryIn();
//	  in.setReportId("10_40");
//      MockHttpServletResponse response = new MockHttpServletResponse();
//
//      // 스파이 객체 생성
//      HofBankChequeIssueInfoSvc spySvc = spy(hofBankChequeIssueInfoSvc);
//
//      // When & Then
//      Exception exception = assertThrows(Exception.class, () -> {
//          spySvc.downloadHofBankChequeIssueInfoReport(in, response);
//      });
//
//      // 메시지가 기대한 내용을 포함하는지 확인
//      assertTrue("MCMNE05011".contains(exception.getMessage()));
//  }
  
}
