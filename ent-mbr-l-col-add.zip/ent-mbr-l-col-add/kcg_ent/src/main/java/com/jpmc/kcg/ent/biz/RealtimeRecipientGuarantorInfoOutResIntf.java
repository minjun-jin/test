package com.jpmc.kcg.ent.biz;

import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0210221000;
import com.jpmc.kcg.ent.biz.vo.KftEnt0210221000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dao.EntMbrLDao;
import com.jpmc.kcg.ent.dto.EntMbrL;
import com.jpmc.kcg.ent.enums.EntRespCdEnum;
import com.jpmc.kcg.ent.enums.EntTlgKndDvsnCdEnum;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class RealtimeRecipientGuarantorInfoOutResIntf extends FrwServiceBean<KftEnt0210221000> {
    private final FrwTemplate frwTemplate;
    private final FrwContext frwContext;
    private final EntCom entCom;
    private final EntMbrLDao entMbrLDao;
    private final ConversionService conversionService;

    @Override
    public boolean control(KftEnt0210221000 in) {

        log.debug("----------------- KftEnt0210221000: {} -----------------", in);

        /*
         * 원거래내역 조회
         */
        EntMbrL originTrax = entCom.getOriginTraxEntMbrL(in.getMessageTrackingNumber(), in.getTransactionIdNumber());

        log.debug("----------------- originTrax EntMbrL -----------------: {}", originTrax);

        /*
         * 당발 보낸 전문이 format error return 인 경우
         * - 원거래 조회전문거래내역 수정
         * - host 에러 응답 전문 전송
         * - return false
         */
        if (EntTlgKndDvsnCdEnum.isFormatErrorResponseCode(in.getMessageType())) {

            if (originTrax != null) {

                originTrax.setEntTlgKndDvsnCd(in.getMessageType());            // 전문종별코드
                originTrax.setEntTlgTrDvsnCd(in.getTransactionCode());        // 거래구분코드
                originTrax.setEntTlgTrceNo(in.getMessageTrackingNumber());
                originTrax.setRespCd1(in.getResponseCode1());
                originTrax.setRespCd2(in.getResponseCode2());
                originTrax.setTrSts(in.getStatus());
                originTrax.setSndRcvDvsnCd(EntConst.RCV_FLAG);
                originTrax.setHostNo(frwContext.getHostMsgNo());

                log.debug("----------------- update origin EntSttlMgmtL -----------------: {}", originTrax);

                entMbrLDao.updateOriginalTransaction(originTrax);

                /*
                 * Cqe 전문 생성
                 * KftEnt0210221000CqeEnt0210221000
                 */
                CqeEnt0210221000 sendVo = conversionService.convert(in, CqeEnt0210221000.class);
                sendVo.setMsgType("KCGCQE");
                sendVo.setMsgNo(originTrax.getHostNo());    // 원거래의 hostNo

                /*
                 * KCG -> CQE 전송 : 결과보고 응답
                 */
                log.debug("----------------- CqeEnt0210221000 -----------------: {}", sendVo);
                frwTemplate.send(FrwDestination.CQE_ENT, sendVo);

            }

            return false;
        }

        // 원거래없음 에러 -> status = 거래고유번호의 위치 set(asis : respCd2 = " 099")
        if (originTrax == null) {
            throw new InternalResponseException(EntRespCdEnum.INPUT_MESSAGE_FORMAT_ERROR.getCode(), "007");
        }

        /*
         * 이중응답 check
         * 원거래.전문종별구분코드 = 0210 and 원거래.응답코드 != null -> 무시
         */
        if (StringUtils.equals(EntTlgKndDvsnCdEnum.RESPONSE.getCode(), originTrax.getEntTlgKndDvsnCd())
                && StringUtils.isNotEmpty(originTrax.getRespCd1())) {
            return false;
        }

        /*
         * 입력값 검증
         */
        entCom.nullCheckKftInput(in);

        /*
         * 공통 전문 필드 검증
         */
        entCom.validateReceivingHeader(in);

        return super.control(in);
    }

    @Override
    public void process(KftEnt0210221000 in) {

        /*
         * 원거래내역 조회
         */
        EntMbrL originTrax = entCom.getOriginTraxEntMbrL(in.getMessageTrackingNumber(), in.getTransactionIdNumber());

        /*
         * 내역 Update
         */
        originTrax.setEntTlgKndDvsnCd(in.getMessageType());            // 전문종별코드
        originTrax.setEntTlgTrDvsnCd(in.getTransactionCode());        // 거래구분코드
        originTrax.setEntTlgTrceNo(in.getMessageTrackingNumber());
        originTrax.setEntOutinDvsnCd(EntConst.OUTBOUND_CD);
        originTrax.setRespCd1(in.getResponseCode1());
        originTrax.setRespCd2(in.getResponseCode2());
        originTrax.setTrSts(in.getStatus());
        originTrax.setSndRcvDvsnCd(EntConst.RCV_FLAG);

        // 업무정보 Setting(수취인)
        originTrax.setCorpIndvDvsnCd(in.getResultbeneCorpIndvSort());
        originTrax.setCtzBizNoEnc(entCom.encryptCtzBizNo(in.getResultbeneResidentBusinessNumber()));
        originTrax.setCtzBizNo(entCom.sliceCtzBizNo(in.getResultbeneResidentBusinessNumber()));
        originTrax.setRepNm(in.getResultbeneNameRepresentativeName());
        originTrax.setCorpNm(in.getResultbeneCorpName());
        originTrax.setMbrAddr(in.getResultbeneAddress());
        originTrax.setMbrTelNo(in.getResultbenePhoneNumber());
        originTrax.setMbrMobileNo(in.getResultbeneMobilePhoneNumber());
        originTrax.setMbrEmail(in.getResultbeneEmail());
        originTrax.setMbrDvsnCd(in.getResultbeneMemberSort());
        originTrax.setCorpSizeCd(in.getResultbeneCompanySize());
        originTrax.setBizCd(in.getResultbeneIndustryCode());

        if ("1".equals(in.getConditionGuarantorSearchConditionSort())) {
            // 업무정보 Setting(보증인)
            originTrax.setCorpIndvDvsnCd2(in.getResultbeneCorpIndvSort());
            originTrax.setCtzBizNoEnc2(entCom.encryptCtzBizNo(in.getResultGuarantorResidentBusinessNumber()));
            originTrax.setCtzBizNo2(entCom.sliceCtzBizNo(in.getResultGuarantorResidentBusinessNumber()));
            originTrax.setRepNm2(in.getResultbeneNameRepresentativeName());
            originTrax.setCorpNm2(in.getResultbeneCorpName());
            originTrax.setMbrAddr2(in.getResultbeneAddress());
            originTrax.setMbrTelNo2(in.getResultbenePhoneNumber());
            originTrax.setMbrMobileNo2(in.getResultbeneMobilePhoneNumber());
            originTrax.setMbrEmail2(in.getResultbeneEmail());
            originTrax.setMbrDvsnCd2(in.getResultbeneMemberSort());
            originTrax.setCorpSizeCd2(in.getResultbeneCompanySize());
            originTrax.setBizCd2(in.getResultGuarantorIndustryCode());
        }

        log.debug("----------------- update origin trax----------------- : {} ", originTrax);
        entMbrLDao.updateOriginalTransaction(originTrax);

        /*
         * kftc 전문 생성
         * KftEnt0210221000CqeEnt0210221000
         */
        CqeEnt0210221000 sendVo = conversionService.convert(in, CqeEnt0210221000.class);
        sendVo.setMsgNo(originTrax.getHostNo());

        /*
         * KCG -> CQE 전송
         */
        frwTemplate.send(FrwDestination.CQE_ENT, sendVo);
    }

    @Override
    public void handleError(KftEnt0210221000 in, Throwable t) {
        // 에러 응답 값 세팅 (공통화 메서드 호출)
        entCom.setOutboundResponseErrorVo(in, t);

        // 로그 출력: 전송 전에 inVo 내용 확인
        log.info("----------------- KftEnt0210221000: {} -----------------", in);

        // 에러 응답 전송은 본 handleError에서 처리
        frwTemplate.send(FrwDestination.KFT_ENT, in);
    }
}
