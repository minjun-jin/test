package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 사고신고 요청
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * issuerCorpIndvSort 발행인법인개인구분 
 * issuerResidentBusinessNumber 발행인주민사업자번호 
 * accidentReporteNoteNumber 사고신고전자어음번호 
 * accidentReportSplitNumber 사고신고분할번호 
 * accidentReportStatus 사고신고여부 
 * accidentReportReceptionCancellationDateTime 사고신고접수(취소)일시 
 * 
 * CqeEnt0200330000 cqeEnt0200330000 = new CqeEnt0200330000(); // 사고신고 요청
 * cqeEnt0200330000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200330000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200330000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200330000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200330000.setTransactionCode("330000"); // 거래구분코드
 * cqeEnt0200330000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200330000.setBnkCd("057"); // 은행코드
 * cqeEnt0200330000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200330000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200330000.setFiller(""); // FILLER
 * cqeEnt0200330000.setIssuerCorpIndvSort(""); // 발행인법인개인구분
 * cqeEnt0200330000.setIssuerResidentBusinessNumber(""); // 발행인주민사업자번호
 * cqeEnt0200330000.setAccidentReporteNoteNumber(""); // 사고신고전자어음번호
 * cqeEnt0200330000.setAccidentReportSplitNumber(""); // 사고신고분할번호
 * cqeEnt0200330000.setAccidentReportStatus(""); // 사고신고여부
 * cqeEnt0200330000.setAccidentReportReceptionCancellationDateTime(LocalDateTime.now()); // 사고신고접수(취소)일시
 * }</pre>
 */
@Data
public class CqeEnt0200330000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "330000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String issuerCorpIndvSort; // 발행인법인개인구분
	private String issuerResidentBusinessNumber; // 발행인주민사업자번호
	private String accidentReporteNoteNumber; // 사고신고전자어음번호
	private String accidentReportSplitNumber; // 사고신고분할번호
	private String accidentReportStatus; // 사고신고여부
	private LocalDateTime accidentReportReceptionCancellationDateTime; // 사고신고접수(취소)일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReporteNoteNumber$; // 사고신고전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportSplitNumber$; // 사고신고분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportStatus$; // 사고신고여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportReceptionCancellationDateTime$; // 사고신고접수(취소)일시

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerResidentBusinessNumber$)) { // 발행인주민사업자번호
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(accidentReporteNoteNumber$)) { // 사고신고전자어음번호
			return 12;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인주민사업자번호
		accidentReporteNoteNumber$ = VOUtils.write(out, accidentReporteNoteNumber, 20); // 사고신고전자어음번호
		accidentReportSplitNumber$ = VOUtils.write(out, accidentReportSplitNumber, 2); // 사고신고분할번호
		accidentReportStatus$ = VOUtils.write(out, accidentReportStatus, 1); // 사고신고여부
		accidentReportReceptionCancellationDateTime$ = VOUtils.write(out, accidentReportReceptionCancellationDateTime, 14, "yyyyMMddHHmmss"); // 사고신고접수(취소)일시
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인주민사업자번호
		accidentReporteNoteNumber = VOUtils.toString(accidentReporteNoteNumber$ = VOUtils.read(in, 20)); // 사고신고전자어음번호
		accidentReportSplitNumber = VOUtils.toString(accidentReportSplitNumber$ = VOUtils.read(in, 2)); // 사고신고분할번호
		accidentReportStatus = VOUtils.toString(accidentReportStatus$ = VOUtils.read(in, 1)); // 사고신고여부
		accidentReportReceptionCancellationDateTime = VOUtils.toLocalDateTime(accidentReportReceptionCancellationDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 사고신고접수(취소)일시
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인주민사업자번호
		sb.append(", accidentReporteNoteNumber=").append(accidentReporteNoteNumber).append(System.lineSeparator()); // 사고신고전자어음번호
		sb.append(", accidentReportSplitNumber=").append(accidentReportSplitNumber).append(System.lineSeparator()); // 사고신고분할번호
		sb.append(", accidentReportStatus=").append(accidentReportStatus).append(System.lineSeparator()); // 사고신고여부
		sb.append(", accidentReportReceptionCancellationDateTime=").append(accidentReportReceptionCancellationDateTime).append(System.lineSeparator()); // 사고신고접수(취소)일시
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "330000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "accidentReporteNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "accidentReportSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "accidentReportReceptionCancellationDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss")
		);
	}

}
