package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자금조정 근기표
 * <pre>{@code
 * KftEntES0004R kftEntES0004R  = new KftEntES0004R(); // 자금조정 근기표
 * kftEntES0004R.setFileName(""); // 업무구분
 * kftEntES0004R.setDataType(""); // 데이터구분
 * kftEntES0004R.setSerialNumber(""); // 일련번호
 * kftEntES0004R.setBankCode(""); // 은행코드
 * kftEntES0004R.setFundAdjustmentNoteDebitCreditFlag(""); // 자금조정대상 어음 대차구분
 * kftEntES0004R.setFundAdjustmentAmount(0L); // 자금조정대상 금액
 * kftEntES0004R.setFundAdjustmentBenchmarkInterestRate(""); // 자금조정기준금리
 * kftEntES0004R.setBenchmarkInterestRateApplicationDate(""); // 기준금리적용일
 * kftEntES0004R.setFundBurdenDays(0); // 자금부담일수
 * kftEntES0004R.setFundAdjustmentDebitCreditFlag(""); // 자금조정대차구분
 * kftEntES0004R.setFundAdjustmentSettlementAmount(0L); // 자금조정정산금액
 * kftEntES0004R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES0004R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String bankCode; // 은행코드
	private String fundAdjustmentNoteDebitCreditFlag; // 자금조정대상 어음 대차구분
	private long fundAdjustmentAmount; // 자금조정대상 금액
	private String fundAdjustmentBenchmarkInterestRate; // 자금조정기준금리
	private String benchmarkInterestRateApplicationDate; // 기준금리적용일
	private int fundBurdenDays; // 자금부담일수
	private String fundAdjustmentDebitCreditFlag; // 자금조정대차구분
	private long fundAdjustmentSettlementAmount; // 자금조정정산금액
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentNoteDebitCreditFlag$; // 자금조정대상 어음 대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentAmount$; // 자금조정대상 금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentBenchmarkInterestRate$; // 자금조정기준금리
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String benchmarkInterestRateApplicationDate$; // 기준금리적용일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundBurdenDays$; // 자금부담일수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentDebitCreditFlag$; // 자금조정대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentSettlementAmount$; // 자금조정정산금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		fundAdjustmentNoteDebitCreditFlag$ = VOUtils.write(out, fundAdjustmentNoteDebitCreditFlag, 1); // 자금조정대상 어음 대차구분
		fundAdjustmentAmount$ = VOUtils.write(out, fundAdjustmentAmount, 15); // 자금조정대상 금액
		fundAdjustmentBenchmarkInterestRate$ = VOUtils.write(out, fundAdjustmentBenchmarkInterestRate, 5); // 자금조정기준금리
		benchmarkInterestRateApplicationDate$ = VOUtils.write(out, benchmarkInterestRateApplicationDate, 8); // 기준금리적용일
		fundBurdenDays$ = VOUtils.write(out, fundBurdenDays, 1); // 자금부담일수
		fundAdjustmentDebitCreditFlag$ = VOUtils.write(out, fundAdjustmentDebitCreditFlag, 1); // 자금조정대차구분
		fundAdjustmentSettlementAmount$ = VOUtils.write(out, fundAdjustmentSettlementAmount, 15); // 자금조정정산금액
		filler2$ = VOUtils.write(out, filler2, 16); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		fundAdjustmentNoteDebitCreditFlag = VOUtils.toString(fundAdjustmentNoteDebitCreditFlag$ = VOUtils.read(in, 1)); // 자금조정대상 어음 대차구분
		fundAdjustmentAmount = VOUtils.toLong(fundAdjustmentAmount$ = VOUtils.read(in, 15)); // 자금조정대상 금액
		fundAdjustmentBenchmarkInterestRate = VOUtils.toString(fundAdjustmentBenchmarkInterestRate$ = VOUtils.read(in, 5)); // 자금조정기준금리
		benchmarkInterestRateApplicationDate = VOUtils.toString(benchmarkInterestRateApplicationDate$ = VOUtils.read(in, 8)); // 기준금리적용일
		fundBurdenDays = VOUtils.toInt(fundBurdenDays$ = VOUtils.read(in, 1)); // 자금부담일수
		fundAdjustmentDebitCreditFlag = VOUtils.toString(fundAdjustmentDebitCreditFlag$ = VOUtils.read(in, 1)); // 자금조정대차구분
		fundAdjustmentSettlementAmount = VOUtils.toLong(fundAdjustmentSettlementAmount$ = VOUtils.read(in, 15)); // 자금조정정산금액
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 16)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", fundAdjustmentNoteDebitCreditFlag=").append(fundAdjustmentNoteDebitCreditFlag).append(System.lineSeparator()); // 자금조정대상 어음 대차구분
		sb.append(", fundAdjustmentAmount=").append(fundAdjustmentAmount).append(System.lineSeparator()); // 자금조정대상 금액
		sb.append(", fundAdjustmentBenchmarkInterestRate=").append(fundAdjustmentBenchmarkInterestRate).append(System.lineSeparator()); // 자금조정기준금리
		sb.append(", benchmarkInterestRateApplicationDate=").append(benchmarkInterestRateApplicationDate).append(System.lineSeparator()); // 기준금리적용일
		sb.append(", fundBurdenDays=").append(fundBurdenDays).append(System.lineSeparator()); // 자금부담일수
		sb.append(", fundAdjustmentDebitCreditFlag=").append(fundAdjustmentDebitCreditFlag).append(System.lineSeparator()); // 자금조정대차구분
		sb.append(", fundAdjustmentSettlementAmount=").append(fundAdjustmentSettlementAmount).append(System.lineSeparator()); // 자금조정정산금액
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "fundAdjustmentNoteDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "fundAdjustmentAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "fundAdjustmentBenchmarkInterestRate", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "benchmarkInterestRateApplicationDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "fundBurdenDays", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "fundAdjustmentDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "fundAdjustmentSettlementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "16", "defltVal", "")
		);
	}

}
