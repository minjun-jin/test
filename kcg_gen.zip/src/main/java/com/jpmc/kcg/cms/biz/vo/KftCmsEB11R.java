package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.Mac;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (은행접수)출금이체신청내역
 * <pre>{@code
 * KftCmsEB11R kftCmsEB11R  = new KftCmsEB11R(); // (은행접수)출금이체신청내역
 * kftCmsEB11R.setRecordType(""); // Record 구분
 * kftCmsEB11R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB11R.setInstitutionCode(""); // 기관코드
 * kftCmsEB11R.setRequestDate(""); // 신청일자
 * kftCmsEB11R.setRequestDivision(""); // 신청구분
 * kftCmsEB11R.setPayerNumber(""); // 납부자번호
 * kftCmsEB11R.setBankBranchCode(""); // 은행점코드
 * kftCmsEB11R.setDesignatedWithdrawalAccountNumber(""); // 지정출금계좌번호
 * kftCmsEB11R.setAccountHolderResidentBusinessNumber(""); // 예금주 생년월일 또는 사업자등록번호
 * kftCmsEB11R.setHandlingBranchCode(""); // 취급점코드
 * kftCmsEB11R.setFundType(""); // 자금종류
 * kftCmsEB11R.setProcessingResultCode(""); // 처리결과-결과코드
 * kftCmsEB11R.setProcessingResultFailedCode(""); // 처리결과-불능코드
 * kftCmsEB11R.setCheckResidentBusinessNumberYn(""); // 생년월일(사업자등록번호) Check 여부
 * kftCmsEB11R.setPhoneNumber(""); // 전화번호(핸드폰)
 * kftCmsEB11R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB11R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String requestDate; // 신청일자
	private String requestDivision; // 신청구분
	private String payerNumber; // 납부자번호
	private String bankBranchCode; // 은행점코드
	private String designatedWithdrawalAccountNumber; // 지정출금계좌번호
	private String accountHolderResidentBusinessNumber; // 예금주 생년월일 또는 사업자등록번호
	private String handlingBranchCode; // 취급점코드
	private String fundType; // 자금종류
	private String processingResultCode; // 처리결과-결과코드
	private String processingResultFailedCode; // 처리결과-불능코드
	private String checkResidentBusinessNumberYn; // 생년월일(사업자등록번호) Check 여부
	private String phoneNumber; // 전화번호(핸드폰)
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestDate$; // 신청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestDivision$; // 신청구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String payerNumber$; // 납부자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankBranchCode$; // 은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String designatedWithdrawalAccountNumber$; // 지정출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accountHolderResidentBusinessNumber$; // 예금주 생년월일 또는 사업자등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingBranchCode$; // 취급점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingResultCode$; // 처리결과-결과코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String processingResultFailedCode$; // 처리결과-불능코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String checkResidentBusinessNumberYn$; // 생년월일(사업자등록번호) Check 여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String phoneNumber$; // 전화번호(핸드폰)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void calculate(Mac mac) {
		mac.calculate(designatedWithdrawalAccountNumber);
	}

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		requestDate$ = VOUtils.write(out, requestDate, 6); // 신청일자
		requestDivision$ = VOUtils.write(out, requestDivision, 1); // 신청구분
		payerNumber$ = VOUtils.write(out, payerNumber, 20); // 납부자번호
		bankBranchCode$ = VOUtils.write(out, bankBranchCode, 7); // 은행점코드
		designatedWithdrawalAccountNumber$ = VOUtils.write(out, designatedWithdrawalAccountNumber, 16); // 지정출금계좌번호
		accountHolderResidentBusinessNumber$ = VOUtils.write(out, accountHolderResidentBusinessNumber, 16); // 예금주 생년월일 또는 사업자등록번호
		handlingBranchCode$ = VOUtils.write(out, handlingBranchCode, 4); // 취급점코드
		fundType$ = VOUtils.write(out, fundType, 2); // 자금종류
		processingResultCode$ = VOUtils.write(out, processingResultCode, 1); // 처리결과-결과코드
		processingResultFailedCode$ = VOUtils.write(out, processingResultFailedCode, 4); // 처리결과-불능코드
		checkResidentBusinessNumberYn$ = VOUtils.write(out, checkResidentBusinessNumberYn, 1); // 생년월일(사업자등록번호) Check 여부
		phoneNumber$ = VOUtils.write(out, phoneNumber, 12); // 전화번호(핸드폰)
		filler2$ = VOUtils.write(out, filler2, 11); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		requestDate = VOUtils.toString(requestDate$ = VOUtils.read(in, 6)); // 신청일자
		requestDivision = VOUtils.toString(requestDivision$ = VOUtils.read(in, 1)); // 신청구분
		payerNumber = VOUtils.toString(payerNumber$ = VOUtils.read(in, 20)); // 납부자번호
		bankBranchCode = VOUtils.toString(bankBranchCode$ = VOUtils.read(in, 7)); // 은행점코드
		designatedWithdrawalAccountNumber = VOUtils.toString(designatedWithdrawalAccountNumber$ = VOUtils.read(in, 16)); // 지정출금계좌번호
		accountHolderResidentBusinessNumber = VOUtils.toString(accountHolderResidentBusinessNumber$ = VOUtils.read(in, 16)); // 예금주 생년월일 또는 사업자등록번호
		handlingBranchCode = VOUtils.toString(handlingBranchCode$ = VOUtils.read(in, 4)); // 취급점코드
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금종류
		processingResultCode = VOUtils.toString(processingResultCode$ = VOUtils.read(in, 1)); // 처리결과-결과코드
		processingResultFailedCode = VOUtils.toString(processingResultFailedCode$ = VOUtils.read(in, 4)); // 처리결과-불능코드
		checkResidentBusinessNumberYn = VOUtils.toString(checkResidentBusinessNumberYn$ = VOUtils.read(in, 1)); // 생년월일(사업자등록번호) Check 여부
		phoneNumber = VOUtils.toString(phoneNumber$ = VOUtils.read(in, 12)); // 전화번호(핸드폰)
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 11)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", requestDate=").append(requestDate).append(System.lineSeparator()); // 신청일자
		sb.append(", requestDivision=").append(requestDivision).append(System.lineSeparator()); // 신청구분
		sb.append(", payerNumber=").append(payerNumber).append(System.lineSeparator()); // 납부자번호
		sb.append(", bankBranchCode=").append(bankBranchCode).append(System.lineSeparator()); // 은행점코드
		sb.append(", designatedWithdrawalAccountNumber=").append(designatedWithdrawalAccountNumber).append(System.lineSeparator()); // 지정출금계좌번호
		sb.append(", accountHolderResidentBusinessNumber=").append(accountHolderResidentBusinessNumber).append(System.lineSeparator()); // 예금주 생년월일 또는 사업자등록번호
		sb.append(", handlingBranchCode=").append(handlingBranchCode).append(System.lineSeparator()); // 취급점코드
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금종류
		sb.append(", processingResultCode=").append(processingResultCode).append(System.lineSeparator()); // 처리결과-결과코드
		sb.append(", processingResultFailedCode=").append(processingResultFailedCode).append(System.lineSeparator()); // 처리결과-불능코드
		sb.append(", checkResidentBusinessNumberYn=").append(checkResidentBusinessNumberYn).append(System.lineSeparator()); // 생년월일(사업자등록번호) Check 여부
		sb.append(", phoneNumber=").append(phoneNumber).append(System.lineSeparator()); // 전화번호(핸드폰)
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "requestDate", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "requestDivision", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "payerNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "bankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "designatedWithdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "accountHolderResidentBusinessNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "handlingBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "processingResultCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "processingResultFailedCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "checkResidentBusinessNumberYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "phoneNumber", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "11", "defltVal", "")
		);
	}

}
