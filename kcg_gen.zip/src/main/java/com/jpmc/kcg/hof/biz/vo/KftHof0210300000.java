package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 타행이체수취조회
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+HDR
 * systemId 시스템-ID 고유 System ID (ELB)
 * messageType 전문종별코드 전문종별코드
 * messageCode 통신망관리정보 거래구분코드
 * sendReceiveFlag 송수신FLAG 1:요구,2:지시,3:보고,4:통보,5:통보(지연/재요구응답)
 * status STATUS 오류전문 발생항목의 Bit Map번호
 * responseCode 응답코드 응답코드
 * messageTransmissionDate 전문전송일 YYYYMMDD
 * messageSendTime 전문전송시간 hhmmss
 * messageTrackingNumber 전문추적번호 전문추적번호
 * traxOccurredDate 거래발생일 YYYYMMDD
 * transactionIdNumber 거래고유번호 취급기관대표코드(3) + 일련번호(10)
 * handlingInstitutionRepCode 취급기관대표코드 행정정보공동이용센터는 “481”
 * requestBranchCode 취급기관ㆍ점별코드 취급기관코드(3) + 지점코드(4)
 * beneficiaryBankCode 개설기관대표코드 
 * beneficiaryBranchCode 개설기관ㆍ점별코드 개설기관코드(3) + 지점코드(4)
 * beneficiaryAccountNumber 수취계좌번호 
 * transactionAmount 거래금액 
 * beneficiaryAreaCode 수취지역코드 수취점 지역 코드
 * withdrawer 출금인 전송코드는 KSC 5601 2BYTE 완성형 한글코드
 * beneficiaryName 수취인 전송코드는 KSC 5601 2BYTE 완성형 한글코드
 * mediaType 매체구분 01: PC 뱅킹, 02: 인터넷 뱅킹, 03: 전화, 04: 휴대전화, 05: 건별이체, 06: 기타, 07: 대량이체, 08: TV
 * fundType 자금성격 00: 일 반,
01: 급 여,
02: 배당금,
03: 기 타,
04: 타행 자동이체,
11: 기초생활보장급여,
12: 기초노령연금,
13: 장애인연금,
14: 긴급지원금,
15: 장애(아동)수당,
16: 한부모가족지원,
17: 어선원보험급여,
18: 공무원연금,
19: 보훈급여금 등,
20: 국민연금,
21: 건설근로자 퇴직공제금,
22: 석면피해 구제급여,
23: 아동수당,
24: 소기업ㆍ소상공인 공제금,
25: 실업급여,
26: 산재보험급여,
27: 자립수당,
30: 요양비 등 보험급여 및 특별현금급여
 * requestorInformation 의뢰인정보 CMS계좌번호, 고객번호 등 의뢰인정보
 * withdrawalAccountNumber 출금계좌번호 RK센터 및 행정정보 공동이용센터는 공백
 * reservedInformationField1 예비정보FIELD 
 * reservedInformationField2 예비정보FIELD 
 * realSenderName 송금인실명 
 * suspectedFraudInfo 금융사기의심유의정보 : 일반거래(금융사기 의심거래 아님)
01: 최근 3일 이내 대출금 5백만원 이상 입금내역이 있는 상태에서 송금하는 경우
02: 예․적금 중도해지 후 해지 당일 송금하는 경우
SP: 금융사기 의심거래 01, 02에는 해당하지 않으나 참가기관 자체 판단기준에 따른 의심거래에 해당하는 경우
 * filler FILLER 
 * 
 * KftHof0210300000 kftHof0210300000 = new KftHof0210300000(); // 타행이체수취조회
 * kftHof0210300000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0210300000.setSystemId("ELB"); // 시스템-ID
 * kftHof0210300000.setMessageType("0210"); // 전문종별코드
 * kftHof0210300000.setMessageCode("300000"); // 통신망관리정보
 * kftHof0210300000.setSendReceiveFlag("3"); // 송수신FLAG
 * kftHof0210300000.setStatus("000"); // STATUS
 * kftHof0210300000.setResponseCode(""); // 응답코드
 * kftHof0210300000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0210300000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0210300000.setMessageTrackingNumber("00000000"); // 전문추적번호
 * kftHof0210300000.setTraxOccurredDate(LocalDate.now()); // 거래발생일
 * kftHof0210300000.setTransactionIdNumber(""); // 거래고유번호
 * kftHof0210300000.setHandlingInstitutionRepCode("000"); // 취급기관대표코드
 * kftHof0210300000.setRequestBranchCode("0000000"); // 취급기관ㆍ점별코드
 * kftHof0210300000.setBeneficiaryBankCode("000"); // 개설기관대표코드
 * kftHof0210300000.setBeneficiaryBranchCode("0000000"); // 개설기관ㆍ점별코드
 * kftHof0210300000.setBeneficiaryAccountNumber(""); // 수취계좌번호
 * kftHof0210300000.setTransactionAmount(0L); // 거래금액
 * kftHof0210300000.setBeneficiaryAreaCode("00"); // 수취지역코드
 * kftHof0210300000.setWithdrawer(""); // 출금인
 * kftHof0210300000.setBeneficiaryName(""); // 수취인
 * kftHof0210300000.setMediaType("01"); // 매체구분
 * kftHof0210300000.setFundType("00"); // 자금성격
 * kftHof0210300000.setRequestorInformation(""); // 의뢰인정보
 * kftHof0210300000.setWithdrawalAccountNumber(""); // 출금계좌번호
 * kftHof0210300000.setReservedInformationField1(""); // 예비정보FIELD
 * kftHof0210300000.setReservedInformationField2(""); // 예비정보FIELD
 * kftHof0210300000.setRealSenderName(""); // 송금인실명
 * kftHof0210300000.setSuspectedFraudInfo(""); // 금융사기의심유의정보
 * kftHof0210300000.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHof0210300000 implements KftHofComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "ELB"; // 시스템-ID
	private String messageType = "0210"; // 전문종별코드
	private String messageCode = "300000"; // 통신망관리정보
	private String sendReceiveFlag = "3"; // 송수신FLAG
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "00000000"; // 전문추적번호
	private LocalDate traxOccurredDate; // 거래발생일
	private String transactionIdNumber; // 거래고유번호
	private String handlingInstitutionRepCode = "000"; // 취급기관대표코드
	private String requestBranchCode = "0000000"; // 취급기관ㆍ점별코드
	private String beneficiaryBankCode = "000"; // 개설기관대표코드
	private String beneficiaryBranchCode = "0000000"; // 개설기관ㆍ점별코드
	private String beneficiaryAccountNumber; // 수취계좌번호
	private long transactionAmount; // 거래금액
	private String beneficiaryAreaCode = "00"; // 수취지역코드
	private String withdrawer; // 출금인
	private String beneficiaryName; // 수취인
	private String mediaType = "01"; // 매체구분
	private String fundType = "00"; // 자금성격
	private String requestorInformation; // 의뢰인정보
	private String withdrawalAccountNumber; // 출금계좌번호
	private String reservedInformationField1; // 예비정보FIELD
	private String reservedInformationField2; // 예비정보FIELD
	private String realSenderName; // 송금인실명
	private String suspectedFraudInfo; // 금융사기의심유의정보
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 통신망관리정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String traxOccurredDate$; // 거래발생일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String handlingInstitutionRepCode$; // 취급기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관대표코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionAmount$; // 거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAreaCode$; // 수취지역코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawer$; // 출금인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mediaType$; // 매체구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundType$; // 자금성격
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestorInformation$; // 의뢰인정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalAccountNumber$; // 출금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField1$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField2$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String realSenderName$; // 송금인실명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String suspectedFraudInfo$; // 금융사기의심유의정보
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 2;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 4;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 7;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 8;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 9;
		}
		if (VOUtils.isWhitespace(traxOccurredDate$)) { // 거래발생일
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryAccountNumber$)) { // 수취계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(requestorInformation$)) { // 의뢰인정보
			return 23;
		}
		if (VOUtils.isNotAlphanumericSpace(withdrawalAccountNumber$)) { // 출금계좌번호
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(suspectedFraudInfo$)) { // 금융사기의심유의정보
			return 28;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 통신망관리정보
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 8); // 전문추적번호
		traxOccurredDate$ = VOUtils.write(out, traxOccurredDate, 8, "yyyyMMdd"); // 거래발생일
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		handlingInstitutionRepCode$ = VOUtils.write(out, handlingInstitutionRepCode, 3); // 취급기관대표코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관대표코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 7); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 16); // 수취계좌번호
		transactionAmount$ = VOUtils.write(out, transactionAmount, 14); // 거래금액
		beneficiaryAreaCode$ = VOUtils.write(out, beneficiaryAreaCode, 2); // 수취지역코드
		withdrawer$ = VOUtils.write(out, withdrawer, 20, "EUC-KR"); // 출금인
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인
		mediaType$ = VOUtils.write(out, mediaType, 2); // 매체구분
		fundType$ = VOUtils.write(out, fundType, 2); // 자금성격
		requestorInformation$ = VOUtils.write(out, requestorInformation, 32); // 의뢰인정보
		withdrawalAccountNumber$ = VOUtils.write(out, withdrawalAccountNumber, 16); // 출금계좌번호
		reservedInformationField1$ = VOUtils.write(out, reservedInformationField1, 10); // 예비정보FIELD
		reservedInformationField2$ = VOUtils.write(out, reservedInformationField2, 28); // 예비정보FIELD
		realSenderName$ = VOUtils.write(out, realSenderName, 20, "EUC-KR"); // 송금인실명
		suspectedFraudInfo$ = VOUtils.write(out, suspectedFraudInfo, 2); // 금융사기의심유의정보
		filler$ = VOUtils.write(out, filler, 133); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 통신망관리정보
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 8)); // 전문추적번호
		traxOccurredDate = VOUtils.toLocalDate(traxOccurredDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 거래발생일
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		handlingInstitutionRepCode = VOUtils.toString(handlingInstitutionRepCode$ = VOUtils.read(in, 3)); // 취급기관대표코드
		requestBranchCode = VOUtils.toString(requestBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관대표코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 16)); // 수취계좌번호
		transactionAmount = VOUtils.toLong(transactionAmount$ = VOUtils.read(in, 14)); // 거래금액
		beneficiaryAreaCode = VOUtils.toString(beneficiaryAreaCode$ = VOUtils.read(in, 2)); // 수취지역코드
		withdrawer = VOUtils.toString(withdrawer$ = VOUtils.read(in, 20, "EUC-KR")); // 출금인
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인
		mediaType = VOUtils.toString(mediaType$ = VOUtils.read(in, 2)); // 매체구분
		fundType = VOUtils.toString(fundType$ = VOUtils.read(in, 2)); // 자금성격
		requestorInformation = VOUtils.toString(requestorInformation$ = VOUtils.read(in, 32)); // 의뢰인정보
		withdrawalAccountNumber = VOUtils.toString(withdrawalAccountNumber$ = VOUtils.read(in, 16)); // 출금계좌번호
		reservedInformationField1 = VOUtils.toString(reservedInformationField1$ = VOUtils.read(in, 10)); // 예비정보FIELD
		reservedInformationField2 = VOUtils.toString(reservedInformationField2$ = VOUtils.read(in, 28)); // 예비정보FIELD
		realSenderName = VOUtils.toString(realSenderName$ = VOUtils.read(in, 20, "EUC-KR")); // 송금인실명
		suspectedFraudInfo = VOUtils.toString(suspectedFraudInfo$ = VOUtils.read(in, 2)); // 금융사기의심유의정보
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 133)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 통신망관리정보
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", traxOccurredDate=").append(traxOccurredDate).append(System.lineSeparator()); // 거래발생일
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", handlingInstitutionRepCode=").append(handlingInstitutionRepCode).append(System.lineSeparator()); // 취급기관대표코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관대표코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취계좌번호
		sb.append(", transactionAmount=").append(transactionAmount).append(System.lineSeparator()); // 거래금액
		sb.append(", beneficiaryAreaCode=").append(beneficiaryAreaCode).append(System.lineSeparator()); // 수취지역코드
		sb.append(", withdrawer=").append(withdrawer).append(System.lineSeparator()); // 출금인
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인
		sb.append(", mediaType=").append(mediaType).append(System.lineSeparator()); // 매체구분
		sb.append(", fundType=").append(fundType).append(System.lineSeparator()); // 자금성격
		sb.append(", requestorInformation=").append(requestorInformation).append(System.lineSeparator()); // 의뢰인정보
		sb.append(", withdrawalAccountNumber=").append(withdrawalAccountNumber).append(System.lineSeparator()); // 출금계좌번호
		sb.append(", reservedInformationField1=").append(reservedInformationField1).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", reservedInformationField2=").append(reservedInformationField2).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", realSenderName=").append(realSenderName).append(System.lineSeparator()); // 송금인실명
		sb.append(", suspectedFraudInfo=").append(suspectedFraudInfo).append(System.lineSeparator()); // 금융사기의심유의정보
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "ELB"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "300000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "3"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "traxOccurredDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "handlingInstitutionRepCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "transactionAmount", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "beneficiaryAreaCode", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "withdrawer", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "mediaType", "fldLen", "2", "defltVal", "01"),
			Map.of("fld", "fundType", "fldLen", "2", "defltVal", "00"),
			Map.of("fld", "requestorInformation", "fldLen", "32", "defltVal", ""),
			Map.of("fld", "withdrawalAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "reservedInformationField1", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "reservedInformationField2", "fldLen", "28", "defltVal", ""),
			Map.of("fld", "realSenderName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "suspectedFraudInfo", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "133", "defltVal", "")
		);
	}

}
