package com.jpmc.kcg.ent.map;

import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.ent.biz.vo.CqeEnt0200220000;
import com.jpmc.kcg.ent.constants.EntConst;
import com.jpmc.kcg.ent.dto.EntMbrL;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.springframework.core.convert.converter.Converter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Mapper(
        componentModel = "spring",
        unmappedTargetPolicy = ReportingPolicy.IGNORE,
        imports = {LocalDateTime.class, BigDecimal.class, DateUtils.class, EntConst.class, ComConst.class}
)
public interface CqeEnt0200220000EntMbrL extends Converter<CqeEnt0200220000, EntMbrL> {

    @Mapping(target = "trDt", expression = "java(DateUtils.getISODate())")
    @Mapping(target = "entTlgTrceNo", ignore = true)
    @Mapping(target = "trUnqNo", source = "transactionIdNumber")
    @Mapping(target = "hostNo", source = "msgNo")
    @Mapping(target = "entOutinDvsnCd", expression = "java(EntConst.OUTBOUND_CD)")
    @Mapping(target = "othrPartyBnkCd", ignore = true)
    @Mapping(target = "sysDvsn", expression = "java(EntConst.SYS_ID)")
    @Mapping(target = "bnkCd", source = "bnkCd")
    @Mapping(target = "entTlgKndDvsnCd", source = "messageType")
    @Mapping(target = "entTlgTrDvsnCd", source = "transactionCode")
    @Mapping(target = "sndRcvDvsnCd", expression = "java(EntConst.SND_FLAG)")

    @Mapping(target = "respCd1", source = "responseCode1")
    @Mapping(target = "respCd2", source = "responseCode2")

    @Mapping(target = "tlgTrDt", source = "systemSendReceiveTime", dateFormat = "yyyyMMdd")
    @Mapping(target = "tlgSndTm", source = "systemSendReceiveTime", dateFormat = "HHmmss")

    @Mapping(target = "srchCondSort", source = "conditionSearchConditionSort")
    @Mapping(target = "condCtzBizNoEnc", source = "conditionResidentBusinessNumber")
    @Mapping(target = "condBnkCd", source = "conditionBankCode")
    @Mapping(target = "condDpstAcctNo", source = "conditionDepositAccountNumber")

    @Mapping(target = "corpIndvDvsnCd", source = "resultCorpIndvSort")
    @Mapping(target = "repNm", source = "resultNameRepresentativeName")
    @Mapping(target = "corpNm", source = "resultCorpName")
    @Mapping(target = "mbrAddr", source = "resultAddress")
    @Mapping(target = "mbrTelNo", source = "resultPhoneNumber")
    @Mapping(target = "mbrMobileNo", source = "resultMobilePhoneNumber")
    @Mapping(target = "mbrEmail", source = "resultEmail")
    @Override
    EntMbrL convert(CqeEnt0200220000 source);
}
