package com.jpmc.kcg.web.com.service;

import com.jpmc.kcg.com.dto.ComTlgLaytMapD;
import com.jpmc.kcg.com.dto.ComTlgLaytMapM;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.web.WebApplicationContext;
import com.jpmc.kcg.web.com.dao.ComTlgLaytMapDao;
import com.jpmc.kcg.web.com.dto.ComTlgLaytMapAprv;
import com.jpmc.kcg.web.com.enums.AprvRqstDvsnCdEnum;
import com.jpmc.kcg.web.com.enums.AprvStsCdEnum;
import com.jpmc.kcg.web.com.interfaces.PostApproval;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.List;

@Slf4j
@Service
public class ComTlgLaytMapPostApproval implements PostApproval<ComTlgLaytMapAprv> {
    private final ComTlgLaytMapDao comTlgLaytMapDao;

    public ComTlgLaytMapPostApproval(ComTlgLaytMapDao comTlgLaytMapDao) {
        this.comTlgLaytMapDao = comTlgLaytMapDao;
    }

    @Override
    public Object postApproval(String aprvRqstDvsnCd, ComTlgLaytMapAprv afterDto) {
        String chkId = WebApplicationContext.getHeader().getStaffId();
        String dttm = DateUtils.getDttm();

        if (AprvRqstDvsnCdEnum.INSERT.getValue().equals(aprvRqstDvsnCd)) {
            ComTlgLaytMapM comTlgLaytMapM = new ComTlgLaytMapM();
            comTlgLaytMapM.setTlgLaytMapId(afterDto.getTlgLaytMapId());
            comTlgLaytMapM.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
            comTlgLaytMapM.setChkId(chkId);
            comTlgLaytMapM.setChkDttm(dttm);

            comTlgLaytMapDao.updateTlgMapMPostApproval(comTlgLaytMapM);

            List<ComTlgLaytMapD> comTlgLaytMapDList = afterDto.getComTlgLaytMapDList();
            for (ComTlgLaytMapD comTlgLaytMapD : comTlgLaytMapDList) {
                ComTlgLaytMapD mapD = new ComTlgLaytMapD();
                mapD.setTlgLaytMapId(comTlgLaytMapD.getTlgLaytMapId());
                mapD.setTrgtTlgLaytId(comTlgLaytMapD.getTrgtTlgLaytId());
                mapD.setTrgtTlgFld(comTlgLaytMapD.getTrgtTlgFld());
                mapD.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
                mapD.setChkId(chkId);
                mapD.setChkDttm(dttm);

                comTlgLaytMapDao.updateTlgMapDPostApproval(mapD);
            }

        }
        else if (AprvRqstDvsnCdEnum.UPDATE.getValue().equals(aprvRqstDvsnCd)) {
            ComTlgLaytMapM comTlgLaytMapM = new ComTlgLaytMapM();
            comTlgLaytMapM.setTlgLaytMapId(afterDto.getTlgLaytMapId());
            comTlgLaytMapM.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
            comTlgLaytMapM.setChkId(chkId);
            comTlgLaytMapM.setChkDttm(dttm);

            comTlgLaytMapDao.updateTlgMapMPostApproval(comTlgLaytMapM);

            List<ComTlgLaytMapD> comTlgLaytMapDList = afterDto.getComTlgLaytMapDList();
            for (ComTlgLaytMapD comTlgLaytMapD : comTlgLaytMapDList) {
                int count = comTlgLaytMapDao.selectTlgMapDCount(
                        comTlgLaytMapD.getTlgLaytMapId(),
                        comTlgLaytMapD.getTrgtTlgLaytId(),
                        comTlgLaytMapD.getTrgtTlgFld()
                );

                // 매핑 취소(Reject)한 데이터를 테이블에서 삭제
                comTlgLaytMapDao.deleteRejectTlgMapD(comTlgLaytMapD);

                comTlgLaytMapD.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
                comTlgLaytMapD.setChkId(chkId);
                comTlgLaytMapD.setChkDttm(dttm);

                comTlgLaytMapDao.updateTlgMapDPostApproval(comTlgLaytMapD);
            }
        }

        return afterDto;
    }

    @Override
    public Object postReject(String aprvRqstDvsnCd, ComTlgLaytMapAprv afterDto) {
        String chkId = WebApplicationContext.getHeader().getStaffId();
        String dttm = DateUtils.getDttm();

        if (AprvRqstDvsnCdEnum.INSERT.getValue().equals(aprvRqstDvsnCd)) {
            ComTlgLaytMapM comTlgLaytMapM = new ComTlgLaytMapM();
            comTlgLaytMapM.setTlgLaytMapId(afterDto.getTlgLaytMapId());

            ComTlgLaytMapD comTlgLaytMapD = new ComTlgLaytMapD();
            comTlgLaytMapD.setTlgLaytMapId(afterDto.getTlgLaytMapId());

            comTlgLaytMapDao.deleteTlgMapM(comTlgLaytMapM);
            comTlgLaytMapDao.deleteTlgMapD(comTlgLaytMapD);
        }
        else if (AprvRqstDvsnCdEnum.UPDATE.getValue().equals(aprvRqstDvsnCd)) {
            ComTlgLaytMapM comTlgLaytMapM = new ComTlgLaytMapM();
            comTlgLaytMapM.setTlgLaytMapId(afterDto.getTlgLaytMapId());
            comTlgLaytMapM.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
            comTlgLaytMapM.setChkId(chkId);
            comTlgLaytMapM.setChkDttm(dttm);

            comTlgLaytMapDao.updateTlgMapMPostApproval(comTlgLaytMapM);

            List<ComTlgLaytMapD> comTlgLaytMapDList = afterDto.getComTlgLaytMapDList();
            for (ComTlgLaytMapD comTlgLaytMapD : comTlgLaytMapDList) {
                ComTlgLaytMapD mapD = new ComTlgLaytMapD();

                String aprvStsCd = comTlgLaytMapD.getAprvStsCd();

                if (AprvStsCdEnum.INSERT_NOT_APPROVED.getValue().equals(aprvStsCd)) {
                    mapD.setTlgLaytMapId(comTlgLaytMapD.getTlgLaytMapId());
                    mapD.setTrgtTlgLaytId(comTlgLaytMapD.getTrgtTlgLaytId());
                    mapD.setTrgtTlgFld(comTlgLaytMapD.getTrgtTlgFld());

                    comTlgLaytMapDao.deleteTlgMapD(mapD);
                }
                else {
                    mapD.setTlgLaytMapId(comTlgLaytMapD.getTlgLaytMapId());
                    mapD.setTrgtTlgLaytId(comTlgLaytMapD.getTrgtTlgLaytId());
                    mapD.setTrgtTlgFld(comTlgLaytMapD.getTrgtTlgFld());
                    mapD.setAprvStsCd(AprvStsCdEnum.APPROVED.getValue());
                    mapD.setChkId(chkId);
                    mapD.setChkDttm(dttm);

                    comTlgLaytMapDao.updateTlgMapDPostApproval(mapD);
                }
            }
        }

        return afterDto;
    }
}
