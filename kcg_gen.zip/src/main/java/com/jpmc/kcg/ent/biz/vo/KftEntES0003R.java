package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 차액결제지시내역
 * <pre>{@code
 * KftEntES0003R kftEntES0003R  = new KftEntES0003R(); // 차액결제지시내역
 * kftEntES0003R.setFileName(""); // 업무구분
 * kftEntES0003R.setDataType(""); // 데이터구분
 * kftEntES0003R.setSerialNumber(""); // 일련번호
 * kftEntES0003R.setBankCode(""); // 은행코드
 * kftEntES0003R.setMaturityENotePaymentDebitCreditFlag(""); // 만기전자어음결제대차구분
 * kftEntES0003R.setMaturityENotePaymentDifference(0L); // 만기전자어음결제차액
 * kftEntES0003R.setDefaultENotePaymentDebitCreditFlag(""); // 부도전자어음결제대차구분
 * kftEntES0003R.setDefaultENotePaymentDifference(0L); // 부도전자어음결제차액
 * kftEntES0003R.setFundAdjustmentDebitCreditFlag(""); // 자금조정대차구분
 * kftEntES0003R.setFundAdjustmentDifferenceAmount(0L); // 자금조정차액
 * kftEntES0003R.setFeeSettlementDebitCreditFlag(""); // 수수료정산대차구분
 * kftEntES0003R.setFeeSettlementAmount(0L); // 수수료정산금액
 * kftEntES0003R.setDifferencePaymentDebitCreditFlag(""); // 차액결제대차구분
 * kftEntES0003R.setDifferencePaymentAmount(0L); // 차액결제금액
 * kftEntES0003R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES0003R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String bankCode; // 은행코드
	private String maturityENotePaymentDebitCreditFlag; // 만기전자어음결제대차구분
	private long maturityENotePaymentDifference; // 만기전자어음결제차액
	private String defaultENotePaymentDebitCreditFlag; // 부도전자어음결제대차구분
	private long defaultENotePaymentDifference; // 부도전자어음결제차액
	private String fundAdjustmentDebitCreditFlag; // 자금조정대차구분
	private long fundAdjustmentDifferenceAmount; // 자금조정차액
	private String feeSettlementDebitCreditFlag; // 수수료정산대차구분
	private long feeSettlementAmount; // 수수료정산금액
	private String differencePaymentDebitCreditFlag; // 차액결제대차구분
	private long differencePaymentAmount; // 차액결제금액
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String maturityENotePaymentDebitCreditFlag$; // 만기전자어음결제대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String maturityENotePaymentDifference$; // 만기전자어음결제차액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultENotePaymentDebitCreditFlag$; // 부도전자어음결제대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultENotePaymentDifference$; // 부도전자어음결제차액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentDebitCreditFlag$; // 자금조정대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentDifferenceAmount$; // 자금조정차액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String feeSettlementDebitCreditFlag$; // 수수료정산대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String feeSettlementAmount$; // 수수료정산금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String differencePaymentDebitCreditFlag$; // 차액결제대차구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String differencePaymentAmount$; // 차액결제금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		maturityENotePaymentDebitCreditFlag$ = VOUtils.write(out, maturityENotePaymentDebitCreditFlag, 1); // 만기전자어음결제대차구분
		maturityENotePaymentDifference$ = VOUtils.write(out, maturityENotePaymentDifference, 15); // 만기전자어음결제차액
		defaultENotePaymentDebitCreditFlag$ = VOUtils.write(out, defaultENotePaymentDebitCreditFlag, 1); // 부도전자어음결제대차구분
		defaultENotePaymentDifference$ = VOUtils.write(out, defaultENotePaymentDifference, 15); // 부도전자어음결제차액
		fundAdjustmentDebitCreditFlag$ = VOUtils.write(out, fundAdjustmentDebitCreditFlag, 1); // 자금조정대차구분
		fundAdjustmentDifferenceAmount$ = VOUtils.write(out, fundAdjustmentDifferenceAmount, 15); // 자금조정차액
		feeSettlementDebitCreditFlag$ = VOUtils.write(out, feeSettlementDebitCreditFlag, 1); // 수수료정산대차구분
		feeSettlementAmount$ = VOUtils.write(out, feeSettlementAmount, 15); // 수수료정산금액
		differencePaymentDebitCreditFlag$ = VOUtils.write(out, differencePaymentDebitCreditFlag, 1); // 차액결제대차구분
		differencePaymentAmount$ = VOUtils.write(out, differencePaymentAmount, 15); // 차액결제금액
		filler2$ = VOUtils.write(out, filler2, 2); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		maturityENotePaymentDebitCreditFlag = VOUtils.toString(maturityENotePaymentDebitCreditFlag$ = VOUtils.read(in, 1)); // 만기전자어음결제대차구분
		maturityENotePaymentDifference = VOUtils.toLong(maturityENotePaymentDifference$ = VOUtils.read(in, 15)); // 만기전자어음결제차액
		defaultENotePaymentDebitCreditFlag = VOUtils.toString(defaultENotePaymentDebitCreditFlag$ = VOUtils.read(in, 1)); // 부도전자어음결제대차구분
		defaultENotePaymentDifference = VOUtils.toLong(defaultENotePaymentDifference$ = VOUtils.read(in, 15)); // 부도전자어음결제차액
		fundAdjustmentDebitCreditFlag = VOUtils.toString(fundAdjustmentDebitCreditFlag$ = VOUtils.read(in, 1)); // 자금조정대차구분
		fundAdjustmentDifferenceAmount = VOUtils.toLong(fundAdjustmentDifferenceAmount$ = VOUtils.read(in, 15)); // 자금조정차액
		feeSettlementDebitCreditFlag = VOUtils.toString(feeSettlementDebitCreditFlag$ = VOUtils.read(in, 1)); // 수수료정산대차구분
		feeSettlementAmount = VOUtils.toLong(feeSettlementAmount$ = VOUtils.read(in, 15)); // 수수료정산금액
		differencePaymentDebitCreditFlag = VOUtils.toString(differencePaymentDebitCreditFlag$ = VOUtils.read(in, 1)); // 차액결제대차구분
		differencePaymentAmount = VOUtils.toLong(differencePaymentAmount$ = VOUtils.read(in, 15)); // 차액결제금액
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 2)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", maturityENotePaymentDebitCreditFlag=").append(maturityENotePaymentDebitCreditFlag).append(System.lineSeparator()); // 만기전자어음결제대차구분
		sb.append(", maturityENotePaymentDifference=").append(maturityENotePaymentDifference).append(System.lineSeparator()); // 만기전자어음결제차액
		sb.append(", defaultENotePaymentDebitCreditFlag=").append(defaultENotePaymentDebitCreditFlag).append(System.lineSeparator()); // 부도전자어음결제대차구분
		sb.append(", defaultENotePaymentDifference=").append(defaultENotePaymentDifference).append(System.lineSeparator()); // 부도전자어음결제차액
		sb.append(", fundAdjustmentDebitCreditFlag=").append(fundAdjustmentDebitCreditFlag).append(System.lineSeparator()); // 자금조정대차구분
		sb.append(", fundAdjustmentDifferenceAmount=").append(fundAdjustmentDifferenceAmount).append(System.lineSeparator()); // 자금조정차액
		sb.append(", feeSettlementDebitCreditFlag=").append(feeSettlementDebitCreditFlag).append(System.lineSeparator()); // 수수료정산대차구분
		sb.append(", feeSettlementAmount=").append(feeSettlementAmount).append(System.lineSeparator()); // 수수료정산금액
		sb.append(", differencePaymentDebitCreditFlag=").append(differencePaymentDebitCreditFlag).append(System.lineSeparator()); // 차액결제대차구분
		sb.append(", differencePaymentAmount=").append(differencePaymentAmount).append(System.lineSeparator()); // 차액결제금액
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "maturityENotePaymentDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "maturityENotePaymentDifference", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "defaultENotePaymentDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "defaultENotePaymentDifference", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "fundAdjustmentDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "fundAdjustmentDifferenceAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "feeSettlementDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "feeSettlementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "differencePaymentDebitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "differencePaymentAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "2", "defltVal", "")
		);
	}

}
