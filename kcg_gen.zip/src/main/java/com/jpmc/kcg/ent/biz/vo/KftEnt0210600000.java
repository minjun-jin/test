package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 사고신고 조회 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 0210
 * bnkCd 은행코드 600000
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * userSort 이용자구분 
 * eNoteNumber 전자어음번호 
 * splitNumber 분할번호 
 * accidentReportStatus 사고신고여부 
 * accidentReportReceiptDateTime 사고신고접수일시 
 * accidentReportCancellationDateTime 사고신고취소일시 
 * 
 * KftEnt0210600000 kftEnt0210600000 = new KftEnt0210600000(); // 사고신고 조회 응답
 * kftEnt0210600000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210600000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210600000.setBnkCd("057"); // 은행코드
 * kftEnt0210600000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210600000.setTransactionCode("600000"); // 거래구분코드
 * kftEnt0210600000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210600000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210600000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210600000.setStatus("000"); // STATUS
 * kftEnt0210600000.setResponseCode1(""); // 응답코드1
 * kftEnt0210600000.setResponseCode2(""); // 응답코드2
 * kftEnt0210600000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210600000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210600000.setUserSort(""); // 이용자구분
 * kftEnt0210600000.setENoteNumber(""); // 전자어음번호
 * kftEnt0210600000.setSplitNumber(""); // 분할번호
 * kftEnt0210600000.setAccidentReportStatus(""); // 사고신고여부
 * kftEnt0210600000.setAccidentReportReceiptDateTime(LocalDateTime.now()); // 사고신고접수일시
 * kftEnt0210600000.setAccidentReportCancellationDateTime(LocalDateTime.now()); // 사고신고취소일시
 * }</pre>
 */
@Data
public class KftEnt0210600000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "600000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String userSort; // 이용자구분
	private String eNoteNumber; // 전자어음번호
	private String splitNumber; // 분할번호
	private String accidentReportStatus; // 사고신고여부
	private LocalDateTime accidentReportReceiptDateTime; // 사고신고접수일시
	private LocalDateTime accidentReportCancellationDateTime; // 사고신고취소일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String userSort$; // 이용자구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String splitNumber$; // 분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportStatus$; // 사고신고여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportReceiptDateTime$; // 사고신고접수일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String accidentReportCancellationDateTime$; // 사고신고취소일시

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(userSort$)) { // 이용자구분
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 14;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		userSort$ = VOUtils.write(out, userSort, 1); // 이용자구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		splitNumber$ = VOUtils.write(out, splitNumber, 2); // 분할번호
		accidentReportStatus$ = VOUtils.write(out, accidentReportStatus, 1); // 사고신고여부
		accidentReportReceiptDateTime$ = VOUtils.write(out, accidentReportReceiptDateTime, 14, "yyyyMMddHHmmss"); // 사고신고접수일시
		accidentReportCancellationDateTime$ = VOUtils.write(out, accidentReportCancellationDateTime, 14, "yyyyMMddHHmmss"); // 사고신고취소일시
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		userSort = VOUtils.toString(userSort$ = VOUtils.read(in, 1)); // 이용자구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // 분할번호
		accidentReportStatus = VOUtils.toString(accidentReportStatus$ = VOUtils.read(in, 1)); // 사고신고여부
		accidentReportReceiptDateTime = VOUtils.toLocalDateTime(accidentReportReceiptDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 사고신고접수일시
		accidentReportCancellationDateTime = VOUtils.toLocalDateTime(accidentReportCancellationDateTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 사고신고취소일시
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", userSort=").append(userSort).append(System.lineSeparator()); // 이용자구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // 분할번호
		sb.append(", accidentReportStatus=").append(accidentReportStatus).append(System.lineSeparator()); // 사고신고여부
		sb.append(", accidentReportReceiptDateTime=").append(accidentReportReceiptDateTime).append(System.lineSeparator()); // 사고신고접수일시
		sb.append(", accidentReportCancellationDateTime=").append(accidentReportCancellationDateTime).append(System.lineSeparator()); // 사고신고취소일시
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "600000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "userSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "accidentReportStatus", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "accidentReportReceiptDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "accidentReportCancellationDateTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss")
		);
	}

}
