package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 수령거부 및 반환요청 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0210
 * messageTrackingNumber 전문추적번호 300000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * refusalOfReceiptReturnSort 수령거부,반환구분 
 * issuanceEndorsementAftermaturedEndorsementSort 발행,배서,기한후배서구분 
 * refusalOfReceiptReturnRequestDate 수령거부,반환요청일자 
 * eNoteNumber 어음요건전자어음번호 
 * eNoteType 어음요건어음종류 
 * eNoteIssueDate 어음요건전자어음발행일자 
 * eNoteIssuePlace 어음요건전자어음발행지 
 * eNoteAmount 어음요건전자어음금액 
 * eNoteMaturedDate 어음요건전자어음만기일자 
 * paymentBankAndBranchCode 어음요건지급은행및지점코드 
 * otherPartyInfoCorpIndvSortCode 상대방정보법인개인구분코드 
 * otherPartyInfoResidentBusinessNumber 상대방정보주민사업자번호 
 * otherPartyInfoCorpName 상대방정보법인명 
 * otherPartyInfoNameRepresentativeName 상대방정보성명(대표자명) 
 * otherPartyInfoAddress 상대방정보주소 
 * otherPartyInfoBankCode 상대방정보은행코드 
 * otherPartyInfoCurrentAccountNumber 상대방정보당좌계좌번호 
 * requesterInfoCorpIndvSortCode 요청인정보법인개인구분코드 
 * requesterInfoResidentBusinessNumber 요청인정보주민사업자번호 
 * requesterInfoCorpName 요청인정보법인명 
 * requesterInfoNameRepresentativeName 요청인정보성명(대표자명) 
 * requesterInfoAddress 요청인정보주소 
 * requesterInfoBankCode 요청인정보은행코드 
 * requesterInfoRefusalOfReceiptAndReturnAmount 요청인정보수령거부및반환금액 
 * requesterInfoDepositAccountNumber 요청인정보입금계좌번호 
 * requesterInfoSplitNumber 요청인정보분할번호 
 * requesterInfoEndorsementNumber 요청인정보배서번호 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0210300000 kftEnt0210300000 = new KftEnt0210300000(); // 수령거부 및 반환요청 응답
 * kftEnt0210300000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210300000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210300000.setBnkCd("057"); // 은행코드
 * kftEnt0210300000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210300000.setTransactionCode("300000"); // 거래구분코드
 * kftEnt0210300000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210300000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0210300000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210300000.setStatus("000"); // STATUS
 * kftEnt0210300000.setResponseCode1(""); // 응답코드1
 * kftEnt0210300000.setResponseCode2(""); // 응답코드2
 * kftEnt0210300000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210300000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210300000.setRefusalOfReceiptReturnSort(""); // 수령거부,반환구분
 * kftEnt0210300000.setIssuanceEndorsementAftermaturedEndorsementSort(""); // 발행,배서,기한후배서구분
 * kftEnt0210300000.setRefusalOfReceiptReturnRequestDate(""); // 수령거부,반환요청일자
 * kftEnt0210300000.setENoteNumber(""); // 어음요건전자어음번호
 * kftEnt0210300000.setENoteType(""); // 어음요건어음종류
 * kftEnt0210300000.setENoteIssueDate(""); // 어음요건전자어음발행일자
 * kftEnt0210300000.setENoteIssuePlace(""); // 어음요건전자어음발행지
 * kftEnt0210300000.setENoteAmount(0L); // 어음요건전자어음금액
 * kftEnt0210300000.setENoteMaturedDate(""); // 어음요건전자어음만기일자
 * kftEnt0210300000.setPaymentBankAndBranchCode(""); // 어음요건지급은행및지점코드
 * kftEnt0210300000.setOtherPartyInfoCorpIndvSortCode(""); // 상대방정보법인개인구분코드
 * kftEnt0210300000.setOtherPartyInfoResidentBusinessNumber(""); // 상대방정보주민사업자번호
 * kftEnt0210300000.setOtherPartyInfoCorpName(""); // 상대방정보법인명
 * kftEnt0210300000.setOtherPartyInfoNameRepresentativeName(""); // 상대방정보성명(대표자명)
 * kftEnt0210300000.setOtherPartyInfoAddress(""); // 상대방정보주소
 * kftEnt0210300000.setOtherPartyInfoBankCode(""); // 상대방정보은행코드
 * kftEnt0210300000.setOtherPartyInfoCurrentAccountNumber(""); // 상대방정보당좌계좌번호
 * kftEnt0210300000.setRequesterInfoCorpIndvSortCode(""); // 요청인정보법인개인구분코드
 * kftEnt0210300000.setRequesterInfoResidentBusinessNumber(""); // 요청인정보주민사업자번호
 * kftEnt0210300000.setRequesterInfoCorpName(""); // 요청인정보법인명
 * kftEnt0210300000.setRequesterInfoNameRepresentativeName(""); // 요청인정보성명(대표자명)
 * kftEnt0210300000.setRequesterInfoAddress(""); // 요청인정보주소
 * kftEnt0210300000.setRequesterInfoBankCode(""); // 요청인정보은행코드
 * kftEnt0210300000.setRequesterInfoRefusalOfReceiptAndReturnAmount(""); // 요청인정보수령거부및반환금액
 * kftEnt0210300000.setRequesterInfoDepositAccountNumber(""); // 요청인정보입금계좌번호
 * kftEnt0210300000.setRequesterInfoSplitNumber(""); // 요청인정보분할번호
 * kftEnt0210300000.setRequesterInfoEndorsementNumber(""); // 요청인정보배서번호
 * kftEnt0210300000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0210300000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0210300000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "300000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String refusalOfReceiptReturnSort; // 수령거부,반환구분
	private String issuanceEndorsementAftermaturedEndorsementSort; // 발행,배서,기한후배서구분
	private String refusalOfReceiptReturnRequestDate; // 수령거부,반환요청일자
	private String eNoteNumber; // 어음요건전자어음번호
	private String eNoteType; // 어음요건어음종류
	private String eNoteIssueDate; // 어음요건전자어음발행일자
	private String eNoteIssuePlace; // 어음요건전자어음발행지
	private long eNoteAmount; // 어음요건전자어음금액
	private String eNoteMaturedDate; // 어음요건전자어음만기일자
	private String paymentBankAndBranchCode; // 어음요건지급은행및지점코드
	private String otherPartyInfoCorpIndvSortCode; // 상대방정보법인개인구분코드
	private String otherPartyInfoResidentBusinessNumber; // 상대방정보주민사업자번호
	private String otherPartyInfoCorpName; // 상대방정보법인명
	private String otherPartyInfoNameRepresentativeName; // 상대방정보성명(대표자명)
	private String otherPartyInfoAddress; // 상대방정보주소
	private String otherPartyInfoBankCode; // 상대방정보은행코드
	private String otherPartyInfoCurrentAccountNumber; // 상대방정보당좌계좌번호
	private String requesterInfoCorpIndvSortCode; // 요청인정보법인개인구분코드
	private String requesterInfoResidentBusinessNumber; // 요청인정보주민사업자번호
	private String requesterInfoCorpName; // 요청인정보법인명
	private String requesterInfoNameRepresentativeName; // 요청인정보성명(대표자명)
	private String requesterInfoAddress; // 요청인정보주소
	private String requesterInfoBankCode; // 요청인정보은행코드
	private String requesterInfoRefusalOfReceiptAndReturnAmount; // 요청인정보수령거부및반환금액
	private String requesterInfoDepositAccountNumber; // 요청인정보입금계좌번호
	private String requesterInfoSplitNumber; // 요청인정보분할번호
	private String requesterInfoEndorsementNumber; // 요청인정보배서번호
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptReturnSort$; // 수령거부,반환구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceEndorsementAftermaturedEndorsementSort$; // 발행,배서,기한후배서구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptReturnRequestDate$; // 수령거부,반환요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음요건전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음요건어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음요건전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음요건전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음요건전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음요건전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음요건지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCorpIndvSortCode$; // 상대방정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoResidentBusinessNumber$; // 상대방정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCorpName$; // 상대방정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoNameRepresentativeName$; // 상대방정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoAddress$; // 상대방정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoBankCode$; // 상대방정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCurrentAccountNumber$; // 상대방정보당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoCorpIndvSortCode$; // 요청인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoResidentBusinessNumber$; // 요청인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoCorpName$; // 요청인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoNameRepresentativeName$; // 요청인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoAddress$; // 요청인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoBankCode$; // 요청인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoRefusalOfReceiptAndReturnAmount$; // 요청인정보수령거부및반환금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoDepositAccountNumber$; // 요청인정보입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoSplitNumber$; // 요청인정보분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoEndorsementNumber$; // 요청인정보배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceEndorsementAftermaturedEndorsementSort$)) { // 발행,배서,기한후배서구분
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음요건전자어음번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(otherPartyInfoResidentBusinessNumber$)) { // 상대방정보주민사업자번호
			return 24;
		}
		if (VOUtils.isNotAlphanumericSpace(otherPartyInfoCurrentAccountNumber$)) { // 상대방정보당좌계좌번호
			return 29;
		}
		if (VOUtils.isNotAlphanumericSpace(requesterInfoResidentBusinessNumber$)) { // 요청인정보주민사업자번호
			return 31;
		}
		if (VOUtils.isNotAlphanumericSpace(requesterInfoRefusalOfReceiptAndReturnAmount$)) { // 요청인정보수령거부및반환금액
			return 36;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		refusalOfReceiptReturnSort$ = VOUtils.write(out, refusalOfReceiptReturnSort, 1); // 수령거부,반환구분
		issuanceEndorsementAftermaturedEndorsementSort$ = VOUtils.write(out, issuanceEndorsementAftermaturedEndorsementSort, 1); // 발행,배서,기한후배서구분
		refusalOfReceiptReturnRequestDate$ = VOUtils.write(out, refusalOfReceiptReturnRequestDate, 8); // 수령거부,반환요청일자
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음요건전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음요건어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음요건전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음요건전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음요건전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음요건전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음요건지급은행및지점코드
		otherPartyInfoCorpIndvSortCode$ = VOUtils.write(out, otherPartyInfoCorpIndvSortCode, 1); // 상대방정보법인개인구분코드
		otherPartyInfoResidentBusinessNumber$ = VOUtils.write(out, otherPartyInfoResidentBusinessNumber, 13); // 상대방정보주민사업자번호
		otherPartyInfoCorpName$ = VOUtils.write(out, otherPartyInfoCorpName, 40, "EUC-KR"); // 상대방정보법인명
		otherPartyInfoNameRepresentativeName$ = VOUtils.write(out, otherPartyInfoNameRepresentativeName, 20, "EUC-KR"); // 상대방정보성명(대표자명)
		otherPartyInfoAddress$ = VOUtils.write(out, otherPartyInfoAddress, 60, "EUC-KR"); // 상대방정보주소
		otherPartyInfoBankCode$ = VOUtils.write(out, otherPartyInfoBankCode, 3); // 상대방정보은행코드
		otherPartyInfoCurrentAccountNumber$ = VOUtils.write(out, otherPartyInfoCurrentAccountNumber, 16); // 상대방정보당좌계좌번호
		requesterInfoCorpIndvSortCode$ = VOUtils.write(out, requesterInfoCorpIndvSortCode, 1); // 요청인정보법인개인구분코드
		requesterInfoResidentBusinessNumber$ = VOUtils.write(out, requesterInfoResidentBusinessNumber, 13); // 요청인정보주민사업자번호
		requesterInfoCorpName$ = VOUtils.write(out, requesterInfoCorpName, 40, "EUC-KR"); // 요청인정보법인명
		requesterInfoNameRepresentativeName$ = VOUtils.write(out, requesterInfoNameRepresentativeName, 20, "EUC-KR"); // 요청인정보성명(대표자명)
		requesterInfoAddress$ = VOUtils.write(out, requesterInfoAddress, 60, "EUC-KR"); // 요청인정보주소
		requesterInfoBankCode$ = VOUtils.write(out, requesterInfoBankCode, 3); // 요청인정보은행코드
		requesterInfoRefusalOfReceiptAndReturnAmount$ = VOUtils.write(out, requesterInfoRefusalOfReceiptAndReturnAmount, 15); // 요청인정보수령거부및반환금액
		requesterInfoDepositAccountNumber$ = VOUtils.write(out, requesterInfoDepositAccountNumber, 16); // 요청인정보입금계좌번호
		requesterInfoSplitNumber$ = VOUtils.write(out, requesterInfoSplitNumber, 2); // 요청인정보분할번호
		requesterInfoEndorsementNumber$ = VOUtils.write(out, requesterInfoEndorsementNumber, 2); // 요청인정보배서번호
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		refusalOfReceiptReturnSort = VOUtils.toString(refusalOfReceiptReturnSort$ = VOUtils.read(in, 1)); // 수령거부,반환구분
		issuanceEndorsementAftermaturedEndorsementSort = VOUtils.toString(issuanceEndorsementAftermaturedEndorsementSort$ = VOUtils.read(in, 1)); // 발행,배서,기한후배서구분
		refusalOfReceiptReturnRequestDate = VOUtils.toString(refusalOfReceiptReturnRequestDate$ = VOUtils.read(in, 8)); // 수령거부,반환요청일자
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음요건전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음요건어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음요건전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음요건전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음요건전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음요건전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음요건지급은행및지점코드
		otherPartyInfoCorpIndvSortCode = VOUtils.toString(otherPartyInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상대방정보법인개인구분코드
		otherPartyInfoResidentBusinessNumber = VOUtils.toString(otherPartyInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상대방정보주민사업자번호
		otherPartyInfoCorpName = VOUtils.toString(otherPartyInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상대방정보법인명
		otherPartyInfoNameRepresentativeName = VOUtils.toString(otherPartyInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상대방정보성명(대표자명)
		otherPartyInfoAddress = VOUtils.toString(otherPartyInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상대방정보주소
		otherPartyInfoBankCode = VOUtils.toString(otherPartyInfoBankCode$ = VOUtils.read(in, 3)); // 상대방정보은행코드
		otherPartyInfoCurrentAccountNumber = VOUtils.toString(otherPartyInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // 상대방정보당좌계좌번호
		requesterInfoCorpIndvSortCode = VOUtils.toString(requesterInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 요청인정보법인개인구분코드
		requesterInfoResidentBusinessNumber = VOUtils.toString(requesterInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 요청인정보주민사업자번호
		requesterInfoCorpName = VOUtils.toString(requesterInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 요청인정보법인명
		requesterInfoNameRepresentativeName = VOUtils.toString(requesterInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 요청인정보성명(대표자명)
		requesterInfoAddress = VOUtils.toString(requesterInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 요청인정보주소
		requesterInfoBankCode = VOUtils.toString(requesterInfoBankCode$ = VOUtils.read(in, 3)); // 요청인정보은행코드
		requesterInfoRefusalOfReceiptAndReturnAmount = VOUtils.toString(requesterInfoRefusalOfReceiptAndReturnAmount$ = VOUtils.read(in, 15)); // 요청인정보수령거부및반환금액
		requesterInfoDepositAccountNumber = VOUtils.toString(requesterInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // 요청인정보입금계좌번호
		requesterInfoSplitNumber = VOUtils.toString(requesterInfoSplitNumber$ = VOUtils.read(in, 2)); // 요청인정보분할번호
		requesterInfoEndorsementNumber = VOUtils.toString(requesterInfoEndorsementNumber$ = VOUtils.read(in, 2)); // 요청인정보배서번호
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", refusalOfReceiptReturnSort=").append(refusalOfReceiptReturnSort).append(System.lineSeparator()); // 수령거부,반환구분
		sb.append(", issuanceEndorsementAftermaturedEndorsementSort=").append(issuanceEndorsementAftermaturedEndorsementSort).append(System.lineSeparator()); // 발행,배서,기한후배서구분
		sb.append(", refusalOfReceiptReturnRequestDate=").append(refusalOfReceiptReturnRequestDate).append(System.lineSeparator()); // 수령거부,반환요청일자
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음요건전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음요건어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음요건전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음요건전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음요건전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음요건전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음요건지급은행및지점코드
		sb.append(", otherPartyInfoCorpIndvSortCode=").append(otherPartyInfoCorpIndvSortCode).append(System.lineSeparator()); // 상대방정보법인개인구분코드
		sb.append(", otherPartyInfoResidentBusinessNumber=").append(otherPartyInfoResidentBusinessNumber).append(System.lineSeparator()); // 상대방정보주민사업자번호
		sb.append(", otherPartyInfoCorpName=").append(otherPartyInfoCorpName).append(System.lineSeparator()); // 상대방정보법인명
		sb.append(", otherPartyInfoNameRepresentativeName=").append(otherPartyInfoNameRepresentativeName).append(System.lineSeparator()); // 상대방정보성명(대표자명)
		sb.append(", otherPartyInfoAddress=").append(otherPartyInfoAddress).append(System.lineSeparator()); // 상대방정보주소
		sb.append(", otherPartyInfoBankCode=").append(otherPartyInfoBankCode).append(System.lineSeparator()); // 상대방정보은행코드
		sb.append(", otherPartyInfoCurrentAccountNumber=").append(otherPartyInfoCurrentAccountNumber).append(System.lineSeparator()); // 상대방정보당좌계좌번호
		sb.append(", requesterInfoCorpIndvSortCode=").append(requesterInfoCorpIndvSortCode).append(System.lineSeparator()); // 요청인정보법인개인구분코드
		sb.append(", requesterInfoResidentBusinessNumber=").append(requesterInfoResidentBusinessNumber).append(System.lineSeparator()); // 요청인정보주민사업자번호
		sb.append(", requesterInfoCorpName=").append(requesterInfoCorpName).append(System.lineSeparator()); // 요청인정보법인명
		sb.append(", requesterInfoNameRepresentativeName=").append(requesterInfoNameRepresentativeName).append(System.lineSeparator()); // 요청인정보성명(대표자명)
		sb.append(", requesterInfoAddress=").append(requesterInfoAddress).append(System.lineSeparator()); // 요청인정보주소
		sb.append(", requesterInfoBankCode=").append(requesterInfoBankCode).append(System.lineSeparator()); // 요청인정보은행코드
		sb.append(", requesterInfoRefusalOfReceiptAndReturnAmount=").append(requesterInfoRefusalOfReceiptAndReturnAmount).append(System.lineSeparator()); // 요청인정보수령거부및반환금액
		sb.append(", requesterInfoDepositAccountNumber=").append(requesterInfoDepositAccountNumber).append(System.lineSeparator()); // 요청인정보입금계좌번호
		sb.append(", requesterInfoSplitNumber=").append(requesterInfoSplitNumber).append(System.lineSeparator()); // 요청인정보분할번호
		sb.append(", requesterInfoEndorsementNumber=").append(requesterInfoEndorsementNumber).append(System.lineSeparator()); // 요청인정보배서번호
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "300000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptReturnSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceEndorsementAftermaturedEndorsementSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptReturnRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "otherPartyInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "otherPartyInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "otherPartyInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "otherPartyInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "requesterInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "requesterInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "requesterInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "requesterInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "requesterInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requesterInfoRefusalOfReceiptAndReturnAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "requesterInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterInfoSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "requesterInfoEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
