package com.jpmc.kcg.com.biz;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.quartz.CronExpression;
import org.quartz.CronScheduleBuilder;
import org.quartz.CronTrigger;
import org.quartz.JobBuilder;
import org.quartz.JobDataMap;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerBuilder;
import org.quartz.TriggerKey;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.bat.enums.BatDtDvsnCdEnum;
import com.jpmc.kcg.bat.enums.BatSchdDvsnCdEnum;
import com.jpmc.kcg.com.ComQuartzJob;
import com.jpmc.kcg.com.dao.ComDateMDao;
import com.jpmc.kcg.com.dao.ComDateMMapper;
import com.jpmc.kcg.com.dto.ComDateM;
import com.jpmc.kcg.com.exception.BusinessException;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwTractId;
import com.jpmc.kcg.frw.bat.enums.BatCmpltStsCdEnum;
import com.jpmc.kcg.frw.dao.FrwBatExtDao;
import com.jpmc.kcg.frw.dao.FrwBatRsltLMapper;
import com.jpmc.kcg.frw.dao.FrwBatWorkMMapper;
import com.jpmc.kcg.frw.dto.FrwBatRsltL;
import com.jpmc.kcg.frw.dto.FrwBatWorkM;

import lombok.extern.slf4j.Slf4j;

/**
 * Quartz schedule 을 등록/변경/삭제 하는 기능 제공
 * 즉시 실행, 재실행 시에는 배치작업결과 테이블에도 WAITTING 상태로 데이터 생성합니다.
 * 
 * 참고(좀 더 자세한 설명은 {@link org.quartz.CronExpression} 확인하세요.)
 * Cron 표현식 
 * Seconds Minutes Hours Day-of-Month Month Day-of-Week Year(optional field)
 */

@Slf4j
@Component
public class BatScheduleBean {
	private final static Pattern CRON_PATTERN = Pattern.compile("[0-9\\*\\/\\?\\-\\,]+ [0-9\\*\\/\\?\\-\\,]+ [0-9\\*\\/\\?\\-\\,]+ (.*$)");
	private static final Pattern PATTERN_WHITESPACE = Pattern.compile("[\t\s]+");
	private static final String TRGR_PREFIX = "TRG_";
	private static final String SMPL_TRGR_PREFIX = "SMP_";
	private static final String PARAM_DELIMETER = ",";
	private static final int RIGHT_NOW_DELAY_MINUTES = 1;
	private static final String PARAM_VALUE_DELIMETER = "=";
	private static final String DATETIME_FORMAT = "yyyyMMddHHmmss";
	private static final String DATE_FORMAT = "yyyyMMdd";
	private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern(DATE_FORMAT);

	private static final Class<ComQuartzJob> JOB_CLASS = com.jpmc.kcg.com.ComQuartzJob.class;
	
	private final BizDate bizDate;
	private final ComDateMDao comDateMDao;
	private final ComDateMMapper comDateMMapper;
	private final FrwBatExtDao frwBatExtDao;
	private final FrwBatRsltLMapper frwBatRsltLMapper;
	private final FrwBatWorkMMapper frwBatWorkMMapper;
	private final FrwTractId frwTractId;
	private final Scheduler scheduler;
	
	public BatScheduleBean(BizDate bizDate, ComDateMDao comDateMDao, ComDateMMapper comDateMMapper, FrwBatExtDao frwBatExtDao, FrwBatRsltLMapper frwBatRsltLMapper, FrwBatWorkMMapper frwBatWorkMMapper, FrwTractId frwTractId, Scheduler scheduler) {
		this.bizDate = bizDate;
		this.comDateMDao = comDateMDao;
		this.comDateMMapper = comDateMMapper;
		this.frwBatExtDao = frwBatExtDao;
		this.frwBatRsltLMapper = frwBatRsltLMapper;
		this.frwBatWorkMMapper = frwBatWorkMMapper;
		this.frwTractId = frwTractId;
		this.scheduler = scheduler;
	}

	/**
	 * Cron 스케줄을 등록한다.
	 * 
	 * @param frwBatWorkM
	 * @return
	 */
	public JobDetail addJobWithCronExpr(FrwBatWorkM frwBatWorkM)  {		
		 JobDetail job = null;
		try {
			// Job 생성
	        job = makeJob(frwBatWorkM);

	        // Trigger 생성
	        Trigger trigger = makeTrigger(frwBatWorkM);
	        
	        if (null == trigger) {
	        	// Job 만 등록함
	        	scheduler.addJob(job, false);
	        } else {
		        // 스케줄러 생성 및 Job, Trigger 등록
		        scheduler.scheduleJob(job, trigger);
	        }
		} catch (Exception e) {
			throw new BusinessException("MCMNE11007", e, frwBatWorkM.getBizDvsnCd(), frwBatWorkM.getBatWrkId());
		}
		return job;
	}
	
	/**
	 * Cron 스케줄을 변경 등록한다.
	 * 
	 * @param bfrFrwBatWorkM
	 * @param aftFrwBatWorkM
	 * @return
	 */
	public JobDetail modifyJobWithCronExpr(FrwBatWorkM bfrFrwBatWorkM, FrwBatWorkM aftFrwBatWorkM)  {
		JobDetail jobDetail = null;	
		try {

			if (! aftFrwBatWorkM.getUseYn().equals(bfrFrwBatWorkM.getUseYn())) {
				//DESC  UseYN 컬럼 변경 시
			
				if ("N".equals(aftFrwBatWorkM.getUseYn())) {
					//DESC useYN Y to N 변경 시, 스케쥴 삭제
					JobKey bfrJobKey = makeJobKey(bfrFrwBatWorkM.getBatWrkId(), bfrFrwBatWorkM.getBizDvsnCd());
					scheduler.deleteJob(bfrJobKey);					
					return null;
				} else {
					// 이행으로 데이터 일관성이 유지되지 못하는 경우가 있어 deleteJob을 먼저 수행함.
					JobKey bfrJobKey = makeJobKey(bfrFrwBatWorkM.getBatWrkId(), bfrFrwBatWorkM.getBizDvsnCd());
					scheduler.deleteJob(bfrJobKey);
					
					//DESC useYN N to Y 변경 시, 스케쥴 생성
					jobDetail = addJobWithCronExpr(aftFrwBatWorkM);
					return jobDetail;
				}
			} else if (! aftFrwBatWorkM.getBizDvsnCd().equals(bfrFrwBatWorkM.getBizDvsnCd()) 
					|| ! aftFrwBatWorkM.getSchdDvsnCd().equals(bfrFrwBatWorkM.getSchdDvsnCd())
					|| ! StringUtils.trimToEmpty(bfrFrwBatWorkM.getParmVal()).equals(StringUtils.trimToEmpty(bfrFrwBatWorkM.getParmVal()))
					
					) {
				//DESC 업무유형코드, 스케줄구분코드, param 변경 시 기존 job 삭제 후 신규 schedule 등록
				JobKey bfrJobKey = makeJobKey(bfrFrwBatWorkM.getBatWrkId(), bfrFrwBatWorkM.getBizDvsnCd());
				
				scheduler.deleteJob(bfrJobKey);
				
				jobDetail = addJobWithCronExpr(aftFrwBatWorkM);
				
				return jobDetail;
			} else {
				JobKey jobKey = makeJobKey(aftFrwBatWorkM.getBatWrkId(), aftFrwBatWorkM.getBizDvsnCd());
				jobDetail = scheduler.getJobDetail(jobKey);
				if (null == jobDetail) {
					jobDetail = addJobWithCronExpr(aftFrwBatWorkM);
					return jobDetail;
				} else if (! StringUtils.trimToEmpty(aftFrwBatWorkM.getCronCmd()).equals(StringUtils.trimToEmpty(bfrFrwBatWorkM.getCronCmd()))) {
					//DESC cron 표현식 변경 시 기존 job 삭제 후 신규 schedule 등록
					replaceCronTrigger(aftFrwBatWorkM, jobDetail);
				}
			}
			
		} catch (Exception e) {
			throw new BusinessException("MCMNE11007", e, aftFrwBatWorkM.getBizDvsnCd(), aftFrwBatWorkM.getBatWrkId());
		}
		return jobDetail;
	}
	
	/**
	 * 주어진 시간 startAt에 실행되도록 스케줄 트리거 등록한다.
	 * @param batWrkId
	 * @param bizDvsnCd
	 * @param overwriteJobDataMap
	 * @param startAt
	 */
	public void runTrigger(String batWrkId, String batRsltId, String bizDvsnCd, Map<String,Object> overwriteJobDataMap, Date startAt) {
		JobKey jobKey = makeJobKey(batWrkId, bizDvsnCd);		
		try {			
			JobDetail jobDetail = scheduler.getJobDetail(jobKey);
			
			// start now trigger
			// SimpleTrigger는 name 생성.
			TriggerKey triggerKey = new TriggerKey(makeSimpleTriggerName(batWrkId, batRsltId), bizDvsnCd);
			Trigger trigger = TriggerBuilder.newTrigger()
					.withIdentity(triggerKey)
					.startAt(startAt)
					.usingJobData(new JobDataMap(overwriteJobDataMap))
					.forJob(jobDetail)
					.build();
	       
	        Date fd = scheduler.rescheduleJob(triggerKey, trigger);
	        
	        // 기존 Trigger가 없을 경우 null 이 반환되므로 신규로 등록
	        if (null == fd) {
	        	scheduler.scheduleJob(trigger);
	        }
		} catch (Exception e) {
			throw new BusinessException("MCMNE11007", e, bizDvsnCd, batWrkId);
		}
	}
	
	/**
	 * 배치스케줄에 스케줄 트리거를 등록한다.
	 * @param batWrkId
	 * @param bizDvsnCd
	 * @param overwriteJobDataMap
	 * @param yyyyMMddHHmmss
	 */
	public void runTriggerAtStartDttm(String batWrkId, String batRsltId, String bizDvsnCd, Map<String,Object> overwriteJobDataMap, String yyyyMMddHHmmss) {
        SimpleDateFormat dateformat = new SimpleDateFormat(DATETIME_FORMAT);
        try {
            runTrigger(batWrkId, batRsltId, bizDvsnCd, overwriteJobDataMap, dateformat.parse(yyyyMMddHHmmss));
        } catch (ParseException e) {
            throw new BusinessException("MCMNE11005", e, yyyyMMddHHmmss);
        }
	}

    /**
     * 배치스케줄에 등록된 스케줄 트리거를 제거한다.
     * @param batWrkId
     * @param batRsltId
     * @param bizDvsnCd
     */
    public void cancelTrigger(String batWrkId, String batRsltId, String bizDvsnCd) {
        TriggerKey triggerKey = new TriggerKey(makeSimpleTriggerName(batWrkId, batRsltId), bizDvsnCd);
        try {
            boolean isTriggerRemoved = scheduler.unscheduleJob(triggerKey);

            if (!isTriggerRemoved) {
                throw new Exception("Failed to unschedule trigger: " + triggerKey);
            }

        } catch (Exception e) {
            throw new BusinessException("MCMNE06016", e);
        }
    }
	
	/**
	 * 배치작업을 주어진 시간yyyyMMddHHmmss에 실행한다.
	 * 배치작업결과를 대기상태로 등록하고 스케줄에 주어진 시간startDatetime에 실행하도록 등록한다.
	 * @param batWrkId
	 * @param bizDvsnCd  배치의 업무구분코드. (Option)
	 * @param ordDt      배치작업의 order date. null 이면 today로 설정(Option)
	 * @param overwriteJobDataMap  배치작업의 Parameter Map. null이면 배치작업정보의 파라메터로 대체됨.
	 * @param startDatetime	배치작업 시작시간. null 이면 1분 후 즉시 실행.
	 */
	public FrwBatRsltL runJobAtStartDatetime(String batWrkId, String bizDvsnCd, String ordDt, Map<String,Object> overwriteJobDataMap, Date startDatetime, Date endDatetime) {
		FrwBatWorkM frwBatWorkM = frwBatWorkMMapper.selectByPrimaryKey(batWrkId);

		return runJobAtStartDatetime(frwBatWorkM, ordDt, overwriteJobDataMap, startDatetime, endDatetime);
	}
	
	public FrwBatRsltL runJobAtStartDatetime(FrwBatWorkM frwBatWorkM, String ordDt, Map<String,Object> overwriteJobDataMap, Date startDatetime, Date endDatetime) {
		
		if (null == ordDt) {
			// 입력 ordDt == null 인 경우 today 로 설정
			ordDt = LocalDate.now().format(DATE_FORMATTER);
		}
		
		// JobDataMap 이 null 이면, 배치 기본 정보의 파라메터 설정
		if (null == overwriteJobDataMap) {
			overwriteJobDataMap = parseParmVal(frwBatWorkM.getParmVal());
		}
		
		// 시작시간이 null 이면, 1분 후로 시작시간 설정
		if (null == startDatetime) {
			Calendar rightNow = Calendar.getInstance();
			rightNow.add(Calendar.MINUTE, RIGHT_NOW_DELAY_MINUTES);
			startDatetime = rightNow.getTime();
		}
		
		if (null == endDatetime) {
			Calendar rightNow = Calendar.getInstance();
			rightNow.setTime(startDatetime);
			rightNow.add(Calendar.HOUR, 1);
			endDatetime = rightNow.getTime();
		}
		
		// 대기상태의 배치작업결과 등록
		FrwBatRsltL frwBatRsltL = registerBatRsltLAsWait(frwBatWorkM, ordDt, overwriteJobDataMap, startDatetime, endDatetime);
		
		// 스케줄에 등록
		runTrigger(frwBatWorkM.getBatWrkId(), frwBatRsltL.getBatRsltId(), frwBatWorkM.getBizDvsnCd(), overwriteJobDataMap, startDatetime);
		
		return frwBatRsltL;
	}
	
//	/**
//	 * 배치작업을 주어진 시간yyyyMMddHHmmss에 실행한다.
//	 * 배치작업결과를 대기상태로 등록하고 스케줄에 주어진 yyyyMMddHHmmss에 실행하도록 등록한다.
//	 * @param batWrkId
//	 * @param bizDvsnCd
//	 * @param ordDt
//	 * @param overwriteJobDataMap
//	 * @param startDttm
//	 */
//	public void runJobAtStartDttm(String batWrkId, String bizDvsnCd, String ordDt, Map<String,Object> overwriteJobDataMap, String startDttm, String endDttm) {
//		SimpleDateFormat dateformat = new SimpleDateFormat(DATETIME_FORMAT);
//		try {
//			runJobAtStartDatetime(batWrkId, bizDvsnCd, ordDt, overwriteJobDataMap, dateformat.parse(startDttm), null);
//		} catch (Exception e) {
//			throw new BusinessException("MCMNE09004", e, startDttm);
//		}
//	}
	
//	/**
//	 * 배치작업을 즉시 실행한다.
//	 * 배치작업결과를 대기상태로 등록하고 스케줄에 즉시 실행으로 등록한다.
//	 * 
//	 * @param batWrkId
//	 * @param bizDvsnCd
//	 * @param ordDt
//	 * @param overwriteJobDataMap
//	 */
//	public void runJobNow(String batWrkId, String bizDvsnCd, String ordDt, Map<String,Object> overwriteJobDataMap) {
//		
//		runJobAtStartDatetime(batWrkId, bizDvsnCd, ordDt, overwriteJobDataMap, null);
//		
//	}
	
	/**
	 * 실패 작업에 대하여 즉시 재실행.
	 * 
	 * @param batWrkId
	 * @param bizDvsnCd
	 * @param ordDt
	 * @param parmVal
	 */
	public FrwBatRsltL runJobNow(String batWrkId, String bizDvsnCd, String ordDt, String parmVal) {
		
		// 기존 배치작업결과의 파라메터 유지
		Map<String,Object> overwriteJobDataMap = parseParmVal(parmVal);
		
		//배치작업 즉시 재실행
		return runJobAtStartDatetime(batWrkId, bizDvsnCd, ordDt, overwriteJobDataMap,  new Date(), null);
		
	}
	
	/**
	 * 배치작업 실행.
	 * ODATE가 오늘로 배치작업을 즉시 실행
	 * 
	 * @param batWrkId
	 */
	public FrwBatRsltL runJobNow(String batWrkId) {
		
		//배치작업 즉시 재실행
		return runJobAtStartDatetime(batWrkId, null, null, null, new Date(), null);
		
	}	

	private FrwBatRsltL registerBatRsltLAsWait(FrwBatWorkM frwBatWorkM, String ordDt, Map<String,Object> overwriteJobDataMap, Date startTm, Date endTm) {
		FrwContext frwContext = FrwContextHolder.getContext();
		   
        // 신규 BAT_RSLT_ID를 채번하고 설정한다.
        String newBatRsltId = frwTractId.newTractId(LocalDateTime.now());     
        overwriteJobDataMap.put("BAT_RSLT_ID", newBatRsltId);
        
        // ODATE가 미설정 시 설정한다. 존재하면 기존 유지
        if (! overwriteJobDataMap.containsKey("ODATE")) {
        	overwriteJobDataMap.put("ODATE", ordDt);
        }
        
        // TRACT_DT가 미설정 시 설정한다. 존재하면 기존 유지
        if (! overwriteJobDataMap.containsKey("TRACT_DT")) {
            String tractDt = null;
            LocalDate localOrdDt = LocalDate.parse(ordDt, DATE_FORMATTER);
            //일자구분코드가 not blank인 경우, 거래일자를 구한다
            if (StringUtils.isNotBlank(frwBatWorkM.getDtDvsnCd())) {
            	tractDt = getTractDt(frwBatWorkM, ordDt, localOrdDt);
            }
            if (StringUtils.isEmpty(tractDt)) {
                tractDt = ordDt;
            }
        	overwriteJobDataMap.put("TRACT_DT", tractDt);
        }
        
        SimpleDateFormat dateformat = new SimpleDateFormat(DATETIME_FORMAT);
        
        FrwBatRsltL frwBatRsltL = new FrwBatRsltL();
        frwBatRsltL.setOrdDt(ordDt);
        frwBatRsltL.setPlnStaTm(dateformat.format(startTm));
        frwBatRsltL.setPlnEndTm(dateformat.format(endTm));
        frwBatRsltL.setBatRsltId(newBatRsltId);
        frwBatRsltL.setBatWrkId(frwBatWorkM.getBatWrkId());
        frwBatRsltL.setBatSysDvsn(frwContext.getEnvCd());
        frwBatRsltL.setParmVal(toStringJobDataMap(overwriteJobDataMap));
		frwBatRsltL.setTrgtCnt(0L);
		frwBatRsltL.setReadCnt(0L);
		frwBatRsltL.setWriteCnt(0L);
		frwBatRsltL.setSkipCnt(0L);
        frwBatRsltL.setCmpltStsCd(BatCmpltStsCdEnum.WAITING.getValue()); //배치작업상태 : 대기

        // 배치작업결과 테이블에 한건 복제(배치작업상태만 실행중으로 둔다.)
        frwBatRsltLMapper.insert(frwBatRsltL);
        
        return frwBatRsltL;
	}
	
	private JobKey makeJobKey(String name, String group) {
		return new JobKey(name, group);
	}
	
	private JobDetail makeJob(FrwBatWorkM frwBatWorkM) {
		// Job 생성
		JobKey jobKey = makeJobKey(frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd());
        JobDetail newJobDetail = JobBuilder.newJob(JOB_CLASS)
            .withIdentity(jobKey)
            .storeDurably(true)
            .usingJobData(getJobDataMap(frwBatWorkM))
            .build();
		return newJobDetail;
	}
	
	private Trigger makeTrigger(FrwBatWorkM frwBatWorkM) {
		if (StringUtils.isEmpty(frwBatWorkM.getCronCmd())) {
			//DESC Cron 이 아니면 Trigger 생성하지 않음.
			return null;
		}
		Trigger trigger = TriggerBuilder.newTrigger()
	    		.withIdentity(TRGR_PREFIX + frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd())
	    		.usingJobData(getJobDataMap(frwBatWorkM))
	    	    .withSchedule(CronScheduleBuilder.cronSchedule(frwBatWorkM.getCronCmd()))
	    	    .build();
		return trigger;
	}
	
	private Trigger replaceCronTrigger(FrwBatWorkM frwBatWorkM, JobDetail jobDetail) throws SchedulerException {
		TriggerKey triggerKey = new TriggerKey(TRGR_PREFIX + frwBatWorkM.getBatWrkId(), frwBatWorkM.getBizDvsnCd());
		Trigger oldTrigger = scheduler.getTrigger(triggerKey);
		Trigger newTrigger = oldTrigger;
		if (StringUtils.isEmpty(frwBatWorkM.getCronCmd())) {
			//Job 만 등록하고 Trigger는 등록하지 않음.
			return null;
		} else if (null == oldTrigger) {
			
			// Trigger 생성
			newTrigger = TriggerBuilder.newTrigger()
	    		.withIdentity(triggerKey)
	    		.usingJobData(getJobDataMap(frwBatWorkM))
	    	    .withSchedule(CronScheduleBuilder.cronSchedule(frwBatWorkM.getCronCmd()))
	    	    .forJob(jobDetail)
	    	    .build();
	        scheduler.scheduleJob(newTrigger);
	        
		} else if (oldTrigger instanceof CronTrigger) {
			
			String oldCronExpression = PATTERN_WHITESPACE.matcher(((CronTrigger)oldTrigger).getCronExpression()).replaceAll(StringUtils.EMPTY);
			String newCronExpression = PATTERN_WHITESPACE.matcher(frwBatWorkM.getCronCmd()).replaceAll(StringUtils.EMPTY);
			
			if (!oldCronExpression.equals(newCronExpression)) {
				// Trigger 생성
				newTrigger = TriggerBuilder.newTrigger()
		    		.withIdentity(triggerKey)
		    		.usingJobData(oldTrigger.getJobDataMap())
		    	    .withSchedule(CronScheduleBuilder.cronSchedule(frwBatWorkM.getCronCmd()))
		    	    .build();
		        scheduler.rescheduleJob(triggerKey, newTrigger);
			}
			
		} else {
			// SimpleTrigger
		}
		
		return newTrigger;
	}
	
	/**
	 * 이미 등록된 simple trigger의 시간을 조정할 경우 해당 trigger를 reschedule 한다.
	 * @param batWrkId
	 * @param bizDvsnCd
	 * @param batRsltId
	 * @param strtDttm
	 * @param endDttm
	 * @return
	 * @throws SchedulerException
	 */
	public Trigger replaceSimpleTrigger(String batWrkId, String bizDvsnCd, String batRsltId, String strtDttm, String endDttm) throws SchedulerException {
		SimpleDateFormat dateformat = new SimpleDateFormat(DATETIME_FORMAT);
		JobDetail jobDetail = scheduler.getJobDetail(new JobKey(batWrkId, bizDvsnCd));
		TriggerKey triggerKey = new TriggerKey(makeSimpleTriggerName(batWrkId, batRsltId), bizDvsnCd);
		Trigger oldTrigger = scheduler.getTrigger(triggerKey);
		Trigger newTrigger = oldTrigger;

		try {
			Date startAt = dateformat.parse(strtDttm);
		
			if (null == oldTrigger) {
				// JobData를 배치처리결과로 부터 재생성.
				FrwBatRsltL frwBatRsltL = frwBatRsltLMapper.selectByPrimaryKey(batRsltId);
				JobDataMap jobDataMap = new JobDataMap(parseParmVal(frwBatRsltL.getParmVal()));
				// Trigger 생성
				newTrigger = TriggerBuilder.newTrigger()
		    		.withIdentity(triggerKey)
		    	    .startAt(startAt)
		    	    .forJob(jobDetail)
		    	    .usingJobData(jobDataMap)
		    	    .build();
		        scheduler.scheduleJob(newTrigger);
		        
			} else if (oldTrigger instanceof SimpleTrigger) {
				
				// Trigger 생성
				newTrigger = TriggerBuilder.newTrigger()
		    		.withIdentity(triggerKey)
		    	    .startAt(startAt)
		    	    // JobData를 배치처리결과로 부터 상소.
		    	    .usingJobData(oldTrigger.getJobDataMap())
		    	    .build();
		        scheduler.rescheduleJob(triggerKey, newTrigger);
				
			}
		
		} catch (ParseException e) {
			throw new BusinessException("" ,e);
		}
		
		return newTrigger;
	}
	
	private JobDataMap getJobDataMap(FrwBatWorkM frwBatWorkM) {
		JobDataMap jobDataMap = new JobDataMap(parseParmVal(frwBatWorkM.getParmVal()));
//		jobDataMap.put(JOB_DATA_KEY_JOBBEAN, frwBatWorkM.getBatPgmNm());
		return jobDataMap;
	}
	
	public Map<String,Object> parseParmVal(String parmVal) {
		Map<String,Object> map = new Hashtable<String,Object>();
		if (StringUtils.isNotEmpty(parmVal)) {			
			for(String param : parmVal.split(PARAM_DELIMETER)) {
				if (StringUtils.isBlank(param)) {
					continue;
				}
				String[] arr = param.split(PARAM_VALUE_DELIMETER);
				if (2 == arr.length) {
					map.put(arr[0].trim(), arr[1].trim());
				} else {
					log.warn("The key and value pairs(key=value) of the entered parameters do not match.{}", param);
				}
			}
		}
		return map;
	}
	
	public 	String toStringJobDataMap(Map<String,Object> jobDataMap) {
		StringBuilder sb = new StringBuilder();
		for(String key : jobDataMap.keySet()) {
			sb.append(key).append("=").append(jobDataMap.get(key)).append(",");
		}
		return sb.toString();
	}
	
	private String makeSimpleTriggerName(String batWrkId, String batRsltId) {
		return SMPL_TRGR_PREFIX + batWrkId + "_" + batRsltId;
	}
	
	public String getTractDt(FrwBatWorkM frwBatWorkM, String ordDt, LocalDate oLocalDate) {
		if (StringUtils.isBlank(frwBatWorkM.getDtDvsnCd())) {
			return ordDt;
		}
        BatSchdDvsnCdEnum batSchdDvsnCdEnum = BatSchdDvsnCdEnum.findByCd(frwBatWorkM.getSchdDvsnCd());
        BatDtDvsnCdEnum batDtDvsnCdEnum = BatDtDvsnCdEnum.findByCd(frwBatWorkM.getDtDvsnCd());

        if (null == batSchdDvsnCdEnum) {
            throw new BusinessException("MCMNE01016", frwBatWorkM.getBatWrkId(), frwBatWorkM.getSchdDvsnCd());
        }

        if (null == batDtDvsnCdEnum) {
            throw new BusinessException("MCMNE01015", frwBatWorkM.getBatWrkId(), frwBatWorkM.getDtDvsnCd());
        }

        // 거래일자 로직 보완 필요
        String tractDt = ordDt;
        //parse schdTpCd
        switch (batSchdDvsnCdEnum) {
            case DAY: /* 매일 */
            case TENDAY: /* 매월 10일*/
                tractDt = switch (batDtDvsnCdEnum) {
                    case PLUSONE, MINUSONE, MINUSTWO -> DateUtils.addDays(ordDt, batDtDvsnCdEnum.getDay());
                    case LASTDAYOFBFMONTH -> DateUtils.getLastDateOfPrevMonth(ordDt).format(DATE_FORMATTER);
                    default -> tractDt;
                };
                break;
            case WEEKDAY: /* 매영업일(월~토 영업일 기본달력) */
            case KOREAWEEKDAY: /* 매영업일(월~금 영업일 한국달력) */
            case FRSTWEEKDAY: /*매월 첫 영업일*/
            case THRDWEEKDAY: /*매월 첫 3영업일*/
                tractDt = switch (batDtDvsnCdEnum) {
                    case PLUSONE -> {
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, 1, ordDt, batDtDvsnCdEnum.getDay());
                    }
                    case MINUSONE, MINUSTWO -> {
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, -1, ordDt, -1 * batDtDvsnCdEnum.getDay());
                    }
                    case LASTDAYOFBFMONTH -> {
                        String calcDt = DateUtils.getLastDateOfPrevMonth(ordDt).format(DATE_FORMATTER);
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, -1, calcDt, 0);
                    }
                    default -> tractDt;
                };
                break;
            case BFWEEKDAY: /*전일이 영업일일때*/
                tractDt = switch (batDtDvsnCdEnum) {
                    case PLUSONE -> {
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, 1, ordDt, batDtDvsnCdEnum.getDay());
                    }
                    case MINUSONE, MINUSTWO -> {
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, -1, ordDt, -1 * batDtDvsnCdEnum.getDay());
                    }
                    case LASTDAYOFBFMONTH -> {
                    	// 전일 기준으로 계산
                    	String calcDt = DateUtils.getLastDateOfPrevMonth(DateUtils.addDays(ordDt, -1)).format(DATE_FORMATTER);
                        yield correctionCMS4Bizday(batSchdDvsnCdEnum, -1, calcDt, 0);
                    }
                    default -> tractDt;
                };
                break;
             default:
            	 break;
        }

        return tractDt;
    }
	
//	/**
//	 * 영업일 계산 시 CMS의 토요일 예외 보정 처리
//	 * @param frwBatWorkM
//	 * @param direction
//	 * @param date
//	 * @return
//	 */
//	@Deprecated
//	private String correctionCMS4Bizday(FrwBatWorkM frwBatWorkM, int direction, String date, int days) {
//		String rtnDt = date;
//
//		// (deprecated) CMS이고 토요일인 경우 shift 1 day 한다.
//		// 스케줄구분코드에서 매영업일(월~토)를 제외하고 모두 한국 달력(월~금 영업일) 사용
//		switch (frwBatWorkM.getSchdDvsnCd()) {
//			case "CMS":
//			case "HBK":
//			case "RPR":
//			case "ENT":
//				if (0 < direction) {
//					rtnDt = bizDate.getNextWorkingDay(date, days);
//				} else {
//					rtnDt = bizDate.getPrevWorkingDay(date, days);
//				}
//				break;
//			default:
//				if (0 < direction) {
//					rtnDt = bizDate.getNextBizDay(date, days);
//				} else {
//					rtnDt = bizDate.getPrevBizDay(date, days);
//				}
//				break;
//		}
//		
//		return rtnDt;		
//	}
	
	private String correctionCMS4Bizday(BatSchdDvsnCdEnum batSchdDvsnCdEnum, int direction, String date, int days) {
		String rtnDt = date;

		// (deprecated) CMS이고 토요일인 경우 shift 1 day 한다.
		// 스케줄구분코드에서 매영업일(월~토)를 제외하고 모두 한국 달력(월~금 영업일) 사용
		switch (batSchdDvsnCdEnum) {
			case WEEKDAY:	// 기본 월~토 영업일인 기본 달력 사용한 영업일 계산
				if (0 < direction) {
					rtnDt = bizDate.getNextBizDay(date, days);
				} else {
					rtnDt = bizDate.getPrevBizDay(date, days);
				}
				break;				
			default:	// 기본 월~금 영업일인 한국 달력 사용한 영업일 계산
				if (0 < direction) {
					rtnDt = bizDate.getNextWorkingDay(date, days);
				} else {
					rtnDt = bizDate.getPrevWorkingDay(date, days);
				}
				break;
		}
		
		return rtnDt;		
	}


    /**
     * 월~토 영업일 달력(기본 달력)을 이용하여 ordDt일자에 해당하는 스케줄구분코드 목록을 추출
     * @param ordDt
     * @param oLocalDate
     * @param cronSchdExcldCd
     * @return
     */
    private List<String> getSchdTpCdList(String ordDt, LocalDate oLocalDate, String cronSchdExcldCd) {
    	// 오늘이 휴일인지 평일인지 확인
        boolean isHoliday = Boolean.FALSE;
        List<String> schdTpCdList = new ArrayList<>();

        ComDateM comDateM = comDateMMapper.selectByPrimaryKey(ordDt);
        if (null != comDateM && "Y".equals(comDateM.getUseYn())) {
            if ("01".equals(comDateM.getHoliDvsnCd()) || "02".equals(comDateM.getHoliDvsnCd())) {
                // 휴일 처리 (01 법정공휴일, 02 임시공휴일)
                isHoliday = Boolean.TRUE;
            }
        } else {
            // COM_DATE_M 테이블에 존재하지 않을 경우 Calendar 에서 요일이 주말인지 확인.
            DayOfWeek dow = oLocalDate.getDayOfWeek();
            if (DayOfWeek.SUNDAY == dow) {
                // 휴일
                isHoliday = Boolean.TRUE;
            }
        }

        // select daily calendar all job
        schdTpCdList.add(BatSchdDvsnCdEnum.DAY.getValue()); // 매일

        if (!isHoliday) {
            // weekday calendar 매일
            schdTpCdList.add(BatSchdDvsnCdEnum.WEEKDAY.getValue()); // 매영업일

//            // 오늘이 몇번째 영업일
//            int bizDayOfMonth = comDateMDao.selectBizDtCount(ordDt.substring(0, 6) + "01", ordDt);
//            BatSchdDvsnCdEnum batSchdDvsnCdEnum = BatSchdDvsnCdEnum.findByWeekDay(bizDayOfMonth);
//            if (null != batSchdDvsnCdEnum) {
//                schdTpCdList.add(batSchdDvsnCdEnum.getValue()); // 해당영업일
//            }
        }

//        // 전일 영업일
//        String prevBizDt = bizDate.getPrevBizDay(ordDt, 1);
//        if (oLocalDate.minusDays(1).format(DATE_FORMATTER).equals(prevBizDt)) {
//            // (oDate - 1) is 영업일
//            schdTpCdList.add(BatSchdDvsnCdEnum.BFWEEKDAY.getValue()); // 직전영업일
//        }

        // Cron 표현식 제외 값이 없거나 N이면 Cron 스케줄 포함
        if (StringUtils.isEmpty(cronSchdExcldCd) || "N".equals(cronSchdExcldCd)) {
            schdTpCdList.add(BatSchdDvsnCdEnum.CRON.getValue()); // Cron
        }

        return schdTpCdList;
    }
    

    /**
     * 월~금 영업일 달력을 이용하여 ordDt일자에 해당하는 스케줄구분코드 목록을 추출
     * @param ordDt
     * @param oLocalDate
     * @param cronSchdExcldCd
     * @return
     */
    private List<String> getSchdTpCdListWithSaturdayHoliday(String ordDt, LocalDate oLocalDate, String cronSchdExcldCd) {
        // 오늘이 휴일인지 평일인지 확인
        boolean isHoliday = Boolean.FALSE;
        List<String> schdTpCdList = new ArrayList<>();
        DayOfWeek dow = oLocalDate.getDayOfWeek();
        ComDateM comDateM = comDateMMapper.selectByPrimaryKey(ordDt);
        if (null != comDateM && "Y".equals(comDateM.getUseYn())) {
            if ("01".equals(comDateM.getHoliDvsnCd()) || "02".equals(comDateM.getHoliDvsnCd()) || DayOfWeek.SATURDAY == dow) {
                // 휴일 처리 (01 법정공휴일, 02 임시공휴일, 토요일)
                isHoliday = Boolean.TRUE;
            }
        } else {
            // COM_DATE_M 테이블에 존재하지 않을 경우 Calendar 에서 요일이 주말인지 확인.            
            if (DayOfWeek.SATURDAY == dow || DayOfWeek.SUNDAY == dow) {
                // 휴일
                isHoliday = Boolean.TRUE;
            }
        }

        // select daily calendar all job
        schdTpCdList.add(BatSchdDvsnCdEnum.DAY.getValue()); // 매일        

        if (!isHoliday) {
            // weekday calendar 매일
            schdTpCdList.add(BatSchdDvsnCdEnum.KOREAWEEKDAY.getValue()); // 매영업일

            // 오늘이 몇번째 영업일 단, 토요일은 공휴일로 지정
            int bizDayOfMonth = comDateMDao.selectWorkingDtCount(ordDt.substring(0, 6) + "01", ordDt);
            BatSchdDvsnCdEnum batSchdDvsnCdEnum = BatSchdDvsnCdEnum.findByWeekDay(bizDayOfMonth);
            if (null != batSchdDvsnCdEnum) {
                schdTpCdList.add(batSchdDvsnCdEnum.getValue()); // 해당영업일
            }
            
            // 매월10일, 단 휴일일 경우 다음 영업일 (즉, 매월 10일 포함하여 이후 첫 영업일)
            String tenDate = bizDate.getNextWorkingDay(ordDt.substring(0, 6) + "10", 0);
            if (ordDt.equals(tenDate)) {
            	schdTpCdList.add(BatSchdDvsnCdEnum.TENDAY.getValue()); // 매월10일
            }
        }

        // 전일 영업일 단, 토요일은 공휴일로 처리
        String prevBizDt = bizDate.getPrevWorkingDay(ordDt, 1);
        if (oLocalDate.minusDays(1).format(DATE_FORMATTER).equals(prevBizDt)) {
            // (oDate - 1) is 영업일
            schdTpCdList.add(BatSchdDvsnCdEnum.BFWEEKDAY.getValue()); // 직전영업일
        }

        // Cron 표현식 제외 값이 없거나 N이면 Cron 스케줄 포함
        if (StringUtils.isEmpty(cronSchdExcldCd) || "N".equals(cronSchdExcldCd)) {
            schdTpCdList.add(BatSchdDvsnCdEnum.CRON.getValue()); // Cron
        }

        return schdTpCdList;
    }
	
	/**
	 * 해당 Order date에 실행될 배치작업목록을 조회한다.
	 * @param ordDt
	 * @return
	 * @throws ParseException 
	 */
	public List<FrwBatWorkM> getListPlanBatWork(String ordDt) {
		return getListPlanBatWork(ordDt, "Y");
	}

    /**
     * 해당 Order date와 Cron을 포함하여 실행될 배치작업목록을 조회한다.
     * @param ordDt
     * @param cronSchdExcldCd cron 제외 여부
     * @return
     * @throws ParseException 
     */
    public List<FrwBatWorkM> getListPlanBatWork(String ordDt, String cronSchdExcldCd) {        
        LocalDate oLocalDate = LocalDate.parse(ordDt, DATE_FORMATTER);

        // Calendar를 기준으로  ordDt가 속한 스케줄구분코드 목록 조회
        List<String> schdTpCdList = getSchdTpCdList(ordDt, oLocalDate, cronSchdExcldCd);
        
        // Calendar and 토요일을 공휴일로 한 ordDt가 속한 스케줄구분코드 목록 조회
        List<String> schdTpCdListWithSaturdayHoliday = getSchdTpCdListWithSaturdayHoliday(ordDt, oLocalDate, cronSchdExcldCd);

        // 등록 대상 스케쥴 목록을 추출한다.
        List<FrwBatWorkM> resultList = new ArrayList<>();  
        List<FrwBatWorkM> list = frwBatExtDao.selectListBySchdDvsnCd(ordDt, schdTpCdList, schdTpCdListWithSaturdayHoliday);
        
        Date ordDate = Date.from(oLocalDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
        list.forEach((item) -> {
        	if (StringUtils.isNoneEmpty(item.getCronCmd())) {
        		if (isCronExpressionMatchDate(item, item.getCronCmd(), ordDate)) {    			
        			resultList.add(item);
        		}
        	} else {
        		resultList.add(item);
        	}
        });

        return resultList;
    }
	
	/**
	 * 현재의 Job의 선행 배치들 중 완료되지 않은 배치 목록 추출
	 * @param context
	 * @param batContext
	 * @return
	 */
	public List<FrwBatRsltL> listPrevDelayedBat(String ordDt, String batWrkId) {
		List<FrwBatRsltL> listPrevDelayedBat = new ArrayList<>();
		// 선행 배치 목록을 추출한다.
		List<FrwBatRsltL> listPrevBatLtstRslt = frwBatExtDao.selectListPrevBatLtstRslt(ordDt, batWrkId);
		// 선핸 배치 목록이 모두 완료되었는지 확인한다.
		for (FrwBatRsltL frwBatRsltL : listPrevBatLtstRslt) {
			if (! BatCmpltStsCdEnum.COMPLETED.getValue().equals(frwBatRsltL.getCmpltStsCd())) {
				listPrevDelayedBat.add(frwBatRsltL);
			}
		}
 		return listPrevDelayedBat;
	}
	
	@SuppressWarnings("deprecation")
	private boolean isCronExpressionMatchDate(FrwBatWorkM item, String cronExpression, Date date) {
        try {
        	// sec min hour 부분을 제거하여 일자만 체크하도록 한다.
            CronExpression expression = new CronExpression(removeTimeExpression(cronExpression));
            // CronExpression의 isSatisfiedBy() 메서드를 사용하여 주어진 날짜가 해당 표현식에 맞는지 확인
            if (expression.isSatisfiedBy(date)) {
            	// 해당 일자의 실행시간 계산
            	expression = new CronExpression(cronExpression);
        		Date baseDate = new Date();
        		baseDate.setTime(date.getTime() - 1);
            	Date nextDate = expression.getNextValidTimeAfter(baseDate);
            	item.setSchdStaTm(String.format("%02d%02d%02d", nextDate.getHours(), nextDate.getMinutes(), nextDate.getSeconds()));
            	return true;
            }
        } catch (ParseException e) {
        	log.warn(String.format("Error parsing date(%s) or cronExpression(%s). but skipped.", date, cronExpression), e);
        }
        return false;
    }
	 
   private String removeTimeExpression(String cronExpression) {
	   Matcher m = CRON_PATTERN.matcher(cronExpression);
	   if(m.find() && 1 <= m.groupCount()) {
		   if (log.isDebugEnabled()) {
			   log.debug("removeTimeExpression * * * {}", m.group(1));
		   }
		   return "* * * " +  m.group(1);
	   }
	   return cronExpression;
   }
   
}
