package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금용공동망 거래차감표
 * <pre>{@code
 * KftHofEL0033R kftHofEL0033R  = new KftHofEL0033R(); // 전자금용공동망 거래차감표
 * kftHofEL0033R.setFileName(""); // 업무구분
 * kftHofEL0033R.setDataType(""); // 데이타구분
 * kftHofEL0033R.setSerialNumber(""); // 일련번호
 * kftHofEL0033R.setContentType(""); // 내용구분
 * kftHofEL0033R.setTransactionCode(""); // 거래구분코드
 * kftHofEL0033R.setBnkCd1(""); // 은행코드
 * kftHofEL0033R.setCreditTransactionCount(0L); // 차변거래건수
 * kftHofEL0033R.setCreditCancelCount(0L); // 차변취소건수
 * kftHofEL0033R.setCreditSubtotalCount(0L); // 차변소계건수
 * kftHofEL0033R.setDebitTransactionCount(0L); // 대변거래건수
 * kftHofEL0033R.setDebitCancelCount(0L); // 대변취소건수
 * kftHofEL0033R.setDebitSubtotalCount(0L); // 대변소계건수
 * kftHofEL0033R.setCreditTransactionAmount(0L); // 차변거래금액
 * kftHofEL0033R.setCreditCancelAmount(0L); // 차변취소금액
 * kftHofEL0033R.setCreditSubtotalAmount(0L); // 차변소계금액
 * kftHofEL0033R.setDebitTransactionAmount(0L); // 대변거래금액
 * kftHofEL0033R.setDebitCancelAmount(0L); // 대변취소금액
 * kftHofEL0033R.setDebitSubtotalAmount(0L); // 대변소계금액
 * kftHofEL0033R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0033R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String contentType; // 내용구분
	private String transactionCode; // 거래구분코드
	private String bnkCd1; // 은행코드
	private long creditTransactionCount; // 차변거래건수
	private long creditCancelCount; // 차변취소건수
	private long creditSubtotalCount; // 차변소계건수
	private long debitTransactionCount; // 대변거래건수
	private long debitCancelCount; // 대변취소건수
	private long debitSubtotalCount; // 대변소계건수
	private long creditTransactionAmount; // 차변거래금액
	private long creditCancelAmount; // 차변취소금액
	private long creditSubtotalAmount; // 차변소계금액
	private long debitTransactionAmount; // 대변거래금액
	private long debitCancelAmount; // 대변취소금액
	private long debitSubtotalAmount; // 대변소계금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String contentType$; // 내용구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd1$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionCount$; // 차변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelCount$; // 차변취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditSubtotalCount$; // 차변소계건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionCount$; // 대변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelCount$; // 대변취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitSubtotalCount$; // 대변소계건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionAmount$; // 차변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelAmount$; // 차변취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditSubtotalAmount$; // 차변소계금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionAmount$; // 대변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelAmount$; // 대변취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitSubtotalAmount$; // 대변소계금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		contentType$ = VOUtils.write(out, contentType, 1); // 내용구분
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		bnkCd1$ = VOUtils.write(out, bnkCd1, 3); // 은행코드
		creditTransactionCount$ = VOUtils.write(out, creditTransactionCount, 10); // 차변거래건수
		creditCancelCount$ = VOUtils.write(out, creditCancelCount, 10); // 차변취소건수
		creditSubtotalCount$ = VOUtils.write(out, creditSubtotalCount, 10); // 차변소계건수
		debitTransactionCount$ = VOUtils.write(out, debitTransactionCount, 10); // 대변거래건수
		debitCancelCount$ = VOUtils.write(out, debitCancelCount, 10); // 대변취소건수
		debitSubtotalCount$ = VOUtils.write(out, debitSubtotalCount, 10); // 대변소계건수
		creditTransactionAmount$ = VOUtils.write(out, creditTransactionAmount, 16); // 차변거래금액
		creditCancelAmount$ = VOUtils.write(out, creditCancelAmount, 16); // 차변취소금액
		creditSubtotalAmount$ = VOUtils.write(out, creditSubtotalAmount, 16); // 차변소계금액
		debitTransactionAmount$ = VOUtils.write(out, debitTransactionAmount, 16); // 대변거래금액
		debitCancelAmount$ = VOUtils.write(out, debitCancelAmount, 16); // 대변취소금액
		debitSubtotalAmount$ = VOUtils.write(out, debitSubtotalAmount, 16); // 대변소계금액
		filler$ = VOUtils.write(out, filler, 19); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		contentType = VOUtils.toString(contentType$ = VOUtils.read(in, 1)); // 내용구분
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		bnkCd1 = VOUtils.toString(bnkCd1$ = VOUtils.read(in, 3)); // 은행코드
		creditTransactionCount = VOUtils.toLong(creditTransactionCount$ = VOUtils.read(in, 10)); // 차변거래건수
		creditCancelCount = VOUtils.toLong(creditCancelCount$ = VOUtils.read(in, 10)); // 차변취소건수
		creditSubtotalCount = VOUtils.toLong(creditSubtotalCount$ = VOUtils.read(in, 10)); // 차변소계건수
		debitTransactionCount = VOUtils.toLong(debitTransactionCount$ = VOUtils.read(in, 10)); // 대변거래건수
		debitCancelCount = VOUtils.toLong(debitCancelCount$ = VOUtils.read(in, 10)); // 대변취소건수
		debitSubtotalCount = VOUtils.toLong(debitSubtotalCount$ = VOUtils.read(in, 10)); // 대변소계건수
		creditTransactionAmount = VOUtils.toLong(creditTransactionAmount$ = VOUtils.read(in, 16)); // 차변거래금액
		creditCancelAmount = VOUtils.toLong(creditCancelAmount$ = VOUtils.read(in, 16)); // 차변취소금액
		creditSubtotalAmount = VOUtils.toLong(creditSubtotalAmount$ = VOUtils.read(in, 16)); // 차변소계금액
		debitTransactionAmount = VOUtils.toLong(debitTransactionAmount$ = VOUtils.read(in, 16)); // 대변거래금액
		debitCancelAmount = VOUtils.toLong(debitCancelAmount$ = VOUtils.read(in, 16)); // 대변취소금액
		debitSubtotalAmount = VOUtils.toLong(debitSubtotalAmount$ = VOUtils.read(in, 16)); // 대변소계금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 19)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", contentType=").append(contentType).append(System.lineSeparator()); // 내용구분
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", bnkCd1=").append(bnkCd1).append(System.lineSeparator()); // 은행코드
		sb.append(", creditTransactionCount=").append(creditTransactionCount).append(System.lineSeparator()); // 차변거래건수
		sb.append(", creditCancelCount=").append(creditCancelCount).append(System.lineSeparator()); // 차변취소건수
		sb.append(", creditSubtotalCount=").append(creditSubtotalCount).append(System.lineSeparator()); // 차변소계건수
		sb.append(", debitTransactionCount=").append(debitTransactionCount).append(System.lineSeparator()); // 대변거래건수
		sb.append(", debitCancelCount=").append(debitCancelCount).append(System.lineSeparator()); // 대변취소건수
		sb.append(", debitSubtotalCount=").append(debitSubtotalCount).append(System.lineSeparator()); // 대변소계건수
		sb.append(", creditTransactionAmount=").append(creditTransactionAmount).append(System.lineSeparator()); // 차변거래금액
		sb.append(", creditCancelAmount=").append(creditCancelAmount).append(System.lineSeparator()); // 차변취소금액
		sb.append(", creditSubtotalAmount=").append(creditSubtotalAmount).append(System.lineSeparator()); // 차변소계금액
		sb.append(", debitTransactionAmount=").append(debitTransactionAmount).append(System.lineSeparator()); // 대변거래금액
		sb.append(", debitCancelAmount=").append(debitCancelAmount).append(System.lineSeparator()); // 대변취소금액
		sb.append(", debitSubtotalAmount=").append(debitSubtotalAmount).append(System.lineSeparator()); // 대변소계금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "contentType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "bnkCd1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "creditTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditCancelCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditSubtotalCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitCancelCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitSubtotalCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditCancelAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditSubtotalAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitCancelAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitSubtotalAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "19", "defltVal", "")
		);
	}

}
