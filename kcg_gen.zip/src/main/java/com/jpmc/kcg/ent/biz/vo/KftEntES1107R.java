package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 수령거부 및 반환내역
 * <pre>{@code
 * KftEntES1107R kftEntES1107R  = new KftEntES1107R(); // 수령거부 및 반환내역
 * kftEntES1107R.setFileName(""); // 업무구분
 * kftEntES1107R.setDataType(""); // 데이터구분
 * kftEntES1107R.setSerialNumber(""); // 일련번호
 * kftEntES1107R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1107R.setBankCode(""); // 은행코드
 * kftEntES1107R.setRefusalOfReceiptOrReturnSort(""); // 수령 거부 반환 구분
 * kftEntES1107R.setIssuanceEndorsementPostmaturedEndorsement(""); // 발행/배서/기한후배서
 * kftEntES1107R.setRefusalOfReceiptOrReturnDate(""); // 수령 거부 또는 반환 일자
 * kftEntES1107R.setEnoteNumber(""); // 어음번호
 * kftEntES1107R.setEnoteType(""); // 어음종류
 * kftEntES1107R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1107R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1107R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1107R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1107R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1107R.setOtherPartyCorpIndvSort(""); // 상대방-법인개인구분
 * kftEntES1107R.setOtherPartyResidentBusinessNumber(""); // 상대방-주민사업자번호
 * kftEntES1107R.setOtherPartyCorpName(""); // 상대방-법인명
 * kftEntES1107R.setOtherPartyNameRepresentativeName(""); // 상대방-성명(대표자명)
 * kftEntES1107R.setOtherPartyAddress(""); // 상대방-주소
 * kftEntES1107R.setOtherPartyBankCode(""); // 상대방-은행코드
 * kftEntES1107R.setOtherPartyCurrentCreditAccountNumber(""); // 상대방-당좌(입금)계좌번호
 * kftEntES1107R.setRequesterCorpIndvSort(""); // 요청인-법인개인구분
 * kftEntES1107R.setRequesterResidentBusinessNumber(""); // 요청인-주민사업자번호
 * kftEntES1107R.setRequesterCorpName(""); // 요청인-법인명
 * kftEntES1107R.setRequesterNameRepresentativeName(""); // 요청인-성명(대표자명)
 * kftEntES1107R.setRequesterAddress(""); // 요청인-주소
 * kftEntES1107R.setRequesterBankCode(""); // 요청인-은행코드
 * kftEntES1107R.setRequesterRefusedOrReturnedAmount(0L); // 요청인-수령거부 및 반환금액
 * kftEntES1107R.setRequesterDepositAccountNumber(""); // 요청인-입금계좌번호
 * kftEntES1107R.setRequesterSplitNumber(""); // 요청인-분할번호
 * kftEntES1107R.setRequesterEndorsementNumber(""); // 요청인-배서번호
 * kftEntES1107R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1107R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String refusalOfReceiptOrReturnSort; // 수령 거부 반환 구분
	private String issuanceEndorsementPostmaturedEndorsement; // 발행/배서/기한후배서
	private String refusalOfReceiptOrReturnDate; // 수령 거부 또는 반환 일자
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String otherPartyCorpIndvSort; // 상대방-법인개인구분
	private String otherPartyResidentBusinessNumber; // 상대방-주민사업자번호
	private String otherPartyCorpName; // 상대방-법인명
	private String otherPartyNameRepresentativeName; // 상대방-성명(대표자명)
	private String otherPartyAddress; // 상대방-주소
	private String otherPartyBankCode; // 상대방-은행코드
	private String otherPartyCurrentCreditAccountNumber; // 상대방-당좌(입금)계좌번호
	private String requesterCorpIndvSort; // 요청인-법인개인구분
	private String requesterResidentBusinessNumber; // 요청인-주민사업자번호
	private String requesterCorpName; // 요청인-법인명
	private String requesterNameRepresentativeName; // 요청인-성명(대표자명)
	private String requesterAddress; // 요청인-주소
	private String requesterBankCode; // 요청인-은행코드
	private long requesterRefusedOrReturnedAmount; // 요청인-수령거부 및 반환금액
	private String requesterDepositAccountNumber; // 요청인-입금계좌번호
	private String requesterSplitNumber; // 요청인-분할번호
	private String requesterEndorsementNumber; // 요청인-배서번호
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptOrReturnSort$; // 수령 거부 반환 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceEndorsementPostmaturedEndorsement$; // 발행/배서/기한후배서
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptOrReturnDate$; // 수령 거부 또는 반환 일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyCorpIndvSort$; // 상대방-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyResidentBusinessNumber$; // 상대방-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyCorpName$; // 상대방-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyNameRepresentativeName$; // 상대방-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyAddress$; // 상대방-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyBankCode$; // 상대방-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyCurrentCreditAccountNumber$; // 상대방-당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterCorpIndvSort$; // 요청인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterResidentBusinessNumber$; // 요청인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterCorpName$; // 요청인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterNameRepresentativeName$; // 요청인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterAddress$; // 요청인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterBankCode$; // 요청인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterRefusedOrReturnedAmount$; // 요청인-수령거부 및 반환금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterDepositAccountNumber$; // 요청인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterSplitNumber$; // 요청인-분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterEndorsementNumber$; // 요청인-배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		refusalOfReceiptOrReturnSort$ = VOUtils.write(out, refusalOfReceiptOrReturnSort, 1); // 수령 거부 반환 구분
		issuanceEndorsementPostmaturedEndorsement$ = VOUtils.write(out, issuanceEndorsementPostmaturedEndorsement, 1); // 발행/배서/기한후배서
		refusalOfReceiptOrReturnDate$ = VOUtils.write(out, refusalOfReceiptOrReturnDate, 8); // 수령 거부 또는 반환 일자
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		otherPartyCorpIndvSort$ = VOUtils.write(out, otherPartyCorpIndvSort, 1); // 상대방-법인개인구분
		otherPartyResidentBusinessNumber$ = VOUtils.write(out, otherPartyResidentBusinessNumber, 13); // 상대방-주민사업자번호
		otherPartyCorpName$ = VOUtils.write(out, otherPartyCorpName, 40, "EUC-KR"); // 상대방-법인명
		otherPartyNameRepresentativeName$ = VOUtils.write(out, otherPartyNameRepresentativeName, 20, "EUC-KR"); // 상대방-성명(대표자명)
		otherPartyAddress$ = VOUtils.write(out, otherPartyAddress, 60, "EUC-KR"); // 상대방-주소
		otherPartyBankCode$ = VOUtils.write(out, otherPartyBankCode, 3); // 상대방-은행코드
		otherPartyCurrentCreditAccountNumber$ = VOUtils.write(out, otherPartyCurrentCreditAccountNumber, 16); // 상대방-당좌(입금)계좌번호
		requesterCorpIndvSort$ = VOUtils.write(out, requesterCorpIndvSort, 1); // 요청인-법인개인구분
		requesterResidentBusinessNumber$ = VOUtils.write(out, requesterResidentBusinessNumber, 13); // 요청인-주민사업자번호
		requesterCorpName$ = VOUtils.write(out, requesterCorpName, 40, "EUC-KR"); // 요청인-법인명
		requesterNameRepresentativeName$ = VOUtils.write(out, requesterNameRepresentativeName, 20, "EUC-KR"); // 요청인-성명(대표자명)
		requesterAddress$ = VOUtils.write(out, requesterAddress, 60, "EUC-KR"); // 요청인-주소
		requesterBankCode$ = VOUtils.write(out, requesterBankCode, 3); // 요청인-은행코드
		requesterRefusedOrReturnedAmount$ = VOUtils.write(out, requesterRefusedOrReturnedAmount, 15); // 요청인-수령거부 및 반환금액
		requesterDepositAccountNumber$ = VOUtils.write(out, requesterDepositAccountNumber, 16); // 요청인-입금계좌번호
		requesterSplitNumber$ = VOUtils.write(out, requesterSplitNumber, 2); // 요청인-분할번호
		requesterEndorsementNumber$ = VOUtils.write(out, requesterEndorsementNumber, 2); // 요청인-배서번호
		filler2$ = VOUtils.write(out, filler2, 27); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		refusalOfReceiptOrReturnSort = VOUtils.toString(refusalOfReceiptOrReturnSort$ = VOUtils.read(in, 1)); // 수령 거부 반환 구분
		issuanceEndorsementPostmaturedEndorsement = VOUtils.toString(issuanceEndorsementPostmaturedEndorsement$ = VOUtils.read(in, 1)); // 발행/배서/기한후배서
		refusalOfReceiptOrReturnDate = VOUtils.toString(refusalOfReceiptOrReturnDate$ = VOUtils.read(in, 8)); // 수령 거부 또는 반환 일자
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		otherPartyCorpIndvSort = VOUtils.toString(otherPartyCorpIndvSort$ = VOUtils.read(in, 1)); // 상대방-법인개인구분
		otherPartyResidentBusinessNumber = VOUtils.toString(otherPartyResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상대방-주민사업자번호
		otherPartyCorpName = VOUtils.toString(otherPartyCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상대방-법인명
		otherPartyNameRepresentativeName = VOUtils.toString(otherPartyNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상대방-성명(대표자명)
		otherPartyAddress = VOUtils.toString(otherPartyAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상대방-주소
		otherPartyBankCode = VOUtils.toString(otherPartyBankCode$ = VOUtils.read(in, 3)); // 상대방-은행코드
		otherPartyCurrentCreditAccountNumber = VOUtils.toString(otherPartyCurrentCreditAccountNumber$ = VOUtils.read(in, 16)); // 상대방-당좌(입금)계좌번호
		requesterCorpIndvSort = VOUtils.toString(requesterCorpIndvSort$ = VOUtils.read(in, 1)); // 요청인-법인개인구분
		requesterResidentBusinessNumber = VOUtils.toString(requesterResidentBusinessNumber$ = VOUtils.read(in, 13)); // 요청인-주민사업자번호
		requesterCorpName = VOUtils.toString(requesterCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 요청인-법인명
		requesterNameRepresentativeName = VOUtils.toString(requesterNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 요청인-성명(대표자명)
		requesterAddress = VOUtils.toString(requesterAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 요청인-주소
		requesterBankCode = VOUtils.toString(requesterBankCode$ = VOUtils.read(in, 3)); // 요청인-은행코드
		requesterRefusedOrReturnedAmount = VOUtils.toLong(requesterRefusedOrReturnedAmount$ = VOUtils.read(in, 15)); // 요청인-수령거부 및 반환금액
		requesterDepositAccountNumber = VOUtils.toString(requesterDepositAccountNumber$ = VOUtils.read(in, 16)); // 요청인-입금계좌번호
		requesterSplitNumber = VOUtils.toString(requesterSplitNumber$ = VOUtils.read(in, 2)); // 요청인-분할번호
		requesterEndorsementNumber = VOUtils.toString(requesterEndorsementNumber$ = VOUtils.read(in, 2)); // 요청인-배서번호
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 27)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", refusalOfReceiptOrReturnSort=").append(refusalOfReceiptOrReturnSort).append(System.lineSeparator()); // 수령 거부 반환 구분
		sb.append(", issuanceEndorsementPostmaturedEndorsement=").append(issuanceEndorsementPostmaturedEndorsement).append(System.lineSeparator()); // 발행/배서/기한후배서
		sb.append(", refusalOfReceiptOrReturnDate=").append(refusalOfReceiptOrReturnDate).append(System.lineSeparator()); // 수령 거부 또는 반환 일자
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", otherPartyCorpIndvSort=").append(otherPartyCorpIndvSort).append(System.lineSeparator()); // 상대방-법인개인구분
		sb.append(", otherPartyResidentBusinessNumber=").append(otherPartyResidentBusinessNumber).append(System.lineSeparator()); // 상대방-주민사업자번호
		sb.append(", otherPartyCorpName=").append(otherPartyCorpName).append(System.lineSeparator()); // 상대방-법인명
		sb.append(", otherPartyNameRepresentativeName=").append(otherPartyNameRepresentativeName).append(System.lineSeparator()); // 상대방-성명(대표자명)
		sb.append(", otherPartyAddress=").append(otherPartyAddress).append(System.lineSeparator()); // 상대방-주소
		sb.append(", otherPartyBankCode=").append(otherPartyBankCode).append(System.lineSeparator()); // 상대방-은행코드
		sb.append(", otherPartyCurrentCreditAccountNumber=").append(otherPartyCurrentCreditAccountNumber).append(System.lineSeparator()); // 상대방-당좌(입금)계좌번호
		sb.append(", requesterCorpIndvSort=").append(requesterCorpIndvSort).append(System.lineSeparator()); // 요청인-법인개인구분
		sb.append(", requesterResidentBusinessNumber=").append(requesterResidentBusinessNumber).append(System.lineSeparator()); // 요청인-주민사업자번호
		sb.append(", requesterCorpName=").append(requesterCorpName).append(System.lineSeparator()); // 요청인-법인명
		sb.append(", requesterNameRepresentativeName=").append(requesterNameRepresentativeName).append(System.lineSeparator()); // 요청인-성명(대표자명)
		sb.append(", requesterAddress=").append(requesterAddress).append(System.lineSeparator()); // 요청인-주소
		sb.append(", requesterBankCode=").append(requesterBankCode).append(System.lineSeparator()); // 요청인-은행코드
		sb.append(", requesterRefusedOrReturnedAmount=").append(requesterRefusedOrReturnedAmount).append(System.lineSeparator()); // 요청인-수령거부 및 반환금액
		sb.append(", requesterDepositAccountNumber=").append(requesterDepositAccountNumber).append(System.lineSeparator()); // 요청인-입금계좌번호
		sb.append(", requesterSplitNumber=").append(requesterSplitNumber).append(System.lineSeparator()); // 요청인-분할번호
		sb.append(", requesterEndorsementNumber=").append(requesterEndorsementNumber).append(System.lineSeparator()); // 요청인-배서번호
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptOrReturnSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceEndorsementPostmaturedEndorsement", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptOrReturnDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "otherPartyCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "otherPartyResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "otherPartyCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "otherPartyNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "otherPartyAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "otherPartyBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "otherPartyCurrentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "requesterResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "requesterCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "requesterNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "requesterAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "requesterBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requesterRefusedOrReturnedAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "requesterDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "requesterEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "27", "defltVal", "")
		);
	}

}
