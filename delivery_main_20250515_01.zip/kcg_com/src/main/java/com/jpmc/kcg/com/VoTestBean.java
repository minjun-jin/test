package com.jpmc.kcg.com;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.MethodUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.dao.ComMapper;
import com.jpmc.kcg.com.dto.ComFileLaytD;
import com.jpmc.kcg.com.dto.ComFileLaytM;
import com.jpmc.kcg.com.dto.ComTlgLaytD;
import com.jpmc.kcg.com.dto.ComTlgLaytM;
import com.jpmc.kcg.frw.SystemProperties;

import jakarta.validation.ValidationException;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;

@Generated
@Slf4j
@Component
public class VoTestBean {

	private String[] sArray = ArrayUtils.toArray("FCMS", "FENT", "FHOF", "FIFT", "FRPR", "BAT", "CMS", "COM", "CQE", "ENT", "EXT", "FRW", "GCH", "GEN", "HBK", "HOF", "IFT", "KCG", "KFT", "LVB", "RPR", "SCH", "SIM", "WEB");
	private String[] rArray = Stream.of(sArray).map(s -> {
		if (StringUtils.equalsAny(s, "FCMS", "FENT", "FHOF", "FIFT", "FRPR")) {
			return StringUtils.join("Kft",
			StringUtils.capitalize(StringUtils.lowerCase(StringUtils.right(s, 3))));
		}
		return StringUtils.capitalize(StringUtils.lowerCase(s));
	}).toArray(String[]::new);

	public void test(List<String> list, ComMapper comMapper, ComFileLaytM comFileLaytM, String recTpCd) {
		String clsNm = StringUtils.join("com.jpmc.kcg.", StringUtils.lowerCase(comFileLaytM.getBizDvsnCd()), ".biz.vo.", StringUtils.replaceEach(comFileLaytM.getFileLaytId(), sArray, rArray), recTpCd);
		try {
			log.debug("{}", clsNm);
			List<?> test = (List<?>) MethodUtils.invokeExactStaticMethod(ClassUtils.getClass(clsNm), "test");
			Iterator<?> iterator = test.iterator();
			for (ComFileLaytD comFileLaytD : comMapper.selectComFileLaytD(comFileLaytM.getFileLaytId(), recTpCd)) {
//				log.debug("{}", comFileLaytD);
				if (iterator.hasNext()) {
					Map<?, ?> map = (Map<?, ?>) iterator.next();
//					log.debug("{}", map);
					if (StringUtils.equals(comFileLaytD.getFld(), (String) map.get("fld")) &&
						StringUtils.equals(comFileLaytD.getFldLen(), (String) map.get("fldLen")) &&
						StringUtils.equals(StringUtils.defaultString(comFileLaytD.getDefltVal()), (String) map.get("defltVal"))) {
						continue;
					}
				}
				list.add(clsNm);
				return;
			}
			if (iterator.hasNext()) {
				list.add(clsNm);
			}
		} catch (Throwable t) {
			list.add(clsNm);
		}
	}

	public void test(List<String> list, ComMapper comMapper, ComTlgLaytM comTlgLaytM) {
		String clsNm = StringUtils.join("com.jpmc.kcg.", StringUtils.lowerCase(comTlgLaytM.getBizDvsnCd()), ".biz.vo.", StringUtils.replaceEach(comTlgLaytM.getTlgLaytId(), sArray, rArray));
		try {
			log.debug("{}", clsNm);
			List<?> test = (List<?>) MethodUtils.invokeExactStaticMethod(ClassUtils.getClass(clsNm), "test");
			Iterator<?> iterator = test.iterator();
			for (ComTlgLaytD comTlgLaytD : comMapper.selectComTlgLaytD(comTlgLaytM.getTlgLaytId())) {
//				log.debug("{}", comTlgLaytD);
				if (iterator.hasNext()) {
					Map<?, ?> map = (Map<?, ?>) iterator.next();
//					log.debug("{}", map);
					int fldLen = comTlgLaytD.getFldLen().intValue();
					if (StringUtils.equals(comTlgLaytD.getDataTp(), "ARRAY")) {
						fldLen = ObjectUtils.defaultIfNull(comTlgLaytD.getFixArrSize(), comTlgLaytD.getFldLen()).intValue();
					}
					if (StringUtils.equals(comTlgLaytD.getFld(), (String) map.get("fld")) &&
						StringUtils.equals(String.valueOf(fldLen), (String) map.get("fldLen")) &&
						StringUtils.equals(StringUtils.defaultString(comTlgLaytD.getDefltVal()), (String) map.get("defltVal"))) {
						continue;
					}
				}
				list.add(clsNm);
				return;
			}
			if (iterator.hasNext()) {
				list.add(clsNm);
			}
		} catch (Throwable t) {
			list.add(clsNm);
		}
	}

	public VoTestBean(@Value("${spring.application.name}") String appNm,
		SystemProperties systemProperties,
		ComMapper comMapper) {
		log.debug("isVoTest = {}", systemProperties.isVoTest());
		if (systemProperties.isVoTest()) {
			String bizDvsnCd = StringUtils.right(StringUtils.upperCase(appNm), 3);
			log.debug("bizDvsnCd = {}", bizDvsnCd);
			if (StringUtils.equalsAny(bizDvsnCd, "CMS", "ENT", "HOF", "IFT", "RPR")) {
				List<String> list = new ArrayList<>();
				for (ComFileLaytM comFileLaytM : comMapper.selectComFileLaytM(bizDvsnCd)) {
//					log.debug("{}", comFileLaytM);
					test(list, comMapper, comFileLaytM, "H");
					if (StringUtils.endsWith(comFileLaytM.getFileLaytId(), "CMSEB90")) {
						test(list, comMapper, comFileLaytM, "RA");
						test(list, comMapper, comFileLaytM, "RB");
						test(list, comMapper, comFileLaytM, "RC");
						test(list, comMapper, comFileLaytM, "RD");
						test(list, comMapper, comFileLaytM, "RE");
					} else {
						test(list, comMapper, comFileLaytM, "R");
					}
					test(list, comMapper, comFileLaytM, "T");
				}
				for (ComTlgLaytM comTlgLaytM : comMapper.selectComTlgLaytM(bizDvsnCd)) {
//					log.debug("{}", comTlgLaytM);
					test(list, comMapper, comTlgLaytM);
				}
				if (list.isEmpty()) {
					log.debug("VO test OK");
					return;
				}
				for (String str : list) {
					log.error("VO test {}", str);
				}
				throw new ValidationException();
			}
		}
	}

}
