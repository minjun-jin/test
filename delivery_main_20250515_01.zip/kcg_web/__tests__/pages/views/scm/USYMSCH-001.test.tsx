import React from "react"
import { render, fireEvent, waitFor, within } from "@testing-library/react"

// USYMSCH001 컴포넌트를 불러옵니다.
import USYMSCH001 from "@/pages/views/scm/USYMSCH-001"
import { Component } from "@/hoc/TestUtil"
import CONFIG from "@/config/siteConfig"

const component = Component(USYMSCH001)

describe("[USYMSCH-001] 배치작업관리", () => {
  beforeAll(() => {
    mockStorageUtils.mockRoleList.mockReturnValue([
      {
        roleCd: CONFIG.ROLE_CD.ALL,
      },
    ])
  })

  beforeEach(() => {
    mockUseForm.mockGetValues.mockRestore()
  })

  it.each([
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({
          btWrkId: "test",
        })
        mockUseForm.mockGetValues.mockReturnValue("test")
      },
      expect: () => {
        expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
        expect(mockUseModal.mockAlert).toHaveBeenCalledWith({
          content: "MSG#cannotEnrlSameBtch",
        })
      },
    },
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({
          btWrkId: "test",
        })
        mockUseForm.mockGetValues.mockReturnValue("no test")

        mockGrid.mockGetAllRows.mockReturnValueOnce([
          {
            btWrkId: "test",
          },
        ])
      },
      expect: () => {
        expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
        expect(mockUseModal.mockAlert).toHaveBeenCalledWith({
          content: "MSG#cannotEnrlSamePrevBtch",
        })
      },
    },
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({
          btWrkId: "test",
        })
        mockUseForm.mockGetValues.mockReturnValue("no test")

        mockGrid.mockGetAllRows
          .mockReturnValueOnce([
            {
              btWrkId: "01",
            },
          ])
          .mockReturnValueOnce([{}])
      },
      expect: () => {
        expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
        expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      },
    },
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({})
        mockUseForm.mockGetValues.mockReturnValue("test")
        mockGrid.mockGetAllRows
          .mockReturnValueOnce([
            {
              btWrkId: "01",
            },
          ])
          .mockReturnValueOnce([{}])
      },
      expect: () => {
        expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
        expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      },
    },
  ])("openBatchJobSelectionPopup Test", async (param) => {
    param.mocking()

    const { findByText } = render(component)
    const popupBtn = await findByText(/SCRNITM#addPrevBtchJob/)
    fireEvent.click(popupBtn)

    await waitFor(() => {
      param.expect()
    })
  })

  it("main Grid rowClassRules Test", async () => {
    const { findAllByText } = render(component)
    const rowClassRulesTestBtn = (await findAllByText(/rowClassRules Test/))[0]
    fireEvent.click(rowClassRulesTestBtn, {
      target: { data: { data: { aprvStsCd: "02" } } },
    })
  })

  it.each([
    {
      target: {
        data: {
          paramCd: undefined,
          cronCmd: "* * * * * *",
        },
      },
    },
    {
      target: {
        data: {
          paramCd: undefined,
          cronCmd: "1 1 1 1 * *",
        },
      },
    },
  ])("main Grid onRowClicked Test", async (data) => {
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          subOutList: [],
          totLen: 0,
        },
      })
      .mockResolvedValueOnce({
        data: {
          subOutList: [],
          totLen: 0,
        },
      })
    const { findAllByText } = render(component)
    const onRowClickedTestBtn = (await findAllByText(/onRowClicked Test/))[0]

    fireEvent.click(onRowClickedTestBtn, data)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("initClick Test", async () => {
    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)
  })

  it("addNewData Test", async () => {
    const { findByText } = render(component)
    const newBtn = await findByText(/SCRNITM#new/)
    fireEvent.click(newBtn)
  })

  it("searchBatchData Test", async () => {
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 0,
        subOutList: [],
      },
    })
    const { findByText } = render(component)
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })
  })

  it("saveBatch Test - not isEditable, confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([
      {
        crudType: undefined,
        btWrkId: "",
        btWrkNm: "",
      },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(true)
    mockUseProxy.mockAsync.mockResolvedValueOnce({}).mockResolvedValueOnce({
      data: {
        totLen: 0,
        subOutList: [],
      },
    })

    const { findByText } = render(component)
    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("saveBatch Test - isEditable, not confirm", async () => {
    mockGrid.mockGetAllRows.mockReturnValueOnce([
      {
        crudType: undefined,
        btWrkId: "",
        btWrkNm: "",
      },
    ])

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText } = render(component)
    const initBtn = await findByText(/SCRNITM#init/)
    fireEvent.click(initBtn)

    const saveBtn = await findByText(/SCRNITM#save/)
    fireEvent.click(saveBtn)

    await waitFor(() => {
      expect(mockGrid.mockGetAllRows).toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(0)
    })
  })

  it("deletePreBatch Test - selectRowList.length is 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([])
    const { findByText } = render(component)
    const delBtn = await findByText(/SCRNITM#delPrevBtchJob/)
    fireEvent.click(delBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(1)
    })
  })

  it("deletePreBatch Test - selectRowList.length > 0", async () => {
    mockGrid.mockGetSelectedRows.mockReturnValueOnce([
      {
        crudType: "D",
        btWrkId: "test",
        btWrkNm: "test",
      },
    ])

    mockGrid.mockDelRow.mockImplementationOnce((obj, fn1, fn2) => {
      fn1()
      fn2()
    })

    mockGrid.mockGetAllRows.mockReturnValueOnce([])

    const { findByText } = render(component)
    const delBtn = await findByText(/SCRNITM#delPrevBtchJob/)
    fireEvent.click(delBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalledTimes(2)
    })
  })

  it("handleSelectSchdDvsnCd Test", async () => {
    const { findByTestId } = render(component)
    const onChangeTestBtn = await within(
      await findByTestId(/SCRNITM#schdDvsnCd/),
    ).findByTestId("onChange")
    fireEvent.click(onChangeTestBtn, {
      target: {
        data: {},
      },
    })
  })

  it("useMemo Test", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "00"
        case "btWrkId":
          return "Y"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })
    render(component)
  })

  it("forcedBtch Test - btWrkId is undefined", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "00"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    const { findByText } = render(component)
    const runBtn = await findByText(/SCRNITM#run/)

    // make btWrkId is null
    mockUseForm.mockGetValues.mockReturnValueOnce(undefined)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("forcedBtch Test - findBtch.aprvStsCd is 01", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "00"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 1,
        subOutList: [
          {
            btWrkId: "test",
            useFl: "Y",
            aprvStsCd: "01",
          },
        ],
      },
    })

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("forcedBtch Test - schdDvsnCdValue is 00", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "00"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 1,
        subOutList: [
          {
            btWrkId: "test",
            useFl: "Y",
            aprvStsCd: "02",
          },
        ],
      },
    })

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).toHaveBeenCalled()
    })
  })

  it("forcedBtch Test - btchWrkExecRsltList.length > 0, codeLabel exists, confirm", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "01"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          totLen: 1,
          subOutList: [
            {
              btWrkId: "test",
              useFl: "Y",
              aprvStsCd: "02",
            },
          ],
        },
      })
      .mockResolvedValueOnce({
        data: {
          subOutList: [
            {
              cmpltStsCd: "test",
              execEdtm: 1,
            },
            {
              cmpltStsCd: "test",
              execEdtm: 2,
            },
          ],
        },
      })
      .mockResolvedValueOnce({})

    mockUseModal.mockConfirm.mockResolvedValueOnce(true)

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
    })
  })

  it("forcedBtch Test - btchWrkExecRsltList.length > 0, codeLabel is null, not confirm", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "01"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          totLen: 1,
          subOutList: [
            {
              btWrkId: "test",
              useFl: "Y",
              aprvStsCd: "02",
            },
          ],
        },
      })
      .mockResolvedValueOnce({
        data: {
          subOutList: [
            {
              cmpltStsCd: undefined,
              execEdtm: 1,
            },
            {
              cmpltStsCd: undefined,
              execEdtm: 2,
            },
          ],
        },
      })

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it("forcedBtch Test - btchWrkExecRsltList is undefined, confirm", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "01"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          totLen: 1,
          subOutList: [
            {
              btWrkId: "test",
              useFl: "Y",
              aprvStsCd: "02",
            },
          ],
        },
      })
      .mockResolvedValueOnce({
        data: {
          subOutList: undefined,
        },
      })
      .mockResolvedValueOnce({})

    mockUseModal.mockConfirm.mockResolvedValueOnce(true)

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(3)
    })
  })

  it("forcedBtch Test - btchWrkExecRsltList is undefined, not confirm", async () => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "01"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })

    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          totLen: 1,
          subOutList: [
            {
              btWrkId: "test",
              useFl: "Y",
              aprvStsCd: "02",
            },
          ],
        },
      })
      .mockResolvedValueOnce({
        data: {
          subOutList: undefined,
        },
      })

    mockUseModal.mockConfirm.mockResolvedValueOnce(false)

    const { findByText } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const runBtn = await findByText(/SCRNITM#run/)
    fireEvent.click(runBtn)

    await waitFor(() => {
      expect(mockUseModal.mockAlert).not.toHaveBeenCalled()
      expect(mockUseModal.mockConfirm).toHaveBeenCalled()
      expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2)
    })
  })

  it.each([
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({
          cronExpr: "* * * * * *",
        })
      },
    },
    {
      mocking: () => {
        mockUseModal.mockOpenPopup.mockResolvedValueOnce({
          cronExpr: undefined,
        })
      },
    },
  ])("openCronGenPopup Test", async (data) => {
    mockUseForm.mockGetValues.mockImplementation((key) => {
      switch (key) {
        case "schdDvsnCd":
          return "00"
        case "btWrkId":
          return "test"
        case "btchExecYn":
          return "Y"
        default:
          return key
      }
    })
    mockUseProxy.mockAsync.mockResolvedValueOnce({
      data: {
        totLen: 1,
        subOutList: [
          {
            btWrkId: "test",
            useFl: "Y",
            aprvStsCd: "02",
          },
        ],
      },
    })

    data.mocking()

    const { findByText, findAllByTestId } = render(component)

    // set grid data
    const searchBtn = await findByText(/SCRNITM#search/)
    fireEvent.click(searchBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).toHaveBeenCalled()
    })

    const cronPopupBtn = await within(
      (
        await findAllByTestId(/SCRNITM#cronCmd/)
      )[0],
    ).findByTestId("onClick")
    fireEvent.click(cronPopupBtn, { target: { data: {} } })

    await waitFor(() => {
      expect(mockUseModal.mockOpenPopup).toHaveBeenCalled()
    })
  })
})
