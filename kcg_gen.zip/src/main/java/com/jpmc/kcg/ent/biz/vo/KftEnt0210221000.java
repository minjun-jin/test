package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 회원정보 수취인/보증인 조회 응답
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID ELB
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0210
 * messageTrackingNumber 전문추적번호 221000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * conditionBeneSearchConditionSort 조건-수취인검색조건구분 
 * conditionBeneResidentBusinessNumber 조건-수취인주민(사업자)번호 
 * conditionBeneBankCode 조건-수취인은행코드 
 * conditionBeneDepositAccountNumber 조건-수취인입금계좌번호 
 * conditionGuarantorSearchConditionSort 조건-보증인검색조건구분 
 * conditionGuarantorResidentBusinessNumber 조건-보증인주민(사업자)번호 
 * conditionGuarantorBankCode 조건-보증인은행코드 
 * conditionGuarantorDepositAccountNumber 조건-보증인입금계좌번호 
 * resultbeneCorpIndvSort 결과-수취인법인개인구분 
 * resultbeneResidentBusinessNumber 결과-수취인주민(사업자)번호 
 * resultbeneNameRepresentativeName 결과-수취인성명(대표자명) 
 * resultbeneCorpName 결과-수취인법인명 
 * resultbeneAddress 결과-수취인주소 
 * resultbenePhoneNumber 결과-수취인전화번호 
 * resultbeneMobilePhoneNumber 결과-수취인핸드폰번호 
 * resultbeneEmail 결과-수취인이메일 
 * resultbeneMemberSort 결과-수취인회원구분 
 * resultbeneCompanySize 결과-수취인기업규모 
 * resultbeneIndustryCode 결과-수취인업종코드 
 * resultGuarantorCorpIndvSort 결과-보증인법인개인구분 
 * resultGuarantorResidentBusinessNumber 결과-보증인주민(사업자)번호 
 * resultGuarantorNameRepresentativeName 결과-보증인성명(대표자명) 
 * resultGuarantorCorpName 결과-보증인법인명 
 * resultGuarantorAddress 결과-보증인주소 
 * resultGuarantorPhoneNumber 결과-보증인전화번호 
 * resultGuarantorMobilePhoneNumber 결과-보증인핸드폰번호 
 * resultGuarantorEmail 결과-보증인이메일 
 * resultGuarantorMemberSort 결과-보증인회원구분 
 * resultGuarantorCompanySize 결과-보증인기업규모 
 * resultGuarantorIndustryCode 결과-보증인업종코드 
 * 
 * KftEnt0210221000 kftEnt0210221000 = new KftEnt0210221000(); // 회원정보 수취인/보증인 조회 응답
 * kftEnt0210221000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0210221000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0210221000.setBnkCd("057"); // 은행코드
 * kftEnt0210221000.setMessageType("0210"); // 전문종별코드
 * kftEnt0210221000.setTransactionCode("221000"); // 거래구분코드
 * kftEnt0210221000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0210221000.setSendReceiveFlag("2"); // 송수신FLAG
 * kftEnt0210221000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0210221000.setStatus("000"); // STATUS
 * kftEnt0210221000.setResponseCode1(""); // 응답코드1
 * kftEnt0210221000.setResponseCode2(""); // 응답코드2
 * kftEnt0210221000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0210221000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0210221000.setConditionBeneSearchConditionSort(""); // 조건-수취인검색조건구분
 * kftEnt0210221000.setConditionBeneResidentBusinessNumber(""); // 조건-수취인주민(사업자)번호
 * kftEnt0210221000.setConditionBeneBankCode(""); // 조건-수취인은행코드
 * kftEnt0210221000.setConditionBeneDepositAccountNumber(""); // 조건-수취인입금계좌번호
 * kftEnt0210221000.setConditionGuarantorSearchConditionSort(""); // 조건-보증인검색조건구분
 * kftEnt0210221000.setConditionGuarantorResidentBusinessNumber(""); // 조건-보증인주민(사업자)번호
 * kftEnt0210221000.setConditionGuarantorBankCode(""); // 조건-보증인은행코드
 * kftEnt0210221000.setConditionGuarantorDepositAccountNumber(""); // 조건-보증인입금계좌번호
 * kftEnt0210221000.setResultbeneCorpIndvSort(""); // 결과-수취인법인개인구분
 * kftEnt0210221000.setResultbeneResidentBusinessNumber(""); // 결과-수취인주민(사업자)번호
 * kftEnt0210221000.setResultbeneNameRepresentativeName(""); // 결과-수취인성명(대표자명)
 * kftEnt0210221000.setResultbeneCorpName(""); // 결과-수취인법인명
 * kftEnt0210221000.setResultbeneAddress(""); // 결과-수취인주소
 * kftEnt0210221000.setResultbenePhoneNumber(""); // 결과-수취인전화번호
 * kftEnt0210221000.setResultbeneMobilePhoneNumber(""); // 결과-수취인핸드폰번호
 * kftEnt0210221000.setResultbeneEmail(""); // 결과-수취인이메일
 * kftEnt0210221000.setResultbeneMemberSort(""); // 결과-수취인회원구분
 * kftEnt0210221000.setResultbeneCompanySize(""); // 결과-수취인기업규모
 * kftEnt0210221000.setResultbeneIndustryCode(""); // 결과-수취인업종코드
 * kftEnt0210221000.setResultGuarantorCorpIndvSort(""); // 결과-보증인법인개인구분
 * kftEnt0210221000.setResultGuarantorResidentBusinessNumber(""); // 결과-보증인주민(사업자)번호
 * kftEnt0210221000.setResultGuarantorNameRepresentativeName(""); // 결과-보증인성명(대표자명)
 * kftEnt0210221000.setResultGuarantorCorpName(""); // 결과-보증인법인명
 * kftEnt0210221000.setResultGuarantorAddress(""); // 결과-보증인주소
 * kftEnt0210221000.setResultGuarantorPhoneNumber(""); // 결과-보증인전화번호
 * kftEnt0210221000.setResultGuarantorMobilePhoneNumber(""); // 결과-보증인핸드폰번호
 * kftEnt0210221000.setResultGuarantorEmail(""); // 결과-보증인이메일
 * kftEnt0210221000.setResultGuarantorMemberSort(""); // 결과-보증인회원구분
 * kftEnt0210221000.setResultGuarantorCompanySize(""); // 결과-보증인기업규모
 * kftEnt0210221000.setResultGuarantorIndustryCode(""); // 결과-보증인업종코드
 * }</pre>
 */
@Data
public class KftEnt0210221000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0210"; // 전문종별코드
	private String transactionCode = "221000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag = "2"; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String conditionBeneSearchConditionSort; // 조건-수취인검색조건구분
	private String conditionBeneResidentBusinessNumber; // 조건-수취인주민(사업자)번호
	private String conditionBeneBankCode; // 조건-수취인은행코드
	private String conditionBeneDepositAccountNumber; // 조건-수취인입금계좌번호
	private String conditionGuarantorSearchConditionSort; // 조건-보증인검색조건구분
	private String conditionGuarantorResidentBusinessNumber; // 조건-보증인주민(사업자)번호
	private String conditionGuarantorBankCode; // 조건-보증인은행코드
	private String conditionGuarantorDepositAccountNumber; // 조건-보증인입금계좌번호
	private String resultbeneCorpIndvSort; // 결과-수취인법인개인구분
	private String resultbeneResidentBusinessNumber; // 결과-수취인주민(사업자)번호
	private String resultbeneNameRepresentativeName; // 결과-수취인성명(대표자명)
	private String resultbeneCorpName; // 결과-수취인법인명
	private String resultbeneAddress; // 결과-수취인주소
	private String resultbenePhoneNumber; // 결과-수취인전화번호
	private String resultbeneMobilePhoneNumber; // 결과-수취인핸드폰번호
	private String resultbeneEmail; // 결과-수취인이메일
	private String resultbeneMemberSort; // 결과-수취인회원구분
	private String resultbeneCompanySize; // 결과-수취인기업규모
	private String resultbeneIndustryCode; // 결과-수취인업종코드
	private String resultGuarantorCorpIndvSort; // 결과-보증인법인개인구분
	private String resultGuarantorResidentBusinessNumber; // 결과-보증인주민(사업자)번호
	private String resultGuarantorNameRepresentativeName; // 결과-보증인성명(대표자명)
	private String resultGuarantorCorpName; // 결과-보증인법인명
	private String resultGuarantorAddress; // 결과-보증인주소
	private String resultGuarantorPhoneNumber; // 결과-보증인전화번호
	private String resultGuarantorMobilePhoneNumber; // 결과-보증인핸드폰번호
	private String resultGuarantorEmail; // 결과-보증인이메일
	private String resultGuarantorMemberSort; // 결과-보증인회원구분
	private String resultGuarantorCompanySize; // 결과-보증인기업규모
	private String resultGuarantorIndustryCode; // 결과-보증인업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBeneSearchConditionSort$; // 조건-수취인검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBeneResidentBusinessNumber$; // 조건-수취인주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBeneBankCode$; // 조건-수취인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionBeneDepositAccountNumber$; // 조건-수취인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionGuarantorSearchConditionSort$; // 조건-보증인검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionGuarantorResidentBusinessNumber$; // 조건-보증인주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionGuarantorBankCode$; // 조건-보증인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String conditionGuarantorDepositAccountNumber$; // 조건-보증인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneCorpIndvSort$; // 결과-수취인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneResidentBusinessNumber$; // 결과-수취인주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneNameRepresentativeName$; // 결과-수취인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneCorpName$; // 결과-수취인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneAddress$; // 결과-수취인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbenePhoneNumber$; // 결과-수취인전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneMobilePhoneNumber$; // 결과-수취인핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneEmail$; // 결과-수취인이메일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneMemberSort$; // 결과-수취인회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneCompanySize$; // 결과-수취인기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultbeneIndustryCode$; // 결과-수취인업종코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorCorpIndvSort$; // 결과-보증인법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorResidentBusinessNumber$; // 결과-보증인주민(사업자)번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorNameRepresentativeName$; // 결과-보증인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorCorpName$; // 결과-보증인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorAddress$; // 결과-보증인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorPhoneNumber$; // 결과-보증인전화번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorMobilePhoneNumber$; // 결과-보증인핸드폰번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorEmail$; // 결과-보증인이메일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorMemberSort$; // 결과-보증인회원구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorCompanySize$; // 결과-보증인기업규모
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String resultGuarantorIndustryCode$; // 결과-보증인업종코드

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(conditionBeneDepositAccountNumber$)) { // 조건-수취인입금계좌번호
			return 16;
		}
		if (VOUtils.isNotAlphanumericSpace(conditionGuarantorDepositAccountNumber$)) { // 조건-보증인입금계좌번호
			return 20;
		}
		if (VOUtils.isNotAlphanumericSpace(resultbeneResidentBusinessNumber$)) { // 결과-수취인주민(사업자)번호
			return 22;
		}
		if (VOUtils.isNotAlphanumericSpace(resultbenePhoneNumber$)) { // 결과-수취인전화번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(resultbeneMobilePhoneNumber$)) { // 결과-수취인핸드폰번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(resultbeneEmail$)) { // 결과-수취인이메일
			return 28;
		}
		if (VOUtils.isNotAlphanumericSpace(resultGuarantorResidentBusinessNumber$)) { // 결과-보증인주민(사업자)번호
			return 33;
		}
		if (VOUtils.isNotAlphanumericSpace(resultGuarantorPhoneNumber$)) { // 결과-보증인전화번호
			return 37;
		}
		if (VOUtils.isNotAlphanumericSpace(resultGuarantorMobilePhoneNumber$)) { // 결과-보증인핸드폰번호
			return 38;
		}
		if (VOUtils.isNotAlphanumericSpace(resultGuarantorEmail$)) { // 결과-보증인이메일
			return 39;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		conditionBeneSearchConditionSort$ = VOUtils.write(out, conditionBeneSearchConditionSort, 1); // 조건-수취인검색조건구분
		conditionBeneResidentBusinessNumber$ = VOUtils.write(out, conditionBeneResidentBusinessNumber, 13); // 조건-수취인주민(사업자)번호
		conditionBeneBankCode$ = VOUtils.write(out, conditionBeneBankCode, 3); // 조건-수취인은행코드
		conditionBeneDepositAccountNumber$ = VOUtils.write(out, conditionBeneDepositAccountNumber, 16); // 조건-수취인입금계좌번호
		conditionGuarantorSearchConditionSort$ = VOUtils.write(out, conditionGuarantorSearchConditionSort, 1); // 조건-보증인검색조건구분
		conditionGuarantorResidentBusinessNumber$ = VOUtils.write(out, conditionGuarantorResidentBusinessNumber, 13); // 조건-보증인주민(사업자)번호
		conditionGuarantorBankCode$ = VOUtils.write(out, conditionGuarantorBankCode, 3); // 조건-보증인은행코드
		conditionGuarantorDepositAccountNumber$ = VOUtils.write(out, conditionGuarantorDepositAccountNumber, 16); // 조건-보증인입금계좌번호
		resultbeneCorpIndvSort$ = VOUtils.write(out, resultbeneCorpIndvSort, 1); // 결과-수취인법인개인구분
		resultbeneResidentBusinessNumber$ = VOUtils.write(out, resultbeneResidentBusinessNumber, 13); // 결과-수취인주민(사업자)번호
		resultbeneNameRepresentativeName$ = VOUtils.write(out, resultbeneNameRepresentativeName, 20, "EUC-KR"); // 결과-수취인성명(대표자명)
		resultbeneCorpName$ = VOUtils.write(out, resultbeneCorpName, 40, "EUC-KR"); // 결과-수취인법인명
		resultbeneAddress$ = VOUtils.write(out, resultbeneAddress, 60, "EUC-KR"); // 결과-수취인주소
		resultbenePhoneNumber$ = VOUtils.write(out, resultbenePhoneNumber, 14); // 결과-수취인전화번호
		resultbeneMobilePhoneNumber$ = VOUtils.write(out, resultbeneMobilePhoneNumber, 14); // 결과-수취인핸드폰번호
		resultbeneEmail$ = VOUtils.write(out, resultbeneEmail, 40); // 결과-수취인이메일
		resultbeneMemberSort$ = VOUtils.write(out, resultbeneMemberSort, 1); // 결과-수취인회원구분
		resultbeneCompanySize$ = VOUtils.write(out, resultbeneCompanySize, 1); // 결과-수취인기업규모
		resultbeneIndustryCode$ = VOUtils.write(out, resultbeneIndustryCode, 2); // 결과-수취인업종코드
		resultGuarantorCorpIndvSort$ = VOUtils.write(out, resultGuarantorCorpIndvSort, 1); // 결과-보증인법인개인구분
		resultGuarantorResidentBusinessNumber$ = VOUtils.write(out, resultGuarantorResidentBusinessNumber, 13); // 결과-보증인주민(사업자)번호
		resultGuarantorNameRepresentativeName$ = VOUtils.write(out, resultGuarantorNameRepresentativeName, 20, "EUC-KR"); // 결과-보증인성명(대표자명)
		resultGuarantorCorpName$ = VOUtils.write(out, resultGuarantorCorpName, 40, "EUC-KR"); // 결과-보증인법인명
		resultGuarantorAddress$ = VOUtils.write(out, resultGuarantorAddress, 60, "EUC-KR"); // 결과-보증인주소
		resultGuarantorPhoneNumber$ = VOUtils.write(out, resultGuarantorPhoneNumber, 14); // 결과-보증인전화번호
		resultGuarantorMobilePhoneNumber$ = VOUtils.write(out, resultGuarantorMobilePhoneNumber, 14); // 결과-보증인핸드폰번호
		resultGuarantorEmail$ = VOUtils.write(out, resultGuarantorEmail, 40); // 결과-보증인이메일
		resultGuarantorMemberSort$ = VOUtils.write(out, resultGuarantorMemberSort, 1); // 결과-보증인회원구분
		resultGuarantorCompanySize$ = VOUtils.write(out, resultGuarantorCompanySize, 1); // 결과-보증인기업규모
		resultGuarantorIndustryCode$ = VOUtils.write(out, resultGuarantorIndustryCode, 2); // 결과-보증인업종코드
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		conditionBeneSearchConditionSort = VOUtils.toString(conditionBeneSearchConditionSort$ = VOUtils.read(in, 1)); // 조건-수취인검색조건구분
		conditionBeneResidentBusinessNumber = VOUtils.toString(conditionBeneResidentBusinessNumber$ = VOUtils.read(in, 13)); // 조건-수취인주민(사업자)번호
		conditionBeneBankCode = VOUtils.toString(conditionBeneBankCode$ = VOUtils.read(in, 3)); // 조건-수취인은행코드
		conditionBeneDepositAccountNumber = VOUtils.toString(conditionBeneDepositAccountNumber$ = VOUtils.read(in, 16)); // 조건-수취인입금계좌번호
		conditionGuarantorSearchConditionSort = VOUtils.toString(conditionGuarantorSearchConditionSort$ = VOUtils.read(in, 1)); // 조건-보증인검색조건구분
		conditionGuarantorResidentBusinessNumber = VOUtils.toString(conditionGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 조건-보증인주민(사업자)번호
		conditionGuarantorBankCode = VOUtils.toString(conditionGuarantorBankCode$ = VOUtils.read(in, 3)); // 조건-보증인은행코드
		conditionGuarantorDepositAccountNumber = VOUtils.toString(conditionGuarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // 조건-보증인입금계좌번호
		resultbeneCorpIndvSort = VOUtils.toString(resultbeneCorpIndvSort$ = VOUtils.read(in, 1)); // 결과-수취인법인개인구분
		resultbeneResidentBusinessNumber = VOUtils.toString(resultbeneResidentBusinessNumber$ = VOUtils.read(in, 13)); // 결과-수취인주민(사업자)번호
		resultbeneNameRepresentativeName = VOUtils.toString(resultbeneNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 결과-수취인성명(대표자명)
		resultbeneCorpName = VOUtils.toString(resultbeneCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 결과-수취인법인명
		resultbeneAddress = VOUtils.toString(resultbeneAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 결과-수취인주소
		resultbenePhoneNumber = VOUtils.toString(resultbenePhoneNumber$ = VOUtils.read(in, 14)); // 결과-수취인전화번호
		resultbeneMobilePhoneNumber = VOUtils.toString(resultbeneMobilePhoneNumber$ = VOUtils.read(in, 14)); // 결과-수취인핸드폰번호
		resultbeneEmail = VOUtils.toString(resultbeneEmail$ = VOUtils.read(in, 40)); // 결과-수취인이메일
		resultbeneMemberSort = VOUtils.toString(resultbeneMemberSort$ = VOUtils.read(in, 1)); // 결과-수취인회원구분
		resultbeneCompanySize = VOUtils.toString(resultbeneCompanySize$ = VOUtils.read(in, 1)); // 결과-수취인기업규모
		resultbeneIndustryCode = VOUtils.toString(resultbeneIndustryCode$ = VOUtils.read(in, 2)); // 결과-수취인업종코드
		resultGuarantorCorpIndvSort = VOUtils.toString(resultGuarantorCorpIndvSort$ = VOUtils.read(in, 1)); // 결과-보증인법인개인구분
		resultGuarantorResidentBusinessNumber = VOUtils.toString(resultGuarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 결과-보증인주민(사업자)번호
		resultGuarantorNameRepresentativeName = VOUtils.toString(resultGuarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 결과-보증인성명(대표자명)
		resultGuarantorCorpName = VOUtils.toString(resultGuarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 결과-보증인법인명
		resultGuarantorAddress = VOUtils.toString(resultGuarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 결과-보증인주소
		resultGuarantorPhoneNumber = VOUtils.toString(resultGuarantorPhoneNumber$ = VOUtils.read(in, 14)); // 결과-보증인전화번호
		resultGuarantorMobilePhoneNumber = VOUtils.toString(resultGuarantorMobilePhoneNumber$ = VOUtils.read(in, 14)); // 결과-보증인핸드폰번호
		resultGuarantorEmail = VOUtils.toString(resultGuarantorEmail$ = VOUtils.read(in, 40)); // 결과-보증인이메일
		resultGuarantorMemberSort = VOUtils.toString(resultGuarantorMemberSort$ = VOUtils.read(in, 1)); // 결과-보증인회원구분
		resultGuarantorCompanySize = VOUtils.toString(resultGuarantorCompanySize$ = VOUtils.read(in, 1)); // 결과-보증인기업규모
		resultGuarantorIndustryCode = VOUtils.toString(resultGuarantorIndustryCode$ = VOUtils.read(in, 2)); // 결과-보증인업종코드
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", conditionBeneSearchConditionSort=").append(conditionBeneSearchConditionSort).append(System.lineSeparator()); // 조건-수취인검색조건구분
		sb.append(", conditionBeneResidentBusinessNumber=").append(conditionBeneResidentBusinessNumber).append(System.lineSeparator()); // 조건-수취인주민(사업자)번호
		sb.append(", conditionBeneBankCode=").append(conditionBeneBankCode).append(System.lineSeparator()); // 조건-수취인은행코드
		sb.append(", conditionBeneDepositAccountNumber=").append(conditionBeneDepositAccountNumber).append(System.lineSeparator()); // 조건-수취인입금계좌번호
		sb.append(", conditionGuarantorSearchConditionSort=").append(conditionGuarantorSearchConditionSort).append(System.lineSeparator()); // 조건-보증인검색조건구분
		sb.append(", conditionGuarantorResidentBusinessNumber=").append(conditionGuarantorResidentBusinessNumber).append(System.lineSeparator()); // 조건-보증인주민(사업자)번호
		sb.append(", conditionGuarantorBankCode=").append(conditionGuarantorBankCode).append(System.lineSeparator()); // 조건-보증인은행코드
		sb.append(", conditionGuarantorDepositAccountNumber=").append(conditionGuarantorDepositAccountNumber).append(System.lineSeparator()); // 조건-보증인입금계좌번호
		sb.append(", resultbeneCorpIndvSort=").append(resultbeneCorpIndvSort).append(System.lineSeparator()); // 결과-수취인법인개인구분
		sb.append(", resultbeneResidentBusinessNumber=").append(resultbeneResidentBusinessNumber).append(System.lineSeparator()); // 결과-수취인주민(사업자)번호
		sb.append(", resultbeneNameRepresentativeName=").append(resultbeneNameRepresentativeName).append(System.lineSeparator()); // 결과-수취인성명(대표자명)
		sb.append(", resultbeneCorpName=").append(resultbeneCorpName).append(System.lineSeparator()); // 결과-수취인법인명
		sb.append(", resultbeneAddress=").append(resultbeneAddress).append(System.lineSeparator()); // 결과-수취인주소
		sb.append(", resultbenePhoneNumber=").append(resultbenePhoneNumber).append(System.lineSeparator()); // 결과-수취인전화번호
		sb.append(", resultbeneMobilePhoneNumber=").append(resultbeneMobilePhoneNumber).append(System.lineSeparator()); // 결과-수취인핸드폰번호
		sb.append(", resultbeneEmail=").append(resultbeneEmail).append(System.lineSeparator()); // 결과-수취인이메일
		sb.append(", resultbeneMemberSort=").append(resultbeneMemberSort).append(System.lineSeparator()); // 결과-수취인회원구분
		sb.append(", resultbeneCompanySize=").append(resultbeneCompanySize).append(System.lineSeparator()); // 결과-수취인기업규모
		sb.append(", resultbeneIndustryCode=").append(resultbeneIndustryCode).append(System.lineSeparator()); // 결과-수취인업종코드
		sb.append(", resultGuarantorCorpIndvSort=").append(resultGuarantorCorpIndvSort).append(System.lineSeparator()); // 결과-보증인법인개인구분
		sb.append(", resultGuarantorResidentBusinessNumber=").append(resultGuarantorResidentBusinessNumber).append(System.lineSeparator()); // 결과-보증인주민(사업자)번호
		sb.append(", resultGuarantorNameRepresentativeName=").append(resultGuarantorNameRepresentativeName).append(System.lineSeparator()); // 결과-보증인성명(대표자명)
		sb.append(", resultGuarantorCorpName=").append(resultGuarantorCorpName).append(System.lineSeparator()); // 결과-보증인법인명
		sb.append(", resultGuarantorAddress=").append(resultGuarantorAddress).append(System.lineSeparator()); // 결과-보증인주소
		sb.append(", resultGuarantorPhoneNumber=").append(resultGuarantorPhoneNumber).append(System.lineSeparator()); // 결과-보증인전화번호
		sb.append(", resultGuarantorMobilePhoneNumber=").append(resultGuarantorMobilePhoneNumber).append(System.lineSeparator()); // 결과-보증인핸드폰번호
		sb.append(", resultGuarantorEmail=").append(resultGuarantorEmail).append(System.lineSeparator()); // 결과-보증인이메일
		sb.append(", resultGuarantorMemberSort=").append(resultGuarantorMemberSort).append(System.lineSeparator()); // 결과-보증인회원구분
		sb.append(", resultGuarantorCompanySize=").append(resultGuarantorCompanySize).append(System.lineSeparator()); // 결과-보증인기업규모
		sb.append(", resultGuarantorIndustryCode=").append(resultGuarantorIndustryCode).append(System.lineSeparator()); // 결과-보증인업종코드
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "221000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "2"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "conditionBeneSearchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "conditionBeneResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "conditionBeneBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "conditionBeneDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "conditionGuarantorSearchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "conditionGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "conditionGuarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "conditionGuarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "resultbeneCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultbeneResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "resultbeneNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "resultbeneCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultbeneAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "resultbenePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultbeneMobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultbeneEmail", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultbeneMemberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultbeneCompanySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultbeneIndustryCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "resultGuarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultGuarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "resultGuarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "resultGuarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultGuarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "resultGuarantorPhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultGuarantorMobilePhoneNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "resultGuarantorEmail", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "resultGuarantorMemberSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultGuarantorCompanySize", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "resultGuarantorIndustryCode", "fldLen", "2", "defltVal", "")
		);
	}

}
