package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 수령거부 및 반환 통지
 * <pre>{@code
 * msgType 메시지구분 메시지구분
 * systemSendReceiveTime 시스템송수신시간 
 * msgNo 메시지번호(Key) 
 * messageType 전문종별코드 0200,0210
 * transactionCode 거래구분코드 210000
 * transactionIdNumber 거래고유번호 
 * bnkCd 은행코드 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * filler FILLER 
 * refusalOfReceiptReturnSort 수령거부,반환구분 
 * issuanceEndorsementAftermaturedEndorsementSort 발행,배서,기한후배서구분 
 * refusalOfReceiptReturnRequestDate 수령거부,반환요청일자 
 * eNoteNumber 어음요건전자어음번호 
 * eNoteType 어음요건어음종류 
 * eNoteIssueDate 어음요건전자어음발행일자 
 * eNoteIssuePlace 어음요건전자어음발행지 
 * eNoteAmount 어음요건전자어음금액 
 * eNoteMaturedDate 어음요건전자어음만기일자 
 * paymentBankAndBranchCode 어음요건지급은행및지점코드 
 * otherPartyInfoCorpIndvSortCode 상대방정보법인개인구분코드 
 * otherPartyInfoResidentBusinessNumber 상대방정보주민사업자번호 
 * otherPartyInfoCorpName 상대방정보법인명 
 * otherPartyInfoNameRepresentativeName 상대방정보성명(대표자명) 
 * otherPartyInfoAddress 상대방정보주소 
 * otherPartyInfoBankCode 상대방정보은행코드 
 * otherPartyInfoCurrentAccountNumber 상대방정보당좌계좌번호 
 * requesterInfoCorpIndvSortCode 요청인정보법인개인구분코드 
 * requesterInfoResidentBusinessNumber 요청인정보주민사업자번호 
 * requesterInfoCorpName 요청인정보법인명 
 * requesterInfoNameRepresentativeName 요청인정보성명(대표자명) 
 * requesterInfoAddress 요청인정보주소 
 * requesterInfoBankCode 요청인정보은행코드 
 * requesterInfoRefusalOfReceiptAndReturnAmount 요청인정보수령거부및반환금액 
 * requesterInfoDepositAccountNumber 요청인정보입금계좌번호 
 * requesterInfoSplitNumber 요청인정보분할번호 
 * requesterInfoEndorsementNumber 요청인정보배서번호 
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * CqeEnt0200300000 cqeEnt0200300000 = new CqeEnt0200300000(); // 수령거부 및 반환 통지
 * cqeEnt0200300000.setMsgType("CQEKCG"); // 메시지구분
 * cqeEnt0200300000.setSystemSendReceiveTime(LocalDateTime.now()); // 시스템송수신시간
 * cqeEnt0200300000.setMsgNo("00000000"); // 메시지번호(Key)
 * cqeEnt0200300000.setMessageType("0200"); // 전문종별코드
 * cqeEnt0200300000.setTransactionCode("300000"); // 거래구분코드
 * cqeEnt0200300000.setTransactionIdNumber(""); // 거래고유번호
 * cqeEnt0200300000.setBnkCd("057"); // 은행코드
 * cqeEnt0200300000.setResponseCode1("   "); // 응답코드1
 * cqeEnt0200300000.setResponseCode2(""); // 응답코드2
 * cqeEnt0200300000.setFiller(""); // FILLER
 * cqeEnt0200300000.setRefusalOfReceiptReturnSort(""); // 수령거부,반환구분
 * cqeEnt0200300000.setIssuanceEndorsementAftermaturedEndorsementSort(""); // 발행,배서,기한후배서구분
 * cqeEnt0200300000.setRefusalOfReceiptReturnRequestDate(""); // 수령거부,반환요청일자
 * cqeEnt0200300000.setENoteNumber(""); // 어음요건전자어음번호
 * cqeEnt0200300000.setENoteType(""); // 어음요건어음종류
 * cqeEnt0200300000.setENoteIssueDate(""); // 어음요건전자어음발행일자
 * cqeEnt0200300000.setENoteIssuePlace(""); // 어음요건전자어음발행지
 * cqeEnt0200300000.setENoteAmount(0L); // 어음요건전자어음금액
 * cqeEnt0200300000.setENoteMaturedDate(""); // 어음요건전자어음만기일자
 * cqeEnt0200300000.setPaymentBankAndBranchCode(""); // 어음요건지급은행및지점코드
 * cqeEnt0200300000.setOtherPartyInfoCorpIndvSortCode(""); // 상대방정보법인개인구분코드
 * cqeEnt0200300000.setOtherPartyInfoResidentBusinessNumber(""); // 상대방정보주민사업자번호
 * cqeEnt0200300000.setOtherPartyInfoCorpName(""); // 상대방정보법인명
 * cqeEnt0200300000.setOtherPartyInfoNameRepresentativeName(""); // 상대방정보성명(대표자명)
 * cqeEnt0200300000.setOtherPartyInfoAddress(""); // 상대방정보주소
 * cqeEnt0200300000.setOtherPartyInfoBankCode(""); // 상대방정보은행코드
 * cqeEnt0200300000.setOtherPartyInfoCurrentAccountNumber(""); // 상대방정보당좌계좌번호
 * cqeEnt0200300000.setRequesterInfoCorpIndvSortCode(""); // 요청인정보법인개인구분코드
 * cqeEnt0200300000.setRequesterInfoResidentBusinessNumber(""); // 요청인정보주민사업자번호
 * cqeEnt0200300000.setRequesterInfoCorpName(""); // 요청인정보법인명
 * cqeEnt0200300000.setRequesterInfoNameRepresentativeName(""); // 요청인정보성명(대표자명)
 * cqeEnt0200300000.setRequesterInfoAddress(""); // 요청인정보주소
 * cqeEnt0200300000.setRequesterInfoBankCode(""); // 요청인정보은행코드
 * cqeEnt0200300000.setRequesterInfoRefusalOfReceiptAndReturnAmount(""); // 요청인정보수령거부및반환금액
 * cqeEnt0200300000.setRequesterInfoDepositAccountNumber(""); // 요청인정보입금계좌번호
 * cqeEnt0200300000.setRequesterInfoSplitNumber(""); // 요청인정보분할번호
 * cqeEnt0200300000.setRequesterInfoEndorsementNumber(""); // 요청인정보배서번호
 * cqeEnt0200300000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * cqeEnt0200300000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class CqeEnt0200300000 implements CqeEntComHdr, Vo {

	private String msgType = "CQEKCG"; // 메시지구분
	private LocalDateTime systemSendReceiveTime; // 시스템송수신시간
	private String msgNo = "00000000"; // 메시지번호(Key)
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "300000"; // 거래구분코드
	private String transactionIdNumber; // 거래고유번호
	private String bnkCd = "057"; // 은행코드
	private String responseCode1 = "   "; // 응답코드1
	private String responseCode2; // 응답코드2
	private String filler; // FILLER
	private String refusalOfReceiptReturnSort; // 수령거부,반환구분
	private String issuanceEndorsementAftermaturedEndorsementSort; // 발행,배서,기한후배서구분
	private String refusalOfReceiptReturnRequestDate; // 수령거부,반환요청일자
	private String eNoteNumber; // 어음요건전자어음번호
	private String eNoteType; // 어음요건어음종류
	private String eNoteIssueDate; // 어음요건전자어음발행일자
	private String eNoteIssuePlace; // 어음요건전자어음발행지
	private long eNoteAmount; // 어음요건전자어음금액
	private String eNoteMaturedDate; // 어음요건전자어음만기일자
	private String paymentBankAndBranchCode; // 어음요건지급은행및지점코드
	private String otherPartyInfoCorpIndvSortCode; // 상대방정보법인개인구분코드
	private String otherPartyInfoResidentBusinessNumber; // 상대방정보주민사업자번호
	private String otherPartyInfoCorpName; // 상대방정보법인명
	private String otherPartyInfoNameRepresentativeName; // 상대방정보성명(대표자명)
	private String otherPartyInfoAddress; // 상대방정보주소
	private String otherPartyInfoBankCode; // 상대방정보은행코드
	private String otherPartyInfoCurrentAccountNumber; // 상대방정보당좌계좌번호
	private String requesterInfoCorpIndvSortCode; // 요청인정보법인개인구분코드
	private String requesterInfoResidentBusinessNumber; // 요청인정보주민사업자번호
	private String requesterInfoCorpName; // 요청인정보법인명
	private String requesterInfoNameRepresentativeName; // 요청인정보성명(대표자명)
	private String requesterInfoAddress; // 요청인정보주소
	private String requesterInfoBankCode; // 요청인정보은행코드
	private String requesterInfoRefusalOfReceiptAndReturnAmount; // 요청인정보수령거부및반환금액
	private String requesterInfoDepositAccountNumber; // 요청인정보입금계좌번호
	private String requesterInfoSplitNumber; // 요청인정보분할번호
	private String requesterInfoEndorsementNumber; // 요청인정보배서번호
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgType$; // 메시지구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemSendReceiveTime$; // 시스템송수신시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String msgNo$; // 메시지번호(Key)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptReturnSort$; // 수령거부,반환구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuanceEndorsementAftermaturedEndorsementSort$; // 발행,배서,기한후배서구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String refusalOfReceiptReturnRequestDate$; // 수령거부,반환요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 어음요건전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음요건어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 어음요건전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 어음요건전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 어음요건전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 어음요건전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 어음요건지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCorpIndvSortCode$; // 상대방정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoResidentBusinessNumber$; // 상대방정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCorpName$; // 상대방정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoNameRepresentativeName$; // 상대방정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoAddress$; // 상대방정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoBankCode$; // 상대방정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String otherPartyInfoCurrentAccountNumber$; // 상대방정보당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoCorpIndvSortCode$; // 요청인정보법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoResidentBusinessNumber$; // 요청인정보주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoCorpName$; // 요청인정보법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoNameRepresentativeName$; // 요청인정보성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoAddress$; // 요청인정보주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoBankCode$; // 요청인정보은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoRefusalOfReceiptAndReturnAmount$; // 요청인정보수령거부및반환금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoDepositAccountNumber$; // 요청인정보입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoSplitNumber$; // 요청인정보분할번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requesterInfoEndorsementNumber$; // 요청인정보배서번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(msgType$)) { // 메시지구분
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionCode$)) { // 거래구분코드
			return 4;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 8;
		}
		if (VOUtils.isNotAlphanumericSpace(issuanceEndorsementAftermaturedEndorsementSort$)) { // 발행,배서,기한후배서구분
			return 11;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 어음요건전자어음번호
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(otherPartyInfoResidentBusinessNumber$)) { // 상대방정보주민사업자번호
			return 21;
		}
		if (VOUtils.isNotAlphanumericSpace(otherPartyInfoCurrentAccountNumber$)) { // 상대방정보당좌계좌번호
			return 26;
		}
		if (VOUtils.isNotAlphanumericSpace(requesterInfoResidentBusinessNumber$)) { // 요청인정보주민사업자번호
			return 28;
		}
		if (VOUtils.isNotAlphanumericSpace(requesterInfoRefusalOfReceiptAndReturnAmount$)) { // 요청인정보수령거부및반환금액
			return 33;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		msgType$ = VOUtils.write(out, msgType, 6); // 메시지구분
		systemSendReceiveTime$ = VOUtils.write(out, systemSendReceiveTime, 14, "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo$ = VOUtils.write(out, msgNo, 8); // 메시지번호(Key)
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		filler$ = VOUtils.write(out, filler, 50); // FILLER
		refusalOfReceiptReturnSort$ = VOUtils.write(out, refusalOfReceiptReturnSort, 1); // 수령거부,반환구분
		issuanceEndorsementAftermaturedEndorsementSort$ = VOUtils.write(out, issuanceEndorsementAftermaturedEndorsementSort, 1); // 발행,배서,기한후배서구분
		refusalOfReceiptReturnRequestDate$ = VOUtils.write(out, refusalOfReceiptReturnRequestDate, 8); // 수령거부,반환요청일자
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 어음요건전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음요건어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 어음요건전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 어음요건전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 어음요건전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 어음요건전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 어음요건지급은행및지점코드
		otherPartyInfoCorpIndvSortCode$ = VOUtils.write(out, otherPartyInfoCorpIndvSortCode, 1); // 상대방정보법인개인구분코드
		otherPartyInfoResidentBusinessNumber$ = VOUtils.write(out, otherPartyInfoResidentBusinessNumber, 13); // 상대방정보주민사업자번호
		otherPartyInfoCorpName$ = VOUtils.write(out, otherPartyInfoCorpName, 40, "EUC-KR"); // 상대방정보법인명
		otherPartyInfoNameRepresentativeName$ = VOUtils.write(out, otherPartyInfoNameRepresentativeName, 20, "EUC-KR"); // 상대방정보성명(대표자명)
		otherPartyInfoAddress$ = VOUtils.write(out, otherPartyInfoAddress, 60, "EUC-KR"); // 상대방정보주소
		otherPartyInfoBankCode$ = VOUtils.write(out, otherPartyInfoBankCode, 3); // 상대방정보은행코드
		otherPartyInfoCurrentAccountNumber$ = VOUtils.write(out, otherPartyInfoCurrentAccountNumber, 16); // 상대방정보당좌계좌번호
		requesterInfoCorpIndvSortCode$ = VOUtils.write(out, requesterInfoCorpIndvSortCode, 1); // 요청인정보법인개인구분코드
		requesterInfoResidentBusinessNumber$ = VOUtils.write(out, requesterInfoResidentBusinessNumber, 13); // 요청인정보주민사업자번호
		requesterInfoCorpName$ = VOUtils.write(out, requesterInfoCorpName, 40, "EUC-KR"); // 요청인정보법인명
		requesterInfoNameRepresentativeName$ = VOUtils.write(out, requesterInfoNameRepresentativeName, 20, "EUC-KR"); // 요청인정보성명(대표자명)
		requesterInfoAddress$ = VOUtils.write(out, requesterInfoAddress, 60, "EUC-KR"); // 요청인정보주소
		requesterInfoBankCode$ = VOUtils.write(out, requesterInfoBankCode, 3); // 요청인정보은행코드
		requesterInfoRefusalOfReceiptAndReturnAmount$ = VOUtils.write(out, requesterInfoRefusalOfReceiptAndReturnAmount, 15); // 요청인정보수령거부및반환금액
		requesterInfoDepositAccountNumber$ = VOUtils.write(out, requesterInfoDepositAccountNumber, 16); // 요청인정보입금계좌번호
		requesterInfoSplitNumber$ = VOUtils.write(out, requesterInfoSplitNumber, 2); // 요청인정보분할번호
		requesterInfoEndorsementNumber$ = VOUtils.write(out, requesterInfoEndorsementNumber, 2); // 요청인정보배서번호
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		msgType = VOUtils.toString(msgType$ = VOUtils.read(in, 6)); // 메시지구분
		systemSendReceiveTime = VOUtils.toLocalDateTime(systemSendReceiveTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 시스템송수신시간
		msgNo = VOUtils.toString(msgNo$ = VOUtils.read(in, 8)); // 메시지번호(Key)
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 50)); // FILLER
		refusalOfReceiptReturnSort = VOUtils.toString(refusalOfReceiptReturnSort$ = VOUtils.read(in, 1)); // 수령거부,반환구분
		issuanceEndorsementAftermaturedEndorsementSort = VOUtils.toString(issuanceEndorsementAftermaturedEndorsementSort$ = VOUtils.read(in, 1)); // 발행,배서,기한후배서구분
		refusalOfReceiptReturnRequestDate = VOUtils.toString(refusalOfReceiptReturnRequestDate$ = VOUtils.read(in, 8)); // 수령거부,반환요청일자
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 어음요건전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음요건어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 어음요건전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음요건전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 어음요건전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 어음요건전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 어음요건지급은행및지점코드
		otherPartyInfoCorpIndvSortCode = VOUtils.toString(otherPartyInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 상대방정보법인개인구분코드
		otherPartyInfoResidentBusinessNumber = VOUtils.toString(otherPartyInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 상대방정보주민사업자번호
		otherPartyInfoCorpName = VOUtils.toString(otherPartyInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 상대방정보법인명
		otherPartyInfoNameRepresentativeName = VOUtils.toString(otherPartyInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 상대방정보성명(대표자명)
		otherPartyInfoAddress = VOUtils.toString(otherPartyInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 상대방정보주소
		otherPartyInfoBankCode = VOUtils.toString(otherPartyInfoBankCode$ = VOUtils.read(in, 3)); // 상대방정보은행코드
		otherPartyInfoCurrentAccountNumber = VOUtils.toString(otherPartyInfoCurrentAccountNumber$ = VOUtils.read(in, 16)); // 상대방정보당좌계좌번호
		requesterInfoCorpIndvSortCode = VOUtils.toString(requesterInfoCorpIndvSortCode$ = VOUtils.read(in, 1)); // 요청인정보법인개인구분코드
		requesterInfoResidentBusinessNumber = VOUtils.toString(requesterInfoResidentBusinessNumber$ = VOUtils.read(in, 13)); // 요청인정보주민사업자번호
		requesterInfoCorpName = VOUtils.toString(requesterInfoCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 요청인정보법인명
		requesterInfoNameRepresentativeName = VOUtils.toString(requesterInfoNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 요청인정보성명(대표자명)
		requesterInfoAddress = VOUtils.toString(requesterInfoAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 요청인정보주소
		requesterInfoBankCode = VOUtils.toString(requesterInfoBankCode$ = VOUtils.read(in, 3)); // 요청인정보은행코드
		requesterInfoRefusalOfReceiptAndReturnAmount = VOUtils.toString(requesterInfoRefusalOfReceiptAndReturnAmount$ = VOUtils.read(in, 15)); // 요청인정보수령거부및반환금액
		requesterInfoDepositAccountNumber = VOUtils.toString(requesterInfoDepositAccountNumber$ = VOUtils.read(in, 16)); // 요청인정보입금계좌번호
		requesterInfoSplitNumber = VOUtils.toString(requesterInfoSplitNumber$ = VOUtils.read(in, 2)); // 요청인정보분할번호
		requesterInfoEndorsementNumber = VOUtils.toString(requesterInfoEndorsementNumber$ = VOUtils.read(in, 2)); // 요청인정보배서번호
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", msgType=").append(msgType).append(System.lineSeparator()); // 메시지구분
		sb.append(", systemSendReceiveTime=").append(systemSendReceiveTime).append(System.lineSeparator()); // 시스템송수신시간
		sb.append(", msgNo=").append(msgNo).append(System.lineSeparator()); // 메시지번호(Key)
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append(", refusalOfReceiptReturnSort=").append(refusalOfReceiptReturnSort).append(System.lineSeparator()); // 수령거부,반환구분
		sb.append(", issuanceEndorsementAftermaturedEndorsementSort=").append(issuanceEndorsementAftermaturedEndorsementSort).append(System.lineSeparator()); // 발행,배서,기한후배서구분
		sb.append(", refusalOfReceiptReturnRequestDate=").append(refusalOfReceiptReturnRequestDate).append(System.lineSeparator()); // 수령거부,반환요청일자
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 어음요건전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음요건어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 어음요건전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 어음요건전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 어음요건전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 어음요건전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 어음요건지급은행및지점코드
		sb.append(", otherPartyInfoCorpIndvSortCode=").append(otherPartyInfoCorpIndvSortCode).append(System.lineSeparator()); // 상대방정보법인개인구분코드
		sb.append(", otherPartyInfoResidentBusinessNumber=").append(otherPartyInfoResidentBusinessNumber).append(System.lineSeparator()); // 상대방정보주민사업자번호
		sb.append(", otherPartyInfoCorpName=").append(otherPartyInfoCorpName).append(System.lineSeparator()); // 상대방정보법인명
		sb.append(", otherPartyInfoNameRepresentativeName=").append(otherPartyInfoNameRepresentativeName).append(System.lineSeparator()); // 상대방정보성명(대표자명)
		sb.append(", otherPartyInfoAddress=").append(otherPartyInfoAddress).append(System.lineSeparator()); // 상대방정보주소
		sb.append(", otherPartyInfoBankCode=").append(otherPartyInfoBankCode).append(System.lineSeparator()); // 상대방정보은행코드
		sb.append(", otherPartyInfoCurrentAccountNumber=").append(otherPartyInfoCurrentAccountNumber).append(System.lineSeparator()); // 상대방정보당좌계좌번호
		sb.append(", requesterInfoCorpIndvSortCode=").append(requesterInfoCorpIndvSortCode).append(System.lineSeparator()); // 요청인정보법인개인구분코드
		sb.append(", requesterInfoResidentBusinessNumber=").append(requesterInfoResidentBusinessNumber).append(System.lineSeparator()); // 요청인정보주민사업자번호
		sb.append(", requesterInfoCorpName=").append(requesterInfoCorpName).append(System.lineSeparator()); // 요청인정보법인명
		sb.append(", requesterInfoNameRepresentativeName=").append(requesterInfoNameRepresentativeName).append(System.lineSeparator()); // 요청인정보성명(대표자명)
		sb.append(", requesterInfoAddress=").append(requesterInfoAddress).append(System.lineSeparator()); // 요청인정보주소
		sb.append(", requesterInfoBankCode=").append(requesterInfoBankCode).append(System.lineSeparator()); // 요청인정보은행코드
		sb.append(", requesterInfoRefusalOfReceiptAndReturnAmount=").append(requesterInfoRefusalOfReceiptAndReturnAmount).append(System.lineSeparator()); // 요청인정보수령거부및반환금액
		sb.append(", requesterInfoDepositAccountNumber=").append(requesterInfoDepositAccountNumber).append(System.lineSeparator()); // 요청인정보입금계좌번호
		sb.append(", requesterInfoSplitNumber=").append(requesterInfoSplitNumber).append(System.lineSeparator()); // 요청인정보분할번호
		sb.append(", requesterInfoEndorsementNumber=").append(requesterInfoEndorsementNumber).append(System.lineSeparator()); // 요청인정보배서번호
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "msgType", "fldLen", "6", "defltVal", "CQEKCG"),
			Map.of("fld", "systemSendReceiveTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "msgNo", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "300000"),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", "   "),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "50", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptReturnSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuanceEndorsementAftermaturedEndorsementSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "refusalOfReceiptReturnRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "otherPartyInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "otherPartyInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "otherPartyInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "otherPartyInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "otherPartyInfoCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterInfoCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "requesterInfoResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "requesterInfoCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "requesterInfoNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "requesterInfoAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "requesterInfoBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requesterInfoRefusalOfReceiptAndReturnAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "requesterInfoDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "requesterInfoSplitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "requesterInfoEndorsementNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
