package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;

import java.io.OutputStream;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.bat.ChunkBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dao.BatCmsCorpTotLDao;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.cms.dto.BatCmsDbtTrnsRqstRsltVo;
import com.jpmc.kcg.cms.biz.CmsAccountValidator;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.cms.biz.vo.KftCmsEC23R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEC23T;
import com.jpmc.kcg.cms.biz.vo.LvbCmsEC23;
import com.jpmc.kcg.cms.constants.CmsConst;
import com.jpmc.kcg.cms.dto.AccountOut;
import com.jpmc.kcg.cms.dto.CmsCorpTotL;
import com.jpmc.kcg.cms.dto.CmsSndRcvFileL;
import com.jpmc.kcg.cms.enums.CmsBatchRespCdEnum;
import com.jpmc.kcg.cms.enums.CmsPrcsStsDvsnCdEnum;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.frw.bat.BatContextImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * EC23 (출금의뢰내역)입금 지시
 * (Debit Transfer Request) Deposit Instruction
 */
@Component
@Slf4j
public class CmsDbtTrnsSmDayDpstInstrJobBean extends ChunkBatJob<CmsSndRcvFileL, BatCmsDbtTrnsRqstRsltVo> {

    private final CmsSndRcvLogManager cmsSndRcvLogManager;
	private final CmsAccountValidator cmsAccountValidator;
	private final BatCmsCorpTotLDao batCmsCorpTotLDao;
	private final FrwTemplate frwTemplate;
    private final CmsCom cmsCom;
	  
	public CmsDbtTrnsSmDayDpstInstrJobBean(CmsSndRcvLogManager cmsSndRcvLogManager,
                                           CmsAccountValidator cmsAccountValidator,
                                           BatCmsCorpTotLDao batCmsCorpTotLDao,
                                           FrwTemplate frwTemplate,
                                           CmsCom cmsCom) {
        this.cmsSndRcvLogManager = cmsSndRcvLogManager;
        this.cmsAccountValidator = cmsAccountValidator;
		this.batCmsCorpTotLDao = batCmsCorpTotLDao;
		this.frwTemplate = frwTemplate;
        this.cmsCom = cmsCom;
    }

	@Override
	protected void beforeJob(BatContext batContext) {
		log.debug("### beforeJob #####");
		
		BatCmsContextVo cmsContextVo = new BatCmsContextVo();
        cmsContextVo.initializeContext(batContext, EC23); // EC23 입금지시

        batContext.setData(CMS_CONTEXT, cmsContextVo);
        
        batContext.setData(TOT_RECORD_COUNT, 0); // 총 레코드 건수
        batContext.setData(WITHDRAWAL_COUNT, 0); // EC23R 총 출금건수
        batContext.setData(ERROR_COUNT, 0); 
        batContext.setData(TOT_AMOUNT, BigDecimal.ZERO);  // 총금액

        // file tracking 정보 저장
        batContext.setFileTractId(cmsCom.getFileTractId(cmsContextVo.getSrDt(), EC23));

        // commit interval 설정
        BatContextImpl context = (BatContextImpl)FrwContextHolder.getContext();
        context.setCommitInterval(cmsContextVo.getCommitInterval());
	}

    @Override
    protected long targetTotalCount(BatContext batContext) {
		
		BatCmsContextVo cmsContextVo = (BatCmsContextVo)batContext.getData(CMS_CONTEXT);
        
        return cmsSndRcvLogManager.getCountReceivedFilesData(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
    }

    @Override
    protected Iterator<CmsSndRcvFileL> openReader(BatContext batContext) {
        log.debug(" ##### openReader start ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        /*
         * EC23 파일 데이터 조회(CMS_SND_RVC_FILE_L)
         */
        List<CmsSndRcvFileL> receivedFiles = cmsSndRcvLogManager.getReceivedFilesData(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        
        log.debug("[EC23] [RCV LIST DATA SIZE] : {}", receivedFiles.size());
        return receivedFiles.iterator();
    }

    @Override
    protected OutputStream openWriter(BatContext batContext) {
        return null;
    }

    @Override
    protected BatCmsDbtTrnsRqstRsltVo process(CmsSndRcvFileL cmsSndRcvFileL) {
        log.debug(" ##### process start ######");
        BatCmsDbtTrnsRqstRsltVo resultVo = new BatCmsDbtTrnsRqstRsltVo();
        String respCd;
        
        KftCmsEC23R record = VOUtils.toVo(cmsSndRcvFileL.getTlgCtt(), KftCmsEC23R.class);

        // 출금 데이터 검증
        respCd = validateRecord(BigDecimal.valueOf(record.getAmountOfTotalWithdrawals()), record.getDepositAccountNumber());

        resultVo.setRespCd(respCd);
        resultVo.setTargetFileL(cmsSndRcvFileL);
        resultVo.setTargetRecordVo(record);

        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  =                  EC23 PROCESS                  =] ");
        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  ACCOUNT                : [{}]", record.getDepositAccountNumber());
        log.debug("[I N F O]  SEQ                    : [{}]", record.getDataSerialNumber());
        log.debug("[I N F O]  RESP CODE              : [{}]", respCd);
        log.debug("[I N F O]  TOTAL WITHDRAWAL COUNT : [{}]", record.getCountOfTotalWithdrawals());
        log.debug("[I N F O]  TOTAL WITHDRAWAL AMOUNT: [{}]", record.getAmountOfTotalWithdrawals());
        log.debug("[I N F O]  ===================================================] ");
        
        log.debug(" ##### process end ######");
        return resultVo;
    }

    @Override
    protected void write(List<BatCmsDbtTrnsRqstRsltVo> items) {
        log.debug(" ##### write start ######");
        BatContext batContext = (BatContext) FrwContextHolder.getContext();
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        String prcsDt = cmsContextVo.getPrcsDt();
        
        BigDecimal totAmt = BigDecimal.ZERO; // 총금액
        int totalWhdrwlCnt = 0; // EC23R 총 출금건수
        int recordCnt = 0; // 총 레코드 건수
        int errCnt = 0;
        
        for (BatCmsDbtTrnsRqstRsltVo item : items) {
            String respCd = item.getRespCd();
            CmsSndRcvFileL fileL = item.getTargetFileL();
            KftCmsEC23R record = (KftCmsEC23R) item.getTargetRecordVo();

            // 의뢰금액 합계
            totAmt = totAmt.add(BigDecimal.valueOf(record.getAmountOfTotalWithdrawals())); // 총금액
            totalWhdrwlCnt += record.getCountOfTotalWithdrawals(); // 총 출금건수
            recordCnt++; // record건 수
    
            // 출금이체 HOST 전송
            sendWithdrawal(record, prcsDt, cmsContextVo.getSourceFileNm(), respCd);
    
            // 결과코드, 처리상태코드(11: 전송완료) update
            cmsSndRcvLogManager.updateStatus(fileL, respCd, CmsPrcsStsDvsnCdEnum.LVB_SND.getCode());
            
            if(!CmsBatchRespCdEnum.NORMAL.getCode().equals(respCd)) {
                errCnt++;
                log.debug("[EC23] VALIDATE ERROR DATA [[FILE_NM= {}] [SEQ_NO={}] [RESP_CD = {}]",
                        cmsContextVo.getSourceFileNm(), record.getDataSerialNumber(), respCd);
            }
        }
        
        batContext.setData(TOT_AMOUNT, totAmt);
        batContext.setData(WITHDRAWAL_COUNT, totalWhdrwlCnt);
        batContext.setData(TOT_RECORD_COUNT, recordCnt);
        batContext.setData(ERROR_COUNT, errCnt);
        
        log.debug(" ##### write end ######");
    }
    
    @Override
    protected void afterJob(BatContext batContext) {
        log.debug(" ##### afterJob start ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        BigDecimal totAmt = (BigDecimal) batContext.getData(TOT_AMOUNT);
        int totalWhdrwlCnt = (int) batContext.getData(WITHDRAWAL_COUNT);
        int recordCnt = (int) batContext.getData(TOT_RECORD_COUNT);
        int errCnt = (int) batContext.getData(ERROR_COUNT);

        // JPMC 이용 집계 update
        updateCmsCorpTotL(cmsContextVo.getSourceFileNm(), cmsContextVo.getTrDt(), CmsConst.COR_JPMC, totAmt, totalWhdrwlCnt);

        // header, trailer 처리상태코드 'LVB_SEND'로 update
        cmsSndRcvLogManager.updateHeaderTrailerLvbSndProcessStatus(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());

        // trailer 금액 및 count 검증
        String trailerRespCd = validateTrailerData(totAmt, recordCnt, totalWhdrwlCnt, cmsContextVo);

        if(!CmsBatchRespCdEnum.NORMAL.getCode().equals(trailerRespCd)) {
            // TODO KFTC 이용집계 사용 방법 수정 가능성 있음. check
//			_updateCmsCorpTotL(sourceFileNm, trDt, CmsConst.COR_KFTC, totAmt, recordCnt);
//			log.debug("[EC23] COR_KFTC UPDATE [FILE_NM= {}] [SR_DT={}] [TR_DT = {}] [NORMAL_CNT = {}] [ERR_CNT = {}]", 
//					sourceFileNm, srDt, trDt, recordCnt, errCnt);
        }

        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  =                  EC23 SUMMARY                  =] ");
        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  FILE NAME              : [{}]", cmsContextVo.getSourceFileNm());
        log.debug("[I N F O]  TOTAL AMOUNT           : [{}]", totAmt);
        log.debug("[I N F O]  TOTAL COUNT            : [{}]", recordCnt);
        log.debug("[I N F O]  TOTAL WITHDRAWAL COUNT : [{}]", totalWhdrwlCnt);
        log.debug("[I N F O]  ERROR COUNT            : [{}]", errCnt);
        log.debug("[I N F O]  ===================================================] ");
    }

    private String validateRecord(BigDecimal amount, String acctNo) {
        // 금액 검증
        String respCd = cmsCom.validateAmt(amount);
        if (!CmsBatchRespCdEnum.isNormal(respCd)) {
            return respCd;
        }

        // 계좌 정보 검증
        AccountOut accountInfo = cmsAccountValidator.validateAccountWithdrawalAccountError(acctNo);
        return accountInfo.getRespCd();
    }

    private void sendWithdrawal(KftCmsEC23R kftCmsEC23R, String prcsDt, String sourceFileNm, String respCd) {

        /**************************************************************************
         EC23 파일의 수수료가 기존 00000000000 로 처리되게 되어있어서
         고객의 수수료를 JP가 부담하고 있었음
         하여 의뢰금액-수수료 로 계산하여 수수료를 제외한 금액을 LVB로 전송하기로함.
         **************************************************************************/
        // 총 출금액 - 출금은행 수수료
        long realWithdrawalAmount = kftCmsEC23R.getAmountOfTotalWithdrawals() - kftCmsEC23R.getWithdrawalBankFee();
        
//		BigDecimal realWithdrawalAmount = BigDecimal.ZERO;
//		realWithdrawalAmount = BigDecimal.valueOf(kftCmsEC23R.getAmountOfTotalWithdrawals()).subtract(BigDecimal.valueOf(kftCmsEC23R.getWithdrawalBankFee()));

//        BigDecimal amountOfTotalWithdrawals = new BigDecimal(kftCmsEC23R.getAmountOfTotalWithdrawals());
//        BigDecimal withdrawalBankFee = new BigDecimal(kftCmsEC23R.getWithdrawalBankFee());
//        BigDecimal realWithdrawalAmount = amountOfTotalWithdrawals.subtract(withdrawalBankFee);

        // 메세지번호 채번
        String msgNo = cmsCom.getCmsNumbering();

        /*
         * HOST 전문 조립
         */
        LvbCmsEC23 lvbCmsEC23 = new LvbCmsEC23();
        lvbCmsEC23.setMsgType               ( "KCGLVB"                                  ); // 전문유형
        lvbCmsEC23.setSystemSendReceiveTime ( LocalDateTime.now()                       ); // 시스템송수신시간
        lvbCmsEC23.setMsgNo                 ( msgNo                                     ); // 메시지번호(Key)
        lvbCmsEC23.setMessageType           ( EC23                                      ); // 전문구분코드
        lvbCmsEC23.setInstitutionCode       ( kftCmsEC23R.getInstitutionCode()          ); // 이용기관코드
        lvbCmsEC23.setFileName              ( sourceFileNm                              ); // 파일명
        lvbCmsEC23.setFileSerialNumber      ( kftCmsEC23R.getDataSerialNumber()         ); // 파일일련번호
        lvbCmsEC23.setResponseCode          ( respCd                                    ); // 응답코드 (default: 0000)
        lvbCmsEC23.setProcessDate           ( StringUtils.substring(kftCmsEC23R.getTransferDueDate(), 2, 8)); // LVB 처리일자 -> 이체기일로 전달하도록 적용: 2025-04-18
//        lvbCmsEC23.setProcessDate           ( prcsDt                                    ); // 처리일자 yyMMdd
        lvbCmsEC23.setAccountNumber         ( kftCmsEC23R.getDepositAccountNumber()     ); // 계좌번호
        lvbCmsEC23.setRequestedAmount       ( realWithdrawalAmount                      ); // 의뢰금액
        lvbCmsEC23.setProcessedAmount       ( 0L                                        ); // 처리금액
        lvbCmsEC23.setFeeAmount             ( 0L                                        ); // 수수료
        lvbCmsEC23.setRequestedCount        ( kftCmsEC23R.getCountOfTotalRequests()     ); // 의뢰건수
        lvbCmsEC23.setProcessedCount        ( 0                                         ); // 처리건수
        lvbCmsEC23.setFundType              ( StringUtils.EMPTY                         ); // 자금종류
        lvbCmsEC23.setPassbookEntryDetails  ( StringUtils.EMPTY                         ); // 통장기재내용
        lvbCmsEC23.setWithdrawalType        ( StringUtils.EMPTY                         ); // 출금형태
        lvbCmsEC23.setFiller1               ( StringUtils.SPACE                         ); // FILLER

        frwTemplate.send(FrwDestination.LVB_CMS, lvbCmsEC23);

        /**	TODO 전송 후 성공 알림 호출
         f_sendTivoli("41", "[I N F O] CMS EC23 LVB Sent! [Metlife Insurance] AccNo [%s] Total Amt [KRW %s] Fee [KRW %s] Final Credit Amt [KRW %s]"
         , msg_account, msg_tamount, msg_fee, msg_ramount);
         */
    }

    // 이용집계원장 update
    private void updateCmsCorpTotL(String sourceFileNm, String trDt, String corpCd, BigDecimal totAmt, int recordCnt) {

        CmsCorpTotL corpTotL = new CmsCorpTotL();
        corpTotL.setFileNm(sourceFileNm);
        corpTotL.setCorpCd(corpCd);
        corpTotL.setRegDt(trDt);

        corpTotL.setTotAmt(totAmt);
        corpTotL.setTotCnt(Long.valueOf(recordCnt));

        batCmsCorpTotLDao.update(corpTotL);
    }

    private String validateTrailerData(BigDecimal totAmt, int recordCnt, int totalWhdrwlCnt, BatCmsContextVo cmsContextVo) {
        /*
         * 파일 수신 트레일러 조회
         */
        CmsSndRcvFileL rcvTrailer = cmsSndRcvLogManager.getReceivedFilesTrailer(
                cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());

        if (rcvTrailer == null) {
            return CmsBatchRespCdEnum.ETC_ERROR.getCode(); // 9998 기타오류
        }

        KftCmsEC23T kftCmsEC23T = VOUtils.toVo(rcvTrailer.getTlgCtt(), KftCmsEC23T.class);

        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  =                  EC23 TRAILER                  =] ");
        log.debug("[I N F O]  ===================================================] ");
        log.debug("[I N F O]  TOTAL RECORD COUNT         : [{}]", kftCmsEC23T.getTotalDataRecordCount());
        log.debug("[I N F O]  PROCESSED RECORD COUNT     : [{}]", recordCnt);
        log.debug("[I N F O]  TOTAL WITHDRAWAL COUNT     : [{}]", kftCmsEC23T.getTotalCountOfWithdrawals());
        log.debug("[I N F O]  PROCESSED WITHDRAWAL COUNT : [{}]", totalWhdrwlCnt);
        log.debug("[I N F O]  REQUESTED WITHDRAWAL AMOUNT: [{}]", kftCmsEC23T.getTotalAmountOfWithdrawals());
        log.debug("[I N F O]  PROCESSED WITHDRAWAL AMOUNT: [{}]", totAmt);
        log.debug("[I N F O]  ===================================================] ");

        if (kftCmsEC23T.getTotalDataRecordCount() != recordCnt ) {
            log.info("[F A I L] EC23 FILE 신규건수가 일치하지 않음 [TOTAL_DATA_RECORD_CNT={}] [PROC_RECORD_COUNT = {}]", kftCmsEC23T.getTotalDataRecordCount(), recordCnt);
            return CmsBatchRespCdEnum.ETC_ERROR.getCode(); // 9998 기타오류
        }

        if (kftCmsEC23T.getTotalCountOfWithdrawals() != totalWhdrwlCnt) {
            log.info("[F A I L] EC23 총 출금의뢰 건수가 일치하지 않음 [TOTAL_WITHDRAWAL_RECORD_CNT={}] [PROC_WITHDRAWAL_COUNT = {}]", kftCmsEC23T.getTotalCountOfWithdrawals(), totalWhdrwlCnt);
            return CmsBatchRespCdEnum.ETC_ERROR.getCode(); // 9998 기타오류
        }

        if (BigDecimal.valueOf(kftCmsEC23T.getTotalAmountOfWithdrawals()).compareTo(totAmt) != 0) {
            log.info("[F A I L] EC23 총 금액이 일치하지 않음 [REQUEST_TOT_AMT = {}] [PROC_WITHDRAWAL_COUNT = {}]", kftCmsEC23T.getTotalAmountOfWithdrawals(), totAmt);
            return CmsBatchRespCdEnum.ETC_ERROR.getCode(); // 9998 기타오류
        }
        return CmsBatchRespCdEnum.NORMAL.getCode();
    }

}