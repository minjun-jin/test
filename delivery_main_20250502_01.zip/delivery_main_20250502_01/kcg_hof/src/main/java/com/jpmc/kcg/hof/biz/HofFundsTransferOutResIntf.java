package com.jpmc.kcg.hof.biz;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.ConversionService;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.biz.ReleaseValidation;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dto.ComAcctAlarmIn;
import com.jpmc.kcg.com.dto.ComTrHoldL;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.enums.HoldRsnCdEnum;
import com.jpmc.kcg.com.enums.TrStsCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.dao.FrwMapper;
import com.jpmc.kcg.frw.dto.FrwMsgL;
import com.jpmc.kcg.hof.biz.vo.KftHof0210400000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0200400000;
import com.jpmc.kcg.hof.biz.vo.LvbHof0210400000;
import com.jpmc.kcg.hof.dao.HofLrgAmtSplitMMapper;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitM;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrL;
import com.jpmc.kcg.hof.dto.HofLrgAmtSplitTrLSumOut;
import com.jpmc.kcg.hof.dto.HofTrL;
import com.jpmc.kcg.hof.dto.SelectHofTransactionIn;
import com.jpmc.kcg.hof.enums.FundTypeEnum;
import com.jpmc.kcg.hof.enums.HofConst;
import com.jpmc.kcg.hof.enums.HofRespCdEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 2024.07.19 한성흔 
 * 타행이체 당발응답 (0210/400000)
 */
@Slf4j
@Component
public class HofFundsTransferOutResIntf extends FrwServiceBean<KftHof0210400000> {

	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private FrwMapper frwMapper;
	@Autowired
	private HofCom hofCom;
	@Autowired
	private BizCom bizCom;
	@Autowired
	private ReleaseValidation releaseValidation;
	@Autowired
	private ConversionService conversionService;
	@Autowired
	private ComPshMsgBean comPshMsgBean;
	@Autowired
	private HofLrgAmtSplitMMapper hofLrgAmtSplitMMapper;

	/**
	 * 전문 검증 및 제어
	 */
	@Override
	public boolean control(KftHof0210400000 in) {

		if (!in.getMessageType().equals(HofConst.TLG_KND_DVSN_NO_9200)) {
			// 전문 format validation check
			if (in.validate() > 0) {
				String fieldNo = String.valueOf(in.validate());
				String errCd = StringUtils.leftPad(fieldNo, 3, ComConst.CHAR_0); // 000 ~ 필드번호가 응답코드로 리턴.

				// ** 거래금액 017, 매체구분 021, 자금성격 022
				throw new InternalResponseException(errCd);
			}

			// 개설은행처리중 응답인 경우 바로 종료.
			if (HofRespCdEnum.RESP_CD_602.getCode().equals(in.getResponseCode())
					|| HofRespCdEnum.RESP_CD_430.getCode().equals(in.getResponseCode())) {
				return false;
			}

		}

		return super.control(in);

	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftHof0210400000 in) {
		if (log.isDebugEnabled()) {
			log.debug("process Input Value :::: {}", in);
		}

		/**
		 * 취급전문번호로 요청한 거래가 있는지 확인
		 */
		SelectHofTransactionIn selectIn = new SelectHofTransactionIn();
		selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01); // 당발
		selectIn.setTlgKndDvsnCd(in.getMessageType());
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setTrUnqNo(in.getTransactionIdNumber());
		//		selectIn.setHofTlgTrceNo(in.getMessageTrackingNumber());
		HofTrL reqTrInfo = hofCom.selectHofTransaction(selectIn);

		//	요청거래없음
		if (reqTrInfo == null) {
			throw new InternalResponseException(HofRespCdEnum.RESP_CD_011.getCode(), "원거래 없음");
		}

		log.info("############# log for funds transfer request: {}", reqTrInfo);
		String reqStsCd = reqTrInfo.getTrStsCd();

		log.debug("요청거래 상태코드 reqStsCd {}", reqStsCd);

		// 거래내역, 거액거래테이블 UPDATE
		_updateTransaction(in, reqTrInfo);

		FrwMsgL frwMsgL = frwMapper.selectFrwMsgL(reqTrInfo.getTrcId());
		String requestTlgCtnt = frwMsgL.getTlgCtt();

		LvbHof0200400000 lvbReq = VOUtils.toVo(requestTlgCtnt, LvbHof0200400000.class);
		LvbHof0210400000 lvbRes = conversionService.convert(lvbReq, LvbHof0210400000.class);
		
		/**
		 * 단일거래인 경우.
		 */
		if (!ComConst.Y.equals(reqTrInfo.getLrgAmtSplitTrYn())) {
			// 응답전문송신
			lvbRes.setMsgType(HofConst.KCGLVB);
			lvbRes.setResponseCode(in.getResponseCode());
			lvbRes.setTransactionIdNumber(in.getTransactionIdNumber());
			lvbRes.setBeneficiaryName(in.getBeneficiaryName());
			if(FundTypeEnum.PAYROLL.getCode().equals(in.getFundType()) && StringUtils.isEmpty(lvbReq.getDetailInformation())) {
				lvbRes.setDetailInformation(in.getWithdrawer());    //적요에 출금인명 set
			}
			// 응답코드 결과 HOLD대상이 아닌 경우만 전문전송 처리
			if (!_isHoldTarget(in, lvbRes)) {
				frwTemplate.send(FrwDestination.LVB_HOF, lvbRes);
			}
			
			_sendDrctAcctAlarm(in);
			/**
			 * 거액거래인 경우 응답코드 HOLD 체크 하지 않음. 
			 * 분할된 전체 거래에 대한 후속프로세스를 마지막 거래가 들어온 시점에 판단하기 때문에
			 * 분할된 거래를 개별로 HOLD시킬 수 없음.
			 */
		} 
	}
	
	/**
	 * 거래 알람 발송
	 * @param in
	 */
	private void _sendDrctAcctAlarm(KftHof0210400000 in) {
		try {
			//2025-02-03 추가. 계좌번호에 대한 즉시 알람인 경우 처리.
			ComAcctAlarmIn comAcctAlarmIn = new ComAcctAlarmIn();
			comAcctAlarmIn.setTranDt		(	in.getTraxOccurredDate().format(DateFormat.YYYYMMDD.getFormatter()));
			comAcctAlarmIn.setTrUnqNo		(	in.getTransactionIdNumber()		);
			comAcctAlarmIn.setAcctNo		(	in.getWithdrawalAccountNumber()	);
			String alarmTrDvsnCd = ComConst.CHAR_01;
			if(!ComConst.NORMAL_RESPONSE_CODE.equals(in.getResponseCode())) {
				alarmTrDvsnCd = ComConst.CHAR_02;
				comAcctAlarmIn.setDfltSendFlag(ComConst.Y);
			}
			comAcctAlarmIn.setAlarmTrDvsnCd	(	alarmTrDvsnCd					);
			hofCom.sendDrctAcctAlarm(comAcctAlarmIn);
		} catch (Exception e) {
			log.error("Message Request Fail", e);
		}
	}

	private void _updateTransaction(KftHof0210400000 in, HofTrL reqTrInfo) {
		/*
		 * 2025.01.03 추가 응답코드 HOST응답코드로 맵핑
		 */
		String respCd = bizCom.getRespCdMap(ComConst.HST, BizDvsnCdEnum.HOF.getValue(),
				in.getResponseCode());
		in.setResponseCode(respCd);

		/**
		 * HOF_TR_L UPDATE
		 */
		HofTrL updateIn = new HofTrL();
		updateIn.setTrDt(reqTrInfo.getTrDt());
		updateIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
		updateIn.setTrUnqNo(reqTrInfo.getTrUnqNo());
		if (StringUtils.isNotEmpty(in.getBeneficiaryBranchCode())) {
			updateIn.setOpnBnkBrnchCd(in.getBeneficiaryBranchCode().substring(3));
		}
		updateIn.setTlgKndDvsnCd(HofConst.TLG_KND_DVSN_NO_0210);
		updateIn.setRespCd(in.getResponseCode());
		updateIn.setRcpntNm(in.getBeneficiaryName());
//		updateIn.setHofTlgTrceNo(in.getMessageTrackingNumber());
		hofCom.updateHofTransaction(updateIn);

		/**
		 * HOF_LRG_AMT_SPLIT_L
		 */
		HofLrgAmtSplitTrL lrgTrL = new HofLrgAmtSplitTrL();
		lrgTrL.setTrDt(reqTrInfo.getTrDt());
		lrgTrL.setTrUnqNo(reqTrInfo.getTrUnqNo());
		if (HofRespCdEnum.RESP_CD_000.getCode().equals(in.getResponseCode())) {
			lrgTrL.setTrStsCd(TrStsCdEnum.COMPLETE.getTrStsCd());
		} else {
			lrgTrL.setTrStsCd(TrStsCdEnum.ERROR.getTrStsCd());
		}
		lrgTrL.setHostNo(reqTrInfo.getHostNo());
		hofCom.updateLrgAmtSplitTransaction(lrgTrL);

	}

	private boolean _isHoldTarget(KftHof0210400000 in, LvbHof0210400000 lvbVo) {

		boolean isHoldTarget = false;

		// hold대상 응답코드인지 확인
		boolean isHoldRespCd = releaseValidation.getReleaseResponseCode(ComConst.KFT,
				BizDvsnCdEnum.HOF.getValue(), in.getResponseCode());

		//해당값이 없거나, HOLD_RSN_CD != 05 이면, 응답코드로 인해 HOLD테이블에 입력되어야하는 거래이다.
		String holdRsnCd = frwContext.getTlgHdr().get(ComConst.HOLD_RSN_CD);
		if (isHoldRespCd) {
			if (StringUtils.isEmpty(holdRsnCd)
					|| !holdRsnCd.equals(HoldRsnCdEnum.RESPONSE_CODE.getCode())) {

				isHoldTarget = true;
				/**
				 * 홀드 처리
				 */
				ComTrHoldL holdIn = new ComTrHoldL();
				holdIn.setBizDvsnCd(BizDvsnCdEnum.HOF.getValue());
				holdIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
				holdIn.setTlgKndDvsnCd(in.getMessageType());
				holdIn.setTlgTrDvsnCd(in.getMessageCode());
				holdIn.setRcvBnkCd(in.getBeneficiaryBankCode());
				holdIn.setRcvAcctNo(in.getBeneficiaryAccountNumber());
				holdIn.setSndrRealNm(in.getRealSenderName());

				holdIn.setWhdrwlBnkCd(in.getHandlingInstitutionRepCode());
				holdIn.setWhdrwlNm(in.getRealSenderName());
				holdIn.setWhdrwlAcctNo(in.getWithdrawalAccountNumber());
				holdIn.setRqerInfo(in.getRequestorInformation());

				holdIn.setTrAmt(new BigDecimal(in.getTransactionAmount()));
				holdIn.setTlgCtt(VOUtils.toString(lvbVo));
				holdIn.setHoldRsnCd(HoldRsnCdEnum.RESPONSE_CODE.getCode());
				holdIn.setTrUnqNo(in.getMessageTrackingNumber());
				holdIn.setHostNo(lvbVo.getMsgNo());
				holdIn.setTrcId(frwContext.getOrgnTractId());
				holdIn.setRespCd(in.getResponseCode());
				bizCom.createHoldTransaction(frwContext, holdIn);

			}
		}

		return isHoldTarget;
	}
	
	/**
	 * 예외
	 */
	@Override
	public void handleError(KftHof0210400000 in, Throwable t) {

		if (t instanceof InternalResponseException e) {
			String respCd = e.getRespCd();
			int flag = Integer.parseInt(in.getSendReceiveFlag());
			in.setSendReceiveFlag(String.valueOf(flag + 1));

			//요청에 대해 전문에러받은 경우 바로 host로 내려준다.
			if (HofConst.TLG_KND_DVSN_NO_9200.equals(in.getMessageType())) {
				LvbHof0200400000 lvbReq = VOUtils.toVo(frwContext.getOrgnTlgCtt(),
						LvbHof0200400000.class);
				List<HofTrL> reqTrList = hofCom.selectHofTrListByHostNo(lvbReq.getMsgNo(),
						lvbReq.getTransactionDate().format(DateFormat.YYYYMMDD.getFormatter()));

				for (HofTrL reqTr : reqTrList) {
					if (in.getTransactionIdNumber().equals(reqTr.getTrUnqNo())) {
						HofTrL updateIn = new HofTrL();
						//조회key값
						updateIn.setTrDt(reqTr.getTrDt());
						updateIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
						updateIn.setTrUnqNo(reqTr.getTrUnqNo()); 
						updateIn.setHofTlgTrceNo(reqTr.getHofTlgTrceNo());

						//update값
						updateIn.setTlgKndDvsnCd(HofConst.TLG_KND_DVSN_NO_9200);
						updateIn.setRespCd(respCd);

						//update호출
						hofCom.updateHofTransaction(updateIn);

						//host로 전문전송
						LvbHof0210400000 lvbRes = conversionService.convert(lvbReq,
								LvbHof0210400000.class);
						lvbRes.setMsgType(HofConst.KCGLVB);
						lvbRes.setResponseCode(respCd);
						frwTemplate.send(FrwDestination.LVB_HOF, lvbRes);
					}
				}
				// 받은 응답이 field값 에러인 경우 전문종별 : 9210으로 전송한다.
			} else if (respCd.startsWith(ComConst.CHAR_0)) {
				in.setMessageType(HofConst.TLG_KND_DVSN_NO_9210);
				in.setResponseCode(respCd);
				frwTemplate.send(FrwDestination.KFT_HOF, in);
			}

			try {
				Map<String, Object> errorValList = new Hashtable<>();
				// 에러 메시지 문자열 생성
				String errorMessage = String.format(
						"81 [I N F O] HOF PAYMENT ERROR RESPONSE[DATE=%s][KFTC_NO=%s][BANK_CD=%s][ACCT_NO=%s][TOT_AEK=%d]",
						LocalDate.now().format(DateFormat.YYYYMMDD.getFormatter()),
						in.getTransactionIdNumber(), in.getBeneficiaryBankCode(),
						in.getBeneficiaryAccountNumber(), in.getTransactionAmount());
				errorValList.put("errTlgId", HofConst.OUT_PAYMENT_ERROR_TITLE);
				errorValList.put("errCtt", errorMessage);
				comPshMsgBean.sendAlarm(8, errorValList.get("errTlgId").toString(), errorValList,
						null, true);
				
				//2025-02-03 추가. 계좌번호에 대한 즉시 알람인 경우 처리.
				ComAcctAlarmIn comAcctAlarmIn = new ComAcctAlarmIn();
				comAcctAlarmIn.setTranDt		(	in.getTraxOccurredDate().format(DateFormat.YYYYMMDD.getFormatter()));
				comAcctAlarmIn.setTrUnqNo		(	in.getTransactionIdNumber()		);
				comAcctAlarmIn.setAcctNo		(	in.getWithdrawalAccountNumber()	);
				comAcctAlarmIn.setAlarmTrDvsnCd	(	ComConst.CHAR_02				);	// 불능(오류)
				hofCom.sendDrctAcctAlarm(comAcctAlarmIn);
				
			} catch (Exception e2) {
				log.error("Message Request Fail", e2);
			}
		} else {
			log.error("Fail", t);
		}
		return;
	}
}
