package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자어음 발행 통지 재요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 전자어음시스템을 구분하기 위해'EBS'사용
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 0200
 * messageTrackingNumber 전문추적번호 230000
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * eNoteNumber 전자어음번호 
 * eNoteType 어음종류 
 * eNoteIssueDate 전자어음발행일자 
 * eNoteIssuePlace 전자어음발행지 
 * eNoteAmount 전자어음금액 
 * eNoteMaturedDate 전자어음만기일자 
 * paymentBankAndBranchCode 지급은행및지점코드 
 * issuerIndvCorpSort 발행인-개인법인구분 1,2,3
 * issuerBusinessResidentRegistrationNumber 발행인-사업자(주민)등록번호 
 * issuerCorpName 발행인-법인명 
 * issuerNameRepresentativeName 발행인-성명(대표자명) 
 * issuerAddress 발행인-주소 
 * issuerCurrentAccountNumber 발행인-당좌계좌번호 
 * beneCorpIndvSortCode 수취인법인개인구분코드 1,2,3
 * beneBusinessResidentRegistrationNumber 수취인사업자(주민)등록번호 
 * beneCorpName 수취인법인명 
 * beneNameRepresentativeName 수취인성명(대표자명) 
 * beneAddress 수취인주소 
 * beneBankCode 수취인은행코드 
 * beneDepositAccountNumber 수취인입금계좌번호 
 * prohibitedInstructionYn 지시금지여부 Y,N,P
 * electronicSignatureOriginalLength 전자서명된원본길이 
 * electronicSignatureOriginal 전자서명된원본 
 * 
 * KftEnt0201230000 kftEnt0201230000 = new KftEnt0201230000(); // 전자어음 발행 통지 재요청
 * kftEnt0201230000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0201230000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0201230000.setBnkCd("057"); // 은행코드
 * kftEnt0201230000.setMessageType("0200"); // 전문종별코드
 * kftEnt0201230000.setTransactionCode("230000"); // 거래구분코드
 * kftEnt0201230000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0201230000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0201230000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0201230000.setStatus("000"); // STATUS
 * kftEnt0201230000.setResponseCode1(""); // 응답코드1
 * kftEnt0201230000.setResponseCode2(""); // 응답코드2
 * kftEnt0201230000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0201230000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0201230000.setENoteNumber(""); // 전자어음번호
 * kftEnt0201230000.setENoteType(""); // 어음종류
 * kftEnt0201230000.setENoteIssueDate(""); // 전자어음발행일자
 * kftEnt0201230000.setENoteIssuePlace(""); // 전자어음발행지
 * kftEnt0201230000.setENoteAmount(0L); // 전자어음금액
 * kftEnt0201230000.setENoteMaturedDate(""); // 전자어음만기일자
 * kftEnt0201230000.setPaymentBankAndBranchCode(""); // 지급은행및지점코드
 * kftEnt0201230000.setIssuerIndvCorpSort(""); // 발행인-개인법인구분
 * kftEnt0201230000.setIssuerBusinessResidentRegistrationNumber(""); // 발행인-사업자(주민)등록번호
 * kftEnt0201230000.setIssuerCorpName(""); // 발행인-법인명
 * kftEnt0201230000.setIssuerNameRepresentativeName(""); // 발행인-성명(대표자명)
 * kftEnt0201230000.setIssuerAddress(""); // 발행인-주소
 * kftEnt0201230000.setIssuerCurrentAccountNumber(""); // 발행인-당좌계좌번호
 * kftEnt0201230000.setBeneCorpIndvSortCode(""); // 수취인법인개인구분코드
 * kftEnt0201230000.setBeneBusinessResidentRegistrationNumber(""); // 수취인사업자(주민)등록번호
 * kftEnt0201230000.setBeneCorpName(""); // 수취인법인명
 * kftEnt0201230000.setBeneNameRepresentativeName(""); // 수취인성명(대표자명)
 * kftEnt0201230000.setBeneAddress(""); // 수취인주소
 * kftEnt0201230000.setBeneBankCode(""); // 수취인은행코드
 * kftEnt0201230000.setBeneDepositAccountNumber(""); // 수취인입금계좌번호
 * kftEnt0201230000.setProhibitedInstructionYn(""); // 지시금지여부
 * kftEnt0201230000.setElectronicSignatureOriginalLength(0); // 전자서명된원본길이
 * kftEnt0201230000.setElectronicSignatureOriginal(""); // 전자서명된원본
 * }</pre>
 */
@Data
public class KftEnt0201230000 implements KftEntComHdr, Vo {

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "230000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String eNoteNumber; // 전자어음번호
	private String eNoteType; // 어음종류
	private String eNoteIssueDate; // 전자어음발행일자
	private String eNoteIssuePlace; // 전자어음발행지
	private long eNoteAmount; // 전자어음금액
	private String eNoteMaturedDate; // 전자어음만기일자
	private String paymentBankAndBranchCode; // 지급은행및지점코드
	private String issuerIndvCorpSort; // 발행인-개인법인구분
	private String issuerBusinessResidentRegistrationNumber; // 발행인-사업자(주민)등록번호
	private String issuerCorpName; // 발행인-법인명
	private String issuerNameRepresentativeName; // 발행인-성명(대표자명)
	private String issuerAddress; // 발행인-주소
	private String issuerCurrentAccountNumber; // 발행인-당좌계좌번호
	private String beneCorpIndvSortCode; // 수취인법인개인구분코드
	private String beneBusinessResidentRegistrationNumber; // 수취인사업자(주민)등록번호
	private String beneCorpName; // 수취인법인명
	private String beneNameRepresentativeName; // 수취인성명(대표자명)
	private String beneAddress; // 수취인주소
	private String beneBankCode; // 수취인은행코드
	private String beneDepositAccountNumber; // 수취인입금계좌번호
	private String prohibitedInstructionYn; // 지시금지여부
	private int electronicSignatureOriginalLength; // 전자서명된원본길이
	private String electronicSignatureOriginal; // 전자서명된원본
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssueDate$; // 전자어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteIssuePlace$; // 전자어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteAmount$; // 전자어음금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteMaturedDate$; // 전자어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankAndBranchCode$; // 지급은행및지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerIndvCorpSort$; // 발행인-개인법인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBusinessResidentRegistrationNumber$; // 발행인-사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpIndvSortCode$; // 수취인법인개인구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneBusinessResidentRegistrationNumber$; // 수취인사업자(주민)등록번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneCorpName$; // 수취인법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneNameRepresentativeName$; // 수취인성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneAddress$; // 수취인주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneBankCode$; // 수취인은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneDepositAccountNumber$; // 수취인입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prohibitedInstructionYn$; // 지시금지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginalLength$; // 전자서명된원본길이
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String electronicSignatureOriginal$; // 전자서명된원본

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 13;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerBusinessResidentRegistrationNumber$)) { // 발행인-사업자(주민)등록번호
			return 21;
		}
		if (VOUtils.isNotAlphanumericSpace(issuerCurrentAccountNumber$)) { // 발행인-당좌계좌번호
			return 25;
		}
		if (VOUtils.isNotAlphanumericSpace(beneBusinessResidentRegistrationNumber$)) { // 수취인사업자(주민)등록번호
			return 27;
		}
		if (VOUtils.isNotAlphanumericSpace(beneDepositAccountNumber$)) { // 수취인입금계좌번호
			return 32;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		eNoteType$ = VOUtils.write(out, eNoteType, 1); // 어음종류
		eNoteIssueDate$ = VOUtils.write(out, eNoteIssueDate, 8); // 전자어음발행일자
		eNoteIssuePlace$ = VOUtils.write(out, eNoteIssuePlace, 60, "EUC-KR"); // 전자어음발행지
		eNoteAmount$ = VOUtils.write(out, eNoteAmount, 15); // 전자어음금액
		eNoteMaturedDate$ = VOUtils.write(out, eNoteMaturedDate, 8); // 전자어음만기일자
		paymentBankAndBranchCode$ = VOUtils.write(out, paymentBankAndBranchCode, 7); // 지급은행및지점코드
		issuerIndvCorpSort$ = VOUtils.write(out, issuerIndvCorpSort, 1); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber$ = VOUtils.write(out, issuerBusinessResidentRegistrationNumber, 13); // 발행인-사업자(주민)등록번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인-주소
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인-당좌계좌번호
		beneCorpIndvSortCode$ = VOUtils.write(out, beneCorpIndvSortCode, 1); // 수취인법인개인구분코드
		beneBusinessResidentRegistrationNumber$ = VOUtils.write(out, beneBusinessResidentRegistrationNumber, 13); // 수취인사업자(주민)등록번호
		beneCorpName$ = VOUtils.write(out, beneCorpName, 40, "EUC-KR"); // 수취인법인명
		beneNameRepresentativeName$ = VOUtils.write(out, beneNameRepresentativeName, 20, "EUC-KR"); // 수취인성명(대표자명)
		beneAddress$ = VOUtils.write(out, beneAddress, 60, "EUC-KR"); // 수취인주소
		beneBankCode$ = VOUtils.write(out, beneBankCode, 3); // 수취인은행코드
		beneDepositAccountNumber$ = VOUtils.write(out, beneDepositAccountNumber, 16); // 수취인입금계좌번호
		prohibitedInstructionYn$ = VOUtils.write(out, prohibitedInstructionYn, 1); // 지시금지여부
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginalLength$ = VOUtils.write(out, electronicSignatureOriginalLength, 5); // 전자서명된원본길이
		}
		if (0 < electronicSignatureOriginalLength) {
			electronicSignatureOriginal$ = VOUtils.write(out, electronicSignatureOriginal, electronicSignatureOriginalLength); // 전자서명된원본
		}
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		eNoteType = VOUtils.toString(eNoteType$ = VOUtils.read(in, 1)); // 어음종류
		eNoteIssueDate = VOUtils.toString(eNoteIssueDate$ = VOUtils.read(in, 8)); // 전자어음발행일자
		eNoteIssuePlace = VOUtils.toString(eNoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 전자어음발행지
		eNoteAmount = VOUtils.toLong(eNoteAmount$ = VOUtils.read(in, 15)); // 전자어음금액
		eNoteMaturedDate = VOUtils.toString(eNoteMaturedDate$ = VOUtils.read(in, 8)); // 전자어음만기일자
		paymentBankAndBranchCode = VOUtils.toString(paymentBankAndBranchCode$ = VOUtils.read(in, 7)); // 지급은행및지점코드
		issuerIndvCorpSort = VOUtils.toString(issuerIndvCorpSort$ = VOUtils.read(in, 1)); // 발행인-개인법인구분
		issuerBusinessResidentRegistrationNumber = VOUtils.toString(issuerBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 발행인-사업자(주민)등록번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인-주소
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인-당좌계좌번호
		beneCorpIndvSortCode = VOUtils.toString(beneCorpIndvSortCode$ = VOUtils.read(in, 1)); // 수취인법인개인구분코드
		beneBusinessResidentRegistrationNumber = VOUtils.toString(beneBusinessResidentRegistrationNumber$ = VOUtils.read(in, 13)); // 수취인사업자(주민)등록번호
		beneCorpName = VOUtils.toString(beneCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 수취인법인명
		beneNameRepresentativeName = VOUtils.toString(beneNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인성명(대표자명)
		beneAddress = VOUtils.toString(beneAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 수취인주소
		beneBankCode = VOUtils.toString(beneBankCode$ = VOUtils.read(in, 3)); // 수취인은행코드
		beneDepositAccountNumber = VOUtils.toString(beneDepositAccountNumber$ = VOUtils.read(in, 16)); // 수취인입금계좌번호
		prohibitedInstructionYn = VOUtils.toString(prohibitedInstructionYn$ = VOUtils.read(in, 1)); // 지시금지여부
		if (0 < in.available()) {
			electronicSignatureOriginalLength = VOUtils.toInt(electronicSignatureOriginalLength$ = VOUtils.read(in, 5)); // 전자서명된원본길이
		}
		if (0 < in.available()) {
			electronicSignatureOriginal = VOUtils.toString(electronicSignatureOriginal$ = VOUtils.read(in, electronicSignatureOriginalLength)); // 전자서명된원본
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", eNoteType=").append(eNoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", eNoteIssueDate=").append(eNoteIssueDate).append(System.lineSeparator()); // 전자어음발행일자
		sb.append(", eNoteIssuePlace=").append(eNoteIssuePlace).append(System.lineSeparator()); // 전자어음발행지
		sb.append(", eNoteAmount=").append(eNoteAmount).append(System.lineSeparator()); // 전자어음금액
		sb.append(", eNoteMaturedDate=").append(eNoteMaturedDate).append(System.lineSeparator()); // 전자어음만기일자
		sb.append(", paymentBankAndBranchCode=").append(paymentBankAndBranchCode).append(System.lineSeparator()); // 지급은행및지점코드
		sb.append(", issuerIndvCorpSort=").append(issuerIndvCorpSort).append(System.lineSeparator()); // 발행인-개인법인구분
		sb.append(", issuerBusinessResidentRegistrationNumber=").append(issuerBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 발행인-사업자(주민)등록번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인-주소
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인-당좌계좌번호
		sb.append(", beneCorpIndvSortCode=").append(beneCorpIndvSortCode).append(System.lineSeparator()); // 수취인법인개인구분코드
		sb.append(", beneBusinessResidentRegistrationNumber=").append(beneBusinessResidentRegistrationNumber).append(System.lineSeparator()); // 수취인사업자(주민)등록번호
		sb.append(", beneCorpName=").append(beneCorpName).append(System.lineSeparator()); // 수취인법인명
		sb.append(", beneNameRepresentativeName=").append(beneNameRepresentativeName).append(System.lineSeparator()); // 수취인성명(대표자명)
		sb.append(", beneAddress=").append(beneAddress).append(System.lineSeparator()); // 수취인주소
		sb.append(", beneBankCode=").append(beneBankCode).append(System.lineSeparator()); // 수취인은행코드
		sb.append(", beneDepositAccountNumber=").append(beneDepositAccountNumber).append(System.lineSeparator()); // 수취인입금계좌번호
		sb.append(", prohibitedInstructionYn=").append(prohibitedInstructionYn).append(System.lineSeparator()); // 지시금지여부
		sb.append(", electronicSignatureOriginalLength=").append(electronicSignatureOriginalLength).append(System.lineSeparator()); // 전자서명된원본길이
		sb.append(", electronicSignatureOriginal=").append(electronicSignatureOriginal).append(System.lineSeparator()); // 전자서명된원본
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "230000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "eNoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "eNoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "eNoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "eNoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneCorpIndvSortCode", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneBusinessResidentRegistrationNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prohibitedInstructionYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginalLength", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "electronicSignatureOriginal", "fldLen", "0", "defltVal", "")
		);
	}

}
