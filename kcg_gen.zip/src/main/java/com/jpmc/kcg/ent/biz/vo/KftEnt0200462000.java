package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 부도 전자어음 최종 소지인 조회 요청
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+"HDR"
 * systemId 시스템-ID 
 * bnkCd 은행코드 
 * messageType 전문종별코드 
 * transactionCode 거래구분코드 
 * messageTrackingNumber 전문추적번호 
 * sendReceiveFlag 송수신FLAG 
 * transactionIdNumber 거래고유번호 
 * status STATUS 
 * responseCode1 응답코드1 
 * responseCode2 응답코드2 
 * messageSendTime 전문전송일시 
 * kftcStatisticsCode 관리기관통계코드 
 * searchConditionSort 검색조건구분 
 * eNoteNumber 전자어음번호 
 * residentBusinessNumber 주민사업자번호 
 * currentCreditAccountNumber 당좌(입금)계좌번호 
 * defaultInquiryStartDate 부도일기준조회시작일 
 * defaultInquiryEndDate 부도일기준조회종료일 
 * totalQueryResultCount 조회결과총건수 
 * specifiedQueryNumber 조회내역지정번호 
 * currentCount 현재건수 
 * queryResultArray 조회결과Array 
 * queryResultArray.noteDetailsEnoteNumber (조회결과)어음내역-전자어음번호 
 * queryResultArray.noteDetailsEnoteType (조회결과)어음내역-전자어음종류 
 * queryResultArray.noteDetailsEnoteProcessStatus (조회결과)어음내역-전자어음처리상태 
 * queryResultArray.noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
 * queryResultArray.noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
 * queryResultArray.noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
 * queryResultArray.noteDetailsDefaultReasonCode (조회결과)어음내역-부도사유코드 
 * queryResultArray.noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
 * queryResultArray.noteDetailsEnoteDefaultProcessingDate (조회결과)어음내역-전자어음부도처리일자 
 * queryResultArray.noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
 * queryResultArray.issuerCorpIndvSort (조회결과)발행인-개인법인구분 
 * queryResultArray.issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
 * queryResultArray.issuerCorpName (조회결과)발행인-법인명 
 * queryResultArray.issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
 * queryResultArray.issuerAddress (조회결과)발행인-주소 
 * queryResultArray.issuerCurrentAccountNumber (조회결과)발행인-당좌계좌번호 
 * queryResultArray.recipientIndvCorpSort (조회결과)소지인개인법인구분 
 * queryResultArray.recipientResidentBusinessNumber (조회결과)소지인주민사업자번호 
 * queryResultArray.recipientCorpName (조회결과)소지인법인명 
 * queryResultArray.recipientNameRepresentative (조회결과)소지인성명(대표자명) Y,N,P
 * queryResultArray.recipientAddress (조회결과)소지인주소 
 * queryResultArray.recipientBankCode (조회결과)소지인은행코드 
 * queryResultArray.recipientDepositAccountNumber (조회결과)소지인입금계좌번호 
 * queryResultArray.recipientdefaultAmount (조회결과)소지인부도금액 
 * queryResultArray.splitNumber (조회결과)분할번호 
 * queryResultArray.endorsementNumber (조회결과)배서번호 
 * 
 * KftEnt0200462000 kftEnt0200462000 = new KftEnt0200462000(); // 부도 전자어음 최종 소지인 조회 요청
 * kftEnt0200462000.setTcpIpHeader("0000"); // TCP/IP HEADER
 * kftEnt0200462000.setSystemId("EBS"); // 시스템-ID
 * kftEnt0200462000.setBnkCd("057"); // 은행코드
 * kftEnt0200462000.setMessageType("0200"); // 전문종별코드
 * kftEnt0200462000.setTransactionCode("462000"); // 거래구분코드
 * kftEnt0200462000.setMessageTrackingNumber(""); // 전문추적번호
 * kftEnt0200462000.setSendReceiveFlag(""); // 송수신FLAG
 * kftEnt0200462000.setTransactionIdNumber(""); // 거래고유번호
 * kftEnt0200462000.setStatus("000"); // STATUS
 * kftEnt0200462000.setResponseCode1(""); // 응답코드1
 * kftEnt0200462000.setResponseCode2(""); // 응답코드2
 * kftEnt0200462000.setMessageSendTime(LocalDateTime.now()); // 전문전송일시
 * kftEnt0200462000.setKftcStatisticsCode(""); // 관리기관통계코드
 * kftEnt0200462000.setSearchConditionSort(""); // 검색조건구분
 * kftEnt0200462000.setENoteNumber(""); // 전자어음번호
 * kftEnt0200462000.setResidentBusinessNumber(""); // 주민사업자번호
 * kftEnt0200462000.setCurrentCreditAccountNumber(""); // 당좌(입금)계좌번호
 * kftEnt0200462000.setDefaultInquiryStartDate(""); // 부도일기준조회시작일
 * kftEnt0200462000.setDefaultInquiryEndDate(""); // 부도일기준조회종료일
 * kftEnt0200462000.setTotalQueryResultCount(0); // 조회결과총건수
 * kftEnt0200462000.setSpecifiedQueryNumber(0); // 조회내역지정번호
 * kftEnt0200462000.setCurrentCount(0); // 현재건수
 * KftEnt0200462000.QueryResult queryResult = new KftEnt0200462000.QueryResult(); // 조회결과Array
 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-전자어음번호
 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-전자어음종류
 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-전자어음처리상태
 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
 * queryResult.setNoteDetailsDefaultReasonCode(""); // (조회결과)어음내역-부도사유코드
 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
 * queryResult.setNoteDetailsEnoteDefaultProcessingDate(""); // (조회결과)어음내역-전자어음부도처리일자
 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
 * queryResult.setIssuerCurrentAccountNumber(""); // (조회결과)발행인-당좌계좌번호
 * queryResult.setRecipientIndvCorpSort(""); // (조회결과)소지인개인법인구분
 * queryResult.setRecipientResidentBusinessNumber(""); // (조회결과)소지인주민사업자번호
 * queryResult.setRecipientCorpName(""); // (조회결과)소지인법인명
 * queryResult.setRecipientNameRepresentative(""); // (조회결과)소지인성명(대표자명)
 * queryResult.setRecipientAddress(""); // (조회결과)소지인주소
 * queryResult.setRecipientBankCode(""); // (조회결과)소지인은행코드
 * queryResult.setRecipientDepositAccountNumber(""); // (조회결과)소지인입금계좌번호
 * queryResult.setRecipientdefaultAmount(0L); // (조회결과)소지인부도금액
 * queryResult.setSplitNumber(""); // (조회결과)분할번호
 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
 * kftEnt0200462000.getQueryResultArray().add(queryResult); // 조회결과Array
 * }</pre>
 */
@Data
public class KftEnt0200462000 implements KftEntComHdr, Vo {

	/**
	 * 조회결과Array
	 * <pre>{@code
	 * noteDetailsEnoteNumber (조회결과)어음내역-전자어음번호 
	 * noteDetailsEnoteType (조회결과)어음내역-전자어음종류 
	 * noteDetailsEnoteProcessStatus (조회결과)어음내역-전자어음처리상태 
	 * noteDetailsEnoteIssueDate (조회결과)어음내역-전자어음발행일자 
	 * noteDetailsEnoteIssuePlace (조회결과)어음내역-전자어음발행지 
	 * noteDetailsEnoteAmount (조회결과)어음내역-전자어음금액 
	 * noteDetailsDefaultReasonCode (조회결과)어음내역-부도사유코드 
	 * noteDetailsEnoteMaturedDate (조회결과)어음내역-전자어음만기일자 
	 * noteDetailsEnoteDefaultProcessingDate (조회결과)어음내역-전자어음부도처리일자 
	 * noteDetailsPaymentBankAndBranchCode (조회결과)어음내역-지급은행및지점코드 
	 * issuerCorpIndvSort (조회결과)발행인-개인법인구분 
	 * issuerResidentBusinessNumber (조회결과)발행인-주민사업자번호 
	 * issuerCorpName (조회결과)발행인-법인명 
	 * issuerNameRepresentativeName (조회결과)발행인-성명(대표자명) 
	 * issuerAddress (조회결과)발행인-주소 
	 * issuerCurrentAccountNumber (조회결과)발행인-당좌계좌번호 
	 * recipientIndvCorpSort (조회결과)소지인개인법인구분 
	 * recipientResidentBusinessNumber (조회결과)소지인주민사업자번호 
	 * recipientCorpName (조회결과)소지인법인명 
	 * recipientNameRepresentative (조회결과)소지인성명(대표자명) Y,N,P
	 * recipientAddress (조회결과)소지인주소 
	 * recipientBankCode (조회결과)소지인은행코드 
	 * recipientDepositAccountNumber (조회결과)소지인입금계좌번호 
	 * recipientdefaultAmount (조회결과)소지인부도금액 
	 * splitNumber (조회결과)분할번호 
	 * endorsementNumber (조회결과)배서번호 
	 * 
	 * KftEnt0200462000.QueryResult queryResult = new KftEnt0200462000.QueryResult(); // 조회결과Array
	 * queryResult.setNoteDetailsEnoteNumber(""); // (조회결과)어음내역-전자어음번호
	 * queryResult.setNoteDetailsEnoteType(""); // (조회결과)어음내역-전자어음종류
	 * queryResult.setNoteDetailsEnoteProcessStatus(""); // (조회결과)어음내역-전자어음처리상태
	 * queryResult.setNoteDetailsEnoteIssueDate(""); // (조회결과)어음내역-전자어음발행일자
	 * queryResult.setNoteDetailsEnoteIssuePlace(""); // (조회결과)어음내역-전자어음발행지
	 * queryResult.setNoteDetailsEnoteAmount(0L); // (조회결과)어음내역-전자어음금액
	 * queryResult.setNoteDetailsDefaultReasonCode(""); // (조회결과)어음내역-부도사유코드
	 * queryResult.setNoteDetailsEnoteMaturedDate(""); // (조회결과)어음내역-전자어음만기일자
	 * queryResult.setNoteDetailsEnoteDefaultProcessingDate(""); // (조회결과)어음내역-전자어음부도처리일자
	 * queryResult.setNoteDetailsPaymentBankAndBranchCode(""); // (조회결과)어음내역-지급은행및지점코드
	 * queryResult.setIssuerCorpIndvSort(""); // (조회결과)발행인-개인법인구분
	 * queryResult.setIssuerResidentBusinessNumber(""); // (조회결과)발행인-주민사업자번호
	 * queryResult.setIssuerCorpName(""); // (조회결과)발행인-법인명
	 * queryResult.setIssuerNameRepresentativeName(""); // (조회결과)발행인-성명(대표자명)
	 * queryResult.setIssuerAddress(""); // (조회결과)발행인-주소
	 * queryResult.setIssuerCurrentAccountNumber(""); // (조회결과)발행인-당좌계좌번호
	 * queryResult.setRecipientIndvCorpSort(""); // (조회결과)소지인개인법인구분
	 * queryResult.setRecipientResidentBusinessNumber(""); // (조회결과)소지인주민사업자번호
	 * queryResult.setRecipientCorpName(""); // (조회결과)소지인법인명
	 * queryResult.setRecipientNameRepresentative(""); // (조회결과)소지인성명(대표자명)
	 * queryResult.setRecipientAddress(""); // (조회결과)소지인주소
	 * queryResult.setRecipientBankCode(""); // (조회결과)소지인은행코드
	 * queryResult.setRecipientDepositAccountNumber(""); // (조회결과)소지인입금계좌번호
	 * queryResult.setRecipientdefaultAmount(0L); // (조회결과)소지인부도금액
	 * queryResult.setSplitNumber(""); // (조회결과)분할번호
	 * queryResult.setEndorsementNumber(""); // (조회결과)배서번호
	 * }</pre>
	 */
	@Data
	public static class QueryResult implements Vo {

		private String noteDetailsEnoteNumber; // (조회결과)어음내역-전자어음번호
		private String noteDetailsEnoteType; // (조회결과)어음내역-전자어음종류
		private String noteDetailsEnoteProcessStatus; // (조회결과)어음내역-전자어음처리상태
		private String noteDetailsEnoteIssueDate; // (조회결과)어음내역-전자어음발행일자
		private String noteDetailsEnoteIssuePlace; // (조회결과)어음내역-전자어음발행지
		private long noteDetailsEnoteAmount; // (조회결과)어음내역-전자어음금액
		private String noteDetailsDefaultReasonCode; // (조회결과)어음내역-부도사유코드
		private String noteDetailsEnoteMaturedDate; // (조회결과)어음내역-전자어음만기일자
		private String noteDetailsEnoteDefaultProcessingDate; // (조회결과)어음내역-전자어음부도처리일자
		private String noteDetailsPaymentBankAndBranchCode; // (조회결과)어음내역-지급은행및지점코드
		private String issuerCorpIndvSort; // (조회결과)발행인-개인법인구분
		private String issuerResidentBusinessNumber; // (조회결과)발행인-주민사업자번호
		private String issuerCorpName; // (조회결과)발행인-법인명
		private String issuerNameRepresentativeName; // (조회결과)발행인-성명(대표자명)
		private String issuerAddress; // (조회결과)발행인-주소
		private String issuerCurrentAccountNumber; // (조회결과)발행인-당좌계좌번호
		private String recipientIndvCorpSort; // (조회결과)소지인개인법인구분
		private String recipientResidentBusinessNumber; // (조회결과)소지인주민사업자번호
		private String recipientCorpName; // (조회결과)소지인법인명
		private String recipientNameRepresentative; // (조회결과)소지인성명(대표자명)
		private String recipientAddress; // (조회결과)소지인주소
		private String recipientBankCode; // (조회결과)소지인은행코드
		private String recipientDepositAccountNumber; // (조회결과)소지인입금계좌번호
		private long recipientdefaultAmount; // (조회결과)소지인부도금액
		private String splitNumber; // (조회결과)분할번호
		private String endorsementNumber; // (조회결과)배서번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteNumber$; // (조회결과)어음내역-전자어음번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteType$; // (조회결과)어음내역-전자어음종류
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteProcessStatus$; // (조회결과)어음내역-전자어음처리상태
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssueDate$; // (조회결과)어음내역-전자어음발행일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteIssuePlace$; // (조회결과)어음내역-전자어음발행지
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteAmount$; // (조회결과)어음내역-전자어음금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsDefaultReasonCode$; // (조회결과)어음내역-부도사유코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteMaturedDate$; // (조회결과)어음내역-전자어음만기일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsEnoteDefaultProcessingDate$; // (조회결과)어음내역-전자어음부도처리일자
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String noteDetailsPaymentBankAndBranchCode$; // (조회결과)어음내역-지급은행및지점코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpIndvSort$; // (조회결과)발행인-개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerResidentBusinessNumber$; // (조회결과)발행인-주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCorpName$; // (조회결과)발행인-법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerNameRepresentativeName$; // (조회결과)발행인-성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerAddress$; // (조회결과)발행인-주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String issuerCurrentAccountNumber$; // (조회결과)발행인-당좌계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientIndvCorpSort$; // (조회결과)소지인개인법인구분
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientResidentBusinessNumber$; // (조회결과)소지인주민사업자번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientCorpName$; // (조회결과)소지인법인명
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientNameRepresentative$; // (조회결과)소지인성명(대표자명)
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientAddress$; // (조회결과)소지인주소
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientBankCode$; // (조회결과)소지인은행코드
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientDepositAccountNumber$; // (조회결과)소지인입금계좌번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String recipientdefaultAmount$; // (조회결과)소지인부도금액
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String splitNumber$; // (조회결과)분할번호
		@EqualsAndHashCode.Exclude
		@Getter(AccessLevel.NONE)
		@Setter(AccessLevel.NONE)
		private String endorsementNumber$; // (조회결과)배서번호

		@Override
		public void write(OutputStream out) throws IOException {
			noteDetailsEnoteNumber$ = VOUtils.write(out, noteDetailsEnoteNumber, 20); // (조회결과)어음내역-전자어음번호
			noteDetailsEnoteType$ = VOUtils.write(out, noteDetailsEnoteType, 1); // (조회결과)어음내역-전자어음종류
			noteDetailsEnoteProcessStatus$ = VOUtils.write(out, noteDetailsEnoteProcessStatus, 2); // (조회결과)어음내역-전자어음처리상태
			noteDetailsEnoteIssueDate$ = VOUtils.write(out, noteDetailsEnoteIssueDate, 8); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace$ = VOUtils.write(out, noteDetailsEnoteIssuePlace, 60, "EUC-KR"); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount$ = VOUtils.write(out, noteDetailsEnoteAmount, 15); // (조회결과)어음내역-전자어음금액
			noteDetailsDefaultReasonCode$ = VOUtils.write(out, noteDetailsDefaultReasonCode, 2); // (조회결과)어음내역-부도사유코드
			noteDetailsEnoteMaturedDate$ = VOUtils.write(out, noteDetailsEnoteMaturedDate, 8); // (조회결과)어음내역-전자어음만기일자
			noteDetailsEnoteDefaultProcessingDate$ = VOUtils.write(out, noteDetailsEnoteDefaultProcessingDate, 8); // (조회결과)어음내역-전자어음부도처리일자
			noteDetailsPaymentBankAndBranchCode$ = VOUtils.write(out, noteDetailsPaymentBankAndBranchCode, 7); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // (조회결과)발행인-주민사업자번호
			issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // (조회결과)발행인-법인명
			issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // (조회결과)발행인-성명(대표자명)
			issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // (조회결과)발행인-주소
			issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // (조회결과)발행인-당좌계좌번호
			recipientIndvCorpSort$ = VOUtils.write(out, recipientIndvCorpSort, 1); // (조회결과)소지인개인법인구분
			recipientResidentBusinessNumber$ = VOUtils.write(out, recipientResidentBusinessNumber, 13); // (조회결과)소지인주민사업자번호
			recipientCorpName$ = VOUtils.write(out, recipientCorpName, 40, "EUC-KR"); // (조회결과)소지인법인명
			recipientNameRepresentative$ = VOUtils.write(out, recipientNameRepresentative, 20, "EUC-KR"); // (조회결과)소지인성명(대표자명)
			recipientAddress$ = VOUtils.write(out, recipientAddress, 60, "EUC-KR"); // (조회결과)소지인주소
			recipientBankCode$ = VOUtils.write(out, recipientBankCode, 3); // (조회결과)소지인은행코드
			recipientDepositAccountNumber$ = VOUtils.write(out, recipientDepositAccountNumber, 16); // (조회결과)소지인입금계좌번호
			recipientdefaultAmount$ = VOUtils.write(out, recipientdefaultAmount, 15); // (조회결과)소지인부도금액
			splitNumber$ = VOUtils.write(out, splitNumber, 2); // (조회결과)분할번호
			endorsementNumber$ = VOUtils.write(out, endorsementNumber, 2); // (조회결과)배서번호
		}

		@Override
		public void read(InputStream in) throws IOException {
			noteDetailsEnoteNumber = VOUtils.toString(noteDetailsEnoteNumber$ = VOUtils.read(in, 20)); // (조회결과)어음내역-전자어음번호
			noteDetailsEnoteType = VOUtils.toString(noteDetailsEnoteType$ = VOUtils.read(in, 1)); // (조회결과)어음내역-전자어음종류
			noteDetailsEnoteProcessStatus = VOUtils.toString(noteDetailsEnoteProcessStatus$ = VOUtils.read(in, 2)); // (조회결과)어음내역-전자어음처리상태
			noteDetailsEnoteIssueDate = VOUtils.toString(noteDetailsEnoteIssueDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음발행일자
			noteDetailsEnoteIssuePlace = VOUtils.toString(noteDetailsEnoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)어음내역-전자어음발행지
			noteDetailsEnoteAmount = VOUtils.toLong(noteDetailsEnoteAmount$ = VOUtils.read(in, 15)); // (조회결과)어음내역-전자어음금액
			noteDetailsDefaultReasonCode = VOUtils.toString(noteDetailsDefaultReasonCode$ = VOUtils.read(in, 2)); // (조회결과)어음내역-부도사유코드
			noteDetailsEnoteMaturedDate = VOUtils.toString(noteDetailsEnoteMaturedDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음만기일자
			noteDetailsEnoteDefaultProcessingDate = VOUtils.toString(noteDetailsEnoteDefaultProcessingDate$ = VOUtils.read(in, 8)); // (조회결과)어음내역-전자어음부도처리일자
			noteDetailsPaymentBankAndBranchCode = VOUtils.toString(noteDetailsPaymentBankAndBranchCode$ = VOUtils.read(in, 7)); // (조회결과)어음내역-지급은행및지점코드
			issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // (조회결과)발행인-개인법인구분
			issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)발행인-주민사업자번호
			issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)발행인-법인명
			issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)발행인-성명(대표자명)
			issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)발행인-주소
			issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)발행인-당좌계좌번호
			recipientIndvCorpSort = VOUtils.toString(recipientIndvCorpSort$ = VOUtils.read(in, 1)); // (조회결과)소지인개인법인구분
			recipientResidentBusinessNumber = VOUtils.toString(recipientResidentBusinessNumber$ = VOUtils.read(in, 13)); // (조회결과)소지인주민사업자번호
			recipientCorpName = VOUtils.toString(recipientCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // (조회결과)소지인법인명
			recipientNameRepresentative = VOUtils.toString(recipientNameRepresentative$ = VOUtils.read(in, 20, "EUC-KR")); // (조회결과)소지인성명(대표자명)
			recipientAddress = VOUtils.toString(recipientAddress$ = VOUtils.read(in, 60, "EUC-KR")); // (조회결과)소지인주소
			recipientBankCode = VOUtils.toString(recipientBankCode$ = VOUtils.read(in, 3)); // (조회결과)소지인은행코드
			recipientDepositAccountNumber = VOUtils.toString(recipientDepositAccountNumber$ = VOUtils.read(in, 16)); // (조회결과)소지인입금계좌번호
			recipientdefaultAmount = VOUtils.toLong(recipientdefaultAmount$ = VOUtils.read(in, 15)); // (조회결과)소지인부도금액
			splitNumber = VOUtils.toString(splitNumber$ = VOUtils.read(in, 2)); // (조회결과)분할번호
			endorsementNumber = VOUtils.toString(endorsementNumber$ = VOUtils.read(in, 2)); // (조회결과)배서번호
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getSimpleName());
			sb.append(" [");
			sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
			sb.append(", noteDetailsEnoteNumber=").append(noteDetailsEnoteNumber).append(System.lineSeparator()); // (조회결과)어음내역-전자어음번호
			sb.append(", noteDetailsEnoteType=").append(noteDetailsEnoteType).append(System.lineSeparator()); // (조회결과)어음내역-전자어음종류
			sb.append(", noteDetailsEnoteProcessStatus=").append(noteDetailsEnoteProcessStatus).append(System.lineSeparator()); // (조회결과)어음내역-전자어음처리상태
			sb.append(", noteDetailsEnoteIssueDate=").append(noteDetailsEnoteIssueDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행일자
			sb.append(", noteDetailsEnoteIssuePlace=").append(noteDetailsEnoteIssuePlace).append(System.lineSeparator()); // (조회결과)어음내역-전자어음발행지
			sb.append(", noteDetailsEnoteAmount=").append(noteDetailsEnoteAmount).append(System.lineSeparator()); // (조회결과)어음내역-전자어음금액
			sb.append(", noteDetailsDefaultReasonCode=").append(noteDetailsDefaultReasonCode).append(System.lineSeparator()); // (조회결과)어음내역-부도사유코드
			sb.append(", noteDetailsEnoteMaturedDate=").append(noteDetailsEnoteMaturedDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음만기일자
			sb.append(", noteDetailsEnoteDefaultProcessingDate=").append(noteDetailsEnoteDefaultProcessingDate).append(System.lineSeparator()); // (조회결과)어음내역-전자어음부도처리일자
			sb.append(", noteDetailsPaymentBankAndBranchCode=").append(noteDetailsPaymentBankAndBranchCode).append(System.lineSeparator()); // (조회결과)어음내역-지급은행및지점코드
			sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // (조회결과)발행인-개인법인구분
			sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)발행인-주민사업자번호
			sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // (조회결과)발행인-법인명
			sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // (조회결과)발행인-성명(대표자명)
			sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // (조회결과)발행인-주소
			sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // (조회결과)발행인-당좌계좌번호
			sb.append(", recipientIndvCorpSort=").append(recipientIndvCorpSort).append(System.lineSeparator()); // (조회결과)소지인개인법인구분
			sb.append(", recipientResidentBusinessNumber=").append(recipientResidentBusinessNumber).append(System.lineSeparator()); // (조회결과)소지인주민사업자번호
			sb.append(", recipientCorpName=").append(recipientCorpName).append(System.lineSeparator()); // (조회결과)소지인법인명
			sb.append(", recipientNameRepresentative=").append(recipientNameRepresentative).append(System.lineSeparator()); // (조회결과)소지인성명(대표자명)
			sb.append(", recipientAddress=").append(recipientAddress).append(System.lineSeparator()); // (조회결과)소지인주소
			sb.append(", recipientBankCode=").append(recipientBankCode).append(System.lineSeparator()); // (조회결과)소지인은행코드
			sb.append(", recipientDepositAccountNumber=").append(recipientDepositAccountNumber).append(System.lineSeparator()); // (조회결과)소지인입금계좌번호
			sb.append(", recipientdefaultAmount=").append(recipientdefaultAmount).append(System.lineSeparator()); // (조회결과)소지인부도금액
			sb.append(", splitNumber=").append(splitNumber).append(System.lineSeparator()); // (조회결과)분할번호
			sb.append(", endorsementNumber=").append(endorsementNumber).append(System.lineSeparator()); // (조회결과)배서번호
			sb.append("]");
			return sb.toString();
		}

	}

	private String tcpIpHeader = "0000"; // TCP/IP HEADER
	private String systemId = "EBS"; // 시스템-ID
	private String bnkCd = "057"; // 은행코드
	private String messageType = "0200"; // 전문종별코드
	private String transactionCode = "462000"; // 거래구분코드
	private String messageTrackingNumber; // 전문추적번호
	private String sendReceiveFlag; // 송수신FLAG
	private String transactionIdNumber; // 거래고유번호
	private String status = "000"; // STATUS
	private String responseCode1; // 응답코드1
	private String responseCode2; // 응답코드2
	private LocalDateTime messageSendTime; // 전문전송일시
	private String kftcStatisticsCode; // 관리기관통계코드
	private String searchConditionSort; // 검색조건구분
	private String eNoteNumber; // 전자어음번호
	private String residentBusinessNumber; // 주민사업자번호
	private String currentCreditAccountNumber; // 당좌(입금)계좌번호
	private String defaultInquiryStartDate; // 부도일기준조회시작일
	private String defaultInquiryEndDate; // 부도일기준조회종료일
	private int totalQueryResultCount; // 조회결과총건수
	private int specifiedQueryNumber; // 조회내역지정번호
	private int currentCount; // 현재건수
	private List<KftEnt0200462000.QueryResult> queryResultArray = new ArrayList<>(); // 조회결과Array
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String transactionIdNumber$; // 거래고유번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode1$; // 응답코드1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode2$; // 응답코드2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송일시
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcStatisticsCode$; // 관리기관통계코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String searchConditionSort$; // 검색조건구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String eNoteNumber$; // 전자어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String residentBusinessNumber$; // 주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCreditAccountNumber$; // 당좌(입금)계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultInquiryStartDate$; // 부도일기준조회시작일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String defaultInquiryEndDate$; // 부도일기준조회종료일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalQueryResultCount$; // 조회결과총건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String specifiedQueryNumber$; // 조회내역지정번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String currentCount$; // 현재건수

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isWhitespace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isNotAlphanumericSpace(bnkCd$)) { // 은행코드
			return 2;
		}
		if (VOUtils.isNotAlphanumericSpace(messageType$)) { // 전문종별코드
			return 3;
		}
		if (VOUtils.isNotAlphanumericSpace(messageTrackingNumber$)) { // 전문추적번호
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(transactionIdNumber$)) { // 거래고유번호
			return 7;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode1$)) { // 응답코드1
			return 9;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode2$)) { // 응답코드2
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(kftcStatisticsCode$)) { // 관리기관통계코드
			return 12;
		}
		if (VOUtils.isNotAlphanumericSpace(eNoteNumber$)) { // 전자어음번호
			return 14;
		}
		if (VOUtils.isNotAlphanumericSpace(residentBusinessNumber$)) { // 주민사업자번호
			return 15;
		}
		if (VOUtils.isNotAlphanumericSpace(currentCreditAccountNumber$)) { // 당좌(입금)계좌번호
			return 16;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		currentCount = queryResultArray.size(); // 조회결과Array
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 4); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		transactionCode$ = VOUtils.write(out, transactionCode, 6); // 거래구분코드
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 11); // 전문추적번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		transactionIdNumber$ = VOUtils.write(out, transactionIdNumber, 13); // 거래고유번호
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode1$ = VOUtils.write(out, responseCode1, 3); // 응답코드1
		responseCode2$ = VOUtils.write(out, responseCode2, 20); // 응답코드2
		messageSendTime$ = VOUtils.write(out, messageSendTime, 14, "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode$ = VOUtils.write(out, kftcStatisticsCode, 10); // 관리기관통계코드
		searchConditionSort$ = VOUtils.write(out, searchConditionSort, 1); // 검색조건구분
		eNoteNumber$ = VOUtils.write(out, eNoteNumber, 20); // 전자어음번호
		residentBusinessNumber$ = VOUtils.write(out, residentBusinessNumber, 13); // 주민사업자번호
		currentCreditAccountNumber$ = VOUtils.write(out, currentCreditAccountNumber, 16); // 당좌(입금)계좌번호
		defaultInquiryStartDate$ = VOUtils.write(out, defaultInquiryStartDate, 8); // 부도일기준조회시작일
		defaultInquiryEndDate$ = VOUtils.write(out, defaultInquiryEndDate, 8); // 부도일기준조회종료일
		totalQueryResultCount$ = VOUtils.write(out, totalQueryResultCount, 3); // 조회결과총건수
		specifiedQueryNumber$ = VOUtils.write(out, specifiedQueryNumber, 3); // 조회내역지정번호
		currentCount$ = VOUtils.write(out, currentCount, 3); // 현재건수
		VOUtils.write(out, queryResultArray, 5, KftEnt0200462000.QueryResult::new); // 조회결과Array
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 4)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		transactionCode = VOUtils.toString(transactionCode$ = VOUtils.read(in, 6)); // 거래구분코드
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 11)); // 전문추적번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		transactionIdNumber = VOUtils.toString(transactionIdNumber$ = VOUtils.read(in, 13)); // 거래고유번호
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode1 = VOUtils.toString(responseCode1$ = VOUtils.read(in, 3)); // 응답코드1
		responseCode2 = VOUtils.toString(responseCode2$ = VOUtils.read(in, 20)); // 응답코드2
		messageSendTime = VOUtils.toLocalDateTime(messageSendTime$ = VOUtils.read(in, 14), "yyyyMMddHHmmss"); // 전문전송일시
		kftcStatisticsCode = VOUtils.toString(kftcStatisticsCode$ = VOUtils.read(in, 10)); // 관리기관통계코드
		searchConditionSort = VOUtils.toString(searchConditionSort$ = VOUtils.read(in, 1)); // 검색조건구분
		eNoteNumber = VOUtils.toString(eNoteNumber$ = VOUtils.read(in, 20)); // 전자어음번호
		residentBusinessNumber = VOUtils.toString(residentBusinessNumber$ = VOUtils.read(in, 13)); // 주민사업자번호
		currentCreditAccountNumber = VOUtils.toString(currentCreditAccountNumber$ = VOUtils.read(in, 16)); // 당좌(입금)계좌번호
		defaultInquiryStartDate = VOUtils.toString(defaultInquiryStartDate$ = VOUtils.read(in, 8)); // 부도일기준조회시작일
		defaultInquiryEndDate = VOUtils.toString(defaultInquiryEndDate$ = VOUtils.read(in, 8)); // 부도일기준조회종료일
		totalQueryResultCount = VOUtils.toInt(totalQueryResultCount$ = VOUtils.read(in, 3)); // 조회결과총건수
		specifiedQueryNumber = VOUtils.toInt(specifiedQueryNumber$ = VOUtils.read(in, 3)); // 조회내역지정번호
		currentCount = VOUtils.toInt(currentCount$ = VOUtils.read(in, 3)); // 현재건수
		queryResultArray = VOUtils.toVoList(in, currentCount, KftEnt0200462000.QueryResult.class); // 조회결과Array
	}

	@Override
	public String toString() {
		currentCount = queryResultArray.size(); // 조회결과Array
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", transactionCode=").append(transactionCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", transactionIdNumber=").append(transactionIdNumber).append(System.lineSeparator()); // 거래고유번호
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode1=").append(responseCode1).append(System.lineSeparator()); // 응답코드1
		sb.append(", responseCode2=").append(responseCode2).append(System.lineSeparator()); // 응답코드2
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송일시
		sb.append(", kftcStatisticsCode=").append(kftcStatisticsCode).append(System.lineSeparator()); // 관리기관통계코드
		sb.append(", searchConditionSort=").append(searchConditionSort).append(System.lineSeparator()); // 검색조건구분
		sb.append(", eNoteNumber=").append(eNoteNumber).append(System.lineSeparator()); // 전자어음번호
		sb.append(", residentBusinessNumber=").append(residentBusinessNumber).append(System.lineSeparator()); // 주민사업자번호
		sb.append(", currentCreditAccountNumber=").append(currentCreditAccountNumber).append(System.lineSeparator()); // 당좌(입금)계좌번호
		sb.append(", defaultInquiryStartDate=").append(defaultInquiryStartDate).append(System.lineSeparator()); // 부도일기준조회시작일
		sb.append(", defaultInquiryEndDate=").append(defaultInquiryEndDate).append(System.lineSeparator()); // 부도일기준조회종료일
		sb.append(", totalQueryResultCount=").append(totalQueryResultCount).append(System.lineSeparator()); // 조회결과총건수
		sb.append(", specifiedQueryNumber=").append(specifiedQueryNumber).append(System.lineSeparator()); // 조회내역지정번호
		sb.append(", currentCount=").append(currentCount).append(System.lineSeparator()); // 현재건수
		sb.append(", queryResultArray=").append(queryResultArray).append(System.lineSeparator()); // 조회결과Array
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "EBS"),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0200"),
			Map.of("fld", "transactionCode", "fldLen", "6", "defltVal", "462000"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "transactionIdNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode1", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "responseCode2", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "messageSendTime", "fldLen", "14", "defltVal", "$yyyymmddhhmiss"),
			Map.of("fld", "kftcStatisticsCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "searchConditionSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "eNoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "residentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "currentCreditAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "defaultInquiryStartDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "defaultInquiryEndDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalQueryResultCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "specifiedQueryNumber", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "currentCount", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "queryResultArray", "fldLen", "5", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteProcessStatus", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "noteDetailsDefaultReasonCode", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsEnoteDefaultProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "noteDetailsPaymentBankAndBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientIndvCorpSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "recipientResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "recipientCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "recipientNameRepresentative", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "recipientAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "recipientBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "recipientDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "recipientdefaultAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "splitNumber", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "endorsementNumber", "fldLen", "2", "defltVal", "")
		);
	}

}
