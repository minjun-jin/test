package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (당일)출금결과내역
 * <pre>{@code
 * KftCmsEC22H kftCmsEC22H  = new KftCmsEC22H(); // (당일)출금결과내역
 * kftCmsEC22H.setRecordType(""); // Record 구분
 * kftCmsEC22H.setSerialNumber(""); // 일련번호
 * kftCmsEC22H.setInstitutionCode(""); // 기관코드
 * kftCmsEC22H.setFileName(""); // File 이름
 * kftCmsEC22H.setWithdrawalDate(""); // 출금일자
 * kftCmsEC22H.setMainBankBranchCode(""); // 주거래은행점코드
 * kftCmsEC22H.setDepositAccountNumber(""); // 입금계좌번호
 * kftCmsEC22H.setFiller1(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEC22H implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private String withdrawalDate; // 출금일자
	private String mainBankBranchCode; // 주거래은행점코드
	private String depositAccountNumber; // 입금계좌번호
	private String filler1; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalDate$; // 출금일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String mainBankBranchCode$; // 주거래은행점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositAccountNumber$; // 입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler1$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		withdrawalDate$ = VOUtils.write(out, withdrawalDate, 6); // 출금일자
		mainBankBranchCode$ = VOUtils.write(out, mainBankBranchCode, 7); // 주거래은행점코드
		depositAccountNumber$ = VOUtils.write(out, depositAccountNumber, 16); // 입금계좌번호
		filler1$ = VOUtils.write(out, filler1, 94); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		withdrawalDate = VOUtils.toString(withdrawalDate$ = VOUtils.read(in, 6)); // 출금일자
		mainBankBranchCode = VOUtils.toString(mainBankBranchCode$ = VOUtils.read(in, 7)); // 주거래은행점코드
		depositAccountNumber = VOUtils.toString(depositAccountNumber$ = VOUtils.read(in, 16)); // 입금계좌번호
		filler1 = VOUtils.toString(filler1$ = VOUtils.read(in, 94)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", withdrawalDate=").append(withdrawalDate).append(System.lineSeparator()); // 출금일자
		sb.append(", mainBankBranchCode=").append(mainBankBranchCode).append(System.lineSeparator()); // 주거래은행점코드
		sb.append(", depositAccountNumber=").append(depositAccountNumber).append(System.lineSeparator()); // 입금계좌번호
		sb.append(", filler1=").append(filler1).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "withdrawalDate", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "mainBankBranchCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "depositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler1", "fldLen", "94", "defltVal", "")
		);
	}

}
