package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * (은행접수)출금이체신청내역
 * <pre>{@code
 * KftCmsEB11T kftCmsEB11T  = new KftCmsEB11T(); // (은행접수)출금이체신청내역
 * kftCmsEB11T.setRecordType(""); // Record 구분
 * kftCmsEB11T.setSerialNumber(""); // 일련번호
 * kftCmsEB11T.setInstitutionCode(""); // 기관코드
 * kftCmsEB11T.setFileName(""); // File 이름
 * kftCmsEB11T.setTotalDataRecordCount(0); // 총 DATA RECORD 수
 * kftCmsEB11T.setRegisterRequestCountRegistration(0); // 등록의뢰건수-신규등록
 * kftCmsEB11T.setRegisterRequestCountModification(0); // 등록의뢰건수-변경등록
 * kftCmsEB11T.setRegisterRequestCountTermination(0); // 등록의뢰건수-해지등록
 * kftCmsEB11T.setRegisterRequestCountArbitraryTermination(0); // 등록의뢰건수-임의해지
 * kftCmsEB11T.setFiller2(""); // FILLER
 * kftCmsEB11T.setMacValue(""); // MAC 검증값
 * }</pre>
 */
@Data
public class KftCmsEB11T implements Vo {

	private String recordType; // Record 구분
	private String serialNumber; // 일련번호
	private String institutionCode; // 기관코드
	private String fileName; // File 이름
	private int totalDataRecordCount; // 총 DATA RECORD 수
	private int registerRequestCountRegistration; // 등록의뢰건수-신규등록
	private int registerRequestCountModification; // 등록의뢰건수-변경등록
	private int registerRequestCountTermination; // 등록의뢰건수-해지등록
	private int registerRequestCountArbitraryTermination; // 등록의뢰건수-임의해지
	private String filler2; // FILLER
	private String macValue; // MAC 검증값
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // File 이름
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalDataRecordCount$; // 총 DATA RECORD 수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerRequestCountRegistration$; // 등록의뢰건수-신규등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerRequestCountModification$; // 등록의뢰건수-변경등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerRequestCountTermination$; // 등록의뢰건수-해지등록
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String registerRequestCountArbitraryTermination$; // 등록의뢰건수-임의해지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String macValue$; // MAC 검증값

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		serialNumber$ = VOUtils.write(out, serialNumber, 8); // 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		fileName$ = VOUtils.write(out, fileName, 8); // File 이름
		totalDataRecordCount$ = VOUtils.write(out, totalDataRecordCount, 8); // 총 DATA RECORD 수
		registerRequestCountRegistration$ = VOUtils.write(out, registerRequestCountRegistration, 8); // 등록의뢰건수-신규등록
		registerRequestCountModification$ = VOUtils.write(out, registerRequestCountModification, 8); // 등록의뢰건수-변경등록
		registerRequestCountTermination$ = VOUtils.write(out, registerRequestCountTermination, 8); // 등록의뢰건수-해지등록
		registerRequestCountArbitraryTermination$ = VOUtils.write(out, registerRequestCountArbitraryTermination, 8); // 등록의뢰건수-임의해지
		filler2$ = VOUtils.write(out, filler2, 43); // FILLER
		macValue$ = VOUtils.write(out, macValue, 10); // MAC 검증값
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 8)); // 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 8)); // File 이름
		totalDataRecordCount = VOUtils.toInt(totalDataRecordCount$ = VOUtils.read(in, 8)); // 총 DATA RECORD 수
		registerRequestCountRegistration = VOUtils.toInt(registerRequestCountRegistration$ = VOUtils.read(in, 8)); // 등록의뢰건수-신규등록
		registerRequestCountModification = VOUtils.toInt(registerRequestCountModification$ = VOUtils.read(in, 8)); // 등록의뢰건수-변경등록
		registerRequestCountTermination = VOUtils.toInt(registerRequestCountTermination$ = VOUtils.read(in, 8)); // 등록의뢰건수-해지등록
		registerRequestCountArbitraryTermination = VOUtils.toInt(registerRequestCountArbitraryTermination$ = VOUtils.read(in, 8)); // 등록의뢰건수-임의해지
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 43)); // FILLER
		macValue = VOUtils.toString(macValue$ = VOUtils.read(in, 10)); // MAC 검증값
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // File 이름
		sb.append(", totalDataRecordCount=").append(totalDataRecordCount).append(System.lineSeparator()); // 총 DATA RECORD 수
		sb.append(", registerRequestCountRegistration=").append(registerRequestCountRegistration).append(System.lineSeparator()); // 등록의뢰건수-신규등록
		sb.append(", registerRequestCountModification=").append(registerRequestCountModification).append(System.lineSeparator()); // 등록의뢰건수-변경등록
		sb.append(", registerRequestCountTermination=").append(registerRequestCountTermination).append(System.lineSeparator()); // 등록의뢰건수-해지등록
		sb.append(", registerRequestCountArbitraryTermination=").append(registerRequestCountArbitraryTermination).append(System.lineSeparator()); // 등록의뢰건수-임의해지
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append(", macValue=").append(macValue).append(System.lineSeparator()); // MAC 검증값
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "fileName", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "totalDataRecordCount", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerRequestCountRegistration", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerRequestCountModification", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerRequestCountTermination", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "registerRequestCountArbitraryTermination", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "43", "defltVal", ""),
			Map.of("fld", "macValue", "fldLen", "10", "defltVal", "")
		);
	}

}
