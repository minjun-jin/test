package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 종료예고
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 전문길이(4)+HDR
 * systemId 시스템-ID 고유 System ID (ELB)
 * messageType 전문종별코드 전문종별코드
 * messageCode 통신망관리정보/거래구분코드 거래구분코드
 * sendReceiveFlag 송수신Flag 1:요구,2:지시,3:보고,4:통보,5:통보(지연/재요구응답)
 * status STATUS 오류전문 발생항목의 Bit Map번호
 * responseCode 응답코드 응답코드
 * messageTransmissionDate 전문전송일 YYYYMMDD
 * messageSendTime 전문전송시간 hhmmss
 * messageTrackingNumber 전문추적번호 전문추적번호
 * traxOccurredDateTime 거래발생일자 YYYYMMDD
 * institutionCode 기관코드 대표기관코드
 * recoveryInstitutionCode 장애(회복)기관코드 시스템 장애, 장애회복 처리에서 장애(장애회복)이 발생한 기관의 대표코드.(개시, 종료예고, 종료, 회선시험의 경우에는 “000”)
 * 
 * KftHof0810201000 kftHof0810201000 = new KftHof0810201000(); // 종료예고
 * kftHof0810201000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0810201000.setSystemId("ELB"); // 시스템-ID
 * kftHof0810201000.setMessageType("0810"); // 전문종별코드
 * kftHof0810201000.setMessageCode("201000"); // 통신망관리정보/거래구분코드
 * kftHof0810201000.setSendReceiveFlag("3"); // 송수신Flag
 * kftHof0810201000.setStatus("000"); // STATUS
 * kftHof0810201000.setResponseCode(""); // 응답코드
 * kftHof0810201000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0810201000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0810201000.setMessageTrackingNumber("00000000"); // 전문추적번호
 * kftHof0810201000.setTraxOccurredDateTime("00000000"); // 거래발생일자
 * kftHof0810201000.setInstitutionCode("000"); // 기관코드
 * kftHof0810201000.setRecoveryInstitutionCode("000"); // 장애(회복)기관코드
 * }</pre>
 */
@Data
public class KftHof0810201000 implements KftHofMngHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "ELB"; // 시스템-ID
	private String messageType = "0810"; // 전문종별코드
	private String messageCode = "201000"; // 통신망관리정보/거래구분코드
	private String sendReceiveFlag = "3"; // 송수신Flag
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "00000000"; // 전문추적번호
	private String traxOccurredDateTime = "00000000"; // 거래발생일자
	private String institutionCode = "000"; // 기관코드
	private String recoveryInstitutionCode = "000"; // 장애(회복)기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 통신망관리정보/거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신Flag
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String traxOccurredDateTime$; // 거래발생일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recoveryInstitutionCode$; // 장애(회복)기관코드

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 2;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신Flag
			return 4;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 7;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 8;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 9;
		}
		if (VOUtils.isWhitespace(traxOccurredDateTime$)) { // 거래발생일자
			return 10;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 통신망관리정보/거래구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신Flag
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 8); // 전문추적번호
		traxOccurredDateTime$ = VOUtils.write(out, traxOccurredDateTime, 8); // 거래발생일자
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		recoveryInstitutionCode$ = VOUtils.write(out, recoveryInstitutionCode, 3); // 장애(회복)기관코드
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 통신망관리정보/거래구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신Flag
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 8)); // 전문추적번호
		traxOccurredDateTime = VOUtils.toString(traxOccurredDateTime$ = VOUtils.read(in, 8)); // 거래발생일자
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		recoveryInstitutionCode = VOUtils.toString(recoveryInstitutionCode$ = VOUtils.read(in, 3)); // 장애(회복)기관코드
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 통신망관리정보/거래구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신Flag
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", traxOccurredDateTime=").append(traxOccurredDateTime).append(System.lineSeparator()); // 거래발생일자
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", recoveryInstitutionCode=").append(recoveryInstitutionCode).append(System.lineSeparator()); // 장애(회복)기관코드
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "ELB"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0810"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "201000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "3"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "traxOccurredDateTime", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "recoveryInstitutionCode", "fldLen", "3", "defltVal", "000")
		);
	}

}
