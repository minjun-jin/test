import React from "react"
import { fireEvent, render, waitFor } from "@testing-library/react"
import { findByRole, findByText } from "@testing-library/react"

// 다국어 유틸 모킹
jest.mock("@/utils/common.i18n", () => ({
  $i18nUtils: {
    trans: jest.fn((key) => key),
    getDataByLanguage: jest.fn(),
    getLanguage: jest.fn(),
  },
}))

// useParams 훅 모킹: 기본 params 제공
jest.mock("@/hooks/useParams", () => ({
  __esModule: true,
  default: jest.fn(),
}))
import mockUseParams from "@/hooks/useParams"

// Tab 하위 컴포넌트 모킹
jest.mock("@/pages/views/ent/UENTOPS-215-Tab1", () => {
  const { forwardRef } = jest.requireActual("react")
  return forwardRef((props: any, ref: any) => {
    ref.current = { setOutIssurInfoDetail: jest.fn(), resetTab: jest.fn() }
    return <div>tab1</div>
  })
})
jest.mock("@/pages/views/ent/UENTOPS-215-Tab2", () => {
  const { forwardRef } = jest.requireActual("react")
  return forwardRef((props: any, ref: any) => {
    ref.current = { setOutEndrInfoDetail: jest.fn(), resetTab: jest.fn() }
    return <div>tab2</div>
  })
})
jest.mock("@/pages/views/ent/UENTOPS-215-Tab3", () => {
  const { forwardRef } = jest.requireActual("react")
  return forwardRef((props: any, ref: any) => {
    ref.current = { setOutIssurGuaranteeDetail: jest.fn(), resetTab: jest.fn() }
    return <div>tab3</div>
  })
})
jest.mock("@/pages/views/ent/UENTOPS-215-Tab4", () => {
  const { forwardRef } = jest.requireActual("react")
  return forwardRef((props: any, ref: any) => {
    ref.current = { setOutEndrGuaranteeDetail: jest.fn(), resetTab: jest.fn() }
    return <div>tab4</div>
  })
})

// 컴포넌트 및 테스트 유틸
import UENTOPS215 from "@/pages/views/ent/UENTOPS-215"
import { Component } from "@/hoc/TestUtil"

// useProxy 훅은 TestUtil에서 제공하는 mockUseProxy 사용
// mockUseProxy.mockAsync

const component = Component(UENTOPS215)

describe("[UENTOPS-215] 전자어음 현황", () => {
  beforeAll(() => {
    // 정상 params
    mockUseParams.mockReturnValue({
      params: { entNo: "ENT001", spltNo: "1", endtNo: "1" },
    })
  })

  beforeEach(() => {
    mockUseProxy.mockAsync.mockReset()
    // getENoteStatus 호출
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          outIssurInfo: {},
          outEndrInfo: {},
          outIssurGuarantee: {},
          outEndrGuarantee: {},
          entEnoteInfo: {
            entNo: "ENT001",
            entIssueDt: "20240101",
            pymntBnkCd: "001",
            pymntBrnchCd: "0001",
            entAmt: "1000",
            entMatDt: "20240110",
            prohbtInstrctYn: "N",
            batBfPymntDt: "20240109",
          },
        },
      })
      // getListBankBranchCodeLabel 호출
      .mockResolvedValueOnce({
        data: { codeList: [{ codeField: "branch1", labelField: "Branch 1" }] },
      })
  })

  it("renders and initializes with data", async () => {
    const { findByText, findByRole } = render(component)
    // 비동기 호출 대기
    await waitFor(() => expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2))
    // 탭 자식 컴포넌트 확인
    expect(await findByText("tab1")).toBeInTheDocument()
    expect(await findByText("tab2")).toBeInTheDocument()
  })

  it("click init resets forms without fetching new data", async () => {
    const { findByRole } = render(component)
    await waitFor(() => expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2))
    mockUseProxy.mockAsync.mockClear()

    // init 버튼만 선택
    const initBtn = await findByRole("button", { name: "SCRNITM#init" })
    fireEvent.click(initBtn)

    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("click search fetches data again", async () => {
    const { findByRole } = render(component)
    await waitFor(() => expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2))
    mockUseProxy.mockAsync.mockReset()

    // 검색 클릭으로 호출 재설정
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          outIssurInfo: {},
          outEndrInfo: {},
          outIssurGuarantee: {},
          outEndrGuarantee: {},
          entEnoteInfo: {
            entNo: "ENT002",
            entIssueDt: "20240201",
            pymntBnkCd: "002",
            pymntBrnchCd: "0002",
            entAmt: "2000",
            entMatDt: "20240210",
            prohbtInstrctYn: "Y",
            batBfPymntDt: "20240209",
          },
        },
      })
      .mockResolvedValueOnce({ data: { codeList: [] } })

    const searchBtn = await findByRole("button", { name: "SCRNITM#search" })
    fireEvent.click(searchBtn)

    await waitFor(() => expect(mockUseProxy.mockAsync).toHaveBeenCalledTimes(2))
  })

  it("does not fetch data when params is null", async () => {
    mockUseParams.mockReturnValue({ params: null })
    mockUseProxy.mockAsync.mockReset()

    render(component)
    await waitFor(() => {
      expect(mockUseProxy.mockAsync).not.toHaveBeenCalled()
    })
  })

  it("handles undefined branch list gracefully", async () => {
    mockUseProxy.mockAsync.mockReset()
    mockUseProxy.mockAsync
      .mockResolvedValueOnce({
        data: {
          outIssurInfo: {},
          outEndrInfo: {},
          outIssurGuarantee: {},
          outEndrGuarantee: {},
          entEnoteInfo: {
            entNo: "ENT003",
            entIssueDt: "20240301",
            pymntBnkCd: "003",
            pymntBrnchCd: "0003",
            entAmt: "3000",
            entMatDt: "20240310",
            prohbtInstrctYn: "N",
            batBfPymntDt: "20240309",
          },
        },
      })
      .mockResolvedValueOnce({ data: { codeList: undefined } })

    const { findByText } = render(component)
    // 에러 없이 탭이 렌더링 되는지 확인
    expect(await findByText("tab1")).toBeInTheDocument()
  })
})
