import Base from "antd/es/typography/Base"

export type NavItem = {
  title: string
  href: string
  isExternal?: boolean
  disabled?: boolean
}

export type CardProps = {
  src?: any | string
  alt: string
  githubUrl?: string
  liveUrl?: string
  title: string
  description?: string
}

export type PostProps = {
  _id: string
  title: string
  slug: string
  description?: string
  imageSrc?: string
  imageAlt?: string
  body: {
    code: string
    raw?: string
  }
  status?: string
  headings?: string[]
  tweetIds?: string[]
  publishedAt?: string
  publishedAtFormatted?: string
}

export interface CodeItem {
  codeField: string | number
  labelField: string
  label?: string
  subCdNum1?: number
  subCdNum2?: number
  subCdChar1?: string
  subCdChar2?: string
  useYn?: string
  cdSort?: string | number
}

export interface AddDay {
  year?: number
  month?: number
  day?: number
}

// 사용자 정보
export interface User {
  rntmEnvDsCd: string
  chnlDscd: string
  txDt: string
  lngCd: string
  sysIntrfcId: string
  staffId: string
  staffNm: string
  deptId: string
  deptNm: string
  userGrpCd: string
  sssnId: string
  lastLoinDtm: string
  tmpPswdYn: string
  pswdExprDudtYn: string
  pswdExprYn: string
  mgrRoleYn: string
  roleList: string
  loginComplete: boolean
}

interface Base {
  frstRegsTmstmp?: string // 최초등록일시
  frstRegsStaffId?: string // 최초등록자사원번호
  frstChngTmstmp?: string // 최초변경일시
  frstChngStaffId?: string // 최초변경자사원번호
  lastChngTmstmp?: string // 최종변경일시
  lastChngStaffId?: string // 최종변경자사원번호
}

// 메뉴 정보
export interface Menu extends Base {
  key?: string // (FE)메뉴번호
  title?: string // (FE)메뉴명
  menuId: string // 메뉴번호
  menuNm?: string // 메뉴명
  upperMenuId: string // 상위메뉴ID
  level: number // 화면레벨
  menuFl?: string // 메뉴여부
  menuSort?: string // 메뉴정렬순서
  menuHideFl?: string // 메뉴숨김여부
  scrnId?: string // 화면ID
  menuLink?: string // 메뉴Link
  description?: string // 메뉴설명
  selected?: boolean // 메뉴선택여부
  aprvStsCd?: string
  pathName?: string // 화면에서만들어서 사용하는 속성성
  children?: Menu[]
}

// 선택된 메뉴 정보
export interface SelectMenu extends Base {
  level1: string // 선택된 1레벨 메뉴
  level2: string[] // 선택된 2레벨 메뉴
  level3: string // 선택된 3레벨 메뉴
}

// 메세지 파라미터
export interface MessageParam {
  title?: string
  content: string
  type?: string
  params?: object
  inputEl?: object
}

// 팝업 파라미터
export interface PopupParam {
  screenId: string
  params?: object
  instance: any
}

// 승인요청성공메시지 파라미터
export interface RequestApprovalAlertParam {
  cond: boolean
  showBox?: (isVisible: boolean) => void
  postFunction?: () => any
}

// 아티팩트 정보
export interface Artifact extends Base {
  artfcId?: string // 아티팩트ID
  artfcNm?: string // 아티팩트명
  artfcVer?: string // 아티팩트 버전
  alterVer?: string // 아티팩트 변경 버전
  artfcSt?: string // 아티팩트 상태
  basePkg?: string // 기준패키지
}

// 아티팩트 서비스 정보
export interface WebService extends Base {
  svcId?: string // 서비스ID
  svcNm?: string // 서비스명
  clsNm?: string // 클래스명
  opNm?: string // 오퍼레이션명
  svcTpCd?: string // 서비스실행타입
  logLvl?: string // 로그레벨
  useFl?: string // 사용여부
}

// 앱 서비스 정보
export interface AppService extends Base {
  appNm: string // 앱이름
  hostCd: string // 호스트코드
  bizDvsnCd: string // 업무구분코드
  tlgKndDvsnCd: string // 전문유형번호
  tlgBizDvsnCd: string // 전문거래번호
  aprvStsCd: string // 승인상태코드
  svcBeanNm: string // 서비스빈명
  svcNm: string // 서비스명
  logLvl: string // 로그레벨
  useYn: string // 사용여부
}

// 앱 인스턴스 정보
export interface AppInstance extends Base {
  instnId: string // 인스턴스ID
  aprvStsCd: string // 승인상태코드
  appDvsnCd: string // 앱구분코드
  hlthChcIp: string // 상태확인IP
  hlthChcPort: string // 상태확인Port
  useYn: string // 사용여부
}

// 사용자 정보
export interface UserInfo extends Base {
  emplyNmbr?: string // 사원번호
  staffId?: string // 사용자ID
  staffNm?: string // 사용자명
  dprtmId?: string // 부서ID
  ofclRspns?: string // 직책
  authority?: string // 권한
  authorityNm?: string // 권한명
  staffFl?: string // 사용자상태
  staffFlNm?: string // 사용자상태명
  hireDt?: string // 입사일
  retireDt?: string // 퇴사일
  lastLoginDtm?: string // 최종로그인일시
}

export interface StaffActInfo extends Base {
  txDt?: string // 거래일
  staffId?: string // 사용자ID
  deptId?: string // 사용자ID
  svcId?: string // 서비스ID
  scrnId?: string // 화면ID
  svcTpCd?: string // 서비스실행타입코드
  guid?: string // GUID
  rqstTmstmp?: string
  elpsMlscnd?: string
  clsNm?: string
  opNm?: string
  msgId?: string
  actCtt?: string
  errCtt?: string
}

export interface PushMessage extends Base {
  pshMsgTmpltId?: number // Push 메세지 템플릿 ID
  pshMsgTmpltNm?: string // Push 메세지 템플릿 이름
  pshChnlTpCd?: string // Push 채널 구분 코드
  useYn?: string // 사용여부
  pshMsgTmpltCtt?: string // Push 메세지 템플릿 내용
  staffId?: string // 스태프ID
  parmNm?: string // 파라미터명
  afStaffId?: string // 변경후 스태프ID
  afParmNm?: string // 변경후 파라미터명
}
export interface PshMsgHist extends Base {
  guid?: string // Push 메세지 템플릿 ID
  sndDttm?: string // Push 메세지 템플릿 이름
  pshMsgTmpltId?: number // Push 메세지 템플릿 ID
  appNm?: string // 어플리케이션명
  instanceId?: string // 인스턴스 ID
  rcvdUsr?: string // 수신자
  pshMsgTmpltCtt?: string // 템플릿 내용
}

// 권한 정보
export interface Role extends Base {
  roleCd?: string // 권한코드
  menuId?: string // 메뉴ID
}

// 코드 정보
export interface Code extends Base {
  cdGrpId?: string // 코드그룹ID
  aprvStsCd?: string // 승인상태코드
  cdGrpNm?: string // 코드그룹명
  bizDvsnCd?: string // 업무구분코드
  useYn?: string // 사용여부
  cdId?: string // 코드ID
  cdNm?: string // 코드명
  cdEnm?: string // 코드영문명
  cdNmKo?: string // 코드한글명
  cdNmEn?: string // 코드영문명
  cdSort?: string // 코드정렬순서
  subCdNum1?: string // 숫자코드1
  subCdNum2?: string // 숫자코드2
  subCdChar1?: string // 문자코드1
  subCdChar2?: string // 문자코드2
}

// 메세지 정보
export interface Message extends Base {
  msgId?: string // 메세지ID
  msgLangCd?: string // 메세지언어코드
  bsicMsgCtt?: string // 기본메세지내용
  dtlMsgCtt?: string // 상세메세지내용
  bizGbCd?: string // 업무구분코드
  bizGbNm?: string // 업무구분명
  msgTypeCd?: string // 메세지유형코드
  msgTypeNm?: string // 메세지유형명
  useFl?: string // 사용여부
}

// 배치작업 정보
export interface Batch extends Base {
  ordDt?: string
  crudType?: string // CRUD Type
  plnStaTm?: string
  btWrkExecPlnDt?: string // 배치작업실행계획일
  btWrkExecPlnTm?: string // 배치작업실행계획시간
  btRsltId?: string // 배치결과 ID
  btSchdId?: string // 배치스케줄 ID
  btWrkId?: string // 배치작업 ID
  btWrkNm?: string // 배치작업명
  btWrkDsc?: string // 배치작업설명
  btSysVal?: string // 업무구분
  bizGbCd?: string // 업무구분코드
  bizGbNm?: string // 업무구분명
  btExsvrNm?: string // 배치실행서버명
  btPgmExpl?: string // 배치프로그램명
  paramCd?: string // 파라미터코드
  paramVal?: string // 파라미터값
  cronCmd?: string // 크론명령어
  btWrkCplStCd?: string // 배치작업완료상태코드
  btWrkCplStNm?: string // 배치작업완료상태명
  btWrkErrCnts?: string // 작업오류정보내용
  execSttm?: string // 실행시작시각
  execEdtm?: string // 실행종료시각
  elpsdTm?: string // 경과시간
  btPrevYn?: string // 선행배치여부
  btPrevWrkId?: string // 선행배치작업ID
  btPrevWrkNm?: string // 선행배치작업명
  schdDvsnCd?: string // 스케줄구분코드
  dtDvsnCd?: string // 거래일자구분코드
  schdStaTm?: string // 스케줄시작시간
  schdEndTm?: string // 스케줄종료시간
  cmpltStsCd?: string //배치작업완료상태코드
  aprvStsCd?: string //배치작업결과의 상태변경 등에 대한 승인상태코드
}

// 배치스케쥴 정보
export interface BatchSchedule extends Base {
  seq?: string // 배치스케쥴순번
  btSchId?: string // 배치스케쥴 ID
  btWrkId?: string // 배치작업ID
  btSysVal?: string // 배치시스템구분
  bizGbCd?: string // 업무구분코드
  bizGbNm?: string // 업무구분명
  btExsvrNm?: string // 배치실행서버명
  btWrkNm?: string // 배치작업명
  btPgmExpl?: string // 배치프로그램명
  paramVal?: string // 파라미터값
  btWrkDsc?: string // 배치작업설명
  btExecCycl?: string // 배치실행주기
  btExecCyclNm?: string // 배치실행주기명
  btExecSchdDd?: string // 실행일정일
  btExecSchdMth?: string // (FE)실행월
  btExecSchdDt?: string // (FE)실행일자
  btExecSchdTm?: string // (FE)btExecSchdHr + btExecSchdMin + btExecSchdSec
  btExecSchdHr?: string // 실행일정시
  btExecSchdMin?: string // 실행일정분
  btExecSchdSec?: string // 실행일정초
  btExecSchdDfkCd?: string // 실행일정요일구분코드
}

export interface BatDlySchd extends Base {
  ordDt?: string // 배치작업 실행 계획일
  batRsltId?: string // 배치결과 ID
  batWrkId?: string // 배치작업 ID
  batWrkNm?: string // 배치작업명
  batPgmNm?: string // 배치프로그램명
  bizDvsnCd?: string // 업무구분코드
  batSysDvsn?: string // 배치시스템구분
  batExecNm?: string // 배치실행명
  parmVal?: string // 파라미터값
  cmpltStsCd?: string // 완료상태코드
  batWrkExecPlnDtm?: string // 배치작업실행계획일시
  plnStaDtm?: string
  plnEndDtm?: string
  schdStaTm?: string // 스케줄시작시간
  schdEndTm?: string // 스케줄종료시간
  execStaTm?: string // 실행시작시각
  execEndTm?: string // 실행종료시각
  elpsdTm?: string // 경과시간
  trgtCnt?: number // 대상수
  readCnt?: number // 읽기수
  writeCnt?: number // 쓰기수
  skipCnt?: number // 건너뛰기수
  batWrkErrCtt?: string // 배치작업오류내용
  cronSchdExcld?: string // 크론스케줄제외
}

// 배치결과 정보
export interface BatchResult {
  txDt?: string // 날짜
  rcrdCntnt?: string
}

// 전문 정보
export interface Telegram extends Base {
  crudType?: string // CRUD Type
  tgmMgmtNo?: string // 전문관리번호
  instCd?: string // 기관코드
  linkSysDvsnCd?: string // 시스템구분코드
  tgmTypeNo?: string // 전문유형번호
  tgmTxNo?: string // 전문거래번호
  tgmNm?: string // 전문명
  useFl?: string // 사용여부
  detailedBizCd?: string // 세부업무코드
  trnsmTypeCd?: string // 전송유형코드
  relatedTgmMgmtNo: string // 연관전문관리번호
  // dtoClassPath: string // 전문DTO 경로
}

// 전문 상세 정보
export interface TelegramDetail extends Base {
  crudType?: string // CRUD Type
  tgmMgmtNo?: string // 전문관리번호
  tgmDtlSq?: string // 전문상세일련번호
  tgmRecTypeCd?: string // 전문레코드유형코드
  tgmDtlSort?: string // 전문상세정렬
  depth?: number // depth
  dataType?: string // 데이터유형
  cntField?: string // 카운터필드
  fixArrSize: number // 배열고정사이즈
  field?: string // 전문항목
  fieldNm?: string // 전문항목명
  fieldEn?: string // 전문항목영문명
  type?: string // 전문유형
  bizFldMode?: string // 업무필드유형
  length?: number // 전문길이
  fldScale?: string // 필드크기
  position?: string // 전문위치
  defaultValue?: string // 기본값
  valSetDvsnCd?: string // 값설정구분코드
  // subDtoPath?: string // 서브DTO 경로
  // subDtoYn?: string // 서브DTO 여부
  description?: string // 전문설명
  format?: string // 전문항목형식
  requireYn?: string // 필수여부
  trimYn?: string // 트림여부
  relatedCode?: string // 연관코드
}

// 서브DTO 정보
export interface SubDto extends Base {
  crudType?: string // CRUD Type
  subDtoPath?: string // 서브DTO 경로
  instCd?: string // 기관코드
  sysDvsnCd?: string // 시스템구분코드
  description?: string // 설명
}

// 서브DTO 상세 정보
export interface SubDtoDetail extends Base {
  crudType?: string // CRUD Type
  subDtoPath?: string // 서브DTO 경로
  tgmRecTypeCd?: string // 구분
  tgmDtlSort?: string // 전문상세정렬
  depth?: number // depth
  dataType?: string // 데이터유형
  field?: string // 전문항목
  fieldEn?: string // 전문항목영문명
  length?: number // 전문길이
  cntField?: string // 카운터필드
  position?: string // 전문위치
  type?: string // 전문유형
  defaultValue?: string // 기본값
  description?: string // 전문설명
}

// 전문 변경이력 정보
export interface TelegramHist extends Base {
  tgmMgmtNo?: string // 전문관리번호
  tgmDtlSq?: string // 전문상세일련번호
  tgmChng?: string // 전문변경항목
  tgmChngSq?: string // 전문변경일련번호
  bfChngCtt?: string // 변경전내용
  afChngCtt?: string // 변경후내용
}

// 파일 정보
export interface File extends Base {
  crudType?: string // CRUD Type
  fileMgmtNo?: string // 파일관리번호
  instCd?: string // 기관코드
  linkSysDvsnCd?: string // 시스템구분코드
  fileBizCd?: string // 파일업무구분코드
  fileBizNm?: string // 파일업무구분명
  fileBizCtt?: string // 파일업무내용
  fileNo?: string // 파일구분번호
  filePrcsDtCd?: string // 파일처리일코드
  filePrcsDtNm?: string // 파일처리일명
  fileRecordSize?: string // 파일레코드길이
  fileBizDirection?: string // 파일업무진행방향
  useFl?: string // 사용여부
}

// 파일 상세 정보
export interface FileDetail extends Base {
  crudType?: string // CRUD Type
  fileMgmtNo?: string // 파일관리번호
  fileRecTypeCd?: string // 파일레코드유형코드
  fileDtlSq?: string // 파일상세일련번호
  field?: string // 항목
  fieldNm?: string // 항목명
  fieldEngNm?: string // 항목명(영문)
  length?: string // 길이
  type?: string // 유형
  scrtyFl?: string // 보안
  description?: string // 설명
}

// 파일 이력 정보
export interface FileHist extends Base {
  fileMgmtNo?: string // 파일관리번호
  fileRecTypeCd?: string // 파일레코드유형코드
  fileDtlSq?: string // 파일상세일련번호
  fileChng?: string // 파일변경항목
  fileChngSq?: string // 파일변경일련번호
  bfChngCtt?: string // 변경전내용
  afChngCtt?: string // 변경후내용
}

// 망상태관리 정보
export interface NetStatus extends Base {
  instCd?: string // 기관코드
  linkSysDvsnCd?: string // 시스템구분코드
  nwrkStsCd?: string // 망상태코드
  nwrkObstclCd?: string
  bnkNwrkStsCd?: string
  bnkNwrkObstclCd?: string
}

// MQ 송수신로그조회
export interface MQSendReceiveLog extends Base {
  trDt?: string // 거래일자
  tlgPrcsTm?: string // 처리시간
  mqSeq?: string // 로그순번
  mqId?: string // MQID
  mqTrNo?: string // MQ거래번호
  linkSysDvsnCd?: string // 연계구분코드
  sdrvDvsnCd?: string // 구분
  extrnlSdrvDvsnCd?: string // 대외송수신구분
  tlgKndDstnctnNo?: string // 전문종별코드
  tlgTrDstnctnNo?: string // 거래구분코드
  tlgDataDtlCntnt?: string // 전문데이터상세내용
}

// 휴일관리
export interface Holiday extends Base {
  baseDt?: string // 기준일자
  aplyStrtDt?: string // 적용시작일자
  aprvStsCd?: string // 승인상태코드
  holiDvsnCd?: string // 휴일구분코드
  holiNm?: string // 휴일명
  useYn?: string // 사용여부
  dayCd?: string // 요일코드
}

// 은행코드관리
export interface BankCode extends Base {
  // bnkCd?: string // 은행코드
  kftcBnkCd?: string // 대표은행코드
  bnkNm?: string // 은행명
  bnkEngNm?: string // 은행영문명
  iftYn?: string // 타행환참가기관여부
  hofYn?: string // 전자금융참가기관여부
  rprYn?: string // 자금청구반환참가기관여부
  hbkYn?: string // 거액이체참가기관여부
  cmsYn?: string // CMS참가기관여부
  entYn?: string // 전자어음참가기관여부
}

// 은행지점코드관리
export interface BankBranchCode extends Base {
  bnkCd?: string // 은행코드
  brnchCd1?: string // 지점코드1
  brnchCd2?: string // 지점코드1
  brnchStsCd?: string // 지점상태코드
  zipCd?: string // 우편번호
  addr?: string // 주소
  prmsryExCd?: string // 교환소코드
  brnchNm?: string // 지점명
  onlineCd?: string // 온라인코드
  areaCd?: string // 지역코드
  exprtnDt?: string // 해지일자
  subBrnchCd?: string // 자점코드
  rcptStsCd?: string // 수납상태코드
  telNo?: string // 전화번호
  faxNo?: string // 팩스번호
  emailAddr?: string // 이메일
  addrCd?: string // 주소코드
  trDt?: string // 처리일자
  trTm?: string // 처리시각
  fognExchBrnchCd?: string // 외국환지점코드
  clsMgmtBrnchCd?: string // 폐쇄관리지점코드
}

// 응답코드관리
export interface ResponseCode extends Base {
  hostCd?: string // 호스트코드
  bizDvsnCd?: string // 업무구분코드
  respCd?: string // 응답코드
  respCdNm?: string // 응답코드명
  respCdEngNm?: string // 응답코드영문명
  repRespYn?: string // 대표응답여부
  msgId?: string // 메세지id
  holdYn?: string // 대기여부
}

// 계좌정보관리
export interface AccountInfo extends Base {
  acctNo?: string // 계좌번호
  aprvStsCd?: string // 승인상태코드
  custNo?: string // 고객번호
  vrtlAcctNo?: string // 가상계좌번호
  acctNm?: string // 계좌명
  acctEngNm?: string // 계좌영문명
  acctStsCd?: string // 계좌상태코드
  trDt?: string // 거래일자
  custSbscrbDt?: string // 고객가입일자
  custTpCd?: string // 고객유형코드
  ctzBizNo?: string // 법인사업자번호
  opnDt?: string // 개설일자
  ddaCd?: string // DDA 코드
  rsdntYn?: string // 거주자여부
  remarks?: string // 비고
}

// 승인이력
export interface ApprovalHistory extends Base {
  aprvTpCd?: string // 승인유형코드
  aprvStsCd?: string // 승인상태코드
  makeId?: string // 승인요청자
  checkId?: string // 승인자
  aprvRqstDt?: string // 승인요청일자
  aprvRqstSeq?: string // 승인요청순번
  aprvKeyVal?: string // 승인키값
  aprvRqstDvsnCd?: string // 승인요청구분코드
  chngBfCtt?: string // 변경전내용
  chngAfCtt?: string // 변경후내용
  memo?: string // 메모
}

// 회원 정보
export interface Customer {
  custNbr?: string // 사업자(주민)등록번호
  prcsDscd?: string // 처리구분
  txDt?: string // 처리일자
  opnDt?: string // 신규일자
  trmntnDt?: string // 해지일자
  chngDt?: string // 변경일자
  custDscd?: string // 법인,개인구분
  rprsntvNm?: string // 성명(대표자명)
  cmpnyCorpnNm?: string // 법인명
  zipCd?: string // 우편번호
  stutDongAddrCntnt?: string // 주소1
  stutDongDtlAddr?: string // 주소2
  custTelNbr?: string // 전화번호
  mobileTelNbr?: string // 핸드폰번호
  emailAddr?: string // email주소
  nteItrchPlcCd?: string // 지급점포교환코드
  bnkCd?: string // 지급(등록의뢰)은행코드
  fnclInstBrnchCd?: string // 지급(등록의뢰)은행지점코드
  elctrncDflOwnAcctTxDt?: string // 전자어음 당좌거래 개시(해지)일자
  ownAcctNbr?: string // 당좌계좌번호
  cmpnyScaleCd?: string // 기업규모
  bizCtgryCd?: string // 업종코드
  lmtAmt?: string // 한도금액
  dpstAcctNbr?: string // 입금계좌번호
  mbrshpDscd?: string // 회원구분
  afChngOwnAcctNbr?: string // 변경 후 당좌 계좌번호
  afChngDpstAcctNbr?: string // 변경 후 입금 계좌번호
}

export interface EntSttlMgmtM extends Base {
  trStaDt?: string
  trEndDt?: string
  entNo?: string // 전자어음번호
  addRequSpltNo?: string // 추가 요청 분할 번호
  addRequEndtNo?: string // 추가 요청 보증인 번호
  entSndRcvDvsnCd?: string // 전자어음 송수신 구분 코드
  sttlSts?: string // 정산 상태
  pymntDt?: string // 지급 일자
  pymntNo?: string // 지급 번호
  sttlPrcsDvsn?: string // 정산 처리 구분
  entTp?: string // 전자어음 종류
  entIssueDt?: string // 전자어음 발행 일자
  entIssueAreaNm?: string // 전자어음 발행 지역명
  entAmt?: string // 전자어음 금액
  entMatDt?: string // 전자어음 만기 일자
  pymntBnkBrnchCd?: string // 지급 은행 지점 코드
  pymntExCd?: string // 지급 예외 코드
  issurCorpIndvDvsnCd?: string // 발행자 법인/개인 구분 코드
  issurCtzBizNoEnc?: string // 발행자 사업자번호 (암호화)
  issurCtzBizNo?: string // 발행자 사업자번호
  issurCorpNm?: string // 발행자 법인명
  issurRepNm?: string // 발행자 대표자명
  issurAddr?: string // 발행자 주소
  issurCurrAcctNo?: string // 발행자 지급 계좌번호
  rcpntCorpIndvDvsnCd?: string // 수령자 법인/개인 구분 코드
  rcpntCtzBizNoEnc?: string // 수령자 사업자번호 (암호화)
  rcpntCtzBizNo?: string // 수령자 사업자번호
  rcpntCorpNm?: string // 수령자 법인명
  rcpntRepNm?: string // 수령자 대표자명
  rcpntAddr?: string // 수령자 주소
  rcpntBnkCd?: string // 수령자 은행 코드
  rcpntDpstAcctNo?: string // 수령자 예치 계좌번호
  rcpntSpltEntAmt?: string // 수령자 분할 전자어음 금액
  rcpntSpltNo?: string // 수령자 분할 번호
  rcpntEndtNo?: string // 수령자 보증인 번호
  entStsCd?: string // 전자어음 상태 코드
  entMatSttlDttm?: string // 전자어음 만기 정산 일시
  dfltDt?: string // 디폴트 일자
  dfltRsnEntDfltRsn?: string // 디폴트 사유 전자어음 디폴트 사유
  acdntRptRsnCd?: string // 사고 보고 사유 코드
  dfltRsnStopPymntInjctCd?: string // 디폴트 사유 지급 정지 삽입 코드
  dfltRsnSpclDepoCrdt?: string // 디폴트 사유 특별 예치 신용
  dfltRsnCorpMgmtBnkYn?: string // 디폴트 사유 법인 관리 은행 여부
  dfltRsnRstrctTgtCmpnyYn?: string // 디폴트 사유 제약 대상 회사 여부
  dfltRsnDpstSrtRsn?: string // 디폴트 사유 예치 시작 사유
  dfltDpstDpstDttm?: string // 디폴트 예치 일시
  dfltDpstBnkBrnchCd?: string // 디폴트 예치 은행 지점 코드
  dfltRsnChgYn?: string // 디폴트 사유 변경 여부
  chgBfEntDfltRsn?: string // 변경 전 전자어음 디폴트 사유
  chgAfEntDfltRsn?: string // 변경 후 전자어음 디폴트 사유
  notiTgt?: string // 통지 대상
  rcrsDt?: string // 기록 일자
  rpymntObilgConfmDt?: string // 반환 지급 의무 확인 일자
  dpstDt?: string // 예치 일자
  rcrsAmt?: string // 기록 금액
  batBfPymntDt?: string // 배치 전 지급 일자
  payRsCd?: string // 지급 응답 코드
}

export interface EntEnoteL extends Base {
  trDt?: string
  trStaDt?: string
  trEndDt?: string
  entTlgTrceNo?: string
  trUnqNo?: string
  hostNo?: string
  entOutinDvsnCd?: string
  othrPartyBnkCd?: string
  sysDvsn?: string
  bnkCd?: string
  entTlgKndDvsnCd?: string
  entTlgTrDvsnCd?: string
  sndRcvDvsnCd?: string
  trSts?: string
  respCd1?: string
  respCd2?: string
  tlgTrDt?: string
  tlgSndTm?: string
  entStattcCd?: string
  trMemo?: string
  entNo?: string
  spltNo?: string
  endtNo?: string
  entTp?: string
  entIssueDt?: string
  entIssueAreaNm?: string
  entAmt?: string
  entMatDt?: string
  pymntBnkBrnchCd?: string
  issurCorpIndvDvsnCd?: string
  issurCtzBizNoEnc?: string
  issurCtzBizNo?: string
  issurCorpNm?: string
  issurRepNm?: string
  issurAddr?: string
  issurCurrAcctNo?: string
  beneCorpIndvDvsnCd?: string
  beneCtzBizNoEnc?: string
  beneCtzBizNo?: string
  beneCorpNm?: string
  beneRepNm?: string
  beneAddr?: string
  beneBnkCd?: string
  beneDpstAcctNo?: string
  prohbtInstrctYn?: string
  endtDvsnCd?: string
  endrsrCorpIndvDvsnCd?: string
  endrsrCtzBizNoEnc?: string
  endrsrCtzBizNo?: string
  endrsrCorpNm?: string
  endrsrRepNm?: string
  endrsrAddr?: string
  endrsrBnkCd?: string
  endrsrDpstAcctNo?: string
  endrCorpIndvDvsnCd?: string
  endrCtzBizNoEnc?: string
  endrCtzBizNo?: string
  endrCorpNm?: string
  endrRepNm?: string
  endrAddr?: string
  endrBnkCd?: string
  endrDpstAcctNo?: string
  addRequUnscsrEndtYn?: string
  addRequNonEndrEndtYn?: string
  addRequOrgnSpltNo?: string
  addRequOrgnEndtNo?: string
  addRequEndtAmt?: string
  notiTgt?: string
  grntDvsnCd?: string
  bfAfIssuDvsnCd?: string
  grntRqstDt?: string
  grntPrcsDt?: string
  grntPrcsDvsnCd?: string
  grntCorpIndvDvsnCd?: string
  grntCtzBizNoEnc?: string
  grntCtzBizNo?: string
  grntCorpNm?: string
  grntRepNm?: string
  grntAddr?: string
  grntBenefBnkCd?: string
  grntDpstAcctNo?: string
  grntNo?: string
  grntPrcsPartDvsnCd?: string
  rjctRqstDt?: string
  rjctDvsnCd?: string
  rjctRqstDvsnCd?: string
  acdntRptYn?: string
  acdntRptAcptCnclDttm?: string
  spltRmndPrcsDvsnCd?: string
  spltRmndSpltNo?: string
  spltRmndEndtNo?: string
  spltRmndAmt?: string
  spltEndtSpltNo?: string
  spltEndtEndtNo?: string
  spltEndtAmt?: string
  rcpntChgOldSpltNo?: string
  rcpntChgOldEndtNo?: string
  rcpntChgOldEntAmt?: string
  rcpntChgOldCorpIndvDvsnCd?: string
  rcpntChgOldCtzBizNoEnc?: string
  rcpntChgOldCtzBizNo?: string
  rcpntChgOldCorpNm?: string
  rcpntChgOldRepNm?: string
  rcpntChgOldAddr?: string
  rcpntChgOldDpstAcctNo?: string
  rcpntChgNewCorpIndvDvsnCd?: string
  rcpntChgNewCtzBizNoEnc?: string
  rcpntChgNewCtzBizNo?: string
  rcpntChgNewCorpNm?: string
  rcpntChgNewRepNm?: string
  rcpntChgNewAddr?: string
  rcpntChgNewDpstAcctNo?: string
  rcpntChgChgRsnCd?: string
  rcpntChgRqstBnkBrnchCd?: string
  rcpntChgChgRqstDt?: string
  rcpntChgNotiTgt?: string
  esignLen?: string
  esignData?: string
}

export interface EntMbrL extends Base {
  trDt?: string
  trStaDt?: string
  trEndDt?: string
  entTlgTrceNo?: string
  trUnqNo?: string
  hostNo?: string
  entOutinDvsnCd?: string
  othrPartyBnkCd?: string
  sysDvsn?: string
  bnkCd?: string
  entTlgKndDvsnCd?: string
  entTlgTrDvsnCd?: string
  sndRcvDvsnCd?: string
  trSts?: string
  respCd1?: string
  respCd2?: string
  tlgTrDt?: string
  tlgSndTm?: string
  kftcStattcCd?: string
  trMemo?: string
  srchCondSort?: string
  condCtzBizNoEnc?: string
  condBnkCd?: string
  conDpstAcctNo?: string
  ctzBizNoEnc?: string
  currAcctNo?: string
  dpstAcctNo?: string
  ctzBizNo?: string
  entPrcsDvsnCd?: string
  corpIndvDvsnCd?: string
  repNm?: string
  corpNm?: string
  mbrAddr?: string
  mbrTelNo?: string
  mbrMobileNo?: string
  mbrEmail?: string
  pymntExCd?: string
  pymntRqstRegBnkCd?: string
  pymntBnkBrnchCd?: string
  entCurrOpnDt?: string
  corpSizeCd?: string
  bizCd?: string
  lmtAmt?: string
  mbrDvsnCd?: string
  chgAfCurrAcctNo?: string
  chgAfDpstAcctNo?: string
}

export interface EntSttlMgmtL extends Base {
  trDt?: string
  trUnqNo?: string
  entTlgTrceNo?: string
  hostNo?: string
  entOutinDvsnCd?: string
  othrPartyBnkCd?: string
  sysDvsn?: string
  bnkCd?: string
  entTlgKndDvsnCd?: string
  entTlgTrDvsnCd?: string
  sndRcvDvsnCd?: string
  trSts?: string
  respCd1?: string
  respCd2?: string
  tlgTrDt?: string
  tlgSndTm?: string
  kftcStattcCd?: string
  entNo?: string
  addRequSpltNo?: string
  addRequEndtNo?: string
  entSndRcvDvsnCd?: string
  sttlSts?: string
  pymntDt?: string
  pymntNo?: string
  sttlPrcsDvsnCd?: string
  entTp?: string
  entIssueDt?: string
  entIssueAreaNm?: string
  entAmt?: number
  entMatDt?: string
  pymntBnkBrnchCd?: string
  pymntExCd?: string
  issurCorpIndvDvsnCd?: string
  issurCtzBizNoEnc?: string
  issurCtzBizNo?: string
  issurCorpNm?: string
  issurRepNm?: string
  issurAddr?: string
  issurCurrAcctNo?: string
  rcpntCorpIndvDvsnCd?: string
  rcpntCtzBizNoEnc?: string
  rcpntCtzBizNo?: string
  rcpntCorpNm?: string
  rcpntRepNm?: string
  rcpntAddr?: string
  rcpntBnkCd?: string
  rcpntDpstAcctNo?: string
  rcpntSpltEntAmt?: number
  rcpntSpltNo?: string
  rcpntEndtNo?: string
  entMatSttlDttm?: string
  dfltDt?: string
  dfltRsnEntDfltRsn?: string
  acdntRptRsnCd?: string
  dfltRsnStopPymntInjctCd?: string
  dfltRsnSpclDepoCrdtCd?: string
  dfltRsnCorpMgmtBnkYn?: boolean
  dfltRsnRstrctTgtCmpnyYn?: boolean
  dfltRsnDpstSrtRsnCd?: string
  dfltDpstDpstDttm?: string
  dfltDpstBnkBrnchCd?: string
  dfltRsnChgYn?: boolean
  chgBfEntDfltRsn?: string
  chgAfEntDfltRsn?: string
  notiTgt?: string
  batBfPymntDt?: string
  payRsCd?: string
}

export interface EntCqeInqyL extends Base {
  trStaDt?: string // 거래 시작 일자
  trEndDt?: string // 거래 종료 일자
  conEntNo?: string // 전자어음번호
  entTlgTrceNo?: string // 전문추적번호
  hostNo?: string // 호스트거래번호
  entOutinDvsnCd?: string // ENT_당타발구분(1:당발, 2:타발)
  othrPartyBnkCd?: string // 기타 파티 은행 코드
  sysDvsn?: string // 시스템 구분
  bnkCd?: string // 은행 코드
  entTlgKndDvsnCd?: string // 전자어음 종류 구분 코드
  entTlgTrDvsnCd?: string // 전자어음 거래 구분 코드
  sndRcvDvsnCd?: string // 송수신 구분 코드
  trSts?: string // 거래 상태
  respCd1?: string // 응답 코드1
  respCd2?: string // 응답 코드2
  tlgTrDt?: string // 전송 일자
  tlgSndTm?: string // 전문 전송 시각
  entStattcCd?: string // 전자어음 통계 코드
  trMemo?: string // 거래 메모
  srchCondSort?: string // 검색 조건 정렬
  condCtzBizNoEnc?: string // 조건 주민등록번호 암호화
  condBnkCd?: string // 조건 은행 코드
  conDpstAcctNo?: string // 조건 예금 계좌번호
  ctzBizNoEnc?: string // 주민등록번호 암호화
  currAcctNo?: string // 현재 계좌번호
  dpstAcctNo?: string // 예금 계좌번호
  ctzBizNo?: string // 주민등록번호
  entPrcsDvsnCd?: string // 전자어음 처리 구분
  corpIndvDvsnCd?: string // 법인/개인 구분 코드
  repNm?: string // 대표자 이름
  corpNm?: string // 법인 이름
  mbrAddr?: string // 멤버 주소
  mbrTelNo?: string // 멤버 전화번호
  mbrMobileNo?: string // 멤버 휴대전화번호
  mbrEmail?: string // 멤버 이메일
  pymntExCd?: string // 지급 예외 코드
  pymntRqstRegBnkCd?: string // 지급 요청 등록 은행 코드
  pymntBnkBrnchCd?: string // 지급 은행 지점 코드
  entCurrOpnDt?: string // 전자어음 개시 일자
  corpSizeCd?: string // 법인 규모
  bizCd?: string // 사업 코드
  lmtAmt?: string // 한도 금액
  mbrDvsnCd?: string // 멤버 구분 코드
  chgAfCurrAcctNo?: string // 변경 후 현재 계좌번호
  chgAfDpstAcctNo?: string // 변경 후 예금 계좌번호
}

export interface Member extends Base {
  ctzBizNoEnc?: string
  currAcctNo?: string
  dpstAcctNo?: string
  ctzBizNo?: string
  entPrcsDvsnCd?: string
  corpIndvDvsnCd?: string
  repNm?: string
  corpNm?: string
  mbrAddr?: string
  mbrTelNo?: string
  mbrMobileNo?: string
  mbrEmail?: string
  pymntExCd?: string
  pymntRqstRegBnkCd?: string
  pymntBnkBrnchCd?: string
  entCurrOpnDt?: string
  corpSizeCd?: string
  bizCd?: string
  lmtAmt?: number
  mbrDvsnCd?: string
  chgAfCurrAcctNo?: string
  chgAfDpstAcctNo?: string
  filler1?: string
  filler2?: string
  makeId?: string
  makeDttm?: string
  chkId?: string
  chkDttm?: string
  prcsYn?: string
  rejectMsg?: string
  rprHoldAlrtYn?: string
}

export interface EntPymntInstrctRqstL extends Base {
  recSts?: string
  trDt?: string
  pymntDt?: string
  pymntNo?: string
  aprvStsCd?: string
  sttlPrcsDvsn?: string
  entNo?: string
  entIssueDt?: string
  entAmt?: string
  entMatDt?: string
  pymntBnkBrnchCd?: string
  addRequSpltNo?: string
  addRequEndtNo?: string
  entMatSttlDttm?: string
  dfltDt?: string
  dfltRsnEntDfltRsn?: string
  acdntRptRsnCd?: string
  dfltRsnStopPymntInjctCd?: string
  dfltRsnSpclDepoCrdtCd?: string
  dfltRsnCorpMgmtBnkCd?: string
  dfltRsnRstrctTgtCmpnyCd?: string
  dfltRsnDpstSrtRsnCd?: string
  makeId?: string
  makeDttm?: string
  chkId?: string
  chkDttm?: string
}

// 전문 로그
export interface TelegramLog extends Base {
  trDt?: string // 거래일자
  tlgLogSeq?: string // 전문로그순번
  linkSysDvsnCd?: string // 연계시스템구분코드
  sdrvDvsnCd?: string // 송수신구분코드
  extrnlSdrvDstnctnCd?: string // 대외송수신구분코드
  extrnlInstErrCd?: string // 대외기관오류코드
  tlgKndDstnctnNo?: string // 전문종류식별번호
  tlgTrDstnctnNo?: string // 전문거래식별번호
  trUniqNo?: string // 거래고유번호
  hndlngBnkTlgNo?: string // 취급은행전문번호
  tlgPrcsTm?: string // 전문처리상세시각
  tlgDataDtlCntnt?: string // 전문데이터상세내용
}

// 출금이체 신청내역
export interface WithdrawalTransfer extends Base {
  trDt?: string // 거래일자
  sndRcvPrcsngDt?: string // 송수신일자
  fileNm?: string // 파일명
  pymntSeq?: string // 파일번호
  rspnsCd?: string // 응답코드
  sndRcvRspnsMsgCntnt?: string // 응답코드명
  refInstCd?: string // 기관코드
  refInstCdNm?: string // 기관코드명
  payerNm?: string // 납부자명
  payerNbr?: string // 납부자번호
  whdrwlAcctNbr?: string // 출금계좌번호
  custNm?: string // 출금예금주명
  aplctnAcptncChnlDscdNm?: string // 신청서 접수채널
  mobileTelNbr?: string // 핸드폰
}

// 거래내역 정보
export interface TransactionHist extends Base {
  trDt?: string // 거래일자
  tlgSdrvIntrnlTm?: string // 전문송수신당사시각
  linkSysDvsnCd?: string // 연계시스템구분코드
  sdrvDvsnCd?: string // 송수신구분코드
  tlgKndDstnctnNo?: string // 전문종류구분번호
  tlgTrDstnctnNo?: string // 전문거래구분코드
  trName?: string // 거래명
  trStatCd?: string // 거래상태구분코드
  extrnlInstErrCd?: string // 대외기관오류코드
  trUniqNo?: string // 거래고유번호
  hndlngBnkTlgNo?: string // 취급은행전문번호
  openBnkId?: string // 개설은행코드
  wthdAcctNo?: string // 출금계좌번호
  dpstAcctNo?: string // 입금계좌번호
  rcpntName?: string // 수취인명
  trAmt?: string // 거래금액
  fillerInfo1?: string // 예비정보1
}

// 자금청구반환내역
export interface ReturnFundsClaim extends Base {
  trDt?: string // 결제원거래일
  tlgSdrvIntrnlTm?: string // 결제원거래시간
  sdrvDvsnCd?: string // 구분
  tlgTrDstnctnNo?: string // 전문종별
  extrnlInstErrCd?: string // 응답코드
  trUniqNo?: string // 거래고유번호
  hndlngBnkTlgNo?: string // 전문추적번호
  openBnkId?: string // 상대은행코드
  jontNtwkKindCd?: string // 공통망코드
  orgnTrTrDvsnCd?: string // 원거래거래구분코드
  orgnTrDt?: string // 원거래일자
  orgnTrUniqNo?: string // 원거래고유번호
  orgnTrRCIVAcntNo?: string // 원거래수취계좌번호
  trAmt?: string // 거래금액
  clmRsonCd?: string // 청구사유코드
  aamtRstoYn?: string // 청구사유
  chrrCtcp?: string // 담당자연락처
  clmDt?: string // 청구일자
  clmTrUniqNo?: string // 청구거래고유번호
  rstoYn?: string // 반환여부
  rstoRjctRsonCd?: string // 반환거부사유코드
}

// 어플리케이션 구성 정보
export interface ApplicationConfig extends Base {
  environmentSymbol?: string // 환경심볼
  artifactId?: string // 어플리케이션 아티팩트 ID
  /** APP_INSTANCE_ID deprecated */
  // instanceId?: string // 인스턴스 ID
  name?: string // 어플리케이션 이름
  propertyMap?: string // 어플리케이션 속성맵
  baseApiPath?: string // 기본API경로
  useTimer?: string // 타이머사용여부
}

export interface LoadingConfig {
  disableLoading?: boolean
}

export interface ValidCondition {
  value: boolean // test 조건
  message: string // 에러메세지
}

export interface CpgSimRule {
  env?: string
  endpntId?: string
  inTgmMgmtNo?: string
  ruleOrder?: number | null
  useYn?: string
  outEndpntId?: string
  outTgmMgmtNo?: string
  transScript?: string
  inTgmFilter?: string
  outDataRef?: string
}

export type CpgSimRuleObj = Record<keyof CpgSimRule, undefined>

export interface CmnCodeMapping {
  instCd?: string
  cdGrpId?: string
  cdId?: string
  cdNm?: string
  cdEnm?: string
  mappedInstCd?: string
  mappedCdGrpId?: string
  mappedCdId?: string
  mappedCdNm?: string
  mappedCdEnm?: string
}

export interface AnyObject {
  [key: string]: any
}

export interface ComTlgLaytMapM {
  tlgLaytMapId: string
  tlgLaytMapNm: string
  trgtTlgLaytId: string
  sorcTlgLaytId: string
}

export interface ComTlgLaytMapD {
  crudType?: string
  tlgLaytMapId: string
  trgtTlgLaytId: string
  trgtTlgFld: string
  sorcTlgLaytId: string
  sorcTlgFld: string
  trgtTlgFldNm?: string
  trgtTlgDataTp?: string
  trgtTlgFldDpt?: number
  trgtTlgFldLen?: number
  sorcTlgFldNm?: string
  sorcTlgDataTp?: string
  sorcTlgFldDpt?: number
  sorcTlgFldLen?: number
}

export interface TelegramDetailTree extends TelegramDetail {
  children?: TelegramDetail[]
}

export interface TelegramMap {
  crudType?: string
  tlgLaytId: string
  fld: string
  fldNm?: string
  fldDpt?: number
  dataTp?: string
  fldLen?: number
  sorcTlgLaytId: string
  sorcTlgFld: string
  sorcTlgFldNm?: string
  sorcTlgFldDpt?: number
  sorcTlgDataTp?: string
  sorcTlgFldLen?: number
  aprvStsCd?: string
  fieldList?: any
}

export interface FrwMsg {
  logDt?: string
  logDttm: string
  svcGuid: string
  instnId: string
  appNm: string
  hostCd?: string
  bizDvsnCd: string
  tlgKndDvsnCd: string
  tlgBizDvsnCd: string
  tlgSndRcvDttm?: string
  respCd?: string
  hostMsgNo?: string
  msgTrckNo?: string
  trnsUnqNo?: string
  hndlInstCd?: string
  hndlMsgNo?: string
  kftcMsgNo?: string
  initInstCd?: string
  initMsgNo?: string
  tractSortCd?: string
  tractId?: string
  orgnTractId?: string
  frstTractId?: string
  usrId?: string
  crltnId: string
  exitCd?: number
  tlgCtt: string
  stckTrc: string
  tlgLaytId?: string
}

export interface ComRcvdUserGroup {
  grpId: string
  grpNm: string
  staffId: string
  staffNm: string
}

/** deprecated */
// export interface FrwSvcL {
//   logDttm: string
//   svcGuid: string
//   instnId: string
//   appNm: string
//   hostCd: string
//   bizDvsnCd: string
//   tlgKndDvsnCd: string
//   tlgBizDvsnCd: string
//   respCd: string
//   tlgCtt: string
//   stckTrc: string
// }

/** 업무 대시보드 */
export interface HoldSumItem {
  holdRsnCd?: string
  outCnt?: string
  inCnt?: string
  totCnt?: string
}

export interface TrSumItem {
  bizDvsnCd?: string
  outNormalCnt?: string
  outErrorCnt?: string
  outTotCnt?: string
  inNormalCnt?: string
  inErrorCnt?: string
  inTotCnt?: string
}

export interface DateItem {
  baseDt?: string
  dayCd?: string
  holiDvsnCd?: string
  holiNm?: string
}

export interface RoutingScheduleItem {
  baseDt?: string
  dayCd?: string
  staTm?: string
  endTm?: string
}

export interface NetStsItem {
  bizDvsnCd?: string
  jpmcStsCd?: string
  kftcStsCd?: string
}

export interface NetDebitCapStatus {
  currRatio?: number
  currAmt?: number
  totAmt?: number
}

export interface LongPendingStatus {
  outCnt?: string
  inCnt?: string
  totCnt?: string
}

export interface MqItem {
  queNm: string
  totDpth: string
  crntDpth: string
}

export interface MqDashboardItem {
  [bizCode: string]: {
    [key: string]: number
  }
}

export interface InstanceStatus {
  bizDvsnCd?: string
  active?: string
}

export interface TcpIpStatus {
  bizDvsnCd: string
  totalCount: string
  activeCount: string
}

export interface BizConnectivityItem {
  bizDvsnCd?: string
  hostMqCnt?: string
  hostCrntDepth?: string
  instanceStatus?: string
  kftcMqCnt?: string
  kftcCrntDepth?: string
  tcpIpCnt?: string
  tcpIpConnCnt?: string
}

export interface HofiTraxSum {
  outDepositNormalCnt: number
  outDepositNormalAmt: number
  outDepositErrorCnt: number
  outDepositErrorAmt: number
  outDepositProcessCnt: number
  outDepositProcessAmt: number
  outCancelNormalCnt: number
  outCancelNormalAmt: number
  outCancelErrorCnt: number
  outCancelErrorAmt: number
  outCancelProcessCnt: number
  outCancelProcessAmt: number
  inDepositNormalCnt: number
  inDepositNormalAmt: number
  inDepositErrorCnt: number
  inDepositErrorAmt: number
  inDepositProcessCnt: number
  inDepositProcessAmt: number
  inCancelNormalCnt: number
  inCancelNormalAmt: number
  inCancelErrorCnt: number
  inCancelErrorAmt: number
  inCancelProcessCnt: number
  inCancelProcessAmt: number
  outDepositTotCnt: number
  outDepositTotAmt: number
  outCancelTotCnt: number
  outCancelTotAmt: number
  inDepositTotCnt: number
  inDepositTotAmt: number
  inCancelTotCnt: number
  inCancelTotAmt: number
}

export interface ComFileTractL {
  baseDt?: string
  tractTm?: string
  fileNo?: string
  fileNm?: string
  fileSndRcvDvsnCd?: string
  tractId?: string
  tractNo?: string
  fileSize?: number
  delYn?: string
}

/** 업무 대시보드 */
