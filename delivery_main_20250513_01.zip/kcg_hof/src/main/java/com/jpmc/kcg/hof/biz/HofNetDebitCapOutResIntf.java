package com.jpmc.kcg.hof.biz;

import java.math.BigDecimal;
import java.time.format.DateTimeFormatter;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.jpmc.kcg.com.biz.BizCom;
import com.jpmc.kcg.com.biz.ComPshMsgBean;
import com.jpmc.kcg.com.constants.ComConst;
import com.jpmc.kcg.com.dao.ComCdDDao;
import com.jpmc.kcg.com.dao.ComCdDMapper;
import com.jpmc.kcg.com.dao.ComLcsMapper;
import com.jpmc.kcg.com.dto.ComCdD;
import com.jpmc.kcg.com.dto.ComLcs;
import com.jpmc.kcg.com.enums.BizDvsnCdEnum;
import com.jpmc.kcg.com.exception.InternalResponseException;
import com.jpmc.kcg.com.utils.DateFormat;
import com.jpmc.kcg.frw.FrwContext;
import com.jpmc.kcg.frw.FrwDestination;
import com.jpmc.kcg.frw.FrwServiceBean;
import com.jpmc.kcg.frw.FrwTemplate;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.hof.biz.vo.KcgHof0210010000;
import com.jpmc.kcg.hof.biz.vo.KftHof0210010000;
import com.jpmc.kcg.hof.biz.vo.KftHof0210010000.NetDebitCapInformation;
import com.jpmc.kcg.hof.dao.HofNetTrCapTlgMDao;
import com.jpmc.kcg.hof.dto.HofNetTrCapTlgM;
import com.jpmc.kcg.hof.enums.HofConst;
import com.jpmc.kcg.hof.enums.HofRespCdEnum;

import lombok.extern.slf4j.Slf4j;

/**
 * 2024.08.12 한성흔 순이체한도조회 당발응답 (0210/010000)
 */
@Slf4j
@Component
public class HofNetDebitCapOutResIntf extends FrwServiceBean<KftHof0210010000> {

	@Autowired
	private BizCom bizCom;
	@Autowired
	private FrwTemplate frwTemplate;
	@Autowired
	private FrwContext frwContext;
	@Autowired
	private HofNetTrCapTlgMDao hofNetTrCapTlgMDao;
	@Autowired
	private ComLcsMapper comLcsMapper;
	@Autowired
	private ComPshMsgBean comPshMsgBean;
	@Autowired
	private ComCdDMapper comCdDMapper;
	@Autowired
	private ComCdDDao comCdDDao;

	/**
	 * 전문 검증 및 제어
	 */
	@Override
	public boolean control(KftHof0210010000 in) {

		// 전문 format validation check
		if (in.validate() > 0) {
			String fieldNo = String.valueOf(in.validate());
			String errCd = StringUtils.leftPad(fieldNo, 3, ComConst.CHAR_0); // 000 ~ 필드번호가 응답코드로 리턴.

			throw new InternalResponseException(errCd);
		}

		return super.control(in);

	}

	/**
	 * 처리
	 */
	@Override
	public void process(KftHof0210010000 in) {
		if (log.isDebugEnabled()) {
			log.debug("process Input Value :::: {}", in);
		}

		// 요청거래 확인
		HofNetTrCapTlgM selectIn = new HofNetTrCapTlgM();
		selectIn.setTrDt(in.getMessageTransmissionDate().format(DateFormat.YYYYMMDD.getFormatter()));
		selectIn.setOutinDvsnCd(HofConst.OUTIN_DVSN_CD_01);
		selectIn.setTlgKndDvsnCd(in.getMessageType());
		selectIn.setTlgTrDvsnCd(in.getMessageCode());
		selectIn.setHndlBnkTlgTrNo(in.getMessageTrackingNumber()); // 전문key값

		List<HofNetTrCapTlgM> reqInfoList = hofNetTrCapTlgMDao.selectHofNetTrCapTlgM(selectIn);

		for (HofNetTrCapTlgM reqInfo : reqInfoList) {
			for (NetDebitCapInformation netDebitData : in.getNetDebitCapInformationArray()) {
				if (StringUtils.isNotEmpty(netDebitData.getLimtInformationInstitutionCode())
						&& reqInfo.getBnkCd().equals(netDebitData.getLimtInformationInstitutionCode())) {
					/*
					 * 2025.01.03 추가 응답코드 HOST응답코드로 맵핑
					 */
					String respCd = bizCom.getRespCdMap(ComConst.HST, BizDvsnCdEnum.HOF.getValue(),
							in.getResponseCode());
					in.setResponseCode(respCd);

					HofNetTrCapTlgM updateIn = new HofNetTrCapTlgM();
					// ---- update key값 ---- //
					updateIn.setTrDt(reqInfo.getTrDt());
					updateIn.setOutinDvsnCd(reqInfo.getOutinDvsnCd());
					updateIn.setHndlBnkTlgTrNo(reqInfo.getHndlBnkTlgTrNo());
					updateIn.setDataSeq(reqInfo.getDataSeq());

					// ---- update value 값 ---- //
					updateIn.setStatCd(in.getStatus());
					updateIn.setRespCd(in.getResponseCode());
					updateIn.setNetDebitLmtAmt(new BigDecimal(netDebitData.getCenterLimitAmount()));
					updateIn.setDebitLmtBalAmt(new BigDecimal(netDebitData.getNetDebitCapRemainedAmount()));
					updateIn.setDebitLmtUsageRt(netDebitData.getNetDebitCapLimtspentRate());
					updateIn.setMaxDebitAmt(new BigDecimal(netDebitData.getMaxNetDebitCapAmount()));
					updateIn.setMaxDebitTm(netDebitData.getMaxNetDebitCapOccurredDateTime());

					hofNetTrCapTlgMDao.updateHofNetTrCapTlgM(updateIn);

					if (ComConst.JPMC_BANK_CD.equals(netDebitData.getLimtInformationInstitutionCode())
							&& StringUtils.isNotEmpty(in.getResponseCode())
							&& HofRespCdEnum.RESP_CD_000.getCode().equals(in.getResponseCode())) { // jpmc결과인 경우, com_lcs테이블에 입력해준다.
						ComLcs lcsIn = new ComLcs();
						lcsIn.setTrDt(reqInfo.getTrDt());
						lcsIn.setLcsLitAmt(new BigDecimal(netDebitData.getCenterLimitAmount()));
						lcsIn.setLcsCurAmt(new BigDecimal(
								netDebitData.getCenterLimitAmount() - netDebitData.getNetDebitCapRemainedAmount()));
						lcsIn.setLcsRatio(netDebitData.getNetDebitCapLimtspentRate());
						comLcsMapper.insert(lcsIn);
					}
				}
			}

		}

		if (ComConst.CHAR_01.equals(reqInfoList.get(0).getInqryDvsnCd())) {
			KcgHof0210010000 kcgIn = VOUtils.toVo(frwContext.getTlgCtt(), KcgHof0210010000.class);
			frwTemplate.send(FrwDestination.KCG_HOF, kcgIn);
		}

		try {
			
			//5분마다 당일 한도금액 update
			ComCdD limit = comCdDMapper.selectByPrimaryKey(ComConst.NET_AMT_CD, ComConst.CHAR_01);
			
			//관리금액(SubCdNum2)보다 크거나 같고 & 센터한도금액이 0보다 크면 update
			if (in.getNetDebitCapInformationArray().get(0).getCenterLimitAmount() > 0 
					&& limit.getSubCdNum2().compareTo(new BigDecimal(in.getNetDebitCapInformationArray().get(0).getCenterLimitAmount())) <= 0) {
				// UPDATE
				ComCdD update = new ComCdD(); 
				update.setCdGrpId(limit.getCdGrpId());
				update.setCdId(limit.getCdId());
				update.setAprvStsCd(ComConst.CHAR_02); // 승인
				update.setSubCdChar1(String.valueOf(in.getNetDebitCapInformationArray().get(0).getCenterLimitAmount()));

				comCdDDao.updateComCdD(update);
			}else {
				//관리금액(CHAR2)보다 작을 경우 Alarm
				Map<String, Object> errorValList = new Hashtable<>();
				// 에러 메시지 문자열 생성
				String errorMessage = String.format("[I N F O] Received Net Debit Cap Amount [%s] is lower then Net Debit Cap common code amount [%s]\n",
						in.getNetDebitCapInformationArray().get(0).getCenterLimitAmount(), limit.getSubCdChar2());
				errorValList.put("errTlgId", HofConst.NET_DEBIT_CAPS_CODE);
				errorValList.put("errCtt", errorMessage);
				comPshMsgBean.sendAlarm(8, errorValList.get("errTlgId").toString(), errorValList, null, true);
			}
			
			// 순이체한도율이 88%이상이면 autoYN -> Y / autoYN -> N
			ComCdD auto = comCdDMapper.selectByPrimaryKey(ComConst.NET_AMT_CD, ComConst.CHAR_02);
			if (new BigDecimal(auto.getSubCdChar2()).compareTo(in.getNetDebitCapInformationArray().get(0).getNetDebitCapLimtspentRate()) <= 0) {
				// UPDATE
				ComCdD update = new ComCdD();
				update.setCdGrpId(auto.getCdGrpId());
				update.setCdId(auto.getCdId());
				update.setAprvStsCd(ComConst.CHAR_02); // 승인
				update.setSubCdChar1(ComConst.Y);  

				comCdDDao.updateComCdD(update);
			}else {
				// UPDATE
				ComCdD update = new ComCdD();
				update.setCdGrpId(auto.getCdGrpId());
				update.setCdId(auto.getCdId());
				update.setAprvStsCd(ComConst.CHAR_02); // 승인
				update.setSubCdChar1(ComConst.N);  

				comCdDDao.updateComCdD(update);
				
			}

			// 순이체한도소진율이 50% 초과의 경우 알람
			if (limit.getSubCdNum1()
					.compareTo(in.getNetDebitCapInformationArray().get(0).getNetDebitCapLimtspentRate()) < 0) {
				Map<String, Object> errorValList = new Hashtable<>();
				// 에러 메시지 문자열 생성
				String errorMessage = String.format("[I N F O] NET DEBIT CAPS [PERCENT=%s]\n",
						in.getNetDebitCapInformationArray().get(0).getNetDebitCapLimtspentRate());
				errorValList.put("errTlgId", HofConst.KCG_ALERT_NET_DEBIT_CAPS);
				errorValList.put("errCtt", errorMessage);
				comPshMsgBean.sendAlarm(8, errorValList.get("errTlgId").toString(), errorValList, null, true);

			}
		} catch (Exception e2) {
			log.error("Message Request Fail", e2);
		}

	}

	/**
	 * 예외
	 */
	@Override
	public void handleError(KftHof0210010000 in, Throwable t) {
		String respCd;
		if (t instanceof InternalResponseException e) {
			respCd = e.getRespCd();
		} else {
			respCd = HofRespCdEnum.RESP_CD_413.getCode();
			log.info(t.getStackTrace().toString());
		}

		// field값 에러인 경우 전문종별 : 9210으로 전송한다.
		if (respCd.startsWith(ComConst.CHAR_0)) {
			in.setMessageType(HofConst.TLG_KND_DVSN_NO_9210);
			in.setStatus(respCd);
			frwTemplate.send(FrwDestination.KFT_HOF, in);
		}

		return;

		// super.handleError(in, t);
	}

}
