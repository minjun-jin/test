package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * HBK 거액타행이체거래집계
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER 3(HDR) + 실전문 길이
 * systemId 시스템-ID “ELB”
 * messageType 전문종별코드 전문의 기능을 나타내는 코드
 * messageCode 거래구분코드 각 거래의 종류를 구분하여주는 코드
 * sendReceiveFlag 송수신FLAG 1:요구 2:지시  3:보고 4:통보 5:통보(지연 또는 재요구 응답)
 * status STATUS FORMAT ERROR 발생(9XXX)시 해당 FIELD의 위치값
 * responseCode 응답코드 전문의 처리결과
 * messageTransmissionDate 전문전송일 YYYYMMDD
 * messageSendTime 전문전송시간 HHMMSS
 * messageTrackingNumber 전문추적번호 응답전문에 반드시 동일한 번호를 SET
 * traxOccurredDate 거래발생일 YYYYMMDD
 * institutionCode 기관코드 대표기관코드
 * creditTransactionCount 대변거래건수 대변거래 총 건수(취소건수 포함한 정상거래 건수)
 * creditCancelTransactionCount 대변거래취소건수 대변 취소거래 총 건수(정상거래중 정상취소건수)
 * debitTransactionCount 차변거래건수 차변거래 총 건수(취소건수 포함한 정상거래 건수)
 * debitCancelTransactionCount 차변거래취소건수 차변 취소거래 총 건수(정상거래중 정상취소건수)
 * creditTransactionAmount 대변거래금액 대변거래 총 금액(취소건수 포함한 정상거래 금액)
 * creditCancelTransactionAmount 대변거래취소금액 대변 취소거래 총 금액(정상거래중 정상취소금액)
 * debitTransactionAmount 차변거래금액 차변거래 총 금액(취소건수 포함한 정상거래 금액)
 * debitCancelTransactionAmount 차변거래취소금액 차변 취소거래 총 금액(정상거래중 정상취소금액)
 * prefixNetSettlementAmount prefix순수결제금액 순수결제금액 17 BYTE중 첫번째 BYTE는 SIGN(C 혹은 D)을 SET
 * netSettlementAmount 순수결제금액 
 * filler FILLER 
 * 
 * KftHof0710450000 kftHof0710450000 = new KftHof0710450000(); // HBK 거액타행이체거래집계
 * kftHof0710450000.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kftHof0710450000.setSystemId("ELB"); // 시스템-ID
 * kftHof0710450000.setMessageType("0710"); // 전문종별코드
 * kftHof0710450000.setMessageCode("450000"); // 거래구분코드
 * kftHof0710450000.setSendReceiveFlag("3"); // 송수신FLAG
 * kftHof0710450000.setStatus("000"); // STATUS
 * kftHof0710450000.setResponseCode(""); // 응답코드
 * kftHof0710450000.setMessageTransmissionDate(LocalDate.now()); // 전문전송일
 * kftHof0710450000.setMessageSendTime(LocalTime.now()); // 전문전송시간
 * kftHof0710450000.setMessageTrackingNumber("00000000"); // 전문추적번호
 * kftHof0710450000.setTraxOccurredDate(LocalDate.now()); // 거래발생일
 * kftHof0710450000.setInstitutionCode("000"); // 기관코드
 * kftHof0710450000.setCreditTransactionCount(0L); // 대변거래건수
 * kftHof0710450000.setCreditCancelTransactionCount(0L); // 대변거래취소건수
 * kftHof0710450000.setDebitTransactionCount(0L); // 차변거래건수
 * kftHof0710450000.setDebitCancelTransactionCount(0L); // 차변거래취소건수
 * kftHof0710450000.setCreditTransactionAmount(0L); // 대변거래금액
 * kftHof0710450000.setCreditCancelTransactionAmount(0L); // 대변거래취소금액
 * kftHof0710450000.setDebitTransactionAmount(0L); // 차변거래금액
 * kftHof0710450000.setDebitCancelTransactionAmount(0L); // 차변거래취소금액
 * kftHof0710450000.setPrefixNetSettlementAmount(""); // prefix순수결제금액
 * kftHof0710450000.setNetSettlementAmount(0L); // 순수결제금액
 * kftHof0710450000.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHof0710450000 implements KftHofMngHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "ELB"; // 시스템-ID
	private String messageType = "0710"; // 전문종별코드
	private String messageCode = "450000"; // 거래구분코드
	private String sendReceiveFlag = "3"; // 송수신FLAG
	private String status = "000"; // STATUS
	private String responseCode; // 응답코드
	private LocalDate messageTransmissionDate; // 전문전송일
	private LocalTime messageSendTime; // 전문전송시간
	private String messageTrackingNumber = "00000000"; // 전문추적번호
	private LocalDate traxOccurredDate; // 거래발생일
	private String institutionCode = "000"; // 기관코드
	private long creditTransactionCount; // 대변거래건수
	private long creditCancelTransactionCount; // 대변거래취소건수
	private long debitTransactionCount; // 차변거래건수
	private long debitCancelTransactionCount; // 차변거래취소건수
	private long creditTransactionAmount; // 대변거래금액
	private long creditCancelTransactionAmount; // 대변거래취소금액
	private long debitTransactionAmount; // 차변거래금액
	private long debitCancelTransactionAmount; // 차변거래취소금액
	private String prefixNetSettlementAmount; // prefix순수결제금액
	private long netSettlementAmount; // 순수결제금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 거래구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String status$; // STATUS
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTransmissionDate$; // 전문전송일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageSendTime$; // 전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageTrackingNumber$; // 전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String traxOccurredDate$; // 거래발생일
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionCount$; // 대변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelTransactionCount$; // 대변거래취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionCount$; // 차변거래건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelTransactionCount$; // 차변거래취소건수
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditTransactionAmount$; // 대변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String creditCancelTransactionAmount$; // 대변거래취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitTransactionAmount$; // 차변거래금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCancelTransactionAmount$; // 차변거래취소금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prefixNetSettlementAmount$; // prefix순수결제금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String netSettlementAmount$; // 순수결제금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(systemId$)) { // 시스템-ID
			return 1;
		}
		if (VOUtils.isWhitespace(messageType$)) { // 전문종별코드
			return 2;
		}
		if (VOUtils.isWhitespace(messageCode$)) { // 거래구분코드
			return 3;
		}
		if (VOUtils.isWhitespace(sendReceiveFlag$)) { // 송수신FLAG
			return 4;
		}
		if (VOUtils.isWhitespace(status$)) { // STATUS
			return 5;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isWhitespace(messageTransmissionDate$)) { // 전문전송일
			return 7;
		}
		if (VOUtils.isWhitespace(messageSendTime$)) { // 전문전송시간
			return 8;
		}
		if (VOUtils.isWhitespace(messageTrackingNumber$)) { // 전문추적번호
			return 9;
		}
		if (VOUtils.isWhitespace(traxOccurredDate$)) { // 거래발생일
			return 10;
		}
		if (VOUtils.isNotAlphanumericSpace(prefixNetSettlementAmount$)) { // prefix순수결제금액
			return 20;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 3); // 시스템-ID
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별코드
		messageCode$ = VOUtils.write(out, messageCode, 6); // 거래구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		status$ = VOUtils.write(out, status, 3); // STATUS
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		messageTransmissionDate$ = VOUtils.write(out, messageTransmissionDate, 8, "yyyyMMdd"); // 전문전송일
		messageSendTime$ = VOUtils.write(out, messageSendTime, 6, "HHmmss"); // 전문전송시간
		messageTrackingNumber$ = VOUtils.write(out, messageTrackingNumber, 8); // 전문추적번호
		traxOccurredDate$ = VOUtils.write(out, traxOccurredDate, 8, "yyyyMMdd"); // 거래발생일
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		creditTransactionCount$ = VOUtils.write(out, creditTransactionCount, 10); // 대변거래건수
		creditCancelTransactionCount$ = VOUtils.write(out, creditCancelTransactionCount, 10); // 대변거래취소건수
		debitTransactionCount$ = VOUtils.write(out, debitTransactionCount, 10); // 차변거래건수
		debitCancelTransactionCount$ = VOUtils.write(out, debitCancelTransactionCount, 10); // 차변거래취소건수
		creditTransactionAmount$ = VOUtils.write(out, creditTransactionAmount, 16); // 대변거래금액
		creditCancelTransactionAmount$ = VOUtils.write(out, creditCancelTransactionAmount, 16); // 대변거래취소금액
		debitTransactionAmount$ = VOUtils.write(out, debitTransactionAmount, 16); // 차변거래금액
		debitCancelTransactionAmount$ = VOUtils.write(out, debitCancelTransactionAmount, 16); // 차변거래취소금액
		prefixNetSettlementAmount$ = VOUtils.write(out, prefixNetSettlementAmount, 1); // prefix순수결제금액
		netSettlementAmount$ = VOUtils.write(out, netSettlementAmount, 16); // 순수결제금액
		filler$ = VOUtils.write(out, filler, 26); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 3)); // 시스템-ID
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 6)); // 거래구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		status = VOUtils.toString(status$ = VOUtils.read(in, 3)); // STATUS
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		messageTransmissionDate = VOUtils.toLocalDate(messageTransmissionDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 전문전송일
		messageSendTime = VOUtils.toLocalTime(messageSendTime$ = VOUtils.read(in, 6), "HHmmss"); // 전문전송시간
		messageTrackingNumber = VOUtils.toString(messageTrackingNumber$ = VOUtils.read(in, 8)); // 전문추적번호
		traxOccurredDate = VOUtils.toLocalDate(traxOccurredDate$ = VOUtils.read(in, 8), "yyyyMMdd"); // 거래발생일
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		creditTransactionCount = VOUtils.toLong(creditTransactionCount$ = VOUtils.read(in, 10)); // 대변거래건수
		creditCancelTransactionCount = VOUtils.toLong(creditCancelTransactionCount$ = VOUtils.read(in, 10)); // 대변거래취소건수
		debitTransactionCount = VOUtils.toLong(debitTransactionCount$ = VOUtils.read(in, 10)); // 차변거래건수
		debitCancelTransactionCount = VOUtils.toLong(debitCancelTransactionCount$ = VOUtils.read(in, 10)); // 차변거래취소건수
		creditTransactionAmount = VOUtils.toLong(creditTransactionAmount$ = VOUtils.read(in, 16)); // 대변거래금액
		creditCancelTransactionAmount = VOUtils.toLong(creditCancelTransactionAmount$ = VOUtils.read(in, 16)); // 대변거래취소금액
		debitTransactionAmount = VOUtils.toLong(debitTransactionAmount$ = VOUtils.read(in, 16)); // 차변거래금액
		debitCancelTransactionAmount = VOUtils.toLong(debitCancelTransactionAmount$ = VOUtils.read(in, 16)); // 차변거래취소금액
		prefixNetSettlementAmount = VOUtils.toString(prefixNetSettlementAmount$ = VOUtils.read(in, 1)); // prefix순수결제금액
		netSettlementAmount = VOUtils.toLong(netSettlementAmount$ = VOUtils.read(in, 16)); // 순수결제금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 26)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 거래구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", status=").append(status).append(System.lineSeparator()); // STATUS
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", messageTransmissionDate=").append(messageTransmissionDate).append(System.lineSeparator()); // 전문전송일
		sb.append(", messageSendTime=").append(messageSendTime).append(System.lineSeparator()); // 전문전송시간
		sb.append(", messageTrackingNumber=").append(messageTrackingNumber).append(System.lineSeparator()); // 전문추적번호
		sb.append(", traxOccurredDate=").append(traxOccurredDate).append(System.lineSeparator()); // 거래발생일
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", creditTransactionCount=").append(creditTransactionCount).append(System.lineSeparator()); // 대변거래건수
		sb.append(", creditCancelTransactionCount=").append(creditCancelTransactionCount).append(System.lineSeparator()); // 대변거래취소건수
		sb.append(", debitTransactionCount=").append(debitTransactionCount).append(System.lineSeparator()); // 차변거래건수
		sb.append(", debitCancelTransactionCount=").append(debitCancelTransactionCount).append(System.lineSeparator()); // 차변거래취소건수
		sb.append(", creditTransactionAmount=").append(creditTransactionAmount).append(System.lineSeparator()); // 대변거래금액
		sb.append(", creditCancelTransactionAmount=").append(creditCancelTransactionAmount).append(System.lineSeparator()); // 대변거래취소금액
		sb.append(", debitTransactionAmount=").append(debitTransactionAmount).append(System.lineSeparator()); // 차변거래금액
		sb.append(", debitCancelTransactionAmount=").append(debitCancelTransactionAmount).append(System.lineSeparator()); // 차변거래취소금액
		sb.append(", prefixNetSettlementAmount=").append(prefixNetSettlementAmount).append(System.lineSeparator()); // prefix순수결제금액
		sb.append(", netSettlementAmount=").append(netSettlementAmount).append(System.lineSeparator()); // 순수결제금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "3", "defltVal", "ELB"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0710"),
			Map.of("fld", "messageCode", "fldLen", "6", "defltVal", "450000"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "3"),
			Map.of("fld", "status", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "messageTransmissionDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "messageSendTime", "fldLen", "6", "defltVal", "$hhmiss"),
			Map.of("fld", "messageTrackingNumber", "fldLen", "8", "defltVal", "00000000"),
			Map.of("fld", "traxOccurredDate", "fldLen", "8", "defltVal", "$yyyymmdd"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "creditTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditCancelTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "debitCancelTransactionCount", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "creditTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "creditCancelTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "debitCancelTransactionAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prefixNetSettlementAmount", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "netSettlementAmount", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "26", "defltVal", "")
		);
	}

}
