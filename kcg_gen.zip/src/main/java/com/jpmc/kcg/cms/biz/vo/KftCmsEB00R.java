package com.jpmc.kcg.cms.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 자금결제내역
 * <pre>{@code
 * KftCmsEB00R kftCmsEB00R  = new KftCmsEB00R(); // 자금결제내역
 * kftCmsEB00R.setRecordType(""); // Record 구분
 * kftCmsEB00R.setDataSerialNumber(""); // Data 일련번호
 * kftCmsEB00R.setInstitutionCode(""); // 기관코드
 * kftCmsEB00R.setSettlementOrderTypeCode(""); // 결제지시서 구분코드
 * kftCmsEB00R.setDepositDetailsAmount(0L); // 입금내역 입금액
 * kftCmsEB00R.setDepositDetailsFee(0L); // 입금내역 수수료
 * kftCmsEB00R.setDepositDetailsFailed(0L); // 입금내역 부도금액 또는 입금불능액
 * kftCmsEB00R.setDepositDetailsTotalAmount(0L); // 입금내역 총입금액
 * kftCmsEB00R.setWithdrawalDetailsAmount(0L); // 출금내역 출금액
 * kftCmsEB00R.setWithdrawalDetailsFee(0L); // 출금내역 수수료
 * kftCmsEB00R.setWithdrawalDetailsFailed(0L); // 출금내역 부도금액 또는 출금불능액
 * kftCmsEB00R.setWithdrawalDetailsTotalAmount(0L); // 출금내역 총출금액
 * kftCmsEB00R.setBalSttlDtlsSettlementType(""); // 차액결제내역 결제구분
 * kftCmsEB00R.setBalSttlDtlsSettlementAmount(0L); // 차액결제내역 결제금액
 * kftCmsEB00R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftCmsEB00R implements Vo {

	private String recordType; // Record 구분
	private String dataSerialNumber; // Data 일련번호
	private String institutionCode; // 기관코드
	private String settlementOrderTypeCode; // 결제지시서 구분코드
	private long depositDetailsAmount; // 입금내역 입금액
	private long depositDetailsFee; // 입금내역 수수료
	private long depositDetailsFailed; // 입금내역 부도금액 또는 입금불능액
	private long depositDetailsTotalAmount; // 입금내역 총입금액
	private long withdrawalDetailsAmount; // 출금내역 출금액
	private long withdrawalDetailsFee; // 출금내역 수수료
	private long withdrawalDetailsFailed; // 출금내역 부도금액 또는 출금불능액
	private long withdrawalDetailsTotalAmount; // 출금내역 총출금액
	private String balSttlDtlsSettlementType; // 차액결제내역 결제구분
	private long balSttlDtlsSettlementAmount; // 차액결제내역 결제금액
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String recordType$; // Record 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataSerialNumber$; // Data 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String settlementOrderTypeCode$; // 결제지시서 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositDetailsAmount$; // 입금내역 입금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositDetailsFee$; // 입금내역 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositDetailsFailed$; // 입금내역 부도금액 또는 입금불능액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String depositDetailsTotalAmount$; // 입금내역 총입금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalDetailsAmount$; // 출금내역 출금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalDetailsFee$; // 출금내역 수수료
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalDetailsFailed$; // 출금내역 부도금액 또는 출금불능액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String withdrawalDetailsTotalAmount$; // 출금내역 총출금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String balSttlDtlsSettlementType$; // 차액결제내역 결제구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String balSttlDtlsSettlementAmount$; // 차액결제내역 결제금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		recordType$ = VOUtils.write(out, recordType, 1); // Record 구분
		dataSerialNumber$ = VOUtils.write(out, dataSerialNumber, 8); // Data 일련번호
		institutionCode$ = VOUtils.write(out, institutionCode, 10); // 기관코드
		settlementOrderTypeCode$ = VOUtils.write(out, settlementOrderTypeCode, 4); // 결제지시서 구분코드
		depositDetailsAmount$ = VOUtils.write(out, depositDetailsAmount, 15); // 입금내역 입금액
		depositDetailsFee$ = VOUtils.write(out, depositDetailsFee, 11); // 입금내역 수수료
		depositDetailsFailed$ = VOUtils.write(out, depositDetailsFailed, 15); // 입금내역 부도금액 또는 입금불능액
		depositDetailsTotalAmount$ = VOUtils.write(out, depositDetailsTotalAmount, 15); // 입금내역 총입금액
		withdrawalDetailsAmount$ = VOUtils.write(out, withdrawalDetailsAmount, 15); // 출금내역 출금액
		withdrawalDetailsFee$ = VOUtils.write(out, withdrawalDetailsFee, 11); // 출금내역 수수료
		withdrawalDetailsFailed$ = VOUtils.write(out, withdrawalDetailsFailed, 15); // 출금내역 부도금액 또는 출금불능액
		withdrawalDetailsTotalAmount$ = VOUtils.write(out, withdrawalDetailsTotalAmount, 15); // 출금내역 총출금액
		balSttlDtlsSettlementType$ = VOUtils.write(out, balSttlDtlsSettlementType, 1); // 차액결제내역 결제구분
		balSttlDtlsSettlementAmount$ = VOUtils.write(out, balSttlDtlsSettlementAmount, 15); // 차액결제내역 결제금액
		filler2$ = VOUtils.write(out, filler2, 9); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		recordType = VOUtils.toString(recordType$ = VOUtils.read(in, 1)); // Record 구분
		dataSerialNumber = VOUtils.toString(dataSerialNumber$ = VOUtils.read(in, 8)); // Data 일련번호
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 10)); // 기관코드
		settlementOrderTypeCode = VOUtils.toString(settlementOrderTypeCode$ = VOUtils.read(in, 4)); // 결제지시서 구분코드
		depositDetailsAmount = VOUtils.toLong(depositDetailsAmount$ = VOUtils.read(in, 15)); // 입금내역 입금액
		depositDetailsFee = VOUtils.toLong(depositDetailsFee$ = VOUtils.read(in, 11)); // 입금내역 수수료
		depositDetailsFailed = VOUtils.toLong(depositDetailsFailed$ = VOUtils.read(in, 15)); // 입금내역 부도금액 또는 입금불능액
		depositDetailsTotalAmount = VOUtils.toLong(depositDetailsTotalAmount$ = VOUtils.read(in, 15)); // 입금내역 총입금액
		withdrawalDetailsAmount = VOUtils.toLong(withdrawalDetailsAmount$ = VOUtils.read(in, 15)); // 출금내역 출금액
		withdrawalDetailsFee = VOUtils.toLong(withdrawalDetailsFee$ = VOUtils.read(in, 11)); // 출금내역 수수료
		withdrawalDetailsFailed = VOUtils.toLong(withdrawalDetailsFailed$ = VOUtils.read(in, 15)); // 출금내역 부도금액 또는 출금불능액
		withdrawalDetailsTotalAmount = VOUtils.toLong(withdrawalDetailsTotalAmount$ = VOUtils.read(in, 15)); // 출금내역 총출금액
		balSttlDtlsSettlementType = VOUtils.toString(balSttlDtlsSettlementType$ = VOUtils.read(in, 1)); // 차액결제내역 결제구분
		balSttlDtlsSettlementAmount = VOUtils.toLong(balSttlDtlsSettlementAmount$ = VOUtils.read(in, 15)); // 차액결제내역 결제금액
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 9)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", recordType=").append(recordType).append(System.lineSeparator()); // Record 구분
		sb.append(", dataSerialNumber=").append(dataSerialNumber).append(System.lineSeparator()); // Data 일련번호
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", settlementOrderTypeCode=").append(settlementOrderTypeCode).append(System.lineSeparator()); // 결제지시서 구분코드
		sb.append(", depositDetailsAmount=").append(depositDetailsAmount).append(System.lineSeparator()); // 입금내역 입금액
		sb.append(", depositDetailsFee=").append(depositDetailsFee).append(System.lineSeparator()); // 입금내역 수수료
		sb.append(", depositDetailsFailed=").append(depositDetailsFailed).append(System.lineSeparator()); // 입금내역 부도금액 또는 입금불능액
		sb.append(", depositDetailsTotalAmount=").append(depositDetailsTotalAmount).append(System.lineSeparator()); // 입금내역 총입금액
		sb.append(", withdrawalDetailsAmount=").append(withdrawalDetailsAmount).append(System.lineSeparator()); // 출금내역 출금액
		sb.append(", withdrawalDetailsFee=").append(withdrawalDetailsFee).append(System.lineSeparator()); // 출금내역 수수료
		sb.append(", withdrawalDetailsFailed=").append(withdrawalDetailsFailed).append(System.lineSeparator()); // 출금내역 부도금액 또는 출금불능액
		sb.append(", withdrawalDetailsTotalAmount=").append(withdrawalDetailsTotalAmount).append(System.lineSeparator()); // 출금내역 총출금액
		sb.append(", balSttlDtlsSettlementType=").append(balSttlDtlsSettlementType).append(System.lineSeparator()); // 차액결제내역 결제구분
		sb.append(", balSttlDtlsSettlementAmount=").append(balSttlDtlsSettlementAmount).append(System.lineSeparator()); // 차액결제내역 결제금액
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "recordType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "dataSerialNumber", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "institutionCode", "fldLen", "10", "defltVal", ""),
			Map.of("fld", "settlementOrderTypeCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "depositDetailsAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositDetailsFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "depositDetailsFailed", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "depositDetailsTotalAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "withdrawalDetailsAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "withdrawalDetailsFee", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "withdrawalDetailsFailed", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "withdrawalDetailsTotalAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "balSttlDtlsSettlementType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "balSttlDtlsSettlementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "9", "defltVal", "")
		);
	}

}
