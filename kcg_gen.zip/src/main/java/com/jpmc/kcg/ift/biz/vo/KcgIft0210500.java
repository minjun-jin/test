package com.jpmc.kcg.ift.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 수취조회
 * <pre>{@code
 * tcpIpHeader TCP/IP HEADER TCP / IP HEADER
 * systemId 시스템-ID 타 시스템(CD,ARS)과의 구분을 위한 코드
 * institutionCode 기관코드 전문 ROUTING에 필요한 코드로 금융기관 공동코드를 사용
 * messageType 전문종별구분코드 해당전문의 거래별 MESSAGE 구분코드
 * messageCode 업무구분코드 업무별 거래유형 구분코드
 * sendReceiveFlag 송수신FLAG 기관간 전문송수신 상태를 나타내는 FLAG 1 참가기관센터에서 요구전문을 중계센터로 송신할 때 SET 2 중계센터에서 요구전문에 대한 응답전문을 취급기관센터로 송신할 때 SET 3 중계센터에서 지시전문을 개설기관센터로 송신할 때 SET 4 개설기관센터에서 지시전문에 대한 응답전문을 중계센터로 송신할 때 SET 5 중계센터에서 개설기관센터로부터 입금결과보고전문중 입금불능인 경우 취급기관센터로 송신할 때 SET
 * responseCode 응답코드 전문의 처리결과를 정의해 주는 코드
 * requestBankCode 취급기관코드 취급기관 구분코드
 * requestBranchCode 취급지점코드 
 * requestMessageNumber 취급전문관리번호 취급기관의 전문관리번호(기관별 일련번호)
 * requestMessageSendTime 취급전문전송시간 취급기관센터에서의 해당 전문의 전송시간
 * kftcMessageNumber 중계센터전문추적번호 중계센터에서의 전문추적번호(기관코드 + 일련번호)
 * kftcMessageTime 중계센터전문전송시간 중계센터에서의 해당 전문 전송시간
 * beneficiaryBankCode 개설기관코드 개설기관 구분코드
 * beneficiaryBranchCode 개설지점코드 
 * beneficiaryMessageNumber 개설전문관리번호 개설기관의 전문관리번호(기관별 일련번호)
 * beneficiaryMessageSendTime 개설전문전송시간 개설기관센터에서의 해당 전문의 전송시간
 * beneficiaryInquiryNumber 수취조회번호 취급기관에서 SET하는 고유한 번호 057+00000000
 * beneficiaryAccountNumber 수취인계좌번호 수취인의 계좌번호로 계좌번호 사이의 “-” 기호는 포함하지 않는다.
 * beneficiaryName 수취인성명 수취인의 성명 또는 단체명
 * totalAmount 총금액 수취인의 계좌로 입금할 총금액
 * chequeAmount 자기앞수표금액 수취조회할 금액중 타점권 자기앞수표금액
 * cashAmount 현금금액 수취조회할 금액중 현금금액
 * localCode 지역코드 지역코드
 * reservedInformationField11 예비정보FIELD 중계센터 및 참가기관에서 임의 사용 가능한 FIELD
 * requestBankBranchCode 취급기관ㆍ점별코드 취급기관의 해당 영업점코드
 * beneficiaryBankBranchCode 개설기관ㆍ점별코드 개설기관의 해당 영업점코드
 * filler3 FILLER 
 * 
 * KcgIft0210500 kcgIft0210500 = new KcgIft0210500(); // 수취조회
 * kcgIft0210500.setTcpIpHeader("0000HDR"); // TCP/IP HEADER
 * kcgIft0210500.setSystemId("03"); // 시스템-ID
 * kcgIft0210500.setInstitutionCode("057"); // 기관코드
 * kcgIft0210500.setMessageType("0210"); // 전문종별구분코드
 * kcgIft0210500.setMessageCode("500"); // 업무구분코드
 * kcgIft0210500.setSendReceiveFlag("0"); // 송수신FLAG
 * kcgIft0210500.setResponseCode(""); // 응답코드
 * kcgIft0210500.setRequestBankCode("000"); // 취급기관코드
 * kcgIft0210500.setRequestBranchCode(0); // 취급지점코드
 * kcgIft0210500.setRequestMessageNumber("000000"); // 취급전문관리번호
 * kcgIft0210500.setRequestMessageSendTime(LocalDateTime.now()); // 취급전문전송시간
 * kcgIft0210500.setKftcMessageNumber("000000000"); // 중계센터전문추적번호
 * kcgIft0210500.setKftcMessageTime(LocalDateTime.now()); // 중계센터전문전송시간
 * kcgIft0210500.setBeneficiaryBankCode("000"); // 개설기관코드
 * kcgIft0210500.setBeneficiaryBranchCode("0000"); // 개설지점코드
 * kcgIft0210500.setBeneficiaryMessageNumber("000000"); // 개설전문관리번호
 * kcgIft0210500.setBeneficiaryMessageSendTime(LocalDateTime.now()); // 개설전문전송시간
 * kcgIft0210500.setBeneficiaryInquiryNumber(""); // 수취조회번호
 * kcgIft0210500.setBeneficiaryAccountNumber(""); // 수취인계좌번호
 * kcgIft0210500.setBeneficiaryName(""); // 수취인성명
 * kcgIft0210500.setTotalAmount(0L); // 총금액
 * kcgIft0210500.setChequeAmount(0L); // 자기앞수표금액
 * kcgIft0210500.setCashAmount(0L); // 현금금액
 * kcgIft0210500.setLocalCode("01"); // 지역코드
 * kcgIft0210500.setReservedInformationField11(""); // 예비정보FIELD
 * kcgIft0210500.setRequestBankBranchCode("0000000"); // 취급기관ㆍ점별코드
 * kcgIft0210500.setBeneficiaryBankBranchCode("0000000"); // 개설기관ㆍ점별코드
 * kcgIft0210500.setFiller3(""); // FILLER
 * }</pre>
 */
@Data
public class KcgIft0210500 implements KftIftComHdr, Vo {

	private String tcpIpHeader = "0000HDR"; // TCP/IP HEADER
	private String systemId = "03"; // 시스템-ID
	private String institutionCode = "057"; // 기관코드
	private String messageType = "0210"; // 전문종별구분코드
	private String messageCode = "500"; // 업무구분코드
	private String sendReceiveFlag = "0"; // 송수신FLAG
	private String responseCode; // 응답코드
	private String requestBankCode = "000"; // 취급기관코드
	private int requestBranchCode; // 취급지점코드
	private String requestMessageNumber = "000000"; // 취급전문관리번호
	private LocalDateTime requestMessageSendTime; // 취급전문전송시간
	private String kftcMessageNumber = "000000000"; // 중계센터전문추적번호
	private LocalDateTime kftcMessageTime; // 중계센터전문전송시간
	private String beneficiaryBankCode = "000"; // 개설기관코드
	private String beneficiaryBranchCode = "0000"; // 개설지점코드
	private String beneficiaryMessageNumber = "000000"; // 개설전문관리번호
	private LocalDateTime beneficiaryMessageSendTime; // 개설전문전송시간
	private String beneficiaryInquiryNumber; // 수취조회번호
	private String beneficiaryAccountNumber; // 수취인계좌번호
	private String beneficiaryName; // 수취인성명
	private long totalAmount; // 총금액
	private long chequeAmount; // 자기앞수표금액
	private long cashAmount; // 현금금액
	private String localCode = "01"; // 지역코드
	private String reservedInformationField11; // 예비정보FIELD
	private String requestBankBranchCode = "0000000"; // 취급기관ㆍ점별코드
	private String beneficiaryBankBranchCode = "0000000"; // 개설기관ㆍ점별코드
	private String filler3; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String tcpIpHeader$; // TCP/IP HEADER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String systemId$; // 시스템-ID
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String institutionCode$; // 기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageType$; // 전문종별구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String messageCode$; // 업무구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 송수신FLAG
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String responseCode$; // 응답코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankCode$; // 취급기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBranchCode$; // 취급지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageNumber$; // 취급전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestMessageSendTime$; // 취급전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageNumber$; // 중계센터전문추적번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String kftcMessageTime$; // 중계센터전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 개설기관코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBranchCode$; // 개설지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageNumber$; // 개설전문관리번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryMessageSendTime$; // 개설전문전송시간
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryInquiryNumber$; // 수취조회번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAccountNumber$; // 수취인계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryName$; // 수취인성명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String totalAmount$; // 총금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String chequeAmount$; // 자기앞수표금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String cashAmount$; // 현금금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String localCode$; // 지역코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String reservedInformationField11$; // 예비정보FIELD
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String requestBankBranchCode$; // 취급기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankBranchCode$; // 개설기관ㆍ점별코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler3$; // FILLER

	@Override
	public int validate() {
		if (VOUtils.isNotAlphanumericSpace(tcpIpHeader$)) { // TCP/IP HEADER
			return 0;
		}
		if (VOUtils.isNotAlphanumericSpace(responseCode$)) { // 응답코드
			return 6;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryInquiryNumber$)) { // 수취조회번호
			return 17;
		}
		if (VOUtils.isNotAlphanumericSpace(beneficiaryAccountNumber$)) { // 수취인계좌번호
			return 18;
		}
		return 0;
	}

	@Override
	public void write(OutputStream out) throws IOException {
		tcpIpHeader$ = VOUtils.write(out, tcpIpHeader, 7); // TCP/IP HEADER
		systemId$ = VOUtils.write(out, systemId, 2); // 시스템-ID
		institutionCode$ = VOUtils.write(out, institutionCode, 3); // 기관코드
		messageType$ = VOUtils.write(out, messageType, 4); // 전문종별구분코드
		messageCode$ = VOUtils.write(out, messageCode, 3); // 업무구분코드
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 송수신FLAG
		responseCode$ = VOUtils.write(out, responseCode, 3); // 응답코드
		requestBankCode$ = VOUtils.write(out, requestBankCode, 3); // 취급기관코드
		requestBranchCode$ = VOUtils.write(out, requestBranchCode, 4); // 취급지점코드
		requestMessageNumber$ = VOUtils.write(out, requestMessageNumber, 6); // 취급전문관리번호
		requestMessageSendTime$ = VOUtils.write(out, requestMessageSendTime, 12, "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber$ = VOUtils.write(out, kftcMessageNumber, 9); // 중계센터전문추적번호
		kftcMessageTime$ = VOUtils.write(out, kftcMessageTime, 12, "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 개설기관코드
		beneficiaryBranchCode$ = VOUtils.write(out, beneficiaryBranchCode, 4); // 개설지점코드
		beneficiaryMessageNumber$ = VOUtils.write(out, beneficiaryMessageNumber, 6); // 개설전문관리번호
		beneficiaryMessageSendTime$ = VOUtils.write(out, beneficiaryMessageSendTime, 12, "yyMMddHHmmss"); // 개설전문전송시간
		beneficiaryInquiryNumber$ = VOUtils.write(out, beneficiaryInquiryNumber, 13); // 수취조회번호
		beneficiaryAccountNumber$ = VOUtils.write(out, beneficiaryAccountNumber, 14); // 수취인계좌번호
		beneficiaryName$ = VOUtils.write(out, beneficiaryName, 20, "EUC-KR"); // 수취인성명
		totalAmount$ = VOUtils.write(out, totalAmount, 12); // 총금액
		chequeAmount$ = VOUtils.write(out, chequeAmount, 12); // 자기앞수표금액
		cashAmount$ = VOUtils.write(out, cashAmount, 12); // 현금금액
		localCode$ = VOUtils.write(out, localCode, 2); // 지역코드
		reservedInformationField11$ = VOUtils.write(out, reservedInformationField11, 11); // 예비정보FIELD
		requestBankBranchCode$ = VOUtils.write(out, requestBankBranchCode, 7); // 취급기관ㆍ점별코드
		beneficiaryBankBranchCode$ = VOUtils.write(out, beneficiaryBankBranchCode, 7); // 개설기관ㆍ점별코드
		filler3$ = VOUtils.write(out, filler3, 103); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		tcpIpHeader = VOUtils.toString(tcpIpHeader$ = VOUtils.read(in, 7)); // TCP/IP HEADER
		systemId = VOUtils.toString(systemId$ = VOUtils.read(in, 2)); // 시스템-ID
		institutionCode = VOUtils.toString(institutionCode$ = VOUtils.read(in, 3)); // 기관코드
		messageType = VOUtils.toString(messageType$ = VOUtils.read(in, 4)); // 전문종별구분코드
		messageCode = VOUtils.toString(messageCode$ = VOUtils.read(in, 3)); // 업무구분코드
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 송수신FLAG
		responseCode = VOUtils.toString(responseCode$ = VOUtils.read(in, 3)); // 응답코드
		requestBankCode = VOUtils.toString(requestBankCode$ = VOUtils.read(in, 3)); // 취급기관코드
		requestBranchCode = VOUtils.toInt(requestBranchCode$ = VOUtils.read(in, 4)); // 취급지점코드
		requestMessageNumber = VOUtils.toString(requestMessageNumber$ = VOUtils.read(in, 6)); // 취급전문관리번호
		requestMessageSendTime = VOUtils.toLocalDateTime(requestMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 취급전문전송시간
		kftcMessageNumber = VOUtils.toString(kftcMessageNumber$ = VOUtils.read(in, 9)); // 중계센터전문추적번호
		kftcMessageTime = VOUtils.toLocalDateTime(kftcMessageTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 중계센터전문전송시간
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 개설기관코드
		beneficiaryBranchCode = VOUtils.toString(beneficiaryBranchCode$ = VOUtils.read(in, 4)); // 개설지점코드
		beneficiaryMessageNumber = VOUtils.toString(beneficiaryMessageNumber$ = VOUtils.read(in, 6)); // 개설전문관리번호
		beneficiaryMessageSendTime = VOUtils.toLocalDateTime(beneficiaryMessageSendTime$ = VOUtils.read(in, 12), "yyMMddHHmmss"); // 개설전문전송시간
		beneficiaryInquiryNumber = VOUtils.toString(beneficiaryInquiryNumber$ = VOUtils.read(in, 13)); // 수취조회번호
		beneficiaryAccountNumber = VOUtils.toString(beneficiaryAccountNumber$ = VOUtils.read(in, 14)); // 수취인계좌번호
		beneficiaryName = VOUtils.toString(beneficiaryName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인성명
		totalAmount = VOUtils.toLong(totalAmount$ = VOUtils.read(in, 12)); // 총금액
		chequeAmount = VOUtils.toLong(chequeAmount$ = VOUtils.read(in, 12)); // 자기앞수표금액
		cashAmount = VOUtils.toLong(cashAmount$ = VOUtils.read(in, 12)); // 현금금액
		localCode = VOUtils.toString(localCode$ = VOUtils.read(in, 2)); // 지역코드
		reservedInformationField11 = VOUtils.toString(reservedInformationField11$ = VOUtils.read(in, 11)); // 예비정보FIELD
		requestBankBranchCode = VOUtils.toString(requestBankBranchCode$ = VOUtils.read(in, 7)); // 취급기관ㆍ점별코드
		beneficiaryBankBranchCode = VOUtils.toString(beneficiaryBankBranchCode$ = VOUtils.read(in, 7)); // 개설기관ㆍ점별코드
		filler3 = VOUtils.toString(filler3$ = VOUtils.read(in, 103)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", tcpIpHeader=").append(tcpIpHeader).append(System.lineSeparator()); // TCP/IP HEADER
		sb.append(", systemId=").append(systemId).append(System.lineSeparator()); // 시스템-ID
		sb.append(", institutionCode=").append(institutionCode).append(System.lineSeparator()); // 기관코드
		sb.append(", messageType=").append(messageType).append(System.lineSeparator()); // 전문종별구분코드
		sb.append(", messageCode=").append(messageCode).append(System.lineSeparator()); // 업무구분코드
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 송수신FLAG
		sb.append(", responseCode=").append(responseCode).append(System.lineSeparator()); // 응답코드
		sb.append(", requestBankCode=").append(requestBankCode).append(System.lineSeparator()); // 취급기관코드
		sb.append(", requestBranchCode=").append(requestBranchCode).append(System.lineSeparator()); // 취급지점코드
		sb.append(", requestMessageNumber=").append(requestMessageNumber).append(System.lineSeparator()); // 취급전문관리번호
		sb.append(", requestMessageSendTime=").append(requestMessageSendTime).append(System.lineSeparator()); // 취급전문전송시간
		sb.append(", kftcMessageNumber=").append(kftcMessageNumber).append(System.lineSeparator()); // 중계센터전문추적번호
		sb.append(", kftcMessageTime=").append(kftcMessageTime).append(System.lineSeparator()); // 중계센터전문전송시간
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 개설기관코드
		sb.append(", beneficiaryBranchCode=").append(beneficiaryBranchCode).append(System.lineSeparator()); // 개설지점코드
		sb.append(", beneficiaryMessageNumber=").append(beneficiaryMessageNumber).append(System.lineSeparator()); // 개설전문관리번호
		sb.append(", beneficiaryMessageSendTime=").append(beneficiaryMessageSendTime).append(System.lineSeparator()); // 개설전문전송시간
		sb.append(", beneficiaryInquiryNumber=").append(beneficiaryInquiryNumber).append(System.lineSeparator()); // 수취조회번호
		sb.append(", beneficiaryAccountNumber=").append(beneficiaryAccountNumber).append(System.lineSeparator()); // 수취인계좌번호
		sb.append(", beneficiaryName=").append(beneficiaryName).append(System.lineSeparator()); // 수취인성명
		sb.append(", totalAmount=").append(totalAmount).append(System.lineSeparator()); // 총금액
		sb.append(", chequeAmount=").append(chequeAmount).append(System.lineSeparator()); // 자기앞수표금액
		sb.append(", cashAmount=").append(cashAmount).append(System.lineSeparator()); // 현금금액
		sb.append(", localCode=").append(localCode).append(System.lineSeparator()); // 지역코드
		sb.append(", reservedInformationField11=").append(reservedInformationField11).append(System.lineSeparator()); // 예비정보FIELD
		sb.append(", requestBankBranchCode=").append(requestBankBranchCode).append(System.lineSeparator()); // 취급기관ㆍ점별코드
		sb.append(", beneficiaryBankBranchCode=").append(beneficiaryBankBranchCode).append(System.lineSeparator()); // 개설기관ㆍ점별코드
		sb.append(", filler3=").append(filler3).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "tcpIpHeader", "fldLen", "7", "defltVal", "0000HDR"),
			Map.of("fld", "systemId", "fldLen", "2", "defltVal", "03"),
			Map.of("fld", "institutionCode", "fldLen", "3", "defltVal", "057"),
			Map.of("fld", "messageType", "fldLen", "4", "defltVal", "0210"),
			Map.of("fld", "messageCode", "fldLen", "3", "defltVal", "500"),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", "0"),
			Map.of("fld", "responseCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "requestBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "requestBranchCode", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "requestMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "requestMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "kftcMessageNumber", "fldLen", "9", "defltVal", "000000000"),
			Map.of("fld", "kftcMessageTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", "000"),
			Map.of("fld", "beneficiaryBranchCode", "fldLen", "4", "defltVal", "0000"),
			Map.of("fld", "beneficiaryMessageNumber", "fldLen", "6", "defltVal", "000000"),
			Map.of("fld", "beneficiaryMessageSendTime", "fldLen", "12", "defltVal", "$yymmddhhmiss"),
			Map.of("fld", "beneficiaryInquiryNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneficiaryAccountNumber", "fldLen", "14", "defltVal", ""),
			Map.of("fld", "beneficiaryName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "totalAmount", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "chequeAmount", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "cashAmount", "fldLen", "12", "defltVal", ""),
			Map.of("fld", "localCode", "fldLen", "2", "defltVal", "01"),
			Map.of("fld", "reservedInformationField11", "fldLen", "11", "defltVal", ""),
			Map.of("fld", "requestBankBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "beneficiaryBankBranchCode", "fldLen", "7", "defltVal", "0000000"),
			Map.of("fld", "filler3", "fldLen", "103", "defltVal", "")
		);
	}

}
