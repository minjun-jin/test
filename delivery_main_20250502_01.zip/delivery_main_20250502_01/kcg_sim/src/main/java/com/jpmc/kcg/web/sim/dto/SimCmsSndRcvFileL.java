package com.jpmc.kcg.web.sim.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;


import lombok.Data;
import lombok.Generated;

@Data
@Generated
public class SimCmsSndRcvFileL {
    private String srDt;

    private String trDt;

    private String fileNm;

    private String dataTp;

    private String seqNo;

    private String srTp;

    private String prcsStsDvsnCd;

    private String respCd;

    private String corpCd;

    private String rtpyrId;

    private String custNo;

    private String acctNo;

    private BigDecimal reqAmt;

    private BigDecimal realPrcsAmt;

    private Long prcsFee;

    private String tlgCtt;

    private BigDecimal rcvSeq;

    private BigDecimal sndSeq;

    private String filler;

    private String makeId;

    private String makeDttm;

    private String chkId;

    private String chkDttm;

    private String frstChngGuid;

    private String frstChngStaffId;

    private LocalDateTime frstChngTmstmp;

    private String lastChngGuid;

    private String lastChngStaffId;

    private LocalDateTime lastChngTmstmp;

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
        sb.append(", srDt=").append(srDt).append(System.lineSeparator());
        sb.append(", trDt=").append(trDt).append(System.lineSeparator());
        sb.append(", fileNm=").append(fileNm).append(System.lineSeparator());
        sb.append(", dataTp=").append(dataTp).append(System.lineSeparator());
        sb.append(", seqNo=").append(seqNo).append(System.lineSeparator());
        sb.append(", srTp=").append(srTp).append(System.lineSeparator());
        sb.append(", prcsStsDvsnCd=").append(prcsStsDvsnCd).append(System.lineSeparator());
        sb.append(", respCd=").append(respCd).append(System.lineSeparator());
        sb.append(", corpCd=").append(corpCd).append(System.lineSeparator());
        sb.append(", rtpyrId=").append(rtpyrId).append(System.lineSeparator());
        sb.append(", custNo=").append(custNo).append(System.lineSeparator());
        sb.append(", acctNo=").append(acctNo).append(System.lineSeparator());
        sb.append(", reqAmt=").append(reqAmt).append(System.lineSeparator());
        sb.append(", realPrcsAmt=").append(realPrcsAmt).append(System.lineSeparator());
        sb.append(", prcsFee=").append(prcsFee).append(System.lineSeparator());
        sb.append(", tlgCtt=").append(tlgCtt).append(System.lineSeparator());
        sb.append(", rcvSeq=").append(rcvSeq).append(System.lineSeparator());
        sb.append(", sndSeq=").append(sndSeq).append(System.lineSeparator());
        sb.append(", filler=").append(filler).append(System.lineSeparator());
        sb.append(", makeId=").append(makeId).append(System.lineSeparator());
        sb.append(", makeDttm=").append(makeDttm).append(System.lineSeparator());
        sb.append(", chkId=").append(chkId).append(System.lineSeparator());
        sb.append(", chkDttm=").append(chkDttm).append(System.lineSeparator());
        sb.append(", frstChngGuid=").append(frstChngGuid).append(System.lineSeparator());
        sb.append(", frstChngStaffId=").append(frstChngStaffId).append(System.lineSeparator());
        sb.append(", frstChngTmstmp=").append(frstChngTmstmp).append(System.lineSeparator());
        sb.append(", lastChngGuid=").append(lastChngGuid).append(System.lineSeparator());
        sb.append(", lastChngStaffId=").append(lastChngStaffId).append(System.lineSeparator());
        sb.append(", lastChngTmstmp=").append(lastChngTmstmp).append(System.lineSeparator());
        sb.append("]");
        return sb.toString();
    }
}