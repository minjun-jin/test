package com.jpmc.kcg.bat.cms.job;

import static com.jpmc.kcg.cms.constants.CmsConst.*;
import static com.jpmc.kcg.com.constants.ComConst.N;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.jpmc.kcg.bat.ChunkBatJob;
import com.jpmc.kcg.bat.cms.biz.CmsCom;
import com.jpmc.kcg.bat.cms.biz.CmsSndRcvLogManager;
import com.jpmc.kcg.bat.cms.dao.BatCmsWhdrwlTrnAplyDescMDao;
import com.jpmc.kcg.bat.cms.dao.BatCmsWhdrwlTrnAplyMDao;
import com.jpmc.kcg.bat.cms.dto.BatCmsContextVo;
import com.jpmc.kcg.bat.cms.dto.BatCmsDbtTrnsRqstRsltVo;
import com.jpmc.kcg.cms.biz.CmsAccountValidator;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB13R;
import com.jpmc.kcg.cms.biz.vo.KftCmsEB13T;
import com.jpmc.kcg.cms.dao.CmsWhdrwlTrnAplyDescMMapper;
import com.jpmc.kcg.cms.dao.CmsWhdrwlTrnAplyMMapper;
import com.jpmc.kcg.cms.dto.AccountOut;
import com.jpmc.kcg.cms.dto.CmsSndRcvFileL;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyDescM;
import com.jpmc.kcg.cms.dto.CmsWhdrwlTrnAplyM;
import com.jpmc.kcg.cms.enums.CmsBatchRespCdEnum;
import com.jpmc.kcg.cms.enums.CmsPrcsStsDvsnCdEnum;
import com.jpmc.kcg.cms.enums.CmsRqstDvsnCdEnum;
import com.jpmc.kcg.com.utils.DateUtils;
import com.jpmc.kcg.frw.FrwContextHolder;
import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.bat.BatContext;
import com.jpmc.kcg.frw.bat.BatContextImpl;

import lombok.extern.slf4j.Slf4j;

/**
 * EB13 (출금이체신청)출금이체신청내역(기관접수)
 * 출금 동의를 기관에서 받은 경우(기관 접수시 이용기관 -> 결제원)
 */
@Component
@Slf4j
public class CmsDbtTrnsAplyInstJobBean extends ChunkBatJob<CmsSndRcvFileL, BatCmsDbtTrnsRqstRsltVo> {

	private final BatCmsWhdrwlTrnAplyDescMDao batCmsWhdrwlTrnAplyDescMDao;
	private final BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao;
	private final CmsWhdrwlTrnAplyMMapper cmsWhdrwlTrnAplyMMapper;
	private final CmsWhdrwlTrnAplyDescMMapper cmsWhdrwlTrnAplyDescMMapper;
	private final CmsSndRcvLogManager cmsSndRcvLogManager;
	private final CmsAccountValidator cmsAccountValidator;
    private final CmsCom cmsCom;
	
	public CmsDbtTrnsAplyInstJobBean(BatCmsWhdrwlTrnAplyDescMDao batCmsWhdrwlTrnAplyDescMDao, BatCmsWhdrwlTrnAplyMDao batCmsWhdrwlTrnAplyMDao,
                                     CmsWhdrwlTrnAplyMMapper cmsWhdrwlTrnAplyMMapper, CmsWhdrwlTrnAplyDescMMapper cmsWhdrwlTrnAplyDescMMapper, CmsSndRcvLogManager cmsSndRcvLogManager, CmsAccountValidator cmsAccountValidator, CmsCom cmsCom) {
		this.batCmsWhdrwlTrnAplyDescMDao = batCmsWhdrwlTrnAplyDescMDao;
		this.batCmsWhdrwlTrnAplyMDao = batCmsWhdrwlTrnAplyMDao;
		this.cmsWhdrwlTrnAplyMMapper = cmsWhdrwlTrnAplyMMapper;
		this.cmsWhdrwlTrnAplyDescMMapper = cmsWhdrwlTrnAplyDescMMapper;
		this.cmsSndRcvLogManager = cmsSndRcvLogManager;
		this.cmsAccountValidator = cmsAccountValidator;
        this.cmsCom = cmsCom;
    }
    
    @Override
    protected void beforeJob(BatContext batContext) {
        BatCmsContextVo cmsContextVo = new BatCmsContextVo();
        cmsContextVo.initializeContext(batContext, EB13); // EB13 ( 기관 출금이체 신청 적재 대상 데이터 조회)

        // BatContext에 CMS Context, 집계용 변수 저장
        batContext.setData(CMS_CONTEXT, cmsContextVo);
        batContext.setData(TOT_RECORD_COUNT, 0L);           // EB13 데이터 총 건수
        batContext.setData(SEQ, 0);                         // EB13 생성 총 건수

        batContext.setData(NEW_COUNT, 0);                   // 총건수
        batContext.setData(DELETE_COUNT, 0);                // 신규등록건수
        batContext.setData(MODIFY_COUNT, 0);                // 변경등록건수
        batContext.setData(ARB_TERM_COUNT, 0);              // 임의해지건수

        /*
         * file tracking 정보 저장
         */
        batContext.setFileTractId(cmsCom.getFileTractId(cmsContextVo.getSrDt(), EB13));

        // commit interval 설정
        BatContextImpl context = (BatContextImpl)FrwContextHolder.getContext();
        context.setCommitInterval(cmsContextVo.getCommitInterval());
        
        super.beforeJob(batContext);
    }

    @Override
    protected long targetTotalCount(BatContext batContext) {
        log.debug(" ##### targetTotalCount start  ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        long targetEB13Count = cmsSndRcvLogManager.getCountReceivedFilesData(null, cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        batContext.setData(TOT_RECORD_COUNT, targetEB13Count);
        
        if (targetEB13Count == 0L) {
            log.debug("[EB13] NO DATA [SR_DT= {}] [TR_DT={}] [FILE_NM= {}]  ]", cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        }
        return targetEB13Count;
    }

    @Override
    protected Iterator<CmsSndRcvFileL> openReader(BatContext batContext) {
        log.debug(" ##### openReader start ######");

        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        /*
         * 파일 수신 데이터 조회
         */
        List<CmsSndRcvFileL> receivedFiles = cmsSndRcvLogManager.getReceivedFilesData(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());
        log.debug("[EB13 RCV LIST DATA SIZE] : {}", receivedFiles.size());

        return receivedFiles.iterator();
    }

    @Override
    protected OutputStream openWriter(BatContext batContext) {
        return null;
    }

    @Override
    protected BatCmsDbtTrnsRqstRsltVo process(CmsSndRcvFileL cmsSndRcvFileL) {
        BatContext batContext = (BatContext) FrwContextHolder.getContext();
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);
        
        // 이미 처리한 경우 검증에서 pass함 -> 재처리시 업데이트 하지 않음
        if (CmsPrcsStsDvsnCdEnum.LVB_RCV == CmsPrcsStsDvsnCdEnum.findByCode(cmsSndRcvFileL.getPrcsStsDvsnCd())) {
            return null;
        }
        
        KftCmsEB13R kftCmsEB13R = VOUtils.toVo(cmsSndRcvFileL.getTlgCtt(), KftCmsEB13R.class);
        batContext.setData(SEQ, (int)batContext.getData(SEQ) + 1 ); // 총건수(sequence)

        // 등록구분 조회
        switch (CmsRqstDvsnCdEnum.findByCode(kftCmsEB13R.getRequestDivision())) {
            case REGISTRATION -> batContext.setData(NEW_COUNT, (int) batContext.getData(NEW_COUNT) + 1);
            case TERMINATION -> batContext.setData(DELETE_COUNT, (int) batContext.getData(DELETE_COUNT) + 1);
            case MODIFICATION -> batContext.setData(MODIFY_COUNT, (int) batContext.getData(MODIFY_COUNT) + 1);
            case ARBITRARY_TERMINATION -> batContext.setData(ARB_TERM_COUNT, (int) batContext.getData(ARB_TERM_COUNT) + 1);
            default -> log.error("Unexpected value: " + CmsRqstDvsnCdEnum.findByCode(kftCmsEB13R.getRequestDivision()));
        }

        // 검증로직 2. 계좌 정보 검증
        AccountOut accountInfo = cmsAccountValidator.validateAccountWithdrawalAccountError(kftCmsEB13R.getDesignatedWithdrawalAccountNumber());
        String respCd = accountInfo.getRespCd();
        String acctNm = accountInfo.getAcctNm();

        if (CmsBatchRespCdEnum.isNormal(respCd)) {
            // 불능사유 검증, 중복데이터 검증
            respCd = validateRequestData(kftCmsEB13R, cmsContextVo.getSrDt(), accountInfo);
        }

        log.debug("[EB13] CHECK RESP CODE = [FILE_NM = {}] [SEQ_NO = {}] [RESP_CD = {}] ",
                cmsContextVo.getSourceFileNm(), kftCmsEB13R.getDataSerialNumber(), respCd );

        // write에서 저장할 VO 생성
        BatCmsDbtTrnsRqstRsltVo batCmsDbtTrnsRqstRsltVo = new BatCmsDbtTrnsRqstRsltVo();
        batCmsDbtTrnsRqstRsltVo.setTargetRecordVo(kftCmsEB13R);
        batCmsDbtTrnsRqstRsltVo.setRespCd(respCd);
        batCmsDbtTrnsRqstRsltVo.setAcctNm(acctNm);
        batCmsDbtTrnsRqstRsltVo.setTargetFileL(cmsSndRcvFileL); // EB13
        return batCmsDbtTrnsRqstRsltVo;
    }

    private String validateRequestData(KftCmsEB13R kftCmsEB13R, String srDt, AccountOut accountInfo) {

        String respCd;

        // 신규, 해지, 임의해지가 아닌 경우 에러처리
        if (!CmsRqstDvsnCdEnum.isRequest(kftCmsEB13R.getRequestDivision())) {
            // A012 신청구분 오류
            return CmsBatchRespCdEnum.REQUEST_TYPE_ERROR.getCode();
        }

        String reqDt = StringUtils.join("20", kftCmsEB13R.getRequestDate());
        respCd = cmsCom.validateRequestDate(reqDt, srDt);

        // 검증 로직 1. 신청일자, srDt 비교
        if (!CmsBatchRespCdEnum.isNormal(respCd)) {
            // A011 신청일자 > srDt인 경우 에러(신청일자 오류)
            return respCd;
        }

        // 검증로직 2. 계좌 정보 -> 중복제거를 위해 검증 순서 조정 (필요시 원복)

        // 검증 로직 3. 사업자등록번호 또는 생년월일 오류
        if (CmsRqstDvsnCdEnum.REGISTRATION.getCode().equals(kftCmsEB13R.getRequestDivision()) &&
                !N.equals(kftCmsEB13R.getCheckResidentBusinessNumberYn()) &&
                !kftCmsEB13R.getAccountHolderResidentBusinessNumber().equals(accountInfo.getCtzBizNo())) {
            // 사업자등록번호 또는 생년월일 오류
            return CmsBatchRespCdEnum.CITIZ_BUSINESS_NUMBER_ERROR.getCode();
        }

        // 위의 검증 통과시 출금이체원장 데이터 검증
        return validateWhdrwlStatus(kftCmsEB13R);
    }

    private String validateWhdrwlStatus(KftCmsEB13R kftCmsEB13R) {
        // 중복데이터 검증
        CmsWhdrwlTrnAplyM cmsWhdrwlTrnAplyM = cmsWhdrwlTrnAplyMMapper.selectByPrimaryKey(kftCmsEB13R.getInstitutionCode(),
                kftCmsEB13R.getPayerNumber(), kftCmsEB13R.getDesignatedWithdrawalAccountNumber());

        return switch (CmsRqstDvsnCdEnum.findByCode(kftCmsEB13R.getRequestDivision())) {
            case REGISTRATION -> handleRegistration(cmsWhdrwlTrnAplyM, kftCmsEB13R); // 신규등록 요청인 경우
            case TERMINATION -> handleTermination(cmsWhdrwlTrnAplyM, kftCmsEB13R); // 해지 요청인 경우
            default -> CmsBatchRespCdEnum.NORMAL.getCode();
        };
    }

    private String handleRegistration(CmsWhdrwlTrnAplyM cmsWhdrwlTrnAplyM, KftCmsEB13R kftCmsEB13R) {
        if (ObjectUtils.isEmpty(cmsWhdrwlTrnAplyM)) {
            return CmsBatchRespCdEnum.NORMAL.getCode();
        }

        // 기존에도 신규요청인 경우 에러
        if (CmsRqstDvsnCdEnum.REGISTRATION.getCode().equals(cmsWhdrwlTrnAplyM.getRegStsCd())) {
            // 중복요청(이중신청)
            return CmsBatchRespCdEnum.DUPLICATE_TRANSFER_REQUEST.getCode();
        }

        // 기존 데이터가 0 은행이 아니고 7 임의해지도 아닌 경우에 에러
        if (!REG_DVSN_BANK.equals(cmsWhdrwlTrnAplyM.getRegDvsnCd()) &&
                !CmsRqstDvsnCdEnum.ARBITRARY_TERMINATION.getCode().equals(cmsWhdrwlTrnAplyM.getRegStsCd())) {
            // 출금이체신청 참가기관 (은행)해지
            return CmsBatchRespCdEnum.WITHDRAWAL_TRANSFER_TERMINATION_ERROR.getCode();
        }

        log.debug("[I N F O] [CMS_WHDRWL_TRN_APLY_M] DELETE SUCCESS FOR 재등록 [CORP_CD = {}] [RTRPY_ID = {}] [ACCT_NO = {}]",
                kftCmsEB13R.getInstitutionCode(), kftCmsEB13R.getPayerNumber(), kftCmsEB13R.getDesignatedWithdrawalAccountNumber());

        // 중복 로직 검증에 걸리지 않는 경우 데이터 삭제 후 insert
        cmsWhdrwlTrnAplyMMapper.deleteByPrimaryKey(kftCmsEB13R.getInstitutionCode(), kftCmsEB13R.getPayerNumber(), kftCmsEB13R.getDesignatedWithdrawalAccountNumber());
        return CmsBatchRespCdEnum.NORMAL.getCode();
    }

    private String handleTermination(CmsWhdrwlTrnAplyM cmsWhdrwlTrnAplyM, KftCmsEB13R kftCmsEB13R) {
        // Y거나 빈칸이거나 ( 검증대상인 경우)
        if (!N.equals(kftCmsEB13R.getCheckResidentBusinessNumberYn())) {
            String respCd = cmsCom.validateCtzBizNo(kftCmsEB13R.getAccountHolderResidentBusinessNumber());
            if (!CmsBatchRespCdEnum.isNormal(respCd)) {
                // 사업자등록번호 또는 생년월일 오류
                return CmsBatchRespCdEnum.CITIZ_BUSINESS_NUMBER_ERROR.getCode();
            }
        }

        // 출금이체신청내역(EB13)의 신청구분이 해지신청 또는 임의해지 신청일 때 출금이체신청등록원장에 해당 계좌번호 및 납부자 번호가 없거나 상이한 경우
        if (CmsRqstDvsnCdEnum.isTerminated(cmsWhdrwlTrnAplyM.getRegStsCd())) {
            return CmsBatchRespCdEnum.WITHDRAWAL_TRANSFER_NOT_APPLY_ERROR.getCode();
        }

        return CmsBatchRespCdEnum.NORMAL.getCode();
    }
    
    @Override
    protected void write(List<BatCmsDbtTrnsRqstRsltVo> items) {
        log.debug(" ##### write ######");
        BatContext batContext = (BatContext)FrwContextHolder.getContext();
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        items.forEach(item -> {

            if(CmsBatchRespCdEnum.isNormal(item.getRespCd())) {
                // 출금이체 원장 업데이트 또는 신규
                saveCmsWhdrwlTrnAplyM((KftCmsEB13R) item.getTargetRecordVo(), cmsContextVo, batContext, item.getAcctNm());

                // 출금이체 이력 저장
                saveCmsWhdrwlTrnAplyDescM((KftCmsEB13R) item.getTargetRecordVo(), cmsContextVo, item.getAcctNm());
            }

            //////////////////////////////////////////////////////////////////
            // 검증 결과 후 파일 데이터 update
            updateRespInfo(item.getTargetFileL(), (KftCmsEB13R) item.getTargetRecordVo(), item.getRespCd());
        });
    }

    private void saveCmsWhdrwlTrnAplyM(KftCmsEB13R kftCmsEB13R, BatCmsContextVo cmsContextVo, BatContext batContext, String acctNm) {
        
        String reqDt = StringUtils.join("20", kftCmsEB13R.getRequestDate());

        CmsWhdrwlTrnAplyM cmsWhdrwlTrnAplyM = new CmsWhdrwlTrnAplyM();
        cmsWhdrwlTrnAplyM.setAprvStsCd      ("02"                                               ); // 승인완료
        cmsWhdrwlTrnAplyM.setRegStsCd       (kftCmsEB13R.getRequestDivision()                   ); // 신청구분
        cmsWhdrwlTrnAplyM.setReqDt          (reqDt                                              );
        cmsWhdrwlTrnAplyM.setCorpCd         (kftCmsEB13R.getInstitutionCode()                   ); // 기관코드
        cmsWhdrwlTrnAplyM.setRtpyrId        (kftCmsEB13R.getPayerNumber()                       ); // 납부자번호
        cmsWhdrwlTrnAplyM.setAcctNo         (kftCmsEB13R.getDesignatedWithdrawalAccountNumber() ); // 지정출금계좌번호
        cmsWhdrwlTrnAplyM.setAcctNm         (acctNm                                             );
        cmsWhdrwlTrnAplyM.setCtzBizNo       (kftCmsEB13R.getAccountHolderResidentBusinessNumber()); // 예금주 생년월일, 사업자등록번호
        cmsWhdrwlTrnAplyM.setRegDvsnCd      (REG_DVSN_INST                                      ); // 1: 이용기관
        cmsWhdrwlTrnAplyM.setTelNo          (kftCmsEB13R.getPhoneNumber()                       ); //전화번호
        cmsWhdrwlTrnAplyM.setWhdrwlFile     (cmsContextVo.getSourceFileNm()                     ); // 파일명
        cmsWhdrwlTrnAplyM.setWhdrwlRecSeq   (kftCmsEB13R.getDataSerialNumber()                  ); // 일련번호
        cmsWhdrwlTrnAplyM.setRespDt         (cmsContextVo.getSrDt()                             ); // 응답일자 - srDt
        cmsWhdrwlTrnAplyM.setRespCd         (CmsBatchRespCdEnum.NORMAL.getCode()                ); // 응답코드 - 정상
        cmsWhdrwlTrnAplyM.setLastChgDt      (cmsContextVo.getSrDt()                             ); // 최종변경일
        cmsWhdrwlTrnAplyM.setBnkBrnchCd     (kftCmsEB13R.getBankBranchCode()                    ); // 은행점코드
        cmsWhdrwlTrnAplyM.setResidCheck     (kftCmsEB13R.getCheckResidentBusinessNumberYn()     ); // 생년월일(사업자등록번호) Check 여부
        cmsWhdrwlTrnAplyM.setFundTp         (kftCmsEB13R.getFundType()                          ); // 자금종류
        cmsWhdrwlTrnAplyM.setMakeId         (batContext.getBatId()                              );
        cmsWhdrwlTrnAplyM.setMakeDttm       (DateUtils.getDttm()                                );
        cmsWhdrwlTrnAplyM.setChkId          (batContext.getBatId()                              );
        cmsWhdrwlTrnAplyM.setChkDttm        (DateUtils.getDttm()                                );

        if (CmsRqstDvsnCdEnum.REGISTRATION.getCode().equals(kftCmsEB13R.getRequestDivision())) {
            // 신규 등록
            cmsWhdrwlTrnAplyMMapper.insert(cmsWhdrwlTrnAplyM);

        } else {
            // 해지정보 update
            cmsWhdrwlTrnAplyM.setTrmnDt(reqDt);   // YY + YYMMDD
            batCmsWhdrwlTrnAplyMDao.updateTerminateInfo(cmsWhdrwlTrnAplyM);
        }
    }

    private void saveCmsWhdrwlTrnAplyDescM(KftCmsEB13R kftCmsEB13R, BatCmsContextVo cmsContextVo, String acctNm) {
        CmsWhdrwlTrnAplyDescM cmsWhdrwlTrnAplyDescM = new CmsWhdrwlTrnAplyDescM();
        cmsWhdrwlTrnAplyDescM.setCorpCd        (kftCmsEB13R.getInstitutionCode()                               );
        cmsWhdrwlTrnAplyDescM.setRtpyrId       (kftCmsEB13R.getPayerNumber()                                   );
        cmsWhdrwlTrnAplyDescM.setAcctNo        (kftCmsEB13R.getDesignatedWithdrawalAccountNumber()             );
        cmsWhdrwlTrnAplyDescM.setRegSeq        (batCmsWhdrwlTrnAplyDescMDao.selectRegSeq(cmsWhdrwlTrnAplyDescM)); // REG_SEQ 채번
        cmsWhdrwlTrnAplyDescM.setRqstDvsnCd    (kftCmsEB13R.getRequestDivision()                               );
        cmsWhdrwlTrnAplyDescM.setRegDvsnCd     (REG_DVSN_INST                                         ); // 기관
        cmsWhdrwlTrnAplyDescM.setCtzBizNo      (kftCmsEB13R.getAccountHolderResidentBusinessNumber()           );
        cmsWhdrwlTrnAplyDescM.setTelNo         (kftCmsEB13R.getPhoneNumber()                                   );
        cmsWhdrwlTrnAplyDescM.setAcctNm        (acctNm                                                         );
        cmsWhdrwlTrnAplyDescM.setRqstBrnchCd   (StringUtils.substring(kftCmsEB13R.getBankBranchCode(), 4) );
        cmsWhdrwlTrnAplyDescM.setRegDt         (cmsContextVo.getSrDt()                                         );
        cmsWhdrwlTrnAplyDescM.setSndDt         (cmsContextVo.getSrDt()                                         );
        cmsWhdrwlTrnAplyDescM.setRespCd        (CmsBatchRespCdEnum.NORMAL.getCode()                            );
        cmsWhdrwlTrnAplyDescM.setBnkBrnchCd    (kftCmsEB13R.getBankBranchCode()                                );
        cmsWhdrwlTrnAplyDescM.setFundTp        (kftCmsEB13R.getFundType()                                      );
        cmsWhdrwlTrnAplyDescM.setResidCheck    (kftCmsEB13R.getCheckResidentBusinessNumberYn()                 );
        cmsWhdrwlTrnAplyDescM.setFileNm        (cmsContextVo.getSourceFileNm()                                 );
        cmsWhdrwlTrnAplyDescM.setRecSeqNo      (kftCmsEB13R.getDataSerialNumber()                              );
        cmsWhdrwlTrnAplyDescM.setVrfcFlag      ("0"                                                            );
        cmsWhdrwlTrnAplyDescM.setMakeId        ("SYSTEM"                                                       );
        cmsWhdrwlTrnAplyDescM.setMakeDttm      (DateUtils.getDttm());

        cmsWhdrwlTrnAplyDescMMapper.insert(cmsWhdrwlTrnAplyDescM);
    }

    // 출금이체 검증 결과 update
    private void updateRespInfo(CmsSndRcvFileL cmsSndRcvFile, KftCmsEB13R kftCmsEB13R, String respCd) {

        if(!CmsBatchRespCdEnum.isNormal(respCd)) {
            kftCmsEB13R.setProcessingResultCode(N);
            kftCmsEB13R.setProcessingResultFailedCode(respCd);
            String tlgCtt = VOUtils.toString(kftCmsEB13R);
            cmsSndRcvFile.setTlgCtt(tlgCtt);
        }else {
            // 정상 결과인 경우 update
            cmsSndRcvFile.setPrcsStsDvsnCd(CmsPrcsStsDvsnCdEnum.LVB_RCV.getCode());
        }

        cmsSndRcvFile.setRespCd(respCd);
        cmsSndRcvLogManager.updateRcvFileLog(cmsSndRcvFile, respCd);
    }

    @Override
    protected void afterJob(BatContext batContext) {
        BatCmsContextVo cmsContextVo = (BatCmsContextVo) batContext.getData(CMS_CONTEXT);

        // TRAILER 부 조회
        CmsSndRcvFileL trailer = cmsSndRcvLogManager.getReceivedFilesTrailer(cmsContextVo.getSrDt(), cmsContextVo.getTrDt(), cmsContextVo.getSourceFileNm());

        // 건수 검증 및 TRAILER update
        validateTrailer(trailer, batContext);
        super.afterJob(batContext);
    }

    // 건수 검증 후 검증 내역 TRAILER update
    private void validateTrailer(CmsSndRcvFileL trailer, BatContext batContext) {

        String respCd = CmsBatchRespCdEnum.NORMAL.getCode();
        KftCmsEB13T kftCmsEB13T = VOUtils.toVo(trailer.getTlgCtt(), KftCmsEB13T.class);

        if(kftCmsEB13T.getTotalDataRecordCount() != (int) batContext.getData(SEQ)  ||
                kftCmsEB13T.getRegisterRequestCountRegistration() != (int) batContext.getData(NEW_COUNT) ||
                kftCmsEB13T.getRegisterRequestCountTermination() != (int) batContext.getData(DELETE_COUNT) ||
                kftCmsEB13T.getRegisterRequestCountModification() != (int) batContext.getData(MODIFY_COUNT) ||
                kftCmsEB13T.getRegisterRequestCountArbitraryTermination() != (int) batContext.getData(ARB_TERM_COUNT)) {
            
            log.debug("[I N F O]  =========================================================================== ");
            log.debug("[I N F O]  =                                 EB13 COUNT UNMATCH                                  = ");
            log.debug("[I N F O]  ======================================================================================= ");
            log.debug("[I N F O]  TOTAL                  : 【REQUEST = {}】 【PROC = {}】", 
                    kftCmsEB13T.getTotalDataRecordCount(), batContext.getData(SEQ));
            log.debug("[I N F O]  REGISTRATION           : 【REQUEST = {}】 【PROC = {}】", 
                    kftCmsEB13T.getRegisterRequestCountRegistration(), batContext.getData(NEW_COUNT));
            log.debug("[I N F O]  TERMINATION            : 【REQUEST = {}】 【PROC = {}】", 
                    kftCmsEB13T.getRegisterRequestCountTermination(), batContext.getData(DELETE_COUNT));
            log.debug("[I N F O]  MODIFICATION           : 【REQUEST = {}】 【PROC = {}】", 
                    kftCmsEB13T.getRegisterRequestCountModification(), batContext.getData(MODIFY_COUNT));
            log.debug("[I N F O]  TERMINATION_ARBIT      : 【REQUEST = {}】 【PROC = {}】", 
                    kftCmsEB13T.getRegisterRequestCountArbitraryTermination(), batContext.getData(ARB_TERM_COUNT));
            log.debug("[I N F O]  ==========================================================================================] ");

            // 기타 오류 (표준불능코드에 정의되지 않은 사유로 발생한 오류)
            respCd = CmsBatchRespCdEnum.ETC_ERROR.getCode();
        }

        if(!CmsBatchRespCdEnum.isNormal(respCd)) {
            cmsSndRcvLogManager.updateRcvFileLog(trailer, respCd);
        }

    }
}