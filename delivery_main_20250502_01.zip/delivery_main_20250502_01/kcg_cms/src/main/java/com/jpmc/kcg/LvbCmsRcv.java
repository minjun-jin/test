package com.jpmc.kcg;

import java.time.Duration;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.Charsets;
import org.apache.commons.io.HexDump;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.ThreadUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import com.ibm.mq.MQException;
import com.ibm.mq.MQGetMessageOptions;
import com.ibm.mq.MQMsg2;
import com.ibm.mq.MQPutMessageOptions;
import com.ibm.mq.MQQueue;
import com.ibm.mq.MQQueueManager;
import com.ibm.mq.constants.MQConstants;
import com.ibm.mq.spring.boot.MQConfigurationProperties;
import com.ibm.msg.client.jakarta.wmq.WMQConstants;
import com.jpmc.kcg.frw.FrwServiceExecutor;
import com.jpmc.kcg.frw.SystemProperties;

import jakarta.jms.Message;
import lombok.Generated;
import lombok.extern.slf4j.Slf4j;

@Generated
@Slf4j
@Component
@ConditionalOnProperty("ibm.mq.auto-configure")
public class LvbCmsRcv implements DisposableBean, InitializingBean, Runnable  {

	@Autowired
	private FrwServiceExecutor frwServiceExecutor;
	@Autowired
	private SystemProperties systemProperties;
	private ExecutorService executorService;

//	@JmsListener(concurrency = "${system.lvb.cms.con}", destination = "queue:///${system.lvb.cms.rcv}?receiveCCSID=970&receiveConversion=2")
	public void receiveJms(Message message) {
		frwServiceExecutor.execute(message);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		int nThreads = NumberUtils.toInt(systemProperties.getLvb().getCms().getCon());
		executorService = Executors.newFixedThreadPool(nThreads);
		for (int i = 0; i < nThreads; i++) {
			executorService.submit(this);
		}
	}

	@Override
	public void destroy() throws Exception {
		executorService.shutdown();
		while (!executorService.awaitTermination(1L, TimeUnit.SECONDS)) {
		}
	}

	@Autowired(required = false)
	private MQConfigurationProperties mqConfigurationProperties;
	private MQQueueManager newMQQueueManager() throws MQException {
		Properties properties = new Properties();
		properties.setProperty(MQConstants.HOST_NAME_PROPERTY, StringUtils.substringBefore(mqConfigurationProperties.getConnName(), '('));
		properties.put(MQConstants.PORT_PROPERTY, NumberUtils.createInteger(StringUtils.substringBetween(mqConfigurationProperties.getConnName(), "(", ")")));
		properties.setProperty(MQConstants.CHANNEL_PROPERTY, mqConfigurationProperties.getChannel());
		properties.setProperty(MQConstants.USER_ID_PROPERTY, mqConfigurationProperties.getUser());
		properties.setProperty(MQConstants.PASSWORD_PROPERTY, mqConfigurationProperties.getPassword());
		if (StringUtils.isNotEmpty(mqConfigurationProperties.getSslCipherSuite())) {
			properties.setProperty(MQConstants.SSL_CIPHER_SUITE_PROPERTY, mqConfigurationProperties.getSslCipherSuite());
		}
		return new MQQueueManager(mqConfigurationProperties.getQueueManager(), properties);
	}

	@Override
	public void run() {
		log.info("start");
		while (!executorService.isShutdown()) {
			try {
				MQQueueManager mqQueueManager = newMQQueueManager();
				try {
					MQQueue mqGetQueue = mqQueueManager.accessQueue(systemProperties.getLvb().getCms().getRcv(), MQConstants.MQOO_INPUT_AS_Q_DEF + MQConstants.MQOO_FAIL_IF_QUIESCING);
					MQGetMessageOptions mqGetMessageOptions = new MQGetMessageOptions();
					mqGetMessageOptions.options = MQConstants.MQGMO_SYNCPOINT + MQConstants.MQGMO_WAIT + MQConstants.MQGMO_CONVERT;
					mqGetMessageOptions.waitInterval = NumberUtils.toInt(System.getProperty("system.lvb.cms.rcv.wait-interval", "1000"));
					try {
						MQQueue mqPutQueue = mqQueueManager.accessQueue(systemProperties.getKcg().getCms().getCmn(), MQConstants.MQOO_OUTPUT + MQConstants.MQOO_FAIL_IF_QUIESCING);
						MQPutMessageOptions mqPutMessageOptions = new MQPutMessageOptions();
						mqPutMessageOptions.options = MQConstants.MQPMO_SYNCPOINT;
						try {
							boolean hexDump = Boolean.getBoolean("system.lvb.cms.rcv.hex-dump");
							while (!executorService.isShutdown()) {
								MQMsg2 mqMsg2 = new MQMsg2();
								mqMsg2.setFormat(MQConstants.MQFMT_STRING);
								mqMsg2.setCharacterSet(970);
								try {
									mqGetQueue.getMsg2(mqMsg2, mqGetMessageOptions);
								} catch (MQException e) {
									if ((MQConstants.MQCC_FAILED == e.getCompCode()) &&
										(MQConstants.MQRC_NO_MSG_AVAILABLE == e.getReason())) {
										continue;
									}
									throw e;
								}
								byte[] byteArray = mqMsg2.getMessageData();
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// RFH2헤더보정 ///////////////////////////////////
								if ('R' == byteArray[0] &&
									'F' == byteArray[1] &&
									'H' == byteArray[2]) {
									for (int i = 0; i < byteArray.length - 5; i++) {
										if ('<' == byteArray[i + 0] &&
											'/' == byteArray[i + 1] &&
											'u' == byteArray[i + 2] &&
											's' == byteArray[i + 3] &&
											'r' == byteArray[i + 4] &&
											'>' == byteArray[i + 5]) {
											byteArray = ArrayUtils.subarray(byteArray, i + 6, byteArray.length);
											break;
										}
									}
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// 전문덤프 ///////////////////////////////////////
								if (hexDump) {
									StringBuilder sb = new StringBuilder(System.lineSeparator());
									HexDump.dump(byteArray, sb);
									log.debug("{}", sb.toString());
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
								String tlgCtt = IOUtils.toString(byteArray, "EUC-KR");
								log.info("<{}]", tlgCtt);
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// 전각한글한자보정 ///////////////////////////////
								for (int i = 0; i < byteArray.length; i++) {
									if ((byte) 0xa1 <= byteArray[i] &&
										(byte) 0xaf >= byteArray[i]) { // 전각보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xa1 <= byteArray[i] &&
											(byte) 0x80 <= byteArray[i + 1] &&
											(byte) 0xaf >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
									if ((byte) 0xb0 <= byteArray[i] &&
										(byte) 0xc9 >= byteArray[i]) { // 한글보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xb0 <= byteArray[i] &&
											(byte) 0xa1 <= byteArray[i + 1] &&
											(byte) 0xc9 >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
									if ((byte) 0xca <= byteArray[i] &&
										(byte) 0xfd >= byteArray[i]) { // 한자보정
										if (byteArray.length <= (i + 1)) {
											byteArray[i] = 0x20;
											break;
										}
										if ((byte) 0xca <= byteArray[i] &&
											(byte) 0x80 <= byteArray[i + 1] &&
											(byte) 0xfd >= byteArray[i] &&
											(byte) 0xff >= byteArray[i + 1]) {
											i++;
										} else {
											byteArray[i] = 0x20;
										}
										continue;
									}
								}
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
								tlgCtt = IOUtils.toString(byteArray, "EUC-KR");
								log.info(">{}]", tlgCtt);
								mqMsg2 = new MQMsg2();
								mqMsg2.setFormat(MQConstants.MQFMT_STRING);
								mqMsg2.setCharacterSet(WMQConstants.CCSID_UTF8);
								mqMsg2.setMessageData(StringUtils.getBytes(tlgCtt, Charsets.toCharset("UTF-8")));
								mqMsg2.setPriority(4);
								mqPutQueue.putMsg2(mqMsg2, mqPutMessageOptions);
								mqQueueManager.commit();
							}
						} finally {
							mqPutQueue.close();
						}
					} finally {
						mqGetQueue.close();
					}
				}
				finally {
					try {
						mqQueueManager.close();
					} finally {
						mqQueueManager.disconnect();
					}
				}
			} catch (Throwable t) {
				log.error(ExceptionUtils.getRootCauseMessage(t), t);
			}
			ThreadUtils.sleepQuietly(Duration.ofSeconds(1L));
		}
		log.info("stop");
	}

}
