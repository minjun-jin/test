package com.jpmc.kcg.hof.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 전자금융공동망 차액결제자료
 * <pre>{@code
 * KftHofEL0066R kftHofEL0066R  = new KftHofEL0066R(); // 전자금융공동망 차액결제자료
 * kftHofEL0066R.setFileName(""); // 업무구분
 * kftHofEL0066R.setDataType(""); // 데이타구분
 * kftHofEL0066R.setSerialNumber(""); // 일련번호
 * kftHofEL0066R.setBnkCd(""); // 은행코드
 * kftHofEL0066R.setDebitCreditFlag(""); // 대차구분1
 * kftHofEL0066R.setNetSettlementAmount(0L); // 차액결제금액
 * kftHofEL0066R.setDebitCreditFlag1(""); // 대차구분2
 * kftHofEL0066R.setFundAdjustmentAmount(0L); // 자금조정금액
 * kftHofEL0066R.setDebitCreditFlag2(""); // 대차구분3
 * kftHofEL0066R.setServiceFeeAmount(0L); // 수수료금액
 * kftHofEL0066R.setFiller(""); // FILLER
 * }</pre>
 */
@Data
public class KftHofEL0066R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이타구분
	private String serialNumber; // 일련번호
	private String bnkCd; // 은행코드
	private String debitCreditFlag; // 대차구분1
	private long netSettlementAmount; // 차액결제금액
	private String debitCreditFlag1; // 대차구분2
	private long fundAdjustmentAmount; // 자금조정금액
	private String debitCreditFlag2; // 대차구분3
	private long serviceFeeAmount; // 수수료금액
	private String filler; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이타구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bnkCd$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCreditFlag$; // 대차구분1
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String netSettlementAmount$; // 차액결제금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCreditFlag1$; // 대차구분2
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fundAdjustmentAmount$; // 자금조정금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String debitCreditFlag2$; // 대차구분3
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serviceFeeAmount$; // 수수료금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이타구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		bnkCd$ = VOUtils.write(out, bnkCd, 3); // 은행코드
		debitCreditFlag$ = VOUtils.write(out, debitCreditFlag, 1); // 대차구분1
		netSettlementAmount$ = VOUtils.write(out, netSettlementAmount, 15); // 차액결제금액
		debitCreditFlag1$ = VOUtils.write(out, debitCreditFlag1, 1); // 대차구분2
		fundAdjustmentAmount$ = VOUtils.write(out, fundAdjustmentAmount, 15); // 자금조정금액
		debitCreditFlag2$ = VOUtils.write(out, debitCreditFlag2, 1); // 대차구분3
		serviceFeeAmount$ = VOUtils.write(out, serviceFeeAmount, 15); // 수수료금액
		filler$ = VOUtils.write(out, filler, 8); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이타구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		bnkCd = VOUtils.toString(bnkCd$ = VOUtils.read(in, 3)); // 은행코드
		debitCreditFlag = VOUtils.toString(debitCreditFlag$ = VOUtils.read(in, 1)); // 대차구분1
		netSettlementAmount = VOUtils.toLong(netSettlementAmount$ = VOUtils.read(in, 15)); // 차액결제금액
		debitCreditFlag1 = VOUtils.toString(debitCreditFlag1$ = VOUtils.read(in, 1)); // 대차구분2
		fundAdjustmentAmount = VOUtils.toLong(fundAdjustmentAmount$ = VOUtils.read(in, 15)); // 자금조정금액
		debitCreditFlag2 = VOUtils.toString(debitCreditFlag2$ = VOUtils.read(in, 1)); // 대차구분3
		serviceFeeAmount = VOUtils.toLong(serviceFeeAmount$ = VOUtils.read(in, 15)); // 수수료금액
		filler = VOUtils.toString(filler$ = VOUtils.read(in, 8)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이타구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", bnkCd=").append(bnkCd).append(System.lineSeparator()); // 은행코드
		sb.append(", debitCreditFlag=").append(debitCreditFlag).append(System.lineSeparator()); // 대차구분1
		sb.append(", netSettlementAmount=").append(netSettlementAmount).append(System.lineSeparator()); // 차액결제금액
		sb.append(", debitCreditFlag1=").append(debitCreditFlag1).append(System.lineSeparator()); // 대차구분2
		sb.append(", fundAdjustmentAmount=").append(fundAdjustmentAmount).append(System.lineSeparator()); // 자금조정금액
		sb.append(", debitCreditFlag2=").append(debitCreditFlag2).append(System.lineSeparator()); // 대차구분3
		sb.append(", serviceFeeAmount=").append(serviceFeeAmount).append(System.lineSeparator()); // 수수료금액
		sb.append(", filler=").append(filler).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "bnkCd", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "debitCreditFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "netSettlementAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "debitCreditFlag1", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "fundAdjustmentAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "debitCreditFlag2", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "serviceFeeAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "filler", "fldLen", "8", "defltVal", "")
		);
	}

}
