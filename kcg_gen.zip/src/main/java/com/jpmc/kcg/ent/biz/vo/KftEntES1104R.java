package com.jpmc.kcg.ent.biz.vo;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import com.jpmc.kcg.frw.VOUtils;
import com.jpmc.kcg.frw.Vo;

import lombok.AccessLevel;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * 보증(발행) 결과보고내역
 * <pre>{@code
 * KftEntES1104R kftEntES1104R  = new KftEntES1104R(); // 보증(발행) 결과보고내역
 * kftEntES1104R.setFileName(""); // 업무구분
 * kftEntES1104R.setDataType(""); // 데이터구분
 * kftEntES1104R.setSerialNumber(""); // 일련번호
 * kftEntES1104R.setSendReceiveFlag(""); // 구분코드
 * kftEntES1104R.setBankCode(""); // 은행코드
 * kftEntES1104R.setBeforeAfterIssueSort(""); // 보증요청 발행 전/후 구분
 * kftEntES1104R.setGuaranteeProcessingDate(""); // 보증요청일자
 * kftEntES1104R.setGuaranteeRequestDate(""); // 보증처리일자
 * kftEntES1104R.setGuaranteeProcessSort(""); // 보증처리구분
 * kftEntES1104R.setEnoteNumber(""); // 어음번호
 * kftEntES1104R.setEnoteType(""); // 어음종류
 * kftEntES1104R.setEnoteIssueDate(""); // 어음발행일자
 * kftEntES1104R.setEnoteIssuePlace(""); // 어음발행지
 * kftEntES1104R.setEnoteIssueAmount(0L); // 어음발행금액
 * kftEntES1104R.setEnoteMaturedDate(""); // 어음만기일자
 * kftEntES1104R.setPaymentBankCode(""); // 지급은행 및 지점코드
 * kftEntES1104R.setIssuerCorpIndvSort(""); // 발행인(피보증인)-법인개인구분
 * kftEntES1104R.setIssuerResidentBusinessNumber(""); // 발행인(피보증인)-주민사업자번호
 * kftEntES1104R.setIssuerCorpName(""); // 발행인(피보증인)-법인명
 * kftEntES1104R.setIssuerNameRepresentativeName(""); // 발행인(피보증인)-성명(대표자명)
 * kftEntES1104R.setIssuerAddress(""); // 발행인(피보증인)-주소
 * kftEntES1104R.setIssuerBankCode(""); // 발행인(피보증인)-은행코드
 * kftEntES1104R.setIssuerCurrentAccountNumber(""); // 발행인(피보증인)-당좌계좌번호
 * kftEntES1104R.setBeneficiaryCorpIndvSort(""); // 수취인-법인개인구분
 * kftEntES1104R.setBeneficiaryResidentBusinessNumber(""); // 수취인-주민사업자번호
 * kftEntES1104R.setBeneficiaryCorpName(""); // 수취인-법인명
 * kftEntES1104R.setBeneficiaryNameRepresentativeName(""); // 수취인-성명(대표자명)
 * kftEntES1104R.setBeneficiaryAddress(""); // 수취인-주소
 * kftEntES1104R.setBeneficiaryBankCode(""); // 수취인-수취은행코드
 * kftEntES1104R.setBeneficiaryDepositAccountNumber(""); // 수취인-입금계좌번호
 * kftEntES1104R.setProhibitedInstructionYn(""); // 지시금지여부
 * kftEntES1104R.setGuarantorCorpIndvSort(""); // 보증인-법인개인구분
 * kftEntES1104R.setGuarantorResidentBusinessNumber(""); // 보증인-주민사업자번호
 * kftEntES1104R.setGuarantorCorpName(""); // 보증인-법인명
 * kftEntES1104R.setGuarantorNameRepresentativeName(""); // 보증인-성명(대표자명)
 * kftEntES1104R.setGuarantorAddress(""); // 보증인-주소
 * kftEntES1104R.setGuarantorBankCode(""); // 보증인-은행코드
 * kftEntES1104R.setGuarantorDepositAccountNumber(""); // 보증인-입금계좌번호
 * kftEntES1104R.setGuaranteeNumber(""); // 보증번호
 * kftEntES1104R.setGuaranteeProcessingParticipationSort(""); // 보증처리 참가구분
 * kftEntES1104R.setFiller2(""); // FILLER
 * }</pre>
 */
@Data
public class KftEntES1104R implements Vo {

	private String fileName; // 업무구분
	private String dataType; // 데이터구분
	private String serialNumber; // 일련번호
	private String sendReceiveFlag; // 구분코드
	private String bankCode; // 은행코드
	private String beforeAfterIssueSort; // 보증요청 발행 전/후 구분
	private String guaranteeProcessingDate; // 보증요청일자
	private String guaranteeRequestDate; // 보증처리일자
	private String guaranteeProcessSort; // 보증처리구분
	private String enoteNumber; // 어음번호
	private String enoteType; // 어음종류
	private String enoteIssueDate; // 어음발행일자
	private String enoteIssuePlace; // 어음발행지
	private long enoteIssueAmount; // 어음발행금액
	private String enoteMaturedDate; // 어음만기일자
	private String paymentBankCode; // 지급은행 및 지점코드
	private String issuerCorpIndvSort; // 발행인(피보증인)-법인개인구분
	private String issuerResidentBusinessNumber; // 발행인(피보증인)-주민사업자번호
	private String issuerCorpName; // 발행인(피보증인)-법인명
	private String issuerNameRepresentativeName; // 발행인(피보증인)-성명(대표자명)
	private String issuerAddress; // 발행인(피보증인)-주소
	private String issuerBankCode; // 발행인(피보증인)-은행코드
	private String issuerCurrentAccountNumber; // 발행인(피보증인)-당좌계좌번호
	private String beneficiaryCorpIndvSort; // 수취인-법인개인구분
	private String beneficiaryResidentBusinessNumber; // 수취인-주민사업자번호
	private String beneficiaryCorpName; // 수취인-법인명
	private String beneficiaryNameRepresentativeName; // 수취인-성명(대표자명)
	private String beneficiaryAddress; // 수취인-주소
	private String beneficiaryBankCode; // 수취인-수취은행코드
	private String beneficiaryDepositAccountNumber; // 수취인-입금계좌번호
	private String prohibitedInstructionYn; // 지시금지여부
	private String guarantorCorpIndvSort; // 보증인-법인개인구분
	private String guarantorResidentBusinessNumber; // 보증인-주민사업자번호
	private String guarantorCorpName; // 보증인-법인명
	private String guarantorNameRepresentativeName; // 보증인-성명(대표자명)
	private String guarantorAddress; // 보증인-주소
	private String guarantorBankCode; // 보증인-은행코드
	private String guarantorDepositAccountNumber; // 보증인-입금계좌번호
	private String guaranteeNumber; // 보증번호
	private String guaranteeProcessingParticipationSort; // 보증처리 참가구분
	private String filler2; // FILLER
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String fileName$; // 업무구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String dataType$; // 데이터구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String serialNumber$; // 일련번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String sendReceiveFlag$; // 구분코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String bankCode$; // 은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beforeAfterIssueSort$; // 보증요청 발행 전/후 구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeProcessingDate$; // 보증요청일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeRequestDate$; // 보증처리일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeProcessSort$; // 보증처리구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteNumber$; // 어음번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteType$; // 어음종류
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueDate$; // 어음발행일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssuePlace$; // 어음발행지
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteIssueAmount$; // 어음발행금액
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String enoteMaturedDate$; // 어음만기일자
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String paymentBankCode$; // 지급은행 및 지점코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpIndvSort$; // 발행인(피보증인)-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerResidentBusinessNumber$; // 발행인(피보증인)-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCorpName$; // 발행인(피보증인)-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerNameRepresentativeName$; // 발행인(피보증인)-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerAddress$; // 발행인(피보증인)-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerBankCode$; // 발행인(피보증인)-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String issuerCurrentAccountNumber$; // 발행인(피보증인)-당좌계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryCorpIndvSort$; // 수취인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryResidentBusinessNumber$; // 수취인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryCorpName$; // 수취인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryNameRepresentativeName$; // 수취인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryAddress$; // 수취인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryBankCode$; // 수취인-수취은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String beneficiaryDepositAccountNumber$; // 수취인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String prohibitedInstructionYn$; // 지시금지여부
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorCorpIndvSort$; // 보증인-법인개인구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorResidentBusinessNumber$; // 보증인-주민사업자번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorCorpName$; // 보증인-법인명
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorNameRepresentativeName$; // 보증인-성명(대표자명)
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorAddress$; // 보증인-주소
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorBankCode$; // 보증인-은행코드
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guarantorDepositAccountNumber$; // 보증인-입금계좌번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeNumber$; // 보증번호
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String guaranteeProcessingParticipationSort$; // 보증처리 참가구분
	@EqualsAndHashCode.Exclude
	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private String filler2$; // FILLER

	@Override
	public void write(OutputStream out) throws IOException {
		fileName$ = VOUtils.write(out, fileName, 6); // 업무구분
		dataType$ = VOUtils.write(out, dataType, 2); // 데이터구분
		serialNumber$ = VOUtils.write(out, serialNumber, 7); // 일련번호
		sendReceiveFlag$ = VOUtils.write(out, sendReceiveFlag, 1); // 구분코드
		bankCode$ = VOUtils.write(out, bankCode, 3); // 은행코드
		beforeAfterIssueSort$ = VOUtils.write(out, beforeAfterIssueSort, 1); // 보증요청 발행 전/후 구분
		guaranteeProcessingDate$ = VOUtils.write(out, guaranteeProcessingDate, 8); // 보증요청일자
		guaranteeRequestDate$ = VOUtils.write(out, guaranteeRequestDate, 8); // 보증처리일자
		guaranteeProcessSort$ = VOUtils.write(out, guaranteeProcessSort, 1); // 보증처리구분
		enoteNumber$ = VOUtils.write(out, enoteNumber, 20); // 어음번호
		enoteType$ = VOUtils.write(out, enoteType, 1); // 어음종류
		enoteIssueDate$ = VOUtils.write(out, enoteIssueDate, 8); // 어음발행일자
		enoteIssuePlace$ = VOUtils.write(out, enoteIssuePlace, 60, "EUC-KR"); // 어음발행지
		enoteIssueAmount$ = VOUtils.write(out, enoteIssueAmount, 15); // 어음발행금액
		enoteMaturedDate$ = VOUtils.write(out, enoteMaturedDate, 8); // 어음만기일자
		paymentBankCode$ = VOUtils.write(out, paymentBankCode, 7); // 지급은행 및 지점코드
		issuerCorpIndvSort$ = VOUtils.write(out, issuerCorpIndvSort, 1); // 발행인(피보증인)-법인개인구분
		issuerResidentBusinessNumber$ = VOUtils.write(out, issuerResidentBusinessNumber, 13); // 발행인(피보증인)-주민사업자번호
		issuerCorpName$ = VOUtils.write(out, issuerCorpName, 40, "EUC-KR"); // 발행인(피보증인)-법인명
		issuerNameRepresentativeName$ = VOUtils.write(out, issuerNameRepresentativeName, 20, "EUC-KR"); // 발행인(피보증인)-성명(대표자명)
		issuerAddress$ = VOUtils.write(out, issuerAddress, 60, "EUC-KR"); // 발행인(피보증인)-주소
		issuerBankCode$ = VOUtils.write(out, issuerBankCode, 3); // 발행인(피보증인)-은행코드
		issuerCurrentAccountNumber$ = VOUtils.write(out, issuerCurrentAccountNumber, 16); // 발행인(피보증인)-당좌계좌번호
		beneficiaryCorpIndvSort$ = VOUtils.write(out, beneficiaryCorpIndvSort, 1); // 수취인-법인개인구분
		beneficiaryResidentBusinessNumber$ = VOUtils.write(out, beneficiaryResidentBusinessNumber, 13); // 수취인-주민사업자번호
		beneficiaryCorpName$ = VOUtils.write(out, beneficiaryCorpName, 40, "EUC-KR"); // 수취인-법인명
		beneficiaryNameRepresentativeName$ = VOUtils.write(out, beneficiaryNameRepresentativeName, 20, "EUC-KR"); // 수취인-성명(대표자명)
		beneficiaryAddress$ = VOUtils.write(out, beneficiaryAddress, 60, "EUC-KR"); // 수취인-주소
		beneficiaryBankCode$ = VOUtils.write(out, beneficiaryBankCode, 3); // 수취인-수취은행코드
		beneficiaryDepositAccountNumber$ = VOUtils.write(out, beneficiaryDepositAccountNumber, 16); // 수취인-입금계좌번호
		prohibitedInstructionYn$ = VOUtils.write(out, prohibitedInstructionYn, 1); // 지시금지여부
		guarantorCorpIndvSort$ = VOUtils.write(out, guarantorCorpIndvSort, 1); // 보증인-법인개인구분
		guarantorResidentBusinessNumber$ = VOUtils.write(out, guarantorResidentBusinessNumber, 13); // 보증인-주민사업자번호
		guarantorCorpName$ = VOUtils.write(out, guarantorCorpName, 40, "EUC-KR"); // 보증인-법인명
		guarantorNameRepresentativeName$ = VOUtils.write(out, guarantorNameRepresentativeName, 20, "EUC-KR"); // 보증인-성명(대표자명)
		guarantorAddress$ = VOUtils.write(out, guarantorAddress, 60, "EUC-KR"); // 보증인-주소
		guarantorBankCode$ = VOUtils.write(out, guarantorBankCode, 3); // 보증인-은행코드
		guarantorDepositAccountNumber$ = VOUtils.write(out, guarantorDepositAccountNumber, 16); // 보증인-입금계좌번호
		guaranteeNumber$ = VOUtils.write(out, guaranteeNumber, 4); // 보증번호
		guaranteeProcessingParticipationSort$ = VOUtils.write(out, guaranteeProcessingParticipationSort, 1); // 보증처리 참가구분
		filler2$ = VOUtils.write(out, filler2, 29); // FILLER
	}

	@Override
	public void read(InputStream in) throws IOException {
		fileName = VOUtils.toString(fileName$ = VOUtils.read(in, 6)); // 업무구분
		dataType = VOUtils.toString(dataType$ = VOUtils.read(in, 2)); // 데이터구분
		serialNumber = VOUtils.toString(serialNumber$ = VOUtils.read(in, 7)); // 일련번호
		sendReceiveFlag = VOUtils.toString(sendReceiveFlag$ = VOUtils.read(in, 1)); // 구분코드
		bankCode = VOUtils.toString(bankCode$ = VOUtils.read(in, 3)); // 은행코드
		beforeAfterIssueSort = VOUtils.toString(beforeAfterIssueSort$ = VOUtils.read(in, 1)); // 보증요청 발행 전/후 구분
		guaranteeProcessingDate = VOUtils.toString(guaranteeProcessingDate$ = VOUtils.read(in, 8)); // 보증요청일자
		guaranteeRequestDate = VOUtils.toString(guaranteeRequestDate$ = VOUtils.read(in, 8)); // 보증처리일자
		guaranteeProcessSort = VOUtils.toString(guaranteeProcessSort$ = VOUtils.read(in, 1)); // 보증처리구분
		enoteNumber = VOUtils.toString(enoteNumber$ = VOUtils.read(in, 20)); // 어음번호
		enoteType = VOUtils.toString(enoteType$ = VOUtils.read(in, 1)); // 어음종류
		enoteIssueDate = VOUtils.toString(enoteIssueDate$ = VOUtils.read(in, 8)); // 어음발행일자
		enoteIssuePlace = VOUtils.toString(enoteIssuePlace$ = VOUtils.read(in, 60, "EUC-KR")); // 어음발행지
		enoteIssueAmount = VOUtils.toLong(enoteIssueAmount$ = VOUtils.read(in, 15)); // 어음발행금액
		enoteMaturedDate = VOUtils.toString(enoteMaturedDate$ = VOUtils.read(in, 8)); // 어음만기일자
		paymentBankCode = VOUtils.toString(paymentBankCode$ = VOUtils.read(in, 7)); // 지급은행 및 지점코드
		issuerCorpIndvSort = VOUtils.toString(issuerCorpIndvSort$ = VOUtils.read(in, 1)); // 발행인(피보증인)-법인개인구분
		issuerResidentBusinessNumber = VOUtils.toString(issuerResidentBusinessNumber$ = VOUtils.read(in, 13)); // 발행인(피보증인)-주민사업자번호
		issuerCorpName = VOUtils.toString(issuerCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 발행인(피보증인)-법인명
		issuerNameRepresentativeName = VOUtils.toString(issuerNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 발행인(피보증인)-성명(대표자명)
		issuerAddress = VOUtils.toString(issuerAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 발행인(피보증인)-주소
		issuerBankCode = VOUtils.toString(issuerBankCode$ = VOUtils.read(in, 3)); // 발행인(피보증인)-은행코드
		issuerCurrentAccountNumber = VOUtils.toString(issuerCurrentAccountNumber$ = VOUtils.read(in, 16)); // 발행인(피보증인)-당좌계좌번호
		beneficiaryCorpIndvSort = VOUtils.toString(beneficiaryCorpIndvSort$ = VOUtils.read(in, 1)); // 수취인-법인개인구분
		beneficiaryResidentBusinessNumber = VOUtils.toString(beneficiaryResidentBusinessNumber$ = VOUtils.read(in, 13)); // 수취인-주민사업자번호
		beneficiaryCorpName = VOUtils.toString(beneficiaryCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 수취인-법인명
		beneficiaryNameRepresentativeName = VOUtils.toString(beneficiaryNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 수취인-성명(대표자명)
		beneficiaryAddress = VOUtils.toString(beneficiaryAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 수취인-주소
		beneficiaryBankCode = VOUtils.toString(beneficiaryBankCode$ = VOUtils.read(in, 3)); // 수취인-수취은행코드
		beneficiaryDepositAccountNumber = VOUtils.toString(beneficiaryDepositAccountNumber$ = VOUtils.read(in, 16)); // 수취인-입금계좌번호
		prohibitedInstructionYn = VOUtils.toString(prohibitedInstructionYn$ = VOUtils.read(in, 1)); // 지시금지여부
		guarantorCorpIndvSort = VOUtils.toString(guarantorCorpIndvSort$ = VOUtils.read(in, 1)); // 보증인-법인개인구분
		guarantorResidentBusinessNumber = VOUtils.toString(guarantorResidentBusinessNumber$ = VOUtils.read(in, 13)); // 보증인-주민사업자번호
		guarantorCorpName = VOUtils.toString(guarantorCorpName$ = VOUtils.read(in, 40, "EUC-KR")); // 보증인-법인명
		guarantorNameRepresentativeName = VOUtils.toString(guarantorNameRepresentativeName$ = VOUtils.read(in, 20, "EUC-KR")); // 보증인-성명(대표자명)
		guarantorAddress = VOUtils.toString(guarantorAddress$ = VOUtils.read(in, 60, "EUC-KR")); // 보증인-주소
		guarantorBankCode = VOUtils.toString(guarantorBankCode$ = VOUtils.read(in, 3)); // 보증인-은행코드
		guarantorDepositAccountNumber = VOUtils.toString(guarantorDepositAccountNumber$ = VOUtils.read(in, 16)); // 보증인-입금계좌번호
		guaranteeNumber = VOUtils.toString(guaranteeNumber$ = VOUtils.read(in, 4)); // 보증번호
		guaranteeProcessingParticipationSort = VOUtils.toString(guaranteeProcessingParticipationSort$ = VOUtils.read(in, 1)); // 보증처리 참가구분
		filler2 = VOUtils.toString(filler2$ = VOUtils.read(in, 29)); // FILLER
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(getClass().getSimpleName());
		sb.append(" [");
		sb.append("Hash = ").append(hashCode()).append(System.lineSeparator());
		sb.append(", fileName=").append(fileName).append(System.lineSeparator()); // 업무구분
		sb.append(", dataType=").append(dataType).append(System.lineSeparator()); // 데이터구분
		sb.append(", serialNumber=").append(serialNumber).append(System.lineSeparator()); // 일련번호
		sb.append(", sendReceiveFlag=").append(sendReceiveFlag).append(System.lineSeparator()); // 구분코드
		sb.append(", bankCode=").append(bankCode).append(System.lineSeparator()); // 은행코드
		sb.append(", beforeAfterIssueSort=").append(beforeAfterIssueSort).append(System.lineSeparator()); // 보증요청 발행 전/후 구분
		sb.append(", guaranteeProcessingDate=").append(guaranteeProcessingDate).append(System.lineSeparator()); // 보증요청일자
		sb.append(", guaranteeRequestDate=").append(guaranteeRequestDate).append(System.lineSeparator()); // 보증처리일자
		sb.append(", guaranteeProcessSort=").append(guaranteeProcessSort).append(System.lineSeparator()); // 보증처리구분
		sb.append(", enoteNumber=").append(enoteNumber).append(System.lineSeparator()); // 어음번호
		sb.append(", enoteType=").append(enoteType).append(System.lineSeparator()); // 어음종류
		sb.append(", enoteIssueDate=").append(enoteIssueDate).append(System.lineSeparator()); // 어음발행일자
		sb.append(", enoteIssuePlace=").append(enoteIssuePlace).append(System.lineSeparator()); // 어음발행지
		sb.append(", enoteIssueAmount=").append(enoteIssueAmount).append(System.lineSeparator()); // 어음발행금액
		sb.append(", enoteMaturedDate=").append(enoteMaturedDate).append(System.lineSeparator()); // 어음만기일자
		sb.append(", paymentBankCode=").append(paymentBankCode).append(System.lineSeparator()); // 지급은행 및 지점코드
		sb.append(", issuerCorpIndvSort=").append(issuerCorpIndvSort).append(System.lineSeparator()); // 발행인(피보증인)-법인개인구분
		sb.append(", issuerResidentBusinessNumber=").append(issuerResidentBusinessNumber).append(System.lineSeparator()); // 발행인(피보증인)-주민사업자번호
		sb.append(", issuerCorpName=").append(issuerCorpName).append(System.lineSeparator()); // 발행인(피보증인)-법인명
		sb.append(", issuerNameRepresentativeName=").append(issuerNameRepresentativeName).append(System.lineSeparator()); // 발행인(피보증인)-성명(대표자명)
		sb.append(", issuerAddress=").append(issuerAddress).append(System.lineSeparator()); // 발행인(피보증인)-주소
		sb.append(", issuerBankCode=").append(issuerBankCode).append(System.lineSeparator()); // 발행인(피보증인)-은행코드
		sb.append(", issuerCurrentAccountNumber=").append(issuerCurrentAccountNumber).append(System.lineSeparator()); // 발행인(피보증인)-당좌계좌번호
		sb.append(", beneficiaryCorpIndvSort=").append(beneficiaryCorpIndvSort).append(System.lineSeparator()); // 수취인-법인개인구분
		sb.append(", beneficiaryResidentBusinessNumber=").append(beneficiaryResidentBusinessNumber).append(System.lineSeparator()); // 수취인-주민사업자번호
		sb.append(", beneficiaryCorpName=").append(beneficiaryCorpName).append(System.lineSeparator()); // 수취인-법인명
		sb.append(", beneficiaryNameRepresentativeName=").append(beneficiaryNameRepresentativeName).append(System.lineSeparator()); // 수취인-성명(대표자명)
		sb.append(", beneficiaryAddress=").append(beneficiaryAddress).append(System.lineSeparator()); // 수취인-주소
		sb.append(", beneficiaryBankCode=").append(beneficiaryBankCode).append(System.lineSeparator()); // 수취인-수취은행코드
		sb.append(", beneficiaryDepositAccountNumber=").append(beneficiaryDepositAccountNumber).append(System.lineSeparator()); // 수취인-입금계좌번호
		sb.append(", prohibitedInstructionYn=").append(prohibitedInstructionYn).append(System.lineSeparator()); // 지시금지여부
		sb.append(", guarantorCorpIndvSort=").append(guarantorCorpIndvSort).append(System.lineSeparator()); // 보증인-법인개인구분
		sb.append(", guarantorResidentBusinessNumber=").append(guarantorResidentBusinessNumber).append(System.lineSeparator()); // 보증인-주민사업자번호
		sb.append(", guarantorCorpName=").append(guarantorCorpName).append(System.lineSeparator()); // 보증인-법인명
		sb.append(", guarantorNameRepresentativeName=").append(guarantorNameRepresentativeName).append(System.lineSeparator()); // 보증인-성명(대표자명)
		sb.append(", guarantorAddress=").append(guarantorAddress).append(System.lineSeparator()); // 보증인-주소
		sb.append(", guarantorBankCode=").append(guarantorBankCode).append(System.lineSeparator()); // 보증인-은행코드
		sb.append(", guarantorDepositAccountNumber=").append(guarantorDepositAccountNumber).append(System.lineSeparator()); // 보증인-입금계좌번호
		sb.append(", guaranteeNumber=").append(guaranteeNumber).append(System.lineSeparator()); // 보증번호
		sb.append(", guaranteeProcessingParticipationSort=").append(guaranteeProcessingParticipationSort).append(System.lineSeparator()); // 보증처리 참가구분
		sb.append(", filler2=").append(filler2).append(System.lineSeparator()); // FILLER
		sb.append("]");
		return sb.toString();
	}

	public static List<Map<String, String>> test() {
		return List.of(
			Map.of("fld", "fileName", "fldLen", "6", "defltVal", ""),
			Map.of("fld", "dataType", "fldLen", "2", "defltVal", ""),
			Map.of("fld", "serialNumber", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "sendReceiveFlag", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "bankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beforeAfterIssueSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guaranteeProcessingDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeRequestDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "guaranteeProcessSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteNumber", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "enoteType", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "enoteIssueDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "enoteIssuePlace", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "enoteIssueAmount", "fldLen", "15", "defltVal", ""),
			Map.of("fld", "enoteMaturedDate", "fldLen", "8", "defltVal", ""),
			Map.of("fld", "paymentBankCode", "fldLen", "7", "defltVal", ""),
			Map.of("fld", "issuerCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "issuerResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "issuerCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "issuerNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "issuerAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "issuerBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "issuerCurrentAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "beneficiaryCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "beneficiaryResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "beneficiaryCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "beneficiaryNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "beneficiaryAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "beneficiaryBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "beneficiaryDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "prohibitedInstructionYn", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorCorpIndvSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "guarantorResidentBusinessNumber", "fldLen", "13", "defltVal", ""),
			Map.of("fld", "guarantorCorpName", "fldLen", "40", "defltVal", ""),
			Map.of("fld", "guarantorNameRepresentativeName", "fldLen", "20", "defltVal", ""),
			Map.of("fld", "guarantorAddress", "fldLen", "60", "defltVal", ""),
			Map.of("fld", "guarantorBankCode", "fldLen", "3", "defltVal", ""),
			Map.of("fld", "guarantorDepositAccountNumber", "fldLen", "16", "defltVal", ""),
			Map.of("fld", "guaranteeNumber", "fldLen", "4", "defltVal", ""),
			Map.of("fld", "guaranteeProcessingParticipationSort", "fldLen", "1", "defltVal", ""),
			Map.of("fld", "filler2", "fldLen", "29", "defltVal", "")
		);
	}

}
